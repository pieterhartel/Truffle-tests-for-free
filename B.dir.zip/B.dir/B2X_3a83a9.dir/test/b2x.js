const B2X = artifacts.require( "./B2X.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "B2X" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x9c9891F7795eB127BA4783B671573275fF3a83A9", "0x4D5CB4f7a8ABF01FEb3Cf6a3DDA53655d421e699", "0x03783AEd140aaA1735C7385987Fb1C497D1360ea", "0x74360D87E08E51308eB58cf638f1648929a19405", "0xb9B23e43a13E9d14893817009d333A9Bb1332bd1", "0x01E48Ba2192a1985629Fb84D6b5e4Cc010a6B580", "0x0d2857dA4BbCa20170a5CA386f0F6b6E55124b03", "0xFA9d7B38A3eD1236a13b43208c89E259DBb0F322", "0xdE8904A8156999eFb4CAb571bd995321F0099bb9", "0x7Fad87286B630708603103366F341c68f245af05", "0x2dAAb98856F45084a1285Bcc84B42ec5D75b35ef", "0x00E8697E899125607cd92b0d5dDEceEC1dE57FD1", "0x925D5cFe689b63F6767F30E40C16354a6E49f5ad", "0x91175E751ACa4b73387Cdf7Ed11388E250DF98fE", "0x061A9e47e89219a6035A0f84C7f332Bcf37Fe05A", "0x01712100a965E20bE132a217114b474Cd3EA1e8A", "0x0406E788380E5abbf91ce4157EfD3F827D2c6886", "0x09316bC5c4Ff19728278B00ef73c906C9abb9771", "0x3f7159B2B89644BEEc4D72C99607Ed56cEEb6c89", "0x9Fc1d2fC2cAAfCeDA88FACB6318b6065973c0dbB", "0x9d90024063f4981284Cfc2121733495E7984fB82", "0xddeD5a6D0716b93041622371DB6f2262D49211Fe", "0x0916D017fcAD134135ee38f75Af887A360A386a5", "0x0D3D768DcAaD213D309D4748135e9A672bfBF551", "0xA61722Fe3236f828f83a2aA71619313B5aBA7e4B", "0x0Ad113F15eC46FAb1a154E0E499772Eb2f80DC70", "0x0c873Abf780139C2dC4A35537011b315aE99a9d2", "0x0289cAB06a7219bF9310f22c040017556710371F", "0xa1114819d580A776fAd572634b71886D307a18B7", "0xcd8724A5c0F3DEa679AB62BFBF92b3d6BE1Ca93f", "0x72E312cc49188EB529EfF9ba69a2873a795E0975", "0x067B884818A6E5606d26a1089Fb30B1dFD906681", "0x3E4eA9034B84161f4A9c8ec1f18f1F18a6c11A7c", "0x04d79e46Cdce94ae2b73cb7b536BaE5589dd1751", "0x0b36275Aa92c9e1C2f44E1287229146Ad84E84fe", "0x634e5126144471FB7AF94998C2cc78DE0Fd72049", "0x672Af29F748efaE679427496d758335B4C9D62Be", "0xF6B1109FcC75602e16F3bC9baf779Bd885E2af40", "0xF8Be878c02411E689e1FCF11F1ece3e44Df3625E", "0x7a187ec05B7d92b92201dbdB6b152Bef76467D90", "0x0e160efBEb177DFBC5407ed4AFc59D7D7404270a", "0x885f0996f83AFF1094439Ed595dC1014882ebF24", "0x952A0235ae30ac390ec7f70E04aDDDBeB2317B8d", "0x0211f8Fc9DB7F834D6372d7a76513f06EB727ca3", "0x45B5dE7809A9289A8E11228a4fF303Cd0D518119", "0x2c7b6C5Ab824da1808d309e2ba956d799D8eF43a", "0x6db0C26e5F0a0d34097B33858f885B92d1ac00E8", "0x8F303080ffd7B35fAb58856a63f99147717673DD", "0x1f005D865050c4abe97B5fa0C88867Dd7E981dE7", "0x0ad7BacF5bff13BBD2b22DC49387a15A8EACE1ed", "0x9d01791d844bf123C062cC3675268Fd40B7961D9", "0xFDeef5A8B01FD098884693471a87C95608a57849", "0x07e403C868703b02534D6875AC55b0FDF7B4DC49", "0x4eeFBe1069F921ED5837Cc79B02b863E37d908C1", "0x0D1cb76B818bCA220A2f21C63BdF5542535Cdc33", "0x0B7d5F49D83fee574b17c6Df9df9Ea74eAe5084f", "0x411E9fe94012b830FCAf9199686A9772Eee124E0", "0xD1eDFC56125a33eCd48Fd1877972Fe8945B7F1B6", "0x0E07108d2A0098077337eD99E5f9210F4892FD2F", "0x05770136Cb47693E25790252cCa39F7C4E22575b", "0x0d9F4836b9076eBbCbeE36024ABBB3C07a1753d4", "0xe15620203AaA43F4A994FF1D219bC714eB8ce612", "0x4E566615E8d8260d911350FC35CAb812F31C74De", "0x70E442dA331177EDE0Cb48648967c43fa1702d51", "0x0159316Fca08F021E2A008D09A3857CdA1Ae2c1F", "0xe472f1087F33723fd91B43d6866A21472FdD9E91", "0x7773B2CB00165dD354705e8eB2F9E6619cFBbb7d", "0x3f3179aFB2aE32B514FA61324644326Bc05f4e99", "0x24EFe5b182180B1805daa0B0b13e048ab500f07F", "0x08DB8c6d927d53eaB84Eccf57E2C6F63491bf60f", "0x04140Ab80Dc535e840D9846d062c5f6b500eaf7e", "0x88814D9BBad9F6e298F8116dFC0E62A0e68bE2D8", "0xB462E3E99165ecA7630d99D8f91297715DdfE2b4", "0x0ea2fAdfa61538408e9A2823A0a7596f08B9917A", "0x8eb234b2960C6bD426E94182d91107f6c3ccB4CB", "0x0655cBD538CDd5C537D9157A52e058d396837E3A", "0x5Acd7f9486a55b3Df901c27c810513928c816079", "0x0eAdD9388FE2e1B62545633E02684a461Db97A49", "0x08380fC6BcBCBE46Ee1e4b8007139e41F5D8947e", "0x622c32eD5c9Ef865A4c5bB9b468da4B4F411F228", "0xe56f2F8337EEAEd5D70af90cd228C642086A6dCa", "0x044779D2201d3A148CB615c774bfA05CE65dc09B", "0x2dd9667B4f9C25927010C704cc9608e6eEd9b5bF", "0xe634C64C882164Daac72631c2a0f4Da45FcB0Ec8", "0x79314Ba2805424a89fDa71DbB025dF7e5eaAA8E0", "0x03f46aa1374C4ed595cef27C0EfDBf1238f48550", "0x5F913927B5467D89B45F6d1C083b9AC9aCA560E5", "0x0B4AFD055aC8F138786e74624175cb475FFcD821", "0x2F9FB88C42D9B1Ac27cF519014eC3e23a3189466", "0x43AB4D446a207eDA0eA390ef532c4935055B334E", "0x0983100928c3e6Aee592541De83e8244D020ca28", "0x0999b59415BdC5e9f1044EA895033b71fe7Ee776", "0x2E8666b8877f38AC90930Bd0d6A3c900Dd989856", "0xc38785d2b7b8491c3086fB7A0baE7D98795Be719", "0x6A5A23C6aaD4e51e6Bc8AD925d6E67F634C755f0", "0x9211503026a11558592e05A3dfD54aAC15c4a682", "0xAd3fBa008E3cac1952B12e1BfDE8fCB504D2C5B7", "0x38DCF5707d86334Ba741e9955B055f6a39301DeA", "0x06952b6b94f357c3F416C46d39F08ebb3e3D14D4", "0x76218CaDb716B0d92047867c8044a74FF64eD55d", "0x08fe39ee285f607Ebce99c9aeF7eB3A9ddE38DBF", "0xb029b7C086de211f8F43777C7EE3A7422CA6752C", "0x90fb021d72313F9054D8e7D5e3358D4Ca0efbEb6", "0xC221E9605ed4CF3d984C8A5f080907AF1794EDfd", "0xafC19f513a7e2492959120C580d9AbfA93cB6fE2", "0x44e3ad15301F3810A39503BE869d931d06c38614", "0x058714327ae00ae57F27763F304B9B8895F7C633", "0x1168f1FCB8aA6Da6F87b2FeA1736a3E837977d85", "0xA3160B71d065bb72cbCA602aEc77186802Fa5541", "0x4f16638e721C18B9CAd3e8aa91CFDd6583B4eA46", "0x2e6fa4994D63E8A56e8128ba075f20404d534B64", "0xea0Cc0bDFF9bdfeC6953678D486af58f9308d320", "0xdf6B18194b3a960138259Ef41945012544944795", "0x0765785A94DE21dcf5d74ab8f58ba6E1F832015D", "0x0A931E255b3F40eDe15351614981b38b4d168311", "0xF5D5380F945f2c688A72DdC00BdD9241F4aF2074", "0x82DeFcA823961e6CAb2A4620e58772653f76Ab12", "0xEF3362B0e60bABF7D53381D268917802ed23Ea48", "0xDe5e1a51117194e1098478e1E842eF5a797c719c", "0x381872832467758338f8cfB52356f85e2FFF64a5", "0xEaF17616f104818efa5064B71Db9Eb5a9190b30e", "0x04Dc3F94327669bb37a9e110a4Fd0b42D9f389A6", "0x02Ff05b5E2D2EbC08Ab4eE1457557d9AedA3FB5F", "0x5c881B552c41F450DcAd8d9F9ba56A82628F9f34", "0x67fd07943841Ee604e95Ae41fcc36267Bcd106A2", "0xC96422C3ea021291Dd89b14F239976EFe78B9f69", "0x0Bf34187494a780abfD5C171277746142C3D07d6", "0x0e026a7f7E0D3Eba26AA1ac41f23324f7148046E", "0xddc6683dFe12161ceb224e8B7933Bd3078138123", "0x9C2B4D8497094c619c7A872621A8CA3eaC201C62", "0x8Cf98655f5674965ee7Aa146D21188C837218902", "0x3A33d1e8f61cb32F723C80C4FceA560426f2a7CE", "0x8e238acf4aE28d4329480E0a24be1354f002b345", "0xc79aE9067c199B13055DAa29edE409a39038Ae49", "0x0503e6aa3c1078fAEC10E24fe67f66AD4D790611", "0x002b188a7429bfF44bC90AeAd7cB9dEEAa03A215", "0xE94f219Bf30aFdD2197F851F4A2f8D5302b92748", "0x5A39113f11daad87809C950aa524b838c3bCc178", "0x057e51c4203658Fa5073105721d07927CFDD3971", "0x44dA780f6c082D465abb5D7b27D122A292d88cD7", "0x079592AAD1616E3d734581eB5e21E149b70f7Cd8", "0xFa7D8089A49A98194157a87F797c74436924A3B9", "0x31cB34EaB6027834bee25a3dE8cf88C60Fea7aD5", "0x0649aFe71AeA46f478ADa385648c5A328329D9A8", "0x1A3549131ec22312F1639BbFC742DA11e385fF71", "0xa79fA6a29499232c06DA27D82CC4a06B8E04023D", "0xa4e40589E21724219e6e0236460eDACa395aa531", "0x73B643ca95bDF7eB76F4381a99a59c24D75a7aC5", "0x085424C42ACD56Bc1C427EC269d53f3029CED91A", "0x085f075DEE2008Fee577cE74D0d9ADBFD6545351", "0xbB086621F307016d9d6E4001fe1247bc911D3540", "0x9A1A73c7c8570dB4139305abF5efEb52d6f09D50", "0x6885C12b11A8198092aCC6bA5f708e5e3622c782", "0x0CEDe3d8258dD551330721D9A06c5aFbc62BA8b9", "0x90F5e1907E20A78E52C63e9a701E42d3468e9039", "0x06348c509eeDE65491bd4fA6191Bc651e8CA9538", "0x09678Ba3A491cC48073fdae0a8aeF578E26E257b", "0x08c5123c5A214d48e38961585522eE7C62914599", "0x48012d79165e2A83eeb7229De03adE47B64832e2", "0x0E7393C540975861Ce054B903b2fEa1D5492Fb1A", "0xC55FC50B72D43281693AcC69eD29A588489b0A97", "0x09057c3E4b35C354351E11A29Bad52CD4cA68a3f", "0xC0DeFFa73C7fC8c5dcE8B047D90D1d636781e89F", "0xcB3D7934B4d7c3F72287c6A5De0177a54d24b4c7", "0x521EcE87D2E30A945baA2ac63A35D8bbB2a3B78c", "0x08DE11Dd9Ecc6A70D55c001d8b9f43f5012b2829", "0x08bADFFa3C1DC15fBdb302C1BFF4bbA162Ca2eDE", "0x09F1E12f8EA902BB758f44d0e92d2033d1132Fa0", "0x155486027076C1aCc7c307238b46E354e60f4530", "0x5897d57eBbd35FF255C6c5727b5C5C0f8b82C8B3", "0x74435fA5fad1eB15DF6D63777C4d2a7E5cb6d0Cb", "0x04632001ff826A334BDF1191E5Bc50775a282199", "0x0A0026eb77166Dcda1187A607041BCa70Abd8fB3", "0x04FD6587729451Dd54c2e65088c4F259307E06Fa", "0x109ad20f8DaA79B187d2E95582CA150a309EAD95", "0x3F6cE00DA1B09E2B1F1dcE6bd5CB4B195c0B8847", "0x0Da264Ef17cbd5A90260b4Ce960808CEe4BCEa6E", "0x14E961D2dC589b88b95604e5BA23A0Df54Ec954F", "0x0D6974cF28E75Db227C77f03FF1c00601440F9B7", "0x07B2f97e316c37D08Ee9E9c2B57e15e910fA0182", "0x0bd3c384135E444AcCBb0A443F598c729eEc46bD", "0xb00c198bE7f305B6e83B1CCfc2F8C3f8f2a67e53", "0x00eCf1e7E4D43b5fA150A06DdE9CCdEbD4913117", "0x68F90cC5b8aE92D0C7023dBC88292AA46575B1f3", "0x9D1f0fDaB9375A7FCc8670375FB58786F872FA12", "0xd759924F01A381E0b7E2E8e684F81BB3CC9e3Fd8", "0x71c3A7Ef9eE890532270E05272F79a9dE7637f4F", "0x21637fB704A651d2aCF593A64df436e183745588", "0xD0e11264dB0dF559A85FeFD6672eA69CC3fa8397", "0xd171792a8531642966c567BE138F579B53767918", "0x6972035967b61794827DDF5364E0545dAECA614B", "0x01Bb4625BEbe9a5705021a329E12D7Ff7517Eb82", "0x8128C0248f9F7B34dB92f58A3641873B077df7c1", "0xb017b555531291356dCdE875F6F9C9E8Da928E84", "0x877cf073AFfB142dA7481Ad2d084FE3719206AF7", "0x24f1081DD9322C7Abf58C20D7803C99aFAabF3a3", "0x0a614b405929bE412Ff2377E99c63703cB746170", "0x92F78fd330C9077E5b37F25A2bbB4C645F3FAd90", "0x01B6F89dC71c2AB54455EcEb96B048576673cc7e", "0x7F1368314B7d368E007B2481a3d6d4d7d77dC37C", "0x0399b01BAEA97714362d0dD3291D0C6a42e33a30", "0xa4dD558fB5b4399c3a8Fe138d4fADBDadb843BF5", "0x02C248771dbe1479A3D1563F462e391ff2eb1a3a", "0xB52ec569758c007000Df717bA33D7e3e3784327E", "0xa12ABd09686dA5012e8BAE27C72dDfB4f284b9Ba", "0x045d12cCf7fD81993318d8D76B65C0B7F1B23bb2", "0xC0D1CBB60211Ba3b3c869349FA32C98e56cb3ab6", "0x6E7A9981c728e3B7b884cbb20e78acBdf3C60e58", "0x0D310b96048a34467b128Fe40a1dA5290ED7950c", "0x85966e12D9CbC7e813d2D00E3574A91806e4B44f", "0x0cA948D275a96F7E246fecfed49f26b9dd6842B8", "0x2ED5c648E60869E0106A9325eA0b636fbe6e6016", "0x8d12A197cB00D4747a1fe03395095ce2A5CC6819", "0x264262218723FeC514bFe3Af55c43CF48a9BCD92", "0x31400D4673f4176DF400424FEF2B37FF4D9058d0", "0xDB8172fEeAE573503f86d8F7d6644b6F356afd9F", "0xfe5F4ab32afcBa717b7AA47878C64bc1f76e38c1", "0x32c222935f9cF057A2Bf7dfF3ce6A91937A9B95A", "0x3261752E646b58e5A14A785790E16b6C8cC7C46D"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "allowed", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_spender", type: "address"}, {indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "TransferFrom", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Transfer(address,address,uint256)", "TransferFrom(address,address,address,uint256)", "Approval(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x5f7542858008eeb041631f30e6109ae94b83a58e9a58261dd2c42c508850f939", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4584529 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4599648 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "B2X", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowed", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowed(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "B2X", function( accounts ) {

	it( "TEST: B2X(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4584529", blockHash: "0x895c178c3b15d51e9f11890c99fc6f1cd33abd939595a1f0fcf28b9d12e2cd6d", timeStamp: "1511128373", hash: "0x3e76cf2f34d14c87a1d3d3b72e366816cc02b9935c51456f5bf28f6f335dd91d", nonce: "192", transactionIndex: "90", from: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699", to: 0, value: "0", gas: "1171279", gasPrice: "1000000000", input: "0xc5cebffc", contractAddress: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", cumulativeGasUsed: "4995303", txreceipt_status: "1", gasUsed: "1171279", confirmations: "3159095", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "B2X", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = B2X.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1511128373 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = B2X.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: multiPartyTransfer( [addressList[4],addressList[5]], \"10000... )", async function( ) {
		const txOriginal = {blockNumber: "4584542", blockHash: "0x89f17867402045a32eb8830473bf05bdf6f5d6d9d769b51aeead3b9fd2f8d5b7", timeStamp: "1511128662", hash: "0xf440bae7bed34a6ec98822b3bf6f4921401efb083517646d00f89e346080cee1", nonce: "193", transactionIndex: "83", from: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "124603", gasPrice: "1000000000", input: "0x9ae7a9090000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000003b9aca00000000000000000000000000000000000000000000000000000000000000000200000000000000000000000003783aed140aaa1735c7385987fb1c497d1360ea00000000000000000000000074360d87e08e51308eb58cf638f1648929a19405", contractAddress: "", cumulativeGasUsed: "2025776", txreceipt_status: "1", gasUsed: "83069", confirmations: "3159082", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_toAddresses", value: [addressList[4],addressList[5]]}, {type: "uint256", name: "_amounts", value: "1000000000"}], name: "multiPartyTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multiPartyTransfer(address[],uint256)" ]( [addressList[4],addressList[5]], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1511128662 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x03783aed140aaa1735c7385987fb1c497d1360ea"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x74360d87e08e51308eb58cf638f1648929a19405"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: multiPartyTransfer( [addressList[6],addressList[7],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4595363", blockHash: "0x755899f21685c574f9a7f30c34111b54df3403adff33ee41fd83adcfff4b6a91", timeStamp: "1511279320", hash: "0x9bdfe21b0f8476afc469bbcc9c2f80874dd1062ecdee257e6bf1bf12ae2f2b43", nonce: "197", transactionIndex: "12", from: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "4568565", gasPrice: "1000000000", input: "0x9ae7a9090000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000003b9aca000000000000000000000000000000000000000000000000000000000000000064000000000000000000000000b9b23e43a13e9d14893817009d333a9bb1332bd100000000000000000000000001e48ba2192a1985629fb84d6b5e4cc010a6b5800000000000000000000000000d2857da4bbca20170a5ca386f0f6b6e55124b03000000000000000000000000fa9d7b38a3ed1236a13b43208c89e259dbb0f322000000000000000000000000de8904a8156999efb4cab571bd995321f0099bb90000000000000000000000007fad87286b630708603103366f341c68f245af050000000000000000000000002daab98856f45084a1285bcc84b42ec5d75b35ef00000000000000000000000000e8697e899125607cd92b0d5ddeceec1de57fd1000000000000000000000000925d5cfe689b63f6767f30e40c16354a6e49f5ad00000000000000000000000091175e751aca4b73387cdf7ed11388e250df98fe000000000000000000000000061a9e47e89219a6035a0f84c7f332bcf37fe05a00000000000000000000000001712100a965e20be132a217114b474cd3ea1e8a0000000000000000000000000406e788380e5abbf91ce4157efd3f827d2c688600000000000000000000000009316bc5c4ff19728278b00ef73c906c9abb97710000000000000000000000003f7159b2b89644beec4d72c99607ed56ceeb6c890000000000000000000000009fc1d2fc2caafceda88facb6318b6065973c0dbb0000000000000000000000009d90024063f4981284cfc2121733495e7984fb82000000000000000000000000dded5a6d0716b93041622371db6f2262d49211fe0000000000000000000000000916d017fcad134135ee38f75af887a360a386a50000000000000000000000000d3d768dcaad213d309d4748135e9a672bfbf551000000000000000000000000a61722fe3236f828f83a2aa71619313b5aba7e4b0000000000000000000000000ad113f15ec46fab1a154e0e499772eb2f80dc700000000000000000000000000c873abf780139c2dc4a35537011b315ae99a9d20000000000000000000000000289cab06a7219bf9310f22c040017556710371f000000000000000000000000a1114819d580a776fad572634b71886d307a18b7000000000000000000000000cd8724a5c0f3dea679ab62bfbf92b3d6be1ca93f00000000000000000000000072e312cc49188eb529eff9ba69a2873a795e0975000000000000000000000000067b884818a6e5606d26a1089fb30b1dfd9066810000000000000000000000003e4ea9034b84161f4a9c8ec1f18f1f18a6c11a7c00000000000000000000000004d79e46cdce94ae2b73cb7b536bae5589dd17510000000000000000000000000b36275aa92c9e1c2f44e1287229146ad84e84fe000000000000000000000000634e5126144471fb7af94998c2cc78de0fd72049000000000000000000000000672af29f748efae679427496d758335b4c9d62be000000000000000000000000f6b1109fcc75602e16f3bc9baf779bd885e2af40000000000000000000000000f8be878c02411e689e1fcf11f1ece3e44df3625e0000000000000000000000007a187ec05b7d92b92201dbdb6b152bef76467d900000000000000000000000000e160efbeb177dfbc5407ed4afc59d7d7404270a000000000000000000000000885f0996f83aff1094439ed595dc1014882ebf24000000000000000000000000952a0235ae30ac390ec7f70e04adddbeb2317b8d0000000000000000000000000211f8fc9db7f834d6372d7a76513f06eb727ca300000000000000000000000045b5de7809a9289a8e11228a4ff303cd0d5181190000000000000000000000002c7b6c5ab824da1808d309e2ba956d799d8ef43a0000000000000000000000006db0c26e5f0a0d34097b33858f885b92d1ac00e80000000000000000000000008f303080ffd7b35fab58856a63f99147717673dd0000000000000000000000001f005d865050c4abe97b5fa0c88867dd7e981de70000000000000000000000000ad7bacf5bff13bbd2b22dc49387a15a8eace1ed0000000000000000000000009d01791d844bf123c062cc3675268fd40b7961d9000000000000000000000000fdeef5a8b01fd098884693471a87c95608a5784900000000000000000000000007e403c868703b02534d6875ac55b0fdf7b4dc490000000000000000000000004eefbe1069f921ed5837cc79b02b863e37d908c10000000000000000000000000d1cb76b818bca220a2f21c63bdf5542535cdc330000000000000000000000000b7d5f49d83fee574b17c6df9df9ea74eae5084f000000000000000000000000411e9fe94012b830fcaf9199686a9772eee124e0000000000000000000000000d1edfc56125a33ecd48fd1877972fe8945b7f1b60000000000000000000000000e07108d2a0098077337ed99e5f9210f4892fd2f00000000000000000000000005770136cb47693e25790252cca39f7c4e22575b0000000000000000000000000d9f4836b9076ebbcbee36024abbb3c07a1753d4000000000000000000000000e15620203aaa43f4a994ff1d219bc714eb8ce6120000000000000000000000004e566615e8d8260d911350fc35cab812f31c74de00000000000000000000000070e442da331177ede0cb48648967c43fa1702d510000000000000000000000000159316fca08f021e2a008d09a3857cda1ae2c1f000000000000000000000000e472f1087f33723fd91b43d6866a21472fdd9e910000000000000000000000007773b2cb00165dd354705e8eb2f9e6619cfbbb7d0000000000000000000000003f3179afb2ae32b514fa61324644326bc05f4e9900000000000000000000000024efe5b182180b1805daa0b0b13e048ab500f07f00000000000000000000000008db8c6d927d53eab84eccf57e2c6f63491bf60f00000000000000000000000004140ab80dc535e840d9846d062c5f6b500eaf7e00000000000000000000000088814d9bbad9f6e298f8116dfc0e62a0e68be2d8000000000000000000000000b462e3e99165eca7630d99d8f91297715ddfe2b40000000000000000000000000ea2fadfa61538408e9a2823a0a7596f08b9917a0000000000000000000000008eb234b2960c6bd426e94182d91107f6c3ccb4cb0000000000000000000000000655cbd538cdd5c537d9157a52e058d396837e3a0000000000000000000000005acd7f9486a55b3df901c27c810513928c8160790000000000000000000000000eadd9388fe2e1b62545633e02684a461db97a4900000000000000000000000008380fc6bcbcbe46ee1e4b8007139e41f5d8947e000000000000000000000000622c32ed5c9ef865a4c5bb9b468da4b4f411f228000000000000000000000000e56f2f8337eeaed5d70af90cd228c642086a6dca000000000000000000000000044779d2201d3a148cb615c774bfa05ce65dc09b0000000000000000000000002dd9667b4f9c25927010c704cc9608e6eed9b5bf000000000000000000000000e634c64c882164daac72631c2a0f4da45fcb0ec800000000000000000000000079314ba2805424a89fda71dbb025df7e5eaaa8e000000000000000000000000003f46aa1374c4ed595cef27c0efdbf1238f485500000000000000000000000005f913927b5467d89b45f6d1c083b9ac9aca560e50000000000000000000000000b4afd055ac8f138786e74624175cb475ffcd8210000000000000000000000002f9fb88c42d9b1ac27cf519014ec3e23a318946600000000000000000000000043ab4d446a207eda0ea390ef532c4935055b334e0000000000000000000000000983100928c3e6aee592541de83e8244d020ca280000000000000000000000000999b59415bdc5e9f1044ea895033b71fe7ee7760000000000000000000000002e8666b8877f38ac90930bd0d6a3c900dd989856000000000000000000000000c38785d2b7b8491c3086fb7a0bae7d98795be7190000000000000000000000006a5a23c6aad4e51e6bc8ad925d6e67f634c755f00000000000000000000000009211503026a11558592e05a3dfd54aac15c4a682000000000000000000000000ad3fba008e3cac1952b12e1bfde8fcb504d2c5b700000000000000000000000038dcf5707d86334ba741e9955b055f6a39301dea00000000000000000000000006952b6b94f357c3f416c46d39f08ebb3e3d14d400000000000000000000000076218cadb716b0d92047867c8044a74ff64ed55d00000000000000000000000008fe39ee285f607ebce99c9aef7eb3a9dde38dbf000000000000000000000000b029b7c086de211f8f43777c7ee3a7422ca6752c00000000000000000000000090fb021d72313f9054d8e7d5e3358d4ca0efbeb6000000000000000000000000c221e9605ed4cf3d984c8a5f080907af1794edfd", contractAddress: "", cumulativeGasUsed: "3561346", txreceipt_status: "1", gasUsed: "3045710", confirmations: "3148261", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_toAddresses", value: [addressList[6],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105]]}, {type: "uint256", name: "_amounts", value: "1000000000"}], name: "multiPartyTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multiPartyTransfer(address[],uint256)" ]( [addressList[6],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34],addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43],addressList[44],addressList[45],addressList[46],addressList[47],addressList[48],addressList[49],addressList[50],addressList[51],addressList[52],addressList[53],addressList[54],addressList[55],addressList[56],addressList[57],addressList[58],addressList[59],addressList[60],addressList[61],addressList[62],addressList[63],addressList[64],addressList[65],addressList[66],addressList[67],addressList[68],addressList[69],addressList[70],addressList[71],addressList[72],addressList[73],addressList[74],addressList[75],addressList[76],addressList[77],addressList[78],addressList[79],addressList[80],addressList[81],addressList[82],addressList[83],addressList[84],addressList[85],addressList[86],addressList[87],addressList[88],addressList[89],addressList[90],addressList[91],addressList[92],addressList[93],addressList[94],addressList[95],addressList[96],addressList[97],addressList[98],addressList[99],addressList[100],addressList[101],addressList[102],addressList[103],addressList[104],addressList[105]], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1511279320 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xb9b23e43a13e9d14893817009d333a9bb1332bd1"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x01e48ba2192a1985629fb84d6b5e4cc010a6b580"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0d2857da4bbca20170a5ca386f0f6b6e55124b03"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xfa9d7b38a3ed1236a13b43208c89e259dbb0f322"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xde8904a8156999efb4cab571bd995321f0099bb9"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x7fad87286b630708603103366f341c68f245af05"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x2daab98856f45084a1285bcc84b42ec5d75b35ef"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x00e8697e899125607cd92b0d5ddeceec1de57fd1"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x925d5cfe689b63f6767f30e40c16354a6e49f5ad"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x91175e751aca4b73387cdf7ed11388e250df98fe"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x061a9e47e89219a6035a0f84c7f332bcf37fe05a"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x01712100a965e20be132a217114b474cd3ea1e8a"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0406e788380e5abbf91ce4157efd3f827d2c6886"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x09316bc5c4ff19728278b00ef73c906c9abb9771"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x3f7159b2b89644beec4d72c99607ed56ceeb6c89"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x9fc1d2fc2caafceda88facb6318b6065973c0dbb"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x9d90024063f4981284cfc2121733495e7984fb82"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xdded5a6d0716b93041622371db6f2262d49211fe"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0916d017fcad134135ee38f75af887a360a386a5"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0d3d768dcaad213d309d4748135e9a672bfbf551"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xa61722fe3236f828f83a2aa71619313b5aba7e4b"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0ad113f15ec46fab1a154e0e499772eb2f80dc70"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0c873abf780139c2dc4a35537011b315ae99a9d2"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0289cab06a7219bf9310f22c040017556710371f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xa1114819d580a776fad572634b71886d307a18b7"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xcd8724a5c0f3dea679ab62bfbf92b3d6be1ca93f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x72e312cc49188eb529eff9ba69a2873a795e0975"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x067b884818a6e5606d26a1089fb30b1dfd906681"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x3e4ea9034b84161f4a9c8ec1f18f1f18a6c11a7c"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x04d79e46cdce94ae2b73cb7b536bae5589dd1751"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0b36275aa92c9e1c2f44e1287229146ad84e84fe"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x634e5126144471fb7af94998c2cc78de0fd72049"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x672af29f748efae679427496d758335b4c9d62be"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xf6b1109fcc75602e16f3bc9baf779bd885e2af40"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xf8be878c02411e689e1fcf11f1ece3e44df3625e"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x7a187ec05b7d92b92201dbdb6b152bef76467d90"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0e160efbeb177dfbc5407ed4afc59d7d7404270a"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x885f0996f83aff1094439ed595dc1014882ebf24"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x952a0235ae30ac390ec7f70e04adddbeb2317b8d"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0211f8fc9db7f834d6372d7a76513f06eb727ca3"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x45b5de7809a9289a8e11228a4ff303cd0d518119"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x2c7b6c5ab824da1808d309e2ba956d799d8ef43a"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x6db0c26e5f0a0d34097b33858f885b92d1ac00e8"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x8f303080ffd7b35fab58856a63f99147717673dd"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x1f005d865050c4abe97b5fa0c88867dd7e981de7"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0ad7bacf5bff13bbd2b22dc49387a15a8eace1ed"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x9d01791d844bf123c062cc3675268fd40b7961d9"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xfdeef5a8b01fd098884693471a87c95608a57849"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x07e403c868703b02534d6875ac55b0fdf7b4dc49"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x4eefbe1069f921ed5837cc79b02b863e37d908c1"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0d1cb76b818bca220a2f21c63bdf5542535cdc33"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0b7d5f49d83fee574b17c6df9df9ea74eae5084f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x411e9fe94012b830fcaf9199686a9772eee124e0"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xd1edfc56125a33ecd48fd1877972fe8945b7f1b6"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0e07108d2a0098077337ed99e5f9210f4892fd2f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x05770136cb47693e25790252cca39f7c4e22575b"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0d9f4836b9076ebbcbee36024abbb3c07a1753d4"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xe15620203aaa43f4a994ff1d219bc714eb8ce612"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x4e566615e8d8260d911350fc35cab812f31c74de"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x70e442da331177ede0cb48648967c43fa1702d51"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0159316fca08f021e2a008d09a3857cda1ae2c1f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xe472f1087f33723fd91b43d6866a21472fdd9e91"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x7773b2cb00165dd354705e8eb2f9e6619cfbbb7d"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x3f3179afb2ae32b514fa61324644326bc05f4e99"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x24efe5b182180b1805daa0b0b13e048ab500f07f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x08db8c6d927d53eab84eccf57e2c6f63491bf60f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x04140ab80dc535e840d9846d062c5f6b500eaf7e"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x88814d9bbad9f6e298f8116dfc0e62a0e68be2d8"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xb462e3e99165eca7630d99d8f91297715ddfe2b4"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0ea2fadfa61538408e9a2823a0a7596f08b9917a"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x8eb234b2960c6bd426e94182d91107f6c3ccb4cb"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0655cbd538cdd5c537d9157a52e058d396837e3a"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x5acd7f9486a55b3df901c27c810513928c816079"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0eadd9388fe2e1b62545633e02684a461db97a49"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x08380fc6bcbcbe46ee1e4b8007139e41f5d8947e"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x622c32ed5c9ef865a4c5bb9b468da4b4f411f228"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xe56f2f8337eeaed5d70af90cd228c642086a6dca"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x044779d2201d3a148cb615c774bfa05ce65dc09b"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x2dd9667b4f9c25927010c704cc9608e6eed9b5bf"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xe634c64c882164daac72631c2a0f4da45fcb0ec8"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x79314ba2805424a89fda71dbb025df7e5eaaa8e0"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x03f46aa1374c4ed595cef27c0efdbf1238f48550"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x5f913927b5467d89b45f6d1c083b9ac9aca560e5"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0b4afd055ac8f138786e74624175cb475ffcd821"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x2f9fb88c42d9b1ac27cf519014ec3e23a3189466"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x43ab4d446a207eda0ea390ef532c4935055b334e"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0983100928c3e6aee592541de83e8244d020ca28"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0999b59415bdc5e9f1044ea895033b71fe7ee776"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x2e8666b8877f38ac90930bd0d6a3c900dd989856"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xc38785d2b7b8491c3086fb7a0bae7d98795be719"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x6a5a23c6aad4e51e6bc8ad925d6e67f634c755f0"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x9211503026a11558592e05a3dfd54aac15c4a682"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xad3fba008e3cac1952b12e1bfde8fcb504d2c5b7"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x38dcf5707d86334ba741e9955b055f6a39301dea"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x06952b6b94f357c3f416c46d39f08ebb3e3d14d4"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x76218cadb716b0d92047867c8044a74ff64ed55d"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x08fe39ee285f607ebce99c9aef7eb3a9dde38dbf"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xb029b7c086de211f8f43777c7ee3a7422ca6752c"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x90fb021d72313f9054d8e7d5e3358d4ca0efbeb6"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xc221e9605ed4cf3d984c8a5f080907af1794edfd"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: multiPartyTransfer( [addressList[106],addressList[107],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4595408", blockHash: "0x0f284a8f0b5aba3c74177b3bd43ba7d26f4f1c28a72ffae65ea84adf74d9ee57", timeStamp: "1511279953", hash: "0x3693a22bdacbf3904cc1e890b1729af209f63f17328420b02df26a60bef46cbb", nonce: "198", transactionIndex: "31", from: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "4931713", gasPrice: "1000000000", input: "0x9ae7a9090000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000003b9aca00000000000000000000000000000000000000000000000000000000000000006c000000000000000000000000afc19f513a7e2492959120c580d9abfa93cb6fe200000000000000000000000044e3ad15301f3810a39503be869d931d06c38614000000000000000000000000058714327ae00ae57f27763f304b9b8895f7c6330000000000000000000000001168f1fcb8aa6da6f87b2fea1736a3e837977d85000000000000000000000000a3160b71d065bb72cbca602aec77186802fa55410000000000000000000000004f16638e721c18b9cad3e8aa91cfdd6583b4ea460000000000000000000000002e6fa4994d63e8a56e8128ba075f20404d534b64000000000000000000000000ea0cc0bdff9bdfec6953678d486af58f9308d320000000000000000000000000df6b18194b3a960138259ef419450125449447950000000000000000000000000765785a94de21dcf5d74ab8f58ba6e1f832015d0000000000000000000000000a931e255b3f40ede15351614981b38b4d168311000000000000000000000000f5d5380f945f2c688a72ddc00bdd9241f4af207400000000000000000000000082defca823961e6cab2a4620e58772653f76ab12000000000000000000000000ef3362b0e60babf7d53381d268917802ed23ea48000000000000000000000000de5e1a51117194e1098478e1e842ef5a797c719c000000000000000000000000381872832467758338f8cfb52356f85e2fff64a5000000000000000000000000eaf17616f104818efa5064b71db9eb5a9190b30e00000000000000000000000004dc3f94327669bb37a9e110a4fd0b42d9f389a600000000000000000000000002ff05b5e2d2ebc08ab4ee1457557d9aeda3fb5f0000000000000000000000005c881b552c41f450dcad8d9f9ba56a82628f9f3400000000000000000000000067fd07943841ee604e95ae41fcc36267bcd106a2000000000000000000000000c96422c3ea021291dd89b14f239976efe78b9f690000000000000000000000000bf34187494a780abfd5c171277746142c3d07d60000000000000000000000000e026a7f7e0d3eba26aa1ac41f23324f7148046e000000000000000000000000ddc6683dfe12161ceb224e8b7933bd30781381230000000000000000000000009c2b4d8497094c619c7a872621a8ca3eac201c620000000000000000000000008cf98655f5674965ee7aa146d21188c8372189020000000000000000000000003a33d1e8f61cb32f723c80c4fcea560426f2a7ce0000000000000000000000008e238acf4ae28d4329480e0a24be1354f002b345000000000000000000000000c79ae9067c199b13055daa29ede409a39038ae490000000000000000000000000503e6aa3c1078faec10e24fe67f66ad4d790611000000000000000000000000002b188a7429bff44bc90aead7cb9deeaa03a215000000000000000000000000e94f219bf30afdd2197f851f4a2f8d5302b927480000000000000000000000005a39113f11daad87809c950aa524b838c3bcc178000000000000000000000000057e51c4203658fa5073105721d07927cfdd397100000000000000000000000044da780f6c082d465abb5d7b27d122a292d88cd7000000000000000000000000079592aad1616e3d734581eb5e21e149b70f7cd8000000000000000000000000fa7d8089a49a98194157a87f797c74436924a3b900000000000000000000000031cb34eab6027834bee25a3de8cf88c60fea7ad50000000000000000000000000649afe71aea46f478ada385648c5a328329d9a80000000000000000000000001a3549131ec22312f1639bbfc742da11e385ff71000000000000000000000000a79fa6a29499232c06da27d82cc4a06b8e04023d000000000000000000000000a4e40589e21724219e6e0236460edaca395aa53100000000000000000000000073b643ca95bdf7eb76f4381a99a59c24d75a7ac5000000000000000000000000085424c42acd56bc1c427ec269d53f3029ced91a000000000000000000000000085f075dee2008fee577ce74d0d9adbfd6545351000000000000000000000000bb086621f307016d9d6e4001fe1247bc911d35400000000000000000000000009a1a73c7c8570db4139305abf5efeb52d6f09d500000000000000000000000006885c12b11a8198092acc6ba5f708e5e3622c7820000000000000000000000000cede3d8258dd551330721d9a06c5afbc62ba8b900000000000000000000000090f5e1907e20a78e52c63e9a701e42d3468e903900000000000000000000000006348c509eede65491bd4fa6191bc651e8ca953800000000000000000000000009678ba3a491cc48073fdae0a8aef578e26e257b00000000000000000000000008c5123c5a214d48e38961585522ee7c6291459900000000000000000000000048012d79165e2a83eeb7229de03ade47b64832e20000000000000000000000000e7393c540975861ce054b903b2fea1d5492fb1a000000000000000000000000c55fc50b72d43281693acc69ed29a588489b0a9700000000000000000000000009057c3e4b35c354351e11a29bad52cd4ca68a3f000000000000000000000000c0deffa73c7fc8c5dce8b047d90d1d636781e89f000000000000000000000000cb3d7934b4d7c3f72287c6a5de0177a54d24b4c7000000000000000000000000521ece87d2e30a945baa2ac63a35d8bbb2a3b78c00000000000000000000000008de11dd9ecc6a70d55c001d8b9f43f5012b282900000000000000000000000008badffa3c1dc15fbdb302c1bff4bba162ca2ede00000000000000000000000009f1e12f8ea902bb758f44d0e92d2033d1132fa0000000000000000000000000155486027076c1acc7c307238b46e354e60f45300000000000000000000000005897d57ebbd35ff255c6c5727b5c5c0f8b82c8b300000000000000000000000074435fa5fad1eb15df6d63777c4d2a7e5cb6d0cb00000000000000000000000004632001ff826a334bdf1191e5bc50775a2821990000000000000000000000000a0026eb77166dcda1187a607041bca70abd8fb300000000000000000000000004fd6587729451dd54c2e65088c4f259307e06fa000000000000000000000000109ad20f8daa79b187d2e95582ca150a309ead950000000000000000000000003f6ce00da1b09e2b1f1dce6bd5cb4b195c0b88470000000000000000000000000da264ef17cbd5a90260b4ce960808cee4bcea6e00000000000000000000000014e961d2dc589b88b95604e5ba23a0df54ec954f0000000000000000000000000d6974cf28e75db227c77f03ff1c00601440f9b700000000000000000000000007b2f97e316c37d08ee9e9c2b57e15e910fa01820000000000000000000000000bd3c384135e444accbb0a443f598c729eec46bd000000000000000000000000b00c198be7f305b6e83b1ccfc2f8c3f8f2a67e5300000000000000000000000000ecf1e7e4d43b5fa150a06dde9ccdebd491311700000000000000000000000068f90cc5b8ae92d0c7023dbc88292aa46575b1f30000000000000000000000009d1f0fdab9375a7fcc8670375fb58786f872fa12000000000000000000000000d759924f01a381e0b7e2e8e684f81bb3cc9e3fd800000000000000000000000071c3a7ef9ee890532270e05272f79a9de7637f4f00000000000000000000000021637fb704a651d2acf593a64df436e183745588000000000000000000000000d0e11264db0df559a85fefd6672ea69cc3fa8397000000000000000000000000d171792a8531642966c567be138f579b537679180000000000000000000000006972035967b61794827ddf5364e0545daeca614b00000000000000000000000001bb4625bebe9a5705021a329e12d7ff7517eb820000000000000000000000008128c0248f9f7b34db92f58a3641873b077df7c1000000000000000000000000b017b555531291356dcde875f6f9c9e8da928e84000000000000000000000000877cf073affb142da7481ad2d084fe3719206af700000000000000000000000024f1081dd9322c7abf58c20d7803c99afaabf3a30000000000000000000000000a614b405929be412ff2377e99c63703cb74617000000000000000000000000092f78fd330c9077e5b37f25a2bbb4c645f3fad9000000000000000000000000001b6f89dc71c2ab54455eceb96b048576673cc7e0000000000000000000000007f1368314b7d368e007b2481a3d6d4d7d77dc37c0000000000000000000000000399b01baea97714362d0dd3291d0c6a42e33a30000000000000000000000000a4dd558fb5b4399c3a8fe138d4fadbdadb843bf500000000000000000000000002c248771dbe1479a3d1563f462e391ff2eb1a3a000000000000000000000000b52ec569758c007000df717ba33d7e3e3784327e000000000000000000000000a12abd09686da5012e8bae27c72ddfb4f284b9ba000000000000000000000000045d12ccf7fd81993318d8d76b65c0b7f1b23bb2000000000000000000000000c0d1cbb60211ba3b3c869349fa32c98e56cb3ab60000000000000000000000006e7a9981c728e3b7b884cbb20e78acbdf3c60e580000000000000000000000000d310b96048a34467b128fe40a1da5290ed7950c00000000000000000000000085966e12d9cbc7e813d2d00e3574a91806e4b44f0000000000000000000000000ca948d275a96f7e246fecfed49f26b9dd6842b80000000000000000000000002ed5c648e60869e0106a9325ea0b636fbe6e6016", contractAddress: "", cumulativeGasUsed: "4298363", txreceipt_status: "1", gasUsed: "3287809", confirmations: "3148216", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_toAddresses", value: [addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213]]}, {type: "uint256", name: "_amounts", value: "1000000000"}], name: "multiPartyTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "multiPartyTransfer(address[],uint256)" ]( [addressList[106],addressList[107],addressList[108],addressList[109],addressList[110],addressList[111],addressList[112],addressList[113],addressList[114],addressList[115],addressList[116],addressList[117],addressList[118],addressList[119],addressList[120],addressList[121],addressList[122],addressList[123],addressList[124],addressList[125],addressList[126],addressList[127],addressList[128],addressList[129],addressList[130],addressList[131],addressList[132],addressList[133],addressList[134],addressList[135],addressList[136],addressList[137],addressList[138],addressList[139],addressList[140],addressList[141],addressList[142],addressList[143],addressList[144],addressList[145],addressList[146],addressList[147],addressList[148],addressList[149],addressList[150],addressList[151],addressList[152],addressList[153],addressList[154],addressList[155],addressList[156],addressList[157],addressList[158],addressList[159],addressList[160],addressList[161],addressList[162],addressList[163],addressList[164],addressList[165],addressList[166],addressList[167],addressList[168],addressList[169],addressList[170],addressList[171],addressList[172],addressList[173],addressList[174],addressList[175],addressList[176],addressList[177],addressList[178],addressList[179],addressList[180],addressList[181],addressList[182],addressList[183],addressList[184],addressList[185],addressList[186],addressList[187],addressList[188],addressList[189],addressList[190],addressList[191],addressList[192],addressList[193],addressList[194],addressList[195],addressList[196],addressList[197],addressList[198],addressList[199],addressList[200],addressList[201],addressList[202],addressList[203],addressList[204],addressList[205],addressList[206],addressList[207],addressList[208],addressList[209],addressList[210],addressList[211],addressList[212],addressList[213]], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1511279953 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xafc19f513a7e2492959120c580d9abfa93cb6fe2"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x44e3ad15301f3810a39503be869d931d06c38614"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x058714327ae00ae57f27763f304b9b8895f7c633"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x1168f1fcb8aa6da6f87b2fea1736a3e837977d85"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xa3160b71d065bb72cbca602aec77186802fa5541"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x4f16638e721c18b9cad3e8aa91cfdd6583b4ea46"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x2e6fa4994d63e8a56e8128ba075f20404d534b64"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xea0cc0bdff9bdfec6953678d486af58f9308d320"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xdf6b18194b3a960138259ef41945012544944795"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0765785a94de21dcf5d74ab8f58ba6e1f832015d"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0a931e255b3f40ede15351614981b38b4d168311"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xf5d5380f945f2c688a72ddc00bdd9241f4af2074"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x82defca823961e6cab2a4620e58772653f76ab12"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xef3362b0e60babf7d53381d268917802ed23ea48"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xde5e1a51117194e1098478e1e842ef5a797c719c"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x381872832467758338f8cfb52356f85e2fff64a5"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xeaf17616f104818efa5064b71db9eb5a9190b30e"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x04dc3f94327669bb37a9e110a4fd0b42d9f389a6"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x02ff05b5e2d2ebc08ab4ee1457557d9aeda3fb5f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x5c881b552c41f450dcad8d9f9ba56a82628f9f34"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x67fd07943841ee604e95ae41fcc36267bcd106a2"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xc96422c3ea021291dd89b14f239976efe78b9f69"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0bf34187494a780abfd5c171277746142c3d07d6"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0e026a7f7e0d3eba26aa1ac41f23324f7148046e"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xddc6683dfe12161ceb224e8b7933bd3078138123"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x9c2b4d8497094c619c7a872621a8ca3eac201c62"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x8cf98655f5674965ee7aa146d21188c837218902"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x3a33d1e8f61cb32f723c80c4fcea560426f2a7ce"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x8e238acf4ae28d4329480e0a24be1354f002b345"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xc79ae9067c199b13055daa29ede409a39038ae49"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0503e6aa3c1078faec10e24fe67f66ad4d790611"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x002b188a7429bff44bc90aead7cb9deeaa03a215"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xe94f219bf30afdd2197f851f4a2f8d5302b92748"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x5a39113f11daad87809c950aa524b838c3bcc178"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x057e51c4203658fa5073105721d07927cfdd3971"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x44da780f6c082d465abb5d7b27d122a292d88cd7"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x079592aad1616e3d734581eb5e21e149b70f7cd8"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xfa7d8089a49a98194157a87f797c74436924a3b9"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x31cb34eab6027834bee25a3de8cf88c60fea7ad5"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0649afe71aea46f478ada385648c5a328329d9a8"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x1a3549131ec22312f1639bbfc742da11e385ff71"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xa79fa6a29499232c06da27d82cc4a06b8e04023d"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xa4e40589e21724219e6e0236460edaca395aa531"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x73b643ca95bdf7eb76f4381a99a59c24d75a7ac5"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x085424c42acd56bc1c427ec269d53f3029ced91a"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x085f075dee2008fee577ce74d0d9adbfd6545351"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xbb086621f307016d9d6e4001fe1247bc911d3540"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x9a1a73c7c8570db4139305abf5efeb52d6f09d50"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x6885c12b11a8198092acc6ba5f708e5e3622c782"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0cede3d8258dd551330721d9a06c5afbc62ba8b9"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x90f5e1907e20a78e52c63e9a701e42d3468e9039"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x06348c509eede65491bd4fa6191bc651e8ca9538"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x09678ba3a491cc48073fdae0a8aef578e26e257b"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x08c5123c5a214d48e38961585522ee7c62914599"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x48012d79165e2a83eeb7229de03ade47b64832e2"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0e7393c540975861ce054b903b2fea1d5492fb1a"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xc55fc50b72d43281693acc69ed29a588489b0a97"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x09057c3e4b35c354351e11a29bad52cd4ca68a3f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xc0deffa73c7fc8c5dce8b047d90d1d636781e89f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xcb3d7934b4d7c3f72287c6a5de0177a54d24b4c7"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x521ece87d2e30a945baa2ac63a35d8bbb2a3b78c"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x08de11dd9ecc6a70d55c001d8b9f43f5012b2829"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x08badffa3c1dc15fbdb302c1bff4bba162ca2ede"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x09f1e12f8ea902bb758f44d0e92d2033d1132fa0"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x155486027076c1acc7c307238b46e354e60f4530"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x5897d57ebbd35ff255c6c5727b5c5c0f8b82c8b3"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x74435fa5fad1eb15df6d63777c4d2a7e5cb6d0cb"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x04632001ff826a334bdf1191e5bc50775a282199"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0a0026eb77166dcda1187a607041bca70abd8fb3"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x04fd6587729451dd54c2e65088c4f259307e06fa"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x109ad20f8daa79b187d2e95582ca150a309ead95"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x3f6ce00da1b09e2b1f1dce6bd5cb4b195c0b8847"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0da264ef17cbd5a90260b4ce960808cee4bcea6e"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x14e961d2dc589b88b95604e5ba23a0df54ec954f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0d6974cf28e75db227c77f03ff1c00601440f9b7"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x07b2f97e316c37d08ee9e9c2b57e15e910fa0182"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0bd3c384135e444accbb0a443f598c729eec46bd"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xb00c198be7f305b6e83b1ccfc2f8c3f8f2a67e53"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x00ecf1e7e4d43b5fa150a06dde9ccdebd4913117"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x68f90cc5b8ae92d0c7023dbc88292aa46575b1f3"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x9d1f0fdab9375a7fcc8670375fb58786f872fa12"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xd759924f01a381e0b7e2e8e684f81bb3cc9e3fd8"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x71c3a7ef9ee890532270e05272f79a9de7637f4f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x21637fb704a651d2acf593a64df436e183745588"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xd0e11264db0df559a85fefd6672ea69cc3fa8397"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xd171792a8531642966c567be138f579b53767918"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x6972035967b61794827ddf5364e0545daeca614b"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x01bb4625bebe9a5705021a329e12d7ff7517eb82"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x8128c0248f9f7b34db92f58a3641873b077df7c1"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xb017b555531291356dcde875f6f9c9e8da928e84"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x877cf073affb142da7481ad2d084fe3719206af7"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x24f1081dd9322c7abf58c20d7803c99afaabf3a3"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0a614b405929be412ff2377e99c63703cb746170"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x92f78fd330c9077e5b37f25a2bbb4c645f3fad90"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x01b6f89dc71c2ab54455eceb96b048576673cc7e"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x7f1368314b7d368e007b2481a3d6d4d7d77dc37c"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0399b01baea97714362d0dd3291d0c6a42e33a30"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xa4dd558fb5b4399c3a8fe138d4fadbdadb843bf5"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x02c248771dbe1479a3d1563f462e391ff2eb1a3a"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xb52ec569758c007000df717ba33d7e3e3784327e"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xa12abd09686da5012e8bae27c72ddfb4f284b9ba"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x045d12ccf7fd81993318d8d76b65c0b7f1b23bb2"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0xc0d1cbb60211ba3b3c869349fa32c98e56cb3ab6"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x6e7a9981c728e3b7b884cbb20e78acbdf3c60e58"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0d310b96048a34467b128fe40a1da5290ed7950c"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x85966e12d9cbc7e813d2d00e3574a91806e4b44f"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x0ca948d275a96f7e246fecfed49f26b9dd6842b8"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x4d5cb4f7a8abf01feb3cf6a3dda53655d421e699"}, {name: "_to", type: "address", value: "0x2ed5c648e60869e0106a9325ea0b636fbe6e6016"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595438", blockHash: "0x15355de73c102b78f82293278cd2fd63ff02fcf1d9f7ff351e436cb96fbf8003", timeStamp: "1511280357", hash: "0xab5baf0dc41b856bb0b51fbf22e156924cbd5fbb28fb189de888f9dd1cf320c9", nonce: "12", transactionIndex: "39", from: "0x002b188a7429bff44bc90aead7cb9deeaa03a215", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1256352", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148186", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[137], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1511280357 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x002b188a7429bff44bc90aead7cb9deeaa03a215"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[137], balance: "2464230000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[137], balance: ( await web3.eth.getBalance( addressList[137], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595439", blockHash: "0xdc699d7f63222d61d773fcca86e8f6d69f238aa5c3adef7cfd32a9dd7e396e80", timeStamp: "1511280375", hash: "0x8f2a1de326ab2650e267e9e58c73bad011c3a7ef975289eba42a2fc5ed5ab509", nonce: "13", transactionIndex: "85", from: "0x00e8697e899125607cd92b0d5ddeceec1de57fd1", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "4388463", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148185", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1511280375 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x00e8697e899125607cd92b0d5ddeceec1de57fd1"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "3528999848438731" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595445", blockHash: "0x18d0884302256a50c7bccda66be1555fb55df07f4dd0375ddf3a9e5deaf82062", timeStamp: "1511280418", hash: "0xe242ad2bbb3f17ae75a3cfaf03011e1dbd2e862d77563abcea4740e867c79ecd", nonce: "21", transactionIndex: "118", from: "0x0159316fca08f021e2a008d09a3857cda1ae2c1f", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "4960669", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148179", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[66], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1511280418 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0159316fca08f021e2a008d09a3857cda1ae2c1f"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[66], balance: "2669376383278227" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[66], balance: ( await web3.eth.getBalance( addressList[66], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595453", blockHash: "0x619e7664f2eff339a78b4cee48a56c0e2ff8d5117420abadff64c2afb3ad2da6", timeStamp: "1511280538", hash: "0x1c992f6274432c76a2cc3e4e59cb44fc158eb9e4b159f661e2e2fb42fe6969fe", nonce: "4", transactionIndex: "31", from: "0x00ecf1e7e4d43b5fa150a06dde9ccdebd4913117", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1383456", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148171", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[184], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1511280538 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x00ecf1e7e4d43b5fa150a06dde9ccdebd4913117"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[184], balance: "4364667000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[184], balance: ( await web3.eth.getBalance( addressList[184], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595453", blockHash: "0x619e7664f2eff339a78b4cee48a56c0e2ff8d5117420abadff64c2afb3ad2da6", timeStamp: "1511280538", hash: "0x0b24216a8ed98844418cb316b8f61fee6f2417c56a3a23373e582a838c46ca98", nonce: "13", transactionIndex: "32", from: "0x01712100a965e20be132a217114b474cd3ea1e8a", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1428753", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148171", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1511280538 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x01712100a965e20be132a217114b474cd3ea1e8a"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "2776088304335877" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595553", blockHash: "0xc6fb571b968122d2b8ae735a4a6e2343ed507d121e1f0eadadda2c674a2a2b6c", timeStamp: "1511282147", hash: "0x2060c23142dc91b0c438e2f78b5a10b4bb5797889cda3f0ab21ccf207051c487", nonce: "4", transactionIndex: "81", from: "0x01b6f89dc71c2ab54455eceb96b048576673cc7e", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "2812983", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148071", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[200], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1511282147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x01b6f89dc71c2ab54455eceb96b048576673cc7e"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[200], balance: "2311539200000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[200], balance: ( await web3.eth.getBalance( addressList[200], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595579", blockHash: "0x8dd7a478921e4e20633aa2b728d4d5109201778d339a720d4ebbc651fdc44df9", timeStamp: "1511282510", hash: "0xc3985f18e3149eaaa3e9d1f51391f2fb31b9a3298c235f2061206edc2f2408bf", nonce: "4", transactionIndex: "77", from: "0x01bb4625bebe9a5705021a329e12d7ff7517eb82", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "3620394", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148045", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[193], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1511282510 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x01bb4625bebe9a5705021a329e12d7ff7517eb82"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[193], balance: "2015044000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[193], balance: ( await web3.eth.getBalance( addressList[193], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595611", blockHash: "0x170c2669df30e3a19f15516550a8b4ef967ba10097282293c500b03eb5c1b4ad", timeStamp: "1511282899", hash: "0xf3a75b9f5e6e64069632f4b3008bccfaa97e2e095d8b2363b363ca840eefabeb", nonce: "6", transactionIndex: "54", from: "0x01e48ba2192a1985629fb84d6b5e4cc010a6b580", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1840475", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148013", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1511282899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x01e48ba2192a1985629fb84d6b5e4cc010a6b580"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1505155000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"700000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595617", blockHash: "0x1a2fac29be631809d990a913a3419eb1d7290bb09ee2e19041479d623074cf9b", timeStamp: "1511282980", hash: "0x9899ca2ab26b3a7180e6ce61e1059cf5649c2ca53f60188732e479cda11d01f8", nonce: "106", transactionIndex: "56", from: "0x264262218723fec514bfe3af55c43cf48a9bcd92", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc68190000000000000000000000000000000000000000000000000000000029b92700", contractAddress: "", cumulativeGasUsed: "2316020", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148007", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[215], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "700000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "700000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1511282980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x264262218723fec514bfe3af55c43cf48a9bcd92"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "700000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[215], balance: "169702176517371" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[215], balance: ( await web3.eth.getBalance( addressList[215], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595617", blockHash: "0x1a2fac29be631809d990a913a3419eb1d7290bb09ee2e19041479d623074cf9b", timeStamp: "1511282980", hash: "0x157609bf06fe67ef1f9ef0c6f7f7ac31be443668bc4c4e2e786e82e05f43ed0f", nonce: "4", transactionIndex: "122", from: "0x0211f8fc9db7f834d6372d7a76513f06eb727ca3", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5511021", txreceipt_status: "1", gasUsed: "45297", confirmations: "3148007", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1511282980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0211f8fc9db7f834d6372d7a76513f06eb727ca3"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "2646751580000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595767", blockHash: "0x72d7f58dacba984ff5687dc66096f28327d2526f1a33bfc10453ea9937da8f6d", timeStamp: "1511285173", hash: "0x6f5f99d3318cf1871dd11040dfedfa86491bca32c9e8fcab52966d6683117256", nonce: "5", transactionIndex: "197", from: "0x0289cab06a7219bf9310f22c040017556710371f", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5700120", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147857", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1511285173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0289cab06a7219bf9310f22c040017556710371f"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "2949588000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595837", blockHash: "0x4c55fa511e43d13f196af449de277cf1618a2c77b3ae19501b18f8c71c6b601a", timeStamp: "1511286256", hash: "0x6a76ba4198fe8b4225607b97f3b51ef35587c9410d97362dcf78cd95dca4397c", nonce: "5", transactionIndex: "70", from: "0x02ff05b5e2d2ebc08ab4ee1457557d9aeda3fb5f", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "3537622", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147787", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[124], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1511286256 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x02ff05b5e2d2ebc08ab4ee1457557d9aeda3fb5f"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[124], balance: "2878635000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[124], balance: ( await web3.eth.getBalance( addressList[124], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4595990", blockHash: "0xf4fe965cf12e72c1e4afca2a58575932bff645c32d8cab1324cdc672decafd13", timeStamp: "1511288362", hash: "0xd2aa5cf7f08f30fb31af651c202e2ce89389b765cbd44fd428241b2519391e2e", nonce: "4", transactionIndex: "130", from: "0x03783aed140aaa1735c7385987fb1c497d1360ea", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5191846", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147634", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1511288362 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x03783aed140aaa1735c7385987fb1c497d1360ea"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "3463025258770330" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596147", blockHash: "0xdd6e5e6ecbf5c8cb8f6e9e7f3739250966cbc4852283f802c15072ddc71c4420", timeStamp: "1511290488", hash: "0x062428cbfa236d5c2e4a9c72adb5588023d2cc1ac185f553594987c149df3ac4", nonce: "5", transactionIndex: "48", from: "0x0399b01baea97714362d0dd3291d0c6a42e33a30", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "2553056", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147477", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[202], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1511290488 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0399b01baea97714362d0dd3291d0c6a42e33a30"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[202], balance: "2768603540000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[202], balance: ( await web3.eth.getBalance( addressList[202], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596236", blockHash: "0x855596687c8d77161ae22aa0887ea78d5125aa11c202a067e437ce48df207505", timeStamp: "1511291824", hash: "0x04c82be00c598b01b9f533397dc99cc8ea81b6dba99fbe8802137773e8b1efb7", nonce: "7", transactionIndex: "143", from: "0x03f46aa1374c4ed595cef27c0efdbf1238f48550", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5042055", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147388", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[87], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1511291824 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x03f46aa1374c4ed595cef27c0efdbf1238f48550"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[87], balance: "2800174226616121" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[87], balance: ( await web3.eth.getBalance( addressList[87], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596274", blockHash: "0xa5a0e5f3751b354a7e66739c2b35ba0609389d3c6407e2f3d9d92a760c9d65a8", timeStamp: "1511292210", hash: "0xa3f7c13b99daf55f7baf078f304aef9639240cc8d8bdb15a5f3a827cdf04c5f2", nonce: "5", transactionIndex: "26", from: "0x0406e788380e5abbf91ce4157efd3f827d2c6886", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1152390", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147350", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1511292210 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0406e788380e5abbf91ce4157efd3f827d2c6886"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1737416186322400" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596377", blockHash: "0x121efbab5ad64459c55d8b6721f744cc766297b5d562f84d12a02f72a7fcfe90", timeStamp: "1511293581", hash: "0x96ad567ff7601a0551b1446e7c3008c70981134a163c15187b0fa27429707ca2", nonce: "6", transactionIndex: "60", from: "0x04140ab80dc535e840d9846d062c5f6b500eaf7e", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "3693927", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147247", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[72], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1511293581 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x04140ab80dc535e840d9846d062c5f6b500eaf7e"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[72], balance: "2507739180000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[72], balance: ( await web3.eth.getBalance( addressList[72], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596457", blockHash: "0xd7d4dd9dcf9559428f11d308ec6495f82f75d1d7ab0b640598dfd76ccde620a7", timeStamp: "1511294583", hash: "0xd595724949f1eac4de7bd5da714102bbb002ad2f30a2316c6057ad229d1fa367", nonce: "7", transactionIndex: "55", from: "0x044779d2201d3a148cb615c774bfa05ce65dc09b", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "2096020", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147167", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[83], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1511294583 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x044779d2201d3a148cb615c774bfa05ce65dc09b"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[83], balance: "2067462352525801" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[83], balance: ( await web3.eth.getBalance( addressList[83], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596530", blockHash: "0x48c963dfc24af9d5513716fd6a9a31f4a5ff3131bc4862f8326dfc802d8f5ec2", timeStamp: "1511295612", hash: "0x6c42affbcffbd3ec87f1d321e9f30c61f6b6c6bfcce9f2b97ad0c57416d15506", nonce: "5", transactionIndex: "39", from: "0x045d12ccf7fd81993318d8d76b65c0b7f1b23bb2", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "4630619", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147094", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[207], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1511295612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x045d12ccf7fd81993318d8d76b65c0b7f1b23bb2"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[207], balance: "1536828186322400" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[207], balance: ( await web3.eth.getBalance( addressList[207], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"99700000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596564", blockHash: "0xe2c7afd90e7151ac755c615093ccecd66dc333746fe0cdc256683a79939b30ae", timeStamp: "1511296249", hash: "0xebd241810e1de4e24796d2dc59565c8ac7b8c1e5c6688de329edd70d8524ee01", nonce: "3", transactionIndex: "106", from: "0x31400d4673f4176df400424fef2b37ff4d9058d0", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc68190000000000000000000000000000000000000000000000000000000005f14d20", contractAddress: "", cumulativeGasUsed: "4693538", txreceipt_status: "1", gasUsed: "45361", confirmations: "3147060", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[216], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "99700000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "99700000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1511296249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x31400d4673f4176df400424fef2b37ff4d9058d0"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "99700000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[216], balance: "24605000000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[216], balance: ( await web3.eth.getBalance( addressList[216], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596615", blockHash: "0xb5d5df2d757dcf7588120c0bcee3c32f798d50367efe1d8d93b6a0477b428a36", timeStamp: "1511297118", hash: "0xb3458a28feea895a16953ded77497119d7065fa5a79fc61592d7b006b1b2e5e2", nonce: "5", transactionIndex: "150", from: "0x04632001ff826a334bdf1191e5bc50775a282199", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5827265", txreceipt_status: "1", gasUsed: "45297", confirmations: "3147009", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[173], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1511297118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x04632001ff826a334bdf1191e5bc50775a282199"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[173], balance: "1568550875186920" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[173], balance: ( await web3.eth.getBalance( addressList[173], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596669", blockHash: "0xd88a4f8e02bef9594834d3038aab56f4fcbce3d5ef63ef66db11e424483b3ff0", timeStamp: "1511297756", hash: "0x551b68c021a43c7e612b339e145e55807d00b6f946e7a4a64ef3d88e7879f0d4", nonce: "5", transactionIndex: "113", from: "0x04d79e46cdce94ae2b73cb7b536bae5589dd1751", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "4716619", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146955", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1511297756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x04d79e46cdce94ae2b73cb7b536bae5589dd1751"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "2442713000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596759", blockHash: "0x0639584a0ee6795938ae9a0ca6a81f79996d3cbd2ab2b38ccf72642129a73f58", timeStamp: "1511298874", hash: "0x202f738bc8aa5a2a5b89bbb2989bb8b635cb999d92c2de750202632810491403", nonce: "6", transactionIndex: "33", from: "0x04fd6587729451dd54c2e65088c4f259307e06fa", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1540561", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146865", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[175], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1511298874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x04fd6587729451dd54c2e65088c4f259307e06fa"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[175], balance: "2491227000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[175], balance: ( await web3.eth.getBalance( addressList[175], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"484300000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596776", blockHash: "0xdef5269c851cf914e5e516c59f9ed78e1b06343a9c356feb90d9259d65ed1de9", timeStamp: "1511299229", hash: "0x5921162b97db9151351754bdcd129800145727710e1c0531ec0088bbd3749cf6", nonce: "50", transactionIndex: "71", from: "0xdb8172feeae573503f86d8f7d6644b6f356afd9f", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "21000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000001cddd4e0", contractAddress: "", cumulativeGasUsed: "1913695", txreceipt_status: "1", gasUsed: "45361", confirmations: "3146848", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[217], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "484300000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "484300000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1511299229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0xdb8172feeae573503f86d8f7d6644b6f356afd9f"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "484300000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[217], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[217], balance: ( await web3.eth.getBalance( addressList[217], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596845", blockHash: "0x84f0af9fcf567e412dc1706526843ab535a75cc5910ae9733d18ec495160ab0f", timeStamp: "1511300223", hash: "0x2dc3447a86b573f4f55d9fcdeb163715b2142188478f892fbb512be61e4533f0", nonce: "5", transactionIndex: "44", from: "0x0503e6aa3c1078faec10e24fe67f66ad4d790611", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1648233", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146779", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[136], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1511300223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0503e6aa3c1078faec10e24fe67f66ad4d790611"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[136], balance: "2418620000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[136], balance: ( await web3.eth.getBalance( addressList[136], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4596845", blockHash: "0x84f0af9fcf567e412dc1706526843ab535a75cc5910ae9733d18ec495160ab0f", timeStamp: "1511300223", hash: "0xed0e74e5b9561ffc040e35e659d9788deecbfc0af909b87f519de39988ab5405", nonce: "5", transactionIndex: "91", from: "0x05770136cb47693e25790252cca39f7c4e22575b", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5081255", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146779", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[61], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1511300223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x05770136cb47693e25790252cca39f7c4e22575b"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[61], balance: "1742059000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[61], balance: ( await web3.eth.getBalance( addressList[61], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597154", blockHash: "0x43b00f6e7dc6b0ef71514adf140b41043d3a3c66cacb368a1f84d53ffe462d17", timeStamp: "1511304476", hash: "0x5501987f38451bd34e4586b2a0e101b115116b730bbecb280191c8beb911d3b3", nonce: "5", transactionIndex: "144", from: "0x057e51c4203658fa5073105721d07927cfdd3971", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5942003", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146470", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[140], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1511304476 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x057e51c4203658fa5073105721d07927cfdd3971"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[140], balance: "1742571000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[140], balance: ( await web3.eth.getBalance( addressList[140], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597161", blockHash: "0x5045612064b85a7d86e23725cb4d9012d7211571191bcf43aee6a01bde34010e", timeStamp: "1511304577", hash: "0x59dcbb5aeb15f3677432e88f3621f37ac01126747d3fc53995b76596ce50857c", nonce: "5", transactionIndex: "14", from: "0x058714327ae00ae57f27763f304b9b8895f7c633", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1045000", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146463", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[108], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1511304577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x058714327ae00ae57f27763f304b9b8895f7c633"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[108], balance: "2742571000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[108], balance: ( await web3.eth.getBalance( addressList[108], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597183", blockHash: "0xab84e54dbfe52dc99e1cfe47b55b9980c4ef9b5d21fbdc63c8683da54c5e15a1", timeStamp: "1511304880", hash: "0x24cc17d5ef57cce17e4ff23cb1d3f92dc24c0ed7251b237ea7f00ddad54ba330", nonce: "5", transactionIndex: "78", from: "0x061a9e47e89219a6035a0f84c7f332bcf37fe05a", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "4418335", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146441", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1511304880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x061a9e47e89219a6035a0f84c7f332bcf37fe05a"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "1747867000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597250", blockHash: "0x2643dc6eb02f12145aeb603f5267d08771356582ad7cd1eeed3a0b3fff002faa", timeStamp: "1511305863", hash: "0xbd791fb7cdd6dc6491a903fd1ca9109864882a2c7ca40efc34e34e526bc873e1", nonce: "5", transactionIndex: "87", from: "0x06348c509eede65491bd4fa6191bc651e8ca9538", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "4589237", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146374", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[157], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1511305863 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x06348c509eede65491bd4fa6191bc651e8ca9538"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[157], balance: "2698626560000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[157], balance: ( await web3.eth.getBalance( addressList[157], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597255", blockHash: "0x6ff65f6284096b295505c6f6d51e6a98a6b6c463e27635d19aa4b5c46223665d", timeStamp: "1511305985", hash: "0x421ecca332cd29efd1aa965e650d81d3add22e3bf36beb22609c2d76003d6b03", nonce: "4", transactionIndex: "111", from: "0x0649afe71aea46f478ada385648c5a328329d9a8", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5377325", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146369", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[145], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1511305985 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0649afe71aea46f478ada385648c5a328329d9a8"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[145], balance: "3879171000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[145], balance: ( await web3.eth.getBalance( addressList[145], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597255", blockHash: "0x6ff65f6284096b295505c6f6d51e6a98a6b6c463e27635d19aa4b5c46223665d", timeStamp: "1511305985", hash: "0x2494df5951a493e78d17f19fcc200a05bc83131c935ea87fbc4244b06400e43f", nonce: "4", transactionIndex: "113", from: "0x0655cbd538cdd5c537d9157a52e058d396837e3a", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5500864", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146369", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[77], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1511305985 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0655cbd538cdd5c537d9157a52e058d396837e3a"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[77], balance: "2703927000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[77], balance: ( await web3.eth.getBalance( addressList[77], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597278", blockHash: "0x3aa5674a14ec498685587a8f4087ef00ea1af05761efae72e8c64f9e8ee7ba13", timeStamp: "1511306338", hash: "0xc198005da61df0575eb0acfe0b3b89fad3444763eaa56cba60bd189aae0451a7", nonce: "4", transactionIndex: "65", from: "0x067b884818a6e5606d26a1089fb30b1dfd906681", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "5198756", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146346", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1511306338 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x067b884818a6e5606d26a1089fb30b1dfd906681"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "2478577000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597381", blockHash: "0xa3639e3bcbf028ba9cf1ba7b7c5b6ac7c1c67c699501c82242bba960f37244e1", timeStamp: "1511307749", hash: "0x99e4bd9eda5e972b2a2dfc0a3f3c65ba577500ed65b4ed9f38aa38243053db21", nonce: "4", transactionIndex: "128", from: "0x06952b6b94f357c3f416c46d39f08ebb3e3d14d4", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "1000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "6460754", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146243", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[100], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1511307749 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x06952b6b94f357c3f416c46d39f08ebb3e3d14d4"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[100], balance: "1333259899991500" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[100], balance: ( await web3.eth.getBalance( addressList[100], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597558", blockHash: "0x14d0cc2f15722488849cce91e55efc35fe72e78d8d856f5d95630d57923b6acf", timeStamp: "1511310309", hash: "0x9c5984549607f5d337a87ff98f9903cb1102e95a4b709be995119b788fb8d5cf", nonce: "4", transactionIndex: "23", from: "0x0765785a94de21dcf5d74ab8f58ba6e1f832015d", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "855240", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146066", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[115], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1511310309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0765785a94de21dcf5d74ab8f58ba6e1f832015d"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[115], balance: "3035016000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[115], balance: ( await web3.eth.getBalance( addressList[115], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597584", blockHash: "0x575c40ad3cb331b8edf6db4afc709730fb2a4cded840f2a8fe9375e518df6310", timeStamp: "1511310704", hash: "0xd3f0e56647a720159e3b516bec4e79fdca6b293b196d99e5af42f705ba2e6313", nonce: "4", transactionIndex: "78", from: "0x079592aad1616e3d734581eb5e21e149b70f7cd8", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "2676108", txreceipt_status: "1", gasUsed: "45297", confirmations: "3146040", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[142], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511310704 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x079592aad1616e3d734581eb5e21e149b70f7cd8"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[142], balance: "2555924000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[142], balance: ( await web3.eth.getBalance( addressList[142], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4597666", blockHash: "0x71c8c84ba15d43cc599647a6d7c7b68ac58c5c180df2cdb91b3c227d4e174def", timeStamp: "1511311737", hash: "0xfcfc41a3b4f80bbf4a4171082b4f1c3422939e77786b7d1a2280c92578fe37d6", nonce: "5", transactionIndex: "12", from: "0x07b2f97e316c37d08ee9e9c2b57e15e910fa0182", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "503263", txreceipt_status: "1", gasUsed: "45297", confirmations: "3145958", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[181], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511311737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x07b2f97e316c37d08ee9e9c2b57e15e910fa0182"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[181], balance: "1435156000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[181], balance: ( await web3.eth.getBalance( addressList[181], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"500000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4598051", blockHash: "0xa440e955b120bc025f92aed1937e03683e60e7d78de9c34449d9cad07e6a4a4e", timeStamp: "1511317055", hash: "0x8d4c70751f2b5cac43de17bd09e69500030d3c89c5f2840b76a92dc4823a45d4", nonce: "7", transactionIndex: "95", from: "0xfe5f4ab32afcba717b7aa47878c64bc1f76e38c1", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "8000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000001dcd6500", contractAddress: "", cumulativeGasUsed: "2893687", txreceipt_status: "1", gasUsed: "45297", confirmations: "3145573", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[218], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "500000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "500000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511317055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0xfe5f4ab32afcba717b7aa47878c64bc1f76e38c1"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "500000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[218], balance: "32228499860632041" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[218], balance: ( await web3.eth.getBalance( addressList[218], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4598642", blockHash: "0xa7c087ed247d36c22a4f3c3c2590303364c9f2e42872b5f77a643e40d42c9550", timeStamp: "1511325466", hash: "0x96ba50c294c29435fb6bfbb271c9c0496fdb94960469cc7c14e81c7614d06ff0", nonce: "4", transactionIndex: "111", from: "0x07e403c868703b02534d6875ac55b0fdf7b4dc49", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "2981663", txreceipt_status: "1", gasUsed: "45297", confirmations: "3144982", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1511325466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x07e403c868703b02534d6875ac55b0fdf7b4dc49"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "1967820000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4598977", blockHash: "0x22a7a388e881f4f5c836c6966c744fcf712d3d679f4d3088e2f6aedfae61c0b4", timeStamp: "1511330096", hash: "0xbb4d5557b606add1e0ef7a6026ef4f8e4b6c815e5b36944b30606fcb2736a8aa", nonce: "7", transactionIndex: "64", from: "0x0a0026eb77166dcda1187a607041bca70abd8fb3", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "2538669", txreceipt_status: "1", gasUsed: "45297", confirmations: "3144647", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[174], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1511330096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0a0026eb77166dcda1187a607041bca70abd8fb3"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[174], balance: "2454900000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[174], balance: ( await web3.eth.getBalance( addressList[174], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[220], \"50000\" )", async function( ) {
		const txOriginal = {blockNumber: "4599326", blockHash: "0xaf521f8e026cbe2c2f940d3c37f4da3916b2db3eebf8ff68fab5296c60f777dc", timeStamp: "1511335165", hash: "0xec5c980c3d8e87495f4df72ddf0d38cdfe56b05c03005b0e2ec6445782a4ba0f", nonce: "6", transactionIndex: "133", from: "0x32c222935f9cf057a2bf7dff3ce6a91937a9b95a", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0xa9059cbb0000000000000000000000003261752e646b58e5a14a785790e16b6c8cc7c46d000000000000000000000000000000000000000000000000000000000000c350", contractAddress: "", cumulativeGasUsed: "5820676", txreceipt_status: "0", gasUsed: "24173", confirmations: "3144298", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[219], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[220]}, {type: "uint256", name: "_value", value: "50000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[220], "50000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1511335165 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[219], balance: "42364000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[219], balance: ( await web3.eth.getBalance( addressList[219], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[220], \"50000\" )", async function( ) {
		const txOriginal = {blockNumber: "4599349", blockHash: "0x6ba2182d4f2b5b0e1f6f402316d8ea27ebdc1bfed5f94dd7d30a10b1fd3e4e7c", timeStamp: "1511335484", hash: "0x155d20629befe3a466e55ec66b77cd138a8f9c48bda979c2530afc9aab9c7ac8", nonce: "7", transactionIndex: "160", from: "0x32c222935f9cf057a2bf7dff3ce6a91937a9b95a", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0xa9059cbb0000000000000000000000003261752e646b58e5a14a785790e16b6c8cc7c46d000000000000000000000000000000000000000000000000000000000000c350", contractAddress: "", cumulativeGasUsed: "5357956", txreceipt_status: "0", gasUsed: "24173", confirmations: "3144275", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[219], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[220]}, {type: "uint256", name: "_value", value: "50000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[220], "50000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1511335484 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[219], balance: "42364000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[219], balance: ( await web3.eth.getBalance( addressList[219], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[220], \"50000\" )", async function( ) {
		const txOriginal = {blockNumber: "4599350", blockHash: "0x7de3ae0af56cf9ce1145f179dd010ae1d6bb5f83c9ba038eea7b6b1c48daae9f", timeStamp: "1511335517", hash: "0xf9baac2f3316658494375f136fe6cc36c12de199d5cb7574f638140e631c709b", nonce: "8", transactionIndex: "186", from: "0x32c222935f9cf057a2bf7dff3ce6a91937a9b95a", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0xa9059cbb0000000000000000000000003261752e646b58e5a14a785790e16b6c8cc7c46d000000000000000000000000000000000000000000000000000000000000c350", contractAddress: "", cumulativeGasUsed: "5874465", txreceipt_status: "0", gasUsed: "24173", confirmations: "3144274", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[219], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[220]}, {type: "uint256", name: "_value", value: "50000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[220], "50000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1511335517 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[219], balance: "42364000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[219], balance: ( await web3.eth.getBalance( addressList[219], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4599645", blockHash: "0xb31b40c20f39e594a6cbe3380106a75cda2557ae9e9063c3fa1eac1da3b7334a", timeStamp: "1511339582", hash: "0xb3f4697e8a2707bb8faf1a1711fe786f9f9af952ba3c52778c458a3c88544f36", nonce: "4", transactionIndex: "111", from: "0x08380fc6bcbcbe46ee1e4b8007139e41f5d8947e", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "3767649", txreceipt_status: "1", gasUsed: "45297", confirmations: "3143979", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[80], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1511339582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x08380fc6bcbcbe46ee1e4b8007139e41f5d8947e"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[80], balance: "1865820000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[80], balance: ( await web3.eth.getBalance( addressList[80], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4599647", blockHash: "0xacddc7339a86d2ddaf82d11601e9766f6cb34621f6391b1b91da76ba0f9b279a", timeStamp: "1511339603", hash: "0x7143b06031ec3fdfcb4b6baede7b116463ab1bac03965e7c581e0634a2eb1097", nonce: "4", transactionIndex: "47", from: "0x085424c42acd56bc1c427ec269d53f3029ced91a", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "2072218", txreceipt_status: "1", gasUsed: "45297", confirmations: "3143977", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[150], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1511339603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x085424c42acd56bc1c427ec269d53f3029ced91a"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[150], balance: "1684049600000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[150], balance: ( await web3.eth.getBalance( addressList[150], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[214], \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4599648", blockHash: "0x9c5a9203a484f3a69df86c1c4b4bb910bf843126002c9fe2c5a317928e6e84eb", timeStamp: "1511339612", hash: "0x6fe6f46b98e9a3aa0e0e97d1ad219920e6c84d7bb076f6d83c511ed871c530fb", nonce: "4", transactionIndex: "42", from: "0x085f075dee2008fee577ce74d0d9adbfd6545351", to: "0x9c9891f7795eb127ba4783b671573275ff3a83a9", value: "0", gas: "250000", gasPrice: "4000000000", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "1662043", txreceipt_status: "1", gasUsed: "45297", confirmations: "3143976", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[151], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[214]}, {type: "uint256", name: "_value", value: "1000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[214], "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1511339612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x085f075dee2008fee577ce74d0d9adbfd6545351"}, {name: "_spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "_value", type: "uint256", value: "1000000000"}], address: "0x9c9891f7795eb127ba4783b671573275ff3a83a9"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[151], balance: "1925564000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[151], balance: ( await web3.eth.getBalance( addressList[151], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
