const Bet100 = artifacts.require( "./Bet100.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Bet100" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xE7d934996356e353E6FF1530eE50221761167B47", "0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed", "0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1", "0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA", "0x8C7f8865aCdf45cE86aDAC2939A72658D12272E3", "0x37Cc69783696Ecd60Db956818097FfCdb362f135", "0x4ea5aA6DDf830f0D9Ee548b7Fb1B78fDC1BAA378", "0x000042425e06b0B1E8E20A811C91D6864608324B", "0x00004242ca3469E30aE4a62775fEe6584Ed3FDCA", "0x00004242F4449d49EC9C64ad6F9385a56b2a6297", "0x4b60FB2F76E6E8Af1bd0e9dc62C4C6A4bD0E80B8"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "id", type: "uint256"}], name: "getBet", outputs: [{name: "", type: "address"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "_bankRoll", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getBankroll", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "invest_amount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "id", type: "uint256"}], name: "getBetKey", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isStopped", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "withNumber", type: "uint256"}], name: "getMaxBetAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "betNumber", type: "uint256"}, {name: "betAmount", type: "uint256"}], name: "getBetReward", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "betsInfo", outputs: [{name: "playerAddress", type: "address"}, {name: "betNumber", type: "uint256"}, {name: "amountBet", type: "uint256"}, {name: "numberRolled", type: "uint256"}, {name: "laff", type: "uint256"}, {name: "betTime", type: "uint256"}, {name: "winAmount", type: "uint256"}, {name: "myid", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getStatus", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "investorsLosses", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "draw_amount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "investorsProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "betsKeys", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMinBetAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "randomOrgAPIKey", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "bets", outputs: [{name: "playerAddress", type: "address"}, {name: "betNumber", type: "uint256"}, {name: "amountBet", type: "uint256"}, {name: "numberRolled", type: "uint256"}, {name: "laff", type: "uint256"}, {name: "betTime", type: "uint256"}, {name: "winAmount", type: "uint256"}, {name: "myid", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "houseAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numBets", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "dealer_reward_total", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "OraclizeIFee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"}, {anonymous: false, inputs: [], name: "LOG_EmergencyWithdrawalProposed", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "withdrawalAddress", type: "address"}], name: "LOG_EmergencyWithdrawalFailed", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "withdrawalAddress", type: "address"}, {indexed: false, name: "amountWithdrawn", type: "uint256"}], name: "LOG_EmergencyWithdrawalSucceeded", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_FailedSend", type: "event"}, {anonymous: false, inputs: [], name: "LOG_ZeroSend", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_InvestorEntrance", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "int256"}], name: "LOG_InvestorCapitalUpdate", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_InvestorExit", type: "event"}, {anonymous: false, inputs: [], name: "LOG_ContractStopped", type: "event"}, {anonymous: false, inputs: [], name: "LOG_ContractResumed", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "oldAddr", type: "address"}, {indexed: false, name: "newOwnerAddress", type: "address"}], name: "LOG_OwnerAddressChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "oldAddr", type: "address"}, {indexed: false, name: "newHouseAddress", type: "address"}], name: "LOG_HouseAddressChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "oldKey", type: "string"}, {indexed: false, name: "newKey", type: "string"}], name: "LOG_RandomOrgAPIKeyChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "oldGasLimit", type: "uint256"}, {indexed: false, name: "newGasLimit", type: "uint256"}], name: "LOG_GasLimitChanged", type: "event"}, {anonymous: false, inputs: [], name: "LOG_EmergencyAutoStop", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "vote", type: "bool"}], name: "LOG_EmergencyWithdrawalVote", type: "event"}, {anonymous: false, inputs: [], name: "LOG_ValueIsTooBig", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LOG_NewBet(address,uint256,bytes32)", "LOG_BetWon(address,uint256,uint256,uint256)", "LOG_BetLost(address,uint256,uint256)", "LOG_EmergencyWithdrawalProposed()", "LOG_EmergencyWithdrawalFailed(address)", "LOG_EmergencyWithdrawalSucceeded(address,uint256)", "LOG_FailedSend(address,uint256)", "LOG_ZeroSend()", "LOG_InvestorEntrance(address,uint256)", "LOG_InvestorCapitalUpdate(address,int256)", "LOG_InvestorExit(address,uint256)", "LOG_ContractStopped()", "LOG_ContractResumed()", "LOG_OwnerAddressChanged(address,address)", "LOG_HouseAddressChanged(address,address)", "LOG_RandomOrgAPIKeyChanged(string,string)", "LOG_GasLimitChanged(uint256,uint256)", "LOG_EmergencyAutoStop()", "LOG_EmergencyWithdrawalVote(address,bool)", "LOG_ValueIsTooBig()", "LOG_SuccessfulSend(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xa3b3d5e0e64bd0499cbc49578be941089cde505befc0d24034adb36d078e52c7", "0x7659f92948da1b01a79540c840bd17753fd4c5d63ceaa3f6d66c7697cc37cd16", "0x544aa2cfe271023a2dfb03d6bbdb4e59ca0f3a13cea1422c1f2754861329cd5b", "0x6c0eb56f121418f16eaebbe01cb2694897b8578b3b1c549e634a1b7753ed2d8b", "0x0fd1ed783bf9505e3fc2545a18e022b8bd048d240d98a3c959646ccebd569b39", "0xe0376e740df28d6cbdef46880b37136bc75e027766e3295d4af8a44c557ae732", "0x949201d78c50a6b453f7068ed19a5c7d74aaa07c12cadfd3855357a0b0f47405", "0x4763e3feef50167ae1957a20ba2b75b5f4093062392e81d5e351b709b1d8261f", "0xa4a46f45c9996c78320ae470714f930acba653b022fddec1735c1400209780e4", "0x8ff49347da9034aab52b79ac6b2ba8cf17d221516834af5e5fa04bef1df4d7cd", "0x3026a12843449d7e7377f8932a40bdb5d1b1125efbfbe147132016f8beac0f34", "0x3bb54b4ced112fe0d4fa7efd42b29a0a9036fde6e206de4290c4ff02d2dc2c5c", "0xadf8f79dd508a8e1881e3cca67a5af02a21f971925c3a6a6cb8fc165d07e3463", "0x4f67fe223bca69f22bf24552638f3c95bfb9e9763c4a33a3aa67a46484d81c2b", "0xb750ac854b12114073b8c76dcfe5fb889b30db5d3d60e07abc8ae66c349d7a68", "0x90677626de53eafb8cbcc07c679de736cb8f5137b8d9e9df2097950207469f4d", "0xb5e4ece1f96cc168fddcead7ee209f969a93607238c585767ea80fad5fe884b2", "0x52e578ad17dc8fe0ff456fdf1f81516f7d29eb85fff301475a3a29d0e84bb31a", "0xea22ee15de9c385abeff072b23d6e0de5ebda8c59098f5585f45e82b9faa5762", "0x504b0ae89b95779262e99243870eb936180a8c33b444f17f01807c40a20c7aa7", "0xc7e416c5685d8971558840f05c5e63e02575b29997d8da6b9ba44dc10da6a370"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6902337 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6942989 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Bet100", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}], name: "getBet", outputs: [{name: "", type: "address"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBet(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "_bankRoll", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "_bankRoll()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getBankroll", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBankroll()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "invest_amount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "invest_amount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "id", value: random.range( maxRandom )}], name: "getBetKey", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBetKey(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isStopped", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isStopped()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "withNumber", value: random.range( maxRandom )}], name: "getMaxBetAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMaxBetAmount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "betNumber", value: random.range( maxRandom )}, {type: "uint256", name: "betAmount", value: random.range( maxRandom )}], name: "getBetReward", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBetReward(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "betsInfo", outputs: [{name: "playerAddress", type: "address"}, {name: "betNumber", type: "uint256"}, {name: "amountBet", type: "uint256"}, {name: "numberRolled", type: "uint256"}, {name: "laff", type: "uint256"}, {name: "betTime", type: "uint256"}, {name: "winAmount", type: "uint256"}, {name: "myid", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "betsInfo(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getStatus", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getStatus()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investorsLosses", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorsLosses()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "draw_amount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "draw_amount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investorsProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorsProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "betsKeys", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "betsKeys(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMinBetAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMinBetAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "randomOrgAPIKey", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "randomOrgAPIKey()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "bets", outputs: [{name: "playerAddress", type: "address"}, {name: "betNumber", type: "uint256"}, {name: "amountBet", type: "uint256"}, {name: "numberRolled", type: "uint256"}, {name: "laff", type: "uint256"}, {name: "betTime", type: "uint256"}, {name: "winAmount", type: "uint256"}, {name: "myid", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bets(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "houseAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "houseAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numBets", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numBets()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "dealer_reward_total", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dealer_reward_total()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "OraclizeIFee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "OraclizeIFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Bet100", function( accounts ) {

	it( "TEST: Bet100(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6902337", timeStamp: "1545038170", hash: "0x8e71b8563aa73146c705fb6dc0fc82ffc7f05d878e8b3655ba915c52cdae4f1c", nonce: "51", blockHash: "0xe862895a1dec95419c076211ecb97bc250a27538583a943ea6b835d90db7e97f", transactionIndex: "38", from: "0x37cc69783696ecd60db956818097ffcdb362f135", to: 0, value: "0", gas: "5070108", gasPrice: "8000200000", isError: "0", txreceipt_status: "1", input: "0xb397acb9", contractAddress: "0xe7d934996356e353e6ff1530ee50221761167b47", cumulativeGasUsed: "6492116", gasUsed: "5070108", confirmations: "773782"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Bet100", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Bet100.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1545038170 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Bet100.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "372742859198274945" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: changeOwnerAddress( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "6920051", timeStamp: "1545299086", hash: "0xc6572619f65c9b96e299017ce8cb6787f8e36e4b5a1cea57ed9674a50434ca49", nonce: "53", blockHash: "0xa81c0cdf9f235b1d1648bd94f7406052c956eb45ac75f4d913b667c93cdffaf1", transactionIndex: "87", from: "0x37cc69783696ecd60db956818097ffcdb362f135", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "30592", gasPrice: "5579104400", isError: "0", txreceipt_status: "1", input: "0x85eac05f0000000000000000000000004ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", contractAddress: "", cumulativeGasUsed: "6088628", gasUsed: "30592", confirmations: "756068"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newOwner", value: addressList[8]}], name: "changeOwnerAddress", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeOwnerAddress(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1545299086 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "oldAddr", type: "address"}, {indexed: false, name: "newOwnerAddress", type: "address"}], name: "LOG_OwnerAddressChanged", type: "event"} ;
		console.error( "eventCallOriginal[1,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_OwnerAddressChanged", events: [{name: "oldAddr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "newOwnerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[1,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "372742859198274945" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: increaseInvestment(  )", async function( ) {
		const txOriginal = {blockNumber: "6920080", timeStamp: "1545299504", hash: "0xc3614e11eac208e6930c1f6537190e9fe6441e91d9841928dbfefd456e17a313", nonce: "0", blockHash: "0x366621c5984d71667272dab34ca68ecd92f3ab2eada988578d051a8efd9f171b", transactionIndex: "22", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "500000000000000000", gas: "4600000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xa4beffa7", contractAddress: "", cumulativeGasUsed: "1002669", gasUsed: "63010", confirmations: "756039"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "increaseInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "increaseInvestment()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1545299504 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"46\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6920226", timeStamp: "1545301666", hash: "0x4b1664ceeef01f89b2f8c1f8b21ff8204a7422c67ea02de3fe56b36b95aa957b", nonce: "54", blockHash: "0x8a370f70d2b65baf60f80bad8a9e781aad5ff219ad4af2b796a33749bc6ebb2f", transactionIndex: "54", from: "0x37cc69783696ecd60db956818097ffcdb362f135", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22200000000000000", gas: "4600000", gasPrice: "12600000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc719000000000000000000000000000000000000000000000000000000000000002e0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1644742", gasUsed: "359969", confirmations: "755893"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "22200000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "46"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "46", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1545301666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "amount", type: "uint256", value: "22200000000000000"}, {name: "myid", type: "bytes32", value: "0x67bd03dab8ef0c6936bccc1079f6ff04512f058d06d6ca587fbd31af01a69f4b"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "372742859198274945" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x67bd03dab8ef0c6936bccc1079f6ff04512f... )", async function( ) {
		const txOriginal = {blockNumber: "6920229", timeStamp: "1545301710", hash: "0x3292eb195cd2d3c7561d8e48c8771f84b751652b3b8b1ea0b0a318fa164ef803", nonce: "30244", blockHash: "0x172304f50dbdcade428391a265065b263e0aec372c2c1ab7284da96d47178421", transactionIndex: "95", from: "0x000042425e06b0b1e8e20a811c91d6864608324b", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5067bd03dab8ef0c6936bccc1079f6ff04512f058d06d6ca587fbd31af01a69f4b000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000004323833320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220400fc43f652009d542d67dcbfeeedb75990ceecda2be3317ba8241b0d0531901000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4734738", gasUsed: "370834", confirmations: "755890"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x67bd03dab8ef0c6936bccc1079f6ff04512f058d06d6ca587fbd31af01a69f4b"}, {type: "string", name: "result", value: `2832`}, {type: "bytes", name: "proof", value: "0x1220400fc43f652009d542d67dcbfeeedb75990ceecda2be3317ba8241b0d0531901"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x67bd03dab8ef0c6936bccc1079f6ff04512f058d06d6ca587fbd31af01a69f4b", `2832`, "0x1220400fc43f652009d542d67dcbfeeedb75990ceecda2be3317ba8241b0d0531901", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1545301710 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetWon", events: [{name: "playerAddress", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "numberRolled", type: "uint256", value: "2832"}, {name: "amountWon", type: "uint256", value: "35705851024115867"}, {name: "betId", type: "uint256", value: "0"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[4,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "amount", type: "uint256", value: "35705851024115867"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[4,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "658167200000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6920403", timeStamp: "1545304233", hash: "0x6bddcb72cb986e97650a471448c0adb1b6c6588d637e04fa94913f70da3a7734", nonce: "55", blockHash: "0xb5ff4ab9f03d6e2668e91a73610ab43b81694211ba2a667df3b28711df7a7021", transactionIndex: "39", from: "0x37cc69783696ecd60db956818097ffcdb362f135", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22200000000000000", gas: "4600000", gasPrice: "6000200000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3187114", gasUsed: "329969", confirmations: "755716"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "22200000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1545304233 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "amount", type: "uint256", value: "22200000000000000"}, {name: "myid", type: "bytes32", value: "0x641378c5c5e65876244074c9230b8a71de86e9850d84eb29618ca4cc6b396f80"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "372742859198274945" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x641378c5c5e65876244074c9230b8a71de86... )", async function( ) {
		const txOriginal = {blockNumber: "6920407", timeStamp: "1545304296", hash: "0xb40dd9ccf6d04fd70e33e9926a667169b46db3c32b2eaa3f314a0d22649b2d0e", nonce: "30228", blockHash: "0x957d06e19830021e629223a33bacaf4c6d2606113e9e102330914c7619ec6440", transactionIndex: "40", from: "0x00004242ca3469e30ae4a62775fee6584ed3fdca", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50641378c5c5e65876244074c9230b8a71de86e9850d84eb29618ca4cc6b396f80000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000043231393400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212209b597421fe2e0fbae72690610db7540cc8388209ebe90afb3df6918acf20307e000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2137921", gasUsed: "295834", confirmations: "755712"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x641378c5c5e65876244074c9230b8a71de86e9850d84eb29618ca4cc6b396f80"}, {type: "string", name: "result", value: `2194`}, {type: "bytes", name: "proof", value: "0x12209b597421fe2e0fbae72690610db7540cc8388209ebe90afb3df6918acf20307e"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x641378c5c5e65876244074c9230b8a71de86e9850d84eb29618ca4cc6b396f80", `2194`, "0x12209b597421fe2e0fbae72690610db7540cc8388209ebe90afb3df6918acf20307e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1545304296 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetWon", events: [{name: "playerAddress", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "numberRolled", type: "uint256", value: "2194"}, {name: "amountWon", type: "uint256", value: "31883590154550650"}, {name: "betId", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[6,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "amount", type: "uint256", value: "31883590154550650"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[6,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "392729260000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6922269", timeStamp: "1545331489", hash: "0x52900eef9df9f571b962199a16fbe1fc2f2859a52e9bbb0c0e5327b0ba0f928b", nonce: "1", blockHash: "0x86bea9cd8829534f05d74d2fe818cc14708a28530a83ee0625f5175b7cde5432", transactionIndex: "36", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "60600000000000000", gas: "4600000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1430621", gasUsed: "126881", confirmations: "753850"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "60600000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1545331489 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6923880", timeStamp: "1545355184", hash: "0xda46bda6f985304b63d431c57f15155227fe715be415a7e8c95df72e491bc5ef", nonce: "2", blockHash: "0xa9e43f231609c3a39a282321c9a2aa0725054f8813be4e993b5559e47e340d7d", transactionIndex: "30", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22099999999999998", gas: "4600000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1670110", gasUsed: "422263", confirmations: "752239"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "22099999999999998" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1545355184 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "22099999999999998"}, {name: "myid", type: "bytes32", value: "0xd8a190b13b44dd0eb8439f9504b74c8cc790aa5d151fc7b5f61a4ac4b5b85b76"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xd8a190b13b44dd0eb8439f9504b74c8cc790... )", async function( ) {
		const txOriginal = {blockNumber: "6923882", timeStamp: "1545355226", hash: "0xe1dbf1efdbff97221b6778791d83c9f8dc902dbe9be04df568674dfe687b0c92", nonce: "30336", blockHash: "0x9287468bf96b9581ee9e1f719c838c10e6f3f0ad10d7a4250264a7ec1a611005", transactionIndex: "80", from: "0x000042425e06b0b1e8e20a811c91d6864608324b", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50d8a190b13b44dd0eb8439f9504b74c8cc790aa5d151fc7b5f61a4ac4b5b85b76000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000043137313500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212202da2479623d0e0c03f8bb059596b8887ea76d1619b580c1635f1fe0498c1f8b1000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3278799", gasUsed: "355834", confirmations: "752237"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xd8a190b13b44dd0eb8439f9504b74c8cc790aa5d151fc7b5f61a4ac4b5b85b76"}, {type: "string", name: "result", value: `1715`}, {type: "bytes", name: "proof", value: "0x12202da2479623d0e0c03f8bb059596b8887ea76d1619b580c1635f1fe0498c1f8b1"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xd8a190b13b44dd0eb8439f9504b74c8cc790aa5d151fc7b5f61a4ac4b5b85b76", `1715`, "0x12202da2479623d0e0c03f8bb059596b8887ea76d1619b580c1635f1fe0498c1f8b1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1545355226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetWon", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "1715"}, {name: "amountWon", type: "uint256", value: "31804279491833046"}, {name: "betId", type: "uint256", value: "2"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[9,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "31804279491833046"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[9,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "656923500000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: regName( `Game` )", async function( ) {
		const txOriginal = {blockNumber: "6923894", timeStamp: "1545355350", hash: "0x12752eb914f5d3098f232171eb1bc8d5d6b970cbf106c58e79d0894dcefbc17b", nonce: "3", blockHash: "0xea90a12b89e22a9ac037cf738021e6dcf9b2dd79c1c300aa1b4e44339f43be1f", transactionIndex: "43", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "10000000000000000", gas: "4600000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x135ee4490000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000447616d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1818817", gasUsed: "148093", confirmations: "752225"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `Game`}], name: "regName", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "regName(string)" ]( `Game`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1545355350 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6923894", timeStamp: "1545355350", hash: "0xace4b4f9cbabb2cfc5e0a5177e2bd4579f88017c37aab601ec43c51094c60cb5", nonce: "4", blockHash: "0xea90a12b89e22a9ac037cf738021e6dcf9b2dd79c1c300aa1b4e44339f43be1f", transactionIndex: "48", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22200000000000000", gas: "4600000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2244371", gasUsed: "329969", confirmations: "752225"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "22200000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1545355350 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "22200000000000000"}, {name: "myid", type: "bytes32", value: "0xbeb1f98949e3ce4e82119912fdbf56320037f13ab8797b1f51bc029d3be60ecd"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xbeb1f98949e3ce4e82119912fdbf56320037... )", async function( ) {
		const txOriginal = {blockNumber: "6923897", timeStamp: "1545355382", hash: "0x8c23192c57b1dec2a1ec8b1cde9183ac0f4af4db6adb3a1ea4b1216737c6b8ba", nonce: "30337", blockHash: "0xc4bb8cbbe8a4548c77b678f59f90a4679d47350ae83bfd6ab83e561970bf37d8", transactionIndex: "13", from: "0x000042425e06b0b1e8e20a811c91d6864608324b", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50beb1f98949e3ce4e82119912fdbf56320037f13ab8797b1f51bc029d3be60ecd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000435303231000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122038819edea7c38e48f30f35c756ea88ebb7be377e77388e575c61e6101f961ac8000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "662679", gasUsed: "297843", confirmations: "752222"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xbeb1f98949e3ce4e82119912fdbf56320037f13ab8797b1f51bc029d3be60ecd"}, {type: "string", name: "result", value: `5021`}, {type: "bytes", name: "proof", value: "0x122038819edea7c38e48f30f35c756ea88ebb7be377e77388e575c61e6101f961ac8"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xbeb1f98949e3ce4e82119912fdbf56320037f13ab8797b1f51bc029d3be60ecd", `5021`, "0x122038819edea7c38e48f30f35c756ea88ebb7be377e77388e575c61e6101f961ac8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1545355382 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "5021"}, {name: "betId", type: "uint256", value: "3"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[12,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[12,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "656209900000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6923899", timeStamp: "1545355386", hash: "0x8f937000dbb1d18228c7e1c47c9b65adf9a8dcec4741445111d59ab7db8f18a9", nonce: "5", blockHash: "0x867c951e29925733c59fbacb5c9e16e9abd912e6584d3c3cda18cf05603d75a2", transactionIndex: "64", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22200000000000000", gas: "4600000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3585345", gasUsed: "329969", confirmations: "752220"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "22200000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1545355386 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "22200000000000000"}, {name: "myid", type: "bytes32", value: "0x4225a439a2f8b3801b1e5c35f14798a6f3d08fca0ea9ae135c574a17b828617c"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4225a439a2f8b3801b1e5c35f14798a6f3d0... )", async function( ) {
		const txOriginal = {blockNumber: "6923902", timeStamp: "1545355418", hash: "0xd66ef33345a97c2497267b06da5408cd7b989884fed48db0c5f40dbc08a9d746", nonce: "30324", blockHash: "0x002d1c98578f25410abbddff0115c4a7fcbba7d439570a5285bb09d2eb6f06ee", transactionIndex: "34", from: "0x00004242ca3469e30ae4a62775fee6584ed3fdca", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa504225a439a2f8b3801b1e5c35f14798a6f3d08fca0ea9ae135c574a17b828617c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000004313230360000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220f797ccb13031d85720357a1f274248276e59ae9a5500512056c244f1784e489e000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1679758", gasUsed: "295770", confirmations: "752217"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x4225a439a2f8b3801b1e5c35f14798a6f3d08fca0ea9ae135c574a17b828617c"}, {type: "string", name: "result", value: `1206`}, {type: "bytes", name: "proof", value: "0x1220f797ccb13031d85720357a1f274248276e59ae9a5500512056c244f1784e489e"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x4225a439a2f8b3801b1e5c35f14798a6f3d08fca0ea9ae135c574a17b828617c", `1206`, "0x1220f797ccb13031d85720357a1f274248276e59ae9a5500512056c244f1784e489e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1545355418 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetWon", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "1206"}, {name: "amountWon", type: "uint256", value: "32002279491833050"}, {name: "betId", type: "uint256", value: "4"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[14,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "32002279491833050"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[14,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "389261520000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6923909", timeStamp: "1545355557", hash: "0x94d64ef8aed2b102e80e8022e19b57601a3d9a67e60abc463a01835275e8385c", nonce: "6", blockHash: "0x0aad1fce018b411448a65269177737a792b749bc0be3159d181a79b5db48956d", transactionIndex: "24", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "60700000000000000", gas: "4600000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1032178", gasUsed: "34587", confirmations: "752210"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "60700000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1545355557 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6923909", timeStamp: "1545355557", hash: "0x44098a8133cc8cb74bda5c0eadcf0c0aaf8ceb73d9df5b89239f0ead38b172f7", nonce: "7", blockHash: "0x0aad1fce018b411448a65269177737a792b749bc0be3159d181a79b5db48956d", transactionIndex: "25", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22200000000000000", gas: "4600000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1362147", gasUsed: "329969", confirmations: "752210"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "22200000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1545355557 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "22200000000000000"}, {name: "myid", type: "bytes32", value: "0x03213611856773351fb474dc6faebcfa2dd5f392d2ef23dfe0af5b1b3f434c43"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x03213611856773351fb474dc6faebcfa2dd5... )", async function( ) {
		const txOriginal = {blockNumber: "6923911", timeStamp: "1545355582", hash: "0x8a5ad0b1c953415e37c5c458b614bd673823a20b8ce778c6ffdb08a3600d3457", nonce: "30338", blockHash: "0xb512761472ce7fc9881ca51749beab808daf6102f5147b505b7ac08c5657406f", transactionIndex: "24", from: "0x000042425e06b0b1e8e20a811c91d6864608324b", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5003213611856773351fb474dc6faebcfa2dd5f392d2ef23dfe0af5b1b3f434c43000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000439343234000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122091ad4cb65afb2ae3f27687c92b603f45fb281314c3e0c1f77f573e231db45e82000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1222195", gasUsed: "267907", confirmations: "752208"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x03213611856773351fb474dc6faebcfa2dd5f392d2ef23dfe0af5b1b3f434c43"}, {type: "string", name: "result", value: `9424`}, {type: "bytes", name: "proof", value: "0x122091ad4cb65afb2ae3f27687c92b603f45fb281314c3e0c1f77f573e231db45e82"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x03213611856773351fb474dc6faebcfa2dd5f392d2ef23dfe0af5b1b3f434c43", `9424`, "0x122091ad4cb65afb2ae3f27687c92b603f45fb281314c3e0c1f77f573e231db45e82", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1545355582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "9424"}, {name: "betId", type: "uint256", value: "5"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[17,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[17,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "656209900000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"48\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6924032", timeStamp: "1545357405", hash: "0xdf8cf7de2801193e1bedc1947999a81547dae44449809ed823c1e99462ae4fda", nonce: "8", blockHash: "0xef2a1a30ab5e4fd3a3444304b59eae8b9f72daf2afd749780efc859e0bb8d590", transactionIndex: "66", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22099999999999998", gas: "4600000", gasPrice: "7140000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3237227", gasUsed: "329969", confirmations: "752087"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "22099999999999998" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "48"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "48", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1545357405 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "22099999999999998"}, {name: "myid", type: "bytes32", value: "0x8e69be590c3ee87a15fc1da8b91babdf0138356aafc1b2cbc23d0b0ccefba93e"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x8e69be590c3ee87a15fc1da8b91babdf0138... )", async function( ) {
		const txOriginal = {blockNumber: "6924034", timeStamp: "1545357430", hash: "0x8a9802e6c954949ba9a02f70bc11b8363f5c0368d2c28811d92aaebad2d30316", nonce: "30326", blockHash: "0x79d6fb8885276242440f33961b10f11aae431684faf42a11fa9c10945e9a5435", transactionIndex: "36", from: "0x00004242ca3469e30ae4a62775fee6584ed3fdca", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa508e69be590c3ee87a15fc1da8b91babdf0138356aafc1b2cbc23d0b0ccefba93e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000043634373400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212203d79eaad0e46a436b5a7b43589dfdda19cc3aaa3dec502c94eb8cec7022ff815000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1240724", gasUsed: "267907", confirmations: "752085"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x8e69be590c3ee87a15fc1da8b91babdf0138356aafc1b2cbc23d0b0ccefba93e"}, {type: "string", name: "result", value: `6474`}, {type: "bytes", name: "proof", value: "0x12203d79eaad0e46a436b5a7b43589dfdda19cc3aaa3dec502c94eb8cec7022ff815"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x8e69be590c3ee87a15fc1da8b91babdf0138356aafc1b2cbc23d0b0ccefba93e", `6474`, "0x12203d79eaad0e46a436b5a7b43589dfdda19cc3aaa3dec502c94eb8cec7022ff815", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1545357430 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "6474"}, {name: "betId", type: "uint256", value: "6"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[19,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[19,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "387764700000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6924046", timeStamp: "1545357668", hash: "0x2c29ff8d1ea7ac1d100a67ff9fd519d7eb12786fc13e4b00184c43f4a67d22a6", nonce: "10", blockHash: "0xe3bf15ebc52cd874e9ebeec803f33c06cd45f8f5607500b32982c2d89dfd6977", transactionIndex: "45", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22099999999999998", gas: "4600000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2071989", gasUsed: "329969", confirmations: "752073"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "22099999999999998" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1545357668 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "22099999999999998"}, {name: "myid", type: "bytes32", value: "0x54b2fd328606e5cff9ffaf08fc2b59fedc3b70dfe2b27ff134bfc03c5996709a"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x54b2fd328606e5cff9ffaf08fc2b59fedc3b... )", async function( ) {
		const txOriginal = {blockNumber: "6924051", timeStamp: "1545357729", hash: "0xaf1bbba81af82c027ddd6a3d1bb681781a2b125cd3508b1b654a095513eee480", nonce: "30327", blockHash: "0x3e8ec61445049257735381c44413c34f78ec4092af374d8d9875d728867b46fe", transactionIndex: "55", from: "0x00004242ca3469e30ae4a62775fee6584ed3fdca", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5054b2fd328606e5cff9ffaf08fc2b59fedc3b70dfe2b27ff134bfc03c5996709a000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000004393434310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220526e14736f98bbd34d0c75e17e5b70b83f7a0853cbeb2d2a7f453a2fb56e9e8b000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1905842", gasUsed: "267907", confirmations: "752068"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x54b2fd328606e5cff9ffaf08fc2b59fedc3b70dfe2b27ff134bfc03c5996709a"}, {type: "string", name: "result", value: `9441`}, {type: "bytes", name: "proof", value: "0x1220526e14736f98bbd34d0c75e17e5b70b83f7a0853cbeb2d2a7f453a2fb56e9e8b"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x54b2fd328606e5cff9ffaf08fc2b59fedc3b70dfe2b27ff134bfc03c5996709a", `9441`, "0x1220526e14736f98bbd34d0c75e17e5b70b83f7a0853cbeb2d2a7f453a2fb56e9e8b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1545357729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "9441"}, {name: "betId", type: "uint256", value: "7"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[21,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[21,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "387764700000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"63\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6924054", timeStamp: "1545357786", hash: "0x36438bf49aca1396589b01252702449dbbd52e41bf8b784bed75b81347835e4d", nonce: "11", blockHash: "0xdf1e5dab5bd8efd52f1a429e78beaebdc9e5a31ab83aefb7f258420d0d4d0686", transactionIndex: "18", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22099999999999998", gas: "4600000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc719000000000000000000000000000000000000000000000000000000000000003f0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1736889", gasUsed: "329969", confirmations: "752065"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "22099999999999998" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "63"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "63", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1545357786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "22099999999999998"}, {name: "myid", type: "bytes32", value: "0xe2b36cfeb2ea8aadd735ea72bf0c996b505c6cdca87a1fb43426d826c13dd053"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xe2b36cfeb2ea8aadd735ea72bf0c996b505c... )", async function( ) {
		const txOriginal = {blockNumber: "6924057", timeStamp: "1545357834", hash: "0x20dff2216447244c11135fa5b2dc9235e34f0e9f4f64cdc7e11a8d22fd461b85", nonce: "30328", blockHash: "0x645a0968669abfcdf2c3ccc48a4f032de10b3983ead1a1b58f6cdd769b1f306c", transactionIndex: "19", from: "0x00004242ca3469e30ae4a62775fee6584ed3fdca", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50e2b36cfeb2ea8aadd735ea72bf0c996b505c6cdca87a1fb43426d826c13dd053000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000004373031310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220988044bf03f9c3beeaf862cce5397591eac07f474ddefad2ccd3cf6e97463b85000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "823211", gasUsed: "267907", confirmations: "752062"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xe2b36cfeb2ea8aadd735ea72bf0c996b505c6cdca87a1fb43426d826c13dd053"}, {type: "string", name: "result", value: `7011`}, {type: "bytes", name: "proof", value: "0x1220988044bf03f9c3beeaf862cce5397591eac07f474ddefad2ccd3cf6e97463b85"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xe2b36cfeb2ea8aadd735ea72bf0c996b505c6cdca87a1fb43426d826c13dd053", `7011`, "0x1220988044bf03f9c3beeaf862cce5397591eac07f474ddefad2ccd3cf6e97463b85", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1545357834 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "7011"}, {name: "betId", type: "uint256", value: "8"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[23,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[23,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "387764700000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: divest( \"568000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6937579", timeStamp: "1545556982", hash: "0x773ae43cadbec761c25df35d77cc947fbec9c58f2f6ab4915ad9dc6e53283b47", nonce: "12", blockHash: "0x6da146383c73246324600d37a58e9c6df1c2c7a37726803de0235286dddcaa45", transactionIndex: "68", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "4600000", gasPrice: "2100000645", isError: "1", txreceipt_status: "0", input: "0x8ca1799500000000000000000000000000000000000000000000000007e1f0fd986c0000", contractAddress: "", cumulativeGasUsed: "3061025", gasUsed: "23399", confirmations: "738540"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amount", value: "568000000000000000"}], name: "divest", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "divest(uint256)" ]( "568000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1545556982 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: divest( \"568000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6937579", timeStamp: "1545556982", hash: "0xd61ba133fee65f09e833e03bc343032a50b440ffd87c80fa936accf8bb213403", nonce: "13", blockHash: "0x6da146383c73246324600d37a58e9c6df1c2c7a37726803de0235286dddcaa45", transactionIndex: "69", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "4600000", gasPrice: "14000000000", isError: "1", txreceipt_status: "0", input: "0x8ca1799500000000000000000000000000000000000000000000000007e1f0fd986c0000", contractAddress: "", cumulativeGasUsed: "3084424", gasUsed: "23399", confirmations: "738540"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amount", value: "568000000000000000"}], name: "divest", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "divest(uint256)" ]( "568000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1545556982 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: divest( \"560000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6937627", timeStamp: "1545557639", hash: "0xd9e47087fcca7bfe2b77c7b1a2a187647d5cc87ad07ba1103d8c922548f24e33", nonce: "14", blockHash: "0x812f40cc6d84340ed98244a4d484737b91696d7c192d2d6b2372e54e7f47e8cb", transactionIndex: "8", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "4600000", gasPrice: "14000000000", isError: "1", txreceipt_status: "0", input: "0x8ca1799500000000000000000000000000000000000000000000000007c5850872380000", contractAddress: "", cumulativeGasUsed: "444503", gasUsed: "23399", confirmations: "738492"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amount", value: "560000000000000000"}], name: "divest", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "divest(uint256)" ]( "560000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1545557639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: divest( \"460000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6937652", timeStamp: "1545557974", hash: "0x793cb8c685394c645333783e04880d5ff567659638260c92cdb0638998a7e777", nonce: "15", blockHash: "0x67fec47c9ea60e8878993e16908d08d7d5e76961735704d2bd99f41ea88cd2dd", transactionIndex: "84", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "4600000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0x8ca1799500000000000000000000000000000000000000000000000006623f9014ae0000", contractAddress: "", cumulativeGasUsed: "2041117", gasUsed: "38808", confirmations: "738467"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amount", value: "460000000000000000"}], name: "divest", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "divest(uint256)" ]( "460000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1545557974 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[27,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "460000000000000000"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[27,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: increaseInvestment(  )", async function( ) {
		const txOriginal = {blockNumber: "6937668", timeStamp: "1545558281", hash: "0x27114518c1a71a3a7434ced5f538976d25646407afee084035f00dcdb7352104", nonce: "16", blockHash: "0x59e4fdc7e98635014b0cc50aa94b2dc82159c66c638448d7374e4a66f1f82c0c", transactionIndex: "11", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "10000000000000000000", gas: "4600000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xa4beffa7", contractAddress: "", cumulativeGasUsed: "554682", gasUsed: "33010", confirmations: "738451"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "increaseInvestment", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "increaseInvestment()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1545558281 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6937676", timeStamp: "1545558368", hash: "0x04c01430119eac4a438c8e89bb8006fb3da46b00311854a257f8ac94a51f2f3b", nonce: "17", blockHash: "0x04a47b9de9f5a9eb989d290ea1cd373471e0936b954eec6c53780589bf4aaf04", transactionIndex: "65", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "1000000000000000000", gas: "4600000", gasPrice: "4030000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2686196", gasUsed: "329969", confirmations: "738443"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1545558368 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "1000000000000000000"}, {name: "myid", type: "bytes32", value: "0x00aee011bb2f41bc727a29adf24c1fc7a7147bf05d884cd24e4d01000c15796b"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x00aee011bb2f41bc727a29adf24c1fc7a714... )", async function( ) {
		const txOriginal = {blockNumber: "6937680", timeStamp: "1545558404", hash: "0xa29a462b196e744bede0b12fde5265e70820717f84543f03637995b2abe280ca", nonce: "30580", blockHash: "0x0f1a08c434913ced8a264b93dd65569d682a66cb1097b72f60637a1403a1439f", transactionIndex: "11", from: "0x00004242ca3469e30ae4a62775fee6584ed3fdca", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5000aee011bb2f41bc727a29adf24c1fc7a7147bf05d884cd24e4d01000c15796b000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000043433353600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212206161991858a191fa5530b984427b7da021577ddf20ef0a0bcf7c9c71cc53829c000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "653653", gasUsed: "310706", confirmations: "738439"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x00aee011bb2f41bc727a29adf24c1fc7a7147bf05d884cd24e4d01000c15796b"}, {type: "string", name: "result", value: `4356`}, {type: "bytes", name: "proof", value: "0x12206161991858a191fa5530b984427b7da021577ddf20ef0a0bcf7c9c71cc53829c"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x00aee011bb2f41bc727a29adf24c1fc7a7147bf05d884cd24e4d01000c15796b", `4356`, "0x12206161991858a191fa5530b984427b7da021577ddf20ef0a0bcf7c9c71cc53829c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1545558404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetWon", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "4356"}, {name: "amountWon", type: "uint256", value: "1968046279491833050"}, {name: "betId", type: "uint256", value: "9"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[30,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "1968046279491833050"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[30,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "387764700000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6937709", timeStamp: "1545558751", hash: "0xe7e2c762fce24764187f60b1e27d59bb8f4cdac48546bef38263310d1cba8799", nonce: "18", blockHash: "0x75c4ab7dc9f6dcd5713c07654e20da4970762853f568ba070e52c192db096868", transactionIndex: "45", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "500000000000000000", gas: "4600000", gasPrice: "2500000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2846274", gasUsed: "329969", confirmations: "738410"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1545558751 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "500000000000000000"}, {name: "myid", type: "bytes32", value: "0x2e045a0b18d012c77f2eef641e6ed5fc51cc7551bbc26464ea70ccca419262f4"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x2e045a0b18d012c77f2eef641e6ed5fc51cc... )", async function( ) {
		const txOriginal = {blockNumber: "6937711", timeStamp: "1545558793", hash: "0x84dedf2ef816ce9128a519eaa0fdabf4c1761c096f7fe31fc1fe034035a636c1", nonce: "30594", blockHash: "0x91e769133fbbee3546270382c8dec67e7273fdf5d05dc8b650383cafbd5c4026", transactionIndex: "64", from: "0x000042425e06b0b1e8e20a811c91d6864608324b", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa502e045a0b18d012c77f2eef641e6ed5fc51cc7551bbc26464ea70ccca419262f4000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000043239343200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212209bd036fe1006759a555ba243785d4cc2f88da67974ef44b15711d29da770f5ff000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2139619", gasUsed: "295834", confirmations: "738408"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x2e045a0b18d012c77f2eef641e6ed5fc51cc7551bbc26464ea70ccca419262f4"}, {type: "string", name: "result", value: `2942`}, {type: "bytes", name: "proof", value: "0x12209bd036fe1006759a555ba243785d4cc2f88da67974ef44b15711d29da770f5ff"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x2e045a0b18d012c77f2eef641e6ed5fc51cc7551bbc26464ea70ccca419262f4", `2942`, "0x12209bd036fe1006759a555ba243785d4cc2f88da67974ef44b15711d29da770f5ff", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1545558793 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetWon", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "2942"}, {name: "amountWon", type: "uint256", value: "978046279491833050"}, {name: "betId", type: "uint256", value: "10"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[32,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "978046279491833050"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[32,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "654071020000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6937913", timeStamp: "1545561464", hash: "0x42f8df22aeb054c91aaab3d2df089b38c04ee3fd95cc7af7ab0c183608452203", nonce: "19", blockHash: "0x8bece64756a00df41fc4a3f8196e63eb4ffd91567e25d827849d3f47675d9f51", transactionIndex: "58", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "100000000000000000", gas: "4600000", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3341212", gasUsed: "329969", confirmations: "738206"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1545561464 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "myid", type: "bytes32", value: "0x94d936352968281a8d9a6f248fc13d680033b547f4496c82a362f27f001206e5"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x94d936352968281a8d9a6f248fc13d680033... )", async function( ) {
		const txOriginal = {blockNumber: "6937916", timeStamp: "1545561499", hash: "0x8a2c3a0461129f5a28ff15ed9d3b29ec2c95ba3c74a5a6635a20bf93eeae50fd", nonce: "30513", blockHash: "0x3e965ff1047cb4c39249bc55caa31367faa82c7678cc40111e05a67a63f4aec1", transactionIndex: "4", from: "0x00004242f4449d49ec9c64ad6f9385a56b2a6297", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5094d936352968281a8d9a6f248fc13d680033b547f4496c82a362f27f001206e5000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000043838303200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212208022027298a0135183edd772f33e528ce882248f64238d1ad85a44de20b447a3000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "421244", gasUsed: "282779", confirmations: "738203"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x94d936352968281a8d9a6f248fc13d680033b547f4496c82a362f27f001206e5"}, {type: "string", name: "result", value: `8802`}, {type: "bytes", name: "proof", value: "0x12208022027298a0135183edd772f33e528ce882248f64238d1ad85a44de20b447a3"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x94d936352968281a8d9a6f248fc13d680033b547f4496c82a362f27f001206e5", `8802`, "0x12208022027298a0135183edd772f33e528ce882248f64238d1ad85a44de20b447a3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1545561499 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "8802"}, {name: "betId", type: "uint256", value: "11"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[34,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[34,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "608302860000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6938590", timeStamp: "1545571383", hash: "0xbd4daaca77614060fc60c7f40adb4021ec4a329fb34ddffa94e560b6b9055468", nonce: "20", blockHash: "0x21fb32a241d3ebb9777ae6d6f2ebd353f2db0afa5e7cfb0f000cc0eaec2530be", transactionIndex: "35", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "500000000000000000", gas: "4600000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3251805", gasUsed: "329969", confirmations: "737529"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1545571383 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "500000000000000000"}, {name: "myid", type: "bytes32", value: "0x15660b50df83d3d18b028528fe32f397c5cba133286b8ac3318292f300eab884"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x15660b50df83d3d18b028528fe32f397c5cb... )", async function( ) {
		const txOriginal = {blockNumber: "6938595", timeStamp: "1545571433", hash: "0xa727698640bc1832847822621e8dbdbfd25249b4fd95c6f49b844d5e50e41b77", nonce: "30600", blockHash: "0x75643e21a0b4fdeb1c6b2477439f1af3ef5e03f7bbea2dbdf0fab258868f9f9d", transactionIndex: "36", from: "0x000042425e06b0b1e8e20a811c91d6864608324b", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5015660b50df83d3d18b028528fe32f397c5cba133286b8ac3318292f300eab884000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000004333239330000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220c0b9a963f75aa9c2d75483434655538d7b784c3a082295c302a9a40d24dbe542000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1333231", gasUsed: "295770", confirmations: "737524"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x15660b50df83d3d18b028528fe32f397c5cba133286b8ac3318292f300eab884"}, {type: "string", name: "result", value: `3293`}, {type: "bytes", name: "proof", value: "0x1220c0b9a963f75aa9c2d75483434655538d7b784c3a082295c302a9a40d24dbe542"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x15660b50df83d3d18b028528fe32f397c5cba133286b8ac3318292f300eab884", `3293`, "0x1220c0b9a963f75aa9c2d75483434655538d7b784c3a082295c302a9a40d24dbe542", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1545571433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetWon", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "3293"}, {name: "amountWon", type: "uint256", value: "978046279491833050"}, {name: "betId", type: "uint256", value: "12"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[36,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "978046279491833050"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[36,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "653350420000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6938618", timeStamp: "1545571700", hash: "0xcb53e28a900f2651edac58a49a6c8d14ddf7ff9fdfdab544e2005dbe561dcd54", nonce: "21", blockHash: "0xaeaeed09986d2b6765c2c539fa260fe1bc7f3e3e8ccdcd1ec292ecb8223cad42", transactionIndex: "8", from: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "500000000000000000", gas: "4600000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "749655", gasUsed: "329969", confirmations: "737501"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1545571700 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "500000000000000000"}, {name: "myid", type: "bytes32", value: "0xfd9f1e523da65386b78ce2986a448d5dde90608cd65381107d0b75c3e5f5dfe0"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "329470452680027218" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfd9f1e523da65386b78ce2986a448d5dde90... )", async function( ) {
		const txOriginal = {blockNumber: "6938620", timeStamp: "1545571751", hash: "0xb9432db2a258d90d3d5d8c099440092f57699f538a5f4f63cb028399355de266", nonce: "30601", blockHash: "0x697b933c9e91ebf5f35c8094e40235f7d61e146b687a2c950d49cc86f54ba7c4", transactionIndex: "31", from: "0x000042425e06b0b1e8e20a811c91d6864608324b", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50fd9f1e523da65386b78ce2986a448d5dde90608cd65381107d0b75c3e5f5dfe0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000004343737360000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220a87acf5e8ad9d2f9c84e35aa1ca43197c8d90ecf9cb55d4359c369c4bba484ce000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1177692", gasUsed: "295834", confirmations: "737499"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xfd9f1e523da65386b78ce2986a448d5dde90608cd65381107d0b75c3e5f5dfe0"}, {type: "string", name: "result", value: `4776`}, {type: "bytes", name: "proof", value: "0x1220a87acf5e8ad9d2f9c84e35aa1ca43197c8d90ecf9cb55d4359c369c4bba484ce"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xfd9f1e523da65386b78ce2986a448d5dde90608cd65381107d0b75c3e5f5dfe0", `4776`, "0x1220a87acf5e8ad9d2f9c84e35aa1ca43197c8d90ecf9cb55d4359c369c4bba484ce", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1545571751 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetWon", events: [{name: "playerAddress", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "numberRolled", type: "uint256", value: "4776"}, {name: "amountWon", type: "uint256", value: "978046279491833050"}, {name: "betId", type: "uint256", value: "13"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[38,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4ea5aa6ddf830f0d9ee548b7fb1b78fdc1baa378"}, {name: "amount", type: "uint256", value: "978046279491833050"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[38,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "653350420000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6938698", timeStamp: "1545572941", hash: "0xb877ff50762a259f0612c3118538357fdde28a390c2cc7264e5296ea92d2e3d3", nonce: "57", blockHash: "0x25a5143f13f2c4fa867b0826fcf927b384aaab23478a89a31d8f42046d237325", transactionIndex: "13", from: "0x37cc69783696ecd60db956818097ffcdb362f135", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22099999999999998", gas: "4600000", gasPrice: "2120000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2807892", gasUsed: "329969", confirmations: "737421"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "22099999999999998" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1545572941 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "amount", type: "uint256", value: "22099999999999998"}, {name: "myid", type: "bytes32", value: "0x4c5433dc171b3831edd026baa7050116f9d4808977942470df4f29d427b43b5c"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "372742859198274945" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4c5433dc171b3831edd026baa7050116f9d4... )", async function( ) {
		const txOriginal = {blockNumber: "6938701", timeStamp: "1545572984", hash: "0x1cb455797ee0b8f2c70e5b5adb7109e03d3f7521de392e045e5ebb040d5fecc9", nonce: "30526", blockHash: "0xb3b262b0e38f226fecb3c6668859f408af8e278406cccc33a0f10950926b7f58", transactionIndex: "38", from: "0x00004242f4449d49ec9c64ad6f9385a56b2a6297", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa504c5433dc171b3831edd026baa7050116f9d4808977942470df4f29d427b43b5c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000004383834320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220527dc285084ffc127dbb131b13bccf09c82efa51b5b427eb9a069f9f804d077c000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1442861", gasUsed: "282907", confirmations: "737418"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x4c5433dc171b3831edd026baa7050116f9d4808977942470df4f29d427b43b5c"}, {type: "string", name: "result", value: `8842`}, {type: "bytes", name: "proof", value: "0x1220527dc285084ffc127dbb131b13bccf09c82efa51b5b427eb9a069f9f804d077c"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x4c5433dc171b3831edd026baa7050116f9d4808977942470df4f29d427b43b5c", `8842`, "0x1220527dc285084ffc127dbb131b13bccf09c82efa51b5b427eb9a069f9f804d077c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1545572984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "numberRolled", type: "uint256", value: "8842"}, {name: "betId", type: "uint256", value: "14"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[40,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[40,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "604185580000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6942496", timeStamp: "1545628352", hash: "0xb97d5ef46a1e3791d4ca5e9f3e87402c5f6b50237a51aa61abb05ffdfa88e025", nonce: "1", blockHash: "0x19f2afb791bdcaf25fe5ef7f972d1b4b044eb1f2046291f6adfb452b7f17789a", transactionIndex: "59", from: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22100000000000000", gas: "4600000", gasPrice: "1200000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3345514", gasUsed: "422263", confirmations: "733623"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "22100000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1545628352 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "amount", type: "uint256", value: "22100000000000000"}, {name: "myid", type: "bytes32", value: "0x8df3368c8ab3688d184b60bcd04bdd860f499b8c8ab26a459fa86a8aee9f5e3b"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "285228268583666104" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6942496", timeStamp: "1545628352", hash: "0xbf54e8e4dc9de719b0ef520f1c6fff7ffa7fd6dfe44ef298f12b3ebe72eb440a", nonce: "2", blockHash: "0x19f2afb791bdcaf25fe5ef7f972d1b4b044eb1f2046291f6adfb452b7f17789a", transactionIndex: "60", from: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22100000000000000", gas: "4600000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3675483", gasUsed: "329969", confirmations: "733623"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "22100000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1545628352 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "amount", type: "uint256", value: "22100000000000000"}, {name: "myid", type: "bytes32", value: "0xbf90188e37e556a3b69f28887ec4cd2d23b3c27363ae1aaab977d8839fda72fd"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "285228268583666104" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6942498", timeStamp: "1545628370", hash: "0x33a1b1e41dc321b01696fe88c6e42e872774c38725319f4a64220906c7ff1c33", nonce: "3", blockHash: "0x06e56b52240ec9e64b4c999abf58bc8bda7b01d60b832247d65d0d70c5c8278d", transactionIndex: "6", from: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22100000000000000", gas: "4600000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "506419", gasUsed: "329969", confirmations: "733621"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "22100000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1545628370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "amount", type: "uint256", value: "22100000000000000"}, {name: "myid", type: "bytes32", value: "0x9ea72cb55ae069f2451ac848a5afcbc9a5a802f1be617bdcedb8613a0c42065a"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "285228268583666104" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6942498", timeStamp: "1545628370", hash: "0xa0f8b91075e338f4eb50a177def33227f8344fdb56f0e4b1b5df9105674e3573", nonce: "4", blockHash: "0x06e56b52240ec9e64b4c999abf58bc8bda7b01d60b832247d65d0d70c5c8278d", transactionIndex: "7", from: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22100000000000000", gas: "4600000", gasPrice: "30200000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "836388", gasUsed: "329969", confirmations: "733621"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "22100000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1545628370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "amount", type: "uint256", value: "22100000000000000"}, {name: "myid", type: "bytes32", value: "0x207e6962b9cb02c0d2276d877adeff83d412d7fe7c91d9af6fe80addd400ee7d"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "285228268583666104" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xbf90188e37e556a3b69f28887ec4cd2d23b3... )", async function( ) {
		const txOriginal = {blockNumber: "6942500", timeStamp: "1545628381", hash: "0x28636f5c1dcec57b1f9da5bbc275fda8cbeea7c67df44674a4c0e8b6c9459bb1", nonce: "30622", blockHash: "0xbbcc591e196d1fb41713fb3bb7fd1e7eb6f21f78d050c350b05387324f0edce4", transactionIndex: "17", from: "0x00004242f4449d49ec9c64ad6f9385a56b2a6297", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50bf90188e37e556a3b69f28887ec4cd2d23b3c27363ae1aaab977d8839fda72fd000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000043731383600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212208714f00113537f549f5d9b1a8d1a525b66fe91450daea3801c62578158ea3ddc000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "892113", gasUsed: "312907", confirmations: "733619"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0xbf90188e37e556a3b69f28887ec4cd2d23b3c27363ae1aaab977d8839fda72fd"}, {type: "string", name: "result", value: `7186`}, {type: "bytes", name: "proof", value: "0x12208714f00113537f549f5d9b1a8d1a525b66fe91450daea3801c62578158ea3ddc"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xbf90188e37e556a3b69f28887ec4cd2d23b3c27363ae1aaab977d8839fda72fd", `7186`, "0x12208714f00113537f549f5d9b1a8d1a525b66fe91450daea3801c62578158ea3ddc", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1545628381 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "numberRolled", type: "uint256", value: "7186"}, {name: "betId", type: "uint256", value: "15"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[45,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[45,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "601226620000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x8df3368c8ab3688d184b60bcd04bdd860f49... )", async function( ) {
		const txOriginal = {blockNumber: "6942501", timeStamp: "1545628387", hash: "0x4dd46e29ae3fe0cf29ad3081899db43265129ef2af21eeea067d3f8e323de887", nonce: "30692", blockHash: "0xa4caf236a2a94641543785054e51f6192410cb844a2b8a1fd27b19b0609d121a", transactionIndex: "2", from: "0x000042425e06b0b1e8e20a811c91d6864608324b", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa508df3368c8ab3688d184b60bcd04bdd860f499b8c8ab26a459fa86a8aee9f5e3b000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000043733373300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212200760a3ad0ed35a1180dad00edb1dd4a465983be9d72e5e3ed768de0b0f734244000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "309907", gasUsed: "267907", confirmations: "733618"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x8df3368c8ab3688d184b60bcd04bdd860f499b8c8ab26a459fa86a8aee9f5e3b"}, {type: "string", name: "result", value: `7373`}, {type: "bytes", name: "proof", value: "0x12200760a3ad0ed35a1180dad00edb1dd4a465983be9d72e5e3ed768de0b0f734244"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x8df3368c8ab3688d184b60bcd04bdd860f499b8c8ab26a459fa86a8aee9f5e3b", `7373`, "0x12200760a3ad0ed35a1180dad00edb1dd4a465983be9d72e5e3ed768de0b0f734244", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1545628387 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "numberRolled", type: "uint256", value: "7373"}, {name: "betId", type: "uint256", value: "16"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[46,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[46,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "652630460000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x9ea72cb55ae069f2451ac848a5afcbc9a5a8... )", async function( ) {
		const txOriginal = {blockNumber: "6942503", timeStamp: "1545628449", hash: "0x85a8fb1be2053bc941d0b16c80aad1968c3442a93c7c7dff91f29dfdbff89781", nonce: "30698", blockHash: "0x5cc9d8d85a5f0bc9823308b3628ecfa932c13f0082bf749f07dbf067fa94e9ea", transactionIndex: "70", from: "0x00004242ca3469e30ae4a62775fee6584ed3fdca", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa509ea72cb55ae069f2451ac848a5afcbc9a5a802f1be617bdcedb8613a0c42065a000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000435313139000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122092eb4a759c6baa207688f41572612b05477f685b3bba37fad0fe75c4d0718efb000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2123885", gasUsed: "267907", confirmations: "733616"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x9ea72cb55ae069f2451ac848a5afcbc9a5a802f1be617bdcedb8613a0c42065a"}, {type: "string", name: "result", value: `5119`}, {type: "bytes", name: "proof", value: "0x122092eb4a759c6baa207688f41572612b05477f685b3bba37fad0fe75c4d0718efb"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x9ea72cb55ae069f2451ac848a5afcbc9a5a802f1be617bdcedb8613a0c42065a", `5119`, "0x122092eb4a759c6baa207688f41572612b05477f685b3bba37fad0fe75c4d0718efb", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1545628449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetLost", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetLost", events: [{name: "playerAddress", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "numberRolled", type: "uint256", value: "5119"}, {name: "betId", type: "uint256", value: "17"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[47,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "amount", type: "uint256", value: "1"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[47,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "378399380000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x207e6962b9cb02c0d2276d877adeff83d412... )", async function( ) {
		const txOriginal = {blockNumber: "6942503", timeStamp: "1545628449", hash: "0x59e790d98f9e0642c4de84177d34982f3f6962888f6c550c54341b0f749068c0", nonce: "30693", blockHash: "0x5cc9d8d85a5f0bc9823308b3628ecfa932c13f0082bf749f07dbf067fa94e9ea", transactionIndex: "76", from: "0x000042425e06b0b1e8e20a811c91d6864608324b", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "0", gas: "575000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50207e6962b9cb02c0d2276d877adeff83d412d7fe7c91d9af6fe80addd400ee7d000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000043234303200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212206cc2d27b87b486d6a337fee994ebe6b97e16bf4257e3fb429cdfddd5e9be5ced000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2638717", gasUsed: "325770", confirmations: "733616"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "myid", value: "0x207e6962b9cb02c0d2276d877adeff83d412d7fe7c91d9af6fe80addd400ee7d"}, {type: "string", name: "result", value: `2402`}, {type: "bytes", name: "proof", value: "0x12206cc2d27b87b486d6a337fee994ebe6b97e16bf4257e3fb429cdfddd5e9be5ced"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x207e6962b9cb02c0d2276d877adeff83d412d7fe7c91d9af6fe80addd400ee7d", `2402`, "0x12206cc2d27b87b486d6a337fee994ebe6b97e16bf4257e3fb429cdfddd5e9be5ced", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1545628449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "numberRolled", type: "uint256"}, {indexed: false, name: "amountWon", type: "uint256"}, {indexed: false, name: "betId", type: "uint256"}], name: "LOG_BetWon", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_BetWon", events: [{name: "playerAddress", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "numberRolled", type: "uint256", value: "2402"}, {name: "amountWon", type: "uint256", value: "31804279491833050"}, {name: "betId", type: "uint256", value: "18"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "LOG_SuccessfulSend", type: "event"} ;
		console.error( "eventCallOriginal[48,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LOG_SuccessfulSend", events: [{name: "addr", type: "address", value: "0x4b60fb2f76e6e8af1bd0e9dc62c4c6a4bd0e80b8"}, {name: "amount", type: "uint256", value: "31804279491833050"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[48,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "652630460000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: bet( \"50\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6942989", timeStamp: "1545635896", hash: "0x11178f35a94470c335ee3d7adc9c726c9d15aa60fc88a035bdcd8b719f7ac354", nonce: "60", blockHash: "0x687d8625b5e740a1f30d1515a9425dd4bfe7a2002422a377698b7a491b899ded", transactionIndex: "66", from: "0x37cc69783696ecd60db956818097ffcdb362f135", to: "0xe7d934996356e353e6ff1530ee50221761167b47", value: "22099999999999998", gas: "4600000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x6ffcc71900000000000000000000000000000000000000000000000000000000000000320000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2740174", gasUsed: "329969", confirmations: "733130"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "22099999999999998" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "betNumber", value: "50"}, {type: "uint256", name: "affCode", value: "0"}], name: "bet", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "bet(uint256,uint256)" ]( "50", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1545635896 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "playerAddress", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "myid", type: "bytes32"}], name: "LOG_NewBet", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LOG_NewBet", events: [{name: "playerAddress", type: "address", value: "0x37cc69783696ecd60db956818097ffcdb362f135"}, {name: "amount", type: "uint256", value: "22099999999999998"}, {name: "myid", type: "bytes32", value: "0x1c77966fed9337012bf28b30cd80d0f94bdc3408ab7aa6ba3c62ae3a49837087"}], address: "0xe7d934996356e353e6ff1530ee50221761167b47"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "372742859198274945" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "7558985018719560" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
