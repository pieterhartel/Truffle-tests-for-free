const bestmoney = artifacts.require( "./bestmoney.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "bestmoney" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x93052D29c94f5bCA09a22EE026ceb8c68522306c", "0x39D080403562770754d2fA41225b33CaEE85fdDd", "0xc42F87a2E51577d56D64BF7Aa8eE3A26F3ffE8cF", "0xb327D112A560f832765a12c72451DE40AF3C2be2", "0x87f7a5708e384407B4ED494bE1ff22aE68aB11F9", "0xc951D3463EbBa4e9Ec8dDfe1f42bc5895C46eC8f", "0xe88DB5c82Ebe225290e98B5D0bbB7bFC59e265ca", "0x22F14Cb872871a37B1d981B342B865F8A31fbAF9", "0x8A19329DA265B1B1f2Fc5f3B7D042A1a26f87d9B", "0xE9796E864aFFcdE6d5D168D94bb86571c300299a", "0x75994868e1F467b217C781Eb41cCAA3D436066BC", "0x8380d1c04705AF662EcE8A3eE5255E83bB2E35CA", "0x63E8375dbB9Df13Ab0CD217Ccc46fae376B609C1", "0x9c7245444A8c7570330D0e2B823F7bb2135bA033", "0x5976e422d2D51580c062933e15C71D575712b59d", "0x9c576cf9D7d0F4733E770a4408De5E32700170Bf", "0x38E123F89a7576B2942010Ad1f468CC0EA8f9F4b", "0x7dE2f46f4DafEbc223926e97a2b7D238B764A16a", "0xb03bEF1D9659363a9357aB29a05941491AcCb4eC", "0x41a21b264F9ebF6cF571D4543a5b3AB1c6bEd98C", "0x322F8254642305BD01b3E29728e5963EA4240c14", "0xf96309Cda21cB54E7554ca60B2e6004522815835", "0x0eDd0c239Ef99A285ddCa25EC340064232aD985e", "0x5aFa2A530B83E239261Aa46C6c29c9dF371FAA62", "0x3eA6899FB013949588b8d7Ea37aE19155d784be9", "0x364F8cAd2d0A36595b6dF3593d0DB18aeA24218c", "0x5E680DE4DF125b7F75c532d49CdAE3E5f2eE82D4", "0x9090cF38AF835a9cd535D4ebE45a828CD0DC86ad", "0x04cF0193C8937d8394fE1f2E0b3B2519c898EC10", "0xB973FFd5cBb5a3f182073e729ba5945f04Fc83a5", "0xA17C8047cbe809570FcA127fb4E706C802a9894d", "0xfeF0816BA79Ae57aF17fEC8D531bE197740096CA"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_customerAddress", type: "address"}], name: "dividendsOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_ethereumToSpend", type: "uint256"}], name: "calculateTokensReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokensToSell", type: "uint256"}], name: "calculateEthereumReceived", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "stakingRequirement", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_includeReferralBonus", type: "bool"}], name: "myDividends", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_customerAddress", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "tokensBurned", type: "uint256"}, {indexed: false, name: "ethereumEarned", type: "uint256"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenSell", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumWithdrawn", type: "uint256"}], name: "onWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "tokens", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["onTokenPurchase(address,uint256,uint256,address,uint256,uint256)", "onTokenSell(address,uint256,uint256,uint256,uint256)", "onReinvestment(address,uint256,uint256)", "onWithdraw(address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8032875b28d82ddbd303a9e4e5529d047a14ecb6290f80012a81b7e6227ff1ab", "0x8d3a0130073dbd54ab6ac632c05946df540553d3b514c9f8165b4ab7f2b1805e", "0xbe339fc14b041c2b0e0f3dd2cd325d0c3668b78378001e53160eab3615326458", "0xccad973dcd043c7d680389db4378bd6b9775db7124092e9e0422c9e46d7985dc", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6618122 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6618288 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "bestmoney", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "_customerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "dividendsOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dividendsOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_ethereumToSpend", value: random.range( maxRandom )}], name: "calculateTokensReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateTokensReceived(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokensToSell", value: random.range( maxRandom )}], name: "calculateEthereumReceived", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateEthereumReceived(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sellPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sellPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "stakingRequirement", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stakingRequirement()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bool", name: "_includeReferralBonus", value: ( random.range( 2 ) === 0 )}], name: "myDividends", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myDividends(bool)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalEthereumBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalEthereumBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_customerAddress", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "buyPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "buyPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "myTokens", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myTokens()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "bestmoney", function( accounts ) {

	it( "TEST: bestmoney(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6618122", timeStamp: "1540997334", hash: "0xc187d643185ae9c7d5e1e63b8687ebca4d35b54c34cc841af778ae96c0ff94a8", nonce: "3", blockHash: "0x0df9fb51ada7c2f7d5d248b35c8655c890f989f50c2ab3680894e15a69485281", transactionIndex: "72", from: "0xc42f87a2e51577d56d64bf7aa8ee3a26f3ffe8cf", to: 0, value: "0", gas: "1274343", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb40127f0", contractAddress: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", cumulativeGasUsed: "7309120", gasUsed: "1274343", confirmations: "1113753"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "bestmoney", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = bestmoney.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540997334 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = bestmoney.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "3984396884064351" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618159", timeStamp: "1540997769", hash: "0x17d17be10cba93529d8f03bb4d7dc13dc2945ed11999d6f63063c27c0f0bcf0b", nonce: "4570", blockHash: "0x915e3981ded9a3f6f9349a3938be840f6facc3b1bf1ee17c7a243629be150c60", transactionIndex: "9", from: "0xb327d112a560f832765a12c72451de40af3c2be2", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "200000000000000000", gas: "203472", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "445101", gasUsed: "135648", confirmations: "1113716"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540997769 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "incomingEthereum", type: "uint256", value: "200000000000000000"}, {name: "tokensMinted", type: "uint256", value: "5990008333327546304333"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540997769"}, {name: "price", type: "uint256", value: "65978000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "62250964370671825179" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618163", timeStamp: "1540997828", hash: "0xd80e05a9e064840f17de4afe477ea9a3fa76b1a462d0e50b936d13645481bd8b", nonce: "49", blockHash: "0xeccdd902b67891d1b74fdee8cabb5970e2f69a0a4be28f335687755473095875", transactionIndex: "50", from: "0x87f7a5708e384407b4ed494be1ff22ae68ab11f9", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "50000000000000000", gas: "167928", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1934760", gasUsed: "111952", confirmations: "1113712"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540997828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x87f7a5708e384407b4ed494be1ff22ae68ab11f9"}, {name: "incomingEthereum", type: "uint256", value: "50000000000000000"}, {name: "tokensMinted", type: "uint256", value: "708203052727606922168"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540997828"}, {name: "price", type: "uint256", value: "73766000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "255787719217264715" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618166", timeStamp: "1540997856", hash: "0x08d568c46b29d149115c9fd4f274ae3347d4e7fca70d433ea886318958bb47d7", nonce: "4", blockHash: "0x26166b6deb0e20c55b4f7a783902658943d17c0f5e84b7a74be98debd1bae7a9", transactionIndex: "67", from: "0xc42f87a2e51577d56d64bf7aa8ee3a26f3ffe8cf", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1000000000000000000", gas: "1360110", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5589782", gasUsed: "113190", confirmations: "1113709"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540997856 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xc42f87a2e51577d56d64bf7aa8ee3a26f3ffe8cf"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "8291791947277809736543"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540997856"}, {name: "price", type: "uint256", value: "164978000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "3984396884064351" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618168", timeStamp: "1540997914", hash: "0x49d9fcdf71b3c4c3b5fdb95e50625e3829154ad7b1b437183ebebafb7a176f8e", nonce: "7896", blockHash: "0x62c8be7267e828f75c26ffa97004a1707f411833d762c02920620a055a4ac095", transactionIndex: "91", from: "0xc951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "500000000000000000", gas: "168654", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3221357", gasUsed: "112436", confirmations: "1113707"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540997914 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xc951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f"}, {name: "incomingEthereum", type: "uint256", value: "500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "2748238833146510673965"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540997914"}, {name: "price", type: "uint256", value: "195206000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "332409698115059910" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618169", timeStamp: "1540997958", hash: "0x0d8d92d5782f37da3302f67c88026a99717f121450b90e660f45e46978d2c778", nonce: "0", blockHash: "0x6928bec805cb174e9fca41d47cbb5666722c698e1ce486d531d6f45623799cc7", transactionIndex: "78", from: "0xe88db5c82ebe225290e98b5d0bbb7bfc59e265ca", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1400000000000000000", gas: "113432", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4143818", gasUsed: "113432", confirmations: "1113706"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1400000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540997958 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xe88db5c82ebe225290e98b5d0bbb7bfc59e265ca"}, {name: "incomingEthereum", type: "uint256", value: "1400000000000000000"}, {name: "tokensMinted", type: "uint256", value: "6063521732904376922662"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540997958"}, {name: "price", type: "uint256", value: "261899000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618178", timeStamp: "1540998138", hash: "0xb408e15ebc509f3b01c0462dc3c8160c37fa97d4d5a860aeb9968ceeec14a511", nonce: "1356", blockHash: "0x276a9044bc40f717ed40770242888da67e2cb46997bd4c47dff267cf7bf6edaf", transactionIndex: "46", from: "0x22f14cb872871a37b1d981b342b865f8a31fbaf9", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1000000000000000000", gas: "168835", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1888057", gasUsed: "112557", confirmations: "1113697"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540998138 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x22f14cb872871a37b1d981b342b865f8a31fbaf9"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "3519538667453318022629"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998138"}, {name: "price", type: "uint256", value: "300619000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "408982485127722648" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618178", timeStamp: "1540998138", hash: "0xe14d1563d954155aa6b73f0f1ee532a6923752e7638131294ffdf03d24b99fa1", nonce: "4571", blockHash: "0x276a9044bc40f717ed40770242888da67e2cb46997bd4c47dff267cf7bf6edaf", transactionIndex: "123", from: "0xb327d112a560f832765a12c72451de40af3c2be2", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "146814", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "6445939", gasUsed: "97997", confirmations: "1113697"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540998138 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "incomingEthereum", type: "uint256", value: "180014722010574872"}, {name: "tokensMinted", type: "uint256", value: "586482982197759789713"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998138"}, {name: "price", type: "uint256", value: "307065000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "ethereumReinvested", type: "uint256", value: "180014722010574872"}, {name: "tokensMinted", type: "uint256", value: "586482982197759789713"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "62250964370671825179" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618187", timeStamp: "1540998245", hash: "0xd53dd4259bf9bf9a892e684362ce8431747753faed711f13ef3dde5a3cba6dbd", nonce: "0", blockHash: "0x07abd193e80d91ca7996db1ebfc68edbee8b3b889b9374fe886ee8ba06981eee", transactionIndex: "32", from: "0x8a19329da265b1b1f2fc5f3b7d042a1a26f87d9b", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1900000000000000000", gas: "112678", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1938416", gasUsed: "112678", confirmations: "1113688"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "1900000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3303526280257017" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618197", timeStamp: "1540998341", hash: "0x3fed85c7f0bf418607d669ef265ef16908ee89a085572ddc877a8367dbe08aa6", nonce: "1", blockHash: "0x7f2ffdabd6fecbd89901e581a0c2e203650146932660fd77c419638883d2be4e", transactionIndex: "47", from: "0xe9796e864affcde6d5d168d94bb86571c300299a", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1240000000000000000", gas: "112678", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3487894", gasUsed: "112678", confirmations: "1113678"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1240000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6618197", timeStamp: "1540998341", hash: "0x2612304ab32d48088652c879f36f9b1e55f0e5c971a320e22358f93b4d68e553", nonce: "12", blockHash: "0x7f2ffdabd6fecbd89901e581a0c2e203650146932660fd77c419638883d2be4e", transactionIndex: "82", from: "0x75994868e1f467b217c781eb41ccaa3d436066bc", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "700000000000000000", gas: "204238", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000b327d112a560f832765a12c72451de40af3c2be2", contractAddress: "", cumulativeGasUsed: "5292779", gasUsed: "136159", confirmations: "1113678"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "700000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[5]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540998341 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x75994868e1f467b217c781eb41ccaa3d436066bc"}, {name: "incomingEthereum", type: "uint256", value: "700000000000000000"}, {name: "tokensMinted", type: "uint256", value: "2172125550233933990949"}, {name: "referredBy", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "timestamp", type: "uint256", value: "1540998341"}, {name: "price", type: "uint256", value: "330957000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[14] )", async function( ) {
		const txOriginal = {blockNumber: "6618201", timeStamp: "1540998406", hash: "0xb036372adf03c0a2236c049ed28f903ebd337f065209b88712d0f8478c9dbc2a", nonce: "1935", blockHash: "0x09c65260f0d50b706b27f5524b778a998d9f5ffee26edbea5cb3c1d5f013ed4a", transactionIndex: "122", from: "0x8380d1c04705af662ece8a3ee5255e83bb2e35ca", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "100000000000000000", gas: "138811", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xf088d54700000000000000000000000063e8375dbb9df13ab0cd217ccc46fae376b609c1", contractAddress: "", cumulativeGasUsed: "5613288", gasUsed: "115676", confirmations: "1113674"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[14]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[14], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540998406 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x8380d1c04705af662ece8a3ee5255e83bb2e35ca"}, {name: "incomingEthereum", type: "uint256", value: "100000000000000000"}, {name: "tokensMinted", type: "uint256", value: "297631577984648604255"}, {name: "referredBy", type: "address", value: "0x63e8375dbb9df13ab0cd217ccc46fae376b609c1"}, {name: "timestamp", type: "uint256", value: "1540998406"}, {name: "price", type: "uint256", value: "334235000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "13054001351371648" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618205", timeStamp: "1540998458", hash: "0x0a79b73ed7aa301ccb10d95f90c5f987b4a93d373c3184c12c6a155527ec8c77", nonce: "0", blockHash: "0x43600fe3f9a70f00998e89c619dff26facc252f72cbd94c24a2919af75e527b9", transactionIndex: "140", from: "0x9c7245444a8c7570330d0e2b823f7bb2135ba033", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1900000000000000000", gas: "113674", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3256613", gasUsed: "113674", confirmations: "1113670"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1900000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540998458 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9c7245444a8c7570330d0e2b823f7bb2135ba033"}, {name: "incomingEthereum", type: "uint256", value: "1900000000000000000"}, {name: "tokensMinted", type: "uint256", value: "5184957234362252181114"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998458"}, {name: "price", type: "uint256", value: "391270000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "2172469098981342" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618210", timeStamp: "1540998524", hash: "0xb7f79af7641a6602e0978b9bb11eb35814044b2f2885ab6c93aca58dc9929de9", nonce: "4572", blockHash: "0x40c7a4dc5528ade66e9c8010213ee37428029ab467d60f6307b4779d29d90feb", transactionIndex: "103", from: "0xb327d112a560f832765a12c72451de40af3c2be2", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "147177", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "4923832", gasUsed: "83118", confirmations: "1113665"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540998524 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "incomingEthereum", type: "uint256", value: "93045376568647677"}, {name: "tokensMinted", type: "uint256", value: "234635100058377478439"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998524"}, {name: "price", type: "uint256", value: "393855000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "ethereumReinvested", type: "uint256", value: "93045376568647677"}, {name: "tokensMinted", type: "uint256", value: "234635100058377478439"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "62250964370671825179" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618212", timeStamp: "1540998568", hash: "0x75452b6bfe78354770797fa9da5149f52b4e6e87ba57a1547a1b23379e60d78d", nonce: "0", blockHash: "0x53ca175bc27ad3b2d3b4b578711479199791fc7079326fa4a13d4bc56cf71bf6", transactionIndex: "27", from: "0x5976e422d2d51580c062933e15c71d575712b59d", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "4800000000000000000", gas: "113674", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "893004", gasUsed: "113674", confirmations: "1113663"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "4800000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540998568 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x5976e422d2d51580c062933e15c71d575712b59d"}, {name: "incomingEthereum", type: "uint256", value: "4800000000000000000"}, {name: "tokensMinted", type: "uint256", value: "10519433151144266647538"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998568"}, {name: "price", type: "uint256", value: "509564000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "9062524708448674" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618214", timeStamp: "1540998602", hash: "0x24cc262c6378bd3cda4f014ccb86ceb31c8f1e6ea5b03ead749e8d4ba5591d3a", nonce: "7", blockHash: "0xd20a3c94c4f3df66064cc07c14cdb8f2583a0f185ceaa49e863df1abf2ca2981", transactionIndex: "24", from: "0x9c576cf9d7d0f4733e770a4408de5e32700170bf", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1500000000000000000", gas: "113674", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "902524", gasUsed: "113674", confirmations: "1113661"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "1500000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540998602 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9c576cf9d7d0f4733e770a4408de5e32700170bf"}, {name: "incomingEthereum", type: "uint256", value: "1500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "2827789911967393543259"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998602"}, {name: "price", type: "uint256", value: "540672000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "438177205850580436" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618217", timeStamp: "1540998648", hash: "0x068bc67500f480203a3d6ff956fb5c0283000d0ecef74b74703658490379cdce", nonce: "7897", blockHash: "0x02d6a635d805154bafedf32a7b96ad2665bc1d7e5e72c691917485c5f56d4915", transactionIndex: "37", from: "0xc951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "500000000000000000", gas: "124017", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1336643", gasUsed: "82678", confirmations: "1113658"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540998648 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xc951d3463ebba4e9ec8ddfe1f42bc5895c46ec8f"}, {name: "incomingEthereum", type: "uint256", value: "500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "907113315338761311285"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998648"}, {name: "price", type: "uint256", value: "550649000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "332409698115059910" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618217", timeStamp: "1540998648", hash: "0x1e193a640dbd1dccfbeb9f37f77d7cad5d140f61384a122650d81370be5fd2f9", nonce: "4573", blockHash: "0x02d6a635d805154bafedf32a7b96ad2665bc1d7e5e72c691917485c5f56d4915", transactionIndex: "85", from: "0xb327d112a560f832765a12c72451de40af3c2be2", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "147177", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "2828026", gasUsed: "98118", confirmations: "1113658"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540998648 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "incomingEthereum", type: "uint256", value: "129935635675506176"}, {name: "tokensMinted", type: "uint256", value: "233054476671827930141"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998648"}, {name: "price", type: "uint256", value: "553212000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "ethereumReinvested", type: "uint256", value: "129935635675506176"}, {name: "tokensMinted", type: "uint256", value: "233054476671827930141"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "62250964370671825179" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618217", timeStamp: "1540998648", hash: "0xd9bbc78f8ca5a5abb833634c5bc32b667b297fab2033d300ed193a80ad290e97", nonce: "50", blockHash: "0x02d6a635d805154bafedf32a7b96ad2665bc1d7e5e72c691917485c5f56d4915", transactionIndex: "101", from: "0x87f7a5708e384407b4ed494be1ff22ae68ab11f9", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "169677", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "3462868", gasUsed: "113118", confirmations: "1113658"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540998648 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x87f7a5708e384407b4ed494be1ff22ae68ab11f9"}, {name: "incomingEthereum", type: "uint256", value: "39338990147978527"}, {name: "tokensMinted", type: "uint256", value: "70346320001496282364"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998648"}, {name: "price", type: "uint256", value: "553982000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x87f7a5708e384407b4ed494be1ff22ae68ab11f9"}, {name: "ethereumReinvested", type: "uint256", value: "39338990147978527"}, {name: "tokensMinted", type: "uint256", value: "70346320001496282364"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "255787719217264715" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618218", timeStamp: "1540998674", hash: "0x5287216bd100705e0971bf5db6ca765823e417fa51e1f2136f80ae46029f448b", nonce: "1281", blockHash: "0x92a633e5f6e0b4a05c4b255c1b3620ca5622d9248a3f98f4abaadf519e5ebe0e", transactionIndex: "33", from: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1000000000000000000", gas: "135213", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "902335", gasUsed: "112678", confirmations: "1113657"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540998674 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1756336072340612891495"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998674"}, {name: "price", type: "uint256", value: "573309000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1506925000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618220", timeStamp: "1540998688", hash: "0x1e00b245c99369c25dd1cc92f8ebb0c222380fe37708b0905366481d40fb73b8", nonce: "28", blockHash: "0x1ff1fafe651e1c74bd715dd575b057f5259ec9a20bb9274589f64c4639c44323", transactionIndex: "28", from: "0x7de2f46f4dafebc223926e97a2b7d238b764a16a", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1500000000000000000", gas: "250000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1028550", gasUsed: "112799", confirmations: "1113655"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "1500000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540998688 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x7de2f46f4dafebc223926e97a2b7d238b764a16a"}, {name: "incomingEthereum", type: "uint256", value: "1500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "2528772073817589634331"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998688"}, {name: "price", type: "uint256", value: "601117000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "2803925715969970130" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618223", timeStamp: "1540998733", hash: "0xde7a0ffb36c5280e170f3c6ede5b54e2bfeec0fbafdb36528156cb632920e518", nonce: "13", blockHash: "0xfeae16e8c134eac8dab24cd7ffe96f52642bb7efd42c48cc430363b1b25af845", transactionIndex: "33", from: "0x75994868e1f467b217c781eb41ccaa3d436066bc", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "1435214", gasUsed: "98360", confirmations: "1113652"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540998733 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x75994868e1f467b217c781eb41ccaa3d436066bc"}, {name: "incomingEthereum", type: "uint256", value: "76376654601505047"}, {name: "tokensMinted", type: "uint256", value: "125636032546894073318"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998733"}, {name: "price", type: "uint256", value: "602503000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x75994868e1f467b217c781eb41ccaa3d436066bc"}, {name: "ethereumReinvested", type: "uint256", value: "76376654601505047"}, {name: "tokensMinted", type: "uint256", value: "125636032546894073318"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618223", timeStamp: "1540998733", hash: "0xc98604bfaa0a9419f0ef558f15b8d72aa38dc4a24b2f4dafd9a9fddebaa4d1a9", nonce: "5829", blockHash: "0xfeae16e8c134eac8dab24cd7ffe96f52642bb7efd42c48cc430363b1b25af845", transactionIndex: "141", from: "0xb03bef1d9659363a9357ab29a05941491accb4ec", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "5000000000000000000", gas: "169380", gasPrice: "115000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5598594", gasUsed: "112920", confirmations: "1113652"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540998733 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb03bef1d9659363a9357ab29a05941491accb4ec"}, {name: "incomingEthereum", type: "uint256", value: "5000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "7677311093670283698860"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998733"}, {name: "price", type: "uint256", value: "686950000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "4315328126289636616" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "6618223", timeStamp: "1540998733", hash: "0x1c0506305f8affdbb67a52cfea346bc7ac9cd76dc69e005bf0d82cfb75aa27f3", nonce: "886", blockHash: "0xfeae16e8c134eac8dab24cd7ffe96f52642bb7efd42c48cc430363b1b25af845", transactionIndex: "143", from: "0x41a21b264f9ebf6cf571d4543a5b3ab1c6bed98c", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1000000000000000000", gas: "600000", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0xf088d547000000000000000000000000322f8254642305bd01b3e29728e5963ea4240c14", contractAddress: "", cumulativeGasUsed: "5739105", gasUsed: "115918", confirmations: "1113652"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[22]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540998733 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x41a21b264f9ebf6cf571d4543a5b3ab1c6bed98c"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1424831958489139456924"}, {name: "referredBy", type: "address", value: "0x322f8254642305bd01b3e29728e5963ea4240c14"}, {name: "timestamp", type: "uint256", value: "1540998733"}, {name: "price", type: "uint256", value: "702625000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "1281672464499661630" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618224", timeStamp: "1540998764", hash: "0xddb2cfc9adcdff7f8afd9ebb1d25fb35180c51bbdf2ec56a61f56c337f3188dc", nonce: "4574", blockHash: "0x2589f9c92080cffe7874c520c007824140b0298e9c1e7777b75ab1f08d5dd95e", transactionIndex: "40", from: "0xb327d112a560f832765a12c72451de40af3c2be2", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "147540", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "4278156", gasUsed: "98360", confirmations: "1113651"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540998764 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "incomingEthereum", type: "uint256", value: "134735614690842063"}, {name: "tokensMinted", type: "uint256", value: "189553300018439252223"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998764"}, {name: "price", type: "uint256", value: "704715000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "ethereumReinvested", type: "uint256", value: "134735614690842063"}, {name: "tokensMinted", type: "uint256", value: "189553300018439252223"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "62250964370671825179" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618229", timeStamp: "1540998841", hash: "0xddf1e3b0cb1ddee877cb96627c9bd0362d234ff52ec542c9b3c6535acffb74f2", nonce: "0", blockHash: "0x7180b169e0363795b4061d3ab3ca3ae84254c63dd73aa9bc8408db27c431f59f", transactionIndex: "3", from: "0xf96309cda21cb54e7554ca60b2e6004522815835", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "950000000000000000", gas: "113916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "176967", gasUsed: "113916", confirmations: "1113646"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "950000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540998841 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xf96309cda21cb54e7554ca60b2e6004522815835"}, {name: "incomingEthereum", type: "uint256", value: "950000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1320916795474729812201"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998841"}, {name: "price", type: "uint256", value: "719246000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "13904548228811575" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618231", timeStamp: "1540998854", hash: "0xf7a1286baae680d116287161aa5054c2fd4a0e6dab5da407cf0440b09a4f5801", nonce: "29", blockHash: "0x754e40b0e39c7154051b3e9b88e71675d0c7bcd902852f1caac0fecf796c7763", transactionIndex: "42", from: "0x7de2f46f4dafebc223926e97a2b7d238b764a16a", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1000000000000000000", gas: "250000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2011777", gasUsed: "82920", confirmations: "1113644"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540998854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x7de2f46f4dafebc223926e97a2b7d238b764a16a"}, {name: "incomingEthereum", type: "uint256", value: "1000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1362205383293674758607"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998854"}, {name: "price", type: "uint256", value: "734228000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "2803925715969970130" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618232", timeStamp: "1540998891", hash: "0x1471a64e935c5a153b815d9cc370113f556d76a48cbd65d5718200bc7d54dc5f", nonce: "0", blockHash: "0x6b21e2da1390c949084c79bb27de711732670fc19d8631ea232e477f39ecb145", transactionIndex: "11", from: "0x0edd0c239ef99a285ddca25ec340064232ad985e", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "950000000000000000", gas: "113916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "389502", gasUsed: "113916", confirmations: "1113643"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "950000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540998891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x0edd0c239ef99a285ddca25ec340064232ad985e"}, {name: "incomingEthereum", type: "uint256", value: "950000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1268831189455483148659"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998891"}, {name: "price", type: "uint256", value: "748187000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "1531519608667641" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618232", timeStamp: "1540998891", hash: "0x2bec1de10328f2d3ea8e3902c8ba771207c98383723aa9b0c8e3eff37a824453", nonce: "1282", blockHash: "0x6b21e2da1390c949084c79bb27de711732670fc19d8631ea232e477f39ecb145", transactionIndex: "34", from: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "118032", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "1291493", gasUsed: "98360", confirmations: "1113643"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540998891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b"}, {name: "incomingEthereum", type: "uint256", value: "43233897337933736"}, {name: "tokensMinted", type: "uint256", value: "57181092146045835753"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998891"}, {name: "price", type: "uint256", value: "748814000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b"}, {name: "ethereumReinvested", type: "uint256", value: "43233897337933736"}, {name: "tokensMinted", type: "uint256", value: "57181092146045835753"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1506925000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618232", timeStamp: "1540998891", hash: "0xb8384683003e6af5b94e7d1c654e6e862c3e54b324b7596544b2033df6a270b5", nonce: "1936", blockHash: "0x6b21e2da1390c949084c79bb27de711732670fc19d8631ea232e477f39ecb145", transactionIndex: "112", from: "0x8380d1c04705af662ece8a3ee5255e83bb2e35ca", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "118032", gasPrice: "5280000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "3704492", gasUsed: "98360", confirmations: "1113643"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540998891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x8380d1c04705af662ece8a3ee5255e83bb2e35ca"}, {name: "incomingEthereum", type: "uint256", value: "15353755558763311"}, {name: "tokensMinted", type: "uint256", value: "20295301942456484870"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998891"}, {name: "price", type: "uint256", value: "749034000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x8380d1c04705af662ece8a3ee5255e83bb2e35ca"}, {name: "ethereumReinvested", type: "uint256", value: "15353755558763311"}, {name: "tokensMinted", type: "uint256", value: "20295301942456484870"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "13054001351371648" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618238", timeStamp: "1540998940", hash: "0xe5dc1f8cac77330de6d345563783612a81f968fb653ea15f34e77b52f6121429", nonce: "14", blockHash: "0x07201d76fc1867c7390385c08d597a8d6243d69f7a8ac13ebb20107cb466ab0e", transactionIndex: "62", from: "0x75994868e1f467b217c781eb41ccaa3d436066bc", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "2777358", gasUsed: "98360", confirmations: "1113637"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540998940 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x75994868e1f467b217c781eb41ccaa3d436066bc"}, {name: "incomingEthereum", type: "uint256", value: "42886265142897835"}, {name: "tokensMinted", type: "uint256", value: "56657025183590858873"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998940"}, {name: "price", type: "uint256", value: "749661000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x75994868e1f467b217c781eb41ccaa3d436066bc"}, {name: "ethereumReinvested", type: "uint256", value: "42886265142897835"}, {name: "tokensMinted", type: "uint256", value: "56657025183590858873"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618239", timeStamp: "1540998957", hash: "0x9d6411377ce6ea89e1d76baff3707b82f4ec3a0e7bc85698a5bc8dcb6904b6ff", nonce: "1", blockHash: "0xacf4d0c6a4c86720cf3ff4ee3e6c12fd2e586e81bff29e881db35cefa42ca0ad", transactionIndex: "22", from: "0x8a19329da265b1b1f2fc5f3b7d042a1a26f87d9b", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1950000000000000000", gas: "112920", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "660236", gasUsed: "112920", confirmations: "1113636"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "1950000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3303526280257017" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618239", timeStamp: "1540998957", hash: "0x7d6f1e8dafa7d0c4f271348009d08f23d54fb5bd2296fec9d2c69664d61ee3f8", nonce: "4575", blockHash: "0xacf4d0c6a4c86720cf3ff4ee3e6c12fd2e586e81bff29e881db35cefa42ca0ad", transactionIndex: "43", from: "0xb327d112a560f832765a12c72451de40af3c2be2", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "147540", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "2829209", gasUsed: "98360", confirmations: "1113636"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540998957 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "incomingEthereum", type: "uint256", value: "44269890450446086"}, {name: "tokensMinted", type: "uint256", value: "58435570514526687614"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540998957"}, {name: "price", type: "uint256", value: "750299000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "ethereumReinvested", type: "uint256", value: "44269890450446086"}, {name: "tokensMinted", type: "uint256", value: "58435570514526687614"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "62250964370671825179" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618242", timeStamp: "1540999009", hash: "0x181e54e7fc62b41e416653570f477fdf2c502307de7b5666ce7747f2b0481822", nonce: "16", blockHash: "0xa78603d110a5fe8762772f0464fe12783b6e9939e8f31a7160667620f34e6969", transactionIndex: "109", from: "0x5afa2a530b83e239261aa46c6c29c9df371faa62", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "50000000000000000", gas: "172110", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x87f7a5708e384407b4ed494be1ff22ae68ab11f9", contractAddress: "", cumulativeGasUsed: "5609494", gasUsed: "114740", confirmations: "1113633"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540999009 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x5afa2a530b83e239261aa46c6c29c9df371faa62"}, {name: "incomingEthereum", type: "uint256", value: "50000000000000000"}, {name: "tokensMinted", type: "uint256", value: "65939085402366482653"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999009"}, {name: "price", type: "uint256", value: "751025000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "701527572001076708" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618246", timeStamp: "1540999061", hash: "0xa8566bcf263c522b5b257fe7cf1f6ee37840f5a2ef6634944c33c305658c0835", nonce: "2", blockHash: "0xb67181ada41ef125c4f5375324650874368a41883c8741d59f3e6c179bde5ead", transactionIndex: "5", from: "0xe9796e864affcde6d5d168d94bb86571c300299a", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1250000000000000000", gas: "113916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "241680", gasUsed: "113916", confirmations: "1113629"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1250000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540999061 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xe9796e864affcde6d5d168d94bb86571c300299a"}, {name: "incomingEthereum", type: "uint256", value: "1250000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1628265952714165762472"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999061"}, {name: "price", type: "uint256", value: "768944000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618253", timeStamp: "1540999164", hash: "0xbd4003fd685e7b971c79d4fb93ca88b3cff6a9b1c60f63b38657ed2844da710e", nonce: "0", blockHash: "0xadca1205bd14616d5c5b9233ea86c6aa563c75d7f095724ab921ea98d8e69101", transactionIndex: "28", from: "0x3ea6899fb013949588b8d7ea37ae19155d784be9", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1350000000000000000", gas: "113916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "996268", gasUsed: "113916", confirmations: "1113622"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "1350000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540999164 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x3ea6899fb013949588b8d7ea37ae19155d784be9"}, {name: "incomingEthereum", type: "uint256", value: "1350000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1716962087952110300651"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999164"}, {name: "price", type: "uint256", value: "787831000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618254", timeStamp: "1540999202", hash: "0xa6646824ac47f8b3d2508deaae604a7ce16927202adfaf041005a42d1f329f64", nonce: "30", blockHash: "0x0c7b6733a69414c32e1f2d68b453f505ce2c4b57afeb067612381f8525988acf", transactionIndex: "92", from: "0x7de2f46f4dafebc223926e97a2b7d238b764a16a", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "190000000000000000", gas: "250000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5232341", gasUsed: "82920", confirmations: "1113621"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "190000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540999202 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x7de2f46f4dafebc223926e97a2b7d238b764a16a"}, {name: "incomingEthereum", type: "uint256", value: "190000000000000000"}, {name: "tokensMinted", type: "uint256", value: "238353507642795888339"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999202"}, {name: "price", type: "uint256", value: "790449000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "2803925715969970130" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618254", timeStamp: "1540999202", hash: "0x35b43d1ec7aee53d8132fa123a710bfd9ff74d6d193b842e12cb1cc87d7feab0", nonce: "21", blockHash: "0x0c7b6733a69414c32e1f2d68b453f505ce2c4b57afeb067612381f8525988acf", transactionIndex: "129", from: "0x364f8cad2d0a36595b6df3593d0db18aea24218c", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "500000000000000000", gas: "250000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7359889", gasUsed: "112920", confirmations: "1113621"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540999202 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x364f8cad2d0a36595b6df3593d0db18aea24218c"}, {name: "incomingEthereum", type: "uint256", value: "500000000000000000"}, {name: "tokensMinted", type: "uint256", value: "623500946269206727151"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999202"}, {name: "price", type: "uint256", value: "797302000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618255", timeStamp: "1540999226", hash: "0xe49127548c7be80ee44ba36505be37cb472ae491e0defe4f4fe89d31bd5e7850", nonce: "1", blockHash: "0x2910c1610334ac71a6b8c0eda3e9c06d40560db655c8c13835ac74c311f2af8c", transactionIndex: "172", from: "0x5976e422d2d51580c062933e15c71d575712b59d", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "190000000000000000", gas: "83916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4359164", gasUsed: "83916", confirmations: "1113620"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "190000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540999226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x5976e422d2d51580c062933e15c71d575712b59d"}, {name: "incomingEthereum", type: "uint256", value: "190000000000000000"}, {name: "tokensMinted", type: "uint256", value: "235528687045467184828"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999226"}, {name: "price", type: "uint256", value: "799898000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "9062524708448674" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618260", timeStamp: "1540999313", hash: "0xb6df26182bf5ce604f70be55b59fbe13bac215535574fb8788ace80774c57e9b", nonce: "0", blockHash: "0x379ba5e1742b44908dfc22b3d705cbda365028f88f6684f599f0d2c1b17c7fac", transactionIndex: "29", from: "0x5e680de4df125b7f75c532d49cdae3e5f2ee82d4", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "950000000000000000", gas: "113916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4977357", gasUsed: "113916", confirmations: "1113615"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "950000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540999313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x5e680de4df125b7f75c532d49cdae3e5f2ee82d4"}, {name: "incomingEthereum", type: "uint256", value: "950000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1166382379204957168474"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999313"}, {name: "price", type: "uint256", value: "812724000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "3021063498306947" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618260", timeStamp: "1540999313", hash: "0xdae57e4f9cb3d01e136d5d94f580416d75d5ffbd9f507338639c9ea05e599bab", nonce: "0", blockHash: "0x379ba5e1742b44908dfc22b3d705cbda365028f88f6684f599f0d2c1b17c7fac", transactionIndex: "35", from: "0x9090cf38af835a9cd535d4ebe45a828cd0dc86ad", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "950000000000000000", gas: "113916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5196273", gasUsed: "113916", confirmations: "1113615"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "950000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540999313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x9090cf38af835a9cd535d4ebe45a828cd0dc86ad"}, {name: "incomingEthereum", type: "uint256", value: "950000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1148253730685406870100"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999313"}, {name: "price", type: "uint256", value: "825363000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "2524877928828009" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618267", timeStamp: "1540999432", hash: "0xe96a2ed3c799ef8c8ec5e99abe28b510bbb95c30f7ea81b2aa90c94c11dba7b7", nonce: "0", blockHash: "0x00a1eb606068abe6759ece602ee124f6388f00c6d41351cf8a1da0f2781f844d", transactionIndex: "20", from: "0x04cf0193c8937d8394fe1f2e0b3b2519c898ec10", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1950000000000000000", gas: "112920", gasPrice: "41000000000", isError: "1", txreceipt_status: "0", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "694854", gasUsed: "112920", confirmations: "1113608"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "1950000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618275", timeStamp: "1540999526", hash: "0xc990203360b267394e5a3f56238dead4770df976df2ad42fbe11967dfb7532f7", nonce: "0", blockHash: "0x4254fd2ecf745477207fa184f5377ad8f81e5f5c9bcda0625a988f50006e58b2", transactionIndex: "229", from: "0xb973ffd5cbb5a3f182073e729ba5945f04fc83a5", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "2000000000000000000", gas: "113916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5116956", gasUsed: "113916", confirmations: "1113600"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540999526 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb973ffd5cbb5a3f182073e729ba5945f04fc83a5"}, {name: "incomingEthereum", type: "uint256", value: "2000000000000000000"}, {name: "tokensMinted", type: "uint256", value: "2361712615396081257232"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999526"}, {name: "price", type: "uint256", value: "851334000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618276", timeStamp: "1540999546", hash: "0x3f88cbc8776ab7cacc0a5a92ff92b53437b66b8d161ac185b1f8edbdbd34ef5a", nonce: "1284", blockHash: "0x9d4ba592ddf18580dbaa7d2c9e4fc99fcd2eb5157a248226d866152783e24690", transactionIndex: "24", from: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "118032", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "997510", gasUsed: "98360", confirmations: "1113599"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540999546 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b"}, {name: "incomingEthereum", type: "uint256", value: "24313380117567058"}, {name: "tokensMinted", type: "uint256", value: "28267403190645874965"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999546"}, {name: "price", type: "uint256", value: "851653000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x38e123f89a7576b2942010ad1f468cc0ea8f9f4b"}, {name: "ethereumReinvested", type: "uint256", value: "24313380117567058"}, {name: "tokensMinted", type: "uint256", value: "28267403190645874965"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "1506925000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618278", timeStamp: "1540999580", hash: "0x9d46a0e68e46c1c83f0a9d1f4b23b4eff81d3afb66ea02ef11a4e441624f2b7a", nonce: "0", blockHash: "0xa6ac92bcff26b7ce506ce59594015e65d6719ecf5436719a51cc23462b61f2f7", transactionIndex: "17", from: "0xa17c8047cbe809570fca127fb4e706c802a9894d", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "950000000000000000", gas: "113916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "911412", gasUsed: "113916", confirmations: "1113597"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "950000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540999580 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xa17c8047cbe809570fca127fb4e706c802a9894d"}, {name: "incomingEthereum", type: "uint256", value: "950000000000000000"}, {name: "tokensMinted", type: "uint256", value: "1096529670362274698983"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999580"}, {name: "price", type: "uint256", value: "863709000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "5190725514524365666" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618278", timeStamp: "1540999580", hash: "0x73b147111a882c110f30273aeb505186daa0a25dedd0c80d2ff9ea85c1f591cc", nonce: "51", blockHash: "0xa6ac92bcff26b7ce506ce59594015e65d6719ecf5436719a51cc23462b61f2f7", transactionIndex: "83", from: "0x87f7a5708e384407b4ed494be1ff22ae68ab11f9", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "147540", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "7561476", gasUsed: "98360", confirmations: "1113597"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540999580 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x87f7a5708e384407b4ed494be1ff22ae68ab11f9"}, {name: "incomingEthereum", type: "uint256", value: "30938088896056799"}, {name: "tokensMinted", type: "uint256", value: "35452690663773364942"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999580"}, {name: "price", type: "uint256", value: "864094000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x87f7a5708e384407b4ed494be1ff22ae68ab11f9"}, {name: "ethereumReinvested", type: "uint256", value: "30938088896056799"}, {name: "tokensMinted", type: "uint256", value: "35452690663773364942"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "255787719217264715" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6618279", timeStamp: "1540999606", hash: "0x8665a54d463f8974ccbbc707d1b6e02da3523a0c6f60f62c87bb945ff69e143e", nonce: "36", blockHash: "0xb11acd1884bacfa2d506cb3ebcbfad974f0786815e8bcf1bad2907e9cb56ce82", transactionIndex: "145", from: "0xfef0816ba79ae57af17fec8d531be197740096ca", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "250000000000000000", gas: "300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4930389", gasUsed: "112920", confirmations: "1113596"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540999606 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xfef0816ba79ae57af17fec8d531be197740096ca"}, {name: "incomingEthereum", type: "uint256", value: "250000000000000000"}, {name: "tokensMinted", type: "uint256", value: "285896054398006081191"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999606"}, {name: "price", type: "uint256", value: "867240000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "52334144329076466" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618280", timeStamp: "1540999628", hash: "0xd033ea34c9ba2c10cd7fe3c2156410ff886592e43dcb014a22afc38d5a1a152e", nonce: "15", blockHash: "0xf7de6f3341a45d8dcdcd3a11549a93023fa3f29cffed883ca02cd9ef9bb3e674", transactionIndex: "38", from: "0x75994868e1f467b217c781eb41ccaa3d436066bc", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "200000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "1500725", gasUsed: "98360", confirmations: "1113595"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540999628 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x75994868e1f467b217c781eb41ccaa3d436066bc"}, {name: "incomingEthereum", type: "uint256", value: "36192551240071947"}, {name: "tokensMinted", type: "uint256", value: "41303369842772414439"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999628"}, {name: "price", type: "uint256", value: "867702000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0x75994868e1f467b217c781eb41ccaa3d436066bc"}, {name: "ethereumReinvested", type: "uint256", value: "36192551240071947"}, {name: "tokensMinted", type: "uint256", value: "41303369842772414439"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: reinvest(  )", async function( ) {
		const txOriginal = {blockNumber: "6618281", timeStamp: "1540999676", hash: "0x61b305e745186b41b5aab35cd42181fcec258815635fa20c37de227d356b58e6", nonce: "4577", blockHash: "0x6f04f2cda9aa9af73de7d72fc6d07453da4f4005d0ff9da2f99ca14a3bc91e80", transactionIndex: "89", from: "0xb327d112a560f832765a12c72451de40af3c2be2", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "0", gas: "147540", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xfdb5a03e", contractAddress: "", cumulativeGasUsed: "6210773", gasUsed: "98360", confirmations: "1113594"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "reinvest", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reinvest()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540999676 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "incomingEthereum", type: "uint256", value: "111934940092484786"}, {name: "tokensMinted", type: "uint256", value: "127604834023125825393"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999676"}, {name: "price", type: "uint256", value: "869099000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "ethereumReinvested", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}], name: "onReinvestment", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "onReinvestment", events: [{name: "customerAddress", type: "address", value: "0xb327d112a560f832765a12c72451de40af3c2be2"}, {name: "ethereumReinvested", type: "uint256", value: "111934940092484786"}, {name: "tokensMinted", type: "uint256", value: "127604834023125825393"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "62250964370671825179" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buy( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6618288", timeStamp: "1540999763", hash: "0x35fe9bcfe152c82d574bae9d28858a3e98a9a11dffb974d4a5d9a67b4d7f17e9", nonce: "2", blockHash: "0x0436aa71e384cbe65670647c071b17058ba93d51196e5a7ccd87f6678c064d6c", transactionIndex: "6", from: "0x8a19329da265b1b1f2fc5f3b7d042a1a26f87d9b", to: "0x93052d29c94f5bca09a22ee026ceb8c68522306c", value: "1900000000000000000", gas: "113916", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xf088d5470000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "256561", gasUsed: "113916", confirmations: "1113587"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "1900000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_referredBy", value: addressList[0]}], name: "buy", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buy(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540999763 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "customerAddress", type: "address"}, {indexed: false, name: "incomingEthereum", type: "uint256"}, {indexed: false, name: "tokensMinted", type: "uint256"}, {indexed: true, name: "referredBy", type: "address"}, {indexed: false, name: "timestamp", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}], name: "onTokenPurchase", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "onTokenPurchase", events: [{name: "customerAddress", type: "address", value: "0x8a19329da265b1b1f2fc5f3b7d042a1a26f87d9b"}, {name: "incomingEthereum", type: "uint256", value: "1900000000000000000"}, {name: "tokensMinted", type: "uint256", value: "2135378571424455606014"}, {name: "referredBy", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "timestamp", type: "uint256", value: "1540999763"}, {name: "price", type: "uint256", value: "892595000000000"}], address: "0x93052d29c94f5bca09a22ee026ceb8c68522306c"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "3303526280257017" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "319082707890538" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
