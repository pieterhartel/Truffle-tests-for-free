const BancorChanger = artifacts.require( "./BancorChanger.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BancorChanger" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xF31619A15518DcE0613A514e6672D1F84f6e7fE7", "0x000528E861133F7DE24af8Cff4e2D44Ecec2449c", "0xd7eB9DB184DA9f099B84e2F86b1da1Fe6b305B3d", "0x8b0c11E0DF925387DE1ce92504Fe0e4af23Af6F2", "0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C", "0x6810e776880C02933D47DB1b9fc05908e5386b96", "0xc0829421C1d260BD3cB3E0F06cfE2D52db2cE315", "0x009BB5e9fCF28E5E601B7D0e9e821da6365d0a9c", "0x7B2e78D4dFaABA045A167a70dA285E30E8FcA196", "0xBca63B098bcA515c0424878E913e7bc932Df7726", "0x03733D509f60a33f1B86856560256351f23e5531", "0x97428F5eEADf095FD84Fe346286cFB2267826683", "0xa0f8adDD96a145843134d4447b9b90b75A7Cd62E", "0x1aeBfDc97dE35Bc32544Ff1db87159f16aBc98c7", "0x0080Ef2e364721695608c066b8330B1488156060", "0xb46dd29Bf9463E9d230cc6aab4125451Fc8a3345", "0xD5c0D17cCb9071D27a4F7eD8255F59989b9aee0d", "0x00156cd84776616BCc0bc5F78867cC2b67f8a285", "0x6Be4a7bbb812Bfa6A63126EE7b76C8A13529BDB8", "0x4c92a4C058F4b8699f2e18e3d83E8BD46eC37c32", "0xef1Efd77bFcE6A1D823BaaB65a6ed4144128a04f", "0xb0314ff0FaF9D82F04063b2540AC1BC617973235"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "changeFee", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_reserveToken", type: "address"}], name: "getReserveBalance", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_fromToken", type: "address"}, {name: "_toToken", type: "address"}, {name: "_amount", type: "uint256"}], name: "getReturn", outputs: [{name: "amount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "changerType", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newManager", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "manager", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_amount", type: "uint256"}], name: "getChangeFeeAmount", outputs: [{name: "feeAmount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "formula", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenIndex", type: "uint16"}], name: "changeableToken", outputs: [{name: "tokenAddress", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "version", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "changeableTokenCount", outputs: [{name: "count", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_reserveToken", type: "address"}, {name: "_sellAmount", type: "uint256"}], name: "getSaleReturn", outputs: [{name: "amount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "changingEnabled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getQuickBuyPathLength", outputs: [{name: "length", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "reserveTokenCount", outputs: [{name: "count", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_reserveToken", type: "address"}, {name: "_depositAmount", type: "uint256"}], name: "getPurchaseReturn", outputs: [{name: "amount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "hasQuickBuyEtherToken", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getQuickBuyEtherToken", outputs: [{name: "etherToken", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "reserveTokens", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "reserves", outputs: [{name: "virtualBalance", type: "uint256"}, {name: "ratio", type: "uint32"}, {name: "isVirtualBalanceEnabled", type: "bool"}, {name: "isPurchaseEnabled", type: "bool"}, {name: "isSet", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxChangeFee", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "quickBuyPath", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prevManager", type: "address"}, {indexed: false, name: "_newManager", type: "address"}], name: "ManagerUpdate", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prevOwner", type: "address"}, {indexed: false, name: "_newOwner", type: "address"}], name: "OwnerUpdate", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Change(address,address,address,uint256,uint256,uint256,uint256)", "ManagerUpdate(address,address)", "OwnerUpdate(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x7a222e1014ca7136a33e1c036d11f04c2fb08a3ecb33c8e02760a7e038580f90", "0xbe4cc281795971a471c980e842627a7f1ea3892ddfce8c5b6357cd2611c19732", "0x343765429aea5a34b3ff6a3785a98a5abb2597aca87bfbb58632c173d585373a"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4343661 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4363586 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}, {type: "address", name: "_formula", value: 5}, {type: "uint32", name: "_maxChangeFee", value: "30000"}, {type: "address", name: "_reserveToken", value: 6}, {type: "uint32", name: "_reserveRatio", value: "500000"}], name: "BancorChanger", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "changeFee", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changeFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getReserveBalance", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getReserveBalance(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_toToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_amount", value: random.range( maxRandom )}], name: "getReturn", outputs: [{name: "amount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getReturn(address,address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "changerType", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changerType()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newManager", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newManager()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "manager", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "manager()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_amount", value: random.range( maxRandom )}], name: "getChangeFeeAmount", outputs: [{name: "feeAmount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getChangeFeeAmount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "formula", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "formula()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "_tokenIndex", value: random.range( maxRandom )}], name: "changeableToken", outputs: [{name: "tokenAddress", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changeableToken(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "version", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "version()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "changeableTokenCount", outputs: [{name: "count", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changeableTokenCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_sellAmount", value: random.range( maxRandom )}], name: "getSaleReturn", outputs: [{name: "amount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getSaleReturn(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "changingEnabled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changingEnabled()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getQuickBuyPathLength", outputs: [{name: "length", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getQuickBuyPathLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "reserveTokenCount", outputs: [{name: "count", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserveTokenCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_depositAmount", value: random.range( maxRandom )}], name: "getPurchaseReturn", outputs: [{name: "amount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPurchaseReturn(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "hasQuickBuyEtherToken", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasQuickBuyEtherToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getQuickBuyEtherToken", outputs: [{name: "etherToken", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getQuickBuyEtherToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "reserveTokens", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserveTokens(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "reserves", outputs: [{name: "virtualBalance", type: "uint256"}, {name: "ratio", type: "uint32"}, {name: "isVirtualBalanceEnabled", type: "bool"}, {name: "isPurchaseEnabled", type: "bool"}, {name: "isSet", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserves(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxChangeFee", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxChangeFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "quickBuyPath", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "quickBuyPath(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BancorChanger", function( accounts ) {

	it( "TEST: BancorChanger( addressList[4], addressList[5], \"30000\... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4343661", timeStamp: "1507345256", hash: "0x727c5b331c58364d29a733863ba41c91279a10d3c8727b4b10db593e34e1bf6f", nonce: "44", blockHash: "0x6f5fb453803b2381130e7f8956c13a000e853ae49dfafb466454972eb3b6eb97", transactionIndex: "23", from: "0x000528e861133f7de24af8cff4e2d44ecec2449c", to: 0, value: "0", gas: "4471849", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x8e508527000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000008b0c11e0df925387de1ce92504fe0e4af23af6f200000000000000000000000000000000000000000000000000000000000075300000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000000000000000000000000000000000000007a120", contractAddress: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", cumulativeGasUsed: "4938527", gasUsed: "3726541", confirmations: "3372638"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "address", name: "_formula", value: addressList[5]}, {type: "uint32", name: "_maxChangeFee", value: "30000"}, {type: "address", name: "_reserveToken", value: addressList[6]}, {type: "uint32", name: "_reserveRatio", value: "500000"}], name: "BancorChanger", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BancorChanger.new( addressList[4], addressList[5], "30000", addressList[6], "500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1507345256 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BancorChanger.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: addReserve( addressList[7], \"500000\", false )", async function( ) {
		const txOriginal = {blockNumber: "4343666", timeStamp: "1507345377", hash: "0xd77ea904be375c92378565913bd1c929573885fb996b2a8e8e8e81d5322c6903", nonce: "45", blockHash: "0xddeaf5bcce5afce05c8603e3f6f1e8b84d59158572af78f2995fce503e672a61", transactionIndex: "45", from: "0x000528e861133f7de24af8cff4e2d44ecec2449c", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "101720", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x3291b39a0000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000000000000000000000000000000000000007a1200000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1868108", gasUsed: "84767", confirmations: "3372633"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[7]}, {type: "uint32", name: "_ratio", value: "500000"}, {type: "bool", name: "_enableVirtualBalance", value: false}], name: "addReserve", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addReserve(address,uint32,bool)" ]( addressList[7], "500000", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1507345377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setQuickBuyPath( [addressList[8],addressList[6],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4343668", timeStamp: "1507345435", hash: "0x76eb1d7692cdcd9d6e24ae1a5df2e27c09cfa03dd925e6c7de816dc625e77999", nonce: "46", blockHash: "0x14fecb74cc1219a1215660bdbf1995784063afc205f195e33fdc6a2beb8f4345", transactionIndex: "105", from: "0x000528e861133f7de24af8cff4e2d44ecec2449c", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "164128", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xd395ee0f00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000005000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96", contractAddress: "", cumulativeGasUsed: "3784922", gasUsed: "153053", confirmations: "3372631"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[8],addressList[6],addressList[6],addressList[4],addressList[7]]}], name: "setQuickBuyPath", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setQuickBuyPath(address[])" ]( [addressList[8],addressList[6],addressList[6],addressList[4],addressList[7]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1507345435 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: acceptTokenOwnership(  )", async function( ) {
		const txOriginal = {blockNumber: "4343679", timeStamp: "1507345699", hash: "0x26b943fe3f43ec51a32eb14a523a7af0c64677f70d4610515b3bcffc3c730009", nonce: "50", blockHash: "0x3bd820bea80c1e3559748589f96cac3cb3fe8cdea49f8c5d26f4ccb3c1e6655a", transactionIndex: "37", from: "0x000528e861133f7de24af8cff4e2d44ecec2449c", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "44446", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x38a5e016", contractAddress: "", cumulativeGasUsed: "1694488", gasUsed: "21867", confirmations: "3372620"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "acceptTokenOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptTokenOwnership()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1507345699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4343682", timeStamp: "1507345866", hash: "0x9372bd7b63191ed45ed09e88e1e81a70df63fbde75a439f50ca821637d4632d3", nonce: "356", blockHash: "0x4b71584e9611f9ff68c7cd8da90259a15240119326e8f922e4d48a8ffebc201e", transactionIndex: "66", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "1000000000000000000", gas: "478045", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "4259698", gasUsed: "353436", confirmations: "3372617"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1507345866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "135029723968352861695"}, {name: "_return", type: "uint256", value: "134831270159162540443"}, {name: "_currentPriceN", type: "uint256", value: "114935222905050814660325000000"}, {name: "_currentPriceD", type: "uint256", value: "114867415635079581270221500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "134831270159162540443"}, {name: "_return", type: "uint256", value: "2346909316410072508"}, {name: "_currentPriceN", type: "uint256", value: "114800000000000000000000000000"}, {name: "_currentPriceD", type: "uint256", value: "2000000000000000000000000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4343705", timeStamp: "1507346544", hash: "0x930bbe77b68fa240141120258d2720980f1a830413cfe40b13a892778d78eb46", nonce: "358", blockHash: "0xd76a908403d0a7a8afdce5cdc8ee6e09002f4e3fc3888fd3d9738eed725439ef", transactionIndex: "93", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "438236", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000002091e596bcad5dbc000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "4284951", gasUsed: "304975", confirmations: "3372594"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "2346909316410072508"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]], "2346909316410072508", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1507346544 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "2346909316410072508"}, {name: "_return", type: "uint256", value: "134673098151820979887"}, {name: "_currentPriceN", type: "uint256", value: "2000000000000000000000000000"}, {name: "_currentPriceD", type: "uint256", value: "114867336549075910489943500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "134673098151820979887"}, {name: "_return", type: "uint256", value: "134713192886052246186"}, {name: "_currentPriceN", type: "uint256", value: "114800000000000000000000000000"}, {name: "_currentPriceD", type: "uint256", value: "114935222905050814660325000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4345200", timeStamp: "1507392715", hash: "0xbff858afa35fe1288b1e9584d2ff9d00ce98e9da37de7ec28f0c21c8e1ec8bb4", nonce: "195", blockHash: "0x6b5cfbfcf5c022b5f53bbfa31b7fa6405394dda382bbe5e53e791ab8cc038f0d", transactionIndex: "61", from: "0x7b2e78d4dfaaba045a167a70da285e30e8fca196", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "100000000000000000", gas: "600265", gasPrice: "5000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "4967567", gasUsed: "354364", confirmations: "3371099"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1507392715 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "13604554941100276888"}, {name: "_return", type: "uint256", value: "13602479578906240992"}, {name: "_currentPriceN", type: "uint256", value: "114814114267105862691027000000"}, {name: "_currentPriceD", type: "uint256", value: "114806801239789453120496000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "13602479578906240992"}, {name: "_return", type: "uint256", value: "236955938525327518"}, {name: "_currentPriceN", type: "uint256", value: "114800000000000000000000000000"}, {name: "_currentPriceD", type: "uint256", value: "2000000000000000000000000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "2521440637054409488" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4350459", timeStamp: "1507549543", hash: "0x133d9d1377e3de79feead5b0f6ae6336cf92571214dd93b020e0ae0a7702e743", nonce: "2", blockHash: "0x2ea9bc94cf5ecf2d6a53f9495f844a43c353dd284b1ae3a8c6ea866082b76b5d", transactionIndex: "94", from: "0xbca63b098bca515c0424878e913e7bc932df7726", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "10000000000000000", gas: "600265", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "4339137", gasUsed: "354298", confirmations: "3365840"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1507549543 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1328071040469164129"}, {name: "_return", type: "uint256", value: "1327888578920618073"}, {name: "_currentPriceN", type: "uint256", value: "114815442338146331855156000000"}, {name: "_currentPriceD", type: "uint256", value: "114800663944289460309036500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1327888578920618073"}, {name: "_return", type: "uint256", value: "23131005837854551"}, {name: "_currentPriceN", type: "uint256", value: "114800000000000000000000000000"}, {name: "_currentPriceD", type: "uint256", value: "1999763044061474672482000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "43869434209000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4350937", timeStamp: "1507563490", hash: "0x0c25d22940a2ae5e4a7c6cb8de11956f02ae04e98a6667ceef575de368e3fab8", nonce: "359", blockHash: "0xdbff632844860e90f9af2d8c140bd92f3b04dcf5d1d811feb877ba2a83a11c3b", transactionIndex: "51", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "222950", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000056150f46ff1dd9c000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "2233341", gasUsed: "170719", confirmations: "3365362"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "25407000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "25407000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1507563490 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "25407000000000000000000"}, {name: "_return", type: "uint256", value: "24004488879165548830510"}, {name: "_currentPriceN", type: "uint256", value: "102096500000000000000000000000"}, {name: "_currentPriceD", type: "uint256", value: "114815442338146331855156000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4350945", timeStamp: "1507563736", hash: "0x3ef6c391df4cca859e60f19d6849debef4b3bf324b82b5b1977d34eab805bad8", nonce: "360", blockHash: "0x0552bd82fa9ad4fd486e9ee9641d0e41e9b8822a9841d7a77e4c2e7a79e87214", transactionIndex: "51", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "221482", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000003635c9adc5dea0000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000003000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "3472208", gasUsed: "169495", confirmations: "3365354"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "1000000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "1000000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1507563736 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1000000000000000000000"}, {name: "_return", type: "uint256", value: "887283971221881137570"}, {name: "_currentPriceN", type: "uint256", value: "101596500000000000000000000000"}, {name: "_currentPriceD", type: "uint256", value: "90810953458980783024646000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4351060", timeStamp: "1507567052", hash: "0xb6b995189daae892623b0923c1a31a41435efb16947c64ba04284d985b62044e", nonce: "15", blockHash: "0x4650336828f0689bb2d2219d2cdbe568bc9200407cfe45e782a21f50d260f652", transactionIndex: "51", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "20000000000000000", gas: "501000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3095868", gasUsed: "354759", confirmations: "3365239"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "1"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1507567052 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "2662491685463728450"}, {name: "_return", type: "uint256", value: "2959042934870294348"}, {name: "_currentPriceN", type: "uint256", value: "92926331979444365615526000000"}, {name: "_currentPriceD", type: "uint256", value: "103278788217358652799685000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "2959042934870294348"}, {name: "_return", type: "uint256", value: "57294183821763885"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1999739913055636817931000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4351073", timeStamp: "1507567509", hash: "0x4823aee913b069aafa7a177539c1f935473f885e6d3e80b704097f561984678c", nonce: "20", blockHash: "0x254a05ab03ff03909c58fdf2e9d0dfad1555671b3bc6ab51f5a38db1284676b9", transactionIndex: "37", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "908298", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "2097341", gasUsed: "209995", confirmations: "3365226"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6]], "10000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1507567509 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_return", type: "uint256", value: "516468052616820255"}, {name: "_currentPriceN", type: "uint256", value: "1999681859424967053517000000"}, {name: "_currentPriceD", type: "uint256", value: "103277566929917526062638500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "516468052616820255"}, {name: "_return", type: "uint256", value: "464705757246851410"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "92926831979444365615526000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4351091", timeStamp: "1507568055", hash: "0x6615f0e78e66a6ab64ebe7b9bae1075d4d8638cd7f7eaeaa66beb4e13073caa9", nonce: "8", blockHash: "0xcd01386890ee062d9be50bf70a6171ab6908b83eb2c4160f5e45fe62ee68bb6b", transactionIndex: "92", from: "0x97428f5eeadf095fd84fe346286cfb2267826683", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "349000000000000", gas: "498680", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3760615", gasUsed: "353367", confirmations: "3365208"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "349000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "1"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1507568055 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "46420675076058395"}, {name: "_return", type: "uint256", value: "51591378601389279"}, {name: "_currentPriceN", type: "uint256", value: "92926413694362194822511000000"}, {name: "_currentPriceD", type: "uint256", value: "103277334491580518347150500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "51591378601389279"}, {name: "_return", type: "uint256", value: "998925190273481"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1999681859424967053517000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "69101784083912013" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4351144", timeStamp: "1507570011", hash: "0x535859f900d87bc1e1837fecd1be87e1b95768cccd582acb2cd24a3fc0ec51d3", nonce: "21", blockHash: "0xf95de053cd4971c84ea4b876ce5051c80a054ccc604ffdfe3b132253d8ba4b1a", transactionIndex: "63", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "909342", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "3457358", gasUsed: "909342", confirmations: "3365155"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4351155", timeStamp: "1507570375", hash: "0xa9cfdc9332bb1117b825f2bd3e22fb429853ef268404a175d317d3a956adc5ee", nonce: "3", blockHash: "0x33b65f070a01c1bf001eaedeb06da626dc1bde7f7c890de14608708706f95dc8", transactionIndex: "51", from: "0xbca63b098bca515c0424878e913e7bc932df7726", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "10000000000000000", gas: "485867", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "3099546", gasUsed: "340756", confirmations: "3365144"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1507570375 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1331505487820839791"}, {name: "_return", type: "uint256", value: "1479633602762148928"}, {name: "_currentPriceN", type: "uint256", value: "92937745199850015662302000000"}, {name: "_currentPriceD", type: "uint256", value: "103278048512692598726975000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1479633602762148928"}, {name: "_return", type: "uint256", value: "28645642269813419"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1999465693937929872499000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "43869434209000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4351330", timeStamp: "1507575782", hash: "0xd133163586da3bb8e0d4054b1c8e9c94b31fafe037ae3eba11b30a82f380c439", nonce: "5", blockHash: "0x36c42e534303b4778f9c250cd7094d18c3d5efdfce6a7d62c336aae008d7a70a", transactionIndex: "95", from: "0xbca63b098bca515c0424878e913e7bc932df7726", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "371459", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "3455851", gasUsed: "331237", confirmations: "3364969"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "10000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]], "10000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1507575782 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_return", type: "uint256", value: "516528705533414071"}, {name: "_currentPriceN", type: "uint256", value: "1999447048295660059080000000"}, {name: "_currentPriceD", type: "uint256", value: "103277566960243984359546500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "516528705533414071"}, {name: "_return", type: "uint256", value: "464814912023592992"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "92937745199850015662302000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "43869434209000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4351342", timeStamp: "1507576075", hash: "0x2f5fb947880cfd5ae0f65bac609d47b683670b6c53d56c796e54aee7d826ccba", nonce: "6", blockHash: "0x04b3345354b30db04c4bcd1c23320f5f02a1cecf66cd1e114e99c68f0ab58ce2", transactionIndex: "13", from: "0xbca63b098bca515c0424878e913e7bc932df7726", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "3496796131776931", gas: "394011", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "880467", gasUsed: "338900", confirmations: "3364957"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "3496796131776931" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1507576075 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "464814912023592922"}, {name: "_return", type: "uint256", value: "516526122191800628"}, {name: "_currentPriceN", type: "uint256", value: "92937745199850015662232000000"}, {name: "_currentPriceD", type: "uint256", value: "103277566958952313552825000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "516526122191800628"}, {name: "_return", type: "uint256", value: "9999899973345310"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1999447048295660059080000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "43869434209000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4351935", timeStamp: "1507594113", hash: "0xa153f67e7f6fa27780ba1c2f26cf28170f2340766d1f3f7258bae95a622f62e8", nonce: "196", blockHash: "0xdfbe301edd9e30790e009c4c646096a075ba4d16719fae0489b211d9d9a02fa8", transactionIndex: "65", from: "0x7b2e78d4dfaaba045a167a70da285e30e8fca196", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "34485000000000000", gas: "486292", gasPrice: "4000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6181220", gasUsed: "339809", confirmations: "3364364"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "34485000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "1"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1507594113 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "4650368655710137710"}, {name: "_return", type: "uint256", value: "5167410940415816084"}, {name: "_currentPriceN", type: "uint256", value: "92942395568505725799942000000"}, {name: "_currentPriceD", type: "uint256", value: "103279892401361425560553000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "5167410940415816084"}, {name: "_return", type: "uint256", value: "100036739039679219"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1999437048395686713770000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "2521440637054409488" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4352003", timeStamp: "1507596520", hash: "0xebd4d0b5e6c003e6f42efd702f29815777bba7b07a37d81c330ff48df30d4b07", nonce: "17", blockHash: "0x7bf9998d6acca68df82dcc06bf59e27542aedf554d52f3f2fc1b8bf273b3e578", transactionIndex: "37", from: "0xa0f8addd96a145843134d4447b9b90b75a7cd62e", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "3459314000000000000", gas: "500006", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2077795", gasUsed: "354693", confirmations: "3364296"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "3459314000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "1"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1507596520 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "466494801963891587844"}, {name: "_return", type: "uint256", value: "512949296808227752485"}, {name: "_currentPriceN", type: "uint256", value: "93807672823419617387786000000"}, {name: "_currentPriceD", type: "uint256", value: "103533783344295331528753500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "512949296808227752485"}, {name: "_return", type: "uint256", value: "9851008470139702154"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1990795224048193130157000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1113000000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4352755", timeStamp: "1507619487", hash: "0xe44f847d8ae5d3f63d752ebe10c7bbf26b9d53cd00fb9d3d90a6da7d6a49e171", nonce: "250", blockHash: "0xde7a476e12416aecab2b7e02f70871d632dbac6cf01cf304b007d978bc6c2af3", transactionIndex: "27", from: "0x1aebfdc97de35bc32544ff1db87159f16abc98c7", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "3478000000000000", gas: "499608", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1540064", gasUsed: "354295", confirmations: "3363544"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "3478000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "1"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1507619487 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "473474951431011950"}, {name: "_return", type: "uint256", value: "521267703781921077"}, {name: "_currentPriceN", type: "uint256", value: "93808146298371048399736000000"}, {name: "_currentPriceD", type: "uint256", value: "103277569329743108613049500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "521267703781921077"}, {name: "_return", type: "uint256", value: "9998307922286401"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1980944215578053428003000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "2192775263802279" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4353305", timeStamp: "1507635005", hash: "0x216859fcea9d4b3e3037a87f548aa857e93e3e1a030bf5d309764d372476ee59", nonce: "96", blockHash: "0x98c45d2b7ffa4d83a09c25ae768d89eaa1edfb15f624288c63a5665f745a90ce", transactionIndex: "27", from: "0x0080ef2e364721695608c066b8330b1488156060", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "25178953000000000000", gas: "500652", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1868312", gasUsed: "355339", confirmations: "3362994"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "25178953000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "1"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1507635005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "3420724877905906876779"}, {name: "_return", type: "uint256", value: "3602113478101337765951"}, {name: "_currentPriceN", type: "uint256", value: "97228871176276955276515000000"}, {name: "_currentPriceD", type: "uint256", value: "105078365434941886535486500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "3602113478101337765951"}, {name: "_return", type: "uint256", value: "67324969241437819850"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1980934217270131141602000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "99915793457155046" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4353317", timeStamp: "1507635631", hash: "0x442d85830c051c687038fdba10343464b67c9b07785d43c374af0d2b3a0e962c", nonce: "6", blockHash: "0x225f522bd7545c0e892ded4d162ffef354dcf8bc0e8d21a61f6884d633cfb3f5", transactionIndex: "31", from: "0xb46dd29bf9463e9d230cc6aab4125451fc8a3345", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "560657000000000000", gas: "500586", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1475598", gasUsed: "355273", confirmations: "3362982"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "560657000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "1"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1507635631 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "76153274528124671170"}, {name: "_return", type: "uint256", value: "80811521002553878061"}, {name: "_currentPriceN", type: "uint256", value: "97305024450805079947685000000"}, {name: "_currentPriceD", type: "uint256", value: "103317714456392494591541500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "80811521002553878061"}, {name: "_return", type: "uint256", value: "1496465886002290776"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1913609248028693321752000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "870043199379485636" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4353500", timeStamp: "1507640948", hash: "0x497119af1a149054c9220355f88b1db2137d966fd84f1a3847da0a9f42c45660", nonce: "100", blockHash: "0x72080cfb43ee4e4de25e68bf9e70afecc3bf2607e81a487dc1541666b5d138e4", transactionIndex: "51", from: "0x0080ef2e364721695608c066b8330b1488156060", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1516590", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000003a640af52c74c0000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "4702885", gasUsed: "1516590", confirmations: "3362799"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "67320000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "99915793457155046" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4353515", timeStamp: "1507641659", hash: "0xc0dbbb9d9b37fc9320019b9765db21acb5a5e7412f74ef82b5a9998acdc616a7", nonce: "101", blockHash: "0x231cbb7c42a30e3d1c610d2223279085e953076cbf8c8f57ddf5dcdb9b3a9fda", transactionIndex: "49", from: "0x0080ef2e364721695608c066b8330b1488156060", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1516590", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000003a5f9a16de7ca0000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "2597170", gasUsed: "334447", confirmations: "3362784"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "67300000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]], "67300000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1507641659 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "67300000000000000000"}, {name: "_return", type: "uint256", value: "3482076447844511271805"}, {name: "_currentPriceN", type: "uint256", value: "1979412782142691030976000000"}, {name: "_currentPriceD", type: "uint256", value: "105018346919813473288413500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "3482076447844511271805"}, {name: "_return", type: "uint256", value: "3199583352718139243626"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "97305024450805079947685000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "99915793457155046" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4353588", timeStamp: "1507643517", hash: "0xf8d5a5bc6fe5bb925d9e0e55380ec7a874474f9e269d129b6fd466e2cafe3120", nonce: "3", blockHash: "0x8739aa69939798fd891377d2bb6125cf19390fac0bd431a4f2a76d2290bc1222", transactionIndex: "29", from: "0xd5c0d17ccb9071d27a4f7ed8255f59989b9aee0d", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "10000000000000000", gas: "501564", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1471615", gasUsed: "356251", confirmations: "3362711"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "1"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1507643517 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1358614965370426249"}, {name: "_return", type: "uint256", value: "1491003744491224537"}, {name: "_currentPriceN", type: "uint256", value: "94106799713052311130308000000"}, {name: "_currentPriceD", type: "uint256", value: "103278054197763463264779500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1491003744491224537"}, {name: "_return", type: "uint256", value: "28576266672768693"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1979412782142691030976000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "5848538000000001" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[6],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4354313", timeStamp: "1507664982", hash: "0x365b15ac45082ddbd5201df2d2ac5d6d2f912c406800760b6b50c01ace81b859", nonce: "179", blockHash: "0x552d9caede35df021685a807b2a65588a55e933d83b3c4f72d7016c7ea991275", transactionIndex: "99", from: "0x00156cd84776616bcc0bc5f78867cc2b67f8a285", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "350000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d", contractAddress: "", cumulativeGasUsed: "6216930", gasUsed: "350000", confirmations: "3361986"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[6],addressList[4],addressList[4]]}, {type: "uint256", name: "_amount", value: "2000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "996850000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[6],addressList[4]], \"20000... )", async function( ) {
		const txOriginal = {blockNumber: "4354351", timeStamp: "1507666019", hash: "0xd1dcfd17a7e542c0131651d1ec8f05cdff4ecefc8d31b47c600a2f354e5e1798", nonce: "180", blockHash: "0x554fe07ec891d06fa900aae89cd60d4af93b46f8dc4263a6f25fb20188008516", transactionIndex: "25", from: "0x00156cd84776616bcc0bc5f78867cc2b67f8a285", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "350000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000020000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d", contractAddress: "", cumulativeGasUsed: "2308577", gasUsed: "350000", confirmations: "3361948"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[6],addressList[4]]}, {type: "uint256", name: "_amount", value: "2000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "996850000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[6],addressList[7]], \"20000... )", async function( ) {
		const txOriginal = {blockNumber: "4354439", timeStamp: "1507668693", hash: "0xae2b2245e9170511005c9f1d54b0aca0edc1cc07d3f1e3eb91905deacdbbfdad", nonce: "181", blockHash: "0x4c391d57af9decd8e378d3d1bdc556d5f830ae0415290804d55debba55d87ad4", transactionIndex: "116", from: "0x00156cd84776616bcc0bc5f78867cc2b67f8a285", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "350000", gasPrice: "10000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000020000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96", contractAddress: "", cumulativeGasUsed: "6227409", gasUsed: "350000", confirmations: "3361860"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[6],addressList[7]]}, {type: "uint256", name: "_amount", value: "2000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "996850000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4361187", timeStamp: "1507869545", hash: "0x7d642b6347adb888052f46cb845687f804bff78aa816cec4e4ac5047fea9e66a", nonce: "79", blockHash: "0xfac00c42960fda52e82c59767d668322a662958542e510d1f91425cc259d38a3", transactionIndex: "47", from: "0x6be4a7bbb812bfa6a63126ee7b76c8a13529bdb8", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1516170", gasPrice: "25812961229", isError: "0", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000dbd2fc137a3000000000000000000000000000000000000000000000000000004ad1d1853562be400000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "2314676", gasUsed: "304665", confirmations: "3355112"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "990000000000000000"}, {type: "uint256", name: "_minReturn", value: "336957537437232100"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]], "990000000000000000", "336957537437232100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1507869545 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "990000000000000000"}, {name: "_return", type: "uint256", value: "51625187119232267450"}, {name: "_currentPriceN", type: "uint256", value: "1980269044556613512944000000"}, {name: "_currentPriceD", type: "uint256", value: "103303121289450833786236000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "51625187119232267450"}, {name: "_return", type: "uint256", value: "47025996914387578021"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "94111799713052311130308000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "301116081431119144" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4361234", timeStamp: "1507870750", hash: "0x8c087323cd0e4d54ad553bd1844270759e354a9b7f7b20b343a31a8ab4c5f29a", nonce: "81", blockHash: "0x9b5d55a1a01a8af4b03a3076d96696d4bbd0089d2a440c69c70d391d8d020123", transactionIndex: "44", from: "0x6be4a7bbb812bfa6a63126ee7b76c8a13529bdb8", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1517910", gasPrice: "26648819512", isError: "1", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000002a2155683c3cc4000000000000000000000000000000000000000000000000000e4c9c1160c3565000000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "3171149", gasUsed: "1517910", confirmations: "3355065"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "3035801530000000000"}, {type: "uint256", name: "_minReturn", value: "1030370013212792400"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "301116081431119144" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4361246", timeStamp: "1507871123", hash: "0x178b9f6e0d6209d17615587933dbbd1e752dcde85820766d1fe23adc4af36200", nonce: "83", blockHash: "0x05048bb033489fb0a2c800bed5ee1ebecf057605562578ffd3edbfd34eafaf48", transactionIndex: "24", from: "0x6be4a7bbb812bfa6a63126ee7b76c8a13529bdb8", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1517910", gasPrice: "26648819512", isError: "0", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000002a1e7c6b7d4f80000000000000000000000000000000000000000000000000000e4ba4a5216609bc00000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "1679781", gasUsed: "334033", confirmations: "3355053"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "3035000000000000000"}, {type: "uint256", name: "_minReturn", value: "1030097968921184700"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]], "3035000000000000000", "1030097968921184700", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1507871123 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "3035000000000000000"}, {name: "_return", type: "uint256", value: "157982236537607001312"}, {name: "_currentPriceN", type: "uint256", value: "1983304044556613512944000000"}, {name: "_currentPriceD", type: "uint256", value: "103356299814160021153167000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "157982236537607001312"}, {name: "_return", type: "uint256", value: "143725004555908693247"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "94064773716137923552287000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "301116081431119144" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4361325", timeStamp: "1507873048", hash: "0xeab8814ba9246e079774ca5ce59bb02f07156c689f2b759ece0eb8e7032eca11", nonce: "87", blockHash: "0x4f4c02364615736efb631f878a9047fe6b318d4df38ac3b8a85f80eb6cd0e5f7", transactionIndex: "166", from: "0x6be4a7bbb812bfa6a63126ee7b76c8a13529bdb8", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1517660", gasPrice: "32982836542", isError: "0", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000002b05699353b600000000000000000000000000000000000000000000000000000e8cc572d4b24b2800000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "4707438", gasUsed: "319069", confirmations: "3354974"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "3100000000000000000"}, {type: "uint256", name: "_minReturn", value: "1048429910255881000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]], "3100000000000000000", "1048429910255881000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1507873048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "3100000000000000000"}, {name: "_return", type: "uint256", value: "161112661947395941726"}, {name: "_currentPriceN", type: "uint256", value: "1986404044556613512944000000"}, {name: "_currentPriceD", type: "uint256", value: "103357865026864915623374000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "161112661947395941726"}, {name: "_return", type: "uint256", value: "146345644183292890531"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "93921048711582014859040000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "301116081431119144" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"9954524910303375\" )", async function( ) {
		const txOriginal = {blockNumber: "4362900", timeStamp: "1507919425", hash: "0xf31a8f0352b6e8f40feae65b3eac164ffdfb583e871b087909a51ea853504333", nonce: "23", blockHash: "0xeff4fa0f71e44ca9ed4eb5de779b6a6f25cfc9e42fccf94bbfe0ad65ea320930", transactionIndex: "33", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "3357000000000000", gas: "485964", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f800000000000000000000000000000000000000000000000000235d96712fb88f", contractAddress: "", cumulativeGasUsed: "2063472", gasUsed: "340889", confirmations: "3353399"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "3357000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "9954524910303375"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "9954524910303375", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1507919425 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "472046637247059714"}, {name: "_return", type: "uint256", value: "519877940648534914"}, {name: "_currentPriceN", type: "uint256", value: "93775175114035969028223000000"}, {name: "_currentPriceD", type: "uint256", value: "103277568634861541919968000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "519877940648534914"}, {name: "_return", type: "uint256", value: "9999134933617838"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1986404044556613512944000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4362961", timeStamp: "1507921061", hash: "0x79ed0bcc3f1d755ad678cef9089b3df8e495fe2dc9f7bacb474e83db3a495ba8", nonce: "15", blockHash: "0x9e2191d59b254f08aac63b20e489b29a01cbfd257c3d30c737fa92e7d936e351", transactionIndex: "56", from: "0x4c92a4c058f4b8699f2e18e3d83e8bd46ec37c32", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1513250", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000377edba02430b000000000000000000000000000000000000000000000000000128767a246536d4b000000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "3900014", gasUsed: "1513250", confirmations: "3353338"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "63982000000000000000"}, {type: "uint256", name: "_minReturn", value: "21362396179214030000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "55703339554401" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4362967", timeStamp: "1507921331", hash: "0x006b72ecf474db75fff06164a9726fa78a3d3131df59a4de0509e93e97c846bd", nonce: "16", blockHash: "0xe727cce0b28162613422e34b8e1e8b1e38865b247edc40c6cf44b4e4aeacd86d", transactionIndex: "57", from: "0x4c92a4c058f4b8699f2e18e3d83e8bd46ec37c32", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "70000", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000036a4cf636319c000000000000000000000000000000000000000000000000000123e9a4c49e34966000000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "2101993", gasUsed: "70000", confirmations: "3353332"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "63000000000000000000"}, {type: "uint256", name: "_minReturn", value: "21034524698985404000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "55703339554401" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4362974", timeStamp: "1507921673", hash: "0x61ab55ffb86f4eb9f150087d752fbfa100a11619d5cb503d31acf435db366629", nonce: "17", blockHash: "0x0ffacf6e5d526b9f5a4bf9d338de6e0dee9f4f6dfad75e1035f6f76d2f637624", transactionIndex: "135", from: "0x4c92a4c058f4b8699f2e18e3d83e8bd46ec37c32", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "907950", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000377edba02430b000000000000000000000000000000000000000000000000009dd6e59ae19e79700000000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "6343593", gasUsed: "907950", confirmations: "3353325"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "63982000000000000000"}, {type: "uint256", name: "_minReturn", value: "2911623772760000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "55703339554401" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"28855000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4362982", timeStamp: "1507922082", hash: "0xbf6fdb28b9155ebfc15bf315a5ee11c6246569849eaf821b14535b1af0f5bb7b", nonce: "8", blockHash: "0xe8585609d3b9e4656257ef666704df2a04655a83adadc08a0d9c97644a8658b5", transactionIndex: "86", from: "0xef1efd77bfce6a1d823baab65a6ed4144128a04f", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "10000000000000", gas: "499102", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f800000000000000000000000000000000000000000000000000001a3e54066600", contractAddress: "", cumulativeGasUsed: "3402307", gasUsed: "353623", confirmations: "3353317"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "28855000000000"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "28855000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1507922082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1406157221504269"}, {name: "_return", type: "uint256", value: "1548641530571501"}, {name: "_currentPriceN", type: "uint256", value: "93775176520193190532492000000"}, {name: "_currentPriceD", type: "uint256", value: "103277309470211982938261500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1548641530571501"}, {name: "_return", type: "uint256", value: "29785945422748"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1986394045421679895106000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "104936640520067227" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4362989", timeStamp: "1507922235", hash: "0x7026d4c1a660e5f6154d9c2ff23d4224a44958706845e2f28b5b19c28374ea24", nonce: "18", blockHash: "0x39b28052e87839cd6781d055ab899751a3c2322062871bfed6749152a213779d", transactionIndex: "123", from: "0x4c92a4c058f4b8699f2e18e3d83e8bd46ec37c32", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "52090", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000002b5e3af16b1880000000000000000000000000000000000000000000000000000e020536f028f07d000000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "3586296", gasUsed: "52090", confirmations: "3353310"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "50000000000000000000"}, {type: "uint256", name: "_minReturn", value: "16150000000000002000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "55703339554401" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"29643760395940090\" )", async function( ) {
		const txOriginal = {blockNumber: "4362989", timeStamp: "1507922235", hash: "0x471e1eef7742ad72aa0ba8b5963ea6c25881ee43a238df3fa85a08fd74dce867", nonce: "27", blockHash: "0x39b28052e87839cd6781d055ab899751a3c2322062871bfed6749152a213779d", transactionIndex: "134", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "10000000000000000", gas: "486378", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x7758c4f8000000000000000000000000000000000000000000000000006950d7d034f0fa", contractAddress: "", cumulativeGasUsed: "4137679", gasUsed: "341303", confirmations: "3353310"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "29643760395940090"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "29643760395940090", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1507922235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1406367018739279204"}, {name: "_return", type: "uint256", value: "1548843556713574046"}, {name: "_currentPriceN", type: "uint256", value: "93776582887211929811696000000"}, {name: "_currentPriceD", type: "uint256", value: "103278083117669574439534000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "1548843556713574046"}, {name: "_return", type: "uint256", value: "29789495936384065"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "1986394015635734472358000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4362997", timeStamp: "1507922372", hash: "0x9b529aa70238019c38448c05ab3bd82f41f37187792e07f3113096c4796465f6", nonce: "19", blockHash: "0xf72ebd1b2c856b9037da411f771139141f53eae48e91216e2633cdb153f06901", transactionIndex: "44", from: "0x4c92a4c058f4b8699f2e18e3d83e8bd46ec37c32", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1513000", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000002b5e3af16b1880000000000000000000000000000000000000000000000000000e20b7e6e69ad540000000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "3745789", gasUsed: "1513000", confirmations: "3353302"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "50000000000000000000"}, {type: "uint256", name: "_minReturn", value: "16288251490000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "55703339554401" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363031", timeStamp: "1507923558", hash: "0xcf3eeb5275daadf9bc0670da1a94b146446f2d7594bda06e7aca79da17e8a656", nonce: "29", blockHash: "0x4b29a5ee6547474e1dbe67e19cc891d7c54d91ca7e17b4f2fed84ed5f88caba7", transactionIndex: "19", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "907800", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000684d8ae77d91a0000000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "1043473", gasUsed: "209567", confirmations: "3353268"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000"}, {type: "uint256", name: "_minReturn", value: "469738505000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6]], "10000000000000000", "469738505000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1507923558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_return", type: "uint256", value: "519928104961023963"}, {name: "_currentPriceN", type: "uint256", value: "1986374226139798088293000000"}, {name: "_currentPriceD", type: "uint256", value: "103277568659943698164492500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "519928104961023963"}, {name: "_return", type: "uint256", value: "472096896729042517"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "93776582887211929811696000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363034", timeStamp: "1507923586", hash: "0xde2cc47aa0437e3d189e6590aa494bd8dfe11d5331cdf767a743a18fcb68c4ae", nonce: "31", blockHash: "0xf8705e61da7278d70518c1d17f9cfd4fc422f03374cc9bbaa50e399bc80f6654", transactionIndex: "9", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1513000", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000002386f26fc10000000000000000000000000000000000000000000000000000000bdd00bded480000000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "668451", gasUsed: "318349", confirmations: "3353265"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "10000000000000000"}, {type: "uint256", name: "_minReturn", value: "3339220000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]], "10000000000000000", "3339220000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1507923586 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_return", type: "uint256", value: "519925487504422382"}, {name: "_currentPriceN", type: "uint256", value: "1986384226139798088293000000"}, {name: "_currentPriceD", type: "uint256", value: "103277568658634969863702000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "519925487504422382"}, {name: "_return", type: "uint256", value: "472092143423877646"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "93776110790315200769179000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363037", timeStamp: "1507923660", hash: "0xdb2f4399d934576413b9414f6513b5defca02f91d37a4ad37bcfa7d58a04152a", nonce: "21", blockHash: "0xbaf57d8176e44f1a5f051a2fdc4550210b7d71817b74bfe039b3172f29d899ac", transactionIndex: "60", from: "0x4c92a4c058f4b8699f2e18e3d83e8bd46ec37c32", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "363830", gasPrice: "22000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000377edba02430b00000000000000000000000000000000000000000000000000011f2c60ef968f146000000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "2537379", gasUsed: "363830", confirmations: "3353262"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "63982000000000000000"}, {type: "uint256", name: "_minReturn", value: "20693020969999996000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "55703339554401" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363501", timeStamp: "1507937944", hash: "0x3baab738a45498a25e93c4e4b4f18987afb57e621de30813c9ca9600a6dbfd85", nonce: "1", blockHash: "0xad93ad6d749a70041f9843273465d0f189b2258cb65c679cdefc38c6c9f61e60", transactionIndex: "51", from: "0xb0314ff0faf9d82f04063b2540ac1bc617973235", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "910236", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000019562ef3011ad66c6000000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "3849350", gasUsed: "226483", confirmations: "3352798"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "467378769965000060000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6]], "10000000000000000000", "467378769965000060000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1507937944 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "10000000000000000000"}, {name: "_return", type: "uint256", value: "516675596790526100282"}, {name: "_currentPriceN", type: "uint256", value: "1996384226139798088293000000"}, {name: "_currentPriceD", type: "uint256", value: "103535646494286480702652000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "516675596790526100282"}, {name: "_return", type: "uint256", value: "467386243753482372894"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "93775638698171776891533000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363508", timeStamp: "1507938206", hash: "0x02cde5fb90cfa4997a98fce6c131a2ae428ef7ee51ea790f9360695aa79c0bc3", nonce: "3", blockHash: "0x7c0fbf84c69a1f0022d6b285a93bbf1db0eab6a370983c01ff581ea16f66afb2", transactionIndex: "46", from: "0xb0314ff0faf9d82f04063b2540ac1bc617973235", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "1513000", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000002ed2696fdb9230000000000000000000000000000000000000000000000000000f19dec9d5720e60000000000000000000000000000000000000000000000000000000000000000050000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "4463444", gasUsed: "1513000", confirmations: "3352791"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6],addressList[6],addressList[8]]}, {type: "uint256", name: "_amount", value: "53982000000000000000"}, {type: "uint256", name: "_minReturn", value: "17410331895000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363566", timeStamp: "1507940403", hash: "0x9eabb3dd4c186408d4642c14b3f72ee3af2d3fb796910d2e2b5c1e8195424887", nonce: "5", blockHash: "0xc86f38a7d6c23697fddd83891f03d2bc4c9b198ca226dd247c7b4d87aa5c8c32", transactionIndex: "99", from: "0xb0314ff0faf9d82f04063b2540ac1bc617973235", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "907800", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000002ed2696fdb923000000000000000000000000000000000000000000000000008481f537e94ca335e000000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "5951413", gasUsed: "907800", confirmations: "3352733"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "53982000000000000000"}, {type: "uint256", name: "_minReturn", value: "2444334670205000300000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363576", timeStamp: "1507940793", hash: "0x6ea200ba7c08b81cfe7a454f4c34d149b9e95711cc67b71ed7f71ffc1a578903", nonce: "6", blockHash: "0x20397d9514242a5401032269e84b0dcd334e6548ac841c5e56aec3b0414caadf", transactionIndex: "65", from: "0xb0314ff0faf9d82f04063b2540ac1bc617973235", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "907800", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000001915b067168daa6b5000000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "3795982", gasUsed: "227941", confirmations: "3352723"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "462731464260000050000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6]], "10000000000000000000", "462731464260000050000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1507940793 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "10000000000000000000"}, {name: "_return", type: "uint256", value: "514103635741490263403"}, {name: "_currentPriceN", type: "uint256", value: "2006384226139798088293000000"}, {name: "_currentPriceD", type: "uint256", value: "103534360513761962784212500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "514103635741490263403"}, {name: "_return", type: "uint256", value: "462750359007961873254"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "93308252454418294518639000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363581", timeStamp: "1507940870", hash: "0x4fde981e2dff02c3712afc0f34df60433e46bd87741093cbe45ae2d5b9fdca37", nonce: "7", blockHash: "0x814cdf15c6b3b302d298ae8062da4da1c676c28208794a06fc0c22e7e1074006", transactionIndex: "68", from: "0xb0314ff0faf9d82f04063b2540ac1bc617973235", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "909888", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000001158e460913d000000000000000000000000000000000000000000000000000316d8cd96f2363b40000000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "3617515", gasUsed: "909888", confirmations: "3352718"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "20000000000000000000"}, {type: "uint256", name: "_minReturn", value: "911784382930000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363584", timeStamp: "1507941031", hash: "0x663a3bf0dcab7b1fda99df7633316c6ad710e1c6879ecb2110e0484ea50daa74", nonce: "8", blockHash: "0x176dd003b199f63637f26c77674965d6ad7f568f27168ddee99c6e1d9d7556f9", transactionIndex: "79", from: "0xb0314ff0faf9d82f04063b2540ac1bc617973235", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "909888", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000018d626e44dc9323eb000000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "4281432", gasUsed: "229615", confirmations: "3352715"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "458153129964999950000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[7],addressList[4],addressList[6]], "10000000000000000000", "458153129964999950000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1507941031 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x6810e776880c02933d47db1b9fc05908e5386b96"}, {name: "_toToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "10000000000000000000"}, {name: "_return", type: "uint256", value: "511557153844522110487"}, {name: "_currentPriceN", type: "uint256", value: "2016384226139798088293000000"}, {name: "_currentPriceD", type: "uint256", value: "103533087272813478707754500000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "Change", events: [{name: "_fromToken", type: "address", value: "0xd7eb9db184da9f099b84e2f86b1da1fe6b305b3d"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}, {name: "_amount", type: "uint256", value: "511557153844522110487"}, {name: "_return", type: "uint256", value: "458183107121191242430"}, {name: "_currentPriceN", type: "uint256", value: "103277308695891217652511000000"}, {name: "_currentPriceD", type: "uint256", value: "92845502095410332645385000000"}], address: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[7],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4363586", timeStamp: "1507941112", hash: "0x58eb29ec1e69efe9c4474328b8e5efb7e96cedf71ee2c3f2d5b34b24f52c46be", nonce: "9", blockHash: "0x2465e02f72213a2480e2d0b7a8dd4c5361863bc2abfdbee7e54cfd3296d4a8b7", transactionIndex: "95", from: "0xb0314ff0faf9d82f04063b2540ac1bc617973235", to: "0xf31619a15518dce0613a514e6672d1f84f6e7fe7", value: "0", gas: "909888", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000018d626e44dc9323eb000000000000000000000000000000000000000000000000000000000000000030000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "6302991", gasUsed: "909888", confirmations: "3352713"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[7],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "458153129964999950000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
