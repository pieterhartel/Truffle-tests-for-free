const BancorChanger = artifacts.require( "./BancorChanger.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BancorChanger" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xb72A0Fa1E537c956DFca72711c468EfD81270468", "0x009BB5e9fCF28E5E601B7D0e9e821da6365d0a9c", "0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C", "0x8b0c11E0DF925387DE1ce92504Fe0e4af23Af6F2", "0xc0829421C1d260BD3cB3E0F06cfE2D52db2cE315", "0x51A3ac2399c89FFA893B0f627c740C05193875A6", "0x013419614FF1d412f7D54E345d2B12832EAdaa3a", "0x8DC6a22d868c08C727BE2aCAeaF116576afFA30a", "0x7ac34681F6aAeb691E150c43ee494177C0e2c183", "0x1bd39650266B94Fde58a72C0e2BB17D85708D3Af", "0xaf6787931E7369113b667C2cB09449DE88951144", "0xC5d7345a18974aB0DA7fa54ef0646b8b528fc980", "0x3880F7473F18Ba81cB330d1fED943dA583265fb2", "0xD8C79b6D4BD49B867F64163d2B109F3cA170d0bC", "0x9345c50fb2158d40A09723a7B414DCa763Bf8543", "0xcAb007003d241d7e7e8c1092AB93911B669eBd0c", "0xD76b5c2A23ef78368d8E34288B5b65D616B746aE", "0x00156cd84776616BCc0bc5F78867cC2b67f8a285", "0x3B0899f81f2Dc9d7D25c7251E979eF4E89e3C75B", "0x00a83e95a30765e4938Ad86370B25F941a3caa86", "0xe37aa3cc875b568091aD38D9554eB83cb5E4Ba2f", "0x4A834adA4C8134686e0958d22B3c9BCFbe75D816", "0x411f7A41DDcb3494D1592b84ebB692017428ea19"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "changeFee", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_reserveToken", type: "address"}], name: "getReserveBalance", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_fromToken", type: "address"}, {name: "_toToken", type: "address"}, {name: "_amount", type: "uint256"}], name: "getReturn", outputs: [{name: "amount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "changerType", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newManager", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "manager", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_amount", type: "uint256"}], name: "getChangeFeeAmount", outputs: [{name: "feeAmount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "formula", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenIndex", type: "uint16"}], name: "changeableToken", outputs: [{name: "tokenAddress", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "version", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "changeableTokenCount", outputs: [{name: "count", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_reserveToken", type: "address"}, {name: "_sellAmount", type: "uint256"}], name: "getSaleReturn", outputs: [{name: "amount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "changingEnabled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getQuickBuyPathLength", outputs: [{name: "length", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "reserveTokenCount", outputs: [{name: "count", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_reserveToken", type: "address"}, {name: "_depositAmount", type: "uint256"}], name: "getPurchaseReturn", outputs: [{name: "amount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "hasQuickBuyEtherToken", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getQuickBuyEtherToken", outputs: [{name: "etherToken", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "reserveTokens", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "reserves", outputs: [{name: "virtualBalance", type: "uint256"}, {name: "ratio", type: "uint32"}, {name: "isVirtualBalanceEnabled", type: "bool"}, {name: "isPurchaseEnabled", type: "bool"}, {name: "isSet", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxChangeFee", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "quickBuyPath", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prevManager", type: "address"}, {indexed: false, name: "_newManager", type: "address"}], name: "ManagerUpdate", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prevOwner", type: "address"}, {indexed: false, name: "_newOwner", type: "address"}], name: "OwnerUpdate", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Change(address,address,address,uint256,uint256,uint256,uint256)", "ManagerUpdate(address,address)", "OwnerUpdate(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x7a222e1014ca7136a33e1c036d11f04c2fb08a3ecb33c8e02760a7e038580f90", "0xbe4cc281795971a471c980e842627a7f1ea3892ddfce8c5b6357cd2611c19732", "0x343765429aea5a34b3ff6a3785a98a5abb2597aca87bfbb58632c173d585373a"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4259145 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4265276 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}, {type: "address", name: "_formula", value: 5}, {type: "uint32", name: "_maxChangeFee", value: "0"}, {type: "address", name: "_reserveToken", value: 6}, {type: "uint32", name: "_reserveRatio", value: "100000"}], name: "BancorChanger", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "changeFee", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changeFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getReserveBalance", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getReserveBalance(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_toToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_amount", value: random.range( maxRandom )}], name: "getReturn", outputs: [{name: "amount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getReturn(address,address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "changerType", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changerType()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newManager", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newManager()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "manager", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "manager()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_amount", value: random.range( maxRandom )}], name: "getChangeFeeAmount", outputs: [{name: "feeAmount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getChangeFeeAmount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "formula", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "formula()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "_tokenIndex", value: random.range( maxRandom )}], name: "changeableToken", outputs: [{name: "tokenAddress", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changeableToken(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "version", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "version()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "changeableTokenCount", outputs: [{name: "count", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changeableTokenCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_sellAmount", value: random.range( maxRandom )}], name: "getSaleReturn", outputs: [{name: "amount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getSaleReturn(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "changingEnabled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "changingEnabled()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getQuickBuyPathLength", outputs: [{name: "length", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getQuickBuyPathLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "reserveTokenCount", outputs: [{name: "count", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserveTokenCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_depositAmount", value: random.range( maxRandom )}], name: "getPurchaseReturn", outputs: [{name: "amount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPurchaseReturn(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "hasQuickBuyEtherToken", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasQuickBuyEtherToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getQuickBuyEtherToken", outputs: [{name: "etherToken", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getQuickBuyEtherToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "reserveTokens", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserveTokens(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "reserves", outputs: [{name: "virtualBalance", type: "uint256"}, {name: "ratio", type: "uint32"}, {name: "isVirtualBalanceEnabled", type: "bool"}, {name: "isPurchaseEnabled", type: "bool"}, {name: "isSet", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserves(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxChangeFee", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxChangeFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "quickBuyPath", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "quickBuyPath(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BancorChanger", function( accounts ) {

	it( "TEST: BancorChanger( addressList[4], addressList[5], \"0\", a... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4259145", timeStamp: "1505055894", hash: "0x8bc6729f977ffd31c542e5d7e970dbf0a3633d2a1ed0ba051a613ab2cedd2e86", nonce: "315", blockHash: "0x146d6d941633001c071abc461963e50eaa65e5c4ec1f23364a3d77eddb7baf1f", transactionIndex: "55", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: 0, value: "0", gas: "4472778", gasPrice: "21834513098", isError: "0", txreceipt_status: "", input: "0x8e5085270000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000008b0c11e0df925387de1ce92504fe0e4af23af6f20000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000000000000000000186a0", contractAddress: "0xb72a0fa1e537c956dfca72711c468efd81270468", cumulativeGasUsed: "5444870", gasUsed: "3727315", confirmations: "3444651"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "address", name: "_formula", value: addressList[5]}, {type: "uint32", name: "_maxChangeFee", value: "0"}, {type: "address", name: "_reserveToken", value: addressList[6]}, {type: "uint32", name: "_reserveRatio", value: "100000"}], name: "BancorChanger", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BancorChanger.new( addressList[4], addressList[5], "0", addressList[6], "100000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1505055894 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BancorChanger.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setQuickBuyPath( [addressList[6],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4259181", timeStamp: "1505056871", hash: "0x9dd074b3ccf7ec6b5f4ae48e621420018511bd5674b4eb23cae144be4a0fc43a", nonce: "316", blockHash: "0xa7c137a36f4c786ddd37ef0bca13fb0304df0975be85acf73d8ba7533911cb13", transactionIndex: "29", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "72589", gasPrice: "21834513098", isError: "1", txreceipt_status: "", input: "0xd395ee0f00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000003000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "871956", gasUsed: "72589", confirmations: "3444615"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[6],addressList[4],addressList[4]]}], name: "setQuickBuyPath", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setQuickBuyPath( [addressList[6],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4259187", timeStamp: "1505057007", hash: "0xc0bfd206568c7375bebcb9157966a8f81441d70c3ab679c3dc859a1b19777d20", nonce: "317", blockHash: "0x5356712dc41242db9475a4f8569098e6941c45f9dae9d659f14e97242d6954cd", transactionIndex: "55", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "191197", gasPrice: "21834513098", isError: "0", txreceipt_status: "", input: "0xd395ee0f00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000003000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "3363273", gasUsed: "109331", confirmations: "3444609"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[6],addressList[4],addressList[4]]}], name: "setQuickBuyPath", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setQuickBuyPath(address[])" ]( [addressList[6],addressList[4],addressList[4]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1505057007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: updateReserve( addressList[6], \"100000\", true, \"6014... )", async function( ) {
		const txOriginal = {blockNumber: "4261583", timeStamp: "1505115262", hash: "0x8bc05d830b5e006c92848c3b80901982a73da8965ff4886dde188a85da8b8fed", nonce: "322", blockHash: "0x89509fe7b9852b9900881c79eadf94cffbfee26c823efe773b50828690f9efed", transactionIndex: "166", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "68578", gasPrice: "21767967327", isError: "0", txreceipt_status: "", input: "0xab5841f2000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000000000000000000186a00000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000cbc36342e2fc550276e", contractAddress: "", cumulativeGasUsed: "5885346", gasUsed: "57148", confirmations: "3442213"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[6]}, {type: "uint32", name: "_ratio", value: "100000"}, {type: "bool", name: "_enableVirtualBalance", value: true}, {type: "uint256", name: "_virtualBalance", value: "60140291477852684035950"}], name: "updateReserve", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateReserve(address,uint32,bool,uint256)" ]( addressList[6], "100000", true, "60140291477852684035950", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1505115262 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: acceptTokenOwnership(  )", async function( ) {
		const txOriginal = {blockNumber: "4261639", timeStamp: "1505116614", hash: "0x01638233d1520941f2d742cd5266d19e2fcf60291038ce4a1ec591b9e03c93a7", nonce: "330", blockHash: "0x19144c9ab25893005ef6fa9fa93fc0fe81bb602fed01f7f9bcf4166256b45a19", transactionIndex: "125", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "144347", gasPrice: "21767967327", isError: "0", txreceipt_status: "", input: "0x38a5e016", contractAddress: "", cumulativeGasUsed: "3261801", gasUsed: "21786", confirmations: "3442157"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "acceptTokenOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptTokenOwnership()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1505116614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4261649", timeStamp: "1505116768", hash: "0x13ebacb37ae89f89f662405a68709e560b8cdfdb6521ef034d7667b4947c11be", nonce: "331", blockHash: "0xe1c06b1e5bdb3671eb3713454026d81b592021f1d6746880105067de0357758d", transactionIndex: "121", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "100000000000000000", gas: "501188", gasPrice: "21767967327", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "5626934", gasUsed: "240866", confirmations: "3442147"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1505116768 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xb72a0fa1e537c956dfca72711c468efd81270468"}, {name: "_amount", type: "uint256", value: "100000000000000000"}, {name: "_return", type: "uint256", value: "12828428392318817093"}, {name: "_currentPriceN", type: "uint256", value: "60140391477852684035950000000"}, {name: "_currentPriceD", type: "uint256", value: "7715061282802003622776927300000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4261667", timeStamp: "1505117159", hash: "0xa215851df43f477fe6136fdf1bd3f0c19982f3e7f0be94453acdc3bf66167b1b", nonce: "333", blockHash: "0x82f217c7fc8287c3aff5fcad10d3a788a3f4c334939b8fb9f8068692573970d9", transactionIndex: "53", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "93912", gasPrice: "21767967327", isError: "0", txreceipt_status: "", input: "0xf2fde38b00000000000000000000000051a3ac2399c89ffa893b0f627c740c05193875a6", contractAddress: "", cumulativeGasUsed: "1419086", gasUsed: "44927", confirmations: "3442129"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newOwner", value: addressList[7]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1505117159 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[6], addressList[4], \"500000... )", async function( ) {
		const txOriginal = {blockNumber: "4261765", timeStamp: "1505119598", hash: "0x540f7ac9a0fac820264640ac96b6de56bf22a7909cbff22f096a8b64b0750e74", nonce: "20", blockHash: "0x0c05decb299e76a8f7e8f6b1d8513d3651410a41bd129cb3da5780617791c020", transactionIndex: "81", from: "0x013419614ff1d412f7d54e345d2b12832eadaa3a", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "25000000000", isError: "1", txreceipt_status: "", input: "0x5e5144eb000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c00000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2629570", gasUsed: "150000", confirmations: "3442031"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[6]}, {type: "address", name: "_toToken", value: addressList[4]}, {type: "uint256", name: "_amount", value: "50000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "28160846999999992" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[6], addressList[4], \"500000... )", async function( ) {
		const txOriginal = {blockNumber: "4261804", timeStamp: "1505120859", hash: "0x507c655b4ece85c5df80882f468e6f1444054142a3260b56b895a6ed20bf83d9", nonce: "23", blockHash: "0xd7d4c70ed067c46c6c4c9c357f73dd1d278c8f4aaaafed90994a490cd1260852", transactionIndex: "258", from: "0x013419614ff1d412f7d54e345d2b12832eadaa3a", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "132286", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c00000000000000000000000000000000000000000000000000b1a2bc2ec500000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6420024", gasUsed: "102286", confirmations: "3441992"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[6]}, {type: "address", name: "_toToken", value: addressList[4]}, {type: "uint256", name: "_amount", value: "50000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[6], addressList[4], "50000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1505120859 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0x013419614ff1d412f7d54e345d2b12832eadaa3a"}, {name: "_amount", type: "uint256", value: "50000000000000000"}, {name: "_return", type: "uint256", value: "6414206997015013024"}, {name: "_currentPriceN", type: "uint256", value: "60140441477852684035950000000"}, {name: "_currentPriceD", type: "uint256", value: "7715061924222703324278229700000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "28160846999999992" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4262012", timeStamp: "1505125796", hash: "0x81fc626d4447b8accc628b0f1bdcc45cf966250b905b8e265bba1f2ba53442a1", nonce: "1", blockHash: "0xca021b4ce7076f6bcea4241652fc1900ec4d20134efc3a96af1e39e7c5c427b5", transactionIndex: "109", from: "0x8dc6a22d868c08c727be2acaeaf116576affa30a", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "120000000000000000", gas: "316344", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "4622194", gasUsed: "255982", confirmations: "3441784"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "120000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1505125796 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xb72a0fa1e537c956dfca72711c468efd81270468"}, {name: "_amount", type: "uint256", value: "120000000000000000"}, {name: "_return", type: "uint256", value: "15394077211218952819"}, {name: "_currentPriceN", type: "uint256", value: "60140561477852684035950000000"}, {name: "_currentPriceD", type: "uint256", value: "7715063463630424446173511600000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "213290000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"788030... )", async function( ) {
		const txOriginal = {blockNumber: "4262128", timeStamp: "1505129136", hash: "0x6a8fab3dfa255592a9feba2bb1eb7ec4f24b0cd4761bca8ea42d34d71ecbfe8c", nonce: "469", blockHash: "0xa5fe58ab8c4f59dbe1dde03cb87d3f5c9bbd91ebdba498457e7632f79457f1f3", transactionIndex: "17", from: "0x7ac34681f6aaeb691e150c43ee494177c0e2c183", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "133525", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000002ab81cf5d68f1300000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "660246", gasUsed: "118525", confirmations: "3441668"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "788030000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "788030000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1505129136 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x7ac34681f6aaeb691e150c43ee494177c0e2c183"}, {name: "_amount", type: "uint256", value: "788030000000000000000"}, {name: "_return", type: "uint256", value: "6142579202685140614"}, {name: "_currentPriceN", type: "uint256", value: "7714984660630424446173511600000"}, {name: "_currentPriceD", type: "uint256", value: "60134418898649998895336000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "300652595082717782242" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"280000... )", async function( ) {
		const txOriginal = {blockNumber: "4262235", timeStamp: "1505131367", hash: "0x1437838139a2f261cef08af4fd0219be53761d6fd4686f9a30f293c528d6592b", nonce: "187", blockHash: "0x9eeee8480db0df29bc4531760341fc47119ee0a2d2021fe0d949e8108090e099", transactionIndex: "44", from: "0x1bd39650266b94fde58a72c0e2bb17d85708d3af", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "133575", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000097c9ce4cf6d5c000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2002158", gasUsed: "133575", confirmations: "3441561"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "2800000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "2800000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1505131367 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x1bd39650266b94fde58a72c0e2bb17d85708d3af"}, {name: "_amount", type: "uint256", value: "2800000000000000000000"}, {name: "_return", type: "uint256", value: "21821025445948507679"}, {name: "_currentPriceN", type: "uint256", value: "7714704660630424446173511600000"}, {name: "_currentPriceD", type: "uint256", value: "60112597873204050387657000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "50161986844508189" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: transferManagement( addressList[3] )", async function( ) {
		const txOriginal = {blockNumber: "4262250", timeStamp: "1505131729", hash: "0xa9b6368434a0b2096d2ce9ba3fb79e2f64d2971f1c80625c94dc40189e534e6d", nonce: "336", blockHash: "0x266a40717ad8fbc04234c9714e7ac92c2703aa38f710941369e4e5c8a2a06a44", transactionIndex: "58", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "134271", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0xe4edf852000000000000000000000000009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", contractAddress: "", cumulativeGasUsed: "1873718", gasUsed: "134271", confirmations: "3441546"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newManager", value: addressList[3]}], name: "transferManagement", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transferManagement( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4262257", timeStamp: "1505131863", hash: "0x7fccd09e3560cdfbde36197b5d9e043ca821f5c9c5b9139142a19af9059343d8", nonce: "337", blockHash: "0x1eae77088456271b34e1c4f8a808842ba8fbf27ecfd1adcc2b12781d1b81d74a", transactionIndex: "74", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "153807", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xe4edf85200000000000000000000000051a3ac2399c89ffa893b0f627c740c05193875a6", contractAddress: "", cumulativeGasUsed: "3217459", gasUsed: "44839", confirmations: "3441539"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newManager", value: addressList[7]}], name: "transferManagement", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferManagement(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1505131863 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"200933... )", async function( ) {
		const txOriginal = {blockNumber: "4262325", timeStamp: "1505133091", hash: "0xb9d3a065c19295bcde91cb94a80c171eee1c867f540d1b290e7d9986f0af556c", nonce: "701", blockHash: "0x4efd78374ca5c543af1ecafc718266467ec6aa3c3aba1b06c32d00b5fc678d46", transactionIndex: "136", from: "0xaf6787931e7369113b667c2cb09449de88951144", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000006ced1d0af9d0200c000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4943090", gasUsed: "118175", confirmations: "3441471"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "2009334184590000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "2009334184590000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1505133091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xaf6787931e7369113b667c2cb09449de88951144"}, {name: "_amount", type: "uint256", value: "2009334184590000000000"}, {name: "_return", type: "uint256", value: "15654797868973364444"}, {name: "_currentPriceN", type: "uint256", value: "7714503727211965446173511600000"}, {name: "_currentPriceD", type: "uint256", value: "60096943075335077023213000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "276345833039875297" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[2], addressList[6], \"500000... )", async function( ) {
		const txOriginal = {blockNumber: "4262448", timeStamp: "1505136327", hash: "0xaf75749a0569005f86e174e9b80e0d13b86f2b8e6a88c85d158a868b95c05bbf", nonce: "104", blockHash: "0xfcf50f9f24b4b32fc6016025ddc08e2fcd464aa81d0c813d4ff3588d59aca9c3", transactionIndex: "8", from: "0xc5d7345a18974ab0da7fa54ef0646b8b528fc980", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "58000000000", isError: "1", txreceipt_status: "", input: "0x5e5144eb000000000000000000000000b72a0fa1e537c956dfca72711c468efd81270468000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "482886", gasUsed: "150000", confirmations: "3441348"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[2]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "5000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "2205708818638671" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[14]], \"10\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4262515", timeStamp: "1505137935", hash: "0xda5d0417f7badcec2f76dc18020a0dbf387a020f667931698c60d44137e87819", nonce: "15", blockHash: "0x45fca0b0b731c06165e5c1b2e419c17a5e93aff2bd6ee9d9b556287f9c7683f8", transactionIndex: "105", from: "0x3880f7473f18ba81cb330d1fed943da583265fb2", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000010000000000000000000000003880f7473f18ba81cb330d1fed943da583265fb2", contractAddress: "", cumulativeGasUsed: "4399598", gasUsed: "150000", confirmations: "3441281"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[14]]}, {type: "uint256", name: "_amount", value: "10"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1033034292857374001" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"10\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4262535", timeStamp: "1505138414", hash: "0x129503b6de84c7726a49d8b2c5785d02108630cf00389a0fbf414b7386be9e2a", nonce: "16", blockHash: "0x2fcdc7356c90986d40b93755b818f46582f0b919f73b7f1e9e4b4aea152e56c9", transactionIndex: "90", from: "0x3880f7473f18ba81cb330d1fed943da583265fb2", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3217710", gasUsed: "150000", confirmations: "3441261"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "10"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1033034292857374001" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"15\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4262537", timeStamp: "1505138482", hash: "0xeb290ca1999800fa1a4327f3fc2e1d12513ddd5fd0ae6abcf170fb1225f89ba6", nonce: "17", blockHash: "0xd32677d9b59a970ec1d16bd55711d44de7333ce46b889265a86f7021e509a1d8", transactionIndex: "110", from: "0x3880f7473f18ba81cb330d1fed943da583265fb2", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4322433", gasUsed: "150000", confirmations: "3441259"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "15"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1033034292857374001" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4262593", timeStamp: "1505139552", hash: "0x30af914eedd555270849e3f0796bb5bf548108cbf72f31a72467b103e3cd5250", nonce: "1", blockHash: "0x88095f79052d779c214d684f7b898d0aeeca4ea22e4788c4f22cdbfd8cce22a6", transactionIndex: "23", from: "0xd8c79b6d4bd49b867f64163d2b109f3ca170d0bc", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "50000000000000000", gas: "315648", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "2003080", gasUsed: "255286", confirmations: "3441203"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1505139552 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xb72a0fa1e537c956dfca72711c468efd81270468"}, {name: "_amount", type: "uint256", value: "50000000000000000"}, {name: "_return", type: "uint256", value: "6418380406862491544"}, {name: "_currentPriceN", type: "uint256", value: "60096993075335077023213000000"}, {name: "_currentPriceD", type: "uint256", value: "7714504369050006132422666000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "4472886708911465" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[6], addressList[2], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "4262595", timeStamp: "1505139608", hash: "0x47c66c34cf534e6902a93832917dbb33b017b49313a410a4d356af1b77e15087", nonce: "20", blockHash: "0x02b75f344546163475d5eacff036f1197b2422f3841c30f5a4bcde43df444366", transactionIndex: "85", from: "0x3880f7473f18ba81cb330d1fed943da583265fb2", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "46054", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x5e5144eb000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000b72a0fa1e537c956dfca72711c468efd81270468000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3557078", gasUsed: "46054", confirmations: "3441201"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[6]}, {type: "address", name: "_toToken", value: addressList[2]}, {type: "uint256", name: "_amount", value: "10000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1033034292857374001" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[6], addressList[2], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "4262602", timeStamp: "1505139725", hash: "0xb4648339414eaa5df5a44dc0ad4be857d8c94c9d39fe79eb611a68e4bb86852b", nonce: "21", blockHash: "0x0f13e2fa2bdc850b0c0c367865844b854963df375fe2892d64aa8bde6c5072d3", transactionIndex: "64", from: "0x3880f7473f18ba81cb330d1fed943da583265fb2", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x5e5144eb000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000b72a0fa1e537c956dfca72711c468efd81270468000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2204160", gasUsed: "150000", confirmations: "3441194"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[6]}, {type: "address", name: "_toToken", value: addressList[2]}, {type: "uint256", name: "_amount", value: "10000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1033034292857374001" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "4262611", timeStamp: "1505139947", hash: "0xec0d6d462f19847b495e7d71218f8c7adde78de9580ec25888b2493537cbe205", nonce: "340", blockHash: "0xb182f210eb1fa11302968ee289436e2ff0f27a895f5afb1c5c8bad030eb0dfe7", transactionIndex: "95", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "159796", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2802644", gasUsed: "133163", confirmations: "3441185"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "10000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1505139947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c"}, {name: "_amount", type: "uint256", value: "10000000000000000000"}, {name: "_return", type: "uint256", value: "77901256055885924"}, {name: "_currentPriceN", type: "uint256", value: "7714503369050006132422666000000"}, {name: "_currentPriceD", type: "uint256", value: "60096915174079021137289000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[2], addressList[6], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "4262618", timeStamp: "1505140127", hash: "0x666dd956547611a895b17da75133c18b4a39c90cfad98568e49bed8295db8390", nonce: "425", blockHash: "0xa63d349205568b968917a741c272b3e002f3ceeb34feaee1a22b9ddf9aaf7905", transactionIndex: "14", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0x5e5144eb000000000000000000000000b72a0fa1e537c956dfca72711c468efd81270468000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "566194", gasUsed: "150000", confirmations: "3441178"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[2]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "4262624", timeStamp: "1505140286", hash: "0xb182b169d86d3247fa21959bd190ebd00ccd0ee0ddeb1542bd393139e182108c", nonce: "22", blockHash: "0x5d28442a37aea693b73bb2c23fed98ffdfdcb76c87748cc728f8a1091ad8bca1", transactionIndex: "39", from: "0x3880f7473f18ba81cb330d1fed943da583265fb2", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "117069", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5311719", gasUsed: "117069", confirmations: "3441172"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "10000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1505140286 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x3880f7473f18ba81cb330d1fed943da583265fb2"}, {name: "_amount", type: "uint256", value: "10000000000000000000"}, {name: "_return", type: "uint256", value: "77901165173704402"}, {name: "_currentPriceN", type: "uint256", value: "7714502369050006132422666000000"}, {name: "_currentPriceD", type: "uint256", value: "60096837272913847432887000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1033034292857374001" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "4262634", timeStamp: "1505140458", hash: "0x03d64f5eb52c354edcf759ad8e57a33936844cee521ecfd7f1f0a743a754b36c", nonce: "426", blockHash: "0x2a2e944d7e7a3fafddbfefe331ce6e084b42dab91b504cbd541cc76f99310a0c", transactionIndex: "71", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "131771", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2000899", gasUsed: "131771", confirmations: "3441162"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "1000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1505140458 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x9345c50fb2158d40a09723a7b414dca763bf8543"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}, {name: "_return", type: "uint256", value: "7790111518854085"}, {name: "_currentPriceN", type: "uint256", value: "7714502269050006132422666000000"}, {name: "_currentPriceD", type: "uint256", value: "60096829482802328578802000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"179100... )", async function( ) {
		const txOriginal = {blockNumber: "4262636", timeStamp: "1505140564", hash: "0x3c81f4544a3072687ebad70b9eadba999aee18301a3bc09ac2447abd8bf03149", nonce: "427", blockHash: "0xd907d6705a2ace63037387c552efe1b3e335514b25d310fa133a9e28cb82bb22", transactionIndex: "46", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "118575", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000061171e32e0149c00000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4631905", gasUsed: "118575", confirmations: "3441160"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "1791000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "1791000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1505140564 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x9345c50fb2158d40a09723a7b414dca763bf8543"}, {name: "_amount", type: "uint256", value: "1791000000000000000000"}, {name: "_return", type: "uint256", value: "13950631403082467509"}, {name: "_currentPriceN", type: "uint256", value: "7714323169050006132422666000000"}, {name: "_currentPriceD", type: "uint256", value: "60082878851399246111293000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"203257... )", async function( ) {
		const txOriginal = {blockNumber: "4262639", timeStamp: "1505140611", hash: "0xcb38433640c54293801a6c28d3a474c5b8eb15a3a0dd4ab1ef492fab4a84b71a", nonce: "704", blockHash: "0x0018fc32bbc063059a64152fd0abb9c3250a78452bec67a3fe3c1259b25ed067", transactionIndex: "84", from: "0xaf6787931e7369113b667c2cb09449de88951144", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000006e2fa5792c42fdcc000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3355351", gasUsed: "117313", confirmations: "3441157"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "2032575131630000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "2032575131630000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1505140611 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xaf6787931e7369113b667c2cb09449de88951144"}, {name: "_amount", type: "uint256", value: "2032575131630000000000"}, {name: "_return", type: "uint256", value: "15828801057791131129"}, {name: "_currentPriceN", type: "uint256", value: "7714119911536843132422666000000"}, {name: "_currentPriceD", type: "uint256", value: "60067050050341454980164000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "276345833039875297" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4262640", timeStamp: "1505140613", hash: "0x36b7e92f7f39a466e911825a25c88890d5ff61d21a1f9f6c7c66bb189d43dad1", nonce: "23", blockHash: "0xcac1413ec246c8be44238dcd1717a4c2c600805562dcdf4775f51866436c6880", transactionIndex: "25", from: "0x3880f7473f18ba81cb330d1fed943da583265fb2", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "1218579", gasUsed: "190681", confirmations: "3441156"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "10000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1505140613 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xb72a0fa1e537c956dfca72711c468efd81270468"}, {name: "_amount", type: "uint256", value: "10000000000000000000"}, {name: "_return", type: "uint256", value: "77866322664565757"}, {name: "_currentPriceN", type: "uint256", value: "7714118911536843132422666000000"}, {name: "_currentPriceD", type: "uint256", value: "60066972184018790414407000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "1033034292857374001" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "4262675", timeStamp: "1505141227", hash: "0xed36c11bb38e002bc6ee7da1a66030131295c24446951ba43bbae1f6f6d2c6e0", nonce: "3392", blockHash: "0x5b3d50aac693066bb99d3d5ea1a5f93ce4b719397fdbfcbf5714784b976798be", transactionIndex: "108", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4001678", gasUsed: "132815", confirmations: "3441121"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "10000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1505141227 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c"}, {name: "_amount", type: "uint256", value: "10000000000000000000"}, {name: "_return", type: "uint256", value: "77866231818611318"}, {name: "_currentPriceN", type: "uint256", value: "7714117911536843132422666000000"}, {name: "_currentPriceD", type: "uint256", value: "60066894317786971803089000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[18], \"15000... )", async function( ) {
		const txOriginal = {blockNumber: "4262685", timeStamp: "1505141515", hash: "0x73cc9f5368c697a9342fc74cb26a137fbdc2c7e67ecef363d2f1651564bb3a22", nonce: "3393", blockHash: "0x7a67b9624250e7faa11fe6a9906f614ddad842edbbc63306b7278507955ec10b", transactionIndex: "80", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000d76b5c2a23ef78368d8e34288b5b65d616b746ae000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2830576", gasUsed: "150000", confirmations: "3441111"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[18]}, {type: "uint256", name: "_amount", value: "15000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"150000... )", async function( ) {
		const txOriginal = {blockNumber: "4262706", timeStamp: "1505141869", hash: "0xc1f162c3af529d1c6587901f6184634bd00c84b624c71270a84099dc9c515589", nonce: "3394", blockHash: "0xccdbac066860cec7b33de20c577c8aea61397683bd727a2ac216547640253adf", transactionIndex: "54", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2769109", gasUsed: "118461", confirmations: "3441090"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "15000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "15000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1505141869 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c"}, {name: "_amount", type: "uint256", value: "15000000000000000000"}, {name: "_return", type: "uint256", value: "116799177391958494"}, {name: "_currentPriceN", type: "uint256", value: "7714116411536843132422666000000"}, {name: "_currentPriceD", type: "uint256", value: "60066777518609579844595000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"500000... )", async function( ) {
		const txOriginal = {blockNumber: "4262718", timeStamp: "1505142094", hash: "0x89cd6cd43d42ae0e57f4c982898e712fc7a1842c249c297b24e5913f6b2db15a", nonce: "105", blockHash: "0x8dc99a28518b42318255cf4c12cfdec30dce54fa9910bdc837d697ea1af07af9", transactionIndex: "40", from: "0xc5d7345a18974ab0da7fa54ef0646b8b528fc980", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "133511", gasPrice: "58000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1508585", gasUsed: "133511", confirmations: "3441078"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "5000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "5000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1505142094 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xc5d7345a18974ab0da7fa54ef0646b8b528fc980"}, {name: "_amount", type: "uint256", value: "5000000000000000000"}, {name: "_return", type: "uint256", value: "38933013707777675"}, {name: "_currentPriceN", type: "uint256", value: "7714115911536843132422666000000"}, {name: "_currentPriceD", type: "uint256", value: "60066738585595872066920000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "2205708818638671" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4262718", timeStamp: "1505142094", hash: "0x8459b6603ed6bbc2711cb2da57ed65abc013692b53c65309197fe87926b499e0", nonce: "190", blockHash: "0x8dc99a28518b42318255cf4c12cfdec30dce54fa9910bdc837d697ea1af07af9", transactionIndex: "120", from: "0x1bd39650266b94fde58a72c0e2bb17d85708d3af", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "12000000000000000000", gas: "300874", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "6069075", gasUsed: "240170", confirmations: "3441078"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "12000000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1505142094 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xb72a0fa1e537c956dfca72711c468efd81270468"}, {name: "_amount", type: "uint256", value: "12000000000000000000"}, {name: "_return", type: "uint256", value: "1540970463558311927982"}, {name: "_currentPriceN", type: "uint256", value: "60078738585595872066920000000"}, {name: "_currentPriceD", type: "uint256", value: "7714270008583198963615464200000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "50161986844508189" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"838300... )", async function( ) {
		const txOriginal = {blockNumber: "4262725", timeStamp: "1505142319", hash: "0x44ab88e782e8ef49a2bb4b56aadbfcf98345fda42815b2276650051a7bf9886f", nonce: "3396", blockHash: "0x92c9dd8c3db42dfb5e9cbc4a2191b99edb288f5375bb4308725e9973fa1f2c00", transactionIndex: "118", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000001c6717ec4f6639c00000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4401516", gasUsed: "133059", confirmations: "3441071"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "8383000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "8383000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1505142319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c"}, {name: "_amount", type: "uint256", value: "8383000000000000000000"}, {name: "_return", type: "uint256", value: "65254891476199029827"}, {name: "_currentPriceN", type: "uint256", value: "7713431708583198963615464200000"}, {name: "_currentPriceD", type: "uint256", value: "60013483694119673037093000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"157600... )", async function( ) {
		const txOriginal = {blockNumber: "4262761", timeStamp: "1505142931", hash: "0xb752ee973879313d2598fb47c66d58f0ec7bd0342855d93b6490d526598c32f0", nonce: "3401", blockHash: "0x9f1a2cf2903315b22bcb86a1227d7ab63c91b358541bda6c7845c7ef5135cdde", transactionIndex: "99", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000556f64c1fe7fa000000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5335449", gasUsed: "132945", confirmations: "3441035"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "1576000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "1576000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1505142931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c"}, {name: "_amount", type: "uint256", value: "1576000000000000000000"}, {name: "_return", type: "uint256", value: "12260762552441694336"}, {name: "_currentPriceN", type: "uint256", value: "7713274108583198963615464200000"}, {name: "_currentPriceD", type: "uint256", value: "60001222931567231342757000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"201100... )", async function( ) {
		const txOriginal = {blockNumber: "4262858", timeStamp: "1505145373", hash: "0x4f737f8b02a66384cf9d2bee96a71aec7d06a42616a1c9fa75dae0e67af5cb10", nonce: "430", blockHash: "0x41ed896d673fdcaec14f452772f7371ea52798abc53be80392860385507894eb", transactionIndex: "58", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "133061", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000006d043b3543ee8c00000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2640310", gasUsed: "133061", confirmations: "3440938"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "2011000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "2011000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1505145373 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x9345c50fb2158d40a09723a7b414dca763bf8543"}, {name: "_amount", type: "uint256", value: "2011000000000000000000"}, {name: "_return", type: "uint256", value: "15641646080866302286"}, {name: "_currentPriceN", type: "uint256", value: "7713073008583198963615464200000"}, {name: "_currentPriceD", type: "uint256", value: "59985581285486365040471000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"377350... )", async function( ) {
		const txOriginal = {blockNumber: "4263019", timeStamp: "1505149424", hash: "0xc0437f5aab3f9da36cb18f03882d6e0167927b17a4eba85eb241cffdbd0d5615", nonce: "75", blockHash: "0x296811c0d4a011c0977c31e8f7ceabb9a20bdc38c0a214e1898df9e06dbf9c2c", transactionIndex: "61", from: "0x00156cd84776616bcc0bc5f78867cc2b67f8a285", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "146438", gasPrice: "500000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000001474caf15d169f0c000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6024299", gasUsed: "133125", confirmations: "3440777"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "377350685710000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "377350685710000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1505149424 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x00156cd84776616bcc0bc5f78867cc2b67f8a285"}, {name: "_amount", type: "uint256", value: "377350685710000000000"}, {name: "_return", type: "uint256", value: "2934641209300142940"}, {name: "_currentPriceN", type: "uint256", value: "7713035273514627963615464200000"}, {name: "_currentPriceD", type: "uint256", value: "59982646644277064897531000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "996850000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"934000... )", async function( ) {
		const txOriginal = {blockNumber: "4263037", timeStamp: "1505149862", hash: "0x499e8a8e7ecadb0a3621c26366c5f3a793b3d3738edbd507a3bab357a21a54c5", nonce: "433", blockHash: "0xfaf61338ac7bbe68657fbf175dd6626c6f6ec7861f2ff2fb48be2fde1c9da408", transactionIndex: "43", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "132829", gasPrice: "24000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000032a1da9374b6d800000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1547662", gasUsed: "132829", confirmations: "3440759"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "934000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "934000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1505149862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x9345c50fb2158d40a09723a7b414dca763bf8543"}, {name: "_amount", type: "uint256", value: "934000000000000000000"}, {name: "_return", type: "uint256", value: "7263124985168725473"}, {name: "_currentPriceN", type: "uint256", value: "7712941873514627963615464200000"}, {name: "_currentPriceD", type: "uint256", value: "59975383519291896172058000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"204900... )", async function( ) {
		const txOriginal = {blockNumber: "4263213", timeStamp: "1505154074", hash: "0x4924db39cdfc5706ea6618f6c70f72ff06fb477abe7d92534b240f6b2462cae0", nonce: "655", blockHash: "0x0a85ee08132a635e9e21bf0fc44c55c9554ef2dace9a17c1a16cd9a22c0a07df", transactionIndex: "20", from: "0x3b0899f81f2dc9d7d25c7251e979ef4e89e3c75b", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "131553", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000006f139653eec76400000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "904416", gasUsed: "131553", confirmations: "3440583"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "2049000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "2049000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1505154074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x3b0899f81f2dc9d7d25c7251e979ef4e89e3c75b"}, {name: "_amount", type: "uint256", value: "2049000000000000000000"}, {name: "_return", type: "uint256", value: "15930999215709327141"}, {name: "_currentPriceN", type: "uint256", value: "7712736973514627963615464200000"}, {name: "_currentPriceD", type: "uint256", value: "59959452520076186844917000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "32335519000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"216300... )", async function( ) {
		const txOriginal = {blockNumber: "4263261", timeStamp: "1505155149", hash: "0xd26cb6f7249d1875b61adda2bdb9ace55e879f4c3c6df08d72cc3148b23dc42e", nonce: "814", blockHash: "0x856bda02abb8b567e3ece01d1fcc613bd8d5f0e956455c4a56f11f1057ede7e9", transactionIndex: "56", from: "0x00a83e95a30765e4938ad86370b25f941a3caa86", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "159395", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000007541a7afef51ec00000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1942385", gasUsed: "132829", confirmations: "3440535"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "2163000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "2163000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1505155149 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x00a83e95a30765e4938ad86370b25f941a3caa86"}, {name: "_amount", type: "uint256", value: "2163000000000000000000"}, {name: "_return", type: "uint256", value: "16813218220568023168"}, {name: "_currentPriceN", type: "uint256", value: "7712520673514627963615464200000"}, {name: "_currentPriceD", type: "uint256", value: "59942639301855618821749000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "17881413999999999" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"350000... )", async function( ) {
		const txOriginal = {blockNumber: "4263319", timeStamp: "1505156440", hash: "0x62ff78ff4a3ec4c0232cbec4b9803ccaf0815ec55efae6c29a73e5aee2371d9f", nonce: "4", blockHash: "0x6f91ff52dc2c6f21a501f4a859160da0abf0409253f19f4ecaf966fe2e979c2a", transactionIndex: "17", from: "0xe37aa3cc875b568091ad38d9554eb83cb5e4ba2f", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "133691", gasPrice: "50000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000012f939c99edab800000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "635950", gasUsed: "133691", confirmations: "3440477"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "350000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "350000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1505156440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xe37aa3cc875b568091ad38d9554eb83cb5e4ba2f"}, {name: "_amount", type: "uint256", value: "350000000000000000000"}, {name: "_return", type: "uint256", value: "2720186591491677105"}, {name: "_currentPriceN", type: "uint256", value: "7712485673514627963615464200000"}, {name: "_currentPriceD", type: "uint256", value: "59939919115264127144644000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "42077488724223105" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"350000... )", async function( ) {
		const txOriginal = {blockNumber: "4263326", timeStamp: "1505156626", hash: "0x456f8e142c2b3095d1f5898032af9024a1029d5f294193a69fba0c9587a9a162", nonce: "5", blockHash: "0x2c9a88b5253388cd3a567a25e1f553bb6e18b42fb91eeb0a53ad11b473bc991a", transactionIndex: "10", from: "0xe37aa3cc875b568091ad38d9554eb83cb5e4ba2f", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000012f939c99edab800000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "566744", gasUsed: "150000", confirmations: "3440470"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "350000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "42077488724223105" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4263366", timeStamp: "1505157740", hash: "0x8c94db92280374ef6f5cd596ddfab0c20063203a9c5b3e44b242504ae2431ae4", nonce: "33", blockHash: "0x251d2c8861cfcf94c63283fac6f6564c06f848c48bd71c55b88f4fda9cbfa779", transactionIndex: "156", from: "0x4a834ada4c8134686e0958d22b3c9bcfbe75d816", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "1000000000000000000", gas: "316162", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "6045935", gasUsed: "255800", confirmations: "3440430"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1505157740 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xb72a0fa1e537c956dfca72711c468efd81270468"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}, {name: "_return", type: "uint256", value: "128669305637086900706"}, {name: "_currentPriceN", type: "uint256", value: "59940919115264127144644000000"}, {name: "_currentPriceD", type: "uint256", value: "7712498540445191672305534800000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "3337891695181689415" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"307800... )", async function( ) {
		const txOriginal = {blockNumber: "4264750", timeStamp: "1505190824", hash: "0x2e6ee68f93cf4c2ac66cedd891c8dde3b39ac22995e1d28ec40e709682c6666d", nonce: "3408", blockHash: "0xe91ef6350f3c5445fedb9d25582bba2db76f20a72ec96b3f81032af1512603bd", transactionIndex: "151", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000a6dbd4b40e9c5800000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6408460", gasUsed: "134105", confirmations: "3439046"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "3078000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "3078000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1505190824 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c"}, {name: "_amount", type: "uint256", value: "3078000000000000000000"}, {name: "_return", type: "uint256", value: "23917673018228848969"}, {name: "_currentPriceN", type: "uint256", value: "7712190740445191672305534800000"}, {name: "_currentPriceD", type: "uint256", value: "59917001442245898295675000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"389300... )", async function( ) {
		const txOriginal = {blockNumber: "4265081", timeStamp: "1505198917", hash: "0x580dc4fbbd13b4f7e9fbe638ff8eeba6f2ada8aa0df2cf500a024cd5ac1c296a", nonce: "436", blockHash: "0xe0e7dd2b1863b80c7d53bcdda9764bb7eee7a281644b36b92d98ded19a6bbd04", transactionIndex: "17", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "132185", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000d30a3a5a0083b400000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "607930", gasUsed: "132185", confirmations: "3438715"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "3893000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "3893000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1505198917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x9345c50fb2158d40a09723a7b414dca763bf8543"}, {name: "_amount", type: "uint256", value: "3893000000000000000000"}, {name: "_return", type: "uint256", value: "30238348156897794436"}, {name: "_currentPriceN", type: "uint256", value: "7711801440445191672305534800000"}, {name: "_currentPriceD", type: "uint256", value: "59886763094089000501239000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4265146", timeStamp: "1505200367", hash: "0x8a8250ab342c5eed86afbb79f11788fe10fe56d01bb4094c2f66183db6967c55", nonce: "224", blockHash: "0xd09d9ff0bbf8e92afff2dfcb9c159cfd853509789068417894ef597becbdcd43", transactionIndex: "154", from: "0x411f7a41ddcb3494d1592b84ebb692017428ea19", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "203880", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000046791fc84e07d000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "4869481", gasUsed: "188657", confirmations: "3438650"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "20800000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "20800000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1505200367 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xb72a0fa1e537c956dfca72711c468efd81270468"}, {name: "_amount", type: "uint256", value: "20800000000000000000000"}, {name: "_return", type: "uint256", value: "161328568918247483102"}, {name: "_currentPriceN", type: "uint256", value: "7709721440445191672305534800000"}, {name: "_currentPriceD", type: "uint256", value: "59725434525170753018137000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"391400... )", async function( ) {
		const txOriginal = {blockNumber: "4265182", timeStamp: "1505201180", hash: "0xf5829bb31fd25c8409c9836aed80f6272330cb9877fd910c5b9ed099bfe84028", nonce: "439", blockHash: "0x9c9ccd682da46759e015b079934485132546f97b9aad7036ab89e3e21de5fbdf", transactionIndex: "128", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "133343", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000d42da956bd3ee800000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3372666", gasUsed: "133343", confirmations: "3438614"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "3914000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "3914000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1505201180 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x9345c50fb2158d40a09723a7b414dca763bf8543"}, {name: "_amount", type: "uint256", value: "3914000000000000000000"}, {name: "_return", type: "uint256", value: "30313929711078074371"}, {name: "_currentPriceN", type: "uint256", value: "7709330040445191672305534800000"}, {name: "_currentPriceD", type: "uint256", value: "59695120595459674943766000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"118130... )", async function( ) {
		const txOriginal = {blockNumber: "4265187", timeStamp: "1505201344", hash: "0x9a83f1a16915b83f79accb93321fbb8cab8057f6b60fc7500a670691ce30bf56", nonce: "3419", blockHash: "0xbf66303be035554d6b85ca81b01e36e84ed60892e8ecfa1c6b5fe49775d0eb4e", transactionIndex: "139", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000280624eb00b297400000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3925654", gasUsed: "133705", confirmations: "3438609"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "11813000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "11813000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1505201344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c"}, {name: "_amount", type: "uint256", value: "11813000000000000000000"}, {name: "_return", type: "uint256", value: "91407737062121375639"}, {name: "_currentPriceN", type: "uint256", value: "7708148740445191672305534800000"}, {name: "_currentPriceD", type: "uint256", value: "59603712858397553568127000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"393100... )", async function( ) {
		const txOriginal = {blockNumber: "4265276", timeStamp: "1505203390", hash: "0x73c4ac2fb3083d99bf94e58ca93babcd4eecec6c31492128a3fa9024d0537321", nonce: "442", blockHash: "0xbe48e63a07bded71b78f2831eb87194da72116359270ceb718869405a6a8338f", transactionIndex: "70", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb72a0fa1e537c956dfca72711c468efd81270468", value: "0", gas: "132597", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000d5199578ab5c8c00000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2047301", gasUsed: "132597", confirmations: "3438520"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "3931000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "change(address,address,uint256,uint256)" ]( addressList[4], addressList[6], "3931000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1505203390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Change", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Change", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0x9345c50fb2158d40a09723a7b414dca763bf8543"}, {name: "_amount", type: "uint256", value: "3931000000000000000000"}, {name: "_return", type: "uint256", value: "30389713564703507749"}, {name: "_currentPriceN", type: "uint256", value: "7707755640445191672305534800000"}, {name: "_currentPriceD", type: "uint256", value: "59573323144832850060378000000"}], address: "0xb72a0fa1e537c956dfca72711c468efd81270468"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
