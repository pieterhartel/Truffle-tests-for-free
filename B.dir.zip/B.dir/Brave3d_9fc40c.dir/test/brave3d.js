const Brave3d = artifacts.require( "./Brave3d.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Brave3d" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x132E2b67e91Bf0294536B16D772E8deE099Fc40C", "0xB3775fB83F7D12A36E0475aBdD1FCA35c091efBe", "0x97397C2129517f82031a28742247465BC75E1849", "0xDC489B03869dfca0d53cbCcA3b486156eEE3d5Fe", "0x3c0852790aFDa3CD3bb20089B5D448084Da37d7b", "0x843eeAE449F87d27011eb5C30459C4e904b7C367", "0x382672526a043E40EA0e886fdd8Ac993D13361A2", "0x60809F5a0Bf6C6763d763b529EA2b106312b68Bf", "0xf60b28D4C2b230C9be094B48AC7c7ff56fe935CB", "0x46eC8bdD6Ea5AE3ECF26eD60ABDe58138511Df7f", "0x95096780Efd48FA66483Bc197677e89f37Ca0CB5", "0x7aF3f33c42e5b75c97b68C924871B5BE273238ea", "0x4be2b531bd4034cd1A7814313edB2f111D37721e", "0x49D776Ed2D6FCFe2078805B18EA6fd01ca6D1266", "0xEa6bD82eacFc8373E7505beD34e689AA8B74a064"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "adr", type: "address"}], name: "getEarnings", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getName", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "adr", type: "address"}], name: "getRefereeAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "rate", type: "uint8"}, {name: "index", type: "uint256"}], name: "getStageData", outputs: [{name: "", type: "address"}, {name: "", type: "address"}, {name: "", type: "address"}, {name: "", type: "bool"}, {name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "adr", type: "address"}], name: "getReferee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "myReferee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "rate", type: "uint8"}], name: "currentStageData", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "myEarnings", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "BraveWithdraw", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "stage", type: "uint256"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveInvalidateStage", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["BravePlayer(address,uint8)", "BraveDeadPlayer(address,uint256,uint8,uint8)", "BraveWithdraw(address,uint256)", "BraveInvalidateStage(uint256,uint8)", "BraveReferrer(address,address,uint8)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xc67060fd7934d0486a10809595bef915c87c66b6c8a6e41ad32069ca39dd5f60", "0xe5ea169877407973b84c97fad54b2eb010142e06621ede2085cf750f50294b2f", "0x0710cb3289e7fa4f5a7d4652ee3b2c1236a8e4d153105927c0b1f1d615e33aac", "0x55b7611ad4fc07f4aad1486e9121f21b04cd3966345b73729846322e6b71f211", "0x2a183e17d94793529ad6c7c5baa4ff01b7ee25a181bd54830a0e91b4bbb3d439"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6560290 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6565879 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Brave3d", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "adr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getEarnings", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getEarnings(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getName", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getName()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "adr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getRefereeAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRefereeAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint8", name: "rate", value: random.range( maxRandom )}, {type: "uint256", name: "index", value: random.range( maxRandom )}], name: "getStageData", outputs: [{name: "", type: "address"}, {name: "", type: "address"}, {name: "", type: "address"}, {name: "", type: "bool"}, {name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getStageData(uint8,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "adr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getReferee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getReferee(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "myReferee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myReferee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint8", name: "rate", value: random.range( maxRandom )}], name: "currentStageData", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentStageData(uint8)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "myEarnings", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "myEarnings()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Brave3d", function( accounts ) {

	it( "TEST: Brave3d(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6560290", timeStamp: "1540179815", hash: "0xf3eb58b959e820c244d0ba7704dc1e667dce480ac9c70a90cbfae65cbf37aaba", nonce: "8", blockHash: "0x487826d5be0b955b9f59241e12360aeffc704d367ebd04f1b3e185ecdad9f36d", transactionIndex: "69", from: "0x97397c2129517f82031a28742247465bc75e1849", to: 0, value: "0", gas: "1599436", gasPrice: "4200000000", isError: "0", txreceipt_status: "1", input: "0xffa6918a", contractAddress: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", cumulativeGasUsed: "5920357", gasUsed: "1599436", confirmations: "1181629"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Brave3d", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Brave3d.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540179815 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Brave3d.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "876462670300000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560368", timeStamp: "1540180873", hash: "0x5833268d540573d482b5bea77d7fb503768215ef1377a47d37cacaef08f65819", nonce: "10", blockHash: "0x5d07c70f7edcba33ca171848796e70ebf54665dca6a2ffc9e535e092ac49b3b9", transactionIndex: "170", from: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "102804", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xc47f002700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7538102", gasUsed: "68536", confirmations: "1181551"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "setName", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540180873 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "8059353000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560376", timeStamp: "1540181008", hash: "0x48c946531dff4a5f1b83b2af8ab8e3f08604e580ca6ed8749e15ea7872812089", nonce: "4", blockHash: "0x6115b84f033713f57d47c1f9ae19c9ef5a350a02b2230db1165cf63d1b06cc02", transactionIndex: "79", from: "0x3c0852790afda3cd3bb20089b5d448084da37d7b", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "138322", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5958655", gasUsed: "92215", confirmations: "1181543"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540181008 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x3c0852790afda3cd3bb20089b5d448084da37d7b"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[2,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x3c0852790afda3cd3bb20089b5d448084da37d7b"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[2,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "2175873979533142" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560376", timeStamp: "1540181008", hash: "0x171ec2d8325330a73506324db45b58e7e432f79cd12f05b6b3795eef166d4199", nonce: "8", blockHash: "0x6115b84f033713f57d47c1f9ae19c9ef5a350a02b2230db1165cf63d1b06cc02", transactionIndex: "98", from: "0x843eeae449f87d27011eb5c30459c4e904b7c367", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "138322", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7265927", gasUsed: "77215", confirmations: "1181543"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540181008 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x843eeae449f87d27011eb5c30459c4e904b7c367"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x843eeae449f87d27011eb5c30459c4e904b7c367"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "331053106804620" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560381", timeStamp: "1540181071", hash: "0xa5802296e9192a93f25c31273fc61c7dd008a46512331b8d050cb42cb75f5f85", nonce: "1", blockHash: "0x4e46fb79ad7f1a2bc11fd7013e3141db63767bbf082eab1e862096f09bf23fbf", transactionIndex: "32", from: "0x382672526a043e40ea0e886fdd8ac993d13361a2", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "138322", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6321302", gasUsed: "97921", confirmations: "1181538"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540181071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x382672526a043e40ea0e886fdd8ac993d13361a2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x382672526a043e40ea0e886fdd8ac993d13361a2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "19715927575315573" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560398", timeStamp: "1540181388", hash: "0xd8d0b03c2d9f5ecf55658fe67772a4cc45a28d5b6da2df1435a55afa9a399536", nonce: "2", blockHash: "0x6cb55bb2505274c85209d61b102015ed63f68e0f3f6230b19d9e94b5926260c7", transactionIndex: "100", from: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "546442", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5698913", gasUsed: "364295", confirmations: "1181521"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540181388 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x382672526a043e40ea0e886fdd8ac993d13361a2"}, {name: "numberOfStage", type: "uint256", value: "0"}, {name: "deadIndex", type: "uint8", value: "2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2296816970237728" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560440", timeStamp: "1540181861", hash: "0x03a5027dd32581c83b7fc426a980ee99c949886e11ac182441ae84512eb5c91a", nonce: "3", blockHash: "0x8f6571214024332100c5639a7e012b8d741cfdc8e7ef4ea59d21402f19c739de", transactionIndex: "102", from: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "83098", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4019745", gasUsed: "55399", confirmations: "1181479"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540181861 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2296816970237728" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560440", timeStamp: "1540181861", hash: "0x692d89a2be8cc3cb515927e0175ee5d09f7e18cdfbcbb3a11ceb3c3cd216d6e5", nonce: "2", blockHash: "0x8f6571214024332100c5639a7e012b8d741cfdc8e7ef4ea59d21402f19c739de", transactionIndex: "217", from: "0xf60b28d4c2b230c9be094b48ac7c7ff56fe935cb", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "115822", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7189731", gasUsed: "97921", confirmations: "1181479"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540181861 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0xf60b28d4c2b230c9be094b48ac7c7ff56fe935cb"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0xf60b28d4c2b230c9be094b48ac7c7ff56fe935cb"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1883983025050693" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6560453", timeStamp: "1540182074", hash: "0x12e47c104240acce30696ab6450d83b8e445e9240e833ea8b021d694f8dfa7de", nonce: "11", blockHash: "0x57dbf9052f5f523ebfd0cf0c66aabdc25ba3da40fde0202bec3eeb8ded2e7349", transactionIndex: "174", from: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "391153", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7315004", gasUsed: "245769", confirmations: "1181466"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540182074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "numberOfStage", type: "uint256", value: "1"}, {name: "deadIndex", type: "uint8", value: "0"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "BraveWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveWithdraw", events: [{name: "player", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "amount", type: "uint256", value: "21000000000000000"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "8059353000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560470", timeStamp: "1540182370", hash: "0xf298637536674133a7e57948cafd255defdef87e4d0e1db54429d183b24ad59e", nonce: "2", blockHash: "0xf3cdaba97953a20ce505295fe80e01a439aa7e4ded61c7f902ffbc30aa034bce", transactionIndex: "100", from: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "169681", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7835488", gasUsed: "113121", confirmations: "1181449"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540182370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "97121091981492025" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyByAddress( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6560551", timeStamp: "1540183565", hash: "0x42692d0c56e1e410ad26ca2c8487a22197d0ed1b3bc982233adbcbc2cd054d12", nonce: "1523", blockHash: "0x52ccdf1acc2c461042db445cce76a483079cd07e2696678120b7dd8b1b9928e7", transactionIndex: "135", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "112924", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe921b4f80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4419182", gasUsed: "75283", confirmations: "1181368"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "referee", value: addressList[0]}], name: "buyByAddress", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByAddress(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540183565 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0x97397c2129517f82031a28742247465bc75e1849"}, {name: "referrered", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyByAddress( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6560568", timeStamp: "1540183845", hash: "0x72572c3521814b61c85a8284b57787690e6f97d8715a8a8193db247b93eae3b0", nonce: "1524", blockHash: "0x57ec2076142af7356b7d082787e58571996d84f843f51e226ae791db1c637fe9", transactionIndex: "74", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "113230", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe921b4f80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2365581", gasUsed: "75487", confirmations: "1181351"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "referee", value: addressList[0]}], name: "buyByAddress", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByAddress(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540183845 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0x97397c2129517f82031a28742247465bc75e1849"}, {name: "referrered", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buyByAddress( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6560593", timeStamp: "1540184187", hash: "0x1b34c235261ab691a6b1534470cd0b9858a3d3cc478bdd68ce308a1d3c7763c6", nonce: "1525", blockHash: "0xb414cbb391d036b9cdf4d25fb19893ab68c11a3225a0c341fb2ebb7fd6568b53", transactionIndex: "41", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "489529", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xe921b4f80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2294189", gasUsed: "326353", confirmations: "1181326"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "referee", value: addressList[0]}], name: "buyByAddress", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByAddress(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540184187 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "numberOfStage", type: "uint256", value: "2"}, {name: "deadIndex", type: "uint8", value: "2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0x97397c2129517f82031a28742247465bc75e1849"}, {name: "referrered", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560727", timeStamp: "1540186126", hash: "0xa69c37c98df8502514b3959040d24ea38456ed0b7de31177d3ab79af8d185d69", nonce: "4", blockHash: "0x233f93848f204ce8ebeb7190935862ddce7ce9002c838b9fd5caa9c875ac4166", transactionIndex: "125", from: "0x7af3f33c42e5b75c97b68c924871b5be273238ea", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "115822", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6751038", gasUsed: "77215", confirmations: "1181192"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540186126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "6849966072534310" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6560727", timeStamp: "1540186126", hash: "0x68af55f2edcd51aa96dd86bcbe825f5f6648ff30cad2f67ce9bb78383991239f", nonce: "3", blockHash: "0x233f93848f204ce8ebeb7190935862ddce7ce9002c838b9fd5caa9c875ac4166", transactionIndex: "128", from: "0x4be2b531bd4034cd1a7814313edb2f111d37721e", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "115822", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7006258", gasUsed: "97921", confirmations: "1181192"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540186126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x4be2b531bd4034cd1a7814313edb2f111d37721e"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x4be2b531bd4034cd1a7814313edb2f111d37721e"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "58432947094178977" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6560737", timeStamp: "1540186307", hash: "0xdfa2eb308e39d9f7becfadfe99c4659f87aaf41a087f53d5f5e2cb6fad982d39", nonce: "1526", blockHash: "0x3714cce1f6fa87f7bef6f1211e8c4b98fdf269868789ec7af24ebaca086443c0", transactionIndex: "26", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "89842", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2091080", gasUsed: "89842", confirmations: "1181182"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6560737", timeStamp: "1540186307", hash: "0x517724a1eb3e5b824357ebb617f1fc4723c26450f2f1bfa58f897b7903e2fd0b", nonce: "1527", blockHash: "0x3714cce1f6fa87f7bef6f1211e8c4b98fdf269868789ec7af24ebaca086443c0", transactionIndex: "109", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "60145", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "6703373", gasUsed: "60145", confirmations: "1181182"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6560737", timeStamp: "1540186307", hash: "0x352e2be33ae467210b04aa834bba5c9aee5d8486f2d1482f61934cce8b2910f7", nonce: "1528", blockHash: "0x3714cce1f6fa87f7bef6f1211e8c4b98fdf269868789ec7af24ebaca086443c0", transactionIndex: "110", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "89842", gasPrice: "30000000000", isError: "1", txreceipt_status: "0", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6793215", gasUsed: "89842", confirmations: "1181182"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6560755", timeStamp: "1540186539", hash: "0x74f516bb508ea2d9fe241217cddbe207cfde25916fdd817ed8a552aa4d942b09", nonce: "9", blockHash: "0xc36270fe0eb504360f69e40b34a33d35805452f2a47f30510b78d3bcea5aa1e8", transactionIndex: "37", from: "0x843eeae449f87d27011eb5c30459c4e904b7c367", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "452200", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3157326", gasUsed: "301467", confirmations: "1181164"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540186539 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x843eeae449f87d27011eb5c30459c4e904b7c367"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "numberOfStage", type: "uint256", value: "3"}, {name: "deadIndex", type: "uint8", value: "0"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x843eeae449f87d27011eb5c30459c4e904b7c367"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "331053106804620" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6560771", timeStamp: "1540186757", hash: "0x7ff80e48e0d6ca9c633e291cf5f71223127ee137dfd7916482e8ed2bc2ca404a", nonce: "1530", blockHash: "0xd8704bf7bf4eb81288e60ed82c2a5189b763a02aa19e4e79ad6b74daeef3e0ab", transactionIndex: "137", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "89842", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6183755", gasUsed: "59895", confirmations: "1181148"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540186757 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0x97397c2129517f82031a28742247465bc75e1849"}, {name: "referrered", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6560771", timeStamp: "1540186757", hash: "0x0b61b2f653d19168d1a85ca5dfeccec549f988c82c7433d6c8a65d6ff64f34aa", nonce: "1531", blockHash: "0xd8704bf7bf4eb81288e60ed82c2a5189b763a02aa19e4e79ad6b74daeef3e0ab", transactionIndex: "138", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "60145", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "6208852", gasUsed: "25097", confirmations: "1181148"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540186757 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "BraveWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveWithdraw", events: [{name: "player", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "amount", type: "uint256", value: "30000127277887498"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6561032", timeStamp: "1540190543", hash: "0x549d8c4be45a72150d58339a371e79f6a4778e3f02519d1bed79e694a6a0cbc5", nonce: "3", blockHash: "0x4d857d434b40d62eb0ec0f91adc2a3bedd186a407e257363798c09fb799ab5ed", transactionIndex: "80", from: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "120901", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3641731", gasUsed: "80601", confirmations: "1180887"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540190543 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "97121091981492025" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6561037", timeStamp: "1540190664", hash: "0x1448e9a0bb2005b37ee1820174dc0deb0baccdb02d7854bc469ed8f2e0b728ba", nonce: "3", blockHash: "0x6cd3e3756efafcf8b74b268b01cfc8fff31703ac71fbf4be4ac4c45d91aee717", transactionIndex: "95", from: "0xf60b28d4c2b230c9be094b48ac7c7ff56fe935cb", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "429700", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4740333", gasUsed: "286467", confirmations: "1180882"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540190664 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0xf60b28d4c2b230c9be094b48ac7c7ff56fe935cb"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x843eeae449f87d27011eb5c30459c4e904b7c367"}, {name: "numberOfStage", type: "uint256", value: "4"}, {name: "deadIndex", type: "uint8", value: "0"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0xf60b28d4c2b230c9be094b48ac7c7ff56fe935cb"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1883983025050693" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyByAddress( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6561238", timeStamp: "1540193714", hash: "0x73a1ea7383e5005928c4a13c5f1bec90a78abc3db2833c8fc370198293f596f7", nonce: "2", blockHash: "0xcc865c90f98e891d91ee1b5caecbccf2df5e73e6d9bc5cbc0d54098fb890d6c3", transactionIndex: "42", from: "0x382672526a043e40ea0e886fdd8ac993d13361a2", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "82171", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe921b4f80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2238008", gasUsed: "54781", confirmations: "1180681"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "referee", value: addressList[0]}], name: "buyByAddress", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByAddress(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540193714 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x382672526a043e40ea0e886fdd8ac993d13361a2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x382672526a043e40ea0e886fdd8ac993d13361a2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "19715927575315573" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyByAddress( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6561260", timeStamp: "1540193963", hash: "0xdb1c45f4006fbf6b8f4bbafc9a51a5f21bb6901d9bb9d70487be0431f76bb236", nonce: "10", blockHash: "0x106eb9886bbf968b28bf39d126f69242d60bf95fe1eb5958038287b8d4268f1a", transactionIndex: "100", from: "0x843eeae449f87d27011eb5c30459c4e904b7c367", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "113230", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe921b4f80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6887696", gasUsed: "75487", confirmations: "1180659"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "referee", value: addressList[0]}], name: "buyByAddress", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByAddress(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540193963 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x843eeae449f87d27011eb5c30459c4e904b7c367"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x843eeae449f87d27011eb5c30459c4e904b7c367"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "331053106804620" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6561267", timeStamp: "1540194025", hash: "0x17711e88f65b747aa2b639a26b37b80d83da5c99c3fec40f77dec41f02855cf1", nonce: "4", blockHash: "0x2bd1140cf00eec4cb5d8f63d41b3424fe6381431ef4043d1cc3633713eef3bff", transactionIndex: "28", from: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "429700", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1278465", gasUsed: "286467", confirmations: "1180652"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540194025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x843eeae449f87d27011eb5c30459c4e904b7c367"}, {name: "numberOfStage", type: "uint256", value: "5"}, {name: "deadIndex", type: "uint8", value: "2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2296816970237728" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buyByAddress( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6561450", timeStamp: "1540196615", hash: "0x6b9cb42bdf4ecc9c3d72f1387048e979e1ed34dc0633c85454858099ac4fee93", nonce: "5", blockHash: "0x43fef34100c1cbda0150b6866a74848fb4acdb836ed5dbd8e7a5646f42c6af52", transactionIndex: "36", from: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "82171", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe921b4f80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7031121", gasUsed: "54781", confirmations: "1180469"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "referee", value: addressList[0]}], name: "buyByAddress", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByAddress(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540196615 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2296816970237728" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6561456", timeStamp: "1540196692", hash: "0x29dd04eb7bcc4cf7f061247038af574ebe64e62314f3dcf8c98951039349ae19", nonce: "5", blockHash: "0x0d6fe7778c3fe3c5d2659972bac66de5f8ac36b9a65e525f0ae829fb9b8788e2", transactionIndex: "94", from: "0x7af3f33c42e5b75c97b68c924871b5be273238ea", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "120901", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5218271", gasUsed: "80601", confirmations: "1180463"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540196692 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "6849966072534310" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6561466", timeStamp: "1540196854", hash: "0x7a71f05eca082238d1e1051bb046338c2dd4937248896b02a91d04f15eb49542", nonce: "5", blockHash: "0xb75dbea7052ef8e580bd7df64121b39602d044a2bad3523196b92c642b29a2f5", transactionIndex: "128", from: "0x3c0852790afda3cd3bb20089b5d448084da37d7b", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "323653", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7266125", gasUsed: "200769", confirmations: "1180453"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540196854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "numberOfStage", type: "uint256", value: "6"}, {name: "deadIndex", type: "uint8", value: "1"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "BraveWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveWithdraw", events: [{name: "player", type: "address", value: "0x3c0852790afda3cd3bb20089b5d448084da37d7b"}, {name: "amount", type: "uint256", value: "130000000000000000"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "2175873979533142" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyByAddress( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6561489", timeStamp: "1540197182", hash: "0x99d9c5ef2c14aa0fdba61c2c0ec9215c45f0c2d59e0b6e4a4045359cbb674dee", nonce: "675", blockHash: "0x0e405e84f692756a8113c8c19740940dbd2fe78548205ee74aeb16c5118e05eb", transactionIndex: "184", from: "0x49d776ed2d6fcfe2078805b18ea6fd01ca6d1266", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "112924", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe921b4f80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5981975", gasUsed: "111189", confirmations: "1180430"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "referee", value: addressList[0]}], name: "buyByAddress", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByAddress(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540197182 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x49d776ed2d6fcfe2078805b18ea6fd01ca6d1266"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0x97397c2129517f82031a28742247465bc75e1849"}, {name: "referrered", type: "address", value: "0x49d776ed2d6fcfe2078805b18ea6fd01ca6d1266"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "40731315490696518" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: setName( `play` )", async function( ) {
		const txOriginal = {blockNumber: "6561545", timeStamp: "1540198023", hash: "0x1e21bdf7b03a45733a111a8a0679edf5fa80b724cdc8876f91cebf1a4ef07a31", nonce: "676", blockHash: "0xabe4a1cb08f6a6eb614932e9257fac4f1a53299550820cc66e1717c314ae2f0c", transactionIndex: "43", from: "0x49d776ed2d6fcfe2078805b18ea6fd01ca6d1266", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "102804", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xc47f002700000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004706c617900000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2618533", gasUsed: "68536", confirmations: "1180374"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `play`}], name: "setName", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setName(string)" ]( `play`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540198023 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "40731315490696518" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6561844", timeStamp: "1540202042", hash: "0xd6ae09fe63ee6ff8971a6dc3b7cf8d38e7948041d36aa80e635876116d269865", nonce: "3", blockHash: "0x0357f6edf7b9fc864adabb68f98e4f59af8eca0b315fb1173e49e98a3e7b016b", transactionIndex: "87", from: "0x382672526a043e40ea0e886fdd8ac993d13361a2", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "89842", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4059647", gasUsed: "59895", confirmations: "1180075"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540202042 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x382672526a043e40ea0e886fdd8ac993d13361a2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x382672526a043e40ea0e886fdd8ac993d13361a2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "19715927575315573" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6561848", timeStamp: "1540202109", hash: "0xd1641ba5f380852b31d8d6a65be23f9786b2c684f3e3c6935e6cd9b721b1ecca", nonce: "6", blockHash: "0x39e3c8fcb1e28d873c3e92560d194d97620b114e38980380bf4f54d9aefa7422", transactionIndex: "150", from: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "120901", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5198402", gasUsed: "80601", confirmations: "1180071"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540202109 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2296816970237728" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6561856", timeStamp: "1540202219", hash: "0xa29ab590b0779350f7d08008b9479d1fbc5665adcae4c2f4f112f1aa3630ec65", nonce: "12", blockHash: "0xcdf0e661337da27cd87de653fc437cca223607429fb38479a035ea1ae9e002f2", transactionIndex: "82", from: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "368653", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7833524", gasUsed: "230769", confirmations: "1180063"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540202219 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x382672526a043e40ea0e886fdd8ac993d13361a2"}, {name: "numberOfStage", type: "uint256", value: "7"}, {name: "deadIndex", type: "uint8", value: "1"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "BraveWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveWithdraw", events: [{name: "player", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "amount", type: "uint256", value: "98000000000000000"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "8059353000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6561931", timeStamp: "1540203404", hash: "0xefca0864ce815a1fcaabcef04e420eab4ec63cc89602ef18149831954a2e173f", nonce: "677", blockHash: "0xf5595ca4b2dbb4718b7520d007bc67fb3b7c71a5a1e1d07b8d33a9ede652da4c", transactionIndex: "134", from: "0x49d776ed2d6fcfe2078805b18ea6fd01ca6d1266", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "59203", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "7752703", gasUsed: "24469", confirmations: "1179988"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540203404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "BraveWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveWithdraw", events: [{name: "player", type: "address", value: "0x49d776ed2d6fcfe2078805b18ea6fd01ca6d1266"}, {name: "amount", type: "uint256", value: "130000000000000000"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "40731315490696518" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6562095", timeStamp: "1540205666", hash: "0xab883433aca3b3fa7877e2e5f71cc914101795f05bd19070e964cfa5ec2e0882", nonce: "6", blockHash: "0x3e7cc2319a64ced57f2f290aa3c5e1d4d872272e12cb69718a2759ac3e42c21b", transactionIndex: "80", from: "0x7af3f33c42e5b75c97b68c924871b5be273238ea", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "143701", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6414295", gasUsed: "95801", confirmations: "1179824"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540205666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "6849966072534310" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyByName( `home` )", async function( ) {
		const txOriginal = {blockNumber: "6562414", timeStamp: "1540210039", hash: "0x8828ec9bbfb2c18946d82a8eba0409d16b6437f67b65b4bc3dfb55afeb53f977", nonce: "32", blockHash: "0x5c2ea64db1778b2550928276fbad8336866cf5b6fba3ae8766bf05e4f1c1ba68", transactionIndex: "10", from: "0xea6bd82eacfc8373e7505bed34e689aa8b74a064", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "115822", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf2e7514c00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000004686f6d6500000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1550498", gasUsed: "77215", confirmations: "1179505"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `home`}], name: "buyByName", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByName(string)" ]( `home`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540210039 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0xea6bd82eacfc8373e7505bed34e689aa8b74a064"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0xea6bd82eacfc8373e7505bed34e689aa8b74a064"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "97525748607455235" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6562466", timeStamp: "1540210839", hash: "0x9fe53d2898668853f022bedc4379965d36bdf7107a99e576b3f3cf0bd331d6b8", nonce: "4", blockHash: "0xf9853c0fba11081818a44091446e274fcf0254d66728feb9be11374f73aefec5", transactionIndex: "83", from: "0x4be2b531bd4034cd1a7814313edb2f111d37721e", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "120901", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7886026", gasUsed: "80601", confirmations: "1179453"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540210839 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x4be2b531bd4034cd1a7814313edb2f111d37721e"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x4be2b531bd4034cd1a7814313edb2f111d37721e"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "58432947094178977" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6562478", timeStamp: "1540210976", hash: "0xe3078b9efa4abd4058091624448a2bb6966e3dce3a15e9e310fd790590c3ebc8", nonce: "7", blockHash: "0x56baad5e378580df8a2e1faac7b456e0f4d9ebfa7e8162bc095e7ebef00e9e49", transactionIndex: "24", from: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "429700", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5905584", gasUsed: "286467", confirmations: "1179441"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540210976 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x4be2b531bd4034cd1a7814313edb2f111d37721e"}, {name: "numberOfStage", type: "uint256", value: "8"}, {name: "deadIndex", type: "uint8", value: "2"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2296816970237728" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setName( `yin2018` )", async function( ) {
		const txOriginal = {blockNumber: "6562502", timeStamp: "1540211288", hash: "0x532e4e2f54fcd51332686eb8a4fb5ad70750ce03997d1772749dac85833642a5", nonce: "33", blockHash: "0x29e0d97cd9789547275e8c8ad8efc4307790146907aebdfdfd3c48b37a3fb412", transactionIndex: "101", from: "0xea6bd82eacfc8373e7505bed34e689aa8b74a064", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "103092", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xc47f00270000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000779696e3230313800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7918167", gasUsed: "68728", confirmations: "1179417"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "name", value: `yin2018`}], name: "setName", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setName(string)" ]( `yin2018`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540211288 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "97525748607455235" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6563098", timeStamp: "1540220229", hash: "0x919d873cb2d02d20a67914aed9fb63b314a09927f2af0416ab4e5956acbee869", nonce: "1532", blockHash: "0xbcc38ecbe182c653fa60b9f270c3898bf47c13c7cea623291113c4131d877451", transactionIndex: "41", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "89842", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1605175", gasUsed: "59895", confirmations: "1178821"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540220229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0x97397c2129517f82031a28742247465bc75e1849"}, {name: "referrered", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buyByAddress( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6563479", timeStamp: "1540225804", hash: "0xd0fe0a653702eec4fb263afc3ec8774d313498cb6ef8337b2b760e1f5f7a999b", nonce: "6", blockHash: "0x072ace1fc444fee369d6a36ed882dd69febaa052d47faef471b47d190b358fb1", transactionIndex: "134", from: "0x3c0852790afda3cd3bb20089b5d448084da37d7b", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "82171", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe921b4f80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6979669", gasUsed: "75487", confirmations: "1178440"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "referee", value: addressList[0]}], name: "buyByAddress", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByAddress(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540225804 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x3c0852790afda3cd3bb20089b5d448084da37d7b"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x3c0852790afda3cd3bb20089b5d448084da37d7b"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "2175873979533142" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6563554", timeStamp: "1540226972", hash: "0xdf9d00f7f71e5f4b2ec66bdd1264e70ba0bde3ef8b7a6cc0de5a533e6b41f1c5", nonce: "1534", blockHash: "0xf20fe86ca47ca4b5587afe100f4cb7d8febc19b9c6820e6c396bb30c54c1016b", transactionIndex: "6", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "368653", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "506859", gasUsed: "230769", confirmations: "1178365"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540226972 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "numberOfStage", type: "uint256", value: "9"}, {name: "deadIndex", type: "uint8", value: "0"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "BraveWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveWithdraw", events: [{name: "player", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "amount", type: "uint256", value: "30000000000000000"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6563628", timeStamp: "1540228085", hash: "0x2852f5f9c8704a565d1e60b7c27642e6bf34d593047a2c30605e5153358ea601", nonce: "1535", blockHash: "0xbd202369f4c63a3f7f8be5df0809b11dc256ddd3f53a405be3fc0cdc0665f498", transactionIndex: "46", from: "0x95096780efd48fa66483bc197677e89f37ca0cb5", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "59203", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "1473246", gasUsed: "24469", confirmations: "1178291"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540228085 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "BraveWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveWithdraw", events: [{name: "player", type: "address", value: "0x95096780efd48fa66483bc197677e89f37ca0cb5"}, {name: "amount", type: "uint256", value: "130000000000000000"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "34435382193062262" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw(  )", async function( ) {
		const txOriginal = {blockNumber: "6565692", timeStamp: "1540256779", hash: "0xded825a337ae32dd518eaaae1a15c03bc3c6ac0fbebcf74418134a6786b8bbe6", nonce: "11", blockHash: "0x91203fa9b9bb5d786d66ed746789cfe0c243fa19c2e4ca80e36139aa9f8119b6", transactionIndex: "51", from: "0x843eeae449f87d27011eb5c30459c4e904b7c367", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "59203", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x3ccfd60b", contractAddress: "", cumulativeGasUsed: "3075490", gasUsed: "24469", confirmations: "1176227"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540256779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: true, name: "amount", type: "uint256"}], name: "BraveWithdraw", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveWithdraw", events: [{name: "player", type: "address", value: "0x843eeae449f87d27011eb5c30459c4e904b7c367"}, {name: "amount", type: "uint256", value: "30001563323729679"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "331053106804620" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6565852", timeStamp: "1540258868", hash: "0x0e9b6181c776dd7eab1679e6b16fe0a283c15335efcc9c4713a4ae8f394092e4", nonce: "7", blockHash: "0x81592cdb58138b9b09b10fdbf2dbab3812584ea87d865935df9ce946ce11989e", transactionIndex: "64", from: "0x7af3f33c42e5b75c97b68c924871b5be273238ea", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "143701", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2977504", gasUsed: "95801", confirmations: "1176067"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540258868 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "6849966072534310" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6565858", timeStamp: "1540258937", hash: "0x018fc45fb418feac39f48a84563a1bf328fdd4cc5550510fb8b41b90188e99b1", nonce: "4", blockHash: "0x4f09e0f80a4194630276f68fb61737bb0e6e75b7d1b05b1a3458e1127e0a8825", transactionIndex: "183", from: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "89842", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4247891", gasUsed: "59895", confirmations: "1176061"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540258937 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "97121091981492025" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6565862", timeStamp: "1540258984", hash: "0xf7f720c15ec4c219c2dd60a59af94709a460a210364ce7c621cb973273e394d2", nonce: "4", blockHash: "0x6b3ecf9580c3584b0027392669e55bb095041c7ce686841e156bf1c9df9ee228", transactionIndex: "53", from: "0xf60b28d4c2b230c9be094b48ac7c7ff56fe935cb", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "89842", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7084509", gasUsed: "80601", confirmations: "1176057"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540258984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0xf60b28d4c2b230c9be094b48ac7c7ff56fe935cb"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0xf60b28d4c2b230c9be094b48ac7c7ff56fe935cb"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1883983025050693" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buyByAddress( addressList[0] )", async function( ) {
		const txOriginal = {blockNumber: "6565868", timeStamp: "1540259073", hash: "0xb628f17114f86bfb10f056bb0b56afb70d4654dc4bbe7b4e72406a5a0c027253", nonce: "8", blockHash: "0x3d3133ad66d19f269d8fc1d1037b4659c5321b46b0b994cf4620df61a2f80265", transactionIndex: "29", from: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "100000000000000000", gas: "399529", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe921b4f80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2945940", gasUsed: "266353", confirmations: "1176051"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "referee", value: addressList[0]}], name: "buyByAddress", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyByAddress(address)" ]( addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540259073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "deadPlayer", type: "address"}, {indexed: false, name: "numberOfStage", type: "uint256"}, {indexed: true, name: "deadIndex", type: "uint8"}, {indexed: false, name: "rate", type: "uint8"}], name: "BraveDeadPlayer", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveDeadPlayer", events: [{name: "deadPlayer", type: "address", value: "0x46ec8bdd6ea5ae3ecf26ed60abde58138511df7f"}, {name: "numberOfStage", type: "uint256", value: "10"}, {name: "deadIndex", type: "uint8", value: "1"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x60809f5a0bf6c6763d763b529ea2b106312b68bf"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "2296816970237728" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buyFromValue( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6565879", timeStamp: "1540259260", hash: "0x7d3bef4cd4520ea8e3fb7e36515de18435f6043180fb9d32183ef978672a7c8d", nonce: "8", blockHash: "0x605ef4a9993cf1872ecf74db52c91d273ffb3dae7c8833efc6514fdbf844f0dc", transactionIndex: "71", from: "0x7af3f33c42e5b75c97b68c924871b5be273238ea", to: "0x132e2b67e91bf0294536b16d772e8dee099fc40c", value: "0", gas: "89842", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x35ad84f90000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2890660", gasUsed: "59895", confirmations: "1176040"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "rate", value: "1"}], name: "buyFromValue", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyFromValue(uint8)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540259260 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "player", type: "address"}, {indexed: false, name: "rate", type: "uint8"}], name: "BravePlayer", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BravePlayer", events: [{name: "player", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "referrer", type: "address"}, {indexed: true, name: "referrered", type: "address"}, {indexed: true, name: "rate", type: "uint8"}], name: "BraveReferrer", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BraveReferrer", events: [{name: "referrer", type: "address", value: "0xdc489b03869dfca0d53cbcca3b486156eee3d5fe"}, {name: "referrered", type: "address", value: "0x7af3f33c42e5b75c97b68c924871b5be273238ea"}, {name: "rate", type: "uint8", value: "1"}], address: "0x132e2b67e91bf0294536b16d772e8dee099fc40c"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "6849966072534310" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "172087724080820948" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
