const BaFa = artifacts.require( "./BaFa.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BaFa" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xF9845744A35Eb90666b648DBB38bC2B9a6ECCcDf", "0xf4AA26bdb9C45fF850c76E47118188c808e03A35", "0x23f203B707D38e621883a5EA25F7064034329270", "0xBCB229d5a55D6B150c2D22eb671563A8d6060f9b", "0x8d12A197cB00D4747a1fe03395095ce2A5CC6819", "0x0a2f5Dfb5a31642493028C4312E90F2C057F5069", "0x71e0083A42196576E29b64a37ce91209b1911C9f", "0xf87E1F06097bE4F5a426394b8bFd57d022D8e80a", "0x9864458E7133316e10dF7E2c4D006d35aa861A3E", "0xF5d162ae2e34bE14b474e0d29CD1079fa13c9893", "0xdcDe00E24e44d0291C656d7ad16465289365Ca03", "0xA14c6E02CC47492436Bf8CB3652dFc3BeD47e0FF", "0x3439Ea50eD00e9Ba69D195eb0B5b403b3ba5FbA2", "0x890fB358a28F43F014244BAa59C609f00C921Def", "0x81DF114B711dCf8E5C539870100367c5bC98c29d", "0x104B8743D50f914Ec83648eEa2b6B87339Fac8A2", "0xEdF96D80281019A6735968316C57BCc3a271AbC5", "0x70bbA812C3C4b0E386feEBAF2a220C5168F8ce77", "0x080B35710Dc43bf16c8CBCd01731A4D5981Aa1A2", "0x402211F50A86304784a40ADd3E5C8c25395371db", "0x0B375A2B77e80122332df874FC61636DD5eC8bDF", "0xFa966fE7C672054BD1A629Ff0b4A5971De2EdCf9", "0x7B878C0B68f5903EB3802d84adf39684bE3f97a5", "0x75fd09792cC1fd8421aFE069AdFfC846F323fEb3", "0x69B9ECC63d5f2DC05D846Daed51c556A997B8d8A", "0xeCF50FA02188c92393ebD3F3afFdFaE84EA679Af", "0x543A235A9515B2B10489BCCD1A0287F34DF5848c", "0xAcF141FbA61E182006C80A2b170CB21190033614", "0xE673B1EA0C5d49462Ce27CFf1d58177AF5dE7DfA", "0x006415A0e2d3effEa86cd231b88F77b9473c3565", "0xb4066e3F167A4E5b7B97cCA2b163eE396cfD0A1d", "0x2eE28A4E6590074deCb418d511E6067053228feA", "0x5A688B5Ec3DEdB3f2798FbE8ec258C1E7A7F18aB", "0xbE77C7Bac4faE314e7A3629571E09102DE87A8Dd", "0x53837F8Fb1D142Ef0C01b976519a2a3E3048CD77", "0x46D2f6Cee3175Aa986F262D3731FcF2521f728a7", "0xC063EBD91222b8F4862621d6014cf90E9579F495", "0xF15EE7283F334548D2b0a7dB7a4f70c2487942cb", "0xE7a7591F718f18986Dea97af0A0fF68b23C8353F", "0x567a965250a94A9cd93e76bd4E985FDda7e06efB", "0x9b072DaF558fB87322fBB1877eb6724D5e0B9129", "0x47F216fbf2aB34b60dF39da5Ef7e73d76421EC95", "0xC6Fc6835cE16679C89567C0B33604D1e9A71Bf99", "0x658AcDD5063fA27fE816f3923c7426A29Cb2421B", "0x008cd39b569505e006EC93689aDd83999E96aB12", "0x8aE7ed767bab3335D736fA36CAfDFc90034f6DAa"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "INITIAL_SUPPLY", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Approval(address,address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4422007 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4424557 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "BaFa", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "INITIAL_SUPPLY", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "INITIAL_SUPPLY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BaFa", function( accounts ) {

	it( "TEST: BaFa(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4422007", timeStamp: "1508867158", hash: "0xb9e4436b20b645e8457fb6dc18408d4c86ff1fab1863fdf41f45f1cfcb2c9334", nonce: "0", blockHash: "0x75e2a3ba094cecb698efb6e8dfbf52f5ae0424c6655a2d1141df008b279bacfd", transactionIndex: "122", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: 0, value: "0", gas: "1043485", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x9371fbd0", contractAddress: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", cumulativeGasUsed: "4512815", gasUsed: "1043485", confirmations: "3303041"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "BaFa", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BaFa.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508867158 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BaFa.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[4], \"844400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422039", timeStamp: "1508867578", hash: "0xc2167186a5d2dc4cac1df0cd43d4228c03bb63adf98df49a35b0eb12be4c8d72", nonce: "1", blockHash: "0x2fc34c7c40b6ca3dd08862450b6c72c193f2637ead5a678568d8d6eca9b349e2", transactionIndex: "91", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51402", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000023f203b707d38e621883a5ea25f7064034329270000000000000000000000000000000000000000000000000000000c49a297c00", contractAddress: "", cumulativeGasUsed: "5314550", gasUsed: "51402", confirmations: "3303009"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_value", value: "844400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[4], "844400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1508867578 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x23f203b707d38e621883a5ea25f7064034329270"}, {name: "value", type: "uint256", value: "844400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[5], \"844400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422078", timeStamp: "1508868187", hash: "0xb19e273fd58a92cc7ac53c2598020d8d41cae4e27e06f292ec1305b727431aac", nonce: "2", blockHash: "0xf5c5231f2bf85e2161f98a686aec41909d225ba05a59c905916d9d1f081776c9", transactionIndex: "18", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51402", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000bcb229d5a55d6b150c2d22eb671563a8d6060f9b000000000000000000000000000000000000000000000000000000c49a297c00", contractAddress: "", cumulativeGasUsed: "3814244", gasUsed: "51402", confirmations: "3302970"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_value", value: "844400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[5], "844400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1508868187 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xbcb229d5a55d6b150c2d22eb671563a8d6060f9b"}, {name: "value", type: "uint256", value: "844400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[6], \"844400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422125", timeStamp: "1508868751", hash: "0xecc443296f680439d70407863d3632c0ad21fb2d00e9930767215dccb34185dc", nonce: "0", blockHash: "0x1c540685aa57fcdaf6f20ea6a1eeed821557ab81e07b7481c58c8cc2ec8f6ef7", transactionIndex: "132", from: "0xbcb229d5a55d6b150c2d22eb671563a8d6060f9b", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "250000", gasPrice: "200000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000c49a297c00", contractAddress: "", cumulativeGasUsed: "6070105", gasUsed: "45756", confirmations: "3302923"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[6]}, {type: "uint256", name: "_value", value: "844400000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[6], "844400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1508868751 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xbcb229d5a55d6b150c2d22eb671563a8d6060f9b"}, {name: "spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "value", type: "uint256", value: "844400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "931473800000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[7], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422510", timeStamp: "1508873819", hash: "0x13ee794d31891d3b1ed00cbe15c5aca39703aa81530ba8541bb4160b48af0ece", nonce: "5", blockHash: "0x6221c9ac724e9c2f83beb39baa794eb65a17a8c3930c6bd33f6b5dee5df725c0", transactionIndex: "47", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "200000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000a2f5dfb5a31642493028c4312e90f2c057f5069000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6664349", gasUsed: "51338", confirmations: "3302538"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[7], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508873819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x0a2f5dfb5a31642493028c4312e90f2c057f5069"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422524", timeStamp: "1508873997", hash: "0x03c87843caa817cd49a788714bc4f575049830253c261bea87e9af0acd42fd94", nonce: "6", blockHash: "0x81b5eb33a70ace9d5457c2a84d8b7bc2ef4432269882ba198efee29efef23561", transactionIndex: "45", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "200000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000071e0083a42196576e29b64a37ce91209b1911c9f000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "5591731", gasUsed: "51338", confirmations: "3302524"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508873997 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x71e0083a42196576e29b64a37ce91209b1911c9f"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], \"3200000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422695", timeStamp: "1508876127", hash: "0xcd7e4bb63f8ff89a7aecf128e192a8d70352a0d8e59ac6f8e2fa9022b94584bb", nonce: "7", blockHash: "0xc28bb170d916a1d54f9fb950e2ea880f8e60192be7b141b61c4a2ec8133c0daf", transactionIndex: "61", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "200000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000f87e1f06097be4f5a426394b8bfd57d022d8e80a00000000000000000000000000000000000000000000000000000000bebc2000", contractAddress: "", cumulativeGasUsed: "3970349", gasUsed: "51338", confirmations: "3302353"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_value", value: "3200000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[9], "3200000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508876127 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xf87e1f06097be4f5a426394b8bfd57d022d8e80a"}, {name: "value", type: "uint256", value: "3200000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[10], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422719", timeStamp: "1508876478", hash: "0xeea9ffa6dcf5913684990d2b658a1824ae00281ed33da3a3355979cb2d488cd5", nonce: "8", blockHash: "0x0b8169b9a7f5419a10adb81cb72587e8ee3103a724877ec57ba5caa74576f89e", transactionIndex: "159", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51274", gasPrice: "200000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000009864458e7133316e10df7e2c4d006d35aa861a3e000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6649541", gasUsed: "51274", confirmations: "3302329"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[10], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1508876478 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x9864458e7133316e10df7e2c4d006d35aa861a3e"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[11], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422746", timeStamp: "1508876833", hash: "0x8a1932aedb9493f6f531b0441762c940d81e829fb8fc7794912a2fa6df81dc2c", nonce: "9", blockHash: "0xdcf6e5feda3e2d48a2183d3df68542a71a22896b6ce1bdd96a724c36eba43973", transactionIndex: "49", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "200000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000f5d162ae2e34be14b474e0d29cd1079fa13c9893000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6674021", gasUsed: "51338", confirmations: "3302302"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[11], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508876833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xf5d162ae2e34be14b474e0d29cd1079fa13c9893"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[12], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422783", timeStamp: "1508877396", hash: "0xc96fcafb2e520c96ac965a7bb85e1a89e2aae8cb2f7ff22534b74b313a8ff12b", nonce: "10", blockHash: "0x4cb0722c076ff9df35525f1bcc2789773c406d3dd198d42577c8e58a9a41520e", transactionIndex: "69", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "200000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000dcde00e24e44d0291c656d7ad16465289365ca03000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "4353539", gasUsed: "51274", confirmations: "3302265"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[12], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1508877396 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xdcde00e24e44d0291c656d7ad16465289365ca03"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[13], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422902", timeStamp: "1508878942", hash: "0x57e5b1b0d3a36f7ca2b51635e55e9754930fbeea8b32b6f5882a1ec2d7acac08", nonce: "11", blockHash: "0x66b15440e2f90383d9652ea3035c6a2a7ca41e236727c295f795f3d1548924eb", transactionIndex: "30", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000a14c6e02cc47492436bf8cb3652dfc3bed47e0ff000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6506101", gasUsed: "51338", confirmations: "3302146"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[13], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508878942 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xa14c6e02cc47492436bf8cb3652dfc3bed47e0ff"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[14], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4422944", timeStamp: "1508879426", hash: "0x6c40f43817f204ec0efd6fb8f7d573fa611fe89e52f4d3c4df9010ebd280729e", nonce: "12", blockHash: "0x4b5d3965933bf795e73a5a6f15c83824c37e7a3917af04445b3b7bd63c285911", transactionIndex: "109", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51274", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000003439ea50ed00e9ba69d195eb0b5b403b3ba5fba2000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6723061", gasUsed: "51274", confirmations: "3302104"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[14], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1508879426 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x3439ea50ed00e9ba69d195eb0b5b403b3ba5fba2"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423021", timeStamp: "1508880438", hash: "0xba10d102ef406ac184ea5368d38fc873153b0d4264210bdf31457f4bae2d0190", nonce: "13", blockHash: "0xd64a116765276e468a02971bd37eb050069ecdbe263e0f44576751eb06b7aefe", transactionIndex: "21", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000890fb358a28f43f014244baa59c609f00c921def000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "4888936", gasUsed: "51338", confirmations: "3302027"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[15], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508880438 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x890fb358a28f43f014244baa59c609f00c921def"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[6], \"100000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423052", timeStamp: "1508880761", hash: "0xd828555db7c7a43f6193b04624ea43a09b3f69de5b54cafb91bb98b4dcdddcc3", nonce: "0", blockHash: "0x65d8c5ab16a227a2cca6fc0d08b4b4f3ee8aae9c2ffda5354fbbbbad11e7a163", transactionIndex: "13", from: "0x23f203b707d38e621883a5ea25f7064034329270", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "250000", gasPrice: "500000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000174876e800", contractAddress: "", cumulativeGasUsed: "3691977", gasUsed: "45756", confirmations: "3301996"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[6]}, {type: "uint256", name: "_value", value: "100000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[6], "100000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1508880761 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0x23f203b707d38e621883a5ea25f7064034329270"}, {name: "spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "value", type: "uint256", value: "100000000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "155208515120000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[16], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423074", timeStamp: "1508881184", hash: "0xa65ca6017b5e2aef798720fc973299230cf9d10078878f4e389af881dbf45fb5", nonce: "14", blockHash: "0x58903a6a12819c2fd4c0e265f7f37e52b594261b3e9caaffd1e56a7f20e4f813", transactionIndex: "78", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000081df114b711dcf8e5c539870100367c5bc98c29d000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "3722193", gasUsed: "51338", confirmations: "3301974"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[16], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1508881184 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x81df114b711dcf8e5c539870100367c5bc98c29d"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[17], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423101", timeStamp: "1508881646", hash: "0xdd99d8f92834fa8fbce7d1731fe38f704589e0683cd0fde3e7e97b0ebce809ba", nonce: "15", blockHash: "0xeac2d2d07a4fbd2c5c02b3f7e9baa6d86e9e5ede14de806aaa927d02fce955e9", transactionIndex: "189", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000104b8743d50f914ec83648eea2b6b87339fac8a2000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "5183075", gasUsed: "51338", confirmations: "3301947"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[17], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1508881646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x104b8743d50f914ec83648eea2b6b87339fac8a2"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[18], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423109", timeStamp: "1508881756", hash: "0xa0d853e4fd982b70098922df2fe73aad30121c5671226d78edb6a3a2a7dc69cd", nonce: "16", blockHash: "0x10c305f13db0b31e220deda0850d27f57ed91ee5e5eb86d1590559aac8339ddc", transactionIndex: "26", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000edf96d80281019a6735968316c57bcc3a271abc5000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "4851612", gasUsed: "51338", confirmations: "3301939"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[18]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[18], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1508881756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xedf96d80281019a6735968316c57bcc3a271abc5"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[19], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423126", timeStamp: "1508881922", hash: "0xbf34c165ef25678c26ab85b0c225e2f355a53dccea7d34aac64cb6ac58e3830f", nonce: "17", blockHash: "0x00da4a6288b22ab550888092b9f5ac8a32d9d933ed6d555a19f101b530720ea3", transactionIndex: "48", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000070bba812c3c4b0e386feebaf2a220c5168f8ce77000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "4410498", gasUsed: "51338", confirmations: "3301922"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[19]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[19], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1508881922 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x70bba812c3c4b0e386feebaf2a220c5168f8ce77"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[6], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423147", timeStamp: "1508882315", hash: "0x07025b7c52a1618a2a93bf2b364127a8e6460e644755779f578882f843031903", nonce: "87", blockHash: "0xe50ff3b7fa471ddfbe0e29ab37594df85e97b082177e523ff928cb1f3450bd71", transactionIndex: "121", from: "0xedf96d80281019a6735968316c57bcc3a271abc5", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "5105979", gasUsed: "45692", confirmations: "3301901"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[6]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[6], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1508882315 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xedf96d80281019a6735968316c57bcc3a271abc5"}, {name: "spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "110532322879960366" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[6], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423148", timeStamp: "1508882364", hash: "0x57ace5d26948625856423cee430011f118b631bf4324cf7f6c61068c813b8cf5", nonce: "89", blockHash: "0x3a2f00f4a716df6e5649a86c7fdd50cb6a0d855d793ce84904df4eed88d4dba5", transactionIndex: "118", from: "0xedf96d80281019a6735968316c57bcc3a271abc5", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "250000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000008d12a197cb00d4747a1fe03395095ce2a5cc6819000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6436264", gasUsed: "45692", confirmations: "3301900"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[6]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[6], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508882364 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xedf96d80281019a6735968316c57bcc3a271abc5"}, {name: "spender", type: "address", value: "0x8d12a197cb00d4747a1fe03395095ce2a5cc6819"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "110532322879960366" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[20], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423169", timeStamp: "1508882625", hash: "0x27448888f86d302f1a6ed97c6a92c262714c554205ea9382df58d31ca63caa22", nonce: "18", blockHash: "0x9fc6b50329dd43299824fc90d724e96e9a074868961456d593dac5935ec0c3f7", transactionIndex: "59", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000080b35710dc43bf16c8cbcd01731a4d5981aa1a2000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "2535468", gasUsed: "51338", confirmations: "3301879"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[20], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1508882625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x080b35710dc43bf16c8cbcd01731a4d5981aa1a2"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[21], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423255", timeStamp: "1508884063", hash: "0xc94ecfd2476348ec931cff3811a11e1437ccea97fd76cc407d8d6a9b9574b837", nonce: "19", blockHash: "0xad7926a9d66423ba09ccd99b5e78b7d3bddb105b1bcdaa276716b19c88ac4bb8", transactionIndex: "44", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000402211f50a86304784a40add3e5c8c25395371db000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6632675", gasUsed: "51338", confirmations: "3301793"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[21], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1508884063 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x402211f50a86304784a40add3e5c8c25395371db"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[22], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423275", timeStamp: "1508884341", hash: "0xa01fc953847d13bc3fec10065f7ed85b7526519101e46d03e0b663a7d824331c", nonce: "20", blockHash: "0x8545ccae9382b408eb189b21623e5eb907afecca46ee1897e3d9d8ecc28d27f7", transactionIndex: "64", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "400000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000000b375a2b77e80122332df874fc61636dd5ec8bdf000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6644172", gasUsed: "51338", confirmations: "3301773"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[22]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[22], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1508884341 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x0b375a2b77e80122332df874fc61636dd5ec8bdf"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423835", timeStamp: "1508891796", hash: "0x80b59ceddd840b3d4aa26a07f179cfc3b668e3dc41e51763886fef695d75a2a8", nonce: "21", blockHash: "0x432423c8fc5535fc83c9d7c833de5e642c897e66ed1159e4317acce91db5bff8", transactionIndex: "62", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000fa966fe7c672054bd1a629ff0b4a5971de2edcf9000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "5303049", gasUsed: "51338", confirmations: "3301213"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1508891796 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xfa966fe7c672054bd1a629ff0b4a5971de2edcf9"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[23], \"1200000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423842", timeStamp: "1508891948", hash: "0x45e0cceac0e0cc31cda44ab5f183e300331fc8365737a93b728219c7ee8d9c95", nonce: "22", blockHash: "0xd2c323f1bfa99696541f6b78846493d20a1afd92e3d74fe17372eae0694baeef", transactionIndex: "36", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "36338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000fa966fe7c672054bd1a629ff0b4a5971de2edcf90000000000000000000000000000000000000000000000000000000047868c00", contractAddress: "", cumulativeGasUsed: "5021582", gasUsed: "36338", confirmations: "3301206"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "1200000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[23], "1200000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1508891948 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xfa966fe7c672054bd1a629ff0b4a5971de2edcf9"}, {name: "value", type: "uint256", value: "1200000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[24], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423854", timeStamp: "1508892122", hash: "0xf0be8c2481025ad5f45fe633dde3eb2617ec6b543a8c1c75a0c5e96dfd32d7ff", nonce: "23", blockHash: "0xdcb2dc214ad36d83784d0c55a40d7cb1be9f89504a7b02d8ba2331f9b57e6b56", transactionIndex: "148", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000007b878c0b68f5903eb3802d84adf39684be3f97a5000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6713746", gasUsed: "51338", confirmations: "3301194"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[24], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1508892122 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x7b878c0b68f5903eb3802d84adf39684be3f97a5"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[25], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423871", timeStamp: "1508892422", hash: "0xc3b685c1c8467970266847a665b45cec77bd860e74329c78a616e8704e544016", nonce: "24", blockHash: "0xc3b32bff3a8f58fa3dae910d5c4487b5a07db747aea4d84080b38ae2fef9e6c6", transactionIndex: "84", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000075fd09792cc1fd8421afe069adffc846f323feb3000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "3796837", gasUsed: "51338", confirmations: "3301177"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[25], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1508892422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x75fd09792cc1fd8421afe069adffc846f323feb3"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[26], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423882", timeStamp: "1508892501", hash: "0xee6178b83dd15bbaec496a9349c97d59497d5949cacdebd01ad20949c486e857", nonce: "25", blockHash: "0xc53921fc566c56a06ecddb21e1e403e1dc61d0f0eef0d5506d6cfe573ae5c7ff", transactionIndex: "76", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000069b9ecc63d5f2dc05d846daed51c556a997b8d8a000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "3106889", gasUsed: "51338", confirmations: "3301166"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[26], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1508892501 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x69b9ecc63d5f2dc05d846daed51c556a997b8d8a"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423932", timeStamp: "1508893053", hash: "0xddfb8a253f5b6f4670d74708efdffd8dcfdacea6196b58c51e891638cd82da72", nonce: "26", blockHash: "0x12ddcc379b45d22f1de14411c4d04d1fca88637804d0f80992ae2487a73a5976", transactionIndex: "71", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000ecf50fa02188c92393ebd3f3affdfae84ea679af000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "3431236", gasUsed: "51338", confirmations: "3301116"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[27], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1508893053 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xecf50fa02188c92393ebd3f3affdfae84ea679af"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[28], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423945", timeStamp: "1508893331", hash: "0x48e21c64b54886a1234f67a1ea4fe585f69e85f8c00b8e77549880733f8d4f45", nonce: "27", blockHash: "0xd4db72ad561f0c2ee8f3b304164abd6bc395df2938e6fb2775229d17f8217061", transactionIndex: "126", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000543a235a9515b2b10489bccd1a0287f34df5848c000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6716263", gasUsed: "51338", confirmations: "3301103"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[28], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1508893331 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x543a235a9515b2b10489bccd1a0287f34df5848c"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423965", timeStamp: "1508893619", hash: "0xd5a46a7aec2fd1f70e5850e165b158d5e9fb92b0336d74cdd913ba750667ae4a", nonce: "28", blockHash: "0xabb73be3986c5ab8c40cc4d298980792fa11a27a3d046beef4beb8eb8f181054", transactionIndex: "103", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000acf141fba61e182006c80a2b170cb21190033614000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "4688592", gasUsed: "51338", confirmations: "3301083"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[29], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1508893619 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xacf141fba61e182006c80a2b170cb21190033614"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[30], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4423991", timeStamp: "1508893894", hash: "0xf9f07da00ee6fdcf206e0f47ed3faf58ad0b9a0c7edf46d631a3009dae67b2c0", nonce: "29", blockHash: "0x63cd53ff33382a96cd92889da1568121e24ee30f69bf3f9e7e3bb85cc76a7c33", transactionIndex: "30", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000e673b1ea0c5d49462ce27cff1d58177af5de7dfa000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "4209569", gasUsed: "51338", confirmations: "3301057"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[30], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1508893894 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xe673b1ea0c5d49462ce27cff1d58177af5de7dfa"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[31], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424093", timeStamp: "1508895293", hash: "0x1b0eb43966847aec72801b02579eacdba94b529064f03a9369cf27b274a0c08d", nonce: "30", blockHash: "0x99f70fe6460e644e416fd045d838b187fcce5891abfa2f7d4bc86321b7158ab3", transactionIndex: "68", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51274", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000006415a0e2d3effea86cd231b88f77b9473c3565000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6731769", gasUsed: "51274", confirmations: "3300955"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[31], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1508895293 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x006415a0e2d3effea86cd231b88f77b9473c3565"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[32], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424107", timeStamp: "1508895463", hash: "0xcc31f2599da138c54f17bcfbc9b47ac9ef1796dd867903aa150482f4e200e150", nonce: "31", blockHash: "0x0a71e0dd23edc76ad6898f4cb746c4ab4a61fc095d265ff77684b3771b6d10dd", transactionIndex: "41", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000b4066e3f167a4e5b7b97cca2b163ee396cfd0a1d000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "4933460", gasUsed: "51338", confirmations: "3300941"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[32], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1508895463 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xb4066e3f167a4e5b7b97cca2b163ee396cfd0a1d"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[33], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424160", timeStamp: "1508896299", hash: "0x0a0a402c43bad616c33e13336600e1c55e6e2aa92123c52cab86c77cde540bdb", nonce: "32", blockHash: "0x48871804877681da7155caccb254ac099eabd3c17b52a587a9dad8b79a297dcf", transactionIndex: "182", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000002ee28a4e6590074decb418d511e6067053228fea000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6695053", gasUsed: "51338", confirmations: "3300888"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[33]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[33], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1508896299 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x2ee28a4e6590074decb418d511e6067053228fea"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[34], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424172", timeStamp: "1508896424", hash: "0xb4b2c4dc1063ad41a9d3e3d9d56c02027eb3c225855d46730a7326c94a0c710a", nonce: "33", blockHash: "0x8dab175aa17279f656e71df2abbe5ff6c214e57872aeb2bf631eb78870d5b30b", transactionIndex: "32", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000005a688b5ec3dedb3f2798fbe8ec258c1e7a7f18ab000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "4303956", gasUsed: "51338", confirmations: "3300876"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[34], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1508896424 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x5a688b5ec3dedb3f2798fbe8ec258c1e7a7f18ab"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[35], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424189", timeStamp: "1508896642", hash: "0x90c5abdf5fa9f9c4c4f62affb585566305edb400063c9515446b07ed9fa61377", nonce: "34", blockHash: "0xfe5eadbdea8f1eab8d1f1aee48b868c0daf94471cb95818bda5455ca00b825e0", transactionIndex: "60", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000be77c7bac4fae314e7a3629571e09102de87a8dd000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "5918878", gasUsed: "51338", confirmations: "3300859"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[35]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[35], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1508896642 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xbe77c7bac4fae314e7a3629571e09102de87a8dd"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[36], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424201", timeStamp: "1508896806", hash: "0x4147247ae0d402a7424345c1cbdbe39b8315156527da6419e5c83ff5edbdf130", nonce: "35", blockHash: "0x0e99552faf52db7b8d616548cec19be497d62e860696be7a170611664871e36c", transactionIndex: "118", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000053837f8fb1d142ef0c01b976519a2a3e3048cd77000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "5327512", gasUsed: "51338", confirmations: "3300847"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[36]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[36], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1508896806 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x53837f8fb1d142ef0c01b976519a2a3e3048cd77"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[37], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424213", timeStamp: "1508896982", hash: "0x2ac89fdec67cd3c7730e244de10090f130aa36b6ea1bf849ff4ecd75c22df2a2", nonce: "36", blockHash: "0x774f49604666de593c9957efd660942558bee7dff494a6fcc2d5c4a2057df16d", transactionIndex: "114", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000046d2f6cee3175aa986f262d3731fcf2521f728a7000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6708050", gasUsed: "51338", confirmations: "3300835"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[37]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[37], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1508896982 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x46d2f6cee3175aa986f262d3731fcf2521f728a7"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[38], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424222", timeStamp: "1508897153", hash: "0x48f2a226854120b94a30570010afa1c9d6957f97cebe5138b11c8cd2b9b5a027", nonce: "37", blockHash: "0x825cc5aec1c3eb57cb4958a222ce5316125301837e5d1eb5676fbfc3d2df5c80", transactionIndex: "171", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000c063ebd91222b8f4862621d6014cf90e9579f495000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6444038", gasUsed: "51338", confirmations: "3300826"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[38]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[38], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1508897153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xc063ebd91222b8f4862621d6014cf90e9579f495"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[39], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424233", timeStamp: "1508897332", hash: "0xc3a787fe803d9051f495343eca4820ea88c9f40d01d29e5ec1fa8aeccf43d742", nonce: "38", blockHash: "0xb31e7d3fa15396454fc4df9f5ccab9dc7502a767e7813fe6b1d21e01f095058b", transactionIndex: "106", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000f15ee7283f334548d2b0a7db7a4f70c2487942cb000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6713399", gasUsed: "51338", confirmations: "3300815"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[39], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1508897332 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xf15ee7283f334548d2b0a7db7a4f70c2487942cb"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[40], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424256", timeStamp: "1508897732", hash: "0x449250b7f0affc727a35789a909da928f6e315f82a0275a61d79377c1379b501", nonce: "39", blockHash: "0xb3430546b859f2585a65556cc23bf29ab2e33a9c9bd023e3922773afee15f802", transactionIndex: "149", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000e7a7591f718f18986dea97af0a0ff68b23c8353f000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "5012509", gasUsed: "51338", confirmations: "3300792"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[40], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1508897732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xe7a7591f718f18986dea97af0a0ff68b23c8353f"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[41], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424363", timeStamp: "1508899309", hash: "0xdae9fdaa09d188da2806fa395a2d69042ea3d14c5d4d3384a1aafcf6eb09bbd3", nonce: "40", blockHash: "0xab7a043227f51f153cdc91ca22919d26707c8fdc2c335297d28a12ee3204254d", transactionIndex: "142", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000567a965250a94a9cd93e76bd4e985fdda7e06efb000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6692197", gasUsed: "51338", confirmations: "3300685"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[41]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[41], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1508899309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x567a965250a94a9cd93e76bd4e985fdda7e06efb"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[42], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424371", timeStamp: "1508899422", hash: "0x77a1f932a5c62a12245610730a07950086f4799a39241615fab922db5730c61a", nonce: "41", blockHash: "0x492f55bf71550d49e09f653559142efdcc4a073b03c65907cb2dd24f2750141c", transactionIndex: "66", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "500000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000009b072daf558fb87322fbb1877eb6724d5e0b9129000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "3466558", gasUsed: "51338", confirmations: "3300677"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[42]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[42], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1508899422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x9b072daf558fb87322fbb1877eb6724d5e0b9129"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[43], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424389", timeStamp: "1508899679", hash: "0x389ad467a89bd6b1657540c6ac9710982b6e00d63aaa182b89dc295773c82d63", nonce: "42", blockHash: "0xac4ba75f4f559a9c672de2d12be4361b1943a5364447a7942b2b6f1290944d47", transactionIndex: "85", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000047f216fbf2ab34b60df39da5ef7e73d76421ec95000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "3928710", gasUsed: "51338", confirmations: "3300659"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[43]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[43], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1508899679 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x47f216fbf2ab34b60df39da5ef7e73d76421ec95"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[44], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424393", timeStamp: "1508899780", hash: "0xc80c291041a085e9fcdbfcdd99ac5c00238ae936af69d2b7c431b15b7af8579c", nonce: "43", blockHash: "0xfb460ed2ddf8f1b2d997ac670e9ed99847ff2846ee85adbafe87a365cc70aa41", transactionIndex: "227", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000c6fc6835ce16679c89567c0b33604d1e9a71bf99000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "6701574", gasUsed: "51338", confirmations: "3300655"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[44]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[44], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1508899780 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0xc6fc6835ce16679c89567c0b33604d1e9a71bf99"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[45], \"4000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424462", timeStamp: "1508900781", hash: "0x568cc412b0370ce25c6b747728fb88c995cdb583587065d72afe33e205c4020d", nonce: "44", blockHash: "0xd2a927478d80cde70a0f31aebd28badfc96c955230a65ddba1dde515ee6a77a0", transactionIndex: "191", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000658acdd5063fa27fe816f3923c7426a29cb2421b00000000000000000000000000000000000000000000000000000000ee6b2800", contractAddress: "", cumulativeGasUsed: "6678767", gasUsed: "51338", confirmations: "3300586"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[45]}, {type: "uint256", name: "_value", value: "4000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[45], "4000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1508900781 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x658acdd5063fa27fe816f3923c7426a29cb2421b"}, {name: "value", type: "uint256", value: "4000000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[8], \"3200000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424517", timeStamp: "1508901732", hash: "0xc7a379398290e160362cb79f80a75cb75c39d97058d6c6fbb10f7545498d958f", nonce: "45", blockHash: "0xbca0b08edb01830c75714dedb2879d5b430980061b6fd2fe2332604948c7a9ed", transactionIndex: "71", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "36338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb00000000000000000000000071e0083a42196576e29b64a37ce91209b1911c9f00000000000000000000000000000000000000000000000000000000bebc2000", contractAddress: "", cumulativeGasUsed: "5602863", gasUsed: "36338", confirmations: "3300531"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "3200000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[8], "3200000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1508901732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x71e0083a42196576e29b64a37ce91209b1911c9f"}, {name: "value", type: "uint256", value: "3200000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[46], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424530", timeStamp: "1508901866", hash: "0xeea391e19a6e36a3ccc248bca47b21ef6c97a8cf6f3fe884dbb70daaff3a5f01", nonce: "46", blockHash: "0x051c759341dceffe85fc141f97903eb35595ab465b87128b788fe842b3786925", transactionIndex: "62", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51274", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb000000000000000000000000008cd39b569505e006ec93689add83999e96ab12000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "3312193", gasUsed: "51274", confirmations: "3300518"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[46]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[46], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1508901866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x008cd39b569505e006ec93689add83999e96ab12"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[47], \"2400000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4424557", timeStamp: "1508902251", hash: "0xe19df4e7e6b3e4585344e2b6a8e758d40e5e807a72aeaa9df287a516978ecf1c", nonce: "47", blockHash: "0x78579da1116febfb5d9c292f5c1f1ee7eed380432b6bf4a1f214a0c6b4803435", transactionIndex: "55", from: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35", to: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf", value: "0", gas: "51338", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xa9059cbb0000000000000000000000008ae7ed767bab3335d736fa36cafdfc90034f6daa000000000000000000000000000000000000000000000000000000008f0d1800", contractAddress: "", cumulativeGasUsed: "2839360", gasUsed: "51338", confirmations: "3300491"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[47]}, {type: "uint256", name: "_value", value: "2400000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[47], "2400000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1508902251 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xf4aa26bdb9c45ff850c76e47118188c808e03a35"}, {name: "to", type: "address", value: "0x8ae7ed767bab3335d736fa36cafdfc90034f6daa"}, {name: "value", type: "uint256", value: "2400000000"}], address: "0xf9845744a35eb90666b648dbb38bc2b9a6ecccdf"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "135799558143792640" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
