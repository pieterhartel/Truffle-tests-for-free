const BankrollLending = artifacts.require( "./BankrollLending.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BankrollLending" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xE93Fc171cC8F5422efA2362509F9997d4148C04D", "0xDFEC0328a07C399A7e32364DEfd3bE6aaB9365D3", "0x08711D3B02C8758F2FB3ab4e80228418a7F8e39c", "0x91f273b7A28F5169FD7B7995A54B767cA797BC63", "0xb7B5016C6Bd616B80985242f734bF9f79e7a6F9c", "0x397B83D898bEBE08D1cA38500ea30505B23E20D8", "0x70AA8FA0dF2C1fa384e0aEC54806670D97B698fe", "0xBB57eb873CCf3dDfB4C7971C30CC09ff56e95A99", "0xa52DAc233ff577871A66c498BC86de90E61C3988", "0x230106058b9BEB343f238A02A37Cb5796176241e", "0xf699849898c8aE18DDF7dDAd6Cdb5D12ea10bCA4", "0x60819bF283D0015Cc18ea627f48D115a81A90004", "0x56B26F2B99293822ab9ACa0621d1D7aFdE9Eb60a", "0x18DE7833D66e0819cDA2e041292692F5c0B3171a", "0x7C28B0f40A31C559F86Df1dd76Ec082677A8c32b", "0xF5AA26585f48D37289cdeA103Fc5d17DEFDA48A6", "0x4d87980e75101335C6B5E0Bf3A2240EDb9b6D8Bf", "0x712f83F3b7f23c52f104D810395F7DC368a675a4", "0xaEb3d5c62bBA5f0d83b33457A6D1D3e6f1E63723", "0xcD8A5ba49B51c307E24001E1adF2F215eA730716", "0x989A445987F81aB8f892C503cf360e0063c97982", "0xCe473125e7604cc6BDF61c852F2C408426b17d5C", "0xA55D1B6e216c6f0D29acDe670bA6B4572E19D5dB", "0x84A95DCd6997EF134bB4E134b624E5f189dD8088", "0x5503221EF9A426E525EC3b40f08893ac4CA7a408", "0x2DbA6fB5bbA2E418633a394C6EF52C427963776D", "0xC666175C506F1dCC66345fFc64B3c760eb9b1F37", "0x8cAa32CeC20A6C3aFa9FC3c4caE58cD4716f3231", "0x570e729246a3761a1ABbD6465f162E638beF5f04", "0x7B0E893c09936737fac376617c26091B6dfaa635", "0x11f5795a30a08191BA02D3a79439c8823d71c573", "0xACffC41b5b0fe5a398e0a56336A04267b7F3efA3", "0xAeF978A4719CaF60c7f5BF7B879fb027A1475e84", "0x25959032FFd816f0Bbc49554564421d9F941ed10"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "address"}], name: "stakes", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "stakeholders", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minStakingAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cycle", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "updateGasCost", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "finalStakes", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxUpdates", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "casino", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "withdrawGasCost", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxBatchAssignment", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalStakes", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "numHolders", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "depositGasCost", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "initialStakes", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["StakeUpdate(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x89dbe872fd688c751e8c5df10849155d89d1467fd56ddb92b0d0024cda2ccd78"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6817420 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6829896 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "tokenAddr", value: 4}, {type: "address", name: "casinoAddr", value: 5}], name: "BankrollLending", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "stakes", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stakes(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "stakeholders", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "stakeholders(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minStakingAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minStakingAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cycle", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cycle()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "updateGasCost", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "updateGasCost()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "finalStakes", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalStakes(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxUpdates", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxUpdates()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "casino", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "casino()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "withdrawGasCost", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "withdrawGasCost()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxBatchAssignment", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxBatchAssignment()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalStakes", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalStakes()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "numHolders", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numHolders()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "depositGasCost", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "depositGasCost()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "initialStakes", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "initialStakes(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BankrollLending", function( accounts ) {

	it( "TEST: BankrollLending( addressList[4], addressList[5] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6817420", timeStamp: "1543824842", hash: "0xd75cd1923c17f93b292ee7e23bf642071057faf9de045c3c5e3c13cfc7073557", nonce: "76", blockHash: "0x33a6ea05d659fe3ee037f937e25686cf7c686221d171643efd53a2ab8965c3e4", transactionIndex: "142", from: "0xdfec0328a07c399a7e32364defd3be6aab9365d3", to: 0, value: "0", gas: "2030949", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x27a49cbe00000000000000000000000008711d3b02c8758f2fb3ab4e80228418a7f8e39c00000000000000000000000091f273b7a28f5169fd7b7995a54b767ca797bc63", contractAddress: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", cumulativeGasUsed: "7807628", gasUsed: "2030949", confirmations: "866020"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "tokenAddr", value: addressList[4]}, {type: "address", name: "casinoAddr", value: addressList[5]}], name: "BankrollLending", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BankrollLending.new( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543824842 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BankrollLending.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "563651684158473097" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setDepositGasCost( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6818715", timeStamp: "1543843566", hash: "0x7600ac6abae7967a17764bb0c24266bc134fc60620ae1a3e1cde117eadd22b71", nonce: "2849", blockHash: "0x1de3e184d3fbc47898b72b03b4d3fd7cf77e240716ee8b85b7c2aae673071add", transactionIndex: "50", from: "0xb7b5016c6bd616b80985242f734bf9f79e7a6f9c", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "219750", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xd0dd38ad0000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "2281272", gasUsed: "45709", confirmations: "864725"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "gasCost", value: "20"}], name: "setDepositGasCost", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDepositGasCost(uint8)" ]( "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543843566 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "350749849301242964" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setWithdrawGasCost( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "6818721", timeStamp: "1543843656", hash: "0x18485d11076aafedd9b913d97b621cfcad92a38b1e10a14e4031165cbe0745c1", nonce: "2850", blockHash: "0x12d90f33a89d7b60ad071cd35216e47ca1d0fb007184ae3611fd0bc1e2dc42a5", transactionIndex: "61", from: "0xb7b5016c6bd616b80985242f734bf9f79e7a6f9c", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "219750", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xd53537920000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "3891170", gasUsed: "30742", confirmations: "864719"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "gasCost", value: "20"}], name: "setWithdrawGasCost", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setWithdrawGasCost(uint8)" ]( "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543843656 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "350749849301242964" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"21\", \"500000000\", \"28\", \"0xd242f... )", async function( ) {
		const txOriginal = {blockNumber: "6824444", timeStamp: "1543925237", hash: "0x87a5485081bc19a55760e89a5e7371f5b053c4d79077fd6fd0f01f22f2e8d10b", nonce: "2864", blockHash: "0xfbb519b0fbd3770a9d3b772fef27c061ed43c19375c3da5b8fd1094f6b74ec80", transactionIndex: "15", from: "0xb7b5016c6bd616b80985242f734bf9f79e7a6f9c", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "297800", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000000015000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001cd242f601c6c1fe63ddc0474af198f4967b12a99d2b87a3dcc0475666547b0d223f73b38e08eed0b312c00ef702a3d03e77a3d80aea1baccb78a7c66d77b5ec98", contractAddress: "", cumulativeGasUsed: "808954", gasUsed: "293771", confirmations: "858996"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "21"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xd242f601c6c1fe63ddc0474af198f4967b12a99d2b87a3dcc0475666547b0d22"}, {type: "bytes32", name: "s", value: "0x3f73b38e08eed0b312c00ef702a3d03e77a3d80aea1baccb78a7c66d77b5ec98"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "21", "500000000", "28", "0xd242f601c6c1fe63ddc0474af198f4967b12a99d2b87a3dcc0475666547b0d22", "0x3f73b38e08eed0b312c00ef702a3d03e77a3d80aea1baccb78a7c66d77b5ec98", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543925237 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "350749849301242964" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"21\", \"500000000\", \"28\", \"0xd242f... )", async function( ) {
		const txOriginal = {blockNumber: "6824491", timeStamp: "1543925932", hash: "0x7f3590d3b8f0e4ccf96df446ea22dbb54cae858f9167eb6992a806b640d0156b", nonce: "2866", blockHash: "0x6d74306300fabb54907e916b8994dce01220647d3c6c44f8de9e66d5ad0c09bb", transactionIndex: "75", from: "0xb7b5016c6bd616b80985242f734bf9f79e7a6f9c", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "373083", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000000015000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001cd242f601c6c1fe63ddc0474af198f4967b12a99d2b87a3dcc0475666547b0d223f73b38e08eed0b312c00ef702a3d03e77a3d80aea1baccb78a7c66d77b5ec98", contractAddress: "", cumulativeGasUsed: "5779697", gasUsed: "177355", confirmations: "858949"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "21"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xd242f601c6c1fe63ddc0474af198f4967b12a99d2b87a3dcc0475666547b0d22"}, {type: "bytes32", name: "s", value: "0x3f73b38e08eed0b312c00ef702a3d03e77a3d80aea1baccb78a7c66d77b5ec98"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "21", "500000000", "28", "0xd242f601c6c1fe63ddc0474af198f4967b12a99d2b87a3dcc0475666547b0d22", "0x3f73b38e08eed0b312c00ef702a3d03e77a3d80aea1baccb78a7c66d77b5ec98", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543925932 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xb7b5016c6bd616b80985242f734bf9f79e7a6f9c"}, {name: "stake", type: "uint256", value: "1"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "350749849301242964" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"1020\", \"500000000\", \"27\", \"0xfc2... )", async function( ) {
		const txOriginal = {blockNumber: "6824582", timeStamp: "1543927017", hash: "0x07d481d09916d8826c2627419f2524001bf9cb649e5d0b749077af94a09ab70e", nonce: "2", blockHash: "0xec01adc2f6f4f56a24702cb84a48d3b18690987de10957640ca5840d4186aad4", transactionIndex: "30", from: "0x397b83d898bebe08d1ca38500ea30505b23e20d8", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "447600", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe000000000000000000000000000000000000000000000000000000000000003fc000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bfc2aeda32f5631cd8c82e8cbabd0ed228811638b9f08e64ad71cd9b382cceb5b579486c4e16ed13cd6d5422aa698d6456aa9b0175d1fc00d8ce3d46368632612", contractAddress: "", cumulativeGasUsed: "1220597", gasUsed: "117419", confirmations: "858858"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "1020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xfc2aeda32f5631cd8c82e8cbabd0ed228811638b9f08e64ad71cd9b382cceb5b"}, {type: "bytes32", name: "s", value: "0x579486c4e16ed13cd6d5422aa698d6456aa9b0175d1fc00d8ce3d46368632612"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "1020", "500000000", "27", "0xfc2aeda32f5631cd8c82e8cbabd0ed228811638b9f08e64ad71cd9b382cceb5b", "0x579486c4e16ed13cd6d5422aa698d6456aa9b0175d1fc00d8ce3d46368632612", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543927017 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x397b83d898bebe08d1ca38500ea30505b23e20d8"}, {name: "stake", type: "uint256", value: "1000"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "17089839000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0xc0... )", async function( ) {
		const txOriginal = {blockNumber: "6824982", timeStamp: "1543932689", hash: "0x8c2c14e273a923dbba645041e2935b030bff54bfd3cd7b18118aabd4ea79f911", nonce: "0", blockHash: "0xc2f651c80b70382af10cb8a4a4cc5653418ad9555f3f79d101476e3eedbb37a0", transactionIndex: "56", from: "0x70aa8fa0df2c1fa384e0aec54806670d97b698fe", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "222700", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba8876b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239", contractAddress: "", cumulativeGasUsed: "2135841", gasUsed: "219846", confirmations: "858458"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba887"}, {type: "bytes32", name: "s", value: "0x6b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0xc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba887", "0x6b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543932689 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "17671205000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0xc0... )", async function( ) {
		const txOriginal = {blockNumber: "6824990", timeStamp: "1543932816", hash: "0x44e7634bdf7282046319983d4b3bdfcdf472b294ff989dbb67d83ab1cfad8193", nonce: "1", blockHash: "0xb1bdd51aaec9878f3a7674cca0ae5a9a47ae618f73a731e65872015b6f16f33e", transactionIndex: "77", from: "0x70aa8fa0df2c1fa384e0aec54806670d97b698fe", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "222250", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba8876b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239", contractAddress: "", cumulativeGasUsed: "4682944", gasUsed: "219403", confirmations: "858450"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba887"}, {type: "bytes32", name: "s", value: "0x6b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0xc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba887", "0x6b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543932816 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "17671205000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0xc0... )", async function( ) {
		const txOriginal = {blockNumber: "6825004", timeStamp: "1543933044", hash: "0xa21a59ec8ae223106f8e6d7477ba30e7dd6c6e11b5e9459d2af196f40bad7b3e", nonce: "2", blockHash: "0x8eab82b96215af4d7a5133afb3bcd8d582ba8ca31f8612138941bbdbc0396d94", transactionIndex: "59", from: "0x70aa8fa0df2c1fa384e0aec54806670d97b698fe", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "222300", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba8876b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239", contractAddress: "", cumulativeGasUsed: "2059183", gasUsed: "219452", confirmations: "858436"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba887"}, {type: "bytes32", name: "s", value: "0x6b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0xc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba887", "0x6b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543933044 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "17671205000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x6d... )", async function( ) {
		const txOriginal = {blockNumber: "6825210", timeStamp: "1543935879", hash: "0xdee20a445524fc4b2546ddf61ec9b06fde9f1e0ea10dd0747584224928d35165", nonce: "0", blockHash: "0xab33ec578498d3a07ba326ba8a810fd7c66bc4f25a3788f88b83ca43b7a4201c", transactionIndex: "61", from: "0xbb57eb873ccf3ddfb4c7971c30cc09ff56e95a99", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "220750", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", contractAddress: "", cumulativeGasUsed: "3420801", gasUsed: "217926", confirmations: "858230"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d"}, {type: "bytes32", name: "s", value: "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d", "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543935879 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "31045317000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x6d... )", async function( ) {
		const txOriginal = {blockNumber: "6825215", timeStamp: "1543935953", hash: "0xd3f0712303805251d730292e1acf93564540ba261eed3f20e6f5a9242cc80c6a", nonce: "1", blockHash: "0x2e6353a56a3ecc242872547c5392c8bf04cf1fca175f1eba73a285bbe8a13cb2", transactionIndex: "17", from: "0xbb57eb873ccf3ddfb4c7971c30cc09ff56e95a99", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "219050", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", contractAddress: "", cumulativeGasUsed: "1096590", gasUsed: "216253", confirmations: "858225"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d"}, {type: "bytes32", name: "s", value: "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d", "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1543935953 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "31045317000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x6d... )", async function( ) {
		const txOriginal = {blockNumber: "6825223", timeStamp: "1543936064", hash: "0x496e91c5a08e14e58de45b99adc3073ce43c0b10cc5c5164a85ef76158c1f2b3", nonce: "2", blockHash: "0x436d97fe61da621b7da39578668da33ed87dde8be357e63b71a8decf322642d4", transactionIndex: "53", from: "0xbb57eb873ccf3ddfb4c7971c30cc09ff56e95a99", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "230105", gasPrice: "19000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", contractAddress: "", cumulativeGasUsed: "1535132", gasUsed: "227135", confirmations: "858217"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d"}, {type: "bytes32", name: "s", value: "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d", "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543936064 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "31045317000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"27\", \"0x98... )", async function( ) {
		const txOriginal = {blockNumber: "6825249", timeStamp: "1543936543", hash: "0x51bb9648a548ed6d7bed7e7ebe102272ad3aed3bbfc77311b252f67b0b149868", nonce: "1", blockHash: "0x731ad652bf6b71666e4a498459979565c5aacf9e8a41c0d1546bc977e90b197c", transactionIndex: "40", from: "0xa52dac233ff577871a66c498bc86de90e61c3988", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "230421", gasPrice: "19000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b98e6afb585a8a98afd606d9fcf765cb85c6ee566a86c3fdc102f7e50284cf933114bb35fa12aead7e6a604dc651e2963c3e09cda87369f3feccbbb5cd6af9208", contractAddress: "", cumulativeGasUsed: "1540511", gasUsed: "102419", confirmations: "858191"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x98e6afb585a8a98afd606d9fcf765cb85c6ee566a86c3fdc102f7e50284cf933"}, {type: "bytes32", name: "s", value: "0x114bb35fa12aead7e6a604dc651e2963c3e09cda87369f3feccbbb5cd6af9208"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "27", "0x98e6afb585a8a98afd606d9fcf765cb85c6ee566a86c3fdc102f7e50284cf933", "0x114bb35fa12aead7e6a604dc651e2963c3e09cda87369f3feccbbb5cd6af9208", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543936543 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xa52dac233ff577871a66c498bc86de90e61c3988"}, {name: "stake", type: "uint256", value: "30000"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "14437235000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x6d... )", async function( ) {
		const txOriginal = {blockNumber: "6825287", timeStamp: "1543937067", hash: "0x2f15d122f6a392e736eb3aecbda5b319d1f2a8582b92f8d49173d4c23254f106", nonce: "3", blockHash: "0xdf5659481a42f720d4505b245787f0b13250cd095a56ed9c04173e067c5adac7", transactionIndex: "41", from: "0xbb57eb873ccf3ddfb4c7971c30cc09ff56e95a99", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "314071", gasPrice: "14000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", contractAddress: "", cumulativeGasUsed: "1631819", gasUsed: "309789", confirmations: "858153"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d"}, {type: "bytes32", name: "s", value: "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d", "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543937067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "31045317000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x6d... )", async function( ) {
		const txOriginal = {blockNumber: "6825319", timeStamp: "1543937475", hash: "0x5346ea6cfd9eaac6a60634dc90c6ecef08d5f9b4c96ea15efc618554f82a4e32", nonce: "4", blockHash: "0x14ad3d19917ce742c1b11d3fb98d07330938ea2660915827fd8f71a00910e064", transactionIndex: "145", from: "0xbb57eb873ccf3ddfb4c7971c30cc09ff56e95a99", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "314642", gasPrice: "14000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", contractAddress: "", cumulativeGasUsed: "3803813", gasUsed: "310351", confirmations: "858121"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d"}, {type: "bytes32", name: "s", value: "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d", "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543937475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "31045317000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0x3a... )", async function( ) {
		const txOriginal = {blockNumber: "6825329", timeStamp: "1543937582", hash: "0xede9b9954ab4803b0948937fe7432d1f1b96db4efda3b729aac3d8434d2139c9", nonce: "1", blockHash: "0x95e9d87bafc62f052294875a3cf4151b97648da790a9f589d5c6a0bf70c4caa2", transactionIndex: "40", from: "0x230106058b9beb343f238a02a37cb5796176241e", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "400545", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b3a4ed2327ec63377e468172c818a8abca3c0413179288605e39ae83879811a907160c20723c11f6102ecd94bcbe2dbf77d79ac27b94b6131b6892c63d388c84d", contractAddress: "", cumulativeGasUsed: "1925330", gasUsed: "102419", confirmations: "858111"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x3a4ed2327ec63377e468172c818a8abca3c0413179288605e39ae83879811a90"}, {type: "bytes32", name: "s", value: "0x7160c20723c11f6102ecd94bcbe2dbf77d79ac27b94b6131b6892c63d388c84d"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0x3a4ed2327ec63377e468172c818a8abca3c0413179288605e39ae83879811a90", "0x7160c20723c11f6102ecd94bcbe2dbf77d79ac27b94b6131b6892c63d388c84d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543937582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x230106058b9beb343f238a02a37cb5796176241e"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "17392176000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"27\", \"0x41... )", async function( ) {
		const txOriginal = {blockNumber: "6825367", timeStamp: "1543938095", hash: "0xb42ed4855aac2290a264412a0084290b814022f3c35b80146c75c68b09f34a24", nonce: "0", blockHash: "0xd4b750a7c997cbfb5451bd89a2270d62eddfe48822553736505efbfd0986e678", transactionIndex: "9", from: "0xf699849898c8ae18ddf7ddad6cdb5d12ea10bca4", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "315714", gasPrice: "14000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b41d6f7db6303ea1b73d1e442943b8375557337f945933fca0ab761b6a4c26f4307d3c1ae440ddac87fb99d90d1fbef33f9d606134f87b3fdb9bd85b3f6277bf3", contractAddress: "", cumulativeGasUsed: "1174582", gasUsed: "311407", confirmations: "858073"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x41d6f7db6303ea1b73d1e442943b8375557337f945933fca0ab761b6a4c26f43"}, {type: "bytes32", name: "s", value: "0x07d3c1ae440ddac87fb99d90d1fbef33f9d606134f87b3fdb9bd85b3f6277bf3"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "27", "0x41d6f7db6303ea1b73d1e442943b8375557337f945933fca0ab761b6a4c26f43", "0x07d3c1ae440ddac87fb99d90d1fbef33f9d606134f87b3fdb9bd85b3f6277bf3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543938095 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "14538918000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"27\", \"0x41... )", async function( ) {
		const txOriginal = {blockNumber: "6825382", timeStamp: "1543938385", hash: "0xc686c43bfcf9ec8fdb485d0bc235e4ccaa05b77130c665e8a3424dc9a9e41eb0", nonce: "1", blockHash: "0xf96cdb23cad850de64c3928176d5ecf77a55fdc40889ab22ee6b1862d2eed997", transactionIndex: "41", from: "0xf699849898c8ae18ddf7ddad6cdb5d12ea10bca4", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "402000", gasPrice: "11000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b41d6f7db6303ea1b73d1e442943b8375557337f945933fca0ab761b6a4c26f4307d3c1ae440ddac87fb99d90d1fbef33f9d606134f87b3fdb9bd85b3f6277bf3", contractAddress: "", cumulativeGasUsed: "1770293", gasUsed: "396344", confirmations: "858058"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x41d6f7db6303ea1b73d1e442943b8375557337f945933fca0ab761b6a4c26f43"}, {type: "bytes32", name: "s", value: "0x07d3c1ae440ddac87fb99d90d1fbef33f9d606134f87b3fdb9bd85b3f6277bf3"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "27", "0x41d6f7db6303ea1b73d1e442943b8375557337f945933fca0ab761b6a4c26f43", "0x07d3c1ae440ddac87fb99d90d1fbef33f9d606134f87b3fdb9bd85b3f6277bf3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543938385 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "14538918000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"28\", \"0x12... )", async function( ) {
		const txOriginal = {blockNumber: "6825386", timeStamp: "1543938427", hash: "0x499aab716755125b8cb6cc00c8477191de98ae86374b320626e4cb092b704207", nonce: "0", blockHash: "0xa0c15a288ae9978bdb334f110d11716011ce4466f22db8722f460c5a0f972528", transactionIndex: "72", from: "0x60819bf283d0015cc18ea627f48d115a81a90004", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "402000", gasPrice: "11000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c12af703f97b35dab2e675b7e4f984ffb837053cb1fdf60e67ab1cb13165cd7191ecb331b7ade9478cff277c6e69c9104b14813aca48c5d4db9c2d0795dafa0c5", contractAddress: "", cumulativeGasUsed: "4501019", gasUsed: "396344", confirmations: "858054"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x12af703f97b35dab2e675b7e4f984ffb837053cb1fdf60e67ab1cb13165cd719"}, {type: "bytes32", name: "s", value: "0x1ecb331b7ade9478cff277c6e69c9104b14813aca48c5d4db9c2d0795dafa0c5"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "28", "0x12af703f97b35dab2e675b7e4f984ffb837053cb1fdf60e67ab1cb13165cd719", "0x1ecb331b7ade9478cff277c6e69c9104b14813aca48c5d4db9c2d0795dafa0c5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543938427 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "12451264000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"28\", \"0x12... )", async function( ) {
		const txOriginal = {blockNumber: "6825395", timeStamp: "1543938597", hash: "0xe1fde6880f072f0ca8979df5e12f22fff34fbec35c6d2930c3b761c9d2743f49", nonce: "1", blockHash: "0x1a468fb99196ad469fa0937c27384f30ffb7b463e92b16e45540a46ded4e25b1", transactionIndex: "15", from: "0x60819bf283d0015cc18ea627f48d115a81a90004", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "402545", gasPrice: "11000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c12af703f97b35dab2e675b7e4f984ffb837053cb1fdf60e67ab1cb13165cd7191ecb331b7ade9478cff277c6e69c9104b14813aca48c5d4db9c2d0795dafa0c5", contractAddress: "", cumulativeGasUsed: "6597881", gasUsed: "396881", confirmations: "858045"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x12af703f97b35dab2e675b7e4f984ffb837053cb1fdf60e67ab1cb13165cd719"}, {type: "bytes32", name: "s", value: "0x1ecb331b7ade9478cff277c6e69c9104b14813aca48c5d4db9c2d0795dafa0c5"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "28", "0x12af703f97b35dab2e675b7e4f984ffb837053cb1fdf60e67ab1cb13165cd719", "0x1ecb331b7ade9478cff277c6e69c9104b14813aca48c5d4db9c2d0795dafa0c5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543938597 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "12451264000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"27\", \"0x41... )", async function( ) {
		const txOriginal = {blockNumber: "6825406", timeStamp: "1543938835", hash: "0x4a1e7967a7944b688bb7fb1b531ad8aaf02aa8eb77034378e6f120bf237ff5fb", nonce: "3", blockHash: "0xb9b20c8422bb4bb5ed8bc15ebd49b40acb36eadb86c68e4a1080a7a364460084", transactionIndex: "70", from: "0xf699849898c8ae18ddf7ddad6cdb5d12ea10bca4", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "401818", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b41d6f7db6303ea1b73d1e442943b8375557337f945933fca0ab761b6a4c26f4307d3c1ae440ddac87fb99d90d1fbef33f9d606134f87b3fdb9bd85b3f6277bf3", contractAddress: "", cumulativeGasUsed: "3586899", gasUsed: "117419", confirmations: "858034"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x41d6f7db6303ea1b73d1e442943b8375557337f945933fca0ab761b6a4c26f43"}, {type: "bytes32", name: "s", value: "0x07d3c1ae440ddac87fb99d90d1fbef33f9d606134f87b3fdb9bd85b3f6277bf3"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "27", "0x41d6f7db6303ea1b73d1e442943b8375557337f945933fca0ab761b6a4c26f43", "0x07d3c1ae440ddac87fb99d90d1fbef33f9d606134f87b3fdb9bd85b3f6277bf3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543938835 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xf699849898c8ae18ddf7ddad6cdb5d12ea10bca4"}, {name: "stake", type: "uint256", value: "30000"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "14538918000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x6d... )", async function( ) {
		const txOriginal = {blockNumber: "6825425", timeStamp: "1543939213", hash: "0x299e445bbaa427e94f7104a69bcbef94b7531935b2027bbff4ae6777049c7cdf", nonce: "5", blockHash: "0xd8a9b216574dc6b931fd18d0541c8da71852a79e2c1179d525589c1ff2acfc2b", transactionIndex: "127", from: "0xbb57eb873ccf3ddfb4c7971c30cc09ff56e95a99", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "442800", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", contractAddress: "", cumulativeGasUsed: "5804642", gasUsed: "436507", confirmations: "858015"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d"}, {type: "bytes32", name: "s", value: "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d", "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543939213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "31045317000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0xc0... )", async function( ) {
		const txOriginal = {blockNumber: "6825573", timeStamp: "1543941439", hash: "0xd553e39448830df1ff9ac04bf49ef7f67c896b82ac59ec5ebd879e344e87e187", nonce: "4", blockHash: "0xf07c32bcfd4594ccaf3ebe657810be75587363aff863aad8f74512b614931eba", transactionIndex: "171", from: "0x70aa8fa0df2c1fa384e0aec54806670d97b698fe", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "318285", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba8876b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239", contractAddress: "", cumulativeGasUsed: "4661811", gasUsed: "117419", confirmations: "857867"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba887"}, {type: "bytes32", name: "s", value: "0x6b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0xc0690c559d4740b9115cd32589f702fe25c5ca6e472a98eceb3019630a0ba887", "0x6b93f106d0248b513cf4e8e720b43cf1f12386a73b7d59bbd9b5afa602060239", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543941439 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x70aa8fa0df2c1fa384e0aec54806670d97b698fe"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "17671205000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"1491\", \"500000000\", \"28\", \"0xf2f... )", async function( ) {
		const txOriginal = {blockNumber: "6825711", timeStamp: "1543943232", hash: "0xb34815e926f337e8ea13851e0eb9087c8dfddc35c4823ebbb710225ac12ad3ba", nonce: "1", blockHash: "0x460ed84a8b15cf0abe91800f2726c2fe54ebc73ad5c00dffb67735efc40afb27", transactionIndex: "26", from: "0x56b26f2b99293822ab9aca0621d1d7afde9eb60a", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "223050", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe000000000000000000000000000000000000000000000000000000000000005d3000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001cf2f24c138a6146b665fb4e12003f5ed7718b9c8ada771b8f6ef8e08d32328c046454c8f21e52b2739da1335b936914df3eebbad5c10afa18fd3c8ad0aaeb93b6", contractAddress: "", cumulativeGasUsed: "3005304", gasUsed: "102355", confirmations: "857729"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "1491"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xf2f24c138a6146b665fb4e12003f5ed7718b9c8ada771b8f6ef8e08d32328c04"}, {type: "bytes32", name: "s", value: "0x6454c8f21e52b2739da1335b936914df3eebbad5c10afa18fd3c8ad0aaeb93b6"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "1491", "500000000", "28", "0xf2f24c138a6146b665fb4e12003f5ed7718b9c8ada771b8f6ef8e08d32328c04", "0x6454c8f21e52b2739da1335b936914df3eebbad5c10afa18fd3c8ad0aaeb93b6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543943232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x56b26f2b99293822ab9aca0621d1d7afde9eb60a"}, {name: "stake", type: "uint256", value: "1471"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "60963035000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0x20... )", async function( ) {
		const txOriginal = {blockNumber: "6825835", timeStamp: "1543944999", hash: "0x699c989d1e616cc54b8ed380734b6e1fe734804c8dc01658267b0665b0051ab9", nonce: "0", blockHash: "0xf59b9d7f2500abeefbc02b56eedcd48a3310a73a1806470b3ba37de8ac5fe2b8", transactionIndex: "46", from: "0x18de7833d66e0819cda2e041292692f5c0b3171a", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "208350", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b2041274f1076877e0d0e9fe2b34b84f960fa341ddac83e02ce790cf4c3fcb9a56f68f08eda9e9c54c0f101a26bd66564431f75588b5f1d35ff4a15090113cc70", contractAddress: "", cumulativeGasUsed: "3417805", gasUsed: "205720", confirmations: "857605"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x2041274f1076877e0d0e9fe2b34b84f960fa341ddac83e02ce790cf4c3fcb9a5"}, {type: "bytes32", name: "s", value: "0x6f68f08eda9e9c54c0f101a26bd66564431f75588b5f1d35ff4a15090113cc70"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0x2041274f1076877e0d0e9fe2b34b84f960fa341ddac83e02ce790cf4c3fcb9a5", "0x6f68f08eda9e9c54c0f101a26bd66564431f75588b5f1d35ff4a15090113cc70", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1543944999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "12206574000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x6d... )", async function( ) {
		const txOriginal = {blockNumber: "6825835", timeStamp: "1543944999", hash: "0xa481d2b3f6a4a01d074f50db3140af60b2581fe23bb29c0fb10f4cde6b9b7c8f", nonce: "7", blockHash: "0xf59b9d7f2500abeefbc02b56eedcd48a3310a73a1806470b3ba37de8ac5fe2b8", transactionIndex: "48", from: "0xbb57eb873ccf3ddfb4c7971c30cc09ff56e95a99", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "208350", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", contractAddress: "", cumulativeGasUsed: "3580639", gasUsed: "117419", confirmations: "857605"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d"}, {type: "bytes32", name: "s", value: "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x6d605f84cd3f4fe582d82d37934dea039322d83de82a2aa0fa169c665110829d", "0x6d342e0629cd77d48454c69ed812e7a5b53ff3d18445db27b903f2a7f9a916fd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543944999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xbb57eb873ccf3ddfb4c7971c30cc09ff56e95a99"}, {name: "stake", type: "uint256", value: "30000"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "31045317000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"1996\", \"500000000\", \"27\", \"0xab5... )", async function( ) {
		const txOriginal = {blockNumber: "6825835", timeStamp: "1543944999", hash: "0x857084889399f496c85ceb20143855bdca9d1dc88e33992d1972e99dfc4aee81", nonce: "0", blockHash: "0xf59b9d7f2500abeefbc02b56eedcd48a3310a73a1806470b3ba37de8ac5fe2b8", transactionIndex: "50", from: "0x7c28b0f40a31c559f86df1dd76ec082677a8c32b", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "208350", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe000000000000000000000000000000000000000000000000000000000000007cc000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bab5a46ba4196978d270390bd5346696b493272e86d0f6054f1e54b7966d9bcd648ea4c676682986abd0816f893372f6462828b5492ad51aedbc006a2fae5d2a4", contractAddress: "", cumulativeGasUsed: "3831774", gasUsed: "205720", confirmations: "857605"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "1996"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xab5a46ba4196978d270390bd5346696b493272e86d0f6054f1e54b7966d9bcd6"}, {type: "bytes32", name: "s", value: "0x48ea4c676682986abd0816f893372f6462828b5492ad51aedbc006a2fae5d2a4"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "1996", "500000000", "27", "0xab5a46ba4196978d270390bd5346696b493272e86d0f6054f1e54b7966d9bcd6", "0x48ea4c676682986abd0816f893372f6462828b5492ad51aedbc006a2fae5d2a4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543944999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "9767300000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"28\", \"0x12... )", async function( ) {
		const txOriginal = {blockNumber: "6825835", timeStamp: "1543944999", hash: "0xa6175e9d12a57f85d84650054efc5448148248910b0153f4c980bd2aca62caae", nonce: "3", blockHash: "0xf59b9d7f2500abeefbc02b56eedcd48a3310a73a1806470b3ba37de8ac5fe2b8", transactionIndex: "52", from: "0x60819bf283d0015cc18ea627f48d115a81a90004", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "208350", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c12af703f97b35dab2e675b7e4f984ffb837053cb1fdf60e67ab1cb13165cd7191ecb331b7ade9478cff277c6e69c9104b14813aca48c5d4db9c2d0795dafa0c5", contractAddress: "", cumulativeGasUsed: "3979608", gasUsed: "102419", confirmations: "857605"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x12af703f97b35dab2e675b7e4f984ffb837053cb1fdf60e67ab1cb13165cd719"}, {type: "bytes32", name: "s", value: "0x1ecb331b7ade9478cff277c6e69c9104b14813aca48c5d4db9c2d0795dafa0c5"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "28", "0x12af703f97b35dab2e675b7e4f984ffb837053cb1fdf60e67ab1cb13165cd719", "0x1ecb331b7ade9478cff277c6e69c9104b14813aca48c5d4db9c2d0795dafa0c5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1543944999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x60819bf283d0015cc18ea627f48d115a81a90004"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "12451264000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0x19... )", async function( ) {
		const txOriginal = {blockNumber: "6826188", timeStamp: "1543950228", hash: "0x4c72aeecdbab81c56e71edf624c298e0c247007f44dac682aa7affc258fec480", nonce: "1", blockHash: "0x8dc44cf0f90d6a696d2f0e09ba2ccbd4ad447007fafdfbefa3299544e2246d32", transactionIndex: "2", from: "0xf5aa26585f48d37289cdea103fc5d17defda48a6", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "235052", gasPrice: "19000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b1968ed73639668edf7ca8b1f132f8071fcfe487d8091ceacce47254c4ea125dd1dfe518ab31c2ef9a6d27381731979ed0dd434dda1de6b5d7b2b50a7a7168aac", contractAddress: "", cumulativeGasUsed: "425699", gasUsed: "102419", confirmations: "857252"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x1968ed73639668edf7ca8b1f132f8071fcfe487d8091ceacce47254c4ea125dd"}, {type: "bytes32", name: "s", value: "0x1dfe518ab31c2ef9a6d27381731979ed0dd434dda1de6b5d7b2b50a7a7168aac"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0x1968ed73639668edf7ca8b1f132f8071fcfe487d8091ceacce47254c4ea125dd", "0x1dfe518ab31c2ef9a6d27381731979ed0dd434dda1de6b5d7b2b50a7a7168aac", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543950228 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xf5aa26585f48d37289cdea103fc5d17defda48a6"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "12487498000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0xbb... )", async function( ) {
		const txOriginal = {blockNumber: "6826266", timeStamp: "1543951184", hash: "0x19fd95be2f46c323f10a4c4788e93fb548b5165781a6309393bbde63fb3b5341", nonce: "1", blockHash: "0xfd5993a1af402f79355c31ab8f7f8005061007318cd6d213ed018678d67aed6f", transactionIndex: "10", from: "0x4d87980e75101335c6b5e0bf3a2240edb9b6d8bf", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "224000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bbb1aabc35ea5689596570b317185b0cf9acc86da1399292a621c97de968a81c572822bee34a749e1c543037a4f09d1a668435b431de82fc57a9d5f11f4786287", contractAddress: "", cumulativeGasUsed: "846806", gasUsed: "102419", confirmations: "857174"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xbb1aabc35ea5689596570b317185b0cf9acc86da1399292a621c97de968a81c5"}, {type: "bytes32", name: "s", value: "0x72822bee34a749e1c543037a4f09d1a668435b431de82fc57a9d5f11f4786287"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0xbb1aabc35ea5689596570b317185b0cf9acc86da1399292a621c97de968a81c5", "0x72822bee34a749e1c543037a4f09d1a668435b431de82fc57a9d5f11f4786287", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543951184 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x4d87980e75101335c6b5e0bf3a2240edb9b6d8bf"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "11804777000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0x95... )", async function( ) {
		const txOriginal = {blockNumber: "6826361", timeStamp: "1543952452", hash: "0x68d7be439dcc6e4f31436877d3a14623483f38ddf0202d21e7ac072cb5803fc3", nonce: "1", blockHash: "0x2302c992dbf6e4d7379754276f28ec5b4f039c6d000b700fdfe214e0c8b28c21", transactionIndex: "50", from: "0x712f83f3b7f23c52f104d810395f7dc368a675a4", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "212809", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b9550d63251645ecc4728268aabbc54af259d2de112b271c2435139dafa018d1730086b14b6d2f171922765299d67453612c15be406cdda7645bb2d714c712bce", contractAddress: "", cumulativeGasUsed: "5889421", gasUsed: "102419", confirmations: "857079"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x9550d63251645ecc4728268aabbc54af259d2de112b271c2435139dafa018d17"}, {type: "bytes32", name: "s", value: "0x30086b14b6d2f171922765299d67453612c15be406cdda7645bb2d714c712bce"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0x9550d63251645ecc4728268aabbc54af259d2de112b271c2435139dafa018d17", "0x30086b14b6d2f171922765299d67453612c15be406cdda7645bb2d714c712bce", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1543952452 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x712f83f3b7f23c52f104d810395f7dc368a675a4"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "12128966000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"5840\", \"500000000\", \"27\", \"0xc70... )", async function( ) {
		const txOriginal = {blockNumber: "6826667", timeStamp: "1543956151", hash: "0xaaa7a48e25fb44af16b277fb15352b874dae453d333c4df1288decdeab00dc5c", nonce: "1", blockHash: "0xea0ceb03926a8ed935e04ab507263a8a23c42aee2aaa57647c90e0f3aa76baa5", transactionIndex: "26", from: "0xaeb3d5c62bba5f0d83b33457a6d1d3e6f1e63723", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "214904", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe000000000000000000000000000000000000000000000000000000000000016d0000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bc7017af3539950b60ec6f3c53a5221079f4dac5d650fa0416cd3b499e891631a20f1a3c802cdcafbd5b34f2a975edc39ab8cfdca6c4843475f29048ed7fe266e", contractAddress: "", cumulativeGasUsed: "1081215", gasUsed: "117419", confirmations: "856773"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "5840"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xc7017af3539950b60ec6f3c53a5221079f4dac5d650fa0416cd3b499e891631a"}, {type: "bytes32", name: "s", value: "0x20f1a3c802cdcafbd5b34f2a975edc39ab8cfdca6c4843475f29048ed7fe266e"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "5840", "500000000", "27", "0xc7017af3539950b60ec6f3c53a5221079f4dac5d650fa0416cd3b499e891631a", "0x20f1a3c802cdcafbd5b34f2a975edc39ab8cfdca6c4843475f29048ed7fe266e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1543956151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xaeb3d5c62bba5f0d83b33457a6d1d3e6f1e63723"}, {name: "stake", type: "uint256", value: "5820"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "12093201000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"22995\", \"500000000\", \"27\", \"0x6e... )", async function( ) {
		const txOriginal = {blockNumber: "6826898", timeStamp: "1543959446", hash: "0x4bc11485accabda56e83b2ff3c2a9e3cf19cde6e621dda9dbbc13c237110d576", nonce: "1", blockHash: "0xc7758234daa3e5b9460fc167463e94fe6948fcef8567fb176a2b27d25603688a", transactionIndex: "49", from: "0xcd8a5ba49b51c307e24001e1adf2f215ea730716", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "225750", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe000000000000000000000000000000000000000000000000000000000000059d3000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b6e86c7b290d239808d828bae83536b9e879306ec985c6cc6f600100c8f34860502aa8dfd8f5fdfaf22778923d2d36316b8ac1d7b2434ca3d8dcf1742cc14ad5f", contractAddress: "", cumulativeGasUsed: "3795592", gasUsed: "102355", confirmations: "856542"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "22995"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x6e86c7b290d239808d828bae83536b9e879306ec985c6cc6f600100c8f348605"}, {type: "bytes32", name: "s", value: "0x02aa8dfd8f5fdfaf22778923d2d36316b8ac1d7b2434ca3d8dcf1742cc14ad5f"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "22995", "500000000", "27", "0x6e86c7b290d239808d828bae83536b9e879306ec985c6cc6f600100c8f348605", "0x02aa8dfd8f5fdfaf22778923d2d36316b8ac1d7b2434ca3d8dcf1742cc14ad5f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543959446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xcd8a5ba49b51c307e24001e1adf2f215ea730716"}, {name: "stake", type: "uint256", value: "22975"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "14175225000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"2112\", \"500000000\", \"28\", \"0xd96... )", async function( ) {
		const txOriginal = {blockNumber: "6826903", timeStamp: "1543959486", hash: "0x7f63837719d9eb8f533ccd559641de27c8aca6d28fb72265cf34e2709d4ece0b", nonce: "1", blockHash: "0x4a83b1e5fdf4d37740ff7701be9d45478018b92b562d90504298ff6c58ab66a0", transactionIndex: "99", from: "0x989a445987f81ab8f892c503cf360e0063c97982", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "225750", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000000840000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001cd967d39091f1bbc92ad8921ba1fd79cf4c5f8a586512c02590b0d268f3a136d97fd5bbb0a215fa16b209feaf018c54da443b153de3dd3f7c057bf15fb360a65c", contractAddress: "", cumulativeGasUsed: "2230659", gasUsed: "102419", confirmations: "856537"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "2112"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xd967d39091f1bbc92ad8921ba1fd79cf4c5f8a586512c02590b0d268f3a136d9"}, {type: "bytes32", name: "s", value: "0x7fd5bbb0a215fa16b209feaf018c54da443b153de3dd3f7c057bf15fb360a65c"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "2112", "500000000", "28", "0xd967d39091f1bbc92ad8921ba1fd79cf4c5f8a586512c02590b0d268f3a136d9", "0x7fd5bbb0a215fa16b209feaf018c54da443b153de3dd3f7c057bf15fb360a65c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1543959486 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x989a445987f81ab8f892c503cf360e0063c97982"}, {name: "stake", type: "uint256", value: "2092"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "12531620000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"27\", \"0xd0... )", async function( ) {
		const txOriginal = {blockNumber: "6826920", timeStamp: "1543959776", hash: "0xa84625ad221d8daaf36f0e785192732e5f33823c0dd5d91152f197e4ce47c32b", nonce: "1", blockHash: "0x4b006ad6e6c97d2c86c459156f6b4debf63a5bccc959ee7d9b1f47be9eb148d3", transactionIndex: "52", from: "0xce473125e7604cc6bdf61c852f2c408426b17d5c", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "225850", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bd09a3d3e5135f1027b3f30469a76a2466e88582dfde5cf7b7e6ceab01b6811c02d5651c2eeaf1deb2d3c69c132d551e8a4f1858922dd6ae11e725f87cc12085b", contractAddress: "", cumulativeGasUsed: "3744870", gasUsed: "102419", confirmations: "856520"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xd09a3d3e5135f1027b3f30469a76a2466e88582dfde5cf7b7e6ceab01b6811c0"}, {type: "bytes32", name: "s", value: "0x2d5651c2eeaf1deb2d3c69c132d551e8a4f1858922dd6ae11e725f87cc12085b"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "27", "0xd09a3d3e5135f1027b3f30469a76a2466e88582dfde5cf7b7e6ceab01b6811c0", "0x2d5651c2eeaf1deb2d3c69c132d551e8a4f1858922dd6ae11e725f87cc12085b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1543959776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xce473125e7604cc6bdf61c852f2c408426b17d5c"}, {name: "stake", type: "uint256", value: "30000"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "11972510000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"22720\", \"500000000\", \"27\", \"0x30... )", async function( ) {
		const txOriginal = {blockNumber: "6827520", timeStamp: "1543969231", hash: "0xc0ca7cb1a0a15e642e52d970bc7d1965999abbca29b06941da6e33eb028b53f9", nonce: "1", blockHash: "0x6702d3adb834e063df061d85f291592952323e62d86500141d5b99ef6cc7641e", transactionIndex: "90", from: "0xa55d1b6e216c6f0d29acde670ba6b4572e19d5db", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "236157", gasPrice: "19000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe000000000000000000000000000000000000000000000000000000000000058c0000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b30e3f951fc03ccd588035af7da04d396d00313dd874247a37a20bd4bd61e16cc76c3271b00cc6d26d13113f1d402237a6a6e2811b7cb553b2b68839218f688aa", contractAddress: "", cumulativeGasUsed: "4341321", gasUsed: "102355", confirmations: "855920"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "22720"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x30e3f951fc03ccd588035af7da04d396d00313dd874247a37a20bd4bd61e16cc"}, {type: "bytes32", name: "s", value: "0x76c3271b00cc6d26d13113f1d402237a6a6e2811b7cb553b2b68839218f688aa"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "22720", "500000000", "27", "0x30e3f951fc03ccd588035af7da04d396d00313dd874247a37a20bd4bd61e16cc", "0x76c3271b00cc6d26d13113f1d402237a6a6e2811b7cb553b2b68839218f688aa", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1543969231 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xa55d1b6e216c6f0d29acde670ba6b4572e19d5db"}, {name: "stake", type: "uint256", value: "22700"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "12740255000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"22193\", \"500000000\", \"28\", \"0x75... )", async function( ) {
		const txOriginal = {blockNumber: "6827647", timeStamp: "1543971283", hash: "0xe1758afd0d5e097112ba5ef5a983638a4ec8c029e77c1b6ac997e80c5b8ec360", nonce: "1", blockHash: "0x873f10339d83e5abf6f142af60cae56f32301703ecc8f7d8c5e26d3e1416fd32", transactionIndex: "54", from: "0x84a95dcd6997ef134bb4e134b624e5f189dd8088", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "224600", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe000000000000000000000000000000000000000000000000000000000000056b1000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c75664447e7fd19aa09c9a2fe5645be7e52d4822be71074d8084114a27ed022971532dec66cd628ef7585c0e9a0ea55e5d23d1f55e0f1cc7a30ac0715b0ef814a", contractAddress: "", cumulativeGasUsed: "4426775", gasUsed: "102419", confirmations: "855793"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "22193"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x75664447e7fd19aa09c9a2fe5645be7e52d4822be71074d8084114a27ed02297"}, {type: "bytes32", name: "s", value: "0x1532dec66cd628ef7585c0e9a0ea55e5d23d1f55e0f1cc7a30ac0715b0ef814a"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "22193", "500000000", "28", "0x75664447e7fd19aa09c9a2fe5645be7e52d4822be71074d8084114a27ed02297", "0x1532dec66cd628ef7585c0e9a0ea55e5d23d1f55e0f1cc7a30ac0715b0ef814a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1543971283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x84a95dcd6997ef134bb4e134b624e5f189dd8088"}, {name: "stake", type: "uint256", value: "22173"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "12531620000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"14680\", \"500000000\", \"27\", \"0xb6... )", async function( ) {
		const txOriginal = {blockNumber: "6827759", timeStamp: "1543972811", hash: "0x0d0e2e9a8b41f0aa74baa76d23a676aa7a831ecaaee8f70a46d08edbac0a73e6", nonce: "1", blockHash: "0x96f972ed472697d47298f011f28e0c6df831b23f1a88ca7ab2844f3125df6c75", transactionIndex: "30", from: "0x5503221ef9a426e525ec3b40f08893ac4ca7a408", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "226250", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000003958000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001bb656c6b48ec597d4e1eddee72c673c1ac40e1d840869ac8e88798d514e9fd92a1944c761b2e60fc3bc29e22f0bc503887971c644d378cccbbd81b0283fd2b39d", contractAddress: "", cumulativeGasUsed: "1044536", gasUsed: "102419", confirmations: "855681"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "14680"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xb656c6b48ec597d4e1eddee72c673c1ac40e1d840869ac8e88798d514e9fd92a"}, {type: "bytes32", name: "s", value: "0x1944c761b2e60fc3bc29e22f0bc503887971c644d378cccbbd81b0283fd2b39d"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "14680", "500000000", "27", "0xb656c6b48ec597d4e1eddee72c673c1ac40e1d840869ac8e88798d514e9fd92a", "0x1944c761b2e60fc3bc29e22f0bc503887971c644d378cccbbd81b0283fd2b39d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543972811 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x5503221ef9a426e525ec3b40f08893ac4ca7a408"}, {name: "stake", type: "uint256", value: "14660"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "12531620000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"11308\", \"500000000\", \"27\", \"0x60... )", async function( ) {
		const txOriginal = {blockNumber: "6828063", timeStamp: "1543977701", hash: "0x03879f908ac83d37ea12732a2142b180e1c55864b1a902fef8ad3b50c4423ac6", nonce: "1", blockHash: "0x90f2e9579b30232669ca3c523fe99aedad4c252b3e0033f95cf4b121b92dc3ae", transactionIndex: "12", from: "0x2dba6fb5bba2e418633a394c6ef52c427963776d", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "158172", gasPrice: "29000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000002c2c000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b60545dde895510d93e6f95e6ad8921abf07b3a895b5a786003a6aac2075c1bfc754f03170d8bdb2b964664cab6ddd2eff270510584bbba855a07134bcc96815c", contractAddress: "", cumulativeGasUsed: "998073", gasUsed: "102419", confirmations: "855377"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "11308"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x60545dde895510d93e6f95e6ad8921abf07b3a895b5a786003a6aac2075c1bfc"}, {type: "bytes32", name: "s", value: "0x754f03170d8bdb2b964664cab6ddd2eff270510584bbba855a07134bcc96815c"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "11308", "500000000", "27", "0x60545dde895510d93e6f95e6ad8921abf07b3a895b5a786003a6aac2075c1bfc", "0x754f03170d8bdb2b964664cab6ddd2eff270510584bbba855a07134bcc96815c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543977701 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x2dba6fb5bba2e418633a394c6ef52c427963776d"}, {name: "stake", type: "uint256", value: "11288"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "10871350000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"27\", \"0x3d... )", async function( ) {
		const txOriginal = {blockNumber: "6828130", timeStamp: "1543978673", hash: "0x7918b4dd97821ad4e04548ecec00952bf8580e886d0ff89a975baea4f40c1642", nonce: "0", blockHash: "0x9eef7e987998909e985cdbe9609a837f66e97b6574311433f8d795372ebfb879", transactionIndex: "83", from: "0xc666175c506f1dcc66345ffc64b3c760eb9b1f37", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "198913", gasPrice: "23000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b3d1bc78311ca64499699a6c43d32483729a3e8ddce958f3d7ade76fe9e6997e23aa86eb692a1e452c1a7896fd119d254e5b0499ca843a0b7304eeb721d3e411f", contractAddress: "", cumulativeGasUsed: "4705194", gasUsed: "196431", confirmations: "855310"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x3d1bc78311ca64499699a6c43d32483729a3e8ddce958f3d7ade76fe9e6997e2"}, {type: "bytes32", name: "s", value: "0x3aa86eb692a1e452c1a7896fd119d254e5b0499ca843a0b7304eeb721d3e411f"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "27", "0x3d1bc78311ca64499699a6c43d32483729a3e8ddce958f3d7ade76fe9e6997e2", "0x3aa86eb692a1e452c1a7896fd119d254e5b0499ca843a0b7304eeb721d3e411f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543978673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "14187983000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x0c... )", async function( ) {
		const txOriginal = {blockNumber: "6828273", timeStamp: "1543980646", hash: "0x0b4063afe13f4cd3a7c30144c987eeb2a0c8623bdff01f59b2005ede12be6713", nonce: "0", blockHash: "0x60da5103b9961cfdb20a4da536e07eaad147770e1ced55f35d8d87a83c7c785c", transactionIndex: "17", from: "0x8caa32cec20a6c3afa9fc3c4cae58cd4716f3231", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "270000", gasPrice: "17000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c0ccbe6bf6548a3d74bdb1be295fea1a2ae5ad9e33ece89d32b72c24bb98ac4af5be8671fcaba82f179bb17ba786442ec1649aa3fe54f59025e04ebabc9bc1d3c", contractAddress: "", cumulativeGasUsed: "791067", gasUsed: "266407", confirmations: "855167"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x0ccbe6bf6548a3d74bdb1be295fea1a2ae5ad9e33ece89d32b72c24bb98ac4af"}, {type: "bytes32", name: "s", value: "0x5be8671fcaba82f179bb17ba786442ec1649aa3fe54f59025e04ebabc9bc1d3c"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x0ccbe6bf6548a3d74bdb1be295fea1a2ae5ad9e33ece89d32b72c24bb98ac4af", "0x5be8671fcaba82f179bb17ba786442ec1649aa3fe54f59025e04ebabc9bc1d3c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543980646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "14128437000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x4e... )", async function( ) {
		const txOriginal = {blockNumber: "6828323", timeStamp: "1543981459", hash: "0x192222952a2390c6cea54a9400ed6c596236ea569dd5a3ea635f0eb13a4de8d7", nonce: "1", blockHash: "0x64a606cdfa520af6c62ba70b40507a71a152dcfdc80540e1201a7daf78ae5603", transactionIndex: "25", from: "0x570e729246a3761a1abbd6465f162e638bef5f04", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "254611", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c4e93222abbc75f90c95741e3e2153ab0f42c1fc01b668fb4757f471f6c756fb86d10f2cb2850b614e77db29286ccec64220a46a98e7e8cfdd91ecab83d53b207", contractAddress: "", cumulativeGasUsed: "902416", gasUsed: "102419", confirmations: "855117"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x4e93222abbc75f90c95741e3e2153ab0f42c1fc01b668fb4757f471f6c756fb8"}, {type: "bytes32", name: "s", value: "0x6d10f2cb2850b614e77db29286ccec64220a46a98e7e8cfdd91ecab83d53b207"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x4e93222abbc75f90c95741e3e2153ab0f42c1fc01b668fb4757f471f6c756fb8", "0x6d10f2cb2850b614e77db29286ccec64220a46a98e7e8cfdd91ecab83d53b207", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543981459 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x570e729246a3761a1abbd6465f162e638bef5f04"}, {name: "stake", type: "uint256", value: "30000"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "12610917000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"28\", \"0x0c... )", async function( ) {
		const txOriginal = {blockNumber: "6828353", timeStamp: "1543981991", hash: "0x427c6004ad4e99f43fb9617691972829d181382a02f2e79dafbe244d8f7daeb9", nonce: "1", blockHash: "0x19fbb6cb77c0d2de7ae259dc2bfabc0b2b3325c653ade562ac3a519ffdf51424", transactionIndex: "21", from: "0x8caa32cec20a6c3afa9fc3c4cae58cd4716f3231", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "287062", gasPrice: "16000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c0ccbe6bf6548a3d74bdb1be295fea1a2ae5ad9e33ece89d32b72c24bb98ac4af5be8671fcaba82f179bb17ba786442ec1649aa3fe54f59025e04ebabc9bc1d3c", contractAddress: "", cumulativeGasUsed: "1023080", gasUsed: "283202", confirmations: "855087"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x0ccbe6bf6548a3d74bdb1be295fea1a2ae5ad9e33ece89d32b72c24bb98ac4af"}, {type: "bytes32", name: "s", value: "0x5be8671fcaba82f179bb17ba786442ec1649aa3fe54f59025e04ebabc9bc1d3c"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "28", "0x0ccbe6bf6548a3d74bdb1be295fea1a2ae5ad9e33ece89d32b72c24bb98ac4af", "0x5be8671fcaba82f179bb17ba786442ec1649aa3fe54f59025e04ebabc9bc1d3c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1543981991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "14128437000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30020\", \"500000000\", \"27\", \"0x3d... )", async function( ) {
		const txOriginal = {blockNumber: "6828541", timeStamp: "1543984653", hash: "0xbfbd6eea304402d4416a2838f0fc8f50d72632eff73782279e7b3d5ea4e3be5e", nonce: "1", blockHash: "0x1279ce0928b95898d99df5e07c6afd553c2c01a3f14feaace01b9c6711a9d6a9", transactionIndex: "1", from: "0xc666175c506f1dcc66345ffc64b3c760eb9b1f37", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "306333", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007544000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b3d1bc78311ca64499699a6c43d32483729a3e8ddce958f3d7ade76fe9e6997e23aa86eb692a1e452c1a7896fd119d254e5b0499ca843a0b7304eeb721d3e411f", contractAddress: "", cumulativeGasUsed: "323172", gasUsed: "302172", confirmations: "854899"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30020"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x3d1bc78311ca64499699a6c43d32483729a3e8ddce958f3d7ade76fe9e6997e2"}, {type: "bytes32", name: "s", value: "0x3aa86eb692a1e452c1a7896fd119d254e5b0499ca843a0b7304eeb721d3e411f"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30020", "500000000", "27", "0x3d1bc78311ca64499699a6c43d32483729a3e8ddce958f3d7ade76fe9e6997e2", "0x3aa86eb692a1e452c1a7896fd119d254e5b0499ca843a0b7304eeb721d3e411f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1543984653 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "14187983000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"28\", \"0xdc... )", async function( ) {
		const txOriginal = {blockNumber: "6829414", timeStamp: "1543997069", hash: "0x16937d504248dc648fdc2837ab83068ad6998efac42b4f3662ed81bac06cdc6e", nonce: "0", blockHash: "0xfdec3caa06b5566c928b412901f926541c310484c4d544893620aff653a87100", transactionIndex: "171", from: "0x7b0e893c09936737fac376617c26091b6dfaa635", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "307533", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001cdcb3466f66e66936a4282fb54f3d6d7144bbf546f29ce41153604c6b58c5bbdf6b467370f05a0a406e14be3c75a37804d17b061be2cf4829af064d5ab1fdbe29", contractAddress: "", cumulativeGasUsed: "7200108", gasUsed: "303353", confirmations: "854026"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xdcb3466f66e66936a4282fb54f3d6d7144bbf546f29ce41153604c6b58c5bbdf"}, {type: "bytes32", name: "s", value: "0x6b467370f05a0a406e14be3c75a37804d17b061be2cf4829af064d5ab1fdbe29"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "28", "0xdcb3466f66e66936a4282fb54f3d6d7144bbf546f29ce41153604c6b58c5bbdf", "0x6b467370f05a0a406e14be3c75a37804d17b061be2cf4829af064d5ab1fdbe29", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1543997069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "12387081000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"28\", \"0x46... )", async function( ) {
		const txOriginal = {blockNumber: "6829466", timeStamp: "1543997839", hash: "0xec3e951f9f90fa447b3ac7c8c7c0d99ee9166b148f125d8d38a050a77a5bc228", nonce: "1", blockHash: "0xd890cc00b233c4b0678928b5bb5d2b1688ea8ea0500b7745eb5a5050a4067663", transactionIndex: "90", from: "0x11f5795a30a08191ba02d3a79439c8823d71c573", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "306333", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c46fcc9d612639a95179f562fd209eafc4f6d533ce874497e01c0686bed6bdba0141b269dd183581071e23ee552137a39772060b9cf36c2e9210470c47fc3eaff", contractAddress: "", cumulativeGasUsed: "4345923", gasUsed: "102419", confirmations: "853974"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x46fcc9d612639a95179f562fd209eafc4f6d533ce874497e01c0686bed6bdba0"}, {type: "bytes32", name: "s", value: "0x141b269dd183581071e23ee552137a39772060b9cf36c2e9210470c47fc3eaff"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "28", "0x46fcc9d612639a95179f562fd209eafc4f6d533ce874497e01c0686bed6bdba0", "0x141b269dd183581071e23ee552137a39772060b9cf36c2e9210470c47fc3eaff", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1543997839 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x11f5795a30a08191ba02d3a79439c8823d71c573"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "13169715000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"28\", \"0xdc... )", async function( ) {
		const txOriginal = {blockNumber: "6829553", timeStamp: "1543999091", hash: "0xe86339e1a54b5a66e8216dd6c0c8e5fb6a91032e3cb15f7d00b07a3da1e54400", nonce: "2", blockHash: "0xf9d827a72c660c687ecfc1d067957b199abe569cb199162ae1e73bd592c082cd", transactionIndex: "62", from: "0x7b0e893c09936737fac376617c26091b6dfaa635", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "255555", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001cdcb3466f66e66936a4282fb54f3d6d7144bbf546f29ce41153604c6b58c5bbdf6b467370f05a0a406e14be3c75a37804d17b061be2cf4829af064d5ab1fdbe29", contractAddress: "", cumulativeGasUsed: "2009950", gasUsed: "102419", confirmations: "853887"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xdcb3466f66e66936a4282fb54f3d6d7144bbf546f29ce41153604c6b58c5bbdf"}, {type: "bytes32", name: "s", value: "0x6b467370f05a0a406e14be3c75a37804d17b061be2cf4829af064d5ab1fdbe29"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "28", "0xdcb3466f66e66936a4282fb54f3d6d7144bbf546f29ce41153604c6b58c5bbdf", "0x6b467370f05a0a406e14be3c75a37804d17b061be2cf4829af064d5ab1fdbe29", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1543999091 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x7b0e893c09936737fac376617c26091b6dfaa635"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "12387081000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0x26... )", async function( ) {
		const txOriginal = {blockNumber: "6829727", timeStamp: "1544001368", hash: "0x5f20dd16f0736131cbfa1aba3be64ea7565449f4fbb3494a3cd01ef85b4074cd", nonce: "1", blockHash: "0x68fbc16259ab1b7896d6442cce24a8a58d60c8c8169fc0f52da6bcfb7c0f763b", transactionIndex: "67", from: "0xacffc41b5b0fe5a398e0a56336a04267b7f3efa3", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "228850", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b264f8ad907447c752d69863427a7bd4c8f09d07fe578be5ccc10dddff368fe8f09d3cd22de50d8a4f0d0d1e3022f467bf96941004170f7ba2744006f955d87da", contractAddress: "", cumulativeGasUsed: "4295720", gasUsed: "102291", confirmations: "853713"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x264f8ad907447c752d69863427a7bd4c8f09d07fe578be5ccc10dddff368fe8f"}, {type: "bytes32", name: "s", value: "0x09d3cd22de50d8a4f0d0d1e3022f467bf96941004170f7ba2744006f955d87da"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0x264f8ad907447c752d69863427a7bd4c8f09d07fe578be5ccc10dddff368fe8f", "0x09d3cd22de50d8a4f0d0d1e3022f467bf96941004170f7ba2744006f955d87da", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544001368 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xacffc41b5b0fe5a398e0a56336a04267b7f3efa3"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "14314585000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"27\", \"0x35... )", async function( ) {
		const txOriginal = {blockNumber: "6829836", timeStamp: "1544002866", hash: "0xadb8c803f961785c31bc7fab9effaf93440b1f3a520c11e25d45bfb0aa5873b2", nonce: "1", blockHash: "0xb8f36a7e832278d4190899a9956a9f9a8f6e6f609421cfd5ee608475e7ad38e9", transactionIndex: "44", from: "0xaef978a4719caf60c7f5bf7b879fb027a1475e84", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "326928", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001b352fecdde465dba22d1323fdf44159ffe014bdc49b8d6999796596418a7b334d3d0fbedd292625cc795b8c1261d1674a1962fe6635ef06b55c6525fbb6702353", contractAddress: "", cumulativeGasUsed: "2237078", gasUsed: "102419", confirmations: "853604"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x352fecdde465dba22d1323fdf44159ffe014bdc49b8d6999796596418a7b334d"}, {type: "bytes32", name: "s", value: "0x3d0fbedd292625cc795b8c1261d1674a1962fe6635ef06b55c6525fbb6702353"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "27", "0x352fecdde465dba22d1323fdf44159ffe014bdc49b8d6999796596418a7b334d", "0x3d0fbedd292625cc795b8c1261d1674a1962fe6635ef06b55c6525fbb6702353", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544002866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0xaef978a4719caf60c7f5bf7b879fb027a1475e84"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "11735211000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: deposit( \"30000\", \"500000000\", \"28\", \"0x2a... )", async function( ) {
		const txOriginal = {blockNumber: "6829896", timeStamp: "1544003750", hash: "0xedb240d84283a94d8866e0464be7986e0b37c36640324b35e99300571a24271b", nonce: "1", blockHash: "0x537c9078805233ec32313e5a838de1b024454cbed46abcb27ecf8700e97033e5", transactionIndex: "142", from: "0x25959032ffd816f0bbc49554564421d9f941ed10", to: "0xe93fc171cc8f5422efa2362509f9997d4148c04d", value: "0", gas: "457000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x7e34dbe00000000000000000000000000000000000000000000000000000000000007530000000000000000000000000000000000000000000000000000000001dcd6500000000000000000000000000000000000000000000000000000000000000001c2a896a46b713bb360a6f21ec3ec85a54bafc3bcd8b0006ef0928d8cae510e17622c4ed279222587bb9e500ede19a89c4f35c1acaef18b0f40f51d9c9537d4fa6", contractAddress: "", cumulativeGasUsed: "6028581", gasUsed: "102291", confirmations: "853544"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "value", value: "30000"}, {type: "uint256", name: "allowedMax", value: "500000000"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x2a896a46b713bb360a6f21ec3ec85a54bafc3bcd8b0006ef0928d8cae510e176"}, {type: "bytes32", name: "s", value: "0x22c4ed279222587bb9e500ede19a89c4f35c1acaef18b0f40f51d9c9537d4fa6"}], name: "deposit", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deposit(uint256,uint256,uint8,bytes32,bytes32)" ]( "30000", "500000000", "28", "0x2a896a46b713bb360a6f21ec3ec85a54bafc3bcd8b0006ef0928d8cae510e176", "0x22c4ed279222587bb9e500ede19a89c4f35c1acaef18b0f40f51d9c9537d4fa6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544003750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "holder", type: "address"}, {indexed: false, name: "stake", type: "uint256"}], name: "StakeUpdate", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "StakeUpdate", events: [{name: "holder", type: "address", value: "0x25959032ffd816f0bbc49554564421d9f941ed10"}, {name: "stake", type: "uint256", value: "29980"}], address: "0xe93fc171cc8f5422efa2362509f9997d4148c04d"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "11636799000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
