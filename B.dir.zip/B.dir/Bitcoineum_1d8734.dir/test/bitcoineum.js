const Bitcoineum = artifacts.require( "./Bitcoineum.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Bitcoineum" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x73dD069c299A5d691E9836243BcaeC9c8C1D8734", "0xdeaDDeADDEaDdeaDdEAddEADDEAdDeadDEADDEaD", "0xfeeD62E22DFB2C16A8Da2cC581Df5e0eEe2d5a4D", "0x6Cf889DA158ABec2a130c780342C3Cf673bCb428"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "current_external_block", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maximumSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalWeiCommitted", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_totalBlocksMined", type: "uint256"}], name: "calculate_base_mining_reward", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_blockNum", type: "uint256"}], name: "getBlockData", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bool"}, {name: "", type: "address"}, {name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "lastDifficultyAdjustmentEthereumBlock", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minimumDifficultyThresholdWei", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_totalWeiCommitted", type: "uint256"}, {name: "_totalWeiExpected", type: "uint256"}, {name: "_minimumDifficultyThresholdWei", type: "uint256"}, {name: "_difficultyScaleMultiplierLimit", type: "uint256"}], name: "calculate_next_expected_wei", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "INITIAL_SUPPLY", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "MAX_SUPPLY", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_blockNum", type: "uint256"}, {name: "_externalblock", type: "uint256"}], name: "checkBlockMature", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_blockNum", type: "uint256"}], name: "targetBlockNumber", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalBlocksMined", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "difficulty", type: "uint256"}, {name: "offset", type: "uint256"}], name: "calculate_range_attempt", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "divisible_units", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "checkMiningActive", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_blockNum", type: "uint256"}], name: "resolve_block_hash", outputs: [{name: "", type: "bytes32"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_totalBlocksMined", type: "uint256"}, {name: "_sender", type: "address"}, {name: "_blockNumber", type: "uint256"}], name: "calculate_reward", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "burnAddress", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "blockData", outputs: [{name: "targetDifficultyWei", type: "uint256"}, {name: "blockNumber", type: "uint256"}, {name: "totalMiningWei", type: "uint256"}, {name: "totalMiningAttempts", type: "uint256"}, {name: "currentAttemptOffset", type: "uint256"}, {name: "payed", type: "bool"}, {name: "payee", type: "address"}, {name: "isCreated", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getContractState", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "initial_reward", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_blockNum", type: "uint256"}, {name: "_sender", type: "address"}], name: "checkMiningAttempt", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "targetDifficultyWei", type: "uint256"}, {name: "totalMiningWei", type: "uint256"}, {name: "value", type: "uint256"}], name: "calculate_difficulty_attempt", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_blockNum", type: "uint256"}, {name: "_who", type: "address"}], name: "getMiningAttempt", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "address"}], name: "miningAttempts", outputs: [{name: "projectedOffset", type: "uint256"}, {name: "value", type: "uint256"}, {name: "isCreated", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "difficultyScaleMultiplierLimit", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "blockCreationRate", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "currentDifficultyWei", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_baseReward", type: "uint256"}, {name: "_userContributionWei", type: "uint256"}, {name: "_totalCommittedWei", type: "uint256"}], name: "calculate_proportional_reward", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_blockNum", type: "uint256"}, {name: "_externalblock", type: "uint256"}], name: "checkRedemptionWindow", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalWeiExpected", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "get_internal_block_number", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_blockNum", type: "uint256"}], name: "checkWinning", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "difficultyAdjustmentPeriod", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_blockNum", type: "uint256"}], name: "isBlockRedeemed", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "_externalBlockNum", type: "uint256"}], name: "external_to_internal_block_number", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "rewardAdjustmentPeriod", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "who", type: "address"}, {indexed: false, name: "baseContract", type: "address"}, {indexed: false, name: "transmutedContract", type: "address"}, {indexed: false, name: "sourceQuantity", type: "uint256"}, {indexed: false, name: "destQuantity", type: "uint256"}], name: "Transmuted", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_info", type: "string"}], name: "LogEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Transmuted(address,address,address,uint256,uint256)", "MiningAttemptEvent(address,uint256,uint256,uint256,uint256)", "LogEvent(string)", "BlockClaimedEvent(address,address,uint256,uint256)", "Approval(address,address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x11933e4bf668f8fb8314a699158eba5c7836ff5ece3f1bc3056c6c34ccc56e4a", "0x79974ce89535ebe44946f7f7d2814356530f301d744391e2da3cb544e8415bac", "0x0f9302c81771c0eee3c21199d1d5510ce78a68962d32a182bd71b8fb22a9ff1d", "0x02d996374be8c81683a2ac4abd51bbf94eaa161436677d4195541f2ef4cb63b8", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4042908 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4044551 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Bitcoineum", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "current_external_block", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "current_external_block()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maximumSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maximumSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalWeiCommitted", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWeiCommitted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_totalBlocksMined", value: random.range( maxRandom )}], name: "calculate_base_mining_reward", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculate_base_mining_reward(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_blockNum", value: random.range( maxRandom )}], name: "getBlockData", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bool"}, {name: "", type: "address"}, {name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBlockData(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lastDifficultyAdjustmentEthereumBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lastDifficultyAdjustmentEthereumBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimumDifficultyThresholdWei", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimumDifficultyThresholdWei()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_totalWeiCommitted", value: random.range( maxRandom )}, {type: "uint256", name: "_totalWeiExpected", value: random.range( maxRandom )}, {type: "uint256", name: "_minimumDifficultyThresholdWei", value: random.range( maxRandom )}, {type: "uint256", name: "_difficultyScaleMultiplierLimit", value: random.range( maxRandom )}], name: "calculate_next_expected_wei", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculate_next_expected_wei(uint256,uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "INITIAL_SUPPLY", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "INITIAL_SUPPLY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_SUPPLY", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_SUPPLY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_blockNum", value: random.range( maxRandom )}, {type: "uint256", name: "_externalblock", value: random.range( maxRandom )}], name: "checkBlockMature", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkBlockMature(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_blockNum", value: random.range( maxRandom )}], name: "targetBlockNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "targetBlockNumber(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalBlocksMined", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalBlocksMined()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "difficulty", value: random.range( maxRandom )}, {type: "uint256", name: "offset", value: random.range( maxRandom )}], name: "calculate_range_attempt", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculate_range_attempt(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "divisible_units", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "divisible_units()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "checkMiningActive", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkMiningActive()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_blockNum", value: random.range( maxRandom )}], name: "resolve_block_hash", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "resolve_block_hash(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_totalBlocksMined", value: random.range( maxRandom )}, {type: "address", name: "_sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_blockNumber", value: random.range( maxRandom )}], name: "calculate_reward", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculate_reward(uint256,address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "burnAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "burnAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "blockData", outputs: [{name: "targetDifficultyWei", type: "uint256"}, {name: "blockNumber", type: "uint256"}, {name: "totalMiningWei", type: "uint256"}, {name: "totalMiningAttempts", type: "uint256"}, {name: "currentAttemptOffset", type: "uint256"}, {name: "payed", type: "bool"}, {name: "payee", type: "address"}, {name: "isCreated", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "blockData(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getContractState", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getContractState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "initial_reward", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "initial_reward()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_blockNum", value: random.range( maxRandom )}, {type: "address", name: "_sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "checkMiningAttempt", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkMiningAttempt(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "targetDifficultyWei", value: random.range( maxRandom )}, {type: "uint256", name: "totalMiningWei", value: random.range( maxRandom )}, {type: "uint256", name: "value", value: random.range( maxRandom )}], name: "calculate_difficulty_attempt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculate_difficulty_attempt(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_blockNum", value: random.range( maxRandom )}, {type: "address", name: "_who", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getMiningAttempt", outputs: [{name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMiningAttempt(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "miningAttempts", outputs: [{name: "projectedOffset", type: "uint256"}, {name: "value", type: "uint256"}, {name: "isCreated", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "miningAttempts(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "difficultyScaleMultiplierLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "difficultyScaleMultiplierLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "blockCreationRate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "blockCreationRate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "currentDifficultyWei", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "currentDifficultyWei()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_baseReward", value: random.range( maxRandom )}, {type: "uint256", name: "_userContributionWei", value: random.range( maxRandom )}, {type: "uint256", name: "_totalCommittedWei", value: random.range( maxRandom )}], name: "calculate_proportional_reward", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",34] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculate_proportional_reward(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",34] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_blockNum", value: random.range( maxRandom )}, {type: "uint256", name: "_externalblock", value: random.range( maxRandom )}], name: "checkRedemptionWindow", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",35] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkRedemptionWindow(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",35] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalWeiExpected", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",36] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalWeiExpected()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",36] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "get_internal_block_number", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",37] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "get_internal_block_number()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",37] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",38] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",38] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_blockNum", value: random.range( maxRandom )}], name: "checkWinning", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",39] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "checkWinning(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",39] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "difficultyAdjustmentPeriod", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",40] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "difficultyAdjustmentPeriod()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",40] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_blockNum", value: random.range( maxRandom )}], name: "isBlockRedeemed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",41] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isBlockRedeemed(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",41] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_externalBlockNum", value: random.range( maxRandom )}], name: "external_to_internal_block_number", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",42] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "external_to_internal_block_number(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",42] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rewardAdjustmentPeriod", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",43] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rewardAdjustmentPeriod()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",43] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Bitcoineum", function( accounts ) {

	it( "TEST: Bitcoineum(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4042908", timeStamp: "1500449833", hash: "0xe35a03e898b5f3224a2345d1735312bf93c587ca20ece95e92423107e0dc8b26", nonce: "2", blockHash: "0x459c0c2c58e1a298283704d6990886ab69f90cbf1126237ed1826925b6b16e53", transactionIndex: "1", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: 0, value: "0", gas: "4712388", gasPrice: "100000000000", isError: "0", txreceipt_status: "", input: "0xa0979332", contractAddress: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", cumulativeGasUsed: "2610991", gasUsed: "2517813", confirmations: "3642001"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Bitcoineum", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Bitcoineum.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1500449833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Bitcoineum.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4042960", timeStamp: "1500450870", hash: "0x5f1c17197dcdc0e3e6a9d61818ee06db43fbccf4d961d1f8e2190f05ab1c3b1f", nonce: "4", blockHash: "0xe49b14cea0be75de244aff5c9d78881dff7bff2367b10c40c855701688c6bbba", transactionIndex: "73", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "400000", gasPrice: "20000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "3752413", gasUsed: "261380", confirmations: "3641949"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1500450870 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80859"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043011", timeStamp: "1500451743", hash: "0x3a817219046fcbd59bc47ae069fae703d6de9f9b9c34b623025cfa4765cc3c7a", nonce: "5", blockHash: "0x17f37a87707861b35396f111ee2598cff0c84a1415f73b75ffec63972e68262e", transactionIndex: "94", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "400000", gasPrice: "21322425083", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "5441894", gasUsed: "246380", confirmations: "3641898"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1500451743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80860"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80859\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043014", timeStamp: "1500451790", hash: "0x5e36ca97cc6c1fc4eb0f67d100d5f5eeee5ec1edb09b7e85d391e9e56a2e5edd", nonce: "6", blockHash: "0xb8aaa8bd8e2e5ca51daaeca6458c68cf68b2354fe024156abe482ffd3f9e4334", transactionIndex: "30", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "400000", gasPrice: "21322425083", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bdb0000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "902795", gasUsed: "116233", confirmations: "3641895"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80859"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80859", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1500451790 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80859"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043053", timeStamp: "1500452381", hash: "0x6c2699baf32e4ffb486ddead4b0c8d4acd53313006b30e255b1ab9be6de44506", nonce: "7", blockHash: "0xda1ccc6c2fb2b13e29c885e839a7db091445de708c79a499d827144c6b63d6fb", transactionIndex: "16", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "25082094675", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "653743", gasUsed: "246380", confirmations: "3641856"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1500452381 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80861"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043109", timeStamp: "1500453557", hash: "0xa739c4b3fa8ba0459c7fedb3fd8a5ca38c715b817650fb68cc7c3a06266f760e", nonce: "8", blockHash: "0x6e1d7f9c168e03efeb4a8c408a9a77c11309fa2d907c3b370aea81705c59a4e6", transactionIndex: "59", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "22623906115", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "2134718", gasUsed: "246380", confirmations: "3641800"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1500453557 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80862"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043153", timeStamp: "1500454620", hash: "0x36835707c69cc7287af29e9c1c2cbbeb419683c0aa4da1979fbb741d0e762a1e", nonce: "9", blockHash: "0x53ab632dd6154417cfa8fb771ff28b98976908f23221b71d54d28df12f71252b", transactionIndex: "46", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "22838588851", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1807610", gasUsed: "246380", confirmations: "3641756"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1500454620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80863"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80862\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043153", timeStamp: "1500454620", hash: "0xaa35044b4573f0442b63d87ccac4238056ac9efee3b81309a8fcb337d4019ece", nonce: "10", blockHash: "0x53ab632dd6154417cfa8fb771ff28b98976908f23221b71d54d28df12f71252b", transactionIndex: "47", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "22838588851", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bde0000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "1878843", gasUsed: "71233", confirmations: "3641756"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80862"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80862", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1500454620 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80862"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043203", timeStamp: "1500455669", hash: "0xfe89ba4a71f893483e6b5162cdc1fb5a991c2dd513fc8916d24ada1e6bc4aabf", nonce: "11", blockHash: "0x51c568e53c92b7884b104b4f78be3ee44ba1a10192090b79ce92afa406770625", transactionIndex: "65", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "22838588851", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1926034", gasUsed: "246380", confirmations: "3641706"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1500455669 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80864"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043252", timeStamp: "1500456485", hash: "0xce3177f30568e7548c97915f734ad5d520e9c8981ad6868ddc566552ff64d6cf", nonce: "12", blockHash: "0x57467984e52d13cc4112cc25514e01181a08534d24d06cff909bba32f4aa9a94", transactionIndex: "11", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "22838588851", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "529792", gasUsed: "246380", confirmations: "3641657"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1500456485 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80865"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80864\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043252", timeStamp: "1500456485", hash: "0x9ebc206e5e1c3dc6ce56e9caef203d98b7c1d8aa2addecf0364d5ccb9dbb6dfd", nonce: "13", blockHash: "0x57467984e52d13cc4112cc25514e01181a08534d24d06cff909bba32f4aa9a94", transactionIndex: "18", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "22838588851", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013be00000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "961343", gasUsed: "71233", confirmations: "3641657"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80864"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80864", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1500456485 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80864"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043303", timeStamp: "1500457477", hash: "0xb4202a7e4e4339aa6a0528f12f1c9b82fd4cc04215e210c5d2fb6d6d792ab7dd", nonce: "14", blockHash: "0x07960488a2b6c7a1675f2bccea5669ed2cadf6f1947044921f69c44b299e6e6f", transactionIndex: "2", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "288380", gasUsed: "246380", confirmations: "3641606"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1500457477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80866"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043352", timeStamp: "1500458519", hash: "0x79797547b482a3f993c10f1ee5ca82631fa0dcd1b23e4aae2385d4919ed42367", nonce: "15", blockHash: "0xdb565c0032c7f50d659fa2e9377a7d006067ef6dfd0c838c6163953d7515eb2f", transactionIndex: "16", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "759457", gasUsed: "246380", confirmations: "3641557"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1500458519 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80867"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80866\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043352", timeStamp: "1500458519", hash: "0x1f8580799bc7d04b59bc4603e1e3167d439b233a35f18908e5a7053ef918fc51", nonce: "16", blockHash: "0xdb565c0032c7f50d659fa2e9377a7d006067ef6dfd0c838c6163953d7515eb2f", transactionIndex: "17", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013be20000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "830690", gasUsed: "71233", confirmations: "3641557"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80866"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80866", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1500458519 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80866"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[13,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043402", timeStamp: "1500459447", hash: "0x9546108849cb56cb44c0447b9ae58c78e94e58fb8f7e253777f85ee0435cced7", nonce: "17", blockHash: "0x1f10bdf19d649f6bce36db68587d3173dc6b99bf2a20e33d9ca9aa380f39b15f", transactionIndex: "11", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "516193", gasUsed: "246380", confirmations: "3641507"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1500459447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80868"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043452", timeStamp: "1500460351", hash: "0x5c1db30ab5e884ef2f8ea57385f9c6a37debd1b2742f2279738ea65fe3191c3f", nonce: "18", blockHash: "0x10c9ec9b6dfa5cd2395cfd991163532534ab16eea5697a3e9c8c9595855303cd", transactionIndex: "33", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1368820", gasUsed: "246380", confirmations: "3641457"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1500460351 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80869"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80868\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043452", timeStamp: "1500460351", hash: "0x6c84aa51f28d8e28c6bf0d675b3b70b6f4d9920d2a9d98d16a484f9c68748727", nonce: "19", blockHash: "0x10c9ec9b6dfa5cd2395cfd991163532534ab16eea5697a3e9c8c9595855303cd", transactionIndex: "85", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013be40000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "3707224", gasUsed: "71233", confirmations: "3641457"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80868"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80868", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1500460351 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80868"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043503", timeStamp: "1500461249", hash: "0xd914423df48ac92f48fadbd0c2c7cfc12615c9b098ae224e21ba9e8a135b1e64", nonce: "20", blockHash: "0x580727a6d01a1b43d07ce59c9fe1e51666b085c383fe7fa040e7eacf7600dc5d", transactionIndex: "41", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1535248", gasUsed: "246380", confirmations: "3641406"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1500461249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80870"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043554", timeStamp: "1500462071", hash: "0x686661b018052ae9ab61a97afb687d4d416748187dcf147a9201fa2a0be01032", nonce: "21", blockHash: "0x94a14b5f9c77271d5f7a0afe8f90ec2ede08782c249cd11490d79e818c1807e5", transactionIndex: "7", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "507899", gasUsed: "246380", confirmations: "3641355"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1500462071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80871"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80870\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043554", timeStamp: "1500462071", hash: "0x46f726d07647bcdd27f549f59816f466266bb1fc789adaa747647877aee95ce2", nonce: "22", blockHash: "0x94a14b5f9c77271d5f7a0afe8f90ec2ede08782c249cd11490d79e818c1807e5", transactionIndex: "17", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013be60000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "1253435", gasUsed: "71233", confirmations: "3641355"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80870"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80870", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1500462071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80870"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043602", timeStamp: "1500463012", hash: "0xc944bcfa7da4e3fb13825324964675791c00aff15bfbb149a838c3e5f362866f", nonce: "23", blockHash: "0xb21a57b8edd73535b3347f3d799ca229cb17e8d7bdf3c41b0ff6059a5460704e", transactionIndex: "10", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "22528622017", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "556917", gasUsed: "246380", confirmations: "3641307"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1500463012 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80872"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043652", timeStamp: "1500463923", hash: "0xec2f59dc4d2c20e04c70408db3bc0a42e69948dc289ba1a6429cc2386ef4fd51", nonce: "24", blockHash: "0x7d86700e9448a92976ccd0a31b1be64d4ce2074be7160aea9e090a33fbb5b5c3", transactionIndex: "33", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1139998", gasUsed: "246380", confirmations: "3641257"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1500463923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80873"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80872\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043652", timeStamp: "1500463923", hash: "0x450bf3f5fcfb1f29225e8afa90ab027750c5bdd1262c13d02799359672d49a09", nonce: "25", blockHash: "0x7d86700e9448a92976ccd0a31b1be64d4ce2074be7160aea9e090a33fbb5b5c3", transactionIndex: "70", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "23000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013be80000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "2862070", gasUsed: "71233", confirmations: "3641257"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80872"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80872", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1500463923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80872"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043704", timeStamp: "1500465004", hash: "0x888a05620a1c8625b77332e1a0901a40e5bdd898dba04a5060dd6707292ea84c", nonce: "26", blockHash: "0x9dabbf33eaec7fcfaeb501b0fb52abd1254a023c68aa7590acc079d622670584", transactionIndex: "101", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "3567131", gasUsed: "246380", confirmations: "3641205"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1500465004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80874"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043753", timeStamp: "1500465838", hash: "0xc0bb90f201103132eef351b285cfe34cc97b7c4384b2d9246c1bf61db8418251", nonce: "27", blockHash: "0xf73675fdab808cac289ae3b7f492dc74a81fbe26815bc543e7a98f17c20313e3", transactionIndex: "14", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "670083", gasUsed: "246380", confirmations: "3641156"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1500465838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80875"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80874\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043753", timeStamp: "1500465838", hash: "0xf32ec8c74342d5a1f97092891a7376997c6119b4ba08cd132b7d02996fc57200", nonce: "28", blockHash: "0xf73675fdab808cac289ae3b7f492dc74a81fbe26815bc543e7a98f17c20313e3", transactionIndex: "15", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bea0000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "741316", gasUsed: "71233", confirmations: "3641156"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80874"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80874", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1500465838 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[25,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80874"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[25,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043802", timeStamp: "1500466776", hash: "0xf4bb6ccdb45eb9ccf3e8c7a1f73b6da205bcbba4f32618aec459a8b6a676040c", nonce: "29", blockHash: "0x4fafc5da660c96b4d01a9779e7aa12c777cde7ef2738f78899045e6a68a7b50e", transactionIndex: "45", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "2068261", gasUsed: "246380", confirmations: "3641107"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1500466776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80876"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80875\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043802", timeStamp: "1500466776", hash: "0xf675b7ae092032e0b33080dab18c51999b94d30d0e312254ab8b706a10118206", nonce: "30", blockHash: "0x4fafc5da660c96b4d01a9779e7aa12c777cde7ef2738f78899045e6a68a7b50e", transactionIndex: "93", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013beb0000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "3539290", gasUsed: "71233", confirmations: "3641107"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80875"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80875", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1500466776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80875"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043852", timeStamp: "1500467839", hash: "0xe553b0ca387527bfd3c3630a60ffca2c6c9e334233e688b0677d8838ddb6df4e", nonce: "31", blockHash: "0x9800489e1886065ed39784a8ec4f41f23db778d88bdbff1a76d117d1a18d4f6b", transactionIndex: "24", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1052246", gasUsed: "246380", confirmations: "3641057"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1500467839 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80877"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043903", timeStamp: "1500468650", hash: "0xa4554e18d255879f578382144c7f442d4a8d60c63c251bb53fdb679c728e18ce", nonce: "32", blockHash: "0x18c8399144b3d0a1a5a0627b9cc028b2895bf90bfddeafee2bcd99969e89056c", transactionIndex: "12", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "577380", gasUsed: "246380", confirmations: "3641006"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1500468650 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80878"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80877\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4043903", timeStamp: "1500468650", hash: "0x1301e51d2ac3eecf3e1fb15e89f7afcb12deb4b492a0438956e6fdef624018f6", nonce: "33", blockHash: "0x18c8399144b3d0a1a5a0627b9cc028b2895bf90bfddeafee2bcd99969e89056c", transactionIndex: "23", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bed0000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "910231", gasUsed: "71233", confirmations: "3641006"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80877"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80877", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1500468650 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80877"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4043952", timeStamp: "1500469626", hash: "0xbcc2799a19503d54391094921fa15a29ca6300d8c6ca8b7c9364639c3672e10b", nonce: "34", blockHash: "0xc6226a1f7edcc06f11e60e6e03f12949976d847dd2bedd2875926091705d00c9", transactionIndex: "37", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1836083", gasUsed: "246380", confirmations: "3640957"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1500469626 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80879"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044003", timeStamp: "1500470440", hash: "0xc3a7c78bb2056ba1ad6b848c6cac04e7363fab8fbdfbdb89c53d1b6dfb2baf4e", nonce: "35", blockHash: "0xa5443cfeeb12dd78031452a7699bb841a50143ed943d8503515f8dba9d6d7339", transactionIndex: "15", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "689297", gasUsed: "246380", confirmations: "3640906"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1500470440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80880"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80879\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4044003", timeStamp: "1500470440", hash: "0xd197af9e7c21f3e4df24e65f07147d2670b0f749a9924fd694d0141bebfbb6ab", nonce: "36", blockHash: "0xa5443cfeeb12dd78031452a7699bb841a50143ed943d8503515f8dba9d6d7339", transactionIndex: "16", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bef0000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "760530", gasUsed: "71233", confirmations: "3640906"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80879"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80879", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1500470440 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80879"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044052", timeStamp: "1500471287", hash: "0xe437dd0149f7eeb377286a03348ca65199664154fca664d43686f9a073937eba", nonce: "37", blockHash: "0x42c5bc12bb502899943b8ededba1132665de9a97c564e3d886939d9e593c9880", transactionIndex: "101", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "3918208", gasUsed: "246380", confirmations: "3640857"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1500471287 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80881"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044102", timeStamp: "1500472284", hash: "0x6f9e2cb1548688354830cd01cb6d5600d9b2f2e46f52fcec95b4e5736bfcb64e", nonce: "38", blockHash: "0x7b751b0fa539445628cd4e38075611a85f133e40465b0d13198ed11b143235c3", transactionIndex: "23", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1666543", gasUsed: "246380", confirmations: "3640807"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1500472284 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80882"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80881\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4044102", timeStamp: "1500472284", hash: "0x3adaacf84d0f97e6d0390ee7b840a9f5bfcfa88c01367894e26a63e3d48c7f1a", nonce: "39", blockHash: "0x7b751b0fa539445628cd4e38075611a85f133e40465b0d13198ed11b143235c3", transactionIndex: "62", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bf10000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "5335093", gasUsed: "71233", confirmations: "3640807"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80881"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80881", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1500472284 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[36,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80881"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[36,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[36,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044152", timeStamp: "1500473118", hash: "0x5e5331e058dc1ee7940a60b0540b412ea9d18beeb87cc6f2df9ffcd4c1ff184e", nonce: "40", blockHash: "0xe0fb17ad78cad5f9f1e78e930708a80af6b48f09aec2da075f2d8f47cfd09693", transactionIndex: "22", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1085563", gasUsed: "246380", confirmations: "3640757"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1500473118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80883"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044202", timeStamp: "1500473887", hash: "0x94bdf18870c3cc39cec2883cac03cb1c0700f3f481cb645b0a5e4befa18c6b06", nonce: "41", blockHash: "0x680d9ee05e53ad9aa88a244262c11d131ada919312fd32afd0d0c98fe58e226f", transactionIndex: "4", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "330380", gasUsed: "246380", confirmations: "3640707"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1500473887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80884"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80883\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4044202", timeStamp: "1500473887", hash: "0x452bd0783110c0b247ed846b96147f15816d963d6bb9d1da01e9b6b7a460923d", nonce: "42", blockHash: "0x680d9ee05e53ad9aa88a244262c11d131ada919312fd32afd0d0c98fe58e226f", transactionIndex: "9", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bf30000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "576030", gasUsed: "71233", confirmations: "3640707"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80883"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80883", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1500473887 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80883"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044252", timeStamp: "1500474806", hash: "0x84863d3ab52944e3946bc3d45d2e86aee60be45d6c76b3dde5f0b947e23e15bd", nonce: "43", blockHash: "0x541434714421f7226186f36c367fb2ad8855c91d3016a2721767927f8881da10", transactionIndex: "38", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "1760534", gasUsed: "246380", confirmations: "3640657"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1500474806 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80885"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044302", timeStamp: "1500475683", hash: "0xc5e51330e26827e6670977b64b957a5923f83ffbd9798dab23f56c910787cc61", nonce: "44", blockHash: "0x76f667d59f2a189311074e6770079a81d0fdf4d6cd7a051e61b3c75ec11c5b03", transactionIndex: "63", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "2527255", gasUsed: "246380", confirmations: "3640607"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1500475683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80886"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80885\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4044302", timeStamp: "1500475683", hash: "0x57d278a85e8741a5e53e3d3bf2fb2201cb6da738e150e2d71fed75f6a1e59ac8", nonce: "45", blockHash: "0x76f667d59f2a189311074e6770079a81d0fdf4d6cd7a051e61b3c75ec11c5b03", transactionIndex: "64", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bf50000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "2598488", gasUsed: "71233", confirmations: "3640607"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80885"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80885", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1500475683 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[42,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80885"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[42,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044352", timeStamp: "1500476537", hash: "0x6c49ec85060027762ba30017a698963d57dd09ca21072d507e9dc6e1e322fe40", nonce: "46", blockHash: "0x5a22aaaa547fa36c70f2d4944da1789e1e1471d86f19b12873ce869e370c65c0", transactionIndex: "4", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "729171", gasUsed: "246380", confirmations: "3640557"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1500476537 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80887"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044402", timeStamp: "1500477535", hash: "0x295066696e4f779897a19ff5787011cf1c0f6e41e8548e75506cfef52a84e45f", nonce: "47", blockHash: "0x5294d016443f1b19a1b047eaef99f878f79deda90143fc76afed07c97625d13d", transactionIndex: "17", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "634095", gasUsed: "246380", confirmations: "3640507"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1500477535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80888"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80887\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4044402", timeStamp: "1500477535", hash: "0x9d5c3d8eecd32988653fd5855a11847201936fd6149c101f36714710b7290bb2", nonce: "48", blockHash: "0x5294d016443f1b19a1b047eaef99f878f79deda90143fc76afed07c97625d13d", transactionIndex: "55", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bf70000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "2140219", gasUsed: "71233", confirmations: "3640507"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80887"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80887", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1500477535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80887"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044452", timeStamp: "1500478451", hash: "0x68c1606a1017678659496b7334503c69bb94f73c42762a00feab9874aad35240", nonce: "49", blockHash: "0x445f74b07d61c24a6c5e3f444a838dd3537f8712b5cec07cfd22f6a2c0f22de8", transactionIndex: "38", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "2900859", gasUsed: "246380", confirmations: "3640457"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1500478451 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80889"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044502", timeStamp: "1500479410", hash: "0x56b2d3e0c587848794b6b324c6e02c470054091021ef79666ce53d8dd7cb4218", nonce: "50", blockHash: "0x0f110fff16829837eb3efcc3bbf8b9308a852ffc6f53ca081995b2be35a0200e", transactionIndex: "4", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "379105", gasUsed: "246380", confirmations: "3640407"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1500479410 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80890"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: claim( \"80889\", addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4044502", timeStamp: "1500479410", hash: "0x5c70c9cc5bcdff883393f5926b62f4578fe121319dbb615c8eb8fa9642d88c28", nonce: "51", blockHash: "0x0f110fff16829837eb3efcc3bbf8b9308a852ffc6f53ca081995b2be35a0200e", transactionIndex: "5", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "0", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0xddd5e1b20000000000000000000000000000000000000000000000000000000000013bf90000000000000000000000006cf889da158abec2a130c780342c3cf673bcb428", contractAddress: "", cumulativeGasUsed: "450338", gasUsed: "71233", confirmations: "3640407"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_blockNumber", value: "80889"}, {type: "address", name: "forCreditTo", value: addressList[5]}], name: "claim", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claim(uint256,address)" ]( "80889", addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1500479410 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_forCreditTo", type: "address"}, {indexed: false, name: "_reward", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}], name: "BlockClaimedEvent", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BlockClaimedEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_forCreditTo", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "_reward", type: "uint256", value: "10000000000"}, {name: "_blockNumber", type: "uint256", value: "80889"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}, {name: "to", type: "address", value: "0x6cf889da158abec2a130c780342c3cf673bcb428"}, {name: "value", type: "uint256", value: "10000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[48,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: mine(  )", async function( ) {
		const txOriginal = {blockNumber: "4044551", timeStamp: "1500480357", hash: "0x51b7208149499f02408994cf5d7290f6ec3aad003a66a372ef278c8ce4d03a5d", nonce: "52", blockHash: "0xb964d0612ecb0ad7b86a45148cce022107d63b3e06b9bbd12e50174539cc77f0", transactionIndex: "44", from: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d", to: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734", value: "100000000000000", gas: "600000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x99f4b251", contractAddress: "", cumulativeGasUsed: "5870703", gasUsed: "246380", confirmations: "3640358"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "mine", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mine()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1500480357 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: true, name: "_blockNumber", type: "uint256"}, {indexed: false, name: "_totalMinedWei", type: "uint256"}, {indexed: false, name: "_targetDifficultyWei", type: "uint256"}], name: "MiningAttemptEvent", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MiningAttemptEvent", events: [{name: "_from", type: "address", value: "0xfeed62e22dfb2c16a8da2cc581df5e0eee2d5a4d"}, {name: "_value", type: "uint256", value: "100000000000000"}, {name: "_blockNumber", type: "uint256", value: "80891"}, {name: "_totalMinedWei", type: "uint256", value: "100000000000000"}, {name: "_targetDifficultyWei", type: "uint256", value: "100000000000000"}], address: "0x73dd069c299a5d691e9836243bcaec9c8c1d8734"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1460007547009433697" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
