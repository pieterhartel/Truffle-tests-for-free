const BookERC20EthV1 = artifacts.require( "./BookERC20EthV1.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BookERC20EthV1" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x8216DeAe8744A0286c8C53D8F237b65f661644e3", "0x884378D7919125BDfd337145d871a1bA2a58c0E9", "0xd26114cd6EE289AccF82350c8d8487fedB8A0C07", "0xEc2ca0Ef7CBBB49D5305f2f85dda24A9C5EDa305", "0xfeFc43fBa678a282fD354e29e0A9BCf5c10d053d", "0xeB198b469e4003a7b0c0395E2841d3E1Dfc88F87", "0x819785bee354C5A85fdeE9b748B68275221818A3", "0x81528e544Ca84525d7644E624800684229Bf4Bb5", "0x2ff4d83d13fb20B88614FBe38AACEaAdAd9d53FC", "0x9991c2797FD01F60ac99Ae9ebb881Cf3A2139B8F"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "fromPrice", type: "uint16"}], name: "walkBook", outputs: [{name: "price", type: "uint16"}, {name: "depthBase", type: "uint256"}, {name: "orderCount", type: "uint256"}, {name: "blockNumber", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "orderId", type: "uint128"}], name: "getOrder", outputs: [{name: "client", type: "address"}, {name: "price", type: "uint16"}, {name: "sizeBase", type: "uint256"}, {name: "terms", type: "uint8"}, {name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getBookInfo", outputs: [{name: "_bookType", type: "uint8"}, {name: "_baseToken", type: "address"}, {name: "_rwrdToken", type: "address"}, {name: "_baseMinInitialSize", type: "uint256"}, {name: "_cntrMinInitialSize", type: "uint256"}, {name: "_feeDivisor", type: "uint256"}, {name: "_feeCollector", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "orderId", type: "uint128"}], name: "getOrderState", outputs: [{name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "client", type: "address"}], name: "getClientBalances", outputs: [{name: "bookBalanceBase", type: "uint256"}, {name: "bookBalanceCntr", type: "uint256"}, {name: "bookBalanceRwrd", type: "uint256"}, {name: "approvedBalanceBase", type: "uint256"}, {name: "approvedBalanceRwrd", type: "uint256"}, {name: "ownBalanceBase", type: "uint256"}, {name: "ownBalanceRwrd", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "client", type: "address"}, {name: "maybeLastOrderIdReturned", type: "uint128"}, {name: "minClosedOrderIdCutoff", type: "uint128"}], name: "walkClientOrders", outputs: [{name: "orderId", type: "uint128"}, {name: "price", type: "uint16"}, {name: "sizeBase", type: "uint256"}, {name: "terms", type: "uint8"}, {name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["ClientPaymentEvent(address,uint8,uint8,int256)", "ClientOrderEvent(address,uint8,uint128)", "MarketOrderEvent(uint256,uint128,uint8,uint16,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xcaa7be131f5091d6ed32c02b2ba1f45c6721442175b1c8e1a9a5b453e54efe75", "0xbf4a185beeec77f147d27c32ec9b0ccabec6ddb7bcb31c7a8e08cb45a06e6636", "0x40d0a103f9440846844f8f9a0d6968bb70b1a10f7ce225d40eb8796c4993258d"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4311371 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4367338 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "BookERC20EthV1", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint16", name: "fromPrice", value: random.range( maxRandom )}], name: "walkBook", outputs: [{name: "price", type: "uint16"}, {name: "depthBase", type: "uint256"}, {name: "orderCount", type: "uint256"}, {name: "blockNumber", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "walkBook(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint128", name: "orderId", value: random.range( maxRandom )}], name: "getOrder", outputs: [{name: "client", type: "address"}, {name: "price", type: "uint16"}, {name: "sizeBase", type: "uint256"}, {name: "terms", type: "uint8"}, {name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOrder(uint128)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getBookInfo", outputs: [{name: "_bookType", type: "uint8"}, {name: "_baseToken", type: "address"}, {name: "_rwrdToken", type: "address"}, {name: "_baseMinInitialSize", type: "uint256"}, {name: "_cntrMinInitialSize", type: "uint256"}, {name: "_feeDivisor", type: "uint256"}, {name: "_feeCollector", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBookInfo()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint128", name: "orderId", value: random.range( maxRandom )}], name: "getOrderState", outputs: [{name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOrderState(uint128)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "client", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getClientBalances", outputs: [{name: "bookBalanceBase", type: "uint256"}, {name: "bookBalanceCntr", type: "uint256"}, {name: "bookBalanceRwrd", type: "uint256"}, {name: "approvedBalanceBase", type: "uint256"}, {name: "approvedBalanceRwrd", type: "uint256"}, {name: "ownBalanceBase", type: "uint256"}, {name: "ownBalanceRwrd", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getClientBalances(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "client", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint128", name: "maybeLastOrderIdReturned", value: random.range( maxRandom )}, {type: "uint128", name: "minClosedOrderIdCutoff", value: random.range( maxRandom )}], name: "walkClientOrders", outputs: [{name: "orderId", type: "uint128"}, {name: "price", type: "uint16"}, {name: "sizeBase", type: "uint256"}, {name: "terms", type: "uint8"}, {name: "status", type: "uint8"}, {name: "reasonCode", type: "uint8"}, {name: "executedBase", type: "uint256"}, {name: "executedCntr", type: "uint256"}, {name: "feesBaseOrCntr", type: "uint256"}, {name: "feesRwrd", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "walkClientOrders(address,uint128,uint128)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BookERC20EthV1", function( accounts ) {

	it( "TEST: BookERC20EthV1(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4311371", blockHash: "0x1f78cf91ef06a5bb12db95e69279a3b4a8b0bb7aa3996077b69f7f233552f95a", timeStamp: "1506372572", hash: "0xed3e3528d5ecaef3eee86ce5ba8bb3cfeffb42dd89cad0edaf7b935324a6a7f7", nonce: "2", transactionIndex: "36", from: "0x884378d7919125bdfd337145d871a1ba2a58c0e9", to: 0, value: "0", gas: "3314822", gasPrice: "8000000000", input: "0x17011011", contractAddress: "0x8216deae8744a0286c8c53d8f237b65f661644e3", cumulativeGasUsed: "5033085", txreceipt_status: "", gasUsed: "3314821", confirmations: "3395896", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "BookERC20EthV1", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BookERC20EthV1.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1506372572 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BookERC20EthV1.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "13717312240439179" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: init( addressList[4], addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4311389", blockHash: "0xd6fdfc8322945db4bdea39034a57c67996cb8f24dcef793925a5d56f6856c52e", timeStamp: "1506373065", hash: "0x76cf23e01defc30f18f8af5a7a5d8d0a3cc6ee0e9896d49e26f5ab9ef6e9177e", nonce: "3", transactionIndex: "148", from: "0x884378d7919125bdfd337145d871a1ba2a58c0e9", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "70505", gasPrice: "8000000000", input: "0xf09a4016000000000000000000000000d26114cd6ee289accf82350c8d8487fedb8a0c07000000000000000000000000ec2ca0ef7cbbb49d5305f2f85dda24a9c5eda305", contractAddress: "", cumulativeGasUsed: "5833953", txreceipt_status: "", gasUsed: "70504", confirmations: "3395878", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_baseToken", value: addressList[4]}, {type: "address", name: "_rwrdToken", value: addressList[5]}], name: "init", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "init(address,address)" ]( addressList[4], addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1506373065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "13717312240439179" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4311417", blockHash: "0x13ebff7561771a4d5bef3ff33f2dd551e48f316d58cfba7f4a42958563c15e46", timeStamp: "1506373885", hash: "0x20e358369bc84da054f8f0f69f0c999175be2ac25f6fc95017c6b198a3d66175", nonce: "1", transactionIndex: "73", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "250000", gasPrice: "8000000000", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "3616958", txreceipt_status: "", gasUsed: "71476", confirmations: "3395850", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1506373885 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 19, c: [200000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11934724574403221571673153504188580099... )", async function( ) {
		const txOriginal = {blockNumber: "4311425", blockHash: "0x5872ba5fd9fd4c09a86601eaa2fbac7afda2adaf927157d390d165c6221ebc58", timeStamp: "1506374110", hash: "0x4d2e9d5895d095d7479aa8b25c678945d46ddae247ffa9a9507b5384ded9037f", nonce: "2", transactionIndex: "41", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "600000", gasPrice: "8000000000", input: "0xbbec37680000000000000000000000000000000059c9718503294b19aafa35c86c6a8a210000000000000000000000000000000000000000000000000000000000003927000000000000000000000000000000000000000000000001158e460913d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "6261982", txreceipt_status: "", gasUsed: "236868", confirmations: "3395842", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119347245744032215716731535041885800993"}, {type: "uint16", name: "price", value: "14631"}, {type: "uint256", name: "sizeBase", value: "20000000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119347245744032215716731535041885800993", "14631", "20000000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1506374110 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11934724574, 40322157167315, 35041885800993]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1506374110"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c9718503294b19aafa35c86c6a8a21"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14631]}}, {name: "depthBase", type: "uint256", value: "20000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4311461", blockHash: "0x7ab0e84cdf605516a99bd9e43f2375965ffab20cd30ac849371a4e33a6c7c15d", timeStamp: "1506375000", hash: "0xd91db93ea63daa45be85b11b74ac4585b6f59b2fb51b9e10de2cc9c7a48e3586", nonce: "3", transactionIndex: "120", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "100000000000000000", gas: "150000", gasPrice: "4000000000", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "6578900", txreceipt_status: "", gasUsed: "44009", confirmations: "3395806", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1506375000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 17, c: [1000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11934734744949010681477401918876837553... )", async function( ) {
		const txOriginal = {blockNumber: "4311476", blockHash: "0xfc2de868852f5ff62a30a795fee334e707e7610b530d1faf152a0b57d592df28", timeStamp: "1506375428", hash: "0x2e5f43202b6f89c6aa94f95ea42f1f20fe9f1221a12def9edddc5a114b7f60d7", nonce: "4", transactionIndex: "6", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "600000", gasPrice: "21000000000", input: "0xbbec37680000000000000000000000000000000059c97688b738406fbe05beb22c1802f20000000000000000000000000000000000000000000000000000000000001b4400000000000000000000000000000000000000000000000029a2241af62c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "534882", txreceipt_status: "", gasUsed: "251066", confirmations: "3395791", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119347347449490106814774019188768375538"}, {type: "uint16", name: "price", value: "6980"}, {type: "uint256", name: "sizeBase", value: "3000000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119347347449490106814774019188768375538", "6980", "3000000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1506375428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11934734744, 94901068147740, 19188768375538]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1506375428"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c97688b738406fbe05beb22c1802f2"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [6980]}}, {name: "depthBase", type: "uint256", value: "3000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4311481", blockHash: "0x770cf0b995f57ee54902743b66631bdda3b9867796174f8185fcf468d5ffad43", timeStamp: "1506375726", hash: "0xb93000273b2cb0581284eea5abd3a579506adef2349ab8e6ca8ced52111f5be2", nonce: "6", transactionIndex: "113", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "500000000000000000", gas: "150000", gasPrice: "21000000000", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "5255887", txreceipt_status: "", gasUsed: "44009", confirmations: "3395786", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1506375726 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 17, c: [5000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11934738879095952914996268427253381222... )", async function( ) {
		const txOriginal = {blockNumber: "4311485", blockHash: "0x3a06703c08e07f8dd6741ae805dc58988703c2d16a9714e2226d12384ba10f6f", timeStamp: "1506375845", hash: "0x17e9e1d73f0c30c78559e8c9bd066869268cc4cc94d8853942905ba487155874", nonce: "7", transactionIndex: "53", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "600000", gasPrice: "8000000000", input: "0xbbec37680000000000000000000000000000000059c9789284b64097af79e8d9540fb4000000000000000000000000000000000000000000000000000000000000001b3a0000000000000000000000000000000000000000000000001158e460913d000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5431852", txreceipt_status: "", gasUsed: "313472", confirmations: "3395782", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119347388790959529149962684272533812224"}, {type: "uint16", name: "price", value: "6970"}, {type: "uint256", name: "sizeBase", value: "1250000000000000000"}, {type: "uint8", name: "terms", value: "2"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119347388790959529149962684272533812224", "6970", "1250000000000000000", "2", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1506375845 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11934738879, 9595291499626, 84272533812224]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1506375845"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c9718503294b19aafa35c86c6a8a21"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14631]}}, {name: "depthBase", type: "uint256", value: "1250000000000000000"}, {name: "tradeBase", type: "uint256", value: "1250000000000000000"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11934747979382503196374763640936676244... )", async function( ) {
		const txOriginal = {blockNumber: "4311525", blockHash: "0x4b5ffcf3f637d71becdadef89fc0a7170d79b4009c8fcc6f0d005fd45fda2c26", timeStamp: "1506376987", hash: "0xe6aee2b99d396e00141b048ee91c4d69d8187b9fbcde05703c8aa9fa152fa045", nonce: "8", transactionIndex: "38", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "8000000000", input: "0xbbec37680000000000000000000000000000000059c97d0f22d4487387719ae14d0053ca000000000000000000000000000000000000000000000000000000000000396c0000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4989435", txreceipt_status: "", gasUsed: "236040", confirmations: "3395742", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119347479793825031963747636409366762442"}, {type: "uint16", name: "price", value: "14700"}, {type: "uint256", name: "sizeBase", value: "1000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119347479793825031963747636409366762442", "14700", "1000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1506376987 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11934747979, 38250319637476, 36409366762442]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1506376987"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c97d0f22d4487387719ae14d0053ca"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14700]}}, {name: "depthBase", type: "uint256", value: "1000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11934755240687721956820271694264428043... )", async function( ) {
		const txOriginal = {blockNumber: "4311573", blockHash: "0xe94ae09240337a46c38dfca605e755c325ea0034517dec3cefc45cbee1ebdc4a", timeStamp: "1506378102", hash: "0x4c3f60a278704c68b2bd181b1c65922d9ebfb751d084f47d7a0935d949cecb91", nonce: "9", transactionIndex: "6", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "600000", gasPrice: "25000000000", input: "0xbbec37680000000000000000000000000000000059c980a3a4414559bb6afb9d9203fc710000000000000000000000000000000000000000000000000000000000001b580000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "942595", txreceipt_status: "", gasUsed: "233386", confirmations: "3395694", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119347552406877219568202716942644280433"}, {type: "uint16", name: "price", value: "7000"}, {type: "uint256", name: "sizeBase", value: "5000000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119347552406877219568202716942644280433", "7000", "5000000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1506378102 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11934755240, 68772195682027, 16942644280433]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1506378102"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c980a3a4414559bb6afb9d9203fc71"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7000]}}, {name: "depthBase", type: "uint256", value: "5000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"8750000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4311579", blockHash: "0xa1ff3c48d9405dcf2e3744fad3c67e42e87099679f92f3626c5ea12daf5dcff3", timeStamp: "1506378456", hash: "0x2d23eaf3ee73da0348b9448a40e68239c3ddbb60c7c0d5b5e8a97c2911cba0de", nonce: "10", transactionIndex: "173", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "4000000000", input: "0x199f0791000000000000000000000000000000000000000000000000001f161421c8e000", contractAddress: "", cumulativeGasUsed: "5855455", txreceipt_status: "", gasUsed: "37377", confirmations: "3395688", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "8750000000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "8750000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1506378456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 15, c: [87, 50000000000000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4332961", blockHash: "0x92d8e04bb00fe355327d3d9bc186cc0f8178d2e5fb0ca226c5f494e006fbf50d", timeStamp: "1507024943", hash: "0x1bb081e6545428ff1680a4954f6fa3f4bcebc3b3b56a51846d35ebe87e4ace59", nonce: "83", transactionIndex: "83", from: "0x819785bee354c5a85fdee9b748b68275221818a3", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "100000000000000000", gas: "150000", gasPrice: "21000000000", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "3958152", txreceipt_status: "", gasUsed: "44009", confirmations: "3374306", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1507024943 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x819785bee354c5a85fdee9b748b68275221818a3"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 17, c: [1000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1297298713777777777" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11939882728320212781320811741292712947... )", async function( ) {
		const txOriginal = {blockNumber: "4332973", blockHash: "0xceebd86c716ea40591529c0af739ae595772ed00aacd8b372601cbcecf4dc6cb", timeStamp: "1507025169", hash: "0xedf1c477a16005562a4a1896570859377287635e26162a36f121fbf00150cddd", nonce: "84", transactionIndex: "3", from: "0x819785bee354c5a85fdee9b748b68275221818a3", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "600000", gasPrice: "21000000000", input: "0xbbec37680000000000000000000000000000000059d360af91384a0b91bf53f1810c47840000000000000000000000000000000000000000000000000000000000001ba80000000000000000000000000000000000000000000000001bc16d674ec8000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "308134", txreceipt_status: "", gasUsed: "231664", confirmations: "3374294", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119398827283202127813208117412927129476"}, {type: "uint16", name: "price", value: "7080"}, {type: "uint256", name: "sizeBase", value: "2000000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119398827283202127813208117412927129476", "7080", "2000000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1507025169 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0x819785bee354c5a85fdee9b748b68275221818a3"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11939882728, 32021278132081, 17412927129476]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507025169"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d360af91384a0b91bf53f1810c4784"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7080]}}, {name: "depthBase", type: "uint256", value: "2000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1297298713777777777" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4334278", blockHash: "0x36b4c5472b63fd4ca9619ba2e8d5c18868bc73a5647f95b4e27caac3a618f955", timeStamp: "1507064874", hash: "0xe285f4b788e11e41bc77b488f687c76c8428beb0adb90113754110ae9bee91ff", nonce: "11", transactionIndex: "110", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "100000000000000000", gas: "150000", gasPrice: "10000000000", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "5141777", txreceipt_status: "", gasUsed: "29009", confirmations: "3372989", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1507064874 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 17, c: [1000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11934734744949010681477401918876837553... )", async function( ) {
		const txOriginal = {blockNumber: "4334330", blockHash: "0xea6a57553859f02b49a82be16ed8a1a086b13063554bdfc285071b39b4f1d06c", timeStamp: "1507066286", hash: "0x06a0c950d63a18cfc0deae5354debfa13e32c9a92f4df4028073b678537c7bcd", nonce: "5", transactionIndex: "82", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "10000000000", input: "0xdbc913960000000000000000000000000000000059c97688b738406fbe05beb22c1802f2", contractAddress: "", cumulativeGasUsed: "4199974", txreceipt_status: "", gasUsed: "47532", confirmations: "3372937", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119347347449490106814774019188768375538"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119347347449490106814774019188768375538", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1507066286 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507066286"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c97688b738406fbe05beb22c1802f2"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [6980]}}, {name: "depthBase", type: "uint256", value: "3000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11940224306944414091195346495069589772... )", async function( ) {
		const txOriginal = {blockNumber: "4334390", blockHash: "0x5ef606a752f6342e52fb661e01394b0bbdf0a16105e6dab40a255136ed6b5096", timeStamp: "1507068276", hash: "0x4cc47e5a8e9a8f8e83eac1c8aa3b6ce63f248694e018afcb740f3fc8019693aa", nonce: "6", transactionIndex: "86", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "21000000000", input: "0xbbec37680000000000000000000000000000000059d40918d9d44ece80d44ce51c5faa7f0000000000000000000000000000000000000000000000000000000000001b5300000000000000000000000000000000000000000000000029a2241af62c000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4866777", txreceipt_status: "", gasUsed: "233749", confirmations: "3372877", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119402243069444140911953464950695897727"}, {type: "uint16", name: "price", value: "6995"}, {type: "uint256", name: "sizeBase", value: "3000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119402243069444140911953464950695897727", "6995", "3000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1507068276 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11940224306, 94441409119534, 64950695897727]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507068276"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d40918d9d44ece80d44ce51c5faa7f"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [6995]}}, {name: "depthBase", type: "uint256", value: "3000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11940225637359299751752524839861439160... )", async function( ) {
		const txOriginal = {blockNumber: "4334398", blockHash: "0x1ed7f33aa7466e1eb430d642cdc99011ac60c2288abe70cc3a41c9be2e834232", timeStamp: "1507068465", hash: "0xcbc2f99c1451bd2e8d6967794f35c3e553aadf191565f7089e780ce9905f4ffd", nonce: "7", transactionIndex: "107", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "600000", gasPrice: "11000000000", input: "0xbbec37680000000000000000000000000000000059d409c0c5da4efc9e4759b62454eb320000000000000000000000000000000000000000000000000000000000001b530000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5556626", txreceipt_status: "", gasUsed: "249169", confirmations: "3372869", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119402256373592997517525248398614391602"}, {type: "uint16", name: "price", value: "6995"}, {type: "uint256", name: "sizeBase", value: "1000000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119402256373592997517525248398614391602", "6995", "1000000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1507068465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11940225637, 35929975175252, 48398614391602]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507068465"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d409c0c5da4efc9e4759b62454eb32"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [6995]}}, {name: "depthBase", type: "uint256", value: "1000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11940225637359299751752524839861439160... )", async function( ) {
		const txOriginal = {blockNumber: "4334403", blockHash: "0x32d19bff1d15d9e937287f423f6bca8782f94ba1d29ec2d548fddcfc4086b924", timeStamp: "1507068693", hash: "0x64d1628ffad227d9bd62e79682ec294b4d8c5f554de4232a79470649b4e2fd7a", nonce: "8", transactionIndex: "130", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "11000000000", input: "0xdbc913960000000000000000000000000000000059d409c0c5da4efc9e4759b62454eb32", contractAddress: "", cumulativeGasUsed: "6314678", txreceipt_status: "", gasUsed: "42232", confirmations: "3372864", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119402256373592997517525248398614391602"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119402256373592997517525248398614391602", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1507068693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507068693"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d409c0c5da4efc9e4759b62454eb32"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [6995]}}, {name: "depthBase", type: "uint256", value: "1000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11940224306944414091195346495069589772... )", async function( ) {
		const txOriginal = {blockNumber: "4337192", blockHash: "0x08d89ab0122706435d572a36eafe7b4ec54018a73a89fd543c9b709c081d81b4", timeStamp: "1507151899", hash: "0xf27b44cafa3e9b89055cf6cb180586ea400c32302ecdb73c0629aeae8b142da3", nonce: "9", transactionIndex: "86", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "21000000000", input: "0xdbc913960000000000000000000000000000000059d40918d9d44ece80d44ce51c5faa7f", contractAddress: "", cumulativeGasUsed: "3903791", txreceipt_status: "", gasUsed: "47532", confirmations: "3370075", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119402243069444140911953464950695897727"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119402243069444140911953464950695897727", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1507151899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507151899"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d40918d9d44ece80d44ce51c5faa7f"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [6995]}}, {name: "depthBase", type: "uint256", value: "3000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11940888651211747575370862318449894685... )", async function( ) {
		const txOriginal = {blockNumber: "4337199", blockHash: "0xc6bcee4a99e1dce38020ca6fde6c2afa16327385ebf82430b77532c00cbaafd1", timeStamp: "1507152067", hash: "0xc8a36f241756183f8f8f30810596e76dd29c1f137c4416437f895901cbffe95f", nonce: "10", transactionIndex: "81", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "21000000000", input: "0xbbec37680000000000000000000000000000000059d550a4e2d84c41a487f11facae732a0000000000000000000000000000000000000000000000000000000000001b8a0000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3775045", txreceipt_status: "", gasUsed: "231357", confirmations: "3370068", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119408886512117475753708623184498946858"}, {type: "uint16", name: "price", value: "7050"}, {type: "uint256", name: "sizeBase", value: "5000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119408886512117475753708623184498946858", "7050", "5000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1507152067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11940888651, 21174757537086, 23184498946858]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507152067"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d550a4e2d84c41a487f11facae732a"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7050]}}, {name: "depthBase", type: "uint256", value: "5000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11934755240687721956820271694264428043... )", async function( ) {
		const txOriginal = {blockNumber: "4337209", blockHash: "0x41adaf542f24bb259809d6ebef54f1afcaca555e723fa6f7e3064e8f145b4854", timeStamp: "1507152352", hash: "0x8aaf940470fd2759ee3df3f727037b6653f217cb06cdb760594f2314ab3afa07", nonce: "12", transactionIndex: "12", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "21000000000", input: "0xdbc913960000000000000000000000000000000059c980a3a4414559bb6afb9d9203fc71", contractAddress: "", cumulativeGasUsed: "441785", txreceipt_status: "", gasUsed: "47532", confirmations: "3370058", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119347552406877219568202716942644280433"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119347552406877219568202716942644280433", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1507152352 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507152352"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c980a3a4414559bb6afb9d9203fc71"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7000]}}, {name: "depthBase", type: "uint256", value: "5000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11940892681045070279128477677926794117... )", async function( ) {
		const txOriginal = {blockNumber: "4337216", blockHash: "0xe029a7ebbe457353168c5e34ae423ef56791f9e53d7a00230f1cd9d81d6255b3", timeStamp: "1507152595", hash: "0x104929ce8ccf9861253395ac83ae097a003df7e218af1b1a2434ba50f3ae5d6e", nonce: "13", transactionIndex: "37", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "600000", gasPrice: "10000000000", input: "0xbbec37680000000000000000000000000000000059d552a185c842f096d15cca1347a3350000000000000000000000000000000000000000000000000000000000001b8a00000000000000000000000000000000000000000000000029a2241af62c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "2525548", txreceipt_status: "", gasUsed: "246777", confirmations: "3370051", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119408926810450702791284776779267941173"}, {type: "uint16", name: "price", value: "7050"}, {type: "uint256", name: "sizeBase", value: "3000000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119408926810450702791284776779267941173", "7050", "3000000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1507152595 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11940892681, 4507027912847, 76779267941173]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507152595"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d552a185c842f096d15cca1347a335"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7050]}}, {name: "depthBase", type: "uint256", value: "3000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11941556335791652737107210507121296875... )", async function( ) {
		const txOriginal = {blockNumber: "4340053", blockHash: "0x17c63c135c4b9354ab6f99cb46dbb6b65585611114ba60db77dca909b2011a32", timeStamp: "1507236482", hash: "0xef454ca8eb8b1fab2cbc8d462668abbb55d00c53e669f93157ce397f4f9808a0", nonce: "14", transactionIndex: "103", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "21000000000", input: "0xbbec37680000000000000000000000000000000059d699d6872e478d824e82e361733b350000000000000000000000000000000000000000000000000000000000001b9400000000000000000000000000000000000000000000000006f05b59d3b2000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5301023", txreceipt_status: "", gasUsed: "231357", confirmations: "3367214", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119415563357916527371072105071212968757"}, {type: "uint16", name: "price", value: "7060"}, {type: "uint256", name: "sizeBase", value: "500000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119415563357916527371072105071212968757", "7060", "500000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1507236482 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11941556335, 79165273710721, 5071212968757]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507236482"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d699d6872e478d824e82e361733b35"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7060]}}, {name: "depthBase", type: "uint256", value: "500000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4345882", blockHash: "0x8289792e9705b861601e3b636e38490cd81121a8e3bc1f17ba5f4307eb4e4e98", timeStamp: "1507412572", hash: "0x012cc1cd4a32ac5771758d00c0e65e85e023bdfcf22624328324d5d44fe690c8", nonce: "0", transactionIndex: "51", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "1000000000000000000", gas: "150000", gasPrice: "21000000000", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "3453916", txreceipt_status: "", gasUsed: "44009", confirmations: "3361385", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1507412572 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [10000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"49075811000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4347583", blockHash: "0x1baa5eaacb331ac9e1b03b1abad1ab6f25b12e07e85d46255c235baf6e9ca19f", timeStamp: "1507463766", hash: "0xcdd055a34df20c26b889c0cf54ba20f0987ed1392519b1958cc061b7d5d0fec6", nonce: "1", transactionIndex: "104", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "20000000000", input: "0x199f079100000000000000000000000000000000000000000000000000ae5a30a9b81e00", contractAddress: "", cumulativeGasUsed: "4248338", txreceipt_status: "", gasUsed: "37377", confirmations: "3359684", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "49075811000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "49075811000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1507463766 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 16, c: [490, 75811000000000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"950924189000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4347586", blockHash: "0x6cc8224138c56d91d80b59b8e6b7732f6795b12e84bfc0f4b2a6f8b23302c305", timeStamp: "1507463836", hash: "0x014b56298c39b99fdd699cc781bde7e46a35448b92442f6c64506f82b802bd38", nonce: "2", transactionIndex: "91", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "20000000000", input: "0x199f07910000000000000000000000000000000000000000000000000d325c82fdabe200", contractAddress: "", cumulativeGasUsed: "3029431", txreceipt_status: "", gasUsed: "22441", confirmations: "3359681", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "950924189000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "950924189000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1507463836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 17, c: [9509, 24189000000000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4347808", blockHash: "0x61ee205c2c67e179ced8b58862cd45d0b44986500bd31435dca747bc43c5afea", timeStamp: "1507470313", hash: "0xd08908f77450464e01fd2482ccd14d7f528ab5a7d163336d69032aabd3aef8ac", nonce: "4", transactionIndex: "67", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "1000000000000000000", gas: "150000", gasPrice: "24000000000", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "4910825", txreceipt_status: "", gasUsed: "44009", confirmations: "3359459", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1507470313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [10000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawCntr( \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4347822", blockHash: "0x4e7875d1b5af210f7baa288efd86a38e841cc8ed64c38c340e9ff8663a2576c9", timeStamp: "1507470644", hash: "0x36a31174bcc7135952b552973bd4fab5f728306575754cf424b1d2ac5020b128", nonce: "5", transactionIndex: "17", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "50000000000", input: "0x199f07910000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "897534", txreceipt_status: "", gasUsed: "22377", confirmations: "3359445", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountCntr", value: "1000000000000000000"}], name: "withdrawCntr", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawCntr(uint256)" ]( "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1507470644 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "1"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 18, c: [10000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4347836", blockHash: "0x2baef7bb91af5787c4bc92e469bec3e33b5ed36c099c0d0dd4d8f8a54ccde679", timeStamp: "1507471379", hash: "0x56f0d9573e513e8729d6a2a1ea0efc3e755e2f461a845fa113052595c4b9d6ba", nonce: "6", transactionIndex: "90", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "1000000000000000000", gas: "150000", gasPrice: "50000000000", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "5023563", txreceipt_status: "", gasUsed: "44009", confirmations: "3359431", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1507471379 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [10000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11943434006873916778859638059396186614... )", async function( ) {
		const txOriginal = {blockNumber: "4347898", blockHash: "0x680f5339e8356dd8c43ecf7ea39c81c33c7ef874bcf73dabe7edaf119ec65cff", timeStamp: "1507473457", hash: "0x9b3a5a6eccd4973af8e0b90e90871ba9806b4617f9d6db9b504ffe43ebc1c351", nonce: "7", transactionIndex: "136", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "600000", gasPrice: "30000000000", input: "0xbbec37680000000000000000000000000000000059da3799f0064842b32466b76b3893a10000000000000000000000000000000000000000000000000000000000001b3a00000000000000000000000000000000000000000000000053444835ec58000000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "5090918", txreceipt_status: "", gasUsed: "283536", confirmations: "3359369", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119434340068739167788596380593961866145"}, {type: "uint16", name: "price", value: "6970"}, {type: "uint256", name: "sizeBase", value: "6000000000000000000"}, {type: "uint8", name: "terms", value: "2"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119434340068739167788596380593961866145", "6970", "6000000000000000000", "2", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1507473457 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11943434006, 87391677885963, 80593961866145]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507473457"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c9718503294b19aafa35c86c6a8a21"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14631]}}, {name: "depthBase", type: "uint256", value: "6000000000000000000"}, {name: "tradeBase", type: "uint256", value: "6000000000000000000"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: BookERC20EthV1(  )", async function( ) {
		const txOriginal = {blockNumber: "4348003", blockHash: "0xba20533af4e7997bba8d3e7266646ffdd6745a19bbf5f7a9f39a9dfd4eef3e1f", timeStamp: "1507476597", hash: "0x45ad669e8eee7cbf62fcd97da7bfa48aeced953c808188cfc6c73b0ea4f12836", nonce: "516", transactionIndex: "122", from: "0x2ff4d83d13fb20b88614fbe38aaceaadad9d53fc", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "24253", gasPrice: "12000000000", input: "0x17011011", contractAddress: "", cumulativeGasUsed: "2623430", txreceipt_status: "", gasUsed: "24253", confirmations: "3359264", isError: "1"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "BookERC20EthV1", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "93330099993470" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transferBase( \"5997000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4348021", blockHash: "0xb666749fd14ebd0bca9dad90b065de2bb75c9027211d26b8d3e29ca20aac4736", timeStamp: "1507477204", hash: "0x73299934dc01564ac47d8debf48695f81606b645c127e76cdbec6271e3b192d4", nonce: "8", transactionIndex: "3", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "250000", gasPrice: "60000000000", input: "0x3c13fc3300000000000000000000000000000000000000000000000053399fb9fe048000", contractAddress: "", cumulativeGasUsed: "290427", txreceipt_status: "", gasUsed: "45770", confirmations: "3359246", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountBase", value: "5997000000000000000"}], name: "transferBase", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferBase(uint256)" ]( "5997000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1507477204 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "3"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 18, c: [59970]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11943469508290601533407061308595759226... )", async function( ) {
		const txOriginal = {blockNumber: "4348042", blockHash: "0xb78480670b703a8543a29c219079d8648c6caedc7ea3ec1d912dcbafb2397149", timeStamp: "1507477855", hash: "0x19de28418a7d1d6b03da1a0e5120b1043d52d34caa6ab4e8420c521b249573df", nonce: "10", transactionIndex: "120", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "600000", gasPrice: "24000000000", input: "0xbbec37680000000000000000000000000000000059da491ad8aa47bcb509ee0c8ad714cb0000000000000000000000000000000000000000000000000000000000001b3a0000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "4298769", txreceipt_status: "", gasUsed: "284002", confirmations: "3359225", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119434695082906015334070613085957592267"}, {type: "uint16", name: "price", value: "6970"}, {type: "uint256", name: "sizeBase", value: "4000000000000000000"}, {type: "uint8", name: "terms", value: "0"}, {type: "uint256", name: "maxMatches", value: "3"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119434695082906015334070613085957592267", "6970", "4000000000000000000", "0", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1507477855 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11943469508, 29060153340706, 13085957592267]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507477855"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c9718503294b19aafa35c86c6a8a21"}, {name: "marketOrderEventType", type: "uint8", value: "3"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14631]}}, {name: "depthBase", type: "uint256", value: "4000000000000000000"}, {name: "tradeBase", type: "uint256", value: "4000000000000000000"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11934724574403221571673153504188580099... )", async function( ) {
		const txOriginal = {blockNumber: "4348661", blockHash: "0x1e5338d9c06e507cb5693595976c0d34a011e454e96467c6c5fd705e36ea29c7", timeStamp: "1507495517", hash: "0x282ebdaeae6ec1accd755a1f8ac38d0ae920a6c30a5dfa635e3e9c70f0a282a8", nonce: "11", transactionIndex: "124", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "22000000000", input: "0xdbc913960000000000000000000000000000000059c9718503294b19aafa35c86c6a8a21", contractAddress: "", cumulativeGasUsed: "3859156", txreceipt_status: "", gasUsed: "61965", confirmations: "3358606", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119347245744032215716731535041885800993"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119347245744032215716731535041885800993", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1507495517 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507495517"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059c9718503294b19aafa35c86c6a8a21"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14631]}}, {name: "depthBase", type: "uint256", value: "8750000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11943612868194229014793746575767753851... )", async function( ) {
		const txOriginal = {blockNumber: "4348677", blockHash: "0x34f27352d64b6d8cc429c84dfebfbc9c53d9ff9817281cfdbee564d09fbf29ef", timeStamp: "1507496033", hash: "0x195580c2866eb3f9236da5ce97bf0322ee200246cf3243939d526d337d363dc1", nonce: "12", transactionIndex: "26", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "22000000000", input: "0xbbec37680000000000000000000000000000000059da8fc968fb42eea40a7676a9224cd50000000000000000000000000000000000000000000000000000000000003904000000000000000000000000000000000000000000000000796e3ea3f8ab000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1428013", txreceipt_status: "", gasUsed: "234082", confirmations: "3358590", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119436128681942290147937465757677538517"}, {type: "uint16", name: "price", value: "14596"}, {type: "uint256", name: "sizeBase", value: "8750000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119436128681942290147937465757677538517", "14596", "8750000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1507496033 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11943612868, 19422901479374, 65757677538517]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507496033"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059da8fc968fb42eea40a7676a9224cd5"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14596]}}, {name: "depthBase", type: "uint256", value: "8750000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11940888651211747575370862318449894685... )", async function( ) {
		const txOriginal = {blockNumber: "4348679", blockHash: "0x6b4470e33e715eea76655e9981069ade680eb89efcbca33e47215f57d625fe7a", timeStamp: "1507496114", hash: "0x00a1829403700d9241c4f86f6dbafbf8d2bd6a76bd99c873ede857c3024adea3", nonce: "13", transactionIndex: "43", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "22000000000", input: "0xdbc913960000000000000000000000000000000059d550a4e2d84c41a487f11facae732a", contractAddress: "", cumulativeGasUsed: "1906477", txreceipt_status: "", gasUsed: "42146", confirmations: "3358588", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119408886512117475753708623184498946858"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119408886512117475753708623184498946858", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1507496114 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507496114"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d550a4e2d84c41a487f11facae732a"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7050]}}, {name: "depthBase", type: "uint256", value: "5000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11943613723463071563045528406297138508... )", async function( ) {
		const txOriginal = {blockNumber: "4348681", blockHash: "0xc5cde09386efa1e0004cf7b449b51c5bd3c770ff5531f821b9bc526660d57dc9", timeStamp: "1507496151", hash: "0xb4ece64cc1816715f8d7c1dc2acc97cdae254329f255edb6602988e8c6840c1f", nonce: "14", transactionIndex: "18", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "22000000000", input: "0xbbec37680000000000000000000000000000000059da90355c354feda1264c7eac4654f80000000000000000000000000000000000000000000000000000000000001ba30000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1090323", txreceipt_status: "", gasUsed: "231357", confirmations: "3358586", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119436137234630715630455284062971385080"}, {type: "uint16", name: "price", value: "7075"}, {type: "uint256", name: "sizeBase", value: "10000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119436137234630715630455284062971385080", "7075", "10000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1507496151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11943613723, 46307156304552, 84062971385080]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507496151"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059da90355c354feda1264c7eac4654f8"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7075]}}, {name: "depthBase", type: "uint256", value: "10000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: depositCntr(  )", async function( ) {
		const txOriginal = {blockNumber: "4348699", blockHash: "0x6d2c61566783f16ba429ef85646bbd79bbfccc3e1e0c867cc15e750b3dcc21ca", timeStamp: "1507496693", hash: "0x5fff0ce2f775d9e07c710eb07d70af6075dd8d3ad81679c4cecad27b4250832b", nonce: "0", transactionIndex: "115", from: "0x9991c2797fd01f60ac99ae9ebb881cf3a2139b8f", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "1000000000000000000", gas: "150000", gasPrice: "60000000000", input: "0x60445142", contractAddress: "", cumulativeGasUsed: "3716536", txreceipt_status: "", gasUsed: "44009", confirmations: "3358568", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositCntr", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositCntr()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1507496693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x9991c2797fd01f60ac99ae9ebb881cf3a2139b8f"}, {name: "clientPaymentEventType", type: "uint8", value: "0"}, {name: "balanceType", type: "uint8", value: "1"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [10000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1058069520000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: transferBase( \"3998000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4357451", blockHash: "0xc950d93766a5d93b498b34b142b800bfb5f2effed05eb4ace602f6eea10570db", timeStamp: "1507757645", hash: "0xe5706ea5d27c6a4755f7ed7308580fbdebb4f520d8d56d0db5e072932882e6cb", nonce: "11", transactionIndex: "3", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "250000", gasPrice: "50000000000", input: "0x3c13fc33000000000000000000000000000000000000000000000000377bbfd154030000", contractAddress: "", cumulativeGasUsed: "338992", txreceipt_status: "", gasUsed: "45706", confirmations: "3349816", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "amountBase", value: "3998000000000000000"}], name: "transferBase", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferBase(uint256)" ]( "3998000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1507757645 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "3"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: -1, e: 18, c: [39980]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: transferFromBase(  )", async function( ) {
		const txOriginal = {blockNumber: "4357473", blockHash: "0xa62c6c56f1a2dea7dc12ef4415cb4b8e4468287937998b48d2167bf0ac170def", timeStamp: "1507758384", hash: "0x61923f8705ef0858633a7c66288a31646f0ba7f234177a8c86e60727083fc901", nonce: "13", transactionIndex: "1", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "250000", gasPrice: "50000000000", input: "0x61ea6ed7", contractAddress: "", cumulativeGasUsed: "62476", txreceipt_status: "", gasUsed: "41476", confirmations: "3349794", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "transferFromBase", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFromBase()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1507758384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientPaymentEventType", type: "uint8"}, {indexed: false, name: "balanceType", type: "uint8"}, {indexed: false, name: "clientBalanceDelta", type: "int256"}], name: "ClientPaymentEvent", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "ClientPaymentEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientPaymentEventType", type: "uint8", value: "2"}, {name: "balanceType", type: "uint8", value: "0"}, {name: "clientBalanceDelta", type: "int256", value: {s: 1, e: 18, c: [50000]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11945695308434198382765625860269441709... )", async function( ) {
		const txOriginal = {blockNumber: "4357491", blockHash: "0x07f198b5eed0819751534349a382bad47087762e73c108e42400846985774c02", timeStamp: "1507758808", hash: "0xa3ee27db0bf456ad363a7d4a9ff7c74279eb7bc33ba7b9d31ee6f2b0c49f74cf", nonce: "14", transactionIndex: "45", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "22284624259", input: "0xbbec37680000000000000000000000000000000059de928252284a729c2fccac4bd11ac400000000000000000000000000000000000000000000000000000000000038e60000000000000000000000000000000000000000000000004563918244f4000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1600723", txreceipt_status: "", gasUsed: "253102", confirmations: "3349776", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119456953084341983827656258602694417092"}, {type: "uint16", name: "price", value: "14566"}, {type: "uint256", name: "sizeBase", value: "5000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119456953084341983827656258602694417092", "14566", "5000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1507758808 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11945695308, 43419838276562, 58602694417092]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507758808"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059de928252284a729c2fccac4bd11ac4"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 4, c: [14566]}}, {name: "depthBase", type: "uint256", value: "5000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11945698261345887049092473041344834184... )", async function( ) {
		const txOriginal = {blockNumber: "4357507", blockHash: "0x9956ef30436225dd89f7ffd9dfd048965f47d4f9a5c70fac9d11e6930e90a92b", timeStamp: "1507759161", hash: "0x52919509dc76acdff8e7bfcbf69ccd0b61fdee46646db58c366fbc4382633616", nonce: "15", transactionIndex: "74", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "20000000000", input: "0xbbec37680000000000000000000000000000000059de93f707e149078baefd8569bea9540000000000000000000000000000000000000000000000000000000000001b8a0000000000000000000000000000000000000000000000001bc16d674ec8000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5120165", txreceipt_status: "", gasUsed: "275403", confirmations: "3349760", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119456982613458870490924730413448341844"}, {type: "uint16", name: "price", value: "7050"}, {type: "uint256", name: "sizeBase", value: "2000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119456982613458870490924730413448341844", "7050", "2000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1507759161 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11945698261, 34588704909247, 30413448341844]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507759161"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059de93f707e149078baefd8569bea954"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7050]}}, {name: "depthBase", type: "uint256", value: "2000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11945724719600672956897695888374820128... )", async function( ) {
		const txOriginal = {blockNumber: "4357620", blockHash: "0x72e09646847d362d811809e9c518e346e698028732c0c9b0d551fbf3597768f1", timeStamp: "1507762522", hash: "0xc63bbb03edf2536fb08ff288124f23fdd59a647ff81302062dfc76ebd79054ea", nonce: "16", transactionIndex: "50", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "21000000000", input: "0xbbec37680000000000000000000000000000000059dea10288334b4faa1310813b7943480000000000000000000000000000000000000000000000000000000000001b8f0000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2641040", txreceipt_status: "", gasUsed: "259620", confirmations: "3349647", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119457247196006729568976958883748201288"}, {type: "uint16", name: "price", value: "7055"}, {type: "uint256", name: "sizeBase", value: "1000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119457247196006729568976958883748201288", "7055", "1000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1507762522 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11945724719, 60067295689769, 58883748201288]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507762522"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059dea10288334b4faa1310813b794348"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7055]}}, {name: "depthBase", type: "uint256", value: "1000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11945728836338234887677094973112797662... )", async function( ) {
		const txOriginal = {blockNumber: "4357637", blockHash: "0xcbd116935df371b97ecdf1aeaee622376c42d9e66303521ed187902d48677cd9", timeStamp: "1507763050", hash: "0xa1f45e9e6d735228ffe3e368a41ab6383402cd797b8b51719015de494a0de44a", nonce: "17", transactionIndex: "119", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "21000000000", input: "0xbbec37680000000000000000000000000000000059dea30a232a46b2ade61c32c140e2ac0000000000000000000000000000000000000000000000000000000000001b8e0000000000000000000000000000000000000000000000001bc16d674ec8000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5329150", txreceipt_status: "", gasUsed: "259754", confirmations: "3349630", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119457288363382348876770949731127976620"}, {type: "uint16", name: "price", value: "7054"}, {type: "uint256", name: "sizeBase", value: "2000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119457288363382348876770949731127976620", "7054", "2000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1507763050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11945728836, 33823488767709, 49731127976620]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1507763050"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059dea30a232a46b2ade61c32c140e2ac"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7054]}}, {name: "depthBase", type: "uint256", value: "2000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11945698261345887049092473041344834184... )", async function( ) {
		const txOriginal = {blockNumber: "4366220", blockHash: "0x189c22ab1a92e1b1396e923b6201fd83372fb94af2b9ab165631ca5851dfb5e7", timeStamp: "1508019576", hash: "0x0e7ff9f62da5c3e25d83ffac97d1c5e2f5b75261e0d7696048a80b5f52d90d18", nonce: "16", transactionIndex: "70", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "21000000000", input: "0xdbc913960000000000000000000000000000000059de93f707e149078baefd8569bea954", contractAddress: "", cumulativeGasUsed: "3203841", txreceipt_status: "", gasUsed: "42232", confirmations: "3341047", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119456982613458870490924730413448341844"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119456982613458870490924730413448341844", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1508019576 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508019576"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059de93f707e149078baefd8569bea954"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7050]}}, {name: "depthBase", type: "uint256", value: "2000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11940892681045070279128477677926794117... )", async function( ) {
		const txOriginal = {blockNumber: "4366224", blockHash: "0xe74b12599d5e413e7807a5ccdd268c30a313070ccdcd98d35c79e83a8dddf707", timeStamp: "1508019746", hash: "0x277c3c148e0fb354a62e76ecffb819063cb982520f2e4be5205fb57de50fe233", nonce: "17", transactionIndex: "132", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "21000000000", input: "0xdbc913960000000000000000000000000000000059d552a185c842f096d15cca1347a335", contractAddress: "", cumulativeGasUsed: "4985636", txreceipt_status: "", gasUsed: "47532", confirmations: "3341043", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119408926810450702791284776779267941173"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119408926810450702791284776779267941173", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1508019746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508019746"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d552a185c842f096d15cca1347a335"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7050]}}, {name: "depthBase", type: "uint256", value: "3000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11941556335791652737107210507121296875... )", async function( ) {
		const txOriginal = {blockNumber: "4366246", blockHash: "0x86b67935df5ac09460b2f17311c0bafa0c544f5a3bdfea7d83e638fd05061a38", timeStamp: "1508020407", hash: "0x9fb672c8f334348820633d61d9510963890e4520a494da6a132d7ea01661890b", nonce: "18", transactionIndex: "121", from: "0xeb198b469e4003a7b0c0395e2841d3e1dfc88f87", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "21000000000", input: "0xdbc913960000000000000000000000000000000059d699d6872e478d824e82e361733b35", contractAddress: "", cumulativeGasUsed: "4012334", txreceipt_status: "", gasUsed: "47532", confirmations: "3341021", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119415563357916527371072105071212968757"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119415563357916527371072105071212968757", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1508020407 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508020407"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059d699d6872e478d824e82e361733b35"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7060]}}, {name: "depthBase", type: "uint256", value: "500000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "76182745319632733" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11945728836338234887677094973112797662... )", async function( ) {
		const txOriginal = {blockNumber: "4366259", blockHash: "0x70539d65b2223d6624472775d51e0df63aad0c7529e75c615f20b71c1d72a325", timeStamp: "1508020959", hash: "0x7df84cc8079cf5a65477ddb007137fa1e9303f138234ff2c6eb348d0debe8e15", nonce: "18", transactionIndex: "62", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "10000000000", input: "0xdbc913960000000000000000000000000000000059dea30a232a46b2ade61c32c140e2ac", contractAddress: "", cumulativeGasUsed: "3845261", txreceipt_status: "", gasUsed: "47532", confirmations: "3341008", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119457288363382348876770949731127976620"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119457288363382348876770949731127976620", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1508020959 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508020959"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059dea30a232a46b2ade61c32c140e2ac"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7054]}}, {name: "depthBase", type: "uint256", value: "2000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: cancelOrder( \"11945724719600672956897695888374820128... )", async function( ) {
		const txOriginal = {blockNumber: "4366264", blockHash: "0x22b09df5b06248149c4fe6ed7ff79aee266c25af851ed0a712ca02bc2ac227d3", timeStamp: "1508021009", hash: "0xf0718c3c02a1ac48f8377e588fcb6c0af239797df2ba3915228c831aad4223d5", nonce: "19", transactionIndex: "15", from: "0xfefc43fba678a282fd354e29e0a9bcf5c10d053d", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "150000", gasPrice: "21000000000", input: "0xdbc913960000000000000000000000000000000059dea10288334b4faa1310813b794348", contractAddress: "", cumulativeGasUsed: "672061", txreceipt_status: "", gasUsed: "47532", confirmations: "3341003", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119457247196006729568976958883748201288"}], name: "cancelOrder", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancelOrder(uint128)" ]( "119457247196006729568976958883748201288", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1508021009 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508021009"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059dea10288334b4faa1310813b794348"}, {name: "marketOrderEventType", type: "uint8", value: "1"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7055]}}, {name: "depthBase", type: "uint256", value: "1000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "42781132350000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: createOrder( \"11948022477389302882504024237769598744... )", async function( ) {
		const txOriginal = {blockNumber: "4367338", blockHash: "0x50ece541dabf629a7a1ac2a7a41566c2679943876de5b3e9a5be22825171de4f", timeStamp: "1508052711", hash: "0xc40508a1d89dae04259cd6922cd710d902c0737b9e0d694a5ddc895cd462dcf1", nonce: "17", transactionIndex: "82", from: "0x81528e544ca84525d7644e624800684229bf4bb5", to: "0x8216deae8744a0286c8c53d8f237b65f661644e3", value: "0", gas: "300000", gasPrice: "21000000000", input: "0xbbec37680000000000000000000000000000000059e30de4569a44a295c0a3d0a34086f10000000000000000000000000000000000000000000000000000000000001bbc000000000000000000000000000000000000000000000001158e460913d0000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4785078", txreceipt_status: "", gasUsed: "253654", confirmations: "3339929", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint128", name: "orderId", value: "119480224773893028825040242377695987441"}, {type: "uint16", name: "price", value: "7100"}, {type: "uint256", name: "sizeBase", value: "20000000000000000000"}, {type: "uint8", name: "terms", value: "3"}, {type: "uint256", name: "maxMatches", value: "0"}], name: "createOrder", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "createOrder(uint128,uint16,uint256,uint8,uint256)" ]( "119480224773893028825040242377695987441", "7100", "20000000000000000000", "3", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1508052711 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "client", type: "address"}, {indexed: false, name: "clientOrderEventType", type: "uint8"}, {indexed: false, name: "orderId", type: "uint128"}], name: "ClientOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ClientOrderEvent", events: [{name: "client", type: "address", value: "0x81528e544ca84525d7644e624800684229bf4bb5"}, {name: "clientOrderEventType", type: "uint8", value: "0"}, {name: "orderId", type: "uint128", value: {s: 1, e: 38, c: [11948022477, 38930288250402, 42377695987441]}}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "eventTimestamp", type: "uint256"}, {indexed: true, name: "orderId", type: "uint128"}, {indexed: false, name: "marketOrderEventType", type: "uint8"}, {indexed: false, name: "price", type: "uint16"}, {indexed: false, name: "depthBase", type: "uint256"}, {indexed: false, name: "tradeBase", type: "uint256"}], name: "MarketOrderEvent", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MarketOrderEvent", events: [{name: "eventTimestamp", type: "uint256", value: "1508052711"}, {name: "orderId", type: "uint128", value: "0x0000000000000000000000000000000059e30de4569a44a295c0a3d0a34086f1"}, {name: "marketOrderEventType", type: "uint8", value: "0"}, {name: "price", type: "uint16", value: {s: 1, e: 3, c: [7100]}}, {name: "depthBase", type: "uint256", value: "20000000000000000000"}, {name: "tradeBase", type: "uint256", value: "0"}], address: "0x8216deae8744a0286c8c53d8f237b65f661644e3"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "626840000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
