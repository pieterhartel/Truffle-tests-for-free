const BancorX = artifacts.require( "./BancorX.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BancorX" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x98A741591049B6a92d7266a0668A26Aaf61A1b5e", "0xf2ad4572CE38408AC846852a8a2b361eCb76E4Fb", "0x52Ae12ABe5D8BD778BD5397F99cA900624CfADD4", "0x50249160741773B1FED5Aca6C7608D8ef6B50c64", "0xa606c89A511aAbb66Ec87b3367a2a26128578bb8", "0x452895Ae20b6E0C84628A7c34e22DDA58e2a5829", "0xbB2FB5FA152ecCf2B386dd67e68eAd76B963a94F", "0x00AD6821a8B859c9348d2BBe3e0eb3C7BbABbd75", "0x61b6DeD1A39Fb7e99Eb16671A50bd6bb7C430968", "0x03733D509f60a33f1B86856560256351f23e5531", "0x85F2921A8105F514F87aaF53625681516b4D5C4c", "0xcfdf7971527B019Cb68816ce5E5f8Db21c126B46"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "bntConverter", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BANCOR_CONVERTER_UPGRADER", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "prevLockLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentLockLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "prevLockBlockNumber", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BNT_TOKEN", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentReleaseLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "allowRegistryUpdate", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "CONTRACT_REGISTRY", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "reporters", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "prevReleaseBlockNumber", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxReleaseLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "version", outputs: [{name: "", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BANCOR_CONVERTER_FACTORY", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "prevRegistry", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BNT_CONVERTER", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BANCOR_FORMULA", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "limitIncPerBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "registry", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "CONTRACT_FEATURES", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "address"}], name: "reportedTxs", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BANCOR_NETWORK", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BANCOR_GAS_PRICE_LIMIT", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "reportingEnabled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "transactions", outputs: [{name: "amount", type: "uint256"}, {name: "fromBlockchain", type: "bytes32"}, {name: "to", type: "address"}, {name: "numOfReports", type: "uint8"}, {name: "completed", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxLockLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "bntToken", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BANCOR_X", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minRequiredReports", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "BANCOR_X_UPGRADER", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "prevReleaseLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "xTransfersEnabled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensRelease", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_prevOwner", type: "address"}, {indexed: true, name: "_newOwner", type: "address"}], name: "OwnerUpdate", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TokensLock(address,uint256)", "TokensRelease(address,uint256)", "XTransfer(address,bytes32,bytes32,uint256)", "TxReport(address,bytes32,uint256,address,uint256)", "OwnerUpdate(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xf5d7535a395393675f56d066384113754ca9cf4abd37298469934e2e9c2ec902", "0xbfdc1f3c02b4715077e0be4a262f967d53d4d0fcd76c6987fa2ad6e2257d7c8f", "0x75e2f0040f53a9c2fe9d30e9ed8a0c977b07631ba6fc9ec3b19bcdb930a7839c", "0x31927ab5615f4b14be043957c7f76b7425bc582a1d0bc9393433ada9df7a2c0c", "0x343765429aea5a34b3ff6a3785a98a5abb2597aca87bfbb58632c173d585373a"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6611679 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6641705 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "uint256", name: "_maxLockLimit", value: "40000000000000000000000"}, {type: "uint256", name: "_maxReleaseLimit", value: "80000000000000000000000"}, {type: "uint256", name: "_minLimit", value: "100000000000000000000"}, {type: "uint256", name: "_limitIncPerBlock", value: "45000000000000000000"}, {type: "uint256", name: "_minRequiredReports", value: "3"}, {type: "address", name: "_registry", value: 4}], name: "BancorX", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "bntConverter", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bntConverter()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BANCOR_CONVERTER_UPGRADER", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BANCOR_CONVERTER_UPGRADER()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "prevLockLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prevLockLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentLockLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentLockLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "prevLockBlockNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prevLockBlockNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BNT_TOKEN", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BNT_TOKEN()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentReleaseLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentReleaseLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "allowRegistryUpdate", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowRegistryUpdate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CONTRACT_REGISTRY", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CONTRACT_REGISTRY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "reporters", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reporters(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "prevReleaseBlockNumber", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prevReleaseBlockNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxReleaseLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxReleaseLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "version", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "version()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BANCOR_CONVERTER_FACTORY", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BANCOR_CONVERTER_FACTORY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "prevRegistry", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prevRegistry()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BNT_CONVERTER", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BNT_CONVERTER()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BANCOR_FORMULA", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BANCOR_FORMULA()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "limitIncPerBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "limitIncPerBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "registry", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "registry()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CONTRACT_FEATURES", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CONTRACT_FEATURES()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "reportedTxs", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reportedTxs(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BANCOR_NETWORK", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BANCOR_NETWORK()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BANCOR_GAS_PRICE_LIMIT", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BANCOR_GAS_PRICE_LIMIT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "reportingEnabled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reportingEnabled()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "transactions", outputs: [{name: "amount", type: "uint256"}, {name: "fromBlockchain", type: "bytes32"}, {name: "to", type: "address"}, {name: "numOfReports", type: "uint8"}, {name: "completed", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "transactions(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxLockLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxLockLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "bntToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bntToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BANCOR_X", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BANCOR_X()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minRequiredReports", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minRequiredReports()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BANCOR_X_UPGRADER", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BANCOR_X_UPGRADER()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "prevReleaseLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prevReleaseLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "xTransfersEnabled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",34] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "xTransfersEnabled()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",34] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BancorX", function( accounts ) {

	it( "TEST: BancorX( \"40000000000000000000000\", \"800000000... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6611679", timeStamp: "1540906038", hash: "0x81646ce7696bfa46c4aa2b989ffd2cd6ec0043f9aba7cfa7656487581f2bbaf0", nonce: "36", blockHash: "0x68b3b8a27488746119efe8be3497d4cdd8b5a891a528a3d58ab27302757b3cdb", transactionIndex: "78", from: "0xf2ad4572ce38408ac846852a8a2b361ecb76e4fb", to: 0, value: "0", gas: "2071963", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xd80ff8c5000000000000000000000000000000000000000000000878678326eac90000000000000000000000000000000000000000000000000010f0cf064dd5920000000000000000000000000000000000000000000000000000056bc75e2d6310000000000000000000000000000000000000000000000000000270801d946c940000000000000000000000000000000000000000000000000000000000000000000300000000000000000000000052ae12abe5d8bd778bd5397f99ca900624cfadd4", contractAddress: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", cumulativeGasUsed: "5938798", gasUsed: "2071963", confirmations: "1120780"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_maxLockLimit", value: "40000000000000000000000"}, {type: "uint256", name: "_maxReleaseLimit", value: "80000000000000000000000"}, {type: "uint256", name: "_minLimit", value: "100000000000000000000"}, {type: "uint256", name: "_limitIncPerBlock", value: "45000000000000000000"}, {type: "uint256", name: "_minRequiredReports", value: "3"}, {type: "address", name: "_registry", value: addressList[4]}], name: "BancorX", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BancorX.new( "40000000000000000000000", "80000000000000000000000", "100000000000000000000", "45000000000000000000", "3", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540906038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BancorX.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "104733415462169314" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "6611709", timeStamp: "1540906499", hash: "0x55da5f7690104d172bebf5a7b4575de7761e4d0b2648bd07a3dbc5de5fd5df13", nonce: "37", blockHash: "0x7ea646e460ce6fbd62d3001fe00c9324a1b3b2b5a782684bb131bc79bd5e08c6", transactionIndex: "103", from: "0xf2ad4572ce38408ac846852a8a2b361ecb76e4fb", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "29890", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf2fde38b00000000000000000000000050249160741773b1fed5aca6c7608d8ef6b50c64", contractAddress: "", cumulativeGasUsed: "7753079", gasUsed: "29890", confirmations: "1120750"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_newOwner", value: addressList[5]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540906499 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "104733415462169314" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: enableReporting( false )", async function( ) {
		const txOriginal = {blockNumber: "6611757", timeStamp: "1540907229", hash: "0x94689a23afa470cf5cfc3a8018cc13865fee396d536edc01747771d69161e132", nonce: "38", blockHash: "0x3da1a26fe0b37afc289a5d12be3a1a19080552b47ff6c02c7946284a825911b6", transactionIndex: "38", from: "0xf2ad4572ce38408ac846852a8a2b361ecb76e4fb", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "28211", gasPrice: "8920000000", isError: "0", txreceipt_status: "1", input: "0xed1d73a60000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2068405", gasUsed: "28211", confirmations: "1120702"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "_enable", value: false}], name: "enableReporting", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enableReporting(bool)" ]( false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540907229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "104733415462169314" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: enableXTransfers( false )", async function( ) {
		const txOriginal = {blockNumber: "6611759", timeStamp: "1540907261", hash: "0xa688c0867195bcff60e4b5ad87cb485dcd05344f8b92c4701fe176f861235418", nonce: "39", blockHash: "0xe591e6c6bb331571769683e47bac347969e8a4cf091b61f2ecca65131e1d4093", transactionIndex: "128", from: "0xf2ad4572ce38408ac846852a8a2b361ecb76e4fb", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "27947", gasPrice: "8361282716", isError: "0", txreceipt_status: "1", input: "0xa5c670ca0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7553392", gasUsed: "27947", confirmations: "1120700"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "_enable", value: false}], name: "enableXTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enableXTransfers(bool)" ]( false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540907261 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "104733415462169314" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: acceptOwnership(  )", async function( ) {
		const txOriginal = {blockNumber: "6623136", timeStamp: "1541068399", hash: "0x984d873bde3246eafd2b6db1dcd84c5e3254ddfb827dc46c77bc0ba277285f42", nonce: "134", blockHash: "0xf49861f9c57f5d91ec29ecfe23610d8f0faed27f36fa9644706ad626a3dae7bf", transactionIndex: "2", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "300000", gasPrice: "70000000000", isError: "0", txreceipt_status: "1", input: "0x79ba5097", contractAddress: "", cumulativeGasUsed: "108549", gasUsed: "34808", confirmations: "1109323"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "acceptOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptOwnership()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541068399 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_prevOwner", type: "address"}, {indexed: true, name: "_newOwner", type: "address"}], name: "OwnerUpdate", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnerUpdate", events: [{name: "_prevOwner", type: "address", value: "0xf2ad4572ce38408ac846852a8a2b361ecb76e4fb"}, {name: "_newOwner", type: "address", value: "0x50249160741773b1fed5aca6c7608d8ef6b50c64"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setMinLimit( \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6623921", timeStamp: "1541079863", hash: "0xc7e65fada216e92e1df2f9f757bcaa84ef3f3a7c30f198d595528bc6cf6ad235", nonce: "139", blockHash: "0xfdfce9b9160731e483a12f44d361e37e80a11f3330e3731f78502c76f683b686", transactionIndex: "34", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "27748", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x6ec6d4a60000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "7998056", gasUsed: "27748", confirmations: "1108538"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minLimit", value: "1000000000000000000"}], name: "setMinLimit", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMinLimit(uint256)" ]( "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541079863 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setLimitIncPerBlock( \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6623926", timeStamp: "1541079913", hash: "0xcc86ba18d9ebed64481dc84d6a899acb1cbfcea1f5d0d37a6d7383405622e58a", nonce: "140", blockHash: "0x92d51a96a757c7628b93e36a876c3601b1c95bd50b74be014e6a5ff3bfb227a7", transactionIndex: "101", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "27990", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa50c326c0000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "7753566", gasUsed: "27990", confirmations: "1108533"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_limitIncPerBlock", value: "1000000000000000000"}], name: "setLimitIncPerBlock", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setLimitIncPerBlock(uint256)" ]( "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541079913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setMaxLockLimit( \"50000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6623929", timeStamp: "1541079970", hash: "0x821a9f44c9a70a145a9cbf5c345cad57bbab805d3fb609a5a5c82dbdb2403b0c", nonce: "141", blockHash: "0x42bb0e96fb4dfcd4b6f25a0a5db214a130d55f73b50b825153014c1024a5aad0", transactionIndex: "55", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "28120", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xaf2b9618000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "5294198", gasUsed: "28120", confirmations: "1108530"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_maxLockLimit", value: "50000000000000000000"}], name: "setMaxLockLimit", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMaxLockLimit(uint256)" ]( "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541079970 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setMaxReleaseLimit( \"100000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6623932", timeStamp: "1541080017", hash: "0xdadade1fd141090181ca098eb8d2b199160039d1fa50aa6c54e8cdd849322a94", nonce: "142", blockHash: "0x9f1f91de8d886c5c556419f84f3d88725e5f9330d08ac13574407aeed66ae52c", transactionIndex: "105", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "28186", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xbf28ece40000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "6541620", gasUsed: "28186", confirmations: "1108527"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_maxReleaseLimit", value: "100000000000000000000"}], name: "setMaxReleaseLimit", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMaxReleaseLimit(uint256)" ]( "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541080017 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: setReporter( addressList[6], true )", async function( ) {
		const txOriginal = {blockNumber: "6623962", timeStamp: "1541080471", hash: "0xd17b15b5e2449676d8bff2faf4d7afe294743e8f2514f197ddf7bfc3288621fa", nonce: "143", blockHash: "0x9003b28e8639a1dc090a6caae5e27c2b26d5e7a95cf708e2f5fd4fd6f17d946c", transactionIndex: "48", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "44815", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe1bb5133000000000000000000000000a606c89a511aabb66ec87b3367a2a26128578bb80000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "6940905", gasUsed: "44815", confirmations: "1108497"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_reporter", value: addressList[6]}, {type: "bool", name: "_active", value: true}], name: "setReporter", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setReporter(address,bool)" ]( addressList[6], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541080471 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setReporter( addressList[7], true )", async function( ) {
		const txOriginal = {blockNumber: "6623966", timeStamp: "1541080536", hash: "0x91f930a3dd71d62d16a2b636c8022b86bc66335dfeebaf963c587cf74c8eb8c6", nonce: "144", blockHash: "0xaeaf6653ccb5bcea17e0cd1b55a5faf74f0bedeacf7cd06facc5026a42284dcf", transactionIndex: "118", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "44815", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe1bb5133000000000000000000000000452895ae20b6e0c84628a7c34e22dda58e2a58290000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7661525", gasUsed: "44815", confirmations: "1108493"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_reporter", value: addressList[7]}, {type: "bool", name: "_active", value: true}], name: "setReporter", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setReporter(address,bool)" ]( addressList[7], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541080536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: setReporter( addressList[8], true )", async function( ) {
		const txOriginal = {blockNumber: "6623966", timeStamp: "1541080536", hash: "0xa17a135318fa44fe3e7c354c4184ebbdcfab101c45b3e5631bc78d1a3513f32f", nonce: "145", blockHash: "0xaeaf6653ccb5bcea17e0cd1b55a5faf74f0bedeacf7cd06facc5026a42284dcf", transactionIndex: "119", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "44815", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe1bb5133000000000000000000000000bb2fb5fa152eccf2b386dd67e68ead76b963a94f0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "7706340", gasUsed: "44815", confirmations: "1108493"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_reporter", value: addressList[8]}, {type: "bool", name: "_active", value: true}], name: "setReporter", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setReporter(address,bool)" ]( addressList[8], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541080536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: enableXTransfers( true )", async function( ) {
		const txOriginal = {blockNumber: "6624501", timeStamp: "1541087756", hash: "0x0704c089adb71874e56247a7aca2f932129254860287da43303e356636b34755", nonce: "150", blockHash: "0xab99406481ddc22c25530a0a35a55ca76617300811ee155610bdddf9557838e4", transactionIndex: "27", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "300000", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xa5c670ca0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1052642", gasUsed: "28011", confirmations: "1107958"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "_enable", value: true}], name: "enableXTransfers", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enableXTransfers(bool)" ]( true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541087756 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6625008", timeStamp: "1541095050", hash: "0x2d173ff09885de718fa8fd25feb84ae8e734192cf4f5bfebec61fbd9a5e11a41", nonce: "296", blockHash: "0x25e05472c251899d28e19c26d08237d8f119f0c31277497a9aa79c99d2157fd4", transactionIndex: "67", from: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e31313100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "4364892", gasUsed: "94384", confirmations: "1107451"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541095050 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "342089197913606092" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6626634", timeStamp: "1541118126", hash: "0xda84e7e0f904f02d8606d1009c7b6ba8f60bfbfb5e7a21b969c2ae720953084b", nonce: "0", blockHash: "0xd9c8d28b92f0c674d839367d19e6c4f2549fcf6a5ecf4d0ebe20d5e025cdb929", transactionIndex: "48", from: "0x61b6ded1a39fb7e99eb16671a50bd6bb7c430968", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e31313100000000000000000000000000000000000000000000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "5278673", gasUsed: "79384", confirmations: "1105825"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "2000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000", "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541118126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x61b6ded1a39fb7e99eb16671a50bd6bb7c430968"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x61b6ded1a39fb7e99eb16671a50bd6bb7c430968"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "98562320000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628221", timeStamp: "1541141491", hash: "0xad69b3fdb92981b601d92b7746483efda1a759dd4de6690e585e61587f88163f", nonce: "588", blockHash: "0xca3437bab58bd6032a5432b2e290aad26261104b4da07fc0183f2d890023dc02", transactionIndex: "140", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e31313100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6423154", gasUsed: "79384", confirmations: "1104238"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541141491 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628345", timeStamp: "1541143171", hash: "0x35ee1fe00bf6cd292849d88e2e07a554adc8cdaa94465446ab3d8b2f18348fe4", nonce: "78", blockHash: "0x8ed5f29c53553ae1d81bb892c7feb6f65fc2778f54b25190fff1a22114a5d80b", transactionIndex: "87", from: "0x85f2921a8105f514f87aaf53625681516b4d5c4c", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "5240418", gasUsed: "79384", confirmations: "1104114"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541143171 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2191077399220403" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628402", timeStamp: "1541144123", hash: "0xe58d7cd34d341f9d13a81f43ce9f46225fe158bc4ee390fbcc78d05d0861716f", nonce: "79", blockHash: "0x39b2636ba3b05136765ecbb4bc18195609077b781c93fc67f099bb8274a75c87", transactionIndex: "45", from: "0x85f2921a8105f514f87aaf53625681516b4d5c4c", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "6153432", gasUsed: "79384", confirmations: "1104057"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "2000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541144123 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2191077399220403" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628490", timeStamp: "1541145450", hash: "0xbb5e4936d3539ab4b3fd0509a8240af5821bd1ec8a208ca5d94b2875953ba13b", nonce: "80", blockHash: "0xacb7f22bbfd6bc1acc175dcbfb7c5bbb9bf08ce0f2ea95d013d2306a67cee8e1", transactionIndex: "24", from: "0x85f2921a8105f514f87aaf53625681516b4d5c4c", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "975238", gasUsed: "79384", confirmations: "1103969"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541145450 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2191077399220403" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6628594", timeStamp: "1541147038", hash: "0xf4fdc5c566657d482330d2d771d88ce7e51a63bb2fa4b7e47768e49bae2eba42", nonce: "81", blockHash: "0x3609dd1fad6b6f69970baf2b859b5b366231cb6725bdd8a47329274172d25fad", transactionIndex: "112", from: "0x85f2921a8105f514f87aaf53625681516b4d5c4c", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "6902435", gasUsed: "79384", confirmations: "1103865"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541147038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2191077399220403" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: enableReporting( true )", async function( ) {
		const txOriginal = {blockNumber: "6634581", timeStamp: "1541231587", hash: "0xf110b8063f5b0e31eb178672f556a39e7b21a5ca74d3bdedaaf6cbb6607d46a0", nonce: "153", blockHash: "0x9abd27a9126dae59c6ce12cd86f270fb6ced367edca012e62613c040a63c23e7", transactionIndex: "12", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "300000", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xed1d73a60000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "333425", gasUsed: "28275", confirmations: "1097878"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "_enable", value: true}], name: "enableReporting", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "enableReporting(bool)" ]( true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541231587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6637505", timeStamp: "1541272272", hash: "0x2dd432cdb81d0ba2d28b4b8de43d6eab2ae8bcce5bc9e33a9661dee1948b00f6", nonce: "589", blockHash: "0xbc2857c62644ad0327ab21c5e32bf3b8193efd1e19524ee2e78abaeb637552df", transactionIndex: "13", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e313131000000000000000000000000000000000000000000000000000000000000000000000000000000000000000029a2241af62c0000", contractAddress: "", cumulativeGasUsed: "526404", gasUsed: "79384", confirmations: "1094954"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "3000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000", "3000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541272272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "3000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "3000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6637506", timeStamp: "1541272307", hash: "0x58bfa4c7d597592fa7e97883736ce0bae2aa1ad2579bb02c3fc6c0f1a54c49bd", nonce: "82", blockHash: "0x2f949010916fe2e94dc31b196dfd1b5cce7b42c5a4e0ded36560d852ac43a104", transactionIndex: "32", from: "0x85f2921a8105f514f87aaf53625681516b4d5c4c", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "1313683", gasUsed: "79174", confirmations: "1094953"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541272307 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2191077399220403" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641078", timeStamp: "1541322361", hash: "0x79ca79a1325929a83ed96f66ae4391cbe14460e4df5ce3f5871cfd3156df127a", nonce: "1", blockHash: "0xbb2791c1ed3b59f387a58052eab142c9a672bebdb40e98a49cddded531cafc5b", transactionIndex: "18", from: "0x61b6ded1a39fb7e99eb16671a50bd6bb7c430968", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e31313100000000000000000000000000000000000000000000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "524904", gasUsed: "64384", confirmations: "1091381"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "2000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000", "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541322361 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x61b6ded1a39fb7e99eb16671a50bd6bb7c430968"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x61b6ded1a39fb7e99eb16671a50bd6bb7c430968"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "98562320000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641211", timeStamp: "1541324198", hash: "0x44af714ba06f032876ce04d58c8bb24263b9eddcb79afa6ca4be1b8ee05e67ad", nonce: "0", blockHash: "0x2a3d8be326c9406fad191e1fa9ff7a5d6ebfaebb689fdd09bf481a5d85cff2d2", transactionIndex: "14", from: "0xa606c89a511aabb66ec87b3367a2a26128578bb8", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f730000000000000000000000000000000000000000000000000000000000c22af82ea6f1608113cba1d14c5d6b562bd645e0cb84dec42382f7ad0f6f7a4f00000000000000000000000003733d509f60a33f1b86856560256351f23e55310000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "1440869", gasUsed: "116294", confirmations: "1091248"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "87824613092707059377858951054645805733560174308482537698935460137641140255311"}, {type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "87824613092707059377858951054645805733560174308482537698935460137641140255311", addressList[11], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541324198 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0xa606c89a511aabb66ec87b3367a2a26128578bb8"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "87824613092707059377858951054645805733560174308482537698935460137641140255311"}, {name: "_to", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "48451292283855026824" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641273", timeStamp: "1541325142", hash: "0xaa28ceebd2eb808a1bc6e97a7a7781110c0ac87088cb1af005971b560ac7bc3e", nonce: "83", blockHash: "0x13d97103eef2adf4b4b4183626e9871536dc8495f88cafb826929f48fbbb4db4", transactionIndex: "91", from: "0x85f2921a8105f514f87aaf53625681516b4d5c4c", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "4189628", gasUsed: "79384", confirmations: "1091186"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541325142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x85f2921a8105f514f87aaf53625681516b4d5c4c"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "2191077399220403" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641286", timeStamp: "1541325384", hash: "0x87a5bc71d69e3a6ccd699c91a7e865c1066d4cf2c08807c7b3855ec19dd03ed6", nonce: "0", blockHash: "0x2572a745bd6a4912e0c686a8a9f73687558203c260478d953d53ae8dfe8bb89f", transactionIndex: "71", from: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f730000000000000000000000000000000000000000000000000000000000c22af82ea6f1608113cba1d14c5d6b562bd645e0cb84dec42382f7ad0f6f7a4f00000000000000000000000003733d509f60a33f1b86856560256351f23e55310000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "5519839", gasUsed: "56744", confirmations: "1091173"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "87824613092707059377858951054645805733560174308482537698935460137641140255311"}, {type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "87824613092707059377858951054645805733560174308482537698935460137641140255311", addressList[11], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541325384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "87824613092707059377858951054645805733560174308482537698935460137641140255311"}, {name: "_to", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "48383209174179050534" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641307", timeStamp: "1541325699", hash: "0xd23058e14ddad56ce0d1a53a5bba1897ee11e53b1c26374915de322aa2176d5e", nonce: "0", blockHash: "0xa647521cf49fd9c186df611518957092265d09f96344d712ca28c87d52515ffe", transactionIndex: "60", from: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f730000000000000000000000000000000000000000000000000000000000c22af82ea6f1608113cba1d14c5d6b562bd645e0cb84dec42382f7ad0f6f7a4f00000000000000000000000003733d509f60a33f1b86856560256351f23e55310000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "3626775", gasUsed: "91856", confirmations: "1091152"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "87824613092707059377858951054645805733560174308482537698935460137641140255311"}, {type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "87824613092707059377858951054645805733560174308482537698935460137641140255311", addressList[11], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541325699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensRelease", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensRelease", events: [{name: "_to", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "87824613092707059377858951054645805733560174308482537698935460137641140255311"}, {name: "_to", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "48714449489524082192" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setMaxLockLimit( \"4000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6641320", timeStamp: "1541325943", hash: "0xf4f9075f7811327cd7ace8581e247c3fea7a3484ed6f2120922b6c79d9a69f42", nonce: "156", blockHash: "0x411448fd03dda550859a478a0f164ba068d55e6bdc1d8c7a65b3c59c3f2ac604", transactionIndex: "1", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "300000", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xaf2b96180000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "49056", gasUsed: "28056", confirmations: "1091139"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_maxLockLimit", value: "4000000000000000000"}], name: "setMaxLockLimit", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMaxLockLimit(uint256)" ]( "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541325943 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: setMaxReleaseLimit( \"8000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6641325", timeStamp: "1541326015", hash: "0x690c4931e102d2e06263696fdda1f5251ff35925b52446494368626d5e61b9ca", nonce: "157", blockHash: "0x839eb76475941e111ba532e31ac8a75242f0cbca32b533277dd37bbafbd38ded", transactionIndex: "19", from: "0x50249160741773b1fed5aca6c7608d8ef6b50c64", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "300000", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xbf28ece40000000000000000000000000000000000000000000000006f05b59d3b200000", contractAddress: "", cumulativeGasUsed: "1165544", gasUsed: "28122", confirmations: "1091134"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_maxReleaseLimit", value: "8000000000000000000"}], name: "setMaxReleaseLimit", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMaxReleaseLimit(uint256)" ]( "8000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541326015 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5090565040067084704" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641366", timeStamp: "1541326493", hash: "0x4da5a0e0b99a8dd63b8f20c0b94e31799c4a77569624ba2c6ad3256a936e2bf2", nonce: "356", blockHash: "0xc23b8eadb8d8c2a635742b8bc4efd536ebc4a4e6ee44e64745b9242e080c2df1", transactionIndex: "141", from: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e31313100000000000000000000000000000000000000000000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "7784901", gasUsed: "64384", confirmations: "1091093"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "4000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000", "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541326493 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "62900107407370360" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641368", timeStamp: "1541326529", hash: "0x3f17d507017524f4d3bce0c879fad376a87d30ca194cb959edad4a660ddcf92a", nonce: "357", blockHash: "0x611d88a2ff851cce6ed4776840ba5fa0009bc48d5f1619b59060caa3be16b87c", transactionIndex: "40", from: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e31313100000000000000000000000000000000000000000000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "2091721", gasUsed: "25217", confirmations: "1091091"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "4000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000", "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541326529 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "62900107407370360" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641385", timeStamp: "1541326808", hash: "0x07bb63ebb831c1e4a253874869d6772a658bc9d8ca05b1edb1133dcdc67f8376", nonce: "1", blockHash: "0x7bec42183510e474dd3d1bbe2a49d4b8d95ffac02ea80f478e4c153f7f9a17ab", transactionIndex: "92", from: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f730000000000000000000000000000000000000000000000000000000000d5f02a1107861e1f0cc288c9a82928860f1ce6d8f7de437dc6450b696ff0c44100000000000000000000000000ad6821a8b859c9348d2bbe3e0eb3c7bbabbd750000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "7201880", gasUsed: "116230", confirmations: "1091074"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "96766970376240570355252500396408733278016761130134558669459630897232241280065"}, {type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "96766970376240570355252500396408733278016761130134558669459630897232241280065", addressList[9], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541326808 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "96766970376240570355252500396408733278016761130134558669459630897232241280065"}, {name: "_to", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "48714449489524082192" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641386", timeStamp: "1541326821", hash: "0x45070f3ae1e263ac0f8ce827fba8f9883fbd1edcd15ce03b8cf63941142dbe10", nonce: "1", blockHash: "0x12ac5e23d32ccc640ec2ea7d758a0f400ccde6104bff651c42d2ac6d7b70080e", transactionIndex: "119", from: "0xa606c89a511aabb66ec87b3367a2a26128578bb8", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f730000000000000000000000000000000000000000000000000000000000d5f02a1107861e1f0cc288c9a82928860f1ce6d8f7de437dc6450b696ff0c44100000000000000000000000000ad6821a8b859c9348d2bbe3e0eb3c7bbabbd750000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "5892841", gasUsed: "56680", confirmations: "1091073"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "96766970376240570355252500396408733278016761130134558669459630897232241280065"}, {type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "96766970376240570355252500396408733278016761130134558669459630897232241280065", addressList[9], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541326821 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0xa606c89a511aabb66ec87b3367a2a26128578bb8"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "96766970376240570355252500396408733278016761130134558669459630897232241280065"}, {name: "_to", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "48451292283855026824" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641392", timeStamp: "1541326915", hash: "0xb4bb923c36784e4cdcb12a72e9defa2deeb461431bf4be228526475e670da106", nonce: "2", blockHash: "0x01d8745680dda996ce4ed55e644c1a7ec46d1f0fdbc68e22e52135ca0c7dcdce", transactionIndex: "63", from: "0xa606c89a511aabb66ec87b3367a2a26128578bb8", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f730000000000000000000000000000000000000000000000000000000000e361d932d80781368c63864f567acce2f3cc4df4e4ac35e204ee7d2b978899f600000000000000000000000003733d509f60a33f1b86856560256351f23e55310000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "6321384", gasUsed: "116294", confirmations: "1091067"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "102847899843390102621385217433070990513099660694547230609211208963551320906230"}, {type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_amount", value: "2000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "102847899843390102621385217433070990513099660694547230609211208963551320906230", addressList[11], "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541326915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0xa606c89a511aabb66ec87b3367a2a26128578bb8"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "102847899843390102621385217433070990513099660694547230609211208963551320906230"}, {name: "_to", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "48451292283855026824" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641392", timeStamp: "1541326915", hash: "0x51abf10bef6b41b73eaaceec676493f20f37d25f0e1fd7fdf02e0fee03c7ee15", nonce: "2", blockHash: "0x01d8745680dda996ce4ed55e644c1a7ec46d1f0fdbc68e22e52135ca0c7dcdce", transactionIndex: "65", from: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f730000000000000000000000000000000000000000000000000000000000e361d932d80781368c63864f567acce2f3cc4df4e4ac35e204ee7d2b978899f600000000000000000000000003733d509f60a33f1b86856560256351f23e55310000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "6405986", gasUsed: "56744", confirmations: "1091067"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "102847899843390102621385217433070990513099660694547230609211208963551320906230"}, {type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_amount", value: "2000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "102847899843390102621385217433070990513099660694547230609211208963551320906230", addressList[11], "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541326915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[35,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "102847899843390102621385217433070990513099660694547230609211208963551320906230"}, {name: "_to", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[35,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "48714449489524082192" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641398", timeStamp: "1541326969", hash: "0x11d97728c328a4464b809d5dfeab9462d63c7ca2ccd2cb87019e5c86c29c1bfc", nonce: "1", blockHash: "0xe4758b1d1417772eeeadd7b9af63e3811b96dac62f5604a786465fd594e94313", transactionIndex: "74", from: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f730000000000000000000000000000000000000000000000000000000000d5f02a1107861e1f0cc288c9a82928860f1ce6d8f7de437dc6450b696ff0c44100000000000000000000000000ad6821a8b859c9348d2bbe3e0eb3c7bbabbd750000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "4475186", gasUsed: "91792", confirmations: "1091061"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "96766970376240570355252500396408733278016761130134558669459630897232241280065"}, {type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "96766970376240570355252500396408733278016761130134558669459630897232241280065", addressList[9], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541326969 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensRelease", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensRelease", events: [{name: "_to", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[36,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "96766970376240570355252500396408733278016761130134558669459630897232241280065"}, {name: "_to", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[36,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "48383209174179050534" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641400", timeStamp: "1541326990", hash: "0x5d9793063f5c8bfc9c7372169816babf66d477b27fc14cd2b6f0cacf2439e125", nonce: "2", blockHash: "0xab340836d860a214d930aa5f9d82fbdd4f481be09906631a8facef7be709e09d", transactionIndex: "61", from: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f730000000000000000000000000000000000000000000000000000000000e361d932d80781368c63864f567acce2f3cc4df4e4ac35e204ee7d2b978899f600000000000000000000000003733d509f60a33f1b86856560256351f23e55310000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "3808467", gasUsed: "91856", confirmations: "1091059"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "102847899843390102621385217433070990513099660694547230609211208963551320906230"}, {type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_amount", value: "2000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "102847899843390102621385217433070990513099660694547230609211208963551320906230", addressList[11], "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541326990 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensRelease", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensRelease", events: [{name: "_to", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[37,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "102847899843390102621385217433070990513099660694547230609211208963551320906230"}, {name: "_to", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[37,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "48383209174179050534" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641416", timeStamp: "1541327173", hash: "0x4c2bf736ca2e5905076f1fe34b34113a2cb87bac82cff92c0bf3044579abffd0", nonce: "297", blockHash: "0x246c414fb91cbdea5d7cee442424c2a694833bf4a5593781524801230b5a195f", transactionIndex: "128", from: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "5645539", gasUsed: "79384", confirmations: "1091043"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "4000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541327173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "342089197913606092" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641426", timeStamp: "1541327412", hash: "0xaa1b837dd7aa83708ac24860d235dfb689b8781b79a342efa32000d6e7e2277f", nonce: "591", blockHash: "0x5bcbf72ccf489d0aea22dd735f38f9bbb9b0be37ab985df30c7b2cd6ab1c10d3", transactionIndex: "60", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e31313100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "2421400", gasUsed: "94384", confirmations: "1091033"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541327412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641430", timeStamp: "1541327498", hash: "0xe87bbf301a92aa1659b8a92d2276d93c0579a7e19a4da52f87fc1faa186e682e", nonce: "592", blockHash: "0x3352bc5c45e539b43865186b7d4826f005b68b32cd5c64775ec188e1ba55fb0d", transactionIndex: "71", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e31313100000000000000000000000000000000000000000000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "5128975", gasUsed: "79384", confirmations: "1091029"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "2000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000", "2000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541327498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x03733d509f60a33f1b86856560256351f23e5531"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3131310000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "2000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641476", timeStamp: "1541328224", hash: "0x296a51c9f742899a9f7f2cfa7b11b2f2b42ec1d332e419ca6b4bac635a0a0277", nonce: "298", blockHash: "0x755c367719ab7d4478a027631e7139b22c91adf9679a45b569bdb36a84c385b1", transactionIndex: "43", from: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "1959268", gasUsed: "64384", confirmations: "1090983"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "4000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541328224 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "342089197913606092" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641597", timeStamp: "1541330151", hash: "0x4a84108f114d28cd7c9b8100c39715c702a05bdc5b9b4047e54e6a1e2474c306", nonce: "299", blockHash: "0xc6f412d6ad04550004236805fee94ac27d2f5140507846456d26c8fdcd2b0415", transactionIndex: "49", from: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "2415042", gasUsed: "94384", confirmations: "1090862"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541330151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "342089197913606092" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641625", timeStamp: "1541330485", hash: "0x8221562ce8a019fedf5621541850539732e99d6bb0f921b1e907d25f0c93b734", nonce: "300", blockHash: "0xe6f1957209a598dd41be409dffc6288feece63352752708ae778c28e888c33d6", transactionIndex: "23", from: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e35353500000000000000000000000000000000000000000000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "1216208", gasUsed: "64384", confirmations: "1090834"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "4000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000", "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541330485 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3535350000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "342089197913606092" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641666", timeStamp: "1541330976", hash: "0x4cf607d93a51d8c29c8c0b2d91250acf5a65d89038fe56f41ee2eb48786ccdf8", nonce: "3", blockHash: "0x25ef15a3db0887fcb6a9ff28a99f64c3cb0793ffa8df73fefeab8afd1c2a0570", transactionIndex: "46", from: "0xa606c89a511aabb66ec87b3367a2a26128578bb8", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f73000000000000000000000000000000000000000000000000000000000097fd58d45be139f33efe8e5039334598dbb6b4eef7f1f96450515beff0bef19900000000000000000000000000ad6821a8b859c9348d2bbe3e0eb3c7bbabbd750000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "2533905", gasUsed: "116230", confirmations: "1090793"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "68746865522325438180842336664124599245679860628461674617475807819121983156633"}, {type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "68746865522325438180842336664124599245679860628461674617475807819121983156633", addressList[9], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541330976 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0xa606c89a511aabb66ec87b3367a2a26128578bb8"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "68746865522325438180842336664124599245679860628461674617475807819121983156633"}, {name: "_to", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "48451292283855026824" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641666", timeStamp: "1541330976", hash: "0x2d89a0d96f8896da261df2f0656c204e4465bd82759485144f632c7c7d2f9978", nonce: "3", blockHash: "0x25ef15a3db0887fcb6a9ff28a99f64c3cb0793ffa8df73fefeab8afd1c2a0570", transactionIndex: "48", from: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f73000000000000000000000000000000000000000000000000000000000097fd58d45be139f33efe8e5039334598dbb6b4eef7f1f96450515beff0bef19900000000000000000000000000ad6821a8b859c9348d2bbe3e0eb3c7bbabbd750000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "2664119", gasUsed: "56680", confirmations: "1090793"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "68746865522325438180842336664124599245679860628461674617475807819121983156633"}, {type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "68746865522325438180842336664124599245679860628461674617475807819121983156633", addressList[9], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541330976 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "68746865522325438180842336664124599245679860628461674617475807819121983156633"}, {name: "_to", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "48714449489524082192" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641672", timeStamp: "1541331022", hash: "0x8fcde76e1ae4a2a1f37c188ca59450bad01487c716b5aa6b6a75ba97eafaf15d", nonce: "3", blockHash: "0x33d7e18438270a17457f1ae2246b16f2d0a53928a34f7d7050f73c56b17bf196", transactionIndex: "43", from: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5772333333", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f73000000000000000000000000000000000000000000000000000000000097fd58d45be139f33efe8e5039334598dbb6b4eef7f1f96450515beff0bef19900000000000000000000000000ad6821a8b859c9348d2bbe3e0eb3c7bbabbd750000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "1797488", gasUsed: "91792", confirmations: "1090787"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "68746865522325438180842336664124599245679860628461674617475807819121983156633"}, {type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "68746865522325438180842336664124599245679860628461674617475807819121983156633", addressList[9], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541331022 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensRelease", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TokensRelease", events: [{name: "_to", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "68746865522325438180842336664124599245679860628461674617475807819121983156633"}, {name: "_to", type: "address", value: "0x00ad6821a8b859c9348d2bbe3e0eb3c7bbabbd75"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "48383209174179050534" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: xTransfer( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641689", timeStamp: "1541331144", hash: "0x26cc6c6486c6978c150d89cf8573431854226f714dc354cdfc3401b1da3bb223", nonce: "359", blockHash: "0x6e3115d03f22ae5285eec4d14989937b12380d4ee684f220beb2944b39eeef4e", transactionIndex: "27", from: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "150000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x49282538656f7300000000000000000000000000000000000000000000000000000000006c6f63616c636f696e34343400000000000000000000000000000000000000000000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "1308687", gasUsed: "79384", confirmations: "1090770"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_toBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "_to", value: "0x6c6f63616c636f696e3434340000000000000000000000000000000000000000"}, {type: "uint256", name: "_amount", value: "4000000000000000000"}], name: "xTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "xTransfer(bytes32,bytes32,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "0x6c6f63616c636f696e3434340000000000000000000000000000000000000000", "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541331144 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TokensLock", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokensLock", events: [{name: "_from", type: "address", value: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: false, name: "_toBlockchain", type: "bytes32"}, {indexed: true, name: "_to", type: "bytes32"}, {indexed: false, name: "_amount", type: "uint256"}], name: "XTransfer", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "XTransfer", events: [{name: "_from", type: "address", value: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46"}, {name: "_toBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_to", type: "bytes32", value: "0x6c6f63616c636f696e3434340000000000000000000000000000000000000000"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "62900107407370360" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641705", timeStamp: "1541331371", hash: "0x4d61745d46a147fd05c8bd2d5e2920738258a7656b0bac1c3dae31516f4508e2", nonce: "4", blockHash: "0x361166e049382fde9ec8e20a097a0ed9a6837947489b9280921091af2186fa22", transactionIndex: "177", from: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f7300000000000000000000000000000000000000000000000000000000006e7a17d501025810033858bdcace30ba0edfbed610346469ecc1c51abbe70dbb000000000000000000000000cfdf7971527b019cb68816ce5e5f8db21c126b460000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "7248946", gasUsed: "116294", confirmations: "1090754"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "49970133168803158450335904248965505653957721846670787429776555446244506799547"}, {type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_amount", value: "4000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "49970133168803158450335904248965505653957721846670787429776555446244506799547", addressList[13], "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541331371 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0x452895ae20b6e0c84628a7c34e22dda58e2a5829"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "49970133168803158450335904248965505653957721846670787429776555446244506799547"}, {name: "_to", type: "address", value: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "48714449489524082192" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: reportTx( \"0x656f73000000000000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6641705", timeStamp: "1541331371", hash: "0x420536db8947a20d8d2c704d3c15d41e2a843a555cf6554f5fcce0de1004327d", nonce: "4", blockHash: "0x361166e049382fde9ec8e20a097a0ed9a6837947489b9280921091af2186fa22", transactionIndex: "178", from: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f", to: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e", value: "0", gas: "336004", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1bd3d4a5656f7300000000000000000000000000000000000000000000000000000000006e7a17d501025810033858bdcace30ba0edfbed610346469ecc1c51abbe70dbb000000000000000000000000cfdf7971527b019cb68816ce5e5f8db21c126b460000000000000000000000000000000000000000000000003782dace9d900000", contractAddress: "", cumulativeGasUsed: "7305690", gasUsed: "56744", confirmations: "1090754"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_fromBlockchain", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "_txId", value: "49970133168803158450335904248965505653957721846670787429776555446244506799547"}, {type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_amount", value: "4000000000000000000"}], name: "reportTx", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "reportTx(bytes32,uint256,address,uint256)" ]( "0x656f730000000000000000000000000000000000000000000000000000000000", "49970133168803158450335904248965505653957721846670787429776555446244506799547", addressList[13], "4000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541331371 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_reporter", type: "address"}, {indexed: false, name: "_fromBlockchain", type: "bytes32"}, {indexed: false, name: "_txId", type: "uint256"}, {indexed: false, name: "_to", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "TxReport", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TxReport", events: [{name: "_reporter", type: "address", value: "0xbb2fb5fa152eccf2b386dd67e68ead76b963a94f"}, {name: "_fromBlockchain", type: "bytes32", value: "0x656f730000000000000000000000000000000000000000000000000000000000"}, {name: "_txId", type: "uint256", value: "49970133168803158450335904248965505653957721846670787429776555446244506799547"}, {name: "_to", type: "address", value: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46"}, {name: "_amount", type: "uint256", value: "4000000000000000000"}], address: "0x98a741591049b6a92d7266a0668a26aaf61a1b5e"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "48383209174179050534" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
