const Broker = artifacts.require( "./Broker.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Broker" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xba3Ed686cC32FfA8664628b1E96D8022e40543dE", "0x1f8CDD31345fAa00bBdF946fa257b7Feb706b535", "0x1aE3f54679d8b1c5Bc7bd30154faFfCC073E38a5", "0x89d24A6b4CcB1B6fAA2625fE562bDD9a23260359", "0x5B80F18d9c3F91aCbC20cEE093943845dF4d3513", "0xd26114cd6EE289AccF82350c8d8487fedB8A0C07", "0x0A7BB040669d7FeFa01fd7A856acEd117818608b", "0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2", "0x3EDa2E44d5C2c000267B7cff27018881FA283ae7", "0x7c819b61b3A35AB718F66508d31E2CF3c25eB624", "0x0F936dcE97A9A5c50bECC3F58A4842B4C607e722", "0x5bE2f49D897A8c4603960C457ffb466527A28Eae", "0x9D7863E2Ca6Cd42d9549bD3Bde900FB6687Be985"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "coordinator", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "announcedCancellations", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cancelAnnounceDelay", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "offers", outputs: [{name: "maker", type: "address"}, {name: "offerAsset", type: "address"}, {name: "wantAsset", type: "address"}, {name: "nonce", type: "uint64"}, {name: "offerAmount", type: "uint256"}, {name: "wantAmount", type: "uint256"}, {name: "availableAmount", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "operator", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "approvedSpenders", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "announcedWithdrawals", outputs: [{name: "amount", type: "uint256"}, {name: "canWithdrawAt", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "whitelistedSpenders", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "usedHashes", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "state", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}, {name: "", type: "address"}], name: "balances", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "pendingOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "withdrawAnnounceDelay", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "filler", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}, {indexed: false, name: "amountFilled", type: "uint256"}, {indexed: false, name: "amountTaken", type: "uint256"}, {indexed: true, name: "maker", type: "address"}], name: "Fill", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Cancel", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "canWithdrawAt", type: "uint256"}], name: "WithdrawAnnounce", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}, {indexed: false, name: "canCancelAt", type: "uint256"}], name: "CancelAnnounce", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "spender", type: "address"}], name: "SpenderApprove", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "spender", type: "address"}], name: "SpenderRescind", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Make(address,bytes32)", "Fill(address,bytes32,uint256,uint256,address)", "Cancel(address,bytes32)", "BalanceIncrease(address,address,uint256,uint8)", "BalanceDecrease(address,address,uint256,uint8)", "WithdrawAnnounce(address,address,uint256,uint256)", "CancelAnnounce(address,bytes32,uint256)", "SpenderApprove(address,address)", "SpenderRescind(address,address)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x1fa192562e5fbdce807069b18275dc0d672cacd78576602b47d21730975635a1", "0xc587d1c5cbeb2dc01ea21c77c1c9232f39962a50cf2d6ce8d02dd09356e05b85", "0xdb2b33dd6349739e1f3cd6dc90cf093af6a3dfb1838aced380528b0aefe6093c", "0x4a52a947455663fbd6ddcc61a4d3a18a7e387c418de430ea8a191956cc53ec79", "0xa3bbf8b09a42177fa9310281fb7f2fc8803d7c6df09a82093ea047cb6a222aa3", "0xf8721275b3a50a37f692c7ba70c878e6cb3e44c23967756a3f712fe1ccc03779", "0x5a4fb258356f60bc7302795f48ccdc1ca92d9bd3322ddd4c1c93cc1a27f72672", "0x052c513b128416028f181f8d2c76eee59572b251fc379accba39533b40b3e86d", "0x4524ec10cbd92d9466126e9af13eba34a4176c2cc2a74d0dee145087b67f5e04", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6665614 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6666050 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "Broker", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "coordinator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "coordinator()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "announcedCancellations", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "announcedCancellations(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cancelAnnounceDelay", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cancelAnnounceDelay()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "offers", outputs: [{name: "maker", type: "address"}, {name: "offerAsset", type: "address"}, {name: "wantAsset", type: "address"}, {name: "nonce", type: "uint64"}, {name: "offerAmount", type: "uint256"}, {name: "wantAmount", type: "uint256"}, {name: "availableAmount", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "offers(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "operator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "operator()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "approvedSpenders", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "approvedSpenders(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "announcedWithdrawals", outputs: [{name: "amount", type: "uint256"}, {name: "canWithdrawAt", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "announcedWithdrawals(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whitelistedSpenders", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelistedSpenders(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "usedHashes", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "usedHashes(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "state", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "state()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balances", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balances(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pendingOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pendingOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "withdrawAnnounceDelay", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "withdrawAnnounceDelay()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Broker", function( accounts ) {

	it( "TEST: Broker(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6665614", timeStamp: "1541670909", hash: "0x247dfd5ba402a5d4f75dbdd5cb771dfcb74cac5ad85ef86c23a158e1c739c8d6", nonce: "30", blockHash: "0x1df3074d52f7617f011d93a1769560590ad91766da3cb90647133d1ade1aa320", transactionIndex: "18", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: 0, value: "0", gas: "6000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xcfcbb1ef", contractAddress: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", cumulativeGasUsed: "4589059", gasUsed: "4092602", confirmations: "1054426"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "Broker", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Broker.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541670909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Broker.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: depositERC20( addressList[4], addressList[5], \"300000... )", async function( ) {
		const txOriginal = {blockNumber: "6665686", timeStamp: "1541672064", hash: "0xef09e476f3fa0045b13b9846ebf7610c00021c6123bc17beab6f0ed0c966b763", nonce: "31", blockHash: "0x440eea0e4220061eca8b709ff4767363df169aa8ea06eef816119453a30a0aa2", transactionIndex: "109", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x1cad5a400000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000001a055690d9db80000", contractAddress: "", cumulativeGasUsed: "4937330", gasUsed: "70842", confirmations: "1054354"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[4]}, {type: "address", name: "_token", value: addressList[5]}, {type: "uint256", name: "_amount", value: "30000000000000000000"}], name: "depositERC20", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositERC20(address,address,uint256)" ]( addressList[4], addressList[5], "30000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541672064 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[1,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "30000000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[1,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: depositERC20( addressList[6], addressList[7], \"300000... )", async function( ) {
		const txOriginal = {blockNumber: "6665687", timeStamp: "1541672068", hash: "0xa3780a7756a8f9ad660611a705593a221b7d533d1570fa11d6cbf07642fd666d", nonce: "32", blockHash: "0x10e6b52402e87544aaf376b3ae0d1766a3dfbf20267eb4b0358dfbb85801395a", transactionIndex: "86", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x1cad5a400000000000000000000000005b80f18d9c3f91acbc20cee093943845df4d3513000000000000000000000000d26114cd6ee289accf82350c8d8487fedb8a0c07000000000000000000000000000000000000000000000001a055690d9db80000", contractAddress: "", cumulativeGasUsed: "2139851", gasUsed: "70253", confirmations: "1054353"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[6]}, {type: "address", name: "_token", value: addressList[7]}, {type: "uint256", name: "_amount", value: "30000000000000000000"}], name: "depositERC20", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositERC20(address,address,uint256)" ]( addressList[6], addressList[7], "30000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541672068 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0xd26114cd6ee289accf82350c8d8487fedb8a0c07"}, {name: "amount", type: "uint256", value: "30000000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: depositERC20( addressList[8], addressList[9], \"300000... )", async function( ) {
		const txOriginal = {blockNumber: "6665689", timeStamp: "1541672117", hash: "0x74bb508d658e56d040fc48ab34acaa181bd479012a9b25f0532fca7c4c03d7f2", nonce: "33", blockHash: "0xd9c3d95a7165efb989c357f9dce8f2b1747ce98dd842e8a437f708aa2cc4eb41", transactionIndex: "61", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x1cad5a400000000000000000000000000a7bb040669d7fefa01fd7a856aced117818608b0000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a20000000000000000000000000000000000000000000000000429d069189e0000", contractAddress: "", cumulativeGasUsed: "2378631", gasUsed: "70778", confirmations: "1054351"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[8]}, {type: "address", name: "_token", value: addressList[9]}, {type: "uint256", name: "_amount", value: "300000000000000000"}], name: "depositERC20", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositERC20(address,address,uint256)" ]( addressList[8], addressList[9], "300000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541672117 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0a7bb040669d7fefa01fd7a856aced117818608b"}, {name: "token", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "amount", type: "uint256", value: "300000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setOperator( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6665705", timeStamp: "1541672301", hash: "0xc190f150d266a6d1de685ea6efbb65568f11dbc1a14ab885dbbe5539023a6a9b", nonce: "34", blockHash: "0x6c8270c0723ce8c085969b580f6b246ad4fc9c48928f6d44bdd922d983da6dc7", transactionIndex: "35", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "44415", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xb3ab15fb0000000000000000000000003eda2e44d5c2c000267b7cff27018881fa283ae7", contractAddress: "", cumulativeGasUsed: "1119993", gasUsed: "29610", confirmations: "1054335"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_operator", value: addressList[10]}], name: "setOperator", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOperator(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541672301 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transferOwnership( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6665707", timeStamp: "1541672338", hash: "0x00a7a04f982acfd752db4f88bece41f80b82de2707146aa337f78beb7b53fdb2", nonce: "35", blockHash: "0xbde22855205bacfb0b788818bf0844e961e451c898b19267b0987385d8d55bb1", transactionIndex: "41", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "66571", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xf2fde38b0000000000000000000000003eda2e44d5c2c000267b7cff27018881fa283ae7", contractAddress: "", cumulativeGasUsed: "1526285", gasUsed: "44381", confirmations: "1054333"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "newOwner", value: addressList[10]}], name: "transferOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferOwnership(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541672338 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( addressList[8], addressList[9], \"300000... )", async function( ) {
		const txOriginal = {blockNumber: "6665716", timeStamp: "1541672461", hash: "0xee9da49615f0f6d5897168d8fd700d0a0a1de306245040e9738b687a82a3af22", nonce: "36", blockHash: "0xf128eea12c25a7f699dbe18ab37d37502f37f537e8739f9b8b076c2acda71b23", transactionIndex: "81", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "9300000000", isError: "0", txreceipt_status: "1", input: "0x58efd2930000000000000000000000000a7bb040669d7fefa01fd7a856aced117818608b0000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a20000000000000000000000000000000000000000000000000429d069189e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001bfbbacd35405a397f3aa954784d091ebf2c5cd72790e8274e59bbdc290b9c629160c4c68d06baf5a65564adc7012d041ce928df5c42e67519f5f7379c31946312", contractAddress: "", cumulativeGasUsed: "4255482", gasUsed: "51809", confirmations: "1054324"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawer", value: addressList[8]}, {type: "address", name: "_token", value: addressList[9]}, {type: "uint256", name: "_amount", value: "300000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "1"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xfbbacd35405a397f3aa954784d091ebf2c5cd72790e8274e59bbdc290b9c6291"}, {type: "bytes32", name: "_s", value: "0x60c4c68d06baf5a65564adc7012d041ce928df5c42e67519f5f7379c31946312"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(address,address,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[8], addressList[9], "300000000000000000", addressList[0], "0", "1", "27", "0xfbbacd35405a397f3aa954784d091ebf2c5cd72790e8274e59bbdc290b9c6291", "0x60c4c68d06baf5a65564adc7012d041ce928df5c42e67519f5f7379c31946312", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541672461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0a7bb040669d7fefa01fd7a856aced117818608b"}, {name: "token", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "amount", type: "uint256", value: "300000000000000000"}, {name: "reason", type: "uint8", value: "9"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( addressList[4], addressList[5], \"300000... )", async function( ) {
		const txOriginal = {blockNumber: "6665756", timeStamp: "1541673033", hash: "0x41cc70f9a00476bf3736843f4114de51fcee2de31f850a6bbf8d90f2b694e5c7", nonce: "37", blockHash: "0x9e59423a802f38b2f50cf77b5a3c11bb2f68e224ec92bff9b778db30a9e1839f", transactionIndex: "26", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x58efd2930000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000001a055690d9db80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001bfb8f18c57f82e08552e65f18aaca15fb221d0818760bbfdeb4ae5647dd400ae008270e51b824ce584a8d10fdb642f1fa00ae52e880d9fe5641edca732005ec09", contractAddress: "", cumulativeGasUsed: "3017185", gasUsed: "51809", confirmations: "1054284"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawer", value: addressList[4]}, {type: "address", name: "_token", value: addressList[5]}, {type: "uint256", name: "_amount", value: "30000000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "2"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xfb8f18c57f82e08552e65f18aaca15fb221d0818760bbfdeb4ae5647dd400ae0"}, {type: "bytes32", name: "_s", value: "0x08270e51b824ce584a8d10fdb642f1fa00ae52e880d9fe5641edca732005ec09"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(address,address,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[5], "30000000000000000000", addressList[0], "0", "2", "27", "0xfb8f18c57f82e08552e65f18aaca15fb221d0818760bbfdeb4ae5647dd400ae0", "0x08270e51b824ce584a8d10fdb642f1fa00ae52e880d9fe5641edca732005ec09", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541673033 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "30000000000000000000"}, {name: "reason", type: "uint8", value: "9"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: claimOwnership(  )", async function( ) {
		const txOriginal = {blockNumber: "6665764", timeStamp: "1541673217", hash: "0x341c500096ef6eda008b2e862cfeae2688ffed67b974464ab008735e084d7a7d", nonce: "1", blockHash: "0x605d38d9ab7e6a5b7bcafcc53d4b8487ff7d4c871d037da617485f71f776a040", transactionIndex: "35", from: "0x3eda2e44d5c2c000267b7cff27018881fa283ae7", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "51811", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x4e71e0c8", contractAddress: "", cumulativeGasUsed: "1130413", gasUsed: "19541", confirmations: "1054276"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "claimOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "claimOwnership()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541673217 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[8,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535"}, {name: "newOwner", type: "address", value: "0x3eda2e44d5c2c000267b7cff27018881fa283ae7"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[8,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "186130320500000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( addressList[6], addressList[7], \"300000... )", async function( ) {
		const txOriginal = {blockNumber: "6665774", timeStamp: "1541673313", hash: "0x23d8ceb59d168d9a14c4b6c9f2ab36ce31e1e18aa6b6d3dfb24bbe3a23662fdd", nonce: "38", blockHash: "0xf872ea8826a33366ac8933152601f02f87388d035fe3e6948a7c7154f501617f", transactionIndex: "24", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x58efd2930000000000000000000000005b80f18d9c3f91acbc20cee093943845df4d3513000000000000000000000000d26114cd6ee289accf82350c8d8487fedb8a0c07000000000000000000000000000000000000000000000001a055690d9db80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001b5ed2c1d266cbb35c2133ae6e299dda793fb468b9d39c4cfab0d2e23850366e245ebfe0d8007b5853edc312272288e76037f1083d2f77164433d829053c0352d0", contractAddress: "", cumulativeGasUsed: "1797146", gasUsed: "51576", confirmations: "1054266"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawer", value: addressList[6]}, {type: "address", name: "_token", value: addressList[7]}, {type: "uint256", name: "_amount", value: "30000000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "1"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x5ed2c1d266cbb35c2133ae6e299dda793fb468b9d39c4cfab0d2e23850366e24"}, {type: "bytes32", name: "_s", value: "0x5ebfe0d8007b5853edc312272288e76037f1083d2f77164433d829053c0352d0"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(address,address,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[6], addressList[7], "30000000000000000000", addressList[0], "0", "1", "27", "0x5ed2c1d266cbb35c2133ae6e299dda793fb468b9d39c4cfab0d2e23850366e24", "0x5ebfe0d8007b5853edc312272288e76037f1083d2f77164433d829053c0352d0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541673313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0xd26114cd6ee289accf82350c8d8487fedb8a0c07"}, {name: "amount", type: "uint256", value: "30000000000000000000"}, {name: "reason", type: "uint8", value: "9"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: depositEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6665787", timeStamp: "1541673496", hash: "0xa8b546e54b645b8fe79b2305bf0caf3bd5518103ad545ef82866ea9b458e40a9", nonce: "4", blockHash: "0x8bea559e454bc5c7d3b40c6480e40dba8b022fef117207429e50471b6e90b07b", transactionIndex: "48", from: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "23000000000000000000", gas: "45237", gasPrice: "6300000000", isError: "0", txreceipt_status: "1", input: "0x98ea5fca", contractAddress: "", cumulativeGasUsed: "3935139", gasUsed: "45237", confirmations: "1054253"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "23000000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositEther", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541673496 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "23000000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "6000406195940860" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: depositEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6665787", timeStamp: "1541673496", hash: "0xf9d02f0b29ab8c15e5d57f57436340abe5e50af483b359741f133011d1db0174", nonce: "6", blockHash: "0x8bea559e454bc5c7d3b40c6480e40dba8b022fef117207429e50471b6e90b07b", transactionIndex: "51", from: "0x5b80f18d9c3f91acbc20cee093943845df4d3513", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "22000000000000000000", gas: "45237", gasPrice: "6300000000", isError: "0", txreceipt_status: "1", input: "0x98ea5fca", contractAddress: "", cumulativeGasUsed: "4038373", gasUsed: "45237", confirmations: "1054253"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "22000000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositEther", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541673496 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "22000000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8329162424954023" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: depositERC20( addressList[4], addressList[5], \"472022... )", async function( ) {
		const txOriginal = {blockNumber: "6665796", timeStamp: "1541673599", hash: "0x1a7fc315c046378b4327cf6e869cc2ab23d92439b222ad51b6bcfcbc4e593f1e", nonce: "39", blockHash: "0x284aae0b211c3302b19dcf95457f53345eae67aea3961ef9764c09f23dbad4e8", transactionIndex: "79", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "9031779824", isError: "0", txreceipt_status: "1", input: "0x1cad5a400000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000ffe2362933de560000", contractAddress: "", cumulativeGasUsed: "3734516", gasUsed: "55842", confirmations: "1054244"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[4]}, {type: "address", name: "_token", value: addressList[5]}, {type: "uint256", name: "_amount", value: "4720220000000000000000"}], name: "depositERC20", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositERC20(address,address,uint256)" ]( addressList[4], addressList[5], "4720220000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541673599 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "4720220000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677467513641763457580" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: depositERC20( addressList[8], addressList[9], \"575200... )", async function( ) {
		const txOriginal = {blockNumber: "6665800", timeStamp: "1541673646", hash: "0xb9e2871fa2d7efd6b06938d7eb5b99e1703933d976a857e50ff2adb48e21bfc1", nonce: "40", blockHash: "0xbcd5acb6b67e2371104cc83512193929011622601838baf2dbb12db0999e9eac", transactionIndex: "55", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "9031779824", isError: "0", txreceipt_status: "1", input: "0x1cad5a400000000000000000000000000a7bb040669d7fefa01fd7a856aced117818608b0000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a20000000000000000000000000000000000000000000000004fd335864c0c0000", contractAddress: "", cumulativeGasUsed: "2709629", gasUsed: "55778", confirmations: "1054240"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[8]}, {type: "address", name: "_token", value: addressList[9]}, {type: "uint256", name: "_amount", value: "5752000000000000000"}], name: "depositERC20", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositERC20(address,address,uint256)" ]( addressList[8], addressList[9], "5752000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541673646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0a7bb040669d7fefa01fd7a856aced117818608b"}, {name: "token", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "amount", type: "uint256", value: "5752000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( addressList[6], addressList[0], \"220000... )", async function( ) {
		const txOriginal = {blockNumber: "6665815", timeStamp: "1541673830", hash: "0x4330d652274917e6ebbdfbbda2c3cb17c02bcaedd856da2f595cf5a0fde89361", nonce: "41", blockHash: "0xcafc7be71e25e2b54bc4d52f1ce843907196e38e88fa115721cca2acc5d11fd5", transactionIndex: "49", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "8700000000", isError: "0", txreceipt_status: "1", input: "0x58efd2930000000000000000000000005b80f18d9c3f91acbc20cee093943845df4d35130000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001314fb37062980000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c83bd4ddaa8b3d49458c8e9cbb14cb0b5865cb848a192441236e1aa8c202815ef46c0a9e9d58d6a354e07f1883f8bc1b1c11421fcc12f9778e418548a7e58a17d", contractAddress: "", cumulativeGasUsed: "2893793", gasUsed: "56968", confirmations: "1054225"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawer", value: addressList[6]}, {type: "address", name: "_token", value: addressList[0]}, {type: "uint256", name: "_amount", value: "22000000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "1"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x83bd4ddaa8b3d49458c8e9cbb14cb0b5865cb848a192441236e1aa8c202815ef"}, {type: "bytes32", name: "_s", value: "0x46c0a9e9d58d6a354e07f1883f8bc1b1c11421fcc12f9778e418548a7e58a17d"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(address,address,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[6], addressList[0], "22000000000000000000", addressList[0], "0", "1", "28", "0x83bd4ddaa8b3d49458c8e9cbb14cb0b5865cb848a192441236e1aa8c202815ef", "0x46c0a9e9d58d6a354e07f1883f8bc1b1c11421fcc12f9778e418548a7e58a17d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541673830 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "22000000000000000000"}, {name: "reason", type: "uint8", value: "9"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8999511799133741258" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( addressList[4], addressList[0], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "6665818", timeStamp: "1541673858", hash: "0x5754767e2062d09856ce4b9f30226c3291fd761489da8940577532b3f25b070b", nonce: "42", blockHash: "0x1a550021ca80874aab76c9a430ae1f36921eb289dd2171b8efb9ddfb5f930e01", transactionIndex: "37", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "8700000000", isError: "0", txreceipt_status: "1", input: "0x58efd2930000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001be6558740389e16f3cba3d94a543f54286387bb88bb60fcfe206bd0cb94665bff1221db4b9bf794f731b7636c3bf2132860bee66f16ad943e7e1d98b47136fce2", contractAddress: "", cumulativeGasUsed: "2243835", gasUsed: "71904", confirmations: "1054222"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawer", value: addressList[4]}, {type: "address", name: "_token", value: addressList[0]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "1"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xe6558740389e16f3cba3d94a543f54286387bb88bb60fcfe206bd0cb94665bff"}, {type: "bytes32", name: "_s", value: "0x1221db4b9bf794f731b7636c3bf2132860bee66f16ad943e7e1d98b47136fce2"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(address,address,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[0], "1000000000000000000", addressList[0], "0", "1", "27", "0xe6558740389e16f3cba3d94a543f54286387bb88bb60fcfe206bd0cb94665bff", "0x1221db4b9bf794f731b7636c3bf2132860bee66f16ad943e7e1d98b47136fce2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541673858 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "1000000000000000000"}, {name: "reason", type: "uint8", value: "9"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8998431548333741258" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: depositEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6665836", timeStamp: "1541674132", hash: "0x8a6a8dad160158628781e74c5598024fd09d0aae94425de0a0aee8524312ade9", nonce: "7", blockHash: "0xb68397d6b701fe11aa1ddc796806a909444d704fbb8ca0adf3ffe1009e5a9bf4", transactionIndex: "103", from: "0x5b80f18d9c3f91acbc20cee093943845df4d3513", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "22200000000000000000", gas: "45237", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x98ea5fca", contractAddress: "", cumulativeGasUsed: "7388384", gasUsed: "45237", confirmations: "1054204"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "22200000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositEther", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541674132 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "22200000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "8329162424954023" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: depositEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6665840", timeStamp: "1541674183", hash: "0x78ec328ff5389cb3bd329bdd039df889353303a04773a97601f559332b363103", nonce: "6", blockHash: "0x133a1c30c68c3bf7d25ef45e0be32db9a564658bd3fa4e089adfc5c893db0e8f", transactionIndex: "28", from: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "1000000000000000000", gas: "30237", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x98ea5fca", contractAddress: "", cumulativeGasUsed: "4690765", gasUsed: "30237", confirmations: "1054200"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositEther", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541674183 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "1000000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "6000406195940860" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: depositERC20( addressList[6], addressList[7], \"119100... )", async function( ) {
		const txOriginal = {blockNumber: "6665857", timeStamp: "1541674418", hash: "0x1ac1e1754c332df26c9d90e0991feeb12befd73605a0fc1e123f0519e62f345f", nonce: "45", blockHash: "0x60cc72c65c0f8b9f6d444cd89baa8df1e7a6efbf49dab12ee153f920e093c3f8", transactionIndex: "55", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x1cad5a400000000000000000000000005b80f18d9c3f91acbc20cee093943845df4d3513000000000000000000000000d26114cd6ee289accf82350c8d8487fedb8a0c070000000000000000000000000000000000000000000000409071fdcfc23c0000", contractAddress: "", cumulativeGasUsed: "3553745", gasUsed: "70253", confirmations: "1054183"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_user", value: addressList[6]}, {type: "address", name: "_token", value: addressList[7]}, {type: "uint256", name: "_amount", value: "1191000000000000000000"}], name: "depositERC20", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositERC20(address,address,uint256)" ]( addressList[6], addressList[7], "1191000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541674418 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0xd26114cd6ee289accf82350c8d8487fedb8a0c07"}, {name: "amount", type: "uint256", value: "1191000000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8998431548333741258" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: depositEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6665877", timeStamp: "1541674673", hash: "0xc344be975b8e16f583a8480a3752a5917ce9e01ae7f221db05d2c89cf90c9812", nonce: "12", blockHash: "0x29048589152463cf120b750773795b52e15587c7b17ae57a72bbdddec0f75ec1", transactionIndex: "27", from: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "2000000000000000000", gas: "45237", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x98ea5fca", contractAddress: "", cumulativeGasUsed: "1132604", gasUsed: "45237", confirmations: "1054163"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositEther", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541674673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "2000000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "631801722943307781" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[8], addressList[9], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6665895", timeStamp: "1541674900", hash: "0xa8661e061c76d54f96de3b60e65e43f0921f36a2cc06875df91a71392079be43", nonce: "46", blockHash: "0xb06c01b1e20663b84821598a422f803791cda8ea374fe5cfd1ff0e40ac44d9b3", transactionIndex: "38", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000000a7bb040669d7fefa01fd7a856aced117818608b0000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a20000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000450e4da2d258000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000001b6da819bc5f558b670ee06d7786b3038381d4f1069eeaa8c6605687e0cfa8105502f8793b10e0eb442debefcebcd3a56952f95f54b1aed4e1933984cb218e2c10", contractAddress: "", cumulativeGasUsed: "1568348", gasUsed: "196076", confirmations: "1054145"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[8]}, {type: "address", name: "_offerAsset", value: addressList[9]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "100000000000000000"}, {type: "uint256", name: "_wantAmount", value: "311000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "5"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x6da819bc5f558b670ee06d7786b3038381d4f1069eeaa8c6605687e0cfa81055"}, {type: "bytes32", name: "_s", value: "0x02f8793b10e0eb442debefcebcd3a56952f95f54b1aed4e1933984cb218e2c10"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[8], addressList[9], addressList[0], "100000000000000000", "311000000000000000", addressList[0], "0", "5", "27", "0x6da819bc5f558b670ee06d7786b3038381d4f1069eeaa8c6605687e0cfa81055", "0x02f8793b10e0eb442debefcebcd3a56952f95f54b1aed4e1933984cb218e2c10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541674900 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x0a7bb040669d7fefa01fd7a856aced117818608b"}, {name: "offerHash", type: "bytes32", value: "0xd2e9f7eef7965074188e72396964ec0c280703d4c6faf43d139c587a97e011f1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0a7bb040669d7fefa01fd7a856aced117818608b"}, {name: "token", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8998431548333741258" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[6], addressList[7], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6665898", timeStamp: "1541674917", hash: "0x75833de4c2e3618432aca7f69ef7fb225db94a63d366bcf5c390fe5fe89af0b5", nonce: "47", blockHash: "0x3d6569dbf11b5a2ab6c609d8fada7193be7d3a7ade843199747e8326b6a4f159", transactionIndex: "26", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000005b80f18d9c3f91acbc20cee093943845df4d3513000000000000000000000000d26114cd6ee289accf82350c8d8487fedb8a0c0700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001bc16d674ec80000000000000000000000000000000000000000000000000000006f8e2235f28000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001cff878d2a49f00e3ab6375c224ba5e2dfb8bb8dccbc871652c2c74f62a78d8b6e26682caef83c939e39acf39f2902e784d452e654c45c47733d3d790bb9ad6b02", contractAddress: "", cumulativeGasUsed: "1709602", gasUsed: "196012", confirmations: "1054142"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[6]}, {type: "address", name: "_offerAsset", value: addressList[7]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "2000000000000000000"}, {type: "uint256", name: "_wantAmount", value: "31400000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "1"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xff878d2a49f00e3ab6375c224ba5e2dfb8bb8dccbc871652c2c74f62a78d8b6e"}, {type: "bytes32", name: "_s", value: "0x26682caef83c939e39acf39f2902e784d452e654c45c47733d3d790bb9ad6b02"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[6], addressList[7], addressList[0], "2000000000000000000", "31400000000000000", addressList[0], "0", "1", "28", "0xff878d2a49f00e3ab6375c224ba5e2dfb8bb8dccbc871652c2c74f62a78d8b6e", "0x26682caef83c939e39acf39f2902e784d452e654c45c47733d3d790bb9ad6b02", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541674917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "offerHash", type: "bytes32", value: "0x1e280ad9e57176167b7a870df980e943f7a6579e42efef7b4ddf3784cdfaae6a"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0xd26114cd6ee289accf82350c8d8487fedb8a0c07"}, {name: "amount", type: "uint256", value: "2000000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8998431548333741258" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: fillOffers( addressList[11], [\"0xd2e9f7eef796507418... )", async function( ) {
		const txOriginal = {blockNumber: "6665900", timeStamp: "1541674931", hash: "0xf74acf51ff8b36b6ace8c2c80771b9ea9e23db2df9a76d952b73c3c5b8f2210f", nonce: "48", blockHash: "0x6a4eb1b10f8b989f3591362f6f7e78e7e0af8fb5727179054b6dfdd099e8f821", transactionIndex: "48", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xd9b6e0a60000000000000000000000007c819b61b3a35ab718f66508d31e2cf3c25eb624000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001600000000000000000000000009f8f72aa9304c8b593d555f12ef6589cc3a579a20000000000000000000000000000000000000000000000000000b5e620f480000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001bccda219521079887742c3e4bf32e20af0aba473370635ed20d951350dee528386cbb3d340687a2734eff30c29d499061546ebf5cf64cb3257e96a596931b5fa60000000000000000000000000000000000000000000000000000000000000001d2e9f7eef7965074188e72396964ec0c280703d4c6faf43d139c587a97e011f10000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "1678802", gasUsed: "100279", confirmations: "1054140"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_filler", value: addressList[11]}, {type: "bytes32[]", name: "_offerHashes", value: ["0xd2e9f7eef7965074188e72396964ec0c280703d4c6faf43d139c587a97e011f1"]}, {type: "uint256[]", name: "_amountsToTake", value: ["100000000000000000"]}, {type: "address", name: "_feeAsset", value: addressList[9]}, {type: "uint256", name: "_feeAmount", value: "200000000000000"}, {type: "uint64", name: "_nonce", value: "1"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xccda219521079887742c3e4bf32e20af0aba473370635ed20d951350dee52838"}, {type: "bytes32", name: "_s", value: "0x6cbb3d340687a2734eff30c29d499061546ebf5cf64cb3257e96a596931b5fa6"}], name: "fillOffers", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillOffers(address,bytes32[],uint256[],address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[11], ["0xd2e9f7eef7965074188e72396964ec0c280703d4c6faf43d139c587a97e011f1"], ["100000000000000000"], addressList[9], "200000000000000", "1", "27", "0xccda219521079887742c3e4bf32e20af0aba473370635ed20d951350dee52838", "0x6cbb3d340687a2734eff30c29d499061546ebf5cf64cb3257e96a596931b5fa6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541674931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "filler", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}, {indexed: false, name: "amountFilled", type: "uint256"}, {indexed: false, name: "amountTaken", type: "uint256"}, {indexed: true, name: "maker", type: "address"}], name: "Fill", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Fill", events: [{name: "filler", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "offerHash", type: "bytes32", value: "0xd2e9f7eef7965074188e72396964ec0c280703d4c6faf43d139c587a97e011f1"}, {name: "amountFilled", type: "uint256", value: "311000000000000000"}, {name: "amountTaken", type: "uint256", value: "100000000000000000"}, {name: "maker", type: "address", value: "0x0a7bb040669d7fefa01fd7a856aced117818608b"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0a7bb040669d7fefa01fd7a856aced117818608b"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "311000000000000000"}, {name: "reason", type: "uint8", value: "6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "reason", type: "uint8", value: "5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x3eda2e44d5c2c000267b7cff27018881fa283ae7"}, {name: "token", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "amount", type: "uint256", value: "200000000000000"}, {name: "reason", type: "uint8", value: "7"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "311000000000000000"}, {name: "reason", type: "uint8", value: "3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2"}, {name: "amount", type: "uint256", value: "200000000000000"}, {name: "reason", type: "uint8", value: "4"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8998431548333741258" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: fillOffers( addressList[11], [\"0x1e280ad9e57176167b... )", async function( ) {
		const txOriginal = {blockNumber: "6665904", timeStamp: "1541674963", hash: "0x2fce658acfd98273c2413c07c6626ce179491fd14f79650093199b6657512127", nonce: "49", blockHash: "0x5c14156ae3a71b2aa0129e26f9d7943302653b16d2c60c3b5e0d617e435a7635", transactionIndex: "10", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0xd9b6e0a60000000000000000000000007c819b61b3a35ab718f66508d31e2cf3c25eb62400000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000160000000000000000000000000d26114cd6ee289accf82350c8d8487fedb8a0c07000000000000000000000000000000000000000000000000000e35fa931a00000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001bd16dd9d9f7cda8daf71f1d92290bba1e1625176ab7ae523dce63f61d57ddc43d7b3c78c747f5f26ae06d21eb583c96932ff848cc5bbac79e757f54133cdb436200000000000000000000000000000000000000000000000000000000000000011e280ad9e57176167b7a870df980e943f7a6579e42efef7b4ddf3784cdfaae6a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "918951", gasUsed: "87640", confirmations: "1054136"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_filler", value: addressList[11]}, {type: "bytes32[]", name: "_offerHashes", value: ["0x1e280ad9e57176167b7a870df980e943f7a6579e42efef7b4ddf3784cdfaae6a"]}, {type: "uint256[]", name: "_amountsToTake", value: ["2000000000000000000"]}, {type: "address", name: "_feeAsset", value: addressList[7]}, {type: "uint256", name: "_feeAmount", value: "4000000000000000"}, {type: "uint64", name: "_nonce", value: "2"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xd16dd9d9f7cda8daf71f1d92290bba1e1625176ab7ae523dce63f61d57ddc43d"}, {type: "bytes32", name: "_s", value: "0x7b3c78c747f5f26ae06d21eb583c96932ff848cc5bbac79e757f54133cdb4362"}], name: "fillOffers", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillOffers(address,bytes32[],uint256[],address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[11], ["0x1e280ad9e57176167b7a870df980e943f7a6579e42efef7b4ddf3784cdfaae6a"], ["2000000000000000000"], addressList[7], "4000000000000000", "2", "27", "0xd16dd9d9f7cda8daf71f1d92290bba1e1625176ab7ae523dce63f61d57ddc43d", "0x7b3c78c747f5f26ae06d21eb583c96932ff848cc5bbac79e757f54133cdb4362", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541674963 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "filler", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}, {indexed: false, name: "amountFilled", type: "uint256"}, {indexed: false, name: "amountTaken", type: "uint256"}, {indexed: true, name: "maker", type: "address"}], name: "Fill", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Fill", events: [{name: "filler", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "offerHash", type: "bytes32", value: "0x1e280ad9e57176167b7a870df980e943f7a6579e42efef7b4ddf3784cdfaae6a"}, {name: "amountFilled", type: "uint256", value: "31400000000000000"}, {name: "amountTaken", type: "uint256", value: "2000000000000000000"}, {name: "maker", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "31400000000000000"}, {name: "reason", type: "uint8", value: "6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0xd26114cd6ee289accf82350c8d8487fedb8a0c07"}, {name: "amount", type: "uint256", value: "2000000000000000000"}, {name: "reason", type: "uint8", value: "5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x3eda2e44d5c2c000267b7cff27018881fa283ae7"}, {name: "token", type: "address", value: "0xd26114cd6ee289accf82350c8d8487fedb8a0c07"}, {name: "amount", type: "uint256", value: "4000000000000000"}, {name: "reason", type: "uint8", value: "7"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "31400000000000000"}, {name: "reason", type: "uint8", value: "3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0xd26114cd6ee289accf82350c8d8487fedb8a0c07"}, {name: "amount", type: "uint256", value: "4000000000000000"}, {name: "reason", type: "uint8", value: "4"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8998431548333741258" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[5], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6665927", timeStamp: "1541675336", hash: "0x501bfd756fac4f2d12fc35b19d9547aea47050c1e311282f55a020d3c41cd29f", nonce: "50", blockHash: "0xe63673f0ffedfa40bf12f1d2ea84e1712b324e8c349dca80ac1ae87cab877332", transactionIndex: "87", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "11500000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000000052c739ff444000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001bbe5db3cf6cbfcefa5b2aa1a6109aadc188596882b72c4bf5cfe983c91cab7ad81432abc65fb64b6a5924b3c38460e0dcb2c8559e7a8362879d96a890fffeb620", contractAddress: "", cumulativeGasUsed: "2714107", gasUsed: "196012", confirmations: "1054113"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "5000000000000000000"}, {type: "uint256", name: "_wantAmount", value: "23300000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "2"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xbe5db3cf6cbfcefa5b2aa1a6109aadc188596882b72c4bf5cfe983c91cab7ad8"}, {type: "bytes32", name: "_s", value: "0x1432abc65fb64b6a5924b3c38460e0dcb2c8559e7a8362879d96a890fffeb620"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[5], addressList[0], "5000000000000000000", "23300000000000000", addressList[0], "0", "2", "27", "0xbe5db3cf6cbfcefa5b2aa1a6109aadc188596882b72c4bf5cfe983c91cab7ad8", "0x1432abc65fb64b6a5924b3c38460e0dcb2c8559e7a8362879d96a890fffeb620", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541675336 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0xff3b619466f30f93508a107e0307ef4d94fcf4d9c5511b5e6f5f7cf50ab16f9d"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "5000000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8998431548333741258" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: fillOffers( addressList[11], [\"0xff3b619466f30f9350... )", async function( ) {
		const txOriginal = {blockNumber: "6665932", timeStamp: "1541675405", hash: "0x7ac5585802572d0c73f1f60632ed9a1f5bdf18dc15c68c36d35daa83531eddaf", nonce: "51", blockHash: "0x06b49190e56717da533dc3f05b4ee4ff8cb942c6a75293fe6bcaa45d06192383", transactionIndex: "9", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0xd9b6e0a60000000000000000000000007c819b61b3a35ab718f66508d31e2cf3c25eb6240000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000016000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000001bc77d22911a228588b77bf68c6a95aa69b5efd5bc47132588fa79ead8cdd8e43474c83b518a361e62e6e21d9327f878dde0ded3b4cc6666c32289caab634732070000000000000000000000000000000000000000000000000000000000000001ff3b619466f30f93508a107e0307ef4d94fcf4d9c5511b5e6f5f7cf50ab16f9d00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000004563918244f40000", contractAddress: "", cumulativeGasUsed: "532218", gasUsed: "87640", confirmations: "1054108"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_filler", value: addressList[11]}, {type: "bytes32[]", name: "_offerHashes", value: ["0xff3b619466f30f93508a107e0307ef4d94fcf4d9c5511b5e6f5f7cf50ab16f9d"]}, {type: "uint256[]", name: "_amountsToTake", value: ["5000000000000000000"]}, {type: "address", name: "_feeAsset", value: addressList[5]}, {type: "uint256", name: "_feeAmount", value: "10000000000000000"}, {type: "uint64", name: "_nonce", value: "3"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xc77d22911a228588b77bf68c6a95aa69b5efd5bc47132588fa79ead8cdd8e434"}, {type: "bytes32", name: "_s", value: "0x74c83b518a361e62e6e21d9327f878dde0ded3b4cc6666c32289caab63473207"}], name: "fillOffers", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillOffers(address,bytes32[],uint256[],address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[11], ["0xff3b619466f30f93508a107e0307ef4d94fcf4d9c5511b5e6f5f7cf50ab16f9d"], ["5000000000000000000"], addressList[5], "10000000000000000", "3", "27", "0xc77d22911a228588b77bf68c6a95aa69b5efd5bc47132588fa79ead8cdd8e434", "0x74c83b518a361e62e6e21d9327f878dde0ded3b4cc6666c32289caab63473207", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541675405 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "filler", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}, {indexed: false, name: "amountFilled", type: "uint256"}, {indexed: false, name: "amountTaken", type: "uint256"}, {indexed: true, name: "maker", type: "address"}], name: "Fill", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Fill", events: [{name: "filler", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "offerHash", type: "bytes32", value: "0xff3b619466f30f93508a107e0307ef4d94fcf4d9c5511b5e6f5f7cf50ab16f9d"}, {name: "amountFilled", type: "uint256", value: "23300000000000000"}, {name: "amountTaken", type: "uint256", value: "5000000000000000000"}, {name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[25,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "23300000000000000"}, {name: "reason", type: "uint8", value: "6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "5000000000000000000"}, {name: "reason", type: "uint8", value: "5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x3eda2e44d5c2c000267b7cff27018881fa283ae7"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "reason", type: "uint8", value: "7"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[25,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "23300000000000000"}, {name: "reason", type: "uint8", value: "3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x7c819b61b3a35ab718f66508d31e2cf3c25eb624"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000"}, {name: "reason", type: "uint8", value: "4"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8998431548333741258" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: depositEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6665956", timeStamp: "1541675707", hash: "0x013bbf84ff1bf2d464b424de28ce121d45860e20ef00351846bd3df19e3a8bc3", nonce: "2", blockHash: "0x6fd4dc2340b10e99c0556bd3585665e229d90012c7a82c55388cc261188d8038", transactionIndex: "104", from: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "500000000000000000", gas: "45237", gasPrice: "8500000000", isError: "0", txreceipt_status: "1", input: "0x98ea5fca", contractAddress: "", cumulativeGasUsed: "6872376", gasUsed: "45237", confirmations: "1054084"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositEther", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541675707 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "500000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "246805911641888585" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[5], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6665970", timeStamp: "1541675897", hash: "0xe3f55aa1cf0bbec2a839417a492c16254d1fd6e7556afefd1d7c921e75222bb7", nonce: "53", blockHash: "0x84c8113324c9e54beb9f54bb66081045ecd7390023123f96fcbf9b791d7b83ea", transactionIndex: "76", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "23000000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a23260359000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000410d586a20a4c000000000000000000000000000000000000000000000000000004f4519bc8d0800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000001ce36ce184e8da80ecb4f570bb36b2eafba34b3190e3ed728da98ca988cfa46c3a78e7b2bcbd91da16911f1b6d03e97dead83075fb323a2ce6ae0ff67db82172f4", contractAddress: "", cumulativeGasUsed: "3781065", gasUsed: "196140", confirmations: "1054070"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "75000000000000000000"}, {type: "uint256", name: "_wantAmount", value: "357000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "28"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xe36ce184e8da80ecb4f570bb36b2eafba34b3190e3ed728da98ca988cfa46c3a"}, {type: "bytes32", name: "_s", value: "0x78e7b2bcbd91da16911f1b6d03e97dead83075fb323a2ce6ae0ff67db82172f4"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[5], addressList[0], "75000000000000000000", "357000000000000000", addressList[0], "0", "28", "28", "0xe36ce184e8da80ecb4f570bb36b2eafba34b3190e3ed728da98ca988cfa46c3a", "0x78e7b2bcbd91da16911f1b6d03e97dead83075fb323a2ce6ae0ff67db82172f4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541675897 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0x0f28f394ba9c6dca792f9ea47c552285ec983f54589895871ff03ee3f29975f5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "75000000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8998431548333741258" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "677987513641763457580" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: depositEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6665970", timeStamp: "1541675897", hash: "0x3b34cffcb6b4b5db14b5bed11d96ccf8d9d04ed441dfc6caee8161e1a6103df1", nonce: "24", blockHash: "0x84c8113324c9e54beb9f54bb66081045ecd7390023123f96fcbf9b791d7b83ea", transactionIndex: "95", from: "0x5be2f49d897a8c4603960c457ffb466527a28eae", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "1000000000000000000", gas: "45237", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x98ea5fca", contractAddress: "", cumulativeGasUsed: "4714050", gasUsed: "45237", confirmations: "1054070"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositEther", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541675897 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x5be2f49d897a8c4603960c457ffb466527a28eae"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "1000000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "45410601681447397" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "669988891041763457580" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: depositEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6665970", timeStamp: "1541675897", hash: "0x113ae5e440ab9acbb7fe2bbbf6c44c856dbf567db8f3f6e43a39847fa427c8fc", nonce: "5", blockHash: "0x84c8113324c9e54beb9f54bb66081045ecd7390023123f96fcbf9b791d7b83ea", transactionIndex: "124", from: "0x0a7bb040669d7fefa01fd7a856aced117818608b", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "22000000000000000000", gas: "30237", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x98ea5fca", contractAddress: "", cumulativeGasUsed: "5524224", gasUsed: "30237", confirmations: "1054070"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "22000000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositEther", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541675897 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0a7bb040669d7fefa01fd7a856aced117818608b"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "22000000000000000000"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1329150313762974" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "669988891041763457580" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: fillOffers( addressList[12], [\"0x0f28f394ba9c6dca79... )", async function( ) {
		const txOriginal = {blockNumber: "6665977", timeStamp: "1541675950", hash: "0x557a703826955b3abdaaa3f3e8f85c7ee8660d03b39153d161ed08faac24e28f", nonce: "54", blockHash: "0x9dff1b0a1db6b4fe9d6aee4100beee6b4e2b652fe32095d0a7dc34aeee979b03", transactionIndex: "21", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "23000000000", isError: "0", txreceipt_status: "1", input: "0xd9b6e0a60000000000000000000000000f936dce97a9a5c50becc3f58a4842b4c607e7220000000000000000000000000000000000000000000000000000000000000120000000000000000000000000000000000000000000000000000000000000016000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000214e8348c4f00000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001b77979bfa9bb598e1537332ecb5dd0dfea72802c1fc0a17362e501f1f619325a95a6b0499636a54bfe502868218bcf321a66c717918b34d44f3491e95bf5910a100000000000000000000000000000000000000000000000000000000000000010f28f394ba9c6dca792f9ea47c552285ec983f54589895871ff03ee3f29975f5000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000410d586a20a4c0000", contractAddress: "", cumulativeGasUsed: "1581281", gasUsed: "80204", confirmations: "1054063"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_filler", value: addressList[12]}, {type: "bytes32[]", name: "_offerHashes", value: ["0x0f28f394ba9c6dca792f9ea47c552285ec983f54589895871ff03ee3f29975f5"]}, {type: "uint256[]", name: "_amountsToTake", value: ["75000000000000000000"]}, {type: "address", name: "_feeAsset", value: addressList[5]}, {type: "uint256", name: "_feeAmount", value: "150000000000000000"}, {type: "uint64", name: "_nonce", value: "2"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x77979bfa9bb598e1537332ecb5dd0dfea72802c1fc0a17362e501f1f619325a9"}, {type: "bytes32", name: "_s", value: "0x5a6b0499636a54bfe502868218bcf321a66c717918b34d44f3491e95bf5910a1"}], name: "fillOffers", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillOffers(address,bytes32[],uint256[],address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[12], ["0x0f28f394ba9c6dca792f9ea47c552285ec983f54589895871ff03ee3f29975f5"], ["75000000000000000000"], addressList[5], "150000000000000000", "2", "27", "0x77979bfa9bb598e1537332ecb5dd0dfea72802c1fc0a17362e501f1f619325a9", "0x5a6b0499636a54bfe502868218bcf321a66c717918b34d44f3491e95bf5910a1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541675950 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "filler", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}, {indexed: false, name: "amountFilled", type: "uint256"}, {indexed: false, name: "amountTaken", type: "uint256"}, {indexed: true, name: "maker", type: "address"}], name: "Fill", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Fill", events: [{name: "filler", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "offerHash", type: "bytes32", value: "0x0f28f394ba9c6dca792f9ea47c552285ec983f54589895871ff03ee3f29975f5"}, {name: "amountFilled", type: "uint256", value: "357000000000000000"}, {name: "amountTaken", type: "uint256", value: "75000000000000000000"}, {name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "357000000000000000"}, {name: "reason", type: "uint8", value: "6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "75000000000000000000"}, {name: "reason", type: "uint8", value: "5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x3eda2e44d5c2c000267b7cff27018881fa283ae7"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "150000000000000000"}, {name: "reason", type: "uint8", value: "7"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "357000000000000000"}, {name: "reason", type: "uint8", value: "3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "150000000000000000"}, {name: "reason", type: "uint8", value: "4"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8997280524733741258" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[0], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6665989", timeStamp: "1541676106", hash: "0x88b7402114b148461b150cff97457511d0fb366bde3e9a355949d499350f5cb4", nonce: "55", blockHash: "0x720c3a872eea789089dbe59242bf942e3545d9fa74a691daf3927c3145de87d7", transactionIndex: "47", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "17000000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000004e9a91fda7d000000000000000000000000000000000000000000000000000410d586a20a4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001d000000000000000000000000000000000000000000000000000000000000001bb3c47c61cd58a949d0bf7c48dc0992f43889de8f496f031ca438f56bb369fdae2a3340d920fe7d2fbed7c0205b66c3810a856edfb5e4dce05670e8a4b172cbf9", contractAddress: "", cumulativeGasUsed: "1929720", gasUsed: "181162", confirmations: "1054051"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[0]}, {type: "address", name: "_wantAsset", value: addressList[5]}, {type: "uint256", name: "_offerAmount", value: "354000000000000000"}, {type: "uint256", name: "_wantAmount", value: "75000000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "29"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xb3c47c61cd58a949d0bf7c48dc0992f43889de8f496f031ca438f56bb369fdae"}, {type: "bytes32", name: "_s", value: "0x2a3340d920fe7d2fbed7c0205b66c3810a856edfb5e4dce05670e8a4b172cbf9"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[0], addressList[5], "354000000000000000", "75000000000000000000", addressList[0], "0", "29", "27", "0xb3c47c61cd58a949d0bf7c48dc0992f43889de8f496f031ca438f56bb369fdae", "0x2a3340d920fe7d2fbed7c0205b66c3810a856edfb5e4dce05670e8a4b172cbf9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541676106 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "354000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8997280524733741258" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: fillOffers( addressList[12], [\"0xa87338a69c1d447a51... )", async function( ) {
		const txOriginal = {blockNumber: "6665995", timeStamp: "1541676195", hash: "0xfae0263b6cb892e6134fd0ce2d2ed298f4c02296c33e9e0f9ac59a164afd184d", nonce: "56", blockHash: "0xa9f2dc5bec92eeb52508e3aa2fa4a448a06fb586ebfead97791a47dd00464e9c", transactionIndex: "30", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xd9b6e0a60000000000000000000000000f936dce97a9a5c50becc3f58a4842b4c607e722000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000055db367780000000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000001beaf419be5aa9a4a2fe5c0e1f64babd6d0d52ad875be13e32f5a471d27e2275036b8ef8e1376211b02bdfa80c9c59ee4200b97501d928dd7612d8e26bcbbe56b30000000000000000000000000000000000000000000000000000000000000001a87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000a7b02661660000", contractAddress: "", cumulativeGasUsed: "1227369", gasUsed: "128178", confirmations: "1054045"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_filler", value: addressList[12]}, {type: "bytes32[]", name: "_offerHashes", value: ["0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5"]}, {type: "uint256[]", name: "_amountsToTake", value: ["47200000000000000"]}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "94400000000000"}, {type: "uint64", name: "_nonce", value: "3"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xeaf419be5aa9a4a2fe5c0e1f64babd6d0d52ad875be13e32f5a471d27e227503"}, {type: "bytes32", name: "_s", value: "0x6b8ef8e1376211b02bdfa80c9c59ee4200b97501d928dd7612d8e26bcbbe56b3"}], name: "fillOffers", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillOffers(address,bytes32[],uint256[],address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[12], ["0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5"], ["47200000000000000"], addressList[0], "94400000000000", "3", "27", "0xeaf419be5aa9a4a2fe5c0e1f64babd6d0d52ad875be13e32f5a471d27e227503", "0x6b8ef8e1376211b02bdfa80c9c59ee4200b97501d928dd7612d8e26bcbbe56b3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541676195 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "filler", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}, {indexed: false, name: "amountFilled", type: "uint256"}, {indexed: false, name: "amountTaken", type: "uint256"}, {indexed: true, name: "maker", type: "address"}], name: "Fill", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Fill", events: [{name: "filler", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "offerHash", type: "bytes32", value: "0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5"}, {name: "amountFilled", type: "uint256", value: "10000000000000000000"}, {name: "amountTaken", type: "uint256", value: "47200000000000000"}, {name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "reason", type: "uint8", value: "6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "47200000000000000"}, {name: "reason", type: "uint8", value: "5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x3eda2e44d5c2c000267b7cff27018881fa283ae7"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "94400000000000"}, {name: "reason", type: "uint8", value: "7"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "reason", type: "uint8", value: "3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "94400000000000"}, {name: "reason", type: "uint8", value: "4"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: fillOffers( addressList[12], [\"0xa87338a69c1d447a51... )", async function( ) {
		const txOriginal = {blockNumber: "6665999", timeStamp: "1541676268", hash: "0xbd85d1dd27b2581ce9aa991f089f70f28c7dfccc19f1a280280fd5ec9246e0a1", nonce: "57", blockHash: "0x303ccc2bc53f1b04ce670d3c5a12195720856ebeb4fef874dbe477d2aace7058", transactionIndex: "40", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xd9b6e0a60000000000000000000000000f936dce97a9a5c50becc3f58a4842b4c607e722000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000055db367780000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001be57d94ddb91e5238656f737cb694204f0a9232e6c3b271e95f25c334508c49350398420d9da2e46d7f982d3e50bc464f250f07e9771399a0af523122403920ec0000000000000000000000000000000000000000000000000000000000000001a87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000a7b02661660000", contractAddress: "", cumulativeGasUsed: "1492299", gasUsed: "113242", confirmations: "1054041"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_filler", value: addressList[12]}, {type: "bytes32[]", name: "_offerHashes", value: ["0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5"]}, {type: "uint256[]", name: "_amountsToTake", value: ["47200000000000000"]}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "94400000000000"}, {type: "uint64", name: "_nonce", value: "4"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xe57d94ddb91e5238656f737cb694204f0a9232e6c3b271e95f25c334508c4935"}, {type: "bytes32", name: "_s", value: "0x0398420d9da2e46d7f982d3e50bc464f250f07e9771399a0af523122403920ec"}], name: "fillOffers", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillOffers(address,bytes32[],uint256[],address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[12], ["0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5"], ["47200000000000000"], addressList[0], "94400000000000", "4", "27", "0xe57d94ddb91e5238656f737cb694204f0a9232e6c3b271e95f25c334508c4935", "0x0398420d9da2e46d7f982d3e50bc464f250f07e9771399a0af523122403920ec", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541676268 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "filler", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}, {indexed: false, name: "amountFilled", type: "uint256"}, {indexed: false, name: "amountTaken", type: "uint256"}, {indexed: true, name: "maker", type: "address"}], name: "Fill", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Fill", events: [{name: "filler", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "offerHash", type: "bytes32", value: "0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5"}, {name: "amountFilled", type: "uint256", value: "10000000000000000000"}, {name: "amountTaken", type: "uint256", value: "47200000000000000"}, {name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "reason", type: "uint8", value: "6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "47200000000000000"}, {name: "reason", type: "uint8", value: "5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x3eda2e44d5c2c000267b7cff27018881fa283ae7"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "94400000000000"}, {name: "reason", type: "uint8", value: "7"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "reason", type: "uint8", value: "3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "94400000000000"}, {name: "reason", type: "uint8", value: "4"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( addressList[12], addressList[0], \"10000... )", async function( ) {
		const txOriginal = {blockNumber: "6666001", timeStamp: "1541676302", hash: "0xa18390eff28d587b86abcd3e7c6db33a58d1f75e437ffb3107a9543d8d900101", nonce: "58", blockHash: "0xd1956c8340c81b9fe6af498bf81f71924c4b600df63a73313a2b22440b4c17d3", transactionIndex: "106", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x58efd2930000000000000000000000000f936dce97a9a5c50becc3f58a4842b4c607e7220000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016345785d8a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c4b7a5fe84b9c8515d57a3508600689c5ee71fc54b39d4032ce3b6427eefc77c51152153c33b8e43bc7627adc1594016092e9d0ef0625e17c5ab90351b4c7b55d", contractAddress: "", cumulativeGasUsed: "2906398", gasUsed: "71904", confirmations: "1054039"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawer", value: addressList[12]}, {type: "address", name: "_token", value: addressList[0]}, {type: "uint256", name: "_amount", value: "100000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "1"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x4b7a5fe84b9c8515d57a3508600689c5ee71fc54b39d4032ce3b6427eefc77c5"}, {type: "bytes32", name: "_s", value: "0x1152153c33b8e43bc7627adc1594016092e9d0ef0625e17c5ab90351b4c7b55d"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(address,address,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[12], addressList[0], "100000000000000000", addressList[0], "0", "1", "28", "0x4b7a5fe84b9c8515d57a3508600689c5ee71fc54b39d4032ce3b6427eefc77c5", "0x1152153c33b8e43bc7627adc1594016092e9d0ef0625e17c5ab90351b4c7b55d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541676302 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "100000000000000000"}, {name: "reason", type: "uint8", value: "9"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: withdraw( addressList[12], addressList[5], \"19000... )", async function( ) {
		const txOriginal = {blockNumber: "6666003", timeStamp: "1541676324", hash: "0x1a5dcf51063573b0806b264fccd502d55c9bd69228c119eff668d7554f6bbdef", nonce: "59", blockHash: "0xc67f18b6e9534646708d36f5b84d821d9bf15689d5d3e0f39afb4286577aef14", transactionIndex: "34", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x58efd2930000000000000000000000000f936dce97a9a5c50becc3f58a4842b4c607e72200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000107ad8f556c6c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001caed75fb8e8bf1277b8ba262f7d50709692731df194e65cfc1a1e97f4476f73504425ce6f110606724a12e6f457c1959f63d304609c12b8d52055db55147725e9", contractAddress: "", cumulativeGasUsed: "1619593", gasUsed: "81873", confirmations: "1054037"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawer", value: addressList[12]}, {type: "address", name: "_token", value: addressList[5]}, {type: "uint256", name: "_amount", value: "19000000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "1"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xaed75fb8e8bf1277b8ba262f7d50709692731df194e65cfc1a1e97f4476f7350"}, {type: "bytes32", name: "_s", value: "0x4425ce6f110606724a12e6f457c1959f63d304609c12b8d52055db55147725e9"}], name: "withdraw", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdraw(address,address,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[12], addressList[5], "19000000000000000000", addressList[0], "0", "1", "28", "0xaed75fb8e8bf1277b8ba262f7d50709692731df194e65cfc1a1e97f4476f7350", "0x4425ce6f110606724a12e6f457c1959f63d304609c12b8d52055db55147725e9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541676324 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "19000000000000000000"}, {name: "reason", type: "uint8", value: "9"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[12], addressList[5], address... )", async function( ) {
		const txOriginal = {blockNumber: "6666015", timeStamp: "1541676545", hash: "0x954e738dee013edb093b417caca1ae81fccd8381443c219122b30b3b75147649", nonce: "60", blockHash: "0xe7d7ead947af6d3f5a02afc875befa8c57985f11e2e99189997e994cc9073867", transactionIndex: "46", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13300000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000000f936dce97a9a5c50becc3f58a4842b4c607e72200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000000a80b1971e04000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000001bc9dadb16aca976a6b18a223bb2185bb7f392f90c962a8de12f0a15202e04e0b874aa8b5b4897acfce8d3ff3ce29fc39b3f1e01b4c6b3a96fc999e0fcb66c436e", contractAddress: "", cumulativeGasUsed: "1909660", gasUsed: "196012", confirmations: "1054025"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[12]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "10000000000000000000"}, {type: "uint256", name: "_wantAmount", value: "47300000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "2"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xc9dadb16aca976a6b18a223bb2185bb7f392f90c962a8de12f0a15202e04e0b8"}, {type: "bytes32", name: "_s", value: "0x74aa8b5b4897acfce8d3ff3ce29fc39b3f1e01b4c6b3a96fc999e0fcb66c436e"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[12], addressList[5], addressList[0], "10000000000000000000", "47300000000000000", addressList[0], "0", "2", "27", "0xc9dadb16aca976a6b18a223bb2185bb7f392f90c962a8de12f0a15202e04e0b8", "0x74aa8b5b4897acfce8d3ff3ce29fc39b3f1e01b4c6b3a96fc999e0fcb66c436e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541676545 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "offerHash", type: "bytes32", value: "0x91b76abd58ad8f6e30f878723e564248b97b11edf33853a1b22206ea146cb3a3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[5], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6666017", timeStamp: "1541676558", hash: "0x254a7268b2d128be6a7e2532aa3aa1710c0acbdcef1ea9d21eedf7057c52370f", nonce: "61", blockHash: "0xbc62d1a03a7e2152d701cd60dc6c8c21d88e275e445d4bd59c54aad77d7fc87b", transactionIndex: "23", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13300000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e4fbc69449f20000000000000000000000000000000000000000000000000000011e10836d508000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000025000000000000000000000000000000000000000000000000000000000000001ccd1489d46f51ce54573533ffcb2cbdfd93c15a3967d394391c0706791a00717239ab1a114e70bf2222ccec25dfdcb35fdeecb897bcebfd98b417658220b39f7f", contractAddress: "", cumulativeGasUsed: "963193", gasUsed: "196012", confirmations: "1054023"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "16500000000000000000"}, {type: "uint256", name: "_wantAmount", value: "80520000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "37"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xcd1489d46f51ce54573533ffcb2cbdfd93c15a3967d394391c0706791a007172"}, {type: "bytes32", name: "_s", value: "0x39ab1a114e70bf2222ccec25dfdcb35fdeecb897bcebfd98b417658220b39f7f"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[5], addressList[0], "16500000000000000000", "80520000000000000", addressList[0], "0", "37", "28", "0xcd1489d46f51ce54573533ffcb2cbdfd93c15a3967d394391c0706791a007172", "0x39ab1a114e70bf2222ccec25dfdcb35fdeecb897bcebfd98b417658220b39f7f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541676558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0xca1b8ad4748a2487128a725cd3fe1c7cdfe64aeaee64b51f73749e4cc2e908e2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "16500000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[12], addressList[5], address... )", async function( ) {
		const txOriginal = {blockNumber: "6666020", timeStamp: "1541676581", hash: "0x4d186b482baa0b87e91fe466a230d6150be46f3e5f8550f2f654dfdfc155ad24", nonce: "62", blockHash: "0xb8f4b8617baf976f8cde81b4d2be8bbcf5982b328076d3fb56b63b00c216f9f5", transactionIndex: "58", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13300000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000000f936dce97a9a5c50becc3f58a4842b4c607e72200000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000000a8c0ff92d4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000001ce4ed2c73c37b6340185db46f14b78a9187648a2f447824918f01c43001b7114031af9fc13c9559df1dee9b20918258b5da12f6e6fea0e6859d0870314e070815", contractAddress: "", cumulativeGasUsed: "3640653", gasUsed: "196012", confirmations: "1054020"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[12]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "10000000000000000000"}, {type: "uint256", name: "_wantAmount", value: "47500000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "3"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xe4ed2c73c37b6340185db46f14b78a9187648a2f447824918f01c43001b71140"}, {type: "bytes32", name: "_s", value: "0x31af9fc13c9559df1dee9b20918258b5da12f6e6fea0e6859d0870314e070815"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[12], addressList[5], addressList[0], "10000000000000000000", "47500000000000000", addressList[0], "0", "3", "28", "0xe4ed2c73c37b6340185db46f14b78a9187648a2f447824918f01c43001b71140", "0x31af9fc13c9559df1dee9b20918258b5da12f6e6fea0e6859d0870314e070815", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541676581 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "offerHash", type: "bytes32", value: "0x2c0c9e942b91aa53812b89c46598d878a9b356c765311b9fd8d0e206c9b6fcd6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: cancel( \"0xa87338a69c1d447a51703591ede830ec359a... )", async function( ) {
		const txOriginal = {blockNumber: "6666025", timeStamp: "1541676639", hash: "0xfab4dc05467abad9fe5157c168a5e1deff14c655c4b3b0b408556816a184426a", nonce: "63", blockHash: "0x18bd8040003ff4e085372a9856fe308c04e74be001ae8cd15fb3867e6d0f04ba", transactionIndex: "56", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13300000000", isError: "0", txreceipt_status: "1", input: "0x715058c1a87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5000000000000000000000000000000000000000000000000039a48d317b1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001bcf01a6e1fad5b5c97af503deda9ed66f151bfdd093fdb4be6abe2ef238bcb7a16734e56af3227652734829c05c686dde1177d17a01907ab90d16e6273b80c58a", contractAddress: "", cumulativeGasUsed: "3083517", gasUsed: "39164", confirmations: "1054015"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_offerHash", value: "0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5"}, {type: "uint256", name: "_expectedAvailableAmount", value: "259600000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0xcf01a6e1fad5b5c97af503deda9ed66f151bfdd093fdb4be6abe2ef238bcb7a1"}, {type: "bytes32", name: "_s", value: "0x6734e56af3227652734829c05c686dde1177d17a01907ab90d16e6273b80c58a"}], name: "cancel", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "cancel(bytes32,uint256,address,uint256,uint8,bytes32,bytes32)" ]( "0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5", "259600000000000000", addressList[0], "0", "27", "0xcf01a6e1fad5b5c97af503deda9ed66f151bfdd093fdb4be6abe2ef238bcb7a1", "0x6734e56af3227652734829c05c686dde1177d17a01907ab90d16e6273b80c58a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541676639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Cancel", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Cancel", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0xa87338a69c1d447a51703591ede830ec359a101c1c0884f6bce7e9aab013c8e5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "259600000000000000"}, {name: "reason", type: "uint8", value: "8"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: depositEther(  )", async function( ) {
		const txOriginal = {blockNumber: "6666025", timeStamp: "1541676639", hash: "0x969bd7ccf04d03098b2032714e19a5ac9c0b51cd233468caada23d02f1ef1413", nonce: "19", blockHash: "0x18bd8040003ff4e085372a9856fe308c04e74be001ae8cd15fb3867e6d0f04ba", transactionIndex: "124", from: "0x9d7863e2ca6cd42d9549bd3bde900fb6687be985", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "8889087559999996", gas: "45237", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x98ea5fca", contractAddress: "", cumulativeGasUsed: "6198735", gasUsed: "45237", confirmations: "1054015"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "8889087559999996" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositEther", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositEther()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541676639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x9d7863e2ca6cd42d9549bd3bde900fb6687be985"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "8889087559999996"}, {name: "reason", type: "uint8", value: "1"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "647630000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[0], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6666029", timeStamp: "1541676707", hash: "0x087724df6eacd0b7dad8d0fc7712f08c73bbb3f8b4f4643fc3534945ffa5e502", nonce: "64", blockHash: "0xec9261ee8b7c415f76abe1d465e6cd69aeb96509b24c1fff6272d112bfe69fe8", transactionIndex: "63", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13300000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000004df00a3ec29800000000000000000000000000000000000000000000000000410d586a20a4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002b000000000000000000000000000000000000000000000000000000000000001b382a0ca1ba6ab55883de5630810548998088935fd979fb0dee1f50a21524b01876eddc1048f86c3999afae61eb30691cadaf5e5f7b01839983b85bd4b5db5f56", contractAddress: "", cumulativeGasUsed: "3349484", gasUsed: "181162", confirmations: "1054011"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[0]}, {type: "address", name: "_wantAsset", value: addressList[5]}, {type: "uint256", name: "_offerAmount", value: "351000000000000000"}, {type: "uint256", name: "_wantAmount", value: "75000000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "43"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x382a0ca1ba6ab55883de5630810548998088935fd979fb0dee1f50a21524b018"}, {type: "bytes32", name: "_s", value: "0x76eddc1048f86c3999afae61eb30691cadaf5e5f7b01839983b85bd4b5db5f56"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[0], addressList[5], "351000000000000000", "75000000000000000000", addressList[0], "0", "43", "27", "0x382a0ca1ba6ab55883de5630810548998088935fd979fb0dee1f50a21524b018", "0x76eddc1048f86c3999afae61eb30691cadaf5e5f7b01839983b85bd4b5db5f56", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541676707 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0xc4f2144987d0cd121ca2379ffb5eee26e6627806968e6a2dd4cff5c5bc58326d"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "351000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[5], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6666031", timeStamp: "1541676727", hash: "0x1e9c5112955b4769cfde17606aed5eea52c87ec5ce2d81728247dc7a3bb68bfe", nonce: "65", blockHash: "0xe123757bf1f21b044662398800ce92b5dfcef933239eaa654d400e79871cf403", transactionIndex: "76", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000014f498ffead700000000000000000000000000000000000000000000000000000019f6f379e060000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001c9ef0f2948a1a51ce868869fcde25d76ae476bd4c06930cd8c04382af87ba80f55087e47deeaa5c264fcdbd63344899bef89d54f3ad9eb3edc3f10f0c9594f87c", contractAddress: "", cumulativeGasUsed: "3230430", gasUsed: "196076", confirmations: "1054009"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "24160000000000000000"}, {type: "uint256", name: "_wantAmount", value: "116934400000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "48"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x9ef0f2948a1a51ce868869fcde25d76ae476bd4c06930cd8c04382af87ba80f5"}, {type: "bytes32", name: "_s", value: "0x5087e47deeaa5c264fcdbd63344899bef89d54f3ad9eb3edc3f10f0c9594f87c"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[5], addressList[0], "24160000000000000000", "116934400000000000", addressList[0], "0", "48", "28", "0x9ef0f2948a1a51ce868869fcde25d76ae476bd4c06930cd8c04382af87ba80f5", "0x5087e47deeaa5c264fcdbd63344899bef89d54f3ad9eb3edc3f10f0c9594f87c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541676727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0xeae8449622a8f352d09db5ad5c2505d52089d64707f43c33cfe84bbd426cde92"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "24160000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[0], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6666033", timeStamp: "1541676759", hash: "0xc7008f0a1d980989146666ae7a69073c2950528f13ff643367d21bd1747d7e4a", nonce: "66", blockHash: "0xb2df126a63c87c2ffeeb8305027f39f56473de3702aaade680020f296449bba2", transactionIndex: "37", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13300000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000114af72871b8000000000000000000000000000000000000000000000000000e4fbc69449f20000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000039000000000000000000000000000000000000000000000000000000000000001cf70013ba0c1914fa1eca7aa0246835a23e4d679aea0314766fb4fe0e1cd3df134729323c8c30fc3b795c7055d1252126b3f5a532ec8521b57d7a7ef85c0a4887", contractAddress: "", cumulativeGasUsed: "3297745", gasUsed: "181098", confirmations: "1054007"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[0]}, {type: "address", name: "_wantAsset", value: addressList[5]}, {type: "uint256", name: "_offerAmount", value: "77880000000000000"}, {type: "uint256", name: "_wantAmount", value: "16500000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "57"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xf70013ba0c1914fa1eca7aa0246835a23e4d679aea0314766fb4fe0e1cd3df13"}, {type: "bytes32", name: "_s", value: "0x4729323c8c30fc3b795c7055d1252126b3f5a532ec8521b57d7a7ef85c0a4887"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[0], addressList[5], "77880000000000000", "16500000000000000000", addressList[0], "0", "57", "28", "0xf70013ba0c1914fa1eca7aa0246835a23e4d679aea0314766fb4fe0e1cd3df13", "0x4729323c8c30fc3b795c7055d1252126b3f5a532ec8521b57d7a7ef85c0a4887", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541676759 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0xfa1408725ec1852f3f9745dd794613d41fef82cc1889c7ef2b5c20e341294b7f"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "77880000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8996199819533741258" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[0], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6666036", timeStamp: "1541676807", hash: "0x8bcee655dc0b583a44721648b5995822dcffcecfb11c90641d205edc52f5b7a7", nonce: "67", blockHash: "0x0c25c9caba1084395f936b08693d13c73fda540c7eb452896a1895b1f02eb412", transactionIndex: "21", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13300000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000fe32588dade000000000000000000000000000000000000000000000000000d02ab486cedc0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000035000000000000000000000000000000000000000000000000000000000000001cf3210a5138525317553065c434d71a2b9791656f3cee6915633deb08b487a1fb3573d1b1cca431b6a84d7d2a3d4523647627efe43c983dc94c57e49f1d1ebee7", contractAddress: "", cumulativeGasUsed: "1164053", gasUsed: "181098", confirmations: "1054004"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[0]}, {type: "address", name: "_wantAsset", value: addressList[5]}, {type: "uint256", name: "_offerAmount", value: "71550000000000000"}, {type: "uint256", name: "_wantAmount", value: "15000000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "53"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xf3210a5138525317553065c434d71a2b9791656f3cee6915633deb08b487a1fb"}, {type: "bytes32", name: "_s", value: "0x3573d1b1cca431b6a84d7d2a3d4523647627efe43c983dc94c57e49f1d1ebee7"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[0], addressList[5], "71550000000000000", "15000000000000000000", addressList[0], "0", "53", "28", "0xf3210a5138525317553065c434d71a2b9791656f3cee6915633deb08b487a1fb", "0x3573d1b1cca431b6a84d7d2a3d4523647627efe43c983dc94c57e49f1d1ebee7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541676807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0x19fee96a3ce173a5758e699ee049f1a7a7e8c61ec2188ab975822d716b424cf0"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "71550000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8995118205533741258" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "671282809321763457580" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[5], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6666040", timeStamp: "1541676868", hash: "0xd993cef52e80af5c21187ecced0ec17c072fa0c88ecfc2c4eac6f00c56bb14b1", nonce: "68", blockHash: "0xdc93d68883ef477a561e19f92e13fbd07a399ef7a0e32af8f506412eada52776", transactionIndex: "54", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e4fbc69449f20000000000000000000000000000000000000000000000000000011e10836d508000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000042000000000000000000000000000000000000000000000000000000000000001c3d01edd7c543d4db9cc722568a6987f9e83fae75b17d5978a2827b34eee76dc3640a1e0d0422aa6094141926083d90f16bb34806249e07ee3be93b0ea2d46a51", contractAddress: "", cumulativeGasUsed: "2663004", gasUsed: "196076", confirmations: "1054000"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "16500000000000000000"}, {type: "uint256", name: "_wantAmount", value: "80520000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "66"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x3d01edd7c543d4db9cc722568a6987f9e83fae75b17d5978a2827b34eee76dc3"}, {type: "bytes32", name: "_s", value: "0x640a1e0d0422aa6094141926083d90f16bb34806249e07ee3be93b0ea2d46a51"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[5], addressList[0], "16500000000000000000", "80520000000000000", addressList[0], "0", "66", "28", "0x3d01edd7c543d4db9cc722568a6987f9e83fae75b17d5978a2827b34eee76dc3", "0x640a1e0d0422aa6094141926083d90f16bb34806249e07ee3be93b0ea2d46a51", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541676868 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0x627b7066c8a176e122ca9415c07ae3c49cbb6dea3563370b68eb73610328b38c"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "16500000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8994542693733741258" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "669753498021763457580" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[5], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6666041", timeStamp: "1541676875", hash: "0x2992f1a53cc043b298be2fe637bf63d032a95e48e5695ba6261cb024c61869c3", nonce: "69", blockHash: "0xfb0220215ed4679dfb5bce88251885ca77c503daac7f5077cc3d18a821313cba", transactionIndex: "29", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "13000000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d02ab486cedc00000000000000000000000000000000000000000000000000000101ed50bab18000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000043000000000000000000000000000000000000000000000000000000000000001b0edf38c651e6319e8cff1c46b67ea6c8ea5ce86a543b0dd8cb90c85697c598eb2ac5917888a74751b211f217d9579ac9483baaf0a7972137d35a4413abd9cd17", contractAddress: "", cumulativeGasUsed: "2362607", gasUsed: "196076", confirmations: "1053999"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "15000000000000000000"}, {type: "uint256", name: "_wantAmount", value: "72600000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "67"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x0edf38c651e6319e8cff1c46b67ea6c8ea5ce86a543b0dd8cb90c85697c598eb"}, {type: "bytes32", name: "_s", value: "0x2ac5917888a74751b211f217d9579ac9483baaf0a7972137d35a4413abd9cd17"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[5], addressList[0], "15000000000000000000", "72600000000000000", addressList[0], "0", "67", "27", "0x0edf38c651e6319e8cff1c46b67ea6c8ea5ce86a543b0dd8cb90c85697c598eb", "0x2ac5917888a74751b211f217d9579ac9483baaf0a7972137d35a4413abd9cd17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541676875 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0x4ddfdefbb4c1f5cb4c0ca752d215626c980c3a25bba073bdbc418dab131eda9b"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "15000000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8994542693733741258" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "669753498021763457580" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: fillOffers( addressList[6], [\"0x91b76abd58ad8f6e30f... )", async function( ) {
		const txOriginal = {blockNumber: "6666045", timeStamp: "1541676916", hash: "0x054cf784b74a94cc832bf4637b62b1c6baf3737f9eb171c25111aa5150b438b6", nonce: "70", blockHash: "0x742cb894b1f9ccca25dd4aa68b230680fe7e75d96d7a62082806c8c16d058293", transactionIndex: "65", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0xd9b6e0a60000000000000000000000005b80f18d9c3f91acbc20cee093943845df4d3513000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a2326035900000000000000000000000000000000000000000000000000a36cc19bab00000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000001c1cb6acc4f7bcd0eff60d0421279410e235f97caf5ae8f8b2eadfcd819a23c9d31b7d29e8f0055e8592f69e6d4046e5f04ffc6cae5b67e8e1c16079332b1c983f000000000000000000000000000000000000000000000000000000000000000391b76abd58ad8f6e30f878723e564248b97b11edf33853a1b22206ea146cb3a32c0c9e942b91aa53812b89c46598d878a9b356c765311b9fd8d0e206c9b6fcd6ca1b8ad4748a2487128a725cd3fe1c7cdfe64aeaee64b51f73749e4cc2e908e200000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000008ac7230489e800000000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000029a2241af62c0000", contractAddress: "", cumulativeGasUsed: "2303138", gasUsed: "134571", confirmations: "1053995"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_filler", value: addressList[6]}, {type: "bytes32[]", name: "_offerHashes", value: ["0x91b76abd58ad8f6e30f878723e564248b97b11edf33853a1b22206ea146cb3a3","0x2c0c9e942b91aa53812b89c46598d878a9b356c765311b9fd8d0e206c9b6fcd6","0xca1b8ad4748a2487128a725cd3fe1c7cdfe64aeaee64b51f73749e4cc2e908e2"]}, {type: "uint256[]", name: "_amountsToTake", value: ["10000000000000000000","10000000000000000000","3000000000000000000"]}, {type: "address", name: "_feeAsset", value: addressList[5]}, {type: "uint256", name: "_feeAmount", value: "46000000000000000"}, {type: "uint64", name: "_nonce", value: "1"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0x1cb6acc4f7bcd0eff60d0421279410e235f97caf5ae8f8b2eadfcd819a23c9d3"}, {type: "bytes32", name: "_s", value: "0x1b7d29e8f0055e8592f69e6d4046e5f04ffc6cae5b67e8e1c16079332b1c983f"}], name: "fillOffers", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fillOffers(address,bytes32[],uint256[],address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[6], ["0x91b76abd58ad8f6e30f878723e564248b97b11edf33853a1b22206ea146cb3a3","0x2c0c9e942b91aa53812b89c46598d878a9b356c765311b9fd8d0e206c9b6fcd6","0xca1b8ad4748a2487128a725cd3fe1c7cdfe64aeaee64b51f73749e4cc2e908e2"], ["10000000000000000000","10000000000000000000","3000000000000000000"], addressList[5], "46000000000000000", "1", "28", "0x1cb6acc4f7bcd0eff60d0421279410e235f97caf5ae8f8b2eadfcd819a23c9d3", "0x1b7d29e8f0055e8592f69e6d4046e5f04ffc6cae5b67e8e1c16079332b1c983f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541676916 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "filler", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}, {indexed: false, name: "amountFilled", type: "uint256"}, {indexed: false, name: "amountTaken", type: "uint256"}, {indexed: true, name: "maker", type: "address"}], name: "Fill", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Fill", events: [{name: "filler", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "offerHash", type: "bytes32", value: "0x91b76abd58ad8f6e30f878723e564248b97b11edf33853a1b22206ea146cb3a3"}, {name: "amountFilled", type: "uint256", value: "47300000000000000"}, {name: "amountTaken", type: "uint256", value: "10000000000000000000"}, {name: "maker", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "Fill", events: [{name: "filler", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "offerHash", type: "bytes32", value: "0x2c0c9e942b91aa53812b89c46598d878a9b356c765311b9fd8d0e206c9b6fcd6"}, {name: "amountFilled", type: "uint256", value: "47500000000000000"}, {name: "amountTaken", type: "uint256", value: "10000000000000000000"}, {name: "maker", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "Fill", events: [{name: "filler", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "offerHash", type: "bytes32", value: "0xca1b8ad4748a2487128a725cd3fe1c7cdfe64aeaee64b51f73749e4cc2e908e2"}, {name: "amountFilled", type: "uint256", value: "14640000000000000"}, {name: "amountTaken", type: "uint256", value: "3000000000000000000"}, {name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceIncrease", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "47300000000000000"}, {name: "reason", type: "uint8", value: "6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "reason", type: "uint8", value: "5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x0f936dce97a9a5c50becc3f58a4842b4c607e722"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "47500000000000000"}, {name: "reason", type: "uint8", value: "6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "10000000000000000000"}, {name: "reason", type: "uint8", value: "5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "14640000000000000"}, {name: "reason", type: "uint8", value: "6"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "3000000000000000000"}, {name: "reason", type: "uint8", value: "5"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceIncrease", events: [{name: "user", type: "address", value: "0x3eda2e44d5c2c000267b7cff27018881fa283ae7"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "46000000000000000"}, {name: "reason", type: "uint8", value: "7"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "47300000000000000"}, {name: "reason", type: "uint8", value: "3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "47500000000000000"}, {name: "reason", type: "uint8", value: "3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "amount", type: "uint256", value: "14640000000000000"}, {name: "reason", type: "uint8", value: "3"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}, {name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x5b80f18d9c3f91acbc20cee093943845df4d3513"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "46000000000000000"}, {name: "reason", type: "uint8", value: "4"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8994542693733741258" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "669753498021763457580" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[5], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6666047", timeStamp: "1541676936", hash: "0x6c3ce57e6934307d9413c4a15f551d60795c0e7bf3d840ed5ca8c7a5d2d1af90", nonce: "71", blockHash: "0xfa6697c744be1f9f13e32357876b21e7fd41803de36bf6471af1e2248da769ee", transactionIndex: "38", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d02ab486cedc0000000000000000000000000000000000000000000000000000010a741a46278000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000055000000000000000000000000000000000000000000000000000000000000001cefcaa83cc8cd4d5ea213a98920e1284c52342e9b2ea2f03a35ad5877fdb612ff17db07fb9ef3c90976e7e1c77b0da79e1c32d9c205e1939507e46ebecc933eb1", contractAddress: "", cumulativeGasUsed: "1265697", gasUsed: "196076", confirmations: "1053993"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "15000000000000000000"}, {type: "uint256", name: "_wantAmount", value: "75000000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "85"}, {type: "uint8", name: "_v", value: "28"}, {type: "bytes32", name: "_r", value: "0xefcaa83cc8cd4d5ea213a98920e1284c52342e9b2ea2f03a35ad5877fdb612ff"}, {type: "bytes32", name: "_s", value: "0x17db07fb9ef3c90976e7e1c77b0da79e1c32d9c205e1939507e46ebecc933eb1"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[5], addressList[0], "15000000000000000000", "75000000000000000", addressList[0], "0", "85", "28", "0xefcaa83cc8cd4d5ea213a98920e1284c52342e9b2ea2f03a35ad5877fdb612ff", "0x17db07fb9ef3c90976e7e1c77b0da79e1c32d9c205e1939507e46ebecc933eb1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541676936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0xdc540036cfc6706a5efa6401d4c5156320e39fe9032f2d6fd2aa54da8dabeffa"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "15000000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8994542693733741258" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "669753498021763457580" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: makeOffer( addressList[4], addressList[5], addressL... )", async function( ) {
		const txOriginal = {blockNumber: "6666050", timeStamp: "1541677000", hash: "0xcc9c37e9ae4190e097a843d5ad64b3303b3ba78fadfad9a60fe0ba567246bb95", nonce: "72", blockHash: "0xbbd75577c45f3f61d745bd1505ca39e55c17d3cb51f943e9af5d285c81aa432b", transactionIndex: "77", from: "0x1f8cdd31345faa00bbdf946fa257b7feb706b535", to: "0xba3ed686cc32ffa8664628b1e96d8022e40543de", value: "0", gas: "3000000", gasPrice: "18000000000", isError: "0", txreceipt_status: "1", input: "0x81d0f02e0000000000000000000000001ae3f54679d8b1c5bc7bd30154faffcc073e38a500000000000000000000000089d24a6b4ccb1b6faa2625fe562bdd9a232603590000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e4fbc69449f20000000000000000000000000000000000000000000000000000012807a561e8d000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000053000000000000000000000000000000000000000000000000000000000000001b638286dd50eaad4fe65936ae452bb502026ca249d407a8703390f1671a14b3320978af4abf1c6f885dd8b36603cc05d94715515231459d185823da4050d2d623", contractAddress: "", cumulativeGasUsed: "3339814", gasUsed: "196076", confirmations: "1053990"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_maker", value: addressList[4]}, {type: "address", name: "_offerAsset", value: addressList[5]}, {type: "address", name: "_wantAsset", value: addressList[0]}, {type: "uint256", name: "_offerAmount", value: "16500000000000000000"}, {type: "uint256", name: "_wantAmount", value: "83325000000000000"}, {type: "address", name: "_feeAsset", value: addressList[0]}, {type: "uint256", name: "_feeAmount", value: "0"}, {type: "uint64", name: "_nonce", value: "83"}, {type: "uint8", name: "_v", value: "27"}, {type: "bytes32", name: "_r", value: "0x638286dd50eaad4fe65936ae452bb502026ca249d407a8703390f1671a14b332"}, {type: "bytes32", name: "_s", value: "0x0978af4abf1c6f885dd8b36603cc05d94715515231459d185823da4050d2d623"}], name: "makeOffer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "makeOffer(address,address,address,uint256,uint256,address,uint256,uint64,uint8,bytes32,bytes32)" ]( addressList[4], addressList[5], addressList[0], "16500000000000000000", "83325000000000000", addressList[0], "0", "83", "27", "0x638286dd50eaad4fe65936ae452bb502026ca249d407a8703390f1671a14b332", "0x0978af4abf1c6f885dd8b36603cc05d94715515231459d185823da4050d2d623", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541677000 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "maker", type: "address"}, {indexed: true, name: "offerHash", type: "bytes32"}], name: "Make", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Make", events: [{name: "maker", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "offerHash", type: "bytes32", value: "0x777e4926538c6e781159fa915c358ca818658f4c603d6de561f9ba8c46aa3813"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "user", type: "address"}, {indexed: true, name: "token", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: true, name: "reason", type: "uint8"}], name: "BalanceDecrease", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceDecrease", events: [{name: "user", type: "address", value: "0x1ae3f54679d8b1c5bc7bd30154faffcc073e38a5"}, {name: "token", type: "address", value: "0x89d24a6b4ccb1b6faa2625fe562bdd9a23260359"}, {name: "amount", type: "uint256", value: "16500000000000000000"}, {name: "reason", type: "uint8", value: "2"}], address: "0xba3ed686cc32ffa8664628b1e96d8022e40543de"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "8994542693733741258" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "669753498021763457580" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
