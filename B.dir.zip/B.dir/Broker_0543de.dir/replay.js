var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "Broker"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0xba3Ed686cC32FfA8664628b1E96D8022e40543dE","0x1f8CDD31345fAa00bBdF946fa257b7Feb706b535","0x1aE3f54679d8b1c5Bc7bd30154faFfCC073E38a5","0x89d24A6b4CcB1B6fAA2625fE562bDD9a23260359","0x5B80F18d9c3F91aCbC20cEE093943845dF4d3513","0xd26114cd6EE289AccF82350c8d8487fedB8A0C07","0x0A7BB040669d7FeFa01fd7A856acEd117818608b","0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2","0x3EDa2E44d5C2c000267B7cff27018881FA283ae7","0x7c819b61b3A35AB718F66508d31E2CF3c25eB624","0x0F936dcE97A9A5c50bECC3F58A4842B4C607e722","0x5bE2f49D897A8c4603960C457ffb466527A28Eae","0x9D7863E2Ca6Cd42d9549bD3Bde900FB6687Be985"]
addressListOriginal.length = 15
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"coordinator","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"bytes32"}],"name":"announcedCancellations","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"cancelAnnounceDelay","outputs":[{"name":"","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"bytes32"}],"name":"offers","outputs":[{"name":"maker","type":"address"},{"name":"offerAsset","type":"address"},{"name":"wantAsset","type":"address"},{"name":"nonce","type":"uint64"},{"name":"offerAmount","type":"uint256"},{"name":"wantAmount","type":"uint256"},{"name":"availableAmount","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"operator","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"}],"name":"approvedSpenders","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"}],"name":"announcedWithdrawals","outputs":[{"name":"amount","type":"uint256"},{"name":"canWithdrawAt","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"whitelistedSpenders","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"bytes32"}],"name":"usedHashes","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"state","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"}],"name":"balances","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"pendingOwner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"withdrawAnnounceDelay","outputs":[{"name":"","type":"uint32"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":true,"name":"maker","type":"address"},{"indexed":true,"name":"offerHash","type":"bytes32"}],"name":"Make","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"filler","type":"address"},{"indexed":true,"name":"offerHash","type":"bytes32"},{"indexed":false,"name":"amountFilled","type":"uint256"},{"indexed":false,"name":"amountTaken","type":"uint256"},{"indexed":true,"name":"maker","type":"address"}],"name":"Fill","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"maker","type":"address"},{"indexed":true,"name":"offerHash","type":"bytes32"}],"name":"Cancel","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"user","type":"address"},{"indexed":true,"name":"token","type":"address"},{"indexed":false,"name":"amount","type":"uint256"},{"indexed":true,"name":"reason","type":"uint8"}],"name":"BalanceIncrease","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"user","type":"address"},{"indexed":true,"name":"token","type":"address"},{"indexed":false,"name":"amount","type":"uint256"},{"indexed":true,"name":"reason","type":"uint8"}],"name":"BalanceDecrease","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"user","type":"address"},{"indexed":true,"name":"token","type":"address"},{"indexed":false,"name":"amount","type":"uint256"},{"indexed":false,"name":"canWithdrawAt","type":"uint256"}],"name":"WithdrawAnnounce","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"user","type":"address"},{"indexed":true,"name":"offerHash","type":"bytes32"},{"indexed":false,"name":"canCancelAt","type":"uint256"}],"name":"CancelAnnounce","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"user","type":"address"},{"indexed":true,"name":"spender","type":"address"}],"name":"SpenderApprove","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"user","type":"address"},{"indexed":true,"name":"spender","type":"address"}],"name":"SpenderRescind","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"previousOwner","type":"address"}],"name":"OwnershipRenounced","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"previousOwner","type":"address"},{"indexed":true,"name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"}]
eventSignatureListOriginal = ["Make(address,bytes32)","Fill(address,bytes32,uint256,uint256,address)","Cancel(address,bytes32)","BalanceIncrease(address,address,uint256,uint8)","BalanceDecrease(address,address,uint256,uint8)","WithdrawAnnounce(address,address,uint256,uint256)","CancelAnnounce(address,bytes32,uint256)","SpenderApprove(address,address)","SpenderRescind(address,address)","OwnershipRenounced(address)","OwnershipTransferred(address,address)"]
topicListOriginal = ["0x1fa192562e5fbdce807069b18275dc0d672cacd78576602b47d21730975635a1","0xc587d1c5cbeb2dc01ea21c77c1c9232f39962a50cf2d6ce8d02dd09356e05b85","0xdb2b33dd6349739e1f3cd6dc90cf093af6a3dfb1838aced380528b0aefe6093c","0x4a52a947455663fbd6ddcc61a4d3a18a7e387c418de430ea8a191956cc53ec79","0xa3bbf8b09a42177fa9310281fb7f2fc8803d7c6df09a82093ea047cb6a222aa3","0xf8721275b3a50a37f692c7ba70c878e6cb3e44c23967756a3f712fe1ccc03779","0x5a4fb258356f60bc7302795f48ccdc1ca92d9bd3322ddd4c1c93cc1a27f72672","0x052c513b128416028f181f8d2c76eee59572b251fc379accba39533b40b3e86d","0x4524ec10cbd92d9466126e9af13eba34a4176c2cc2a74d0dee145087b67f5e04","0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820","0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"]
nBlocksOriginal = 50
fromBlockOriginal = 6665614
toBlockOriginal = 6666050
constructorPrototypeOriginal = {"inputs":[],"name":"Broker","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"6665614","timeStamp":"1541670909","hash":"0x247dfd5ba402a5d4f75dbdd5cb771dfcb74cac5ad85ef86c23a158e1c739c8d6","nonce":"30","blockHash":"0x1df3074d52f7617f011d93a1769560590ad91766da3cb90647133d1ade1aa320","transactionIndex":"18","from":"0x1f8cdd31345faa00bbdf946fa257b7feb706b535","to":0,"value":"0","gas":"6000000","gasPrice":"20000000000","isError":"0","txreceipt_status":"1","input":"0xcfcbb1ef","contractAddress":"0xba3ed686cc32ffa8664628b1e96d8022e40543de","cumulativeGasUsed":"4589059","gasUsed":"4092602","confirmations":"1054426"}
txOptions[0] = {"from":"0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1","to":0,"value":"0"}
txCall[0] = {"inputs":[],"name":"Broker","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
