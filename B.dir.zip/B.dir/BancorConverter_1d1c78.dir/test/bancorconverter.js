const BancorConverter = artifacts.require( "./BancorConverter.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BancorConverter" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xb626A5FacC4de1c813F5293Ec3bE31979f1D1c78", "0x009BB5e9fCF28E5E601B7D0e9e821da6365d0a9c", "0x1F573D6Fb3F13d689FF844B4cE37794d79a7FF1C", "0x97B15506eACCe136e8241A354C22E779b664b103", "0xc0829421C1d260BD3cB3E0F06cfE2D52db2cE315", "0xef1Efd77bFcE6A1D823BaaB65a6ed4144128a04f", "0xF46002C37af6fb078aE1833Fd447698A0C9012F7", "0xcfdf7971527B019Cb68816ce5E5f8Db21c126B46", "0x006BeA43Baa3f7A6f765F14f10A1a1b08334EF45", "0x03733D509f60a33f1B86856560256351f23e5531", "0xd7eB9DB184DA9f099B84e2F86b1da1Fe6b305B3d", "0x6810e776880C02933D47DB1b9fc05908e5386b96", "0xcAb007003d241d7e7e8c1092AB93911B669eBd0c", "0x0080Ef2e364721695608c066b8330B1488156060", "0x7cdec717125E5EeCc695AFb87b685EBF72B23f67", "0x438cCbD79f20C1e68b828211Ec2ba30c0Ec9c05A", "0x9345c50fb2158d40A09723a7B414DCa763Bf8543", "0x00a83e95a30765e4938Ad86370B25F941a3caa86", "0xbB131C1704046232C30067dEE33c8dDF39112f50", "0x22Fe28537f3F92Bbb90957E99421Eda7bdcBed30", "0x411f7A41DDcb3494D1592b84ebB692017428ea19", "0xe683C725f2C84C18Fe4B2745F3C29fA91d6dBD8f", "0x2e52F7F748Ee2125b483288CC23AbfC222C2Ec6A", "0xf10FF8EDa3e0840f254DF8D8699aF791522b748b", "0xd4992c7f1cFABcaCc3BAE173E7D5901382d5B7F7", "0x3C7C38501Ab5F1Bb88AB2aaCA5EE668410D4BaaB", "0xC0471a8A33274E8f87037b158fB395165B7Ee16A", "0x0DdD9DD9B77d3Ba97B2496e3590787DeF887a95b"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_reserveToken", type: "address"}], name: "getReserveBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_fromToken", type: "address"}, {name: "_toToken", type: "address"}, {name: "_amount", type: "uint256"}], name: "getReturn", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "extensions", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_amount", type: "uint256"}], name: "getConversionFeeAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "converterType", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newManager", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "manager", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "version", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "conversionFee", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_reserveToken", type: "address"}, {name: "_sellAmount", type: "uint256"}], name: "getSaleReturn", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getQuickBuyPathLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxConversionFee", outputs: [{name: "", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "reserveTokenCount", outputs: [{name: "", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_reserveToken", type: "address"}, {name: "_depositAmount", type: "uint256"}], name: "getPurchaseReturn", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "hasQuickBuyEtherToken", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getQuickBuyEtherToken", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "convertibleTokenCount", outputs: [{name: "", type: "uint16"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "conversionsEnabled", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "reserveTokens", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "reserves", outputs: [{name: "virtualBalance", type: "uint256"}, {name: "ratio", type: "uint32"}, {name: "isVirtualBalanceEnabled", type: "bool"}, {name: "isPurchaseEnabled", type: "bool"}, {name: "isSet", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "quickBuyPath", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenIndex", type: "uint16"}], name: "convertibleToken", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prevManager", type: "address"}, {indexed: false, name: "_newManager", type: "address"}], name: "ManagerUpdate", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prevOwner", type: "address"}, {indexed: false, name: "_newOwner", type: "address"}], name: "OwnerUpdate", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Conversion(address,address,address,uint256,uint256,uint256,uint256)", "ManagerUpdate(address,address)", "OwnerUpdate(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x431d62569d69247969ee24b65452f881ddcc12e42b7b71c324403449f870c0d3", "0xbe4cc281795971a471c980e842627a7f1ea3892ddfce8c5b6357cd2611c19732", "0x343765429aea5a34b3ff6a3785a98a5abb2597aca87bfbb58632c173d585373a"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4408563 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4412631 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}, {type: "address", name: "_extensions", value: 5}, {type: "uint32", name: "_maxConversionFee", value: "0"}, {type: "address", name: "_reserveToken", value: 6}, {type: "uint32", name: "_reserveRatio", value: "100000"}], name: "BancorConverter", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getReserveBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getReserveBalance(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_toToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_amount", value: random.range( maxRandom )}], name: "getReturn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getReturn(address,address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "extensions", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "extensions()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_amount", value: random.range( maxRandom )}], name: "getConversionFeeAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getConversionFeeAmount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "converterType", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "converterType()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newManager", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newManager()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "manager", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "manager()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "version", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "version()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "conversionFee", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "conversionFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_sellAmount", value: random.range( maxRandom )}], name: "getSaleReturn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getSaleReturn(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getQuickBuyPathLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getQuickBuyPathLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxConversionFee", outputs: [{name: "", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxConversionFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "reserveTokenCount", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserveTokenCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_depositAmount", value: random.range( maxRandom )}], name: "getPurchaseReturn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPurchaseReturn(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "hasQuickBuyEtherToken", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "hasQuickBuyEtherToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getQuickBuyEtherToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getQuickBuyEtherToken()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "convertibleTokenCount", outputs: [{name: "", type: "uint16"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "convertibleTokenCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "conversionsEnabled", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "conversionsEnabled()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "reserveTokens", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserveTokens(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "reserves", outputs: [{name: "virtualBalance", type: "uint256"}, {name: "ratio", type: "uint32"}, {name: "isVirtualBalanceEnabled", type: "bool"}, {name: "isPurchaseEnabled", type: "bool"}, {name: "isSet", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserves(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "quickBuyPath", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "quickBuyPath(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint16", name: "_tokenIndex", value: random.range( maxRandom )}], name: "convertibleToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "convertibleToken(uint16)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BancorConverter", function( accounts ) {

	it( "TEST: BancorConverter( addressList[4], addressList[5], \"0\", a... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4408563", timeStamp: "1508680067", hash: "0x3c4c71b28f2edabe5e6f10291e1b40d660c8bb077c3f6c9225ffcde52e0793b2", nonce: "386", blockHash: "0xb9e4facde54aa6e06c60bbab8c15882c065aff21575c413cae4894ce35dbd588", transactionIndex: "53", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: 0, value: "0", gas: "4256441", gasPrice: "2414201805", isError: "0", txreceipt_status: "1", input: "0xdc2711b90000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c00000000000000000000000097b15506eacce136e8241a354c22e779b664b1030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000000000000000000186a0", contractAddress: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", cumulativeGasUsed: "5166875", gasUsed: "3547034", confirmations: "3314022"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "address", name: "_extensions", value: addressList[5]}, {type: "uint32", name: "_maxConversionFee", value: "0"}, {type: "address", name: "_reserveToken", value: addressList[6]}, {type: "uint32", name: "_reserveRatio", value: "100000"}], name: "BancorConverter", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BancorConverter.new( addressList[4], addressList[5], "0", addressList[6], "100000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508680067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BancorConverter.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setQuickBuyPath( [addressList[6],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4408570", timeStamp: "1508680147", hash: "0x8a5d08937f3821750cee1f96ea22a38e3cbe1ec469f3fcc50ea92004c9c983a5", nonce: "387", blockHash: "0x06164b6443c81518b9e66c3ba5a7052739f8ce757eb1e50bf056a2a6c396e936", transactionIndex: "75", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "131226", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xd395ee0f00000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000003000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c", contractAddress: "", cumulativeGasUsed: "2950394", gasUsed: "109355", confirmations: "3314015"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[6],addressList[4],addressList[4]]}], name: "setQuickBuyPath", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setQuickBuyPath(address[])" ]( [addressList[6],addressList[4],addressList[4]], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1508680147 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: updateReserve( addressList[6], \"100000\", true, \"5105... )", async function( ) {
		const txOriginal = {blockNumber: "4408642", timeStamp: "1508681044", hash: "0xd0165b9d020b7830c3dd9e762fcc5e9bae6a625d4a0dee5d7d375da65d85b498", nonce: "391", blockHash: "0x2b0847d48690f1829f71ffbcdd7be395564d160499440637ee3c9cd0b07d2e20", transactionIndex: "33", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "68551", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xab5841f2000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce31500000000000000000000000000000000000000000000000000000000000186a00000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000acfc20bbea43b9a1887", contractAddress: "", cumulativeGasUsed: "855586", gasUsed: "57126", confirmations: "3313943"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_reserveToken", value: addressList[6]}, {type: "uint32", name: "_ratio", value: "100000"}, {type: "bool", name: "_enableVirtualBalance", value: true}, {type: "uint256", name: "_virtualBalance", value: "51056123331035015026823"}], name: "updateReserve", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateReserve(address,uint32,bool,uint256)" ]( addressList[6], "100000", true, "51056123331035015026823", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1508681044 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: acceptTokenOwnership(  )", async function( ) {
		const txOriginal = {blockNumber: "4408663", timeStamp: "1508681332", hash: "0x60c3ad6064a890c73e54e8a79aaf2aa4a397320fd4b1ca63c7bc249c35fc583c", nonce: "394", blockHash: "0x11e90a716e42bb1e8c61143f40015246dcee52bb544679083f6900c038489b37", transactionIndex: "80", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "44374", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x38a5e016", contractAddress: "", cumulativeGasUsed: "5021675", gasUsed: "21810", confirmations: "3313922"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "acceptTokenOwnership", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptTokenOwnership()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1508681332 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4408700", timeStamp: "1508681812", hash: "0xc4e38f91e49c949d82f167bf71997187684b49a7d88d5dfcd75d88aaddd4d811", nonce: "396", blockHash: "0xabb0c7412552527fedf7b57c6f6d91d55edf8204b31129171fd8263378702d7d", transactionIndex: "59", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "100000000000000000", gas: "289202", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2786554", gasUsed: "192814", confirmations: "3313885"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508681812 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "100000000000000000"}, {name: "_return", type: "uint256", value: "14865143976727090945"}, {name: "_currentPriceN", type: "uint256", value: "51056223331035015026823000000"}, {name: "_currentPriceD", type: "uint256", value: "7589574417920491714616794600000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"14720736779560310\" )", async function( ) {
		const txOriginal = {blockNumber: "4408725", timeStamp: "1508682347", hash: "0x219ee77c6c61ef84fef27b94e0abdcb04fbf4b87ad3123c517a4eee79b22ac5b", nonce: "11", blockHash: "0x81da673559fe921def2337c59928abc0f6168145a0d7cb7491dea0689a0533a5", transactionIndex: "27", from: "0xef1efd77bfce6a1d823baab65a6ed4144128a04f", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "100000000000000", gas: "341328", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x7758c4f800000000000000000000000000000000000000000000000000344c6e9e93e576", contractAddress: "", cumulativeGasUsed: "2139288", gasUsed: "192637", confirmations: "3313860"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "14720736779560310"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "14720736779560310", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508682347 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "100000000000000"}, {name: "_return", type: "uint256", value: "14865087847738364"}, {name: "_currentPriceN", type: "uint256", value: "51056387584035015026823000000"}, {name: "_currentPriceD", type: "uint256", value: "7589576859559298556702082300000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "104936640520067227" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setExtensions( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "4408731", timeStamp: "1508682447", hash: "0xc50d79a288dd2c77283b19422053f6b44b27ba3e5a0660357453b17a4dcd6bca", nonce: "398", blockHash: "0x989f73cb2c1e9be57ef49d71affa90664b77e24231b8ec8895d7e13d463eb09b", transactionIndex: "25", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "34807", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x2314aad6000000000000000000000000f46002c37af6fb078ae1833fd447698a0c9012f7", contractAddress: "", cumulativeGasUsed: "559845", gasUsed: "29006", confirmations: "3313854"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_extensions", value: addressList[8]}], name: "setExtensions", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExtensions(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508682447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4408731", timeStamp: "1508682447", hash: "0xe51b95012148aad0d8372033e3a0f7eb0921ad2a98839587f7367d96f96c91d7", nonce: "12", blockHash: "0x989f73cb2c1e9be57ef49d71affa90664b77e24231b8ec8895d7e13d463eb09b", transactionIndex: "107", from: "0xef1efd77bfce6a1d823baab65a6ed4144128a04f", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "331566", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000038d7ea4c68000000000000000000000000000000000000000000000000000000005590b4fb00000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "4017588", gasUsed: "192522", confirmations: "3313854"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "1000000000000000"}, {type: "uint256", name: "_minReturn", value: "5880000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "1000000000000000", "5880000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1508682447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "1000000000000000"}, {name: "_return", type: "uint256", value: "6727173347085"}, {name: "_currentPriceN", type: "uint256", value: "7589577050793984266846979400000"}, {name: "_currentPriceD", type: "uint256", value: "51056400448722363055968000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "104936640520067227" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[10],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4408731", timeStamp: "1508682447", hash: "0xcfad5539b820a58866d61cbf33fa0562aeff3169060552014285463026158c58", nonce: "26", blockHash: "0x989f73cb2c1e9be57ef49d71affa90664b77e24231b8ec8895d7e13d463eb09b", transactionIndex: "108", from: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "350931", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000032e24b7215f90000000000000000000000000000000000000000000000000000d9b0d78ea620a0c00000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000006bea43baa3f7a6f765f14f10a1a1b08334ef45000000000000000000000000006bea43baa3f7a6f765f14f10a1a1b08334ef45", contractAddress: "", cumulativeGasUsed: "4215580", gasUsed: "197992", confirmations: "3313854"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[10],addressList[10]]}, {type: "uint256", name: "_amount", value: "229161000000000000"}, {type: "uint256", name: "_minReturn", value: "980392156862745100"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[10],addressList[10]], "229161000000000000", "980392156862745100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508682447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "62900107407370360" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4408736", timeStamp: "1508682537", hash: "0x56dda1477cf0db13a3efaef4b63086b214760bca6df950dbc1fe600a7e2b6b02", nonce: "399", blockHash: "0x28266a81a4ceaf5d5c85566774067df23aa29aa603daf1c650b3a25386800930", transactionIndex: "52", from: "0x009bb5e9fcf28e5e601b7d0e9e821da6365d0a9c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "10000000000000000", gas: "288911", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3408547", gasUsed: "192576", confirmations: "3313849"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1508682537 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "10000000000000000"}, {name: "_return", type: "uint256", value: "1486508355741483964"}, {name: "_currentPriceN", type: "uint256", value: "51056408907110832742340000000"}, {name: "_currentPriceD", type: "uint256", value: "7589577176528633921398597300000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98659080000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[12],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4408820", timeStamp: "1508683566", hash: "0x5a94c253047571a71ae51d36c452d4e6af0454730e48d393b24b9081b5383065", nonce: "44", blockHash: "0x06817b8eaba766f9737facb117e5c27a17e25ae463dd70b0d51044c9c3aa1778", transactionIndex: "46", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "465751", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000005c14c39fc103c600000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96", contractAddress: "", cumulativeGasUsed: "2785147", gasUsed: "296827", confirmations: "3313765"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[12],addressList[13]]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}, {type: "uint256", name: "_minReturn", value: "25918528288785350"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[12],addressList[13]], "1000000000000000000", "25918528288785350", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508683566 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "4408825", timeStamp: "1508683620", hash: "0x30e20a1a6e6420ddc199a2e9f0005500b5e6b3a517097ab836fa522f1ae75f2b", nonce: "4207", blockHash: "0x67963abf0e93412f3821b1acd1d0867deeab0832512dfac847de0a0085711b04", transactionIndex: "1", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "150000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce3150000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "187421", gasUsed: "150000", confirmations: "3313760"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4408844", timeStamp: "1508683895", hash: "0xb1fe0b0ece1285fd4550927ef5cffedd95fca47cce97cb4e57862335927181a0", nonce: "4208", blockHash: "0x866c61457ed5f2a2a99a55672d37cc2f4787d687ff9b0e7b235b52d63b5f6bc2", transactionIndex: "14", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "1207072", gasUsed: "287859", confirmations: "3313741"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "1000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508683895 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4408851", timeStamp: "1508684073", hash: "0x67d7fc4e24553d6eca460c051fa793b9c457562f9b6a5e392726d12898d23707", nonce: "4209", blockHash: "0xee0b73c2417187d1d83867f549997136521528489bc3c0edd19c52c5ef3c12d5", transactionIndex: "99", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333348", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000008ac7230489e8000000000000000000000000000000000000000000000000000000ea36f73982f80000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "4566373", gasUsed: "194260", confirmations: "3313734"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "65925580000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "10000000000000000000", "65925580000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1508684073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "10000000000000000000"}, {name: "_return", type: "uint256", value: "67271697151358531"}, {name: "_currentPriceN", type: "uint256", value: "7589576095560017671210574400000"}, {name: "_currentPriceD", type: "uint256", value: "51056336188513959177173000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4408851", timeStamp: "1508684073", hash: "0x1b52685d330905743a30d5e9006577f64079d0e1804dbb030b02173aaa2ed273", nonce: "243", blockHash: "0xee0b73c2417187d1d83867f549997136521528489bc3c0edd19c52c5ef3c12d5", transactionIndex: "106", from: "0x0080ef2e364721695608c066b8330b1488156060", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "335112", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000001f1c1d8ffadd4b80000000000000000000000000000000000000000000000000003479d41ace529980000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "4907381", gasUsed: "195046", confirmations: "3313734"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "9182000000000000000000"}, {type: "uint256", name: "_minReturn", value: "60500585180000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "9182000000000000000000", "60500585180000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1508684073 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "9182000000000000000000"}, {name: "_return", type: "uint256", value: "61735218496166250347"}, {name: "_currentPriceN", type: "uint256", value: "7588657895560017671210574400000"}, {name: "_currentPriceD", type: "uint256", value: "50994600970017792926826000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "5773787128366354008" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4408862", timeStamp: "1508684241", hash: "0x047b10a299dfa23c2ebec604417cd595f68ae97c188624025c60808d6a3029dc", nonce: "4210", blockHash: "0xe3b1098aa176d4e17961817e2a82266512c69b29b7fd4280d9d0b6c30cbe61a9", transactionIndex: "42", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333374", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000126e72a69a50d000000000000000000000000000000000000000000000000000001f102542d3864d80000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "1900566", gasUsed: "194286", confirmations: "3313723"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "5440000000000000000000"}, {type: "uint256", name: "_minReturn", value: "35813279740000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "5440000000000000000000", "35813279740000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1508684241 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "5440000000000000000000"}, {name: "_return", type: "uint256", value: "36544163832769957311"}, {name: "_currentPriceN", type: "uint256", value: "7588113895560017671210574400000"}, {name: "_currentPriceD", type: "uint256", value: "50958056806185022969515000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[10],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4408895", timeStamp: "1508684743", hash: "0x7d53b5e961711e22592e9c58a3783617ae9aedb9770b1d3125f76f1a21c63d30", nonce: "13", blockHash: "0x50b3dc80c4f4230a64b3c5d3d6ec832ffb71b39b5240153203d13e8d403c4344", transactionIndex: "151", from: "0xef1efd77bfce6a1d823baab65a6ed4144128a04f", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "371340", gasPrice: "1609467870", isError: "0", txreceipt_status: "1", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000032e2688caa9b0000000000000000000000000000000000000000000000000000d9b0d78ea620a7000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000006bea43baa3f7a6f765f14f10a1a1b08334ef45000000000000000000000000006bea43baa3f7a6f765f14f10a1a1b08334ef45", contractAddress: "", cumulativeGasUsed: "5616527", gasUsed: "217163", confirmations: "3313690"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[10],addressList[10]]}, {type: "uint256", name: "_amount", value: "229163000000000000"}, {type: "uint256", name: "_minReturn", value: "980392156862745200"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[10],addressList[10]], "229163000000000000", "980392156862745200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1508684743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "104936640520067227" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[10],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4408897", timeStamp: "1508684784", hash: "0x64d1310ddf722a68ffc1af619ed3f75ce49432b0ba7c159e15d6678f51fd6b1d", nonce: "30", blockHash: "0xec689cf5bf7abd057baaf4a73050641ef3ca85e807ebe0fc3df55d8bc374f56f", transactionIndex: "91", from: "0xcfdf7971527b019cb68816ce5e5f8db21c126b46", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "354660", gasPrice: "1609467870", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000cb89b0bff4bd000000000000000000000000000000000000000000000000000366c35e3a988276800000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000006bea43baa3f7a6f765f14f10a1a1b08334ef45000000000000000000000000006bea43baa3f7a6f765f14f10a1a1b08334ef45", contractAddress: "", cumulativeGasUsed: "3271620", gasUsed: "201069", confirmations: "3313688"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[10],addressList[10]]}, {type: "uint256", name: "_amount", value: "916653000000000000"}, {type: "uint256", name: "_minReturn", value: "3921568627450980200"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[10],addressList[10]], "916653000000000000", "3921568627450980200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1508684784 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "62900107407370360" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4408930", timeStamp: "1508685307", hash: "0x6389898fde1752d16f75cf45dc31dd963d7f65028fed5429140cb35f2d0aad8b", nonce: "4211", blockHash: "0xd4ea55e174e2cca6afb78bf0ed769d600b2d9c9729bc425c00b82450b231e3f5", transactionIndex: "12", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "300000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "855677", gasUsed: "287859", confirmations: "3313655"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "10000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "10000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1508685307 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[12],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4409337", timeStamp: "1508690954", hash: "0xc10483cd1e5201b9aeba9bfc01d613ad61d54af674f1abf95a1f7d910ad63b8a", nonce: "50", blockHash: "0xec2253b6dd542c769f48e972841458930de6d2c8417e2fdc6bf5e8e3cd4fff11", transactionIndex: "27", from: "0x03733d509f60a33f1b86856560256351f23e5531", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "466629", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000016345785d8a000000000000000000000000000000000000000000000000000000093552421d560d00000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000d7eb9db184da9f099b84e2f86b1da1fe6b305b3d0000000000000000000000006810e776880c02933d47db1b9fc05908e5386b96", contractAddress: "", cumulativeGasUsed: "1608038", gasUsed: "297705", confirmations: "3313248"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[12],addressList[13]]}, {type: "uint256", name: "_amount", value: "100000000000000000"}, {type: "uint256", name: "_minReturn", value: "2591902203205133"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[12],addressList[13]], "100000000000000000", "2591902203205133", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1508690954 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4409583", timeStamp: "1508694573", hash: "0x24da1518e12c6f4b8cdc80d744f2aa31466bf05bc241244216e552ce9b2353cf", nonce: "1", blockHash: "0x12c0beed3edd33f94074d3af5e44eb7a6f8f200c1ab3ca33a8d21d18195aeb9f", transactionIndex: "63", from: "0x7cdec717125e5eecc695afb87b685ebf72b23f67", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "585022281174730000", gas: "21000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2565983", gasUsed: "21000", confirmations: "3313002"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "585022281174730000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "13916909394880000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4409640", timeStamp: "1508695335", hash: "0x7fcb4d60adb666d66b349fdb0abfe6abbd96df7b4828ad1f8ec16ed1baa88a83", nonce: "2", blockHash: "0x9f69f38b6ea7aeeb9c8434b0786ca79e34526da3583aef7cc9b8dcea02c6a373", transactionIndex: "34", from: "0x7cdec717125e5eecc695afb87b685ebf72b23f67", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "584917281174730000", gas: "21000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1789254", gasUsed: "21000", confirmations: "3312945"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "584917281174730000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "13916909394880000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4409646", timeStamp: "1508695432", hash: "0x81033f16166ca137137f6d8ba189d3c8ade862eecb22918ff8af702dc9e90373", nonce: "3", blockHash: "0x4380a94e166f36dca004fa967309d7981e7fd33f51218aa046150d0d5f4403ca", transactionIndex: "43", from: "0x7cdec717125e5eecc695afb87b685ebf72b23f67", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "584833281174730000", gas: "21000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1832496", gasUsed: "21000", confirmations: "3312939"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "584833281174730000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "13916909394880000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4409665", timeStamp: "1508695717", hash: "0x5d54f286aa5344aa16045e4c0c18ef3685e614bb07c4b50b9f7569aa12300db9", nonce: "122", blockHash: "0x4ee361c3f335b2525d5c107a500ae5139f89a7cdf71173926ac071d95800b262", transactionIndex: "10", from: "0x438ccbd79f20c1e68b828211ec2ba30c0ec9c05a", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "332908", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000005dbe5bddf7771800000000000000000000000000000000000000000000000000009dec87145dba79c00000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "486789", gasUsed: "193820", confirmations: "3312920"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "108079000000000000000"}, {type: "uint256", name: "_minReturn", value: "711226179999999900"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "108079000000000000000", "711226179999999900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1508695717 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "108079000000000000000"}, {name: "_return", type: "uint256", value: "725741004731572466"}, {name: "_currentPriceN", type: "uint256", value: "7588033412064029658660655700000"}, {name: "_currentPriceD", type: "uint256", value: "50952652186709148458922000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "520494769731246755" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4409691", timeStamp: "1508696318", hash: "0x5b2bb514b03336239c5f1e5eefff54551442a8b49d4a1ac0842fddb8a3bdb1d1", nonce: "4", blockHash: "0x34b106a7798e1740c8481bb08948f0891c1f5705e1a0961904d5b2064d72cf33", transactionIndex: "60", from: "0x7cdec717125e5eecc695afb87b685ebf72b23f67", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "584749281174730000", gas: "21000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2369374", gasUsed: "21000", confirmations: "3312894"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "584749281174730000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "13916909394880000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4409980", timeStamp: "1508700584", hash: "0xc700cecdce1e8170d848bbea1dc474b601d1fcc0632f5036e758b704d717e00b", nonce: "4212", blockHash: "0xea4cda0201e2065318a4d4bf1def64f3255cfba169e2bf976ab55b01ee33de14", transactionIndex: "39", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333890", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000002c2084ef3e3ff800000000000000000000000000000000000000000000000000004a557e516c35f80000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "1747367", gasUsed: "194802", confirmations: "3312605"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "814000000000000000000"}, {type: "uint256", name: "_minReturn", value: "5356326220000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "814000000000000000000", "5356326220000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1508700584 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "814000000000000000000"}, {name: "_return", type: "uint256", value: "5465639715139009332"}, {name: "_currentPriceN", type: "uint256", value: "7587952012064029658660655700000"}, {name: "_currentPriceD", type: "uint256", value: "50947186546994009449590000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410003", timeStamp: "1508700919", hash: "0x37154d8c58084f69d6aeda4cd226f5758c7937ffab637bb5b3aca20667bf032c", nonce: "246", blockHash: "0x8326650e7ec4fee9629703a1347edf2eee2743709e19bf0554cb8e08963d9d79", transactionIndex: "76", from: "0x0080ef2e364721695608c066b8330b1488156060", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333940", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000039076eca43def00000000000000000000000000000000000000000000000000000600eada94ee8f80000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "5406876", gasUsed: "194852", confirmations: "3312582"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "1052000000000000000000"}, {type: "uint256", name: "_minReturn", value: "6921660620000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "1052000000000000000000", "6921660620000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1508700919 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "1052000000000000000000"}, {name: "_return", type: "uint256", value: "7062919809061347198"}, {name: "_currentPriceN", type: "uint256", value: "7587846812064029658660655700000"}, {name: "_currentPriceD", type: "uint256", value: "50940123627184948102392000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "5773787128366354008" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410033", timeStamp: "1508701380", hash: "0x347ae7f4847e6c505a7d7f797447c154acc82f6d7b7c43ec4fe5317fc7c5ed57", nonce: "4214", blockHash: "0x3df5da8f06c344b0b4bbd93ef35d421178a248cdd1537ef01ffc48fc9e30c75a", transactionIndex: "18", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333128", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000088035e9ebf8f140000000000000000000000000000000000000000000000000000e50bebd51e67e00000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "1149996", gasUsed: "194040", confirmations: "3312552"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "2509000000000000000000"}, {type: "uint256", name: "_minReturn", value: "16504544560000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "2509000000000000000000", "16504544560000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1508701380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "2509000000000000000000"}, {name: "_return", type: "uint256", value: "16841372452742582553"}, {name: "_currentPriceN", type: "uint256", value: "7587595912064029658660655700000"}, {name: "_currentPriceD", type: "uint256", value: "50923282254732205519839000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410107", timeStamp: "1508702378", hash: "0x7982786089a110d8f1e182e9477a6ae41e665dcd025265dbee87d399eaf6fd67", nonce: "734", blockHash: "0xaaacd603ae01390403b10972c9b936640bf831fc14d1e6408e22dc020c96a2ef", transactionIndex: "32", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "300000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "2112061", gasUsed: "193592", confirmations: "3312478"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "1000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "1000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1508702378 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}, {name: "_return", type: "uint256", value: "6711385243070525"}, {name: "_currentPriceN", type: "uint256", value: "7587595812064029658660655700000"}, {name: "_currentPriceD", type: "uint256", value: "50923275543346962449314000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410113", timeStamp: "1508702448", hash: "0x33788ce67ddc9a60ada55f5fa2c2353f6f6a4a0a14f0c15281dabfee47239612", nonce: "735", blockHash: "0xda38e5db0e9baa7a0c2f99afac7eba54d1fc40733debd4bc8598169475e2b397", transactionIndex: "101", from: "0x9345c50fb2158d40a09723a7b414dca763bf8543", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "300000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000b44d85b218c5380000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "4076659", gasUsed: "194186", confirmations: "3312472"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "3326000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "3326000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1508702448 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "3326000000000000000000"}, {name: "_return", type: "uint256", value: "22317663344266595169"}, {name: "_currentPriceN", type: "uint256", value: "7587263212064029658660655700000"}, {name: "_currentPriceD", type: "uint256", value: "50900957880002695854145000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "42338368165519306" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410256", timeStamp: "1508704312", hash: "0xe8398b48d9525ae6923d13afc5224dcc35392d57ce2332b8204e1aa453d7a996", nonce: "247", blockHash: "0x4c18b24f1e846c98dde629953ab287db29df01eb22ad9629ce599fa3dc2c7cd2", transactionIndex: "56", from: "0x0080ef2e364721695608c066b8330b1488156060", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "334300", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000c7015bea355afc00000000000000000000000000000000000000000000000000014ee13af472c86c4800000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "2974852", gasUsed: "195212", confirmations: "3312329"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "3671000000000000000000"}, {type: "uint256", name: "_minReturn", value: "24130633099999997000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "3671000000000000000000", "24130633099999997000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1508704312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "3671000000000000000000"}, {name: "_return", type: "uint256", value: "24623095158587926959"}, {name: "_currentPriceN", type: "uint256", value: "7586919424622545315656607400000"}, {name: "_currentPriceD", type: "uint256", value: "50877898784844107927186000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "5773787128366354008" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410257", timeStamp: "1508704328", hash: "0xbdd286b302ee5527c411016511f21ea7f575715ee362f433b3f57121c6ccadf0", nonce: "911", blockHash: "0x20c634e83a4376934a04d608e535fb9ec3674a6aa794247c7e04feb187d936f8", transactionIndex: "46", from: "0x00a83e95a30765e4938ad86370b25f941a3caa86", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "334598", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000fb516c9d6b56f00000000000000000000000000000000000000000000000000001a6e2c5f3e1e80fa000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "1959154", gasUsed: "196024", confirmations: "3312328"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "4636000000000000000000"}, {type: "uint256", name: "_minReturn", value: "30472135680000004000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "4636000000000000000000", "30472135680000004000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1508704328 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "4636000000000000000000"}, {name: "_return", type: "uint256", value: "31080479204976333171"}, {name: "_currentPriceN", type: "uint256", value: "7586455824622545315656607400000"}, {name: "_currentPriceD", type: "uint256", value: "50846818305639131594015000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "17881413999999999" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410288", timeStamp: "1508704709", hash: "0x33ac15fa962b17ae6f265990623a406e3f311698b45dc95b1598cafeffd9d5a5", nonce: "2124", blockHash: "0x3d88b67fa108a2f7dcbd1d19ddb5e6cd35a29f4c0a9fbacd3429fe48b00785ef", transactionIndex: "13", from: "0xbb131c1704046232c30067dee33c8ddf39112f50", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "233866", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000010263d198adfd692400000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "694765", gasUsed: "179778", confirmations: "3312297"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "4766452668970000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "4766452668970000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1508704709 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "4766452668970000000000"}, {name: "_return", type: "uint256", value: "31937237655191209564"}, {name: "_currentPriceN", type: "uint256", value: "7585979179355648315656607400000"}, {name: "_currentPriceD", type: "uint256", value: "50814881067983940384451000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "145715000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"499881... )", async function( ) {
		const txOriginal = {blockNumber: "4410302", timeStamp: "1508704977", hash: "0x8ec1fded4666b481f6dfbbb0de4484fc169ddd3267ae373b7f2efb5e589e2e46", nonce: "17", blockHash: "0xcc9d44cc91154cfc671e314f98ce7cb3073da3bf0c059341a4cd3c77248a5bf3", transactionIndex: "65", from: "0x22fe28537f3f92bbb90957e99421eda7bdcbed30", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "150000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000002b5b98216c4a0e0a00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2060448", gasUsed: "150000", confirmations: "3312283"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "49988128573275300000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "553775301786151427" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410304", timeStamp: "1508705012", hash: "0x1ea1880e38b0269fe8348dc77c9cf321dbc5098fb764711ae6f13bee5f2080fd", nonce: "249", blockHash: "0x9c4d3bba5bc80fcb1a5274d581c5e9a756cee2a149c8a77532d33a59b2ceaddd", transactionIndex: "60", from: "0x0080ef2e364721695608c066b8330b1488156060", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333424", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000fd0d8373e043700000000000000000000000000000000000000000000000000001a924e4712be7b80000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "2272355", gasUsed: "194336", confirmations: "3312281"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "4668000000000000000000"}, {type: "uint256", name: "_minReturn", value: "30634861740000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "4668000000000000000000", "30634861740000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1508705012 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "4668000000000000000000"}, {name: "_return", type: "uint256", value: "31260063720282213167"}, {name: "_currentPriceN", type: "uint256", value: "7585512379355648315656607400000"}, {name: "_currentPriceD", type: "uint256", value: "50783621004263658171284000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "5773787128366354008" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410305", timeStamp: "1508705025", hash: "0x84ee84a672836b3d121eefaa8895735426e98a4b4c7a50be46164f113cb37840", nonce: "4216", blockHash: "0x60ecee0e9a4c944437bfb11f72009458b0b439a42ba83a50027bd540c112ca8d", transactionIndex: "30", from: "0xcab007003d241d7e7e8c1092ab93911b669ebd0c", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333192", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000004625db80181b78000000000000000000000000000000000000000000000000000075e0551848389fd000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "1154371", gasUsed: "195214", confirmations: "3312280"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "1294000000000000000000"}, {type: "uint256", name: "_minReturn", value: "8493882460000002000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "1294000000000000000000", "8493882460000002000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1508705025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "1294000000000000000000"}, {name: "_return", type: "uint256", value: "8662428851645259455"}, {name: "_currentPriceN", type: "uint256", value: "7585382979355648315656607400000"}, {name: "_currentPriceD", type: "uint256", value: "50774958575412012911829000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "67447640899027256550" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410334", timeStamp: "1508705402", hash: "0x24f1eb8b01bda95bb907402fb72245a459457c785648f01b71c46c44dda93df3", nonce: "347", blockHash: "0x822a843f1a06d07234c9490447488d721bab1f8e5e1ca2ec3fe206a778082209", transactionIndex: "30", from: "0x411f7a41ddcb3494d1592b84ebb692017428ea19", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000a2a15d09519be00000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "1527931", gasUsed: "195694", confirmations: "3312251"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "3000000000000000000000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "3000000000000000000000", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1508705402 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "3000000000000000000000"}, {name: "_return", type: "uint256", value: "20077795564357222235"}, {name: "_currentPriceN", type: "uint256", value: "7585082979355648315656607400000"}, {name: "_currentPriceD", type: "uint256", value: "50754880779847655689594000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"490196078431372540000\" )", async function( ) {
		const txOriginal = {blockNumber: "4410367", timeStamp: "1508705786", hash: "0x07f612b9d683d9bdc95b39dd9c887b997d42d90c6efc6e9d034d7d715b880b48", nonce: "0", blockHash: "0x63e56e3fb4bff941a136831a768066f43d6f0f5f9f9303b2bdc41047a19297bd", transactionIndex: "76", from: "0xe683c725f2c84c18fe4b2745f3c29fa91d6dbd8f", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "3345802000000000000", gas: "357738", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x7758c4f800000000000000000000000000000000000000000000001a92d65029c77b7860", contractAddress: "", cumulativeGasUsed: "4160953", gasUsed: "209135", confirmations: "3312218"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "3345802000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "490196078431372540000"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "490196078431372540000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1508705786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "3345802000000000000"}, {name: "_return", type: "uint256", value: "499999854525064641291"}, {name: "_currentPriceN", type: "uint256", value: "50758226581847655689594000000"}, {name: "_currentPriceD", type: "uint256", value: "7585132979341100822120736500000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "2187093459999981000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"74708742545307440000\" )", async function( ) {
		const txOriginal = {blockNumber: "4410417", timeStamp: "1508706642", hash: "0x267d9333f19374844acb365df48ecdb8e0e0c9681f518cdc8a5e4ef39cb6a3cf", nonce: "1", blockHash: "0x4694fb2a5fa5385fc3e782c8b16d08e49237c7602b120bc30e45a9bd479d5d48", transactionIndex: "72", from: "0x2e52f7f748ee2125b483288cc23abfc222c2ec6a", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "500000000000000000", gas: "358092", gasPrice: "5432836096", isError: "0", txreceipt_status: "1", input: "0x7758c4f80000000000000000000000000000000000000000000000040ccac58565299380", contractAddress: "", cumulativeGasUsed: "2096898", gasUsed: "209483", confirmations: "3312168"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "74708742545307440000"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "74708742545307440000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1508706642 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "500000000000000000"}, {name: "_return", type: "uint256", value: "74717931132816837418"}, {name: "_currentPriceN", type: "uint256", value: "50758726581847655689594000000"}, {name: "_currentPriceD", type: "uint256", value: "7585140451134214103804478300000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "83779584033220592" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4410471", timeStamp: "1508707401", hash: "0xc7e8933da36bf4249a7739196eebf385882b987568283063abe6792e2f287a75", nonce: "6", blockHash: "0xa637903591492dc2955975593dd85b3e79a652b976db7468d198b429a3c02c3d", transactionIndex: "18", from: "0xf10ff8eda3e0840f254df8d8699af791522b748b", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333206", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000006c244c9ec1eed80000000000000000000000000000000000000000000000000000b58d88ec0d6bf9c00000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "906817", gasUsed: "194118", confirmations: "3312114"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "124679000000000000000"}, {type: "uint256", name: "_minReturn", value: "817641439999999900"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "124679000000000000000", "817641439999999900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1508707401 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "124679000000000000000"}, {name: "_return", type: "uint256", value: "834328711729993163"}, {name: "_currentPriceN", type: "uint256", value: "7585127983234214103804478300000"}, {name: "_currentPriceD", type: "uint256", value: "50757892253135925696431000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "12361057729993163" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: change( addressList[4], addressList[6], \"499881... )", async function( ) {
		const txOriginal = {blockNumber: "4410477", timeStamp: "1508707487", hash: "0x125e9566dd4b4bfb5895a48d6544d29fda636187663f9f016db2237849344374", nonce: "18", blockHash: "0xf0de7a65c196818931645e5699f74701bd9132d741fdafbd9cae9cb11b04f02a", transactionIndex: "42", from: "0x22fe28537f3f92bbb90957e99421eda7bdcbed30", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "300000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0x5e5144eb0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315000000000000000000000000000000000000000000000002b5b98216c4a0e0a00000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1693685", gasUsed: "300000", confirmations: "3312108"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_fromToken", value: addressList[4]}, {type: "address", name: "_toToken", value: addressList[6]}, {type: "uint256", name: "_amount", value: "49988128573275300000"}, {type: "uint256", name: "_minReturn", value: "1"}], name: "change", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "553775301786151427" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"137254901960784300000\" )", async function( ) {
		const txOriginal = {blockNumber: "4411205", timeStamp: "1508717303", hash: "0x4cc048680316ce68546c79f60b2fa46ee9c81b2d1be6ea5bf118a8e1a6478acb", nonce: "4", blockHash: "0xe637d18e9270426a5611546fc2ba9f5ce8a15bc84da95acb76dfad74122836c0", transactionIndex: "58", from: "0xd4992c7f1cfabcacc3bae173e7d5901382d5b7f7", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "937016000000000000", gas: "357687", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x7758c4f800000000000000000000000000000000000000000000000770cb5e202d9d47e0", contractAddress: "", cumulativeGasUsed: "2205395", gasUsed: "209085", confirmations: "3311380"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "937016000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "137254901960784300000"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "137254901960784300000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1508717303 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "937016000000000000"}, {name: "_return", type: "uint256", value: "139999942695520428643"}, {name: "_currentPriceN", type: "uint256", value: "50768553532135925696431000000"}, {name: "_currentPriceD", type: "uint256", value: "7585287287570227722088106500000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[10],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4411283", timeStamp: "1508718345", hash: "0x2e4e41a503f3287031fa7e1dba14e6ba0842815242584443d0c9ae8d02a1af2a", nonce: "5", blockHash: "0xa2dd3aec083af541ae00b725b8cf55a4d9f6e67bdc8263de293637c898cca8d9", transactionIndex: "23", from: "0xd4992c7f1cfabcacc3bae173e7d5901382d5b7f7", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "355702", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c7200000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000022b1c8c1227a000000000000000000000000000000000000000000000000000093e7d36c9cf916fb000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000006bea43baa3f7a6f765f14f10a1a1b08334ef45000000000000000000000000006bea43baa3f7a6f765f14f10a1a1b08334ef45", contractAddress: "", cumulativeGasUsed: "1259674", gasUsed: "201763", confirmations: "3311302"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[10],addressList[10]]}, {type: "uint256", name: "_amount", value: "40000000000000000000"}, {type: "uint256", name: "_minReturn", value: "170523512106225070000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[10],addressList[10]], "40000000000000000000", "170523512106225070000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1508718345 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4411914", timeStamp: "1508727309", hash: "0x75bcd4f8b86e00ad4bf0a63bdc4885ba2de643bb0807f54c10698bd2d670e68b", nonce: "31", blockHash: "0xf5b00ca6f83117668d75c993c8e6f62db75f79a6b9a061f553d613f1b62d8ccb", transactionIndex: "81", from: "0x3c7c38501ab5f1bb88ab2aaca5ee668410d4baab", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333424", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000340aad21b3b70000000000000000000000000000000000000000000000000000005762a2f47ec5fd800000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "3500254", gasUsed: "194336", confirmations: "3310671"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "60000000000000000000"}, {type: "uint256", name: "_minReturn", value: "393548399999999960"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "60000000000000000000", "393548399999999960", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1508727309 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "60000000000000000000"}, {name: "_return", type: "uint256", value: "401580355991838615"}, {name: "_currentPriceN", type: "uint256", value: "7585281287570227722088106500000"}, {name: "_currentPriceD", type: "uint256", value: "50768151951779933857816000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "758186401081145" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4411944", timeStamp: "1508727614", hash: "0x355dd8999742e7f1a37bdfd89c305f18fcca4d3625fddc269c637692779bb067", nonce: "7", blockHash: "0x4170183cd7280acbaeca370a722b33717eb460bf41eced4e24ed45a552f9d9f1", transactionIndex: "18", from: "0xc0471a8a33274e8f87037b158fb395165b7ee16a", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "100000000000000000", gas: "120000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "585517", gasUsed: "118587", confirmations: "3310641"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1508727614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "155380000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4411997", timeStamp: "1508728280", hash: "0xdd14f013f45c4da04954012b83e648a7c4bb3691ce2d55d26abd107a839ba959", nonce: "8", blockHash: "0xf1b75c9d96be6f79bdc9c6766be395d0b8ba1857b733992c1629ce1a6741e2bf", transactionIndex: "47", from: "0xc0471a8a33274e8f87037b158fb395165b7ee16a", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "100000000000000000", gas: "400000", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "2451739", gasUsed: "389905", confirmations: "3310588"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1508728280 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "155380000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4411999", timeStamp: "1508728349", hash: "0xc049588721301db9b6d312a1185c85c006a6780fefe078fe47e4419d57fb7348", nonce: "251", blockHash: "0x29c2e8c41472869c0a1ced2e9f0111fe4832a6e3512947ec201f8d377f70b19e", transactionIndex: "127", from: "0x0080ef2e364721695608c066b8330b1488156060", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333244", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c720000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000048cdde787b259c00000000000000000000000000000000000000000000000000007a3d022d5935300000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "6110138", gasUsed: "194156", confirmations: "3310586"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "1343000000000000000000"}, {type: "uint256", name: "_minReturn", value: "8808198840000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "1343000000000000000000", "8808198840000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1508728349 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "1343000000000000000000"}, {name: "_return", type: "uint256", value: "8987958842569647324"}, {name: "_currentPriceN", type: "uint256", value: "7585146987570227722088106500000"}, {name: "_currentPriceD", type: "uint256", value: "50759163992937364210492000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "5773787128366354008" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: quickChange( [addressList[4],addressList[4],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4412302", timeStamp: "1508732460", hash: "0x1091730739f10cbd6bff5e51d133208a7695769d62f95f65d4f48f1f194ade02", nonce: "41", blockHash: "0x3522617f847935c84867da5d22ae6455756285d40cdd1eb2e9c1cf6e5faddccd", transactionIndex: "36", from: "0x0ddd9dd9b77d3ba97b2496e3590787def887a95b", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "0", gas: "333772", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xa93d7c72000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000002a0c3b891bb66dc0000000000000000000000000000000000000000000000000004696e441b3acb00000000000000000000000000000000000000000000000000000000000000000030000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c0000000000000000000000001f573d6fb3f13d689ff844b4ce37794d79a7ff1c000000000000000000000000c0829421c1d260bd3cb3e0f06cfe2d52db2ce315", contractAddress: "", cumulativeGasUsed: "3173435", gasUsed: "194684", confirmations: "3310283"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_path", value: [addressList[4],addressList[4],addressList[6]]}, {type: "uint256", name: "_amount", value: "775644700000000000000"}, {type: "uint256", name: "_minReturn", value: "5086503800000000000"}], name: "quickChange", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickChange(address[],uint256,uint256)" ]( [addressList[4],addressList[4],addressList[6]], "775644700000000000000", "5086503800000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1508732460 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_toToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "775644700000000000000"}, {name: "_return", type: "uint256", value: "5190310079907021209"}, {name: "_currentPriceN", type: "uint256", value: "7585069423100227722088106500000"}, {name: "_currentPriceD", type: "uint256", value: "50753973682857457189283000000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "122804337773750680" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: quickBuy( \"8054532662132321000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4412394", timeStamp: "1508733752", hash: "0x6c7c05f84c61d4e4dec241a819f76166300ba20cbeba8a579d66ad79018116a6", nonce: "252", blockHash: "0xead21f5e56e398549629b9821627fdf1df75fadd1f8181748203a3ba94a82382", transactionIndex: "40", from: "0x0080ef2e364721695608c066b8330b1488156060", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "55000000000000000000", gas: "342794", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x7758c4f80000000000000000000000000000000000000000000001b4a3185d7762639a40", contractAddress: "", cumulativeGasUsed: "2344165", gasUsed: "194663", confirmations: "3310191"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "55000000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minReturn", value: "8054532662132321000000"}], name: "quickBuy", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "quickBuy(uint256)" ]( "8054532662132321000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1508733752 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "55000000000000000000"}, {name: "_return", type: "uint256", value: "8215623166332921551298"}, {name: "_currentPriceN", type: "uint256", value: "50808973682857457189283000000"}, {name: "_currentPriceD", type: "uint256", value: "7585890985416861014243236300000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "5773787128366354008" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4412631", timeStamp: "1508737289", hash: "0xaf011121b2595252ccbb5a5527b74bf4d6061187c8d4106210065683408c6dc9", nonce: "350", blockHash: "0xbd6a7ac262e4ac7e48fd965d61498e8b75044d781d73f0770b10f3abc101f76e", transactionIndex: "90", from: "0x411f7a41ddcb3494d1592b84ebb692017428ea19", to: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78", value: "1000000000000000000", gas: "300000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2745682", gasUsed: "207460", confirmations: "3309954"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1508737289 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_fromToken", type: "address"}, {indexed: true, name: "_toToken", type: "address"}, {indexed: true, name: "_trader", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_return", type: "uint256"}, {indexed: false, name: "_currentPriceN", type: "uint256"}, {indexed: false, name: "_currentPriceD", type: "uint256"}], name: "Conversion", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Conversion", events: [{name: "_fromToken", type: "address", value: "0xc0829421c1d260bd3cb3e0f06cfe2d52db2ce315"}, {name: "_toToken", type: "address", value: "0x1f573d6fb3f13d689ff844b4ce37794d79a7ff1c"}, {name: "_trader", type: "address", value: "0xf87a7ec94884f44d9de33d36b73f42c7c0dd38b1"}, {name: "_amount", type: "uint256", value: "1000000000000000000"}, {name: "_return", type: "uint256", value: "149300866567763870550"}, {name: "_currentPriceN", type: "uint256", value: "50809973682857457189283000000"}, {name: "_currentPriceD", type: "uint256", value: "7585905915503517790630291300000"}], address: "0xb626a5facc4de1c813f5293ec3be31979f1d1c78"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
