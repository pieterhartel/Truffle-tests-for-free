const BsToken_SNOV = artifacts.require( "./BsToken_SNOV.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BsToken_SNOV" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xBDC5bAC39Dbe132B1E030e898aE3830017D7d969", "0xDaE3f1D824127754Aca9Eb5E5bFBAC22d8A04A52", "0x7A41258eA90F289684394bCD4562E62e774AB01b", "0x48B00b2FE26932aDaC11c0A0801d8FD6bdD4e0BD", "0x123e084fc361A878AEF966DF784f6b3774084028", "0x5B891817Eb3ae3beb01c28a0eBf84657Be49E647", "0x3aDB710a29470b8D957436A8A86f31F949758fC5", "0xfdB82DdBB1c5E875B62300c1A18AaC5EE421DaC8", "0x9F9f6768FCd665B0AE17F02601A24A60D1eb5DaB", "0x351Fc4e8987a6170FB6bAA38556822d79Eb438E9", "0xd82F335a5d636168d1B0B468eC9223Ba7fb40A14", "0x08c1BAa2aEeDC19F535088529438Ccb309D2Bd89", "0xaf440573EACc6dD5F92AfB3560e2d3BA022bD236", "0xA759c29488D19B56BabcC2BF92bDc29dD3f0A8CD", "0xB6dCB317837D8e23bD249DC14b1718f391CFee92", "0xfEDB5eA07AE09df0102Be33DB6CCA8D11333dEEB", "0xD8F3E8204FbADD6DD5EF25E255d2a5bB7CA507E7", "0x08d7a3FF95526b73843d200224781626Bd4090dF", "0x444cf900Bbe99117F8158f9F8E19cec4bE5aF90D", "0xb8537352Adc3cCcc02c6fa5FF22b225Cc9F3c1c2", "0x7c457DFFFFDeA37c790e9d96Ce93B86b7606Ad1E", "0xD6fFE6C8E81292fF9bA26c093390D82EB7019a7B", "0x54266c317070ce735ebbea3F0f0Fa4C65BaDB75B", "0xA3c6a96C9bafB224BcBD0E32e35cfA15466c8eb0", "0x3D3518C9263E8E7F29D2257d5d3758F1D4445Ba1", "0x009B740F1670AF3a6b62D661f182F15a24a010AE", "0xaadC75cAF1eb2a6e6fF13033A0b422f8a4224A6b", "0x38Ea9AEb4a849F9accdE0c17ccFAEeb53ba6A393", "0x1B9Cb2b9AA606B22A76624067e9dcD63Af247C77", "0x8bd914304cC48c90b17fFb27574f93C3Ce949310", "0x634A953895349A51f4ED5aB0E6505c0Abefe1D2B", "0x8D7D9c5267F932543b6EC745de9F59A135c24ca8", "0x33c2B1D7EC6cde77D04dEBA677d8057Bd70F683F", "0x0bCCE532975c9aE6383C8E6403E42D44c8236288", "0xF2B33d72Ed84592dE0CD7EF32f03c0419C876228", "0xa2649B822E1dCFF3D8c934Ce25FbCD4A88b34c7E", "0x07c037ec6C85f34a0C24624BB442A9505F85ebE0", "0x444fd877A5b6283A3F851e4d1EaC05b0C7bAe178", "0xF0eb27B17f4b43390e9103A9BC4360812A9FFA72", "0x95811a7B64D1A6a0dB60e61aC1991c4dCf6A583C", "0x471ade2f8F8b24c9957C4F0d0a97619744575E6A", "0x7e3a41469Ff3BDCFeA113Faa84c97E48458f248c", "0x0b817d4696EE409E61917Ca8E3E20D3E175eb643", "0x64e1497AC67829a64C04513338d4AC13CED81856", "0xdEDb7bf5C7Ba7809d7c75185CBA32f7C96Ef26c7"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "uint256"}], name: "owners", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "creator", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "seller", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ownerCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "owner", type: "address"}], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "version", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSales", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_oldSeller", type: "address"}, {indexed: true, name: "_newSeller", type: "address"}], name: "SellerChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_newOwner", type: "address"}], name: "OwnerAdded", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_oldOwner", type: "address"}], name: "OwnerRemoved", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Sell(address,address,uint256)", "SellerChanged(address,address)", "OwnerAdded(address)", "OwnerRemoved(address)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xae98fdb7f4bc601d31354dd8c8ba584bf892418c4df67aba01011867bd88ea27", "0xd35d031ef8fbe90a984844820a53576f06a5ac0eb490063bb1e8301c67a6b127", "0x994a936646fe87ffe4f1e469d3d6aa417d6b855598397f323de5b449f765f0c3", "0x58619076adf5bb0943d100ef88d52d7c3fd691b19d3a9071b555b651fbf418da", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4277124 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4321363 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "BsToken_SNOV", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "owners", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owners(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "creator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "creator()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "seller", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "seller()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ownerCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "version", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "version()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSales", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSales()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "locked()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "remaining", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BsToken_SNOV", function( accounts ) {

	it( "TEST: BsToken_SNOV(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4277124", timeStamp: "1505489420", hash: "0x76d946a23d70bac704b31eb3f5ddb61e3fe1ec8bda629c037dcf27ec75a9f506", nonce: "0", blockHash: "0xd44f0282d6f7ff7a91016797ddc17232466bc5baf4f9f12ec2db5696f335e3ce", transactionIndex: "128", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: 0, value: "0", gas: "2654180", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0xad452254", contractAddress: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", cumulativeGasUsed: "6484712", gasUsed: "2654179", confirmations: "3428270"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "BsToken_SNOV", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BsToken_SNOV.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1505489420 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BsToken_SNOV.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[0,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_value", type: "uint256", value: "2500000000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[0,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[4], \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4277155", timeStamp: "1505490063", hash: "0x063a71f1bf092e07de2e7697405a287ac278e97df9fab3276a7b977460041506", nonce: "1", blockHash: "0xe3fdcb4c29101e5280b8633949d00f55a1609b38588390d23ceb0a95bb90da16", transactionIndex: "67", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "95937", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000007a41258ea90f289684394bcd4562e62e774ab01b0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1961911", gasUsed: "95936", confirmations: "3428239"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_value", value: "1"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[4], "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1505490063 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x7a41258ea90f289684394bcd4562e62e774ab01b"}, {name: "_value", type: "uint256", value: "1000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[1,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x7a41258ea90f289684394bcd4562e62e774ab01b"}, {name: "_value", type: "uint256", value: "1000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[1,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[4], \"19545299\" )", async function( ) {
		const txOriginal = {blockNumber: "4277209", timeStamp: "1505491469", hash: "0x958cff66747fb686e18d8eeb93903abb2135e4e74478138cf8b9e1f631c890ba", nonce: "2", blockHash: "0x6ffa416b370687d9e0ffb3b7bf89d545df35f1fe85918185cee434749b69268b", transactionIndex: "126", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "51129", gasPrice: "30000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000007a41258ea90f289684394bcd4562e62e774ab01b00000000000000000000000000000000000000000000000000000000012a3cd3", contractAddress: "", cumulativeGasUsed: "4418359", gasUsed: "51128", confirmations: "3428185"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[4]}, {type: "uint256", name: "_value", value: "19545299"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[4], "19545299", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1505491469 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x7a41258ea90f289684394bcd4562e62e774ab01b"}, {name: "_value", type: "uint256", value: "19545299000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x7a41258ea90f289684394bcd4562e62e774ab01b"}, {name: "_value", type: "uint256", value: "19545299000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[2,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[5], \"1437500\" )", async function( ) {
		const txOriginal = {blockNumber: "4280929", timeStamp: "1505580879", hash: "0xaffe80b25ab6a7ed6c470ba627f4046bf8faded0f798cf1869299d1fb6bddec6", nonce: "3", blockHash: "0x1ce2a91f3db929374078c537701cc33589ca2574682066cb95b4e8e14f097003", transactionIndex: "281", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "35579588499", isError: "0", txreceipt_status: "", input: "0x7c9473f600000000000000000000000048b00b2fe26932adac11c0a0801d8fd6bdd4e0bd000000000000000000000000000000000000000000000000000000000015ef3c", contractAddress: "", cumulativeGasUsed: "6712566", gasUsed: "66064", confirmations: "3424465"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[5]}, {type: "uint256", name: "_value", value: "1437500"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[5], "1437500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1505580879 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x48b00b2fe26932adac11c0a0801d8fd6bdd4e0bd"}, {name: "_value", type: "uint256", value: "1437500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x48b00b2fe26932adac11c0a0801d8fd6bdd4e0bd"}, {name: "_value", type: "uint256", value: "1437500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[6], \"690001\" )", async function( ) {
		const txOriginal = {blockNumber: "4280946", timeStamp: "1505581262", hash: "0xa7cf48abd4d336619434787bac4e182f51564b791b6cc1fff3e30fe91aee071b", nonce: "4", blockHash: "0xe1a52ff670c225afaf69c252d745240dc70ea9168abb33087c0c694fa8de57a1", transactionIndex: "56", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "32140896913", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000123e084fc361a878aef966df784f6b377408402800000000000000000000000000000000000000000000000000000000000a8751", contractAddress: "", cumulativeGasUsed: "2151299", gasUsed: "66064", confirmations: "3424448"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[6]}, {type: "uint256", name: "_value", value: "690001"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[6], "690001", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1505581262 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x123e084fc361a878aef966df784f6b3774084028"}, {name: "_value", type: "uint256", value: "690001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x123e084fc361a878aef966df784f6b3774084028"}, {name: "_value", type: "uint256", value: "690001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[7], \"207001\" )", async function( ) {
		const txOriginal = {blockNumber: "4280957", timeStamp: "1505581536", hash: "0x79f25ef4072f6e7f88491d1915791f8d5e58f6bc67836f1b81a21d332b8911df", nonce: "5", blockHash: "0x9f0a87205029ae584c905794f58a4cc63e25f28bca4a50c7df3f649459b9d211", transactionIndex: "67", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "35000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000005b891817eb3ae3beb01c28a0ebf84657be49e6470000000000000000000000000000000000000000000000000000000000032899", contractAddress: "", cumulativeGasUsed: "2450131", gasUsed: "66064", confirmations: "3424437"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[7]}, {type: "uint256", name: "_value", value: "207001"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[7], "207001", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1505581536 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x5b891817eb3ae3beb01c28a0ebf84657be49e647"}, {name: "_value", type: "uint256", value: "207001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x5b891817eb3ae3beb01c28a0ebf84657be49e647"}, {name: "_value", type: "uint256", value: "207001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[8], \"140301\" )", async function( ) {
		const txOriginal = {blockNumber: "4280965", timeStamp: "1505581796", hash: "0x8588c7b867ed07bb764399ebdcad018a631ba9b7bd436e708485aef983fa2847", nonce: "6", blockHash: "0xbaedd6afb4ae3df7b3a14cfe4c467e5b63917112d8bfb4294873d7c906adf2a6", transactionIndex: "82", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "32140896913", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000003adb710a29470b8d957436a8a86f31f949758fc5000000000000000000000000000000000000000000000000000000000002240d", contractAddress: "", cumulativeGasUsed: "2852550", gasUsed: "66064", confirmations: "3424429"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_value", value: "140301"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[8], "140301", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1505581796 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x3adb710a29470b8d957436a8a86f31f949758fc5"}, {name: "_value", type: "uint256", value: "140301000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x3adb710a29470b8d957436a8a86f31f949758fc5"}, {name: "_value", type: "uint256", value: "140301000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[9], \"662401\" )", async function( ) {
		const txOriginal = {blockNumber: "4280972", timeStamp: "1505582080", hash: "0xece05da58e09d6ef4a3df27cd1c27e6f448c27fda351c9af656fcd697995f0e7", nonce: "7", blockHash: "0xd2f8db0374de489a8dfbbc30f47ff934f1e1626a3a1fc549ccebd0086e5ba194", transactionIndex: "42", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "32140896913", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000fdb82ddbb1c5e875b62300c1a18aac5ee421dac800000000000000000000000000000000000000000000000000000000000a1b81", contractAddress: "", cumulativeGasUsed: "1980365", gasUsed: "66000", confirmations: "3424422"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_value", value: "662401"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[9], "662401", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1505582080 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xfdb82ddbb1c5e875b62300c1a18aac5ee421dac8"}, {name: "_value", type: "uint256", value: "662401000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xfdb82ddbb1c5e875b62300c1a18aac5ee421dac8"}, {name: "_value", type: "uint256", value: "662401000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[10], \"920001\" )", async function( ) {
		const txOriginal = {blockNumber: "4280978", timeStamp: "1505582228", hash: "0x2ce1c16b3f2e62095ce143aef87bd63602682cefb3a64c912f796c222c383947", nonce: "8", blockHash: "0xccb7a23934e6ddcde27773f074043b676c1fc65234d8f0f267bfb0b25c3e2394", transactionIndex: "44", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "32140896913", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000009f9f6768fcd665b0ae17f02601a24a60d1eb5dab00000000000000000000000000000000000000000000000000000000000e09c1", contractAddress: "", cumulativeGasUsed: "1835333", gasUsed: "66064", confirmations: "3424416"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[10]}, {type: "uint256", name: "_value", value: "920001"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[10], "920001", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1505582228 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x9f9f6768fcd665b0ae17f02601a24a60d1eb5dab"}, {name: "_value", type: "uint256", value: "920001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x9f9f6768fcd665b0ae17f02601a24a60d1eb5dab"}, {name: "_value", type: "uint256", value: "920001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[11], \"1495001\" )", async function( ) {
		const txOriginal = {blockNumber: "4280993", timeStamp: "1505582558", hash: "0x5014ea58406844a22ca6c6e8b722cde9a0a29725af4b58a760a2d6aa8dfe4307", nonce: "9", blockHash: "0x4be305fa7f8ef2802332d412a4a77bea866137c31d0594da3b2774fe710d3eed", transactionIndex: "240", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "32476049746", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000351fc4e8987a6170fb6baa38556822d79eb438e9000000000000000000000000000000000000000000000000000000000016cfd9", contractAddress: "", cumulativeGasUsed: "6602657", gasUsed: "66064", confirmations: "3424401"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_value", value: "1495001"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[11], "1495001", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1505582558 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x351fc4e8987a6170fb6baa38556822d79eb438e9"}, {name: "_value", type: "uint256", value: "1495001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x351fc4e8987a6170fb6baa38556822d79eb438e9"}, {name: "_value", type: "uint256", value: "1495001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[12], \"287501\" )", async function( ) {
		const txOriginal = {blockNumber: "4281011", timeStamp: "1505582974", hash: "0xae5c2d4bd5c1462cd9f330d1e0a26f074690f975e96dcfe0cb372f774a1eb101", nonce: "10", blockHash: "0x47894c4f9ca1102a9b68a5e7cc026c52b18f544ed3dcb203fc698efc42c12158", transactionIndex: "32", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "35000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000d82f335a5d636168d1b0b468ec9223ba7fb40a14000000000000000000000000000000000000000000000000000000000004630d", contractAddress: "", cumulativeGasUsed: "3295072", gasUsed: "66064", confirmations: "3424383"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[12]}, {type: "uint256", name: "_value", value: "287501"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[12], "287501", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1505582974 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xd82f335a5d636168d1b0b468ec9223ba7fb40a14"}, {name: "_value", type: "uint256", value: "287501000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xd82f335a5d636168d1b0b468ec9223ba7fb40a14"}, {name: "_value", type: "uint256", value: "287501000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[13], \"52901\" )", async function( ) {
		const txOriginal = {blockNumber: "4281013", timeStamp: "1505583100", hash: "0xabf612fb88868aea673a845cca0ce3e98094567ad4cf9220f935ac5c0e76269c", nonce: "11", blockHash: "0xefd45df411f5f8d04b0ff208afc065709447563a1df9f05e5df268ce43fba9bd", transactionIndex: "164", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "35000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f600000000000000000000000008c1baa2aeedc19f535088529438ccb309d2bd89000000000000000000000000000000000000000000000000000000000000cea5", contractAddress: "", cumulativeGasUsed: "6122158", gasUsed: "66000", confirmations: "3424381"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_value", value: "52901"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[13], "52901", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1505583100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x08c1baa2aeedc19f535088529438ccb309d2bd89"}, {name: "_value", type: "uint256", value: "52901000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x08c1baa2aeedc19f535088529438ccb309d2bd89"}, {name: "_value", type: "uint256", value: "52901000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[14], \"741751\" )", async function( ) {
		const txOriginal = {blockNumber: "4281017", timeStamp: "1505583191", hash: "0xe08cb7ac826f4c365571b8030e8515e363952e67fffec87241e5f5bbbf8796e7", nonce: "12", blockHash: "0x830116b308ba8bc67b7746f72b1e7726a7d5f141b499cc43dd90b75b5ffa863a", transactionIndex: "134", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "35000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000af440573eacc6dd5f92afb3560e2d3ba022bd23600000000000000000000000000000000000000000000000000000000000b5177", contractAddress: "", cumulativeGasUsed: "3430141", gasUsed: "66064", confirmations: "3424377"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_value", value: "741751"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[14], "741751", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1505583191 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xaf440573eacc6dd5f92afb3560e2d3ba022bd236"}, {name: "_value", type: "uint256", value: "741751000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xaf440573eacc6dd5f92afb3560e2d3ba022bd236"}, {name: "_value", type: "uint256", value: "741751000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[15], \"115001\" )", async function( ) {
		const txOriginal = {blockNumber: "4281025", timeStamp: "1505583336", hash: "0xb8404eddb633aee2cb910a6f7c187be5a798640564b98ec3cd649e583cf64716", nonce: "13", blockHash: "0x6247c38035cd346f045d135f381d7ba32df60b6ea1af2f6fd96ad906404033a1", transactionIndex: "138", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "31172369841", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000a759c29488d19b56babcc2bf92bdc29dd3f0a8cd000000000000000000000000000000000000000000000000000000000001c139", contractAddress: "", cumulativeGasUsed: "4738542", gasUsed: "66064", confirmations: "3424369"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[15]}, {type: "uint256", name: "_value", value: "115001"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[15], "115001", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1505583336 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xa759c29488d19b56babcc2bf92bdc29dd3f0a8cd"}, {name: "_value", type: "uint256", value: "115001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xa759c29488d19b56babcc2bf92bdc29dd3f0a8cd"}, {name: "_value", type: "uint256", value: "115001000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[16], \"172501\" )", async function( ) {
		const txOriginal = {blockNumber: "4281029", timeStamp: "1505583453", hash: "0x1e8d2c18aa8ee7f2f81916026b5d496d66b2ff6c5da8c9429aaf2e171bb51f47", nonce: "14", blockHash: "0x1a7f643d33689b14aa426c9fc5ce358155602b7126b856bb481a1fa58dfd7d36", transactionIndex: "87", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "32476049746", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000b6dcb317837d8e23bd249dc14b1718f391cfee92000000000000000000000000000000000000000000000000000000000002a1d5", contractAddress: "", cumulativeGasUsed: "2913409", gasUsed: "66064", confirmations: "3424365"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[16]}, {type: "uint256", name: "_value", value: "172501"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[16], "172501", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1505583453 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xb6dcb317837d8e23bd249dc14b1718f391cfee92"}, {name: "_value", type: "uint256", value: "172501000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xb6dcb317837d8e23bd249dc14b1718f391cfee92"}, {name: "_value", type: "uint256", value: "172501000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[17], \"5171\" )", async function( ) {
		const txOriginal = {blockNumber: "4281031", timeStamp: "1505583508", hash: "0xdf31220ca4015e4aa7790ca1f38c5ff873719c6efcb1929086f4450c04910c15", nonce: "15", blockHash: "0xeb74af9cab675857d8129939154a8fc55eca3e785e9be02e52733a306039d4b4", transactionIndex: "39", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "32074675921", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000fedb5ea07ae09df0102be33db6cca8d11333deeb0000000000000000000000000000000000000000000000000000000000001433", contractAddress: "", cumulativeGasUsed: "1268064", gasUsed: "66000", confirmations: "3424363"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "5171"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[17], "5171", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1505583508 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xfedb5ea07ae09df0102be33db6cca8d11333deeb"}, {name: "_value", type: "uint256", value: "5171000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xfedb5ea07ae09df0102be33db6cca8d11333deeb"}, {name: "_value", type: "uint256", value: "5171000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[18], \"2401\" )", async function( ) {
		const txOriginal = {blockNumber: "4281035", timeStamp: "1505583598", hash: "0xa0da1938bccf0d2e341bbde6ca3a3b101c650d8d07846daaa3830c5ddbec418e", nonce: "16", blockHash: "0x7c7b9f6400897d39711b629797d2aad9642afd8813b3a2ebff106ac332965d15", transactionIndex: "84", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "31172369841", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000d8f3e8204fbadd6dd5ef25e255d2a5bb7ca507e70000000000000000000000000000000000000000000000000000000000000961", contractAddress: "", cumulativeGasUsed: "3191464", gasUsed: "66000", confirmations: "3424359"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[18]}, {type: "uint256", name: "_value", value: "2401"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[18], "2401", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1505583598 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xd8f3e8204fbadd6dd5ef25e255d2a5bb7ca507e7"}, {name: "_value", type: "uint256", value: "2401000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xd8f3e8204fbadd6dd5ef25e255d2a5bb7ca507e7"}, {name: "_value", type: "uint256", value: "2401000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[19], \"495300000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4282146", timeStamp: "1505609569", hash: "0x59f02f120d9d8e59c5306d6ecd26c8a64ae17712637f64922fb66a7019a162e0", nonce: "24", blockHash: "0xa76f45af25d6504f4ea8c0e410b28b0db5193a12b0b2ed476181e6d6044f81b8", transactionIndex: "23", from: "0x7a41258ea90f289684394bcd4562e62e774ab01b", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "60000", gasPrice: "24000000000", isError: "1", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000008d7a3ff95526b73843d200224781626bd4090df0000000000000000000000000000000000000000000068e2444d1c21a0900000", contractAddress: "", cumulativeGasUsed: "899082", gasUsed: "60000", confirmations: "3423248"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[19]}, {type: "uint256", name: "_value", value: "495300000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "1854183393145800" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[17], \"5000\" )", async function( ) {
		const txOriginal = {blockNumber: "4285794", timeStamp: "1505696043", hash: "0x6d2782f6c15da08a7fd4492d816a66f337792c5b980d918995efd96d9c9b35b4", nonce: "17", blockHash: "0xb59c1f3b23e0274c10a2ca22753cb3d7dc81c525cc29c3b5b95b85dac73d20d2", transactionIndex: "10", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "51001", gasPrice: "40000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000fedb5ea07ae09df0102be33db6cca8d11333deeb0000000000000000000000000000000000000000000000000000000000001388", contractAddress: "", cumulativeGasUsed: "297180", gasUsed: "51000", confirmations: "3419600"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_value", value: "5000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[17], "5000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1505696043 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xfedb5ea07ae09df0102be33db6cca8d11333deeb"}, {name: "_value", type: "uint256", value: "5000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xfedb5ea07ae09df0102be33db6cca8d11333deeb"}, {name: "_value", type: "uint256", value: "5000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[20], \"40000\" )", async function( ) {
		const txOriginal = {blockNumber: "4287339", timeStamp: "1505734190", hash: "0x0658dc6f7b625ba7ce4bcc1962a4d5a708d9ec5218a5028914f177e9a84e9fe2", nonce: "18", blockHash: "0x97e3b065bd09b05211c2ad92b7b371588f6c579c023f5535530599ec4c493972", transactionIndex: "21", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "65937", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000444cf900bbe99117f8158f9f8e19cec4be5af90d0000000000000000000000000000000000000000000000000000000000009c40", contractAddress: "", cumulativeGasUsed: "1433123", gasUsed: "65936", confirmations: "3418055"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_value", value: "40000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[20], "40000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1505734190 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x444cf900bbe99117f8158f9f8e19cec4be5af90d"}, {name: "_value", type: "uint256", value: "40000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x444cf900bbe99117f8158f9f8e19cec4be5af90d"}, {name: "_value", type: "uint256", value: "40000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[21], \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4287894", timeStamp: "1505747976", hash: "0xd4a56cb5838411698d1ae8b887f0d576216e756d0712073387dfa37cfea3c79d", nonce: "19", blockHash: "0x3d69bef520c530d1858fa9695790da8091c7032d467891b858070f631e812e4a", transactionIndex: "112", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "65937", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000b8537352adc3cccc02c6fa5ff22b225cc9f3c1c20000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "5227844", gasUsed: "65936", confirmations: "3417500"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_value", value: "1"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[21], "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1505747976 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xb8537352adc3cccc02c6fa5ff22b225cc9f3c1c2"}, {name: "_value", type: "uint256", value: "1000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xb8537352adc3cccc02c6fa5ff22b225cc9f3c1c2"}, {name: "_value", type: "uint256", value: "1000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[21], \"1149999\" )", async function( ) {
		const txOriginal = {blockNumber: "4288388", timeStamp: "1505760035", hash: "0x27a68be3f5532f00c3d8c7bcacc6654a8bac8432b6296758c68a284c22549cfa", nonce: "20", blockHash: "0xb10b87c4fcabcdce07077acfb4b9f6b03d669658231adff71d861dd947364e91", transactionIndex: "197", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "51065", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000b8537352adc3cccc02c6fa5ff22b225cc9f3c1c20000000000000000000000000000000000000000000000000000000000118c2f", contractAddress: "", cumulativeGasUsed: "6279710", gasUsed: "51064", confirmations: "3417006"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_value", value: "1149999"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[21], "1149999", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1505760035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xb8537352adc3cccc02c6fa5ff22b225cc9f3c1c2"}, {name: "_value", type: "uint256", value: "1149999000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xb8537352adc3cccc02c6fa5ff22b225cc9f3c1c2"}, {name: "_value", type: "uint256", value: "1149999000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: addOwner( addressList[22] )", async function( ) {
		const txOriginal = {blockNumber: "4288485", timeStamp: "1505762643", hash: "0x5eef70c78bf4097e75c9818b1e12226fa4c29e8ce871b2a9e7a815f3f79f2393", nonce: "22", blockHash: "0x72b0312a9a97cc4b56ceeb42eaad4cf034f82545c5d682d78fe4cc73dffe6f58", transactionIndex: "45", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "71638", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7065cb480000000000000000000000007c457dffffdea37c790e9d96ce93b86b7606ad1e", contractAddress: "", cumulativeGasUsed: "2087872", gasUsed: "71637", confirmations: "3416909"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[22]}], name: "addOwner", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addOwner(address)" ]( addressList[22], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1505762643 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_newOwner", type: "address"}], name: "OwnerAdded", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnerAdded", events: [{name: "_newOwner", type: "address", value: "0x7c457dffffdea37c790e9d96ce93b86b7606ad1e"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[23], \"70000\" )", async function( ) {
		const txOriginal = {blockNumber: "4292533", timeStamp: "1505858291", hash: "0xf0b55a1dc9a8dd7870b455f08d4cb07484f2292f4c587613cee72f6c6e1e4b26", nonce: "23", blockHash: "0x099accc06882d075cf4700e2ae9761d9e5de2c2c53fa87c8e73e7ace7e1dd487", transactionIndex: "11", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000d6ffe6c8e81292ff9ba26c093390d82eb7019a7b0000000000000000000000000000000000000000000000000000000000011170", contractAddress: "", cumulativeGasUsed: "297064", gasUsed: "66064", confirmations: "3412861"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "70000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[23], "70000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1505858291 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xd6ffe6c8e81292ff9ba26c093390d82eb7019a7b"}, {name: "_value", type: "uint256", value: "70000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xd6ffe6c8e81292ff9ba26c093390d82eb7019a7b"}, {name: "_value", type: "uint256", value: "70000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[24], \"6250000\" )", async function( ) {
		const txOriginal = {blockNumber: "4294491", timeStamp: "1505904884", hash: "0x71eff227c9eb552e2b27688ae5f5635898c3d2015efcd92ac68d7b42d812c26a", nonce: "24", blockHash: "0xaed640f228300b031d669caec7b8d3cde235fc91f7bcc7b2e986fcafa594ca9e", transactionIndex: "44", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f600000000000000000000000054266c317070ce735ebbea3f0f0fa4c65badb75b00000000000000000000000000000000000000000000000000000000005f5e10", contractAddress: "", cumulativeGasUsed: "2278537", gasUsed: "66064", confirmations: "3410903"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[24]}, {type: "uint256", name: "_value", value: "6250000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[24], "6250000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1505904884 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x54266c317070ce735ebbea3f0f0fa4c65badb75b"}, {name: "_value", type: "uint256", value: "6250000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x54266c317070ce735ebbea3f0f0fa4c65badb75b"}, {name: "_value", type: "uint256", value: "6250000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[25], \"2127500\" )", async function( ) {
		const txOriginal = {blockNumber: "4296780", timeStamp: "1505960411", hash: "0xc4b139cb8fd2dc0a30fa4230e17d9dfefd683680a1b476023e28e363038316ba", nonce: "25", blockHash: "0xe070b598f64d2053bdbe5c203454aacf7914bb0975ea3e174c6040d90bbdd337", transactionIndex: "141", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66065", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000a3c6a96c9bafb224bcbd0e32e35cfa15466c8eb0000000000000000000000000000000000000000000000000000000000020768c", contractAddress: "", cumulativeGasUsed: "4779669", gasUsed: "66064", confirmations: "3408614"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[25]}, {type: "uint256", name: "_value", value: "2127500"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[25], "2127500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1505960411 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xa3c6a96c9bafb224bcbd0e32e35cfa15466c8eb0"}, {name: "_value", type: "uint256", value: "2127500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xa3c6a96c9bafb224bcbd0e32e35cfa15466c8eb0"}, {name: "_value", type: "uint256", value: "2127500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[26], \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "4298171", timeStamp: "1505993485", hash: "0xa9076a2869517c91562ab3b95e5109edc6d8a95cf228aa22e72513d74bd58a27", nonce: "26", blockHash: "0x2af58c51661b195bc6475c3e1c058469badd89cd47ff72ceb15c0cc0459a3e0a", transactionIndex: "51", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000003d3518c9263e8e7f29d2257d5d3758f1d4445ba100000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2317940", gasUsed: "66000", confirmations: "3407223"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[26]}, {type: "uint256", name: "_value", value: "1000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[26], "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1505993485 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x3d3518c9263e8e7f29d2257d5d3758f1d4445ba1"}, {name: "_value", type: "uint256", value: "1000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x3d3518c9263e8e7f29d2257d5d3758f1d4445ba1"}, {name: "_value", type: "uint256", value: "1000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"176923076900000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298247", timeStamp: "1505995471", hash: "0xb9de16373155a1510cb036730665963c2a3ed0e25e0f649980a1961368186a77", nonce: "79", blockHash: "0x3bce9fc806e8dbcfcffccc3160a714589cdba1a6cdb487b39405ff84bd1e4895", transactionIndex: "3", from: "0x9f9f6768fcd665b0ae17f02601a24a60d1eb5dab", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "24000", gasPrice: "60000000000", isError: "1", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000009b740f1670af3a6b62d661f182f15a24a010ae00000000000000000000000000000000000000000000257704eb65ea12c64000", contractAddress: "", cumulativeGasUsed: "87000", gasUsed: "24000", confirmations: "3407147"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_value", value: "176923076900000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "5137524846574187783" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[28], \"353846153800000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298249", timeStamp: "1505995497", hash: "0x4ed9e8c941e4acb060283fee467017b8d23c9924ee55d7dce58cb981860d0ea5", nonce: "80", blockHash: "0xd64a7ba944b90f41b6bcfd3868139a04683d5c0a23fdde6f1239998f09e0fb34", transactionIndex: "0", from: "0x9f9f6768fcd665b0ae17f02601a24a60d1eb5dab", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "24000", gasPrice: "60000000000", isError: "1", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000aadc75caf1eb2a6e6ff13033a0b422f8a4224a6b00000000000000000000000000000000000000000000077e342f146203c14000", contractAddress: "", cumulativeGasUsed: "24000", gasUsed: "24000", confirmations: "3407145"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[28]}, {type: "uint256", name: "_value", value: "35384615380000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "5137524846574187783" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[29], \"353846153800000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298250", timeStamp: "1505995526", hash: "0x292aee358efc3a829a9a12772c101ecfd87d810ec48c14df57480e9dc83754f3", nonce: "81", blockHash: "0xb7c8a12373ea6471b124e6ade3fe586bf16538e4fc30d023d26787974cb75a72", transactionIndex: "1", from: "0x9f9f6768fcd665b0ae17f02601a24a60d1eb5dab", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "24000", gasPrice: "60000000000", isError: "1", txreceipt_status: "", input: "0xa9059cbb00000000000000000000000038ea9aeb4a849f9accde0c17ccfaeeb53ba6a393000000000000000000000000000000000000000000004aee09d6cbd4258c8000", contractAddress: "", cumulativeGasUsed: "45051", gasUsed: "24000", confirmations: "3407144"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[29]}, {type: "uint256", name: "_value", value: "353846153800000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "5137524846574187783" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[27], \"176923076900000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4298252", timeStamp: "1505995632", hash: "0x8e08623c74bd3aa45ecb05cfc2e9dd8d3cd9338ff05a7c4138dbc366366d2df3", nonce: "82", blockHash: "0xfa7ccec62e52f40975c56c64785baebe61c283badbe9cba0af7b08c230ac6250", transactionIndex: "1", from: "0x9f9f6768fcd665b0ae17f02601a24a60d1eb5dab", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "50000", gasPrice: "60000000000", isError: "1", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000009b740f1670af3a6b62d661f182f15a24a010ae00000000000000000000000000000000000000000000257704eb65ea12c64000", contractAddress: "", cumulativeGasUsed: "71000", gasUsed: "50000", confirmations: "3407142"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[27]}, {type: "uint256", name: "_value", value: "176923076900000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "5137524846574187783" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[30], \"2500\" )", async function( ) {
		const txOriginal = {blockNumber: "4298357", timeStamp: "1505997973", hash: "0x3fc49798d05f6ea24751770caab69b0d057fc1b2e6fc387850686c8555f4f5c5", nonce: "27", blockHash: "0x6c468256415da86561f86c0f9892d30f94ec493759a06f3a05d9b4955a804d23", transactionIndex: "13", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000001b9cb2b9aa606b22a76624067e9dcd63af247c7700000000000000000000000000000000000000000000000000000000000009c4", contractAddress: "", cumulativeGasUsed: "536135", gasUsed: "66000", confirmations: "3407037"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[30]}, {type: "uint256", name: "_value", value: "2500"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[30], "2500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1505997973 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x1b9cb2b9aa606b22a76624067e9dcd63af247c77"}, {name: "_value", type: "uint256", value: "2500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x1b9cb2b9aa606b22a76624067e9dcd63af247c77"}, {name: "_value", type: "uint256", value: "2500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[31], \"8000\" )", async function( ) {
		const txOriginal = {blockNumber: "4298731", timeStamp: "1506007368", hash: "0x052e40f27dd1c7b53667baaa90e16a82d20c1c5e36dd6faf100ba4cde73a7110", nonce: "28", blockHash: "0xf9c0ba0614c69ce372d02c3d052a9b7f7e5401a25f2029d00500c06001aa1aec", transactionIndex: "25", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000008bd914304cc48c90b17ffb27574f93c3ce9493100000000000000000000000000000000000000000000000000000000000001f40", contractAddress: "", cumulativeGasUsed: "810604", gasUsed: "66000", confirmations: "3406663"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[31]}, {type: "uint256", name: "_value", value: "8000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[31], "8000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1506007368 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x8bd914304cc48c90b17ffb27574f93c3ce949310"}, {name: "_value", type: "uint256", value: "8000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x8bd914304cc48c90b17ffb27574f93c3ce949310"}, {name: "_value", type: "uint256", value: "8000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[32], \"500\" )", async function( ) {
		const txOriginal = {blockNumber: "4299686", timeStamp: "1506029230", hash: "0xd3e5d99ab64ceafde15a20bd737959e9f476d0de423b025537ac9a68b80f9eba", nonce: "29", blockHash: "0x4a0d4fb126cdf7ae903dd3859bc7b38b3de32d86a99b9793bd3fb61eb76e0ae7", transactionIndex: "30", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000634a953895349a51f4ed5ab0e6505c0abefe1d2b00000000000000000000000000000000000000000000000000000000000001f4", contractAddress: "", cumulativeGasUsed: "3278050", gasUsed: "66000", confirmations: "3405708"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[32]}, {type: "uint256", name: "_value", value: "500"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[32], "500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1506029230 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x634a953895349a51f4ed5ab0e6505c0abefe1d2b"}, {name: "_value", type: "uint256", value: "500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x634a953895349a51f4ed5ab0e6505c0abefe1d2b"}, {name: "_value", type: "uint256", value: "500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[33], \"2000\" )", async function( ) {
		const txOriginal = {blockNumber: "4301420", timeStamp: "1506076384", hash: "0xaa44c554a75d178bcb204f7f08e63f344fcb6a1879a2069656cbebbaf34c0136", nonce: "30", blockHash: "0x327e26d18d6a2da1a71a6da116117dbf8cfbf44b0221ce6666f56cfb5b7e4821", transactionIndex: "138", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000008d7d9c5267f932543b6ec745de9f59a135c24ca800000000000000000000000000000000000000000000000000000000000007d0", contractAddress: "", cumulativeGasUsed: "5164265", gasUsed: "66000", confirmations: "3403974"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[33]}, {type: "uint256", name: "_value", value: "2000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[33], "2000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1506076384 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x8d7d9c5267f932543b6ec745de9f59a135c24ca8"}, {name: "_value", type: "uint256", value: "2000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x8d7d9c5267f932543b6ec745de9f59a135c24ca8"}, {name: "_value", type: "uint256", value: "2000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[34], \"8000\" )", async function( ) {
		const txOriginal = {blockNumber: "4301753", timeStamp: "1506085824", hash: "0x39af95a15dc905d5d08fd376d703f6a4cdb6bbf77bf6b0b3bb74807b040e6e15", nonce: "31", blockHash: "0x9856cc0d1498d4fc63c981a70c9490fc0a376aa8c13ae81fbbeedae29a5b2ff2", transactionIndex: "39", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f600000000000000000000000033c2b1d7ec6cde77d04deba677d8057bd70f683f0000000000000000000000000000000000000000000000000000000000001f40", contractAddress: "", cumulativeGasUsed: "2387065", gasUsed: "66000", confirmations: "3403641"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[34]}, {type: "uint256", name: "_value", value: "8000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[34], "8000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1506085824 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x33c2b1d7ec6cde77d04deba677d8057bd70f683f"}, {name: "_value", type: "uint256", value: "8000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x33c2b1d7ec6cde77d04deba677d8057bd70f683f"}, {name: "_value", type: "uint256", value: "8000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[35], \"1500\" )", async function( ) {
		const txOriginal = {blockNumber: "4303088", timeStamp: "1506125076", hash: "0x961cc8c9bf2eb69eccf9ec9b52df77cb643f359d21c74eeb25201a59b5929ea5", nonce: "32", blockHash: "0xb26018c3cc672c338a2b0c2f2aa8e21a9661fa3b1aa7566ba7b100eac14f317a", transactionIndex: "20", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000000bcce532975c9ae6383c8e6403e42d44c823628800000000000000000000000000000000000000000000000000000000000005dc", contractAddress: "", cumulativeGasUsed: "933421", gasUsed: "66000", confirmations: "3402306"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[35]}, {type: "uint256", name: "_value", value: "1500"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[35], "1500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1506125076 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x0bcce532975c9ae6383c8e6403e42d44c8236288"}, {name: "_value", type: "uint256", value: "1500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x0bcce532975c9ae6383c8e6403e42d44c8236288"}, {name: "_value", type: "uint256", value: "1500000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[36], \"300\" )", async function( ) {
		const txOriginal = {blockNumber: "4311802", timeStamp: "1506385843", hash: "0x8460a6df7a271ae97bdb462552812eda5ab070155f32d0ed9a725c1e49601488", nonce: "33", blockHash: "0x8f48cf5ef556929503805a4629c9f7822bfbbbbc2be007e18ba85db878e19b35", transactionIndex: "68", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000f2b33d72ed84592de0cd7ef32f03c0419c876228000000000000000000000000000000000000000000000000000000000000012c", contractAddress: "", cumulativeGasUsed: "2896888", gasUsed: "66000", confirmations: "3393592"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[36]}, {type: "uint256", name: "_value", value: "300"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[36], "300", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1506385843 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xf2b33d72ed84592de0cd7ef32f03c0419c876228"}, {name: "_value", type: "uint256", value: "300000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xf2b33d72ed84592de0cd7ef32f03c0419c876228"}, {name: "_value", type: "uint256", value: "300000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[37], \"10000\" )", async function( ) {
		const txOriginal = {blockNumber: "4313565", timeStamp: "1506438281", hash: "0xb67b33913c3d7c950a82896bff32a0488a2343c92e8d39dfb276bfed342e88e0", nonce: "34", blockHash: "0xabd0f135953712e249e047810d96d9f9292106a951cccf37e74ae6a554227064", transactionIndex: "147", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000a2649b822e1dcff3d8c934ce25fbcd4a88b34c7e0000000000000000000000000000000000000000000000000000000000002710", contractAddress: "", cumulativeGasUsed: "5086312", gasUsed: "66000", confirmations: "3391829"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[37]}, {type: "uint256", name: "_value", value: "10000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[37], "10000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1506438281 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xa2649b822e1dcff3d8c934ce25fbcd4a88b34c7e"}, {name: "_value", type: "uint256", value: "10000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xa2649b822e1dcff3d8c934ce25fbcd4a88b34c7e"}, {name: "_value", type: "uint256", value: "10000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[38], \"26000\" )", async function( ) {
		const txOriginal = {blockNumber: "4313998", timeStamp: "1506450745", hash: "0xa174ab166f801087fa5d938243cca49e082b419571ca6572a0899545d31aca64", nonce: "35", blockHash: "0x32e7c967883b6f5c553093d1a7fa193a2c146a49925e466c45e31934e233a4ab", transactionIndex: "56", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f600000000000000000000000007c037ec6c85f34a0c24624bb442a9505f85ebe00000000000000000000000000000000000000000000000000000000000006590", contractAddress: "", cumulativeGasUsed: "4171299", gasUsed: "66000", confirmations: "3391396"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[38]}, {type: "uint256", name: "_value", value: "26000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[38], "26000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1506450745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x07c037ec6c85f34a0c24624bb442a9505f85ebe0"}, {name: "_value", type: "uint256", value: "26000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x07c037ec6c85f34a0c24624bb442a9505f85ebe0"}, {name: "_value", type: "uint256", value: "26000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[39], \"4000\" )", async function( ) {
		const txOriginal = {blockNumber: "4314184", timeStamp: "1506457094", hash: "0x004baf92e13142d4ca3581342dad0eb187a06f250057cbfabeeebf927428dc16", nonce: "36", blockHash: "0xd6ae1e22bd665338cdddc3b2fbc2faa88d617700b27a31ec1af4ccb09f688368", transactionIndex: "125", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000444fd877a5b6283a3f851e4d1eac05b0c7bae1780000000000000000000000000000000000000000000000000000000000000fa0", contractAddress: "", cumulativeGasUsed: "3852398", gasUsed: "66000", confirmations: "3391210"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[39]}, {type: "uint256", name: "_value", value: "4000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[39], "4000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1506457094 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x444fd877a5b6283a3f851e4d1eac05b0c7bae178"}, {name: "_value", type: "uint256", value: "4000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x444fd877a5b6283a3f851e4d1eac05b0c7bae178"}, {name: "_value", type: "uint256", value: "4000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[38], \"3900\" )", async function( ) {
		const txOriginal = {blockNumber: "4314264", timeStamp: "1506459239", hash: "0x09e9e4ebf50c670df821942d01f0d4f18063cf611616ee71591f5d3f378a5b30", nonce: "37", blockHash: "0x72d5db910b85350582db00ce52e1ca5bdd6a5e245f4ad43fb389335248d25a68", transactionIndex: "9", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "51001", gasPrice: "23100000000", isError: "0", txreceipt_status: "", input: "0x7c9473f600000000000000000000000007c037ec6c85f34a0c24624bb442a9505f85ebe00000000000000000000000000000000000000000000000000000000000000f3c", contractAddress: "", cumulativeGasUsed: "533892", gasUsed: "51000", confirmations: "3391130"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[38]}, {type: "uint256", name: "_value", value: "3900"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[38], "3900", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1506459239 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x07c037ec6c85f34a0c24624bb442a9505f85ebe0"}, {name: "_value", type: "uint256", value: "3900000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x07c037ec6c85f34a0c24624bb442a9505f85ebe0"}, {name: "_value", type: "uint256", value: "3900000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[23], \"15000\" )", async function( ) {
		const txOriginal = {blockNumber: "4317171", timeStamp: "1506545952", hash: "0x16d833028ae5877eb95c4f1fa2d1f6b5a561d30c1262f499b9d9e457622c7238", nonce: "38", blockHash: "0x4624423e713a956b00c267bcc0a60f7db3f537d449c68656b1173b1006f52da4", transactionIndex: "115", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "51001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000d6ffe6c8e81292ff9ba26c093390d82eb7019a7b0000000000000000000000000000000000000000000000000000000000003a98", contractAddress: "", cumulativeGasUsed: "5256393", gasUsed: "51000", confirmations: "3388223"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[23]}, {type: "uint256", name: "_value", value: "15000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[23], "15000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1506545952 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xd6ffe6c8e81292ff9ba26c093390d82eb7019a7b"}, {name: "_value", type: "uint256", value: "15000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xd6ffe6c8e81292ff9ba26c093390d82eb7019a7b"}, {name: "_value", type: "uint256", value: "15000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[40], \"3200\" )", async function( ) {
		const txOriginal = {blockNumber: "4317175", timeStamp: "1506546145", hash: "0x8d1a561e38e51808238fc77d7942cde46e2da2920b32e57b03f17d87ee5e076c", nonce: "39", blockHash: "0xb4b5d323ec9cfe68f5187fa5df8b9ec201fa57e3385eab70e630e6ef5bce8df4", transactionIndex: "64", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000f0eb27b17f4b43390e9103a9bc4360812a9ffa720000000000000000000000000000000000000000000000000000000000000c80", contractAddress: "", cumulativeGasUsed: "3360800", gasUsed: "66000", confirmations: "3388219"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[40]}, {type: "uint256", name: "_value", value: "3200"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[40], "3200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1506546145 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0xf0eb27b17f4b43390e9103a9bc4360812a9ffa72"}, {name: "_value", type: "uint256", value: "3200000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0xf0eb27b17f4b43390e9103a9bc4360812a9ffa72"}, {name: "_value", type: "uint256", value: "3200000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[41], \"1820\" )", async function( ) {
		const txOriginal = {blockNumber: "4318895", timeStamp: "1506597980", hash: "0x37e98f9da6a1bea280b4d78d78301189bdc1f0de0e768f1a251ea7fabe904782", nonce: "40", blockHash: "0x08c3f5a9571c0a428a47ef44dfb97fd62cf1f75f9246b57b47a928275394a66e", transactionIndex: "55", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f600000000000000000000000095811a7b64d1a6a0db60e61ac1991c4dcf6a583c000000000000000000000000000000000000000000000000000000000000071c", contractAddress: "", cumulativeGasUsed: "2787328", gasUsed: "66000", confirmations: "3386499"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[41]}, {type: "uint256", name: "_value", value: "1820"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[41], "1820", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1506597980 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x95811a7b64d1a6a0db60e61ac1991c4dcf6a583c"}, {name: "_value", type: "uint256", value: "1820000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x95811a7b64d1a6a0db60e61ac1991c4dcf6a583c"}, {name: "_value", type: "uint256", value: "1820000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[42], \"20000\" )", async function( ) {
		const txOriginal = {blockNumber: "4319335", timeStamp: "1506610972", hash: "0xbda54256f2043b1d97f08ddbbcbe0e328b5feff110866fd6127ccd631ab1b24c", nonce: "41", blockHash: "0x3e16cfeee720831d591435730016d0f6582d7935676018df5b3d088d9a38dea6", transactionIndex: "89", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "66001", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f6000000000000000000000000471ade2f8f8b24c9957c4f0d0a97619744575e6a0000000000000000000000000000000000000000000000000000000000004e20", contractAddress: "", cumulativeGasUsed: "3859449", gasUsed: "66000", confirmations: "3386059"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[42]}, {type: "uint256", name: "_value", value: "20000"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[42], "20000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1506610972 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x471ade2f8f8b24c9957c4f0d0a97619744575e6a"}, {name: "_value", type: "uint256", value: "20000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x471ade2f8f8b24c9957c4f0d0a97619744575e6a"}, {name: "_value", type: "uint256", value: "20000000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sellNoDecimals( addressList[43], \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4319989", timeStamp: "1506630701", hash: "0x90f74acd396194e2a44c7ffb2699ee7fefc39e810b3d7080e5b36bb3c30e79ca", nonce: "43", blockHash: "0x2db77d2038c6a4883c773a72a240dacadba19e13f137aea028781caaa1ec0a19", transactionIndex: "86", from: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "65937", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x7c9473f60000000000000000000000007e3a41469ff3bdcfea113faa84c97e48458f248c0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "3237699", gasUsed: "65936", confirmations: "3385405"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[43]}, {type: "uint256", name: "_value", value: "1"}], name: "sellNoDecimals", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sellNoDecimals(address,uint256)" ]( addressList[43], "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1506630701 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_seller", type: "address"}, {indexed: true, name: "_buyer", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Sell", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Sell", events: [{name: "_seller", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_buyer", type: "address", value: "0x7e3a41469ff3bdcfea113faa84c97e48458f248c"}, {name: "_value", type: "uint256", value: "1000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xdae3f1d824127754aca9eb5e5bfbac22d8a04a52"}, {name: "_to", type: "address", value: "0x7e3a41469ff3bdcfea113faa84c97e48458f248c"}, {name: "_value", type: "uint256", value: "1000000000000000000"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "98382576000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[0], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4320577", timeStamp: "1506648527", hash: "0xece5a9965be0ce91cddcc591068db329f8a4986099dd5f606a840db586272130", nonce: "41", blockHash: "0xe7cb2bbc113e9b27d0b8d2195ed611c7b351582fce2967f68fa9e5a25bafa031", transactionIndex: "88", from: "0x0b817d4696ee409e61917ca8e3e20d3e175eb643", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "34694", gasPrice: "20770773051", isError: "0", txreceipt_status: "", input: "0x095ea7b300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2874108", gasUsed: "28912", confirmations: "3384817"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_spender", value: addressList[0]}, {type: "uint256", name: "_value", value: "0"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[0], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1506648527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_spender", type: "address"}, {indexed: false, name: "_value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[47,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "_owner", type: "address", value: "0x0b817d4696ee409e61917ca8e3e20d3e175eb643"}, {name: "_spender", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_value", type: "uint256", value: "0"}], address: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969"}] ;
		console.error( "eventResultOriginal[47,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "56734368184795708" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[46], \"2000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4321353", timeStamp: "1506672929", hash: "0x4f11ce3aff8bd6205adcf496c460a5e090fe46e5f69157d3efcba1f919e9d559", nonce: "7", blockHash: "0x36ff113e79256d37a80402f7c3061c09712963f9227364960f63060c6d013494", transactionIndex: "67", from: "0x64e1497ac67829a64c04513338d4ac13ced81856", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "23192", gasPrice: "3000000000", isError: "1", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000dedb7bf5c7ba7809d7c75185cba32f7c96ef26c70000000000000000000000000000000000000000000000001bc16d674ec80000", contractAddress: "", cumulativeGasUsed: "1461409", gasUsed: "23192", confirmations: "3384041"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[46]}, {type: "uint256", name: "_value", value: "2000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "55612641826794469" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[46], \"3000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4321363", timeStamp: "1506673196", hash: "0x2be9c12c67ab5f9eca4b97c141c8414f94af03cdf0c51f38493c2a961e3823fb", nonce: "8", blockHash: "0x4cdd91fc20afabbaddd227b53d505d2747a8476cd422795d68411e67c660b2a7", transactionIndex: "38", from: "0x64e1497ac67829a64c04513338d4ac13ced81856", to: "0xbdc5bac39dbe132b1e030e898ae3830017d7d969", value: "0", gas: "23192", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0xa9059cbb000000000000000000000000dedb7bf5c7ba7809d7c75185cba32f7c96ef26c700000000000000000000000000000000000000000000000029a2241af62c0000", contractAddress: "", cumulativeGasUsed: "886249", gasUsed: "23192", confirmations: "3384031"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_to", value: addressList[46]}, {type: "uint256", name: "_value", value: "3000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "55612641826794469" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
