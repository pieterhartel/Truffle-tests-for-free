var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "BTHCrossFork"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0x05852E51E7c86333510327C64D8dDDC9D2264D24","0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed","0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1","0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e","0x146500cfd35B22E4A392Fe0aDc06De1a1368Ed48","0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475","0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF","0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA","0xaE164891625eE421626F69C14fD94EB6d35e7458","0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51","0xa193C943980A9340F306b3d59Deb183Dc501B35f","0xb73ad2931753d23243c6761eAdd13CD38918bf50"]
addressListOriginal.length = 14
methodPrototypeListOriginal = [{"constant":true,"inputs":[{"name":"result","type":"string"}],"name":"extractBTHAmount","outputs":[{"name":"","type":"uint256"},{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"verifyUrl","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"crossForkBlockNumber","outputs":[{"name":"","type":"uint64"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"moderators","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"gasLimit","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"gasPrice","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":true,"name":"queryId","type":"bytes32"},{"indexed":false,"name":"requestId","type":"uint64"},{"indexed":false,"name":"amount","type":"uint256"},{"indexed":false,"name":"resultCode","type":"uint8"}],"name":"LogReceiveQuery","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"btcAddressHash","type":"bytes32"},{"indexed":false,"name":"requestId","type":"uint64"},{"indexed":false,"name":"receiver","type":"address"},{"indexed":false,"name":"resultCode","type":"uint8"}],"name":"LogTriggerQuery","type":"event"}]
eventSignatureListOriginal = ["LogReceiveQuery(bytes32,uint64,uint256,uint8)","LogTriggerQuery(bytes32,uint64,address,uint8)"]
topicListOriginal = ["0x6e9ddeafba3c6efb137aad14ec0322ed970574b4e4ac66efd2894859ee96abfe","0x01dbbc21fc03b74eb4e677446bd2e8ce395db326e4ede0688356819caebaca09"]
nBlocksOriginal = 50
fromBlockOriginal = 4526053
toBlockOriginal = 4543088
constructorPrototypeOriginal = {"inputs":[{"type":"string","name":"_verifyUrl","value":"https://www.bytether.com/oraclize/get_bth_value"},{"type":"uint64","name":"_crossForkBlockNumber","value":"478558"}],"name":"BTHCrossFork","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":"4526053","timeStamp":"1510316588","hash":"0x4d01d5cc59147f8f93d412a4e815f294a8867b7a470e79644f3696511941cdf8","nonce":"29","blockHash":"0xd5e6a814ac5510d347a8cfd0b7a6f1e7d64289fc352b00299942f1a7a0b792c9","transactionIndex":"36","from":"0xae164891625ee421626f69c14fd94eb6d35e7458","to":0,"value":"0","gas":"5270270","gasPrice":"9000000000","isError":"0","txreceipt_status":"1","input":"0xab5e398c00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000074d5e000000000000000000000000000000000000000000000000000000000000002f68747470733a2f2f7777772e62797465746865722e636f6d2f6f7261636c697a652f6765745f6274685f76616c75650000000000000000000000000000000000","contractAddress":"0x05852e51e7c86333510327c64d8dddc9d2264d24","cumulativeGasUsed":"6207486","gasUsed":"5170270","confirmations":"3211672"}
txOptions[0] = {"from":"0x28a8746e75304c0780E011BEd21C72cD78cd535E","to":0,"value":"0"}
txCall[0] = {"inputs":[{"type":"string","name":"_verifyUrl","value":"https://www.bytether.com/oraclize/get_bth_value"},{"type":"uint64","name":"_crossForkBlockNumber","value":"478558"}],"name":"BTHCrossFork","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
