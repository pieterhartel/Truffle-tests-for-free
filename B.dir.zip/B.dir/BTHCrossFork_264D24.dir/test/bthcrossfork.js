const BTHCrossFork = artifacts.require( "./BTHCrossFork.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "BTHCrossFork" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x05852E51E7c86333510327C64D8dDDC9D2264D24", "0x1d3B2638a7cC9f2CB3D298A3DA7a90B67E5506ed", "0xc03A2615D5efaf5F49F60B7BB6583eaec212fdf1", "0xB7A07BcF2Ba2f2703b24C0691b5278999C59AC7e", "0x146500cfd35B22E4A392Fe0aDc06De1a1368Ed48", "0x6f485C8BF6fc43eA212E93BBF8ce046C7f1cb475", "0x20e12A1F859B3FeaE5Fb2A0A32C18F5a65555bBF", "0x51efaF4c8B3C9AfBD5aB9F4bbC82784Ab6ef8fAA", "0xaE164891625eE421626F69C14fD94EB6d35e7458", "0x26588a9301b0428d95e6Fc3A5024fcE8BEc12D51", "0xa193C943980A9340F306b3d59Deb183Dc501B35f", "0xb73ad2931753d23243c6761eAdd13CD38918bf50"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "result", type: "string"}], name: "extractBTHAmount", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "verifyUrl", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "crossForkBlockNumber", outputs: [{name: "", type: "uint64"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "moderators", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gasLimit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gasPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "btcAddressHash", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "receiver", type: "address"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogTriggerQuery", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogReceiveQuery(bytes32,uint64,uint256,uint8)", "LogTriggerQuery(bytes32,uint64,address,uint8)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x6e9ddeafba3c6efb137aad14ec0322ed970574b4e4ac66efd2894859ee96abfe", "0x01dbbc21fc03b74eb4e677446bd2e8ce395db326e4ede0688356819caebaca09"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4526053 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4543088 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "string", name: "_verifyUrl", value: "https://www.bytether.com/oraclize/get_bth_value"}, {type: "uint64", name: "_crossForkBlockNumber", value: "478558"}], name: "BTHCrossFork", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "string", name: "result", value: random.string( maxRandom )}], name: "extractBTHAmount", outputs: [{name: "", type: "uint256"}, {name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "extractBTHAmount(string)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "verifyUrl", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "verifyUrl()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "crossForkBlockNumber", outputs: [{name: "", type: "uint64"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "crossForkBlockNumber()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "moderators", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "moderators(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gasLimit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gasLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gasPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gasPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "BTHCrossFork", function( accounts ) {

	it( "TEST: BTHCrossFork( `https://www.bytether.com/oraclize/get_b... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4526053", timeStamp: "1510316588", hash: "0x4d01d5cc59147f8f93d412a4e815f294a8867b7a470e79644f3696511941cdf8", nonce: "29", blockHash: "0xd5e6a814ac5510d347a8cfd0b7a6f1e7d64289fc352b00299942f1a7a0b792c9", transactionIndex: "36", from: "0xae164891625ee421626f69c14fd94eb6d35e7458", to: 0, value: "0", gas: "5270270", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xab5e398c00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000074d5e000000000000000000000000000000000000000000000000000000000000002f68747470733a2f2f7777772e62797465746865722e636f6d2f6f7261636c697a652f6765745f6274685f76616c75650000000000000000000000000000000000", contractAddress: "0x05852e51e7c86333510327c64d8dddc9d2264d24", cumulativeGasUsed: "6207486", gasUsed: "5170270", confirmations: "3211672"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_verifyUrl", value: `https://www.bytether.com/oraclize/get_bth_value`}, {type: "uint64", name: "_crossForkBlockNumber", value: "478558"}], name: "BTHCrossFork", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = BTHCrossFork.new( `https://www.bytether.com/oraclize/get_bth_value`, "478558", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510316588 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = BTHCrossFork.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "176672635070505570" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setOraclizeGasPrice( \"1000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4526075", timeStamp: "1510316865", hash: "0xa3baef75df9efd17370c12e98fe65c632aa79ad544221cb808ab3f6bfa752e01", nonce: "30", blockHash: "0xe891b67eed721130c921cd3497a31983a38caf02c2b8f80e736cb0367201bb4e", transactionIndex: "131", from: "0xae164891625ee421626f69c14fd94eb6d35e7458", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "154299", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x71c82c14000000000000000000000000000000000000000000000000000000003b9aca00", contractAddress: "", cumulativeGasUsed: "3772536", gasUsed: "54018", confirmations: "3211650"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_gasPrice", value: "1000000000"}], name: "setOraclizeGasPrice", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setOraclizeGasPrice(uint256)" ]( "1000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510316865 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "176672635070505570" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4526087", timeStamp: "1510317046", hash: "0xac2a324a8d006fe0d82d2e5c33ff94aa96fa0e6172bb6d0e7608b0a22aef4e47", nonce: "31", blockHash: "0x56d188822e26b8475b37d61895b27c707cf72eefa4d2375b5a2c16c1f107647f", transactionIndex: "97", from: "0xae164891625ee421626f69c14fd94eb6d35e7458", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "10000000000000000", gas: "121040", gasPrice: "17000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3116392", gasUsed: "21040", confirmations: "3211638"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510317046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "176672635070505570" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xcfc450a6fb1c58d1f8104f6f5b9416732d2d... )", async function( ) {
		const txOriginal = {blockNumber: "4532251", timeStamp: "1510401906", hash: "0x56de03c7e5d44ac93b496bca4d85531aeb2f15987e23fb88d15c2246238b506e", nonce: "329647", blockHash: "0x3c370ca7163345be72ff6970261f1b361d9d11d133473bd59397455e4f7fed9a", transactionIndex: "28", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50cfc450a6fb1c58d1f8104f6f5b9416732d2d61e7f5ac7772b7198445e59a1754000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000003763d30000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220e6208788cb7e91fe643e7427a3e5256e5088df38e8b3c125f14b950c5043a862000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1279984", gasUsed: "43628", confirmations: "3205474"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xcfc450a6fb1c58d1f8104f6f5b9416732d2d61e7f5ac7772b7198445e59a1754"}, {type: "string", name: "_result", value: `v=0`}, {type: "bytes", name: "proof", value: "0x1220e6208788cb7e91fe643e7427a3e5256e5088df38e8b3c125f14b950c5043a862"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xcfc450a6fb1c58d1f8104f6f5b9416732d2d61e7f5ac7772b7198445e59a1754", `v=0`, "0x1220e6208788cb7e91fe643e7427a3e5256e5088df38e8b3c125f14b950c5043a862", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510401906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xcfc450a6fb1c58d1f8104f6f5b9416732d2d61e7f5ac7772b7198445e59a1754"}, {name: "requestId", type: "uint64", value: {s: 1, e: 0, c: [2]}}, {name: "amount", type: "uint256", value: "0"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x8452bb10b69568413a90ec909cd1cf15537b... )", async function( ) {
		const txOriginal = {blockNumber: "4532318", timeStamp: "1510402846", hash: "0x41ff8e7bf017667de92b79686276f31ee29ef27b56ad3dd5692a3217d4ff27e7", nonce: "329653", blockHash: "0xf67ed02aa36c1373b3de27f13c969051f8821a0a7886c60c7bf508284beeed32", transactionIndex: "59", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa508452bb10b69568413a90ec909cd1cf15537b18e6ea975f5d6a13592b2917d705000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000b763d313030303030303030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212207622dc36c7f9b7f9f108ed0a5d1967b98ea930aab12d5fe13e39deec4f73a6b0000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4213352", gasUsed: "128905", confirmations: "3205407"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x8452bb10b69568413a90ec909cd1cf15537b18e6ea975f5d6a13592b2917d705"}, {type: "string", name: "_result", value: `v=100000000`}, {type: "bytes", name: "proof", value: "0x12207622dc36c7f9b7f9f108ed0a5d1967b98ea930aab12d5fe13e39deec4f73a6b0"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x8452bb10b69568413a90ec909cd1cf15537b18e6ea975f5d6a13592b2917d705", `v=100000000`, "0x12207622dc36c7f9b7f9f108ed0a5d1967b98ea930aab12d5fe13e39deec4f73a6b0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510402846 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x8452bb10b69568413a90ec909cd1cf15537b18e6ea975f5d6a13592b2917d705"}, {name: "requestId", type: "uint64", value: {s: 1, e: 0, c: [3]}}, {name: "amount", type: "uint256", value: "100000000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4532415", timeStamp: "1510404204", hash: "0x6000fb264331260255c03bf699eb5c44bdb6f1e8b65e0090d22b02c373f42227", nonce: "26902", blockHash: "0x2489d8003be723e2ca6766a395b8177a455fd6bb8cbef29f4ca2a14129a1741e", transactionIndex: "1", from: "0xa193c943980a9340f306b3d59deb183dc501b35f", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "100000000000000000", gas: "90000", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "146879", gasUsed: "21040", confirmations: "3205310"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510404204 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "22341794530314259" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4532493", timeStamp: "1510405631", hash: "0x9f7754361d34e593eb0b1f56d11ad0ab2ab18cfe0bbca13f726a851fbba2ede9", nonce: "2", blockHash: "0x1243fe31d38de2ea5fbc9b2a29bc08d0ad5f33ba5da856bd20a13646b32e665a", transactionIndex: "79", from: "0xb73ad2931753d23243c6761eadd13cd38918bf50", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "100000000000000000", gas: "31560", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2612110", gasUsed: "21040", confirmations: "3205232"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510405631 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "7210352800000001" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x2b789a38fa1284d14134e17219c0c4464af5... )", async function( ) {
		const txOriginal = {blockNumber: "4537653", timeStamp: "1510475263", hash: "0x5f86d47c7a709e11a904fbddc63364519a3858bd833aa6bcb7531605d97e6cf6", nonce: "330125", blockHash: "0xb49d942ea3fd21b073451ffd8f7bc14eb3c68224e63972b8202a083bffdd14c2", transactionIndex: "133", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa502b789a38fa1284d14134e17219c0c4464af53c2b48a5f9d11ed0b8b35dcb41f2000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000b763d31303030303030303000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220a48b4ae6935c49c5788647ab8395be1555e8f40b9ca88cd0a9b90b860f039f5c000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5644423", gasUsed: "113905", confirmations: "3200072"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x2b789a38fa1284d14134e17219c0c4464af53c2b48a5f9d11ed0b8b35dcb41f2"}, {type: "string", name: "_result", value: `v=100000000`}, {type: "bytes", name: "proof", value: "0x1220a48b4ae6935c49c5788647ab8395be1555e8f40b9ca88cd0a9b90b860f039f5c"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x2b789a38fa1284d14134e17219c0c4464af53c2b48a5f9d11ed0b8b35dcb41f2", `v=100000000`, "0x1220a48b4ae6935c49c5788647ab8395be1555e8f40b9ca88cd0a9b90b860f039f5c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510475263 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x2b789a38fa1284d14134e17219c0c4464af53c2b48a5f9d11ed0b8b35dcb41f2"}, {name: "requestId", type: "uint64", value: {s: 1, e: 0, c: [4]}}, {name: "amount", type: "uint256", value: "100000000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x85b4992ff3a1e8ca24ef67564e2a61bab91c... )", async function( ) {
		const txOriginal = {blockNumber: "4537762", timeStamp: "1510476614", hash: "0x09bffbf0a5090e42b19fe42bc13c752e743ac8855959feeba3f48944b011de83", nonce: "330132", blockHash: "0xc0729b4eb417ae880bbde5c0001713a1ab8c83af95b5597d884748506cc9e31c", transactionIndex: "167", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5085b4992ff3a1e8ca24ef67564e2a61bab91c0426df5b13399526ef507dd8254c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000c763d31303032323031333838000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220bd8ce4f0007d4de5cb70fc1fd5d90f6980906a446baa05fe2b1e122aaf416a7d000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6171580", gasUsed: "129298", confirmations: "3199963"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x85b4992ff3a1e8ca24ef67564e2a61bab91c0426df5b13399526ef507dd8254c"}, {type: "string", name: "_result", value: `v=1002201388`}, {type: "bytes", name: "proof", value: "0x1220bd8ce4f0007d4de5cb70fc1fd5d90f6980906a446baa05fe2b1e122aaf416a7d"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x85b4992ff3a1e8ca24ef67564e2a61bab91c0426df5b13399526ef507dd8254c", `v=1002201388`, "0x1220bd8ce4f0007d4de5cb70fc1fd5d90f6980906a446baa05fe2b1e122aaf416a7d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510476614 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x85b4992ff3a1e8ca24ef67564e2a61bab91c0426df5b13399526ef507dd8254c"}, {name: "requestId", type: "uint64", value: {s: 1, e: 0, c: [5]}}, {name: "amount", type: "uint256", value: "1002201388"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xa57ace38900e574c2438453f9e30b09ef3af... )", async function( ) {
		const txOriginal = {blockNumber: "4538138", timeStamp: "1510481930", hash: "0x6c08888b7bd486cd2b67648640870d9d32baeac517665b58244fe85cc1bc857b", nonce: "330161", blockHash: "0xe37f8595e2f336a055ff3171fcb105d5434ecf5ed2bc62f863b76ea39fc847e1", transactionIndex: "68", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50a57ace38900e574c2438453f9e30b09ef3afa3e70804b9c2da5ef3ff9e6ecc2c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000a763d33323737383430310000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220bd2a86c8219b44dd7c6938b79f31902d8f0484f4cc4a49c311aadf5bf6176d14000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3328969", gasUsed: "128448", confirmations: "3199587"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xa57ace38900e574c2438453f9e30b09ef3afa3e70804b9c2da5ef3ff9e6ecc2c"}, {type: "string", name: "_result", value: `v=32778401`}, {type: "bytes", name: "proof", value: "0x1220bd2a86c8219b44dd7c6938b79f31902d8f0484f4cc4a49c311aadf5bf6176d14"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xa57ace38900e574c2438453f9e30b09ef3afa3e70804b9c2da5ef3ff9e6ecc2c", `v=32778401`, "0x1220bd2a86c8219b44dd7c6938b79f31902d8f0484f4cc4a49c311aadf5bf6176d14", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510481930 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xa57ace38900e574c2438453f9e30b09ef3afa3e70804b9c2da5ef3ff9e6ecc2c"}, {name: "requestId", type: "uint64", value: {s: 1, e: 0, c: [6]}}, {name: "amount", type: "uint256", value: "32778401"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x90774a3bfa2ac867db2a9565b49cf479f849... )", async function( ) {
		const txOriginal = {blockNumber: "4538181", timeStamp: "1510482563", hash: "0xf81aff6c95425220ccbde7b3a3b2b55e50a04920038af19a9a3bb7e0f95107a1", nonce: "330166", blockHash: "0xdd4fc2aa224ac87f6934349f0bd8c5a22ab1a631fff103956ac68add3511e5c1", transactionIndex: "45", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5090774a3bfa2ac867db2a9565b49cf479f849a6d0c5e2e8f0acc143f9544479fa000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000c763d343530303030303030300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212209a81be967f387191ca598e40f1638fc8534468951f5a6cff2899918e62b46e0c000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2073230", gasUsed: "129362", confirmations: "3199544"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x90774a3bfa2ac867db2a9565b49cf479f849a6d0c5e2e8f0acc143f9544479fa"}, {type: "string", name: "_result", value: `v=4500000000`}, {type: "bytes", name: "proof", value: "0x12209a81be967f387191ca598e40f1638fc8534468951f5a6cff2899918e62b46e0c"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x90774a3bfa2ac867db2a9565b49cf479f849a6d0c5e2e8f0acc143f9544479fa", `v=4500000000`, "0x12209a81be967f387191ca598e40f1638fc8534468951f5a6cff2899918e62b46e0c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510482563 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x90774a3bfa2ac867db2a9565b49cf479f849a6d0c5e2e8f0acc143f9544479fa"}, {name: "requestId", type: "uint64", value: {s: 1, e: 0, c: [7]}}, {name: "amount", type: "uint256", value: "4500000000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x86b93e63f62716eff4414b072c35ee0e8884... )", async function( ) {
		const txOriginal = {blockNumber: "4538271", timeStamp: "1510483869", hash: "0x6d6ed4a4a1d1857373246fb525eea73a238eecab8b128bc6ce5b29543b262ab5", nonce: "330172", blockHash: "0x28837f0a0d2dcfc7e727c6a479ad779098170d44a1eda3f1b0ee06246ee2b5d4", transactionIndex: "75", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5086b93e63f62716eff4414b072c35ee0e8884bcb9cffb8426de039eb300e9990b000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000003763d300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212201ad117216453fb255531f3b4c314aa11a1d2d998decbe845298ea17cfe5c1961000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2014353", gasUsed: "43564", confirmations: "3199454"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x86b93e63f62716eff4414b072c35ee0e8884bcb9cffb8426de039eb300e9990b"}, {type: "string", name: "_result", value: `v=0`}, {type: "bytes", name: "proof", value: "0x12201ad117216453fb255531f3b4c314aa11a1d2d998decbe845298ea17cfe5c1961"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x86b93e63f62716eff4414b072c35ee0e8884bcb9cffb8426de039eb300e9990b", `v=0`, "0x12201ad117216453fb255531f3b4c314aa11a1d2d998decbe845298ea17cfe5c1961", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510483869 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x86b93e63f62716eff4414b072c35ee0e8884bcb9cffb8426de039eb300e9990b"}, {name: "requestId", type: "uint64", value: {s: 1, e: 0, c: [8]}}, {name: "amount", type: "uint256", value: "0"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x93e7e816a5cbb977f52a3744f81834b2abae... )", async function( ) {
		const txOriginal = {blockNumber: "4538284", timeStamp: "1510484024", hash: "0x6b243ef651b2e6ba250c7267f8d328c0ad3dc4735f4b0c52483fc5a41e1ab274", nonce: "330173", blockHash: "0xf6369c9948234c882f12384d504cfefcb3ef0b0d72403f5846c2fe4047679e53", transactionIndex: "153", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5093e7e816a5cbb977f52a3744f81834b2abae30e7a73da66406485245a62a529d000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000003763d300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212208bcd6dda072279e031c970cfd21d2cc2552814b0015c6d292143d590d6aacec4000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6306079", gasUsed: "43628", confirmations: "3199441"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x93e7e816a5cbb977f52a3744f81834b2abae30e7a73da66406485245a62a529d"}, {type: "string", name: "_result", value: `v=0`}, {type: "bytes", name: "proof", value: "0x12208bcd6dda072279e031c970cfd21d2cc2552814b0015c6d292143d590d6aacec4"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x93e7e816a5cbb977f52a3744f81834b2abae30e7a73da66406485245a62a529d", `v=0`, "0x12208bcd6dda072279e031c970cfd21d2cc2552814b0015c6d292143d590d6aacec4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510484024 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x93e7e816a5cbb977f52a3744f81834b2abae30e7a73da66406485245a62a529d"}, {name: "requestId", type: "uint64", value: {s: 1, e: 0, c: [9]}}, {name: "amount", type: "uint256", value: "0"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xc083fcc99fd704645a2f6aa49839ebf0dbcf... )", async function( ) {
		const txOriginal = {blockNumber: "4538290", timeStamp: "1510484061", hash: "0x4b66d65ee0d7abe6c2c8f0f3b2052be5a682035bef7e50cf55d7ca3d3c63d632", nonce: "330174", blockHash: "0x88f694d4a35859e76892f8056b53e2408e110b66de817099572985b5826ae084", transactionIndex: "67", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50c083fcc99fd704645a2f6aa49839ebf0dbcf8e1bf5cc77eb7b5b1d443d4b2a4e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000e763d3134373632323736343932380000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122093d23a57184e3e5ae0f9e38c43026ed3466b24b722334d69278fdf2242f998ca000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2993599", gasUsed: "130276", confirmations: "3199435"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xc083fcc99fd704645a2f6aa49839ebf0dbcf8e1bf5cc77eb7b5b1d443d4b2a4e"}, {type: "string", name: "_result", value: `v=147622764928`}, {type: "bytes", name: "proof", value: "0x122093d23a57184e3e5ae0f9e38c43026ed3466b24b722334d69278fdf2242f998ca"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xc083fcc99fd704645a2f6aa49839ebf0dbcf8e1bf5cc77eb7b5b1d443d4b2a4e", `v=147622764928`, "0x122093d23a57184e3e5ae0f9e38c43026ed3466b24b722334d69278fdf2242f998ca", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510484061 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xc083fcc99fd704645a2f6aa49839ebf0dbcf8e1bf5cc77eb7b5b1d443d4b2a4e"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [10]}}, {name: "amount", type: "uint256", value: "147622764928"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x3592275523c6c45d1f7eeeee0576136d5760... )", async function( ) {
		const txOriginal = {blockNumber: "4538294", timeStamp: "1510484110", hash: "0xece36e26c793976f290cfc3c23f624159dfb0fddae2f3aa5b4b8f7f919c20be9", nonce: "330175", blockHash: "0x0df28d08f61af498c286264a7de9ca1a46f8f98194c8698e4ebc05829f00302b", transactionIndex: "44", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa503592275523c6c45d1f7eeeee0576136d57609d1f536b16428bd30024bc1c5904000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000003763d300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212205d7cbb3fe67e76bbb3660744a4e11ce897e1c605b220b06235ef910a50faa525000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2441626", gasUsed: "43564", confirmations: "3199431"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x3592275523c6c45d1f7eeeee0576136d57609d1f536b16428bd30024bc1c5904"}, {type: "string", name: "_result", value: `v=0`}, {type: "bytes", name: "proof", value: "0x12205d7cbb3fe67e76bbb3660744a4e11ce897e1c605b220b06235ef910a50faa525"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x3592275523c6c45d1f7eeeee0576136d57609d1f536b16428bd30024bc1c5904", `v=0`, "0x12205d7cbb3fe67e76bbb3660744a4e11ce897e1c605b220b06235ef910a50faa525", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510484110 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x3592275523c6c45d1f7eeeee0576136d57609d1f536b16428bd30024bc1c5904"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [11]}}, {name: "amount", type: "uint256", value: "0"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x1c8960b25e4795ab93c53dfa9a9493edf13b... )", async function( ) {
		const txOriginal = {blockNumber: "4538411", timeStamp: "1510485688", hash: "0xf7d857b09d2daafd7ef625b2587e964c9dfa053f9f57437bdd0ee001dcfe7c98", nonce: "330181", blockHash: "0x90f875016f4fc2af7a1cc4ec999edc6bd246f691662c11540e2aae742cae4534", transactionIndex: "122", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa501c8960b25e4795ab93c53dfa9a9493edf13ba2b1c59a16294b88d8ec490d40af000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000b763d373233333132313332000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212204bf1089493b1d0d2306103a689537500f7d5610294c72504258904f02e0cee64000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4613083", gasUsed: "128841", confirmations: "3199314"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x1c8960b25e4795ab93c53dfa9a9493edf13ba2b1c59a16294b88d8ec490d40af"}, {type: "string", name: "_result", value: `v=723312132`}, {type: "bytes", name: "proof", value: "0x12204bf1089493b1d0d2306103a689537500f7d5610294c72504258904f02e0cee64"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x1c8960b25e4795ab93c53dfa9a9493edf13ba2b1c59a16294b88d8ec490d40af", `v=723312132`, "0x12204bf1089493b1d0d2306103a689537500f7d5610294c72504258904f02e0cee64", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510485688 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x1c8960b25e4795ab93c53dfa9a9493edf13ba2b1c59a16294b88d8ec490d40af"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [13]}}, {name: "amount", type: "uint256", value: "723312132"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x874ea1fc4239ae67e23d6622a50f8b4e07b2... )", async function( ) {
		const txOriginal = {blockNumber: "4538454", timeStamp: "1510486213", hash: "0xfe67d444820de8af99e5f4d76ebed0d48c76e44e0308cea3943df3f62bd91b1a", nonce: "330185", blockHash: "0x34f9ee8733daa72de4d08e687ca2cbcc20dca2d9bcc0b004b41eb2a956e5f17d", transactionIndex: "45", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50874ea1fc4239ae67e23d6622a50f8b4e07b2ece4c30937073716e3dc0ecb1ab6000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000b763d33303839373930303000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220bb3abf87130b1bb52d1a255c33c23a0419123b5d926a83e911c1cb68b1ce356a000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1326656", gasUsed: "113905", confirmations: "3199271"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x874ea1fc4239ae67e23d6622a50f8b4e07b2ece4c30937073716e3dc0ecb1ab6"}, {type: "string", name: "_result", value: `v=308979000`}, {type: "bytes", name: "proof", value: "0x1220bb3abf87130b1bb52d1a255c33c23a0419123b5d926a83e911c1cb68b1ce356a"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x874ea1fc4239ae67e23d6622a50f8b4e07b2ece4c30937073716e3dc0ecb1ab6", `v=308979000`, "0x1220bb3abf87130b1bb52d1a255c33c23a0419123b5d926a83e911c1cb68b1ce356a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510486213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x874ea1fc4239ae67e23d6622a50f8b4e07b2ece4c30937073716e3dc0ecb1ab6"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [14]}}, {name: "amount", type: "uint256", value: "308979000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xa27efb42d5f9d033357a03e08353f51e3c37... )", async function( ) {
		const txOriginal = {blockNumber: "4538529", timeStamp: "1510487266", hash: "0x7c43a2da3f56718801cee4d0a062b91f400216df009180d0e0c99e26c3a121bc", nonce: "330192", blockHash: "0xd9e0fa8d2ea0d0a2fbda6fd081af19e45a817f431e495bf1d0140beeb27492ab", transactionIndex: "32", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50a27efb42d5f9d033357a03e08353f51e3c376c60ab24ca014917db0d61ea54dc000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000052763d373534333434323737313626723d3078333130386638386364346266643961323265656535616339623461333061373831303363663862373563663636366364386633393865643937386131623163610000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212206c6943357978bf5c90ca5a4bece0f3a53b4bf11edd394349545a645c1f9ea49a000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1283648", gasUsed: "187516", confirmations: "3199196"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xa27efb42d5f9d033357a03e08353f51e3c376c60ab24ca014917db0d61ea54dc"}, {type: "string", name: "_result", value: `v=75434427716&r=0x3108f88cd4bfd9a22eee5ac9b4a30a78103cf8b75cf666cd8f398ed978a1b1ca`}, {type: "bytes", name: "proof", value: "0x12206c6943357978bf5c90ca5a4bece0f3a53b4bf11edd394349545a645c1f9ea49a"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xa27efb42d5f9d033357a03e08353f51e3c376c60ab24ca014917db0d61ea54dc", `v=75434427716&r=0x3108f88cd4bfd9a22eee5ac9b4a30a78103cf8b75cf666cd8f398ed978a1b1ca`, "0x12206c6943357978bf5c90ca5a4bece0f3a53b4bf11edd394349545a645c1f9ea49a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510487266 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xa27efb42d5f9d033357a03e08353f51e3c376c60ab24ca014917db0d61ea54dc"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [15]}}, {name: "amount", type: "uint256", value: "75434427716"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x6a33a5e84792d0e60fc1ca905478d128b851... )", async function( ) {
		const txOriginal = {blockNumber: "4538533", timeStamp: "1510487349", hash: "0xdf444e4781485162e89e044656f6fde6f6b72520265375f443f84ffbc5dd4f09", nonce: "330194", blockHash: "0xc9c021490496c0198b1fa19e76fa8c7384651f0cb31634a749865e5370ae7044", transactionIndex: "68", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa506a33a5e84792d0e60fc1ca905478d128b8518d486436d6d08261679ebb2ab663000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000051763d3232303431363133383226723d307833313038663838636434626664396132326565653561633962346133306137383130336366386237356366363636636438663339386564393738613162316361000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212208b2818e56f4ae1c958da3bb85b7e31d8f44c960c566680f2d033ac28485596d8000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2955631", gasUsed: "157059", confirmations: "3199192"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x6a33a5e84792d0e60fc1ca905478d128b8518d486436d6d08261679ebb2ab663"}, {type: "string", name: "_result", value: `v=2204161382&r=0x3108f88cd4bfd9a22eee5ac9b4a30a78103cf8b75cf666cd8f398ed978a1b1ca`}, {type: "bytes", name: "proof", value: "0x12208b2818e56f4ae1c958da3bb85b7e31d8f44c960c566680f2d033ac28485596d8"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x6a33a5e84792d0e60fc1ca905478d128b8518d486436d6d08261679ebb2ab663", `v=2204161382&r=0x3108f88cd4bfd9a22eee5ac9b4a30a78103cf8b75cf666cd8f398ed978a1b1ca`, "0x12208b2818e56f4ae1c958da3bb85b7e31d8f44c960c566680f2d033ac28485596d8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510487349 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x6a33a5e84792d0e60fc1ca905478d128b8518d486436d6d08261679ebb2ab663"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [16]}}, {name: "amount", type: "uint256", value: "2204161382"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x63661f6120d41cbba0485a61ad8d808ad775... )", async function( ) {
		const txOriginal = {blockNumber: "4538542", timeStamp: "1510487433", hash: "0x297bbb244373503775735c861178dc2f8cfa48a952460b81c413f1568e41bb30", nonce: "330196", blockHash: "0xddfa469781dce9f0ffc1fde285335676faf4dfe96111cd0a7f0462b263dd0991", transactionIndex: "134", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5063661f6120d41cbba0485a61ad8d808ad7755c8b0eeaa623256c986fb851a4e8000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000051763d3433303630313238393026723d307833313038663838636434626664396132326565653561633962346133306137383130336366386237356366363636636438663339386564393738613162316361000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212203fe532f1779767c9be84b65b5461e8a163a5cd4ee5effe37084e75d39fe025c4000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3781590", gasUsed: "157059", confirmations: "3199183"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x63661f6120d41cbba0485a61ad8d808ad7755c8b0eeaa623256c986fb851a4e8"}, {type: "string", name: "_result", value: `v=4306012890&r=0x3108f88cd4bfd9a22eee5ac9b4a30a78103cf8b75cf666cd8f398ed978a1b1ca`}, {type: "bytes", name: "proof", value: "0x12203fe532f1779767c9be84b65b5461e8a163a5cd4ee5effe37084e75d39fe025c4"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x63661f6120d41cbba0485a61ad8d808ad7755c8b0eeaa623256c986fb851a4e8", `v=4306012890&r=0x3108f88cd4bfd9a22eee5ac9b4a30a78103cf8b75cf666cd8f398ed978a1b1ca`, "0x12203fe532f1779767c9be84b65b5461e8a163a5cd4ee5effe37084e75d39fe025c4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510487433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x63661f6120d41cbba0485a61ad8d808ad7755c8b0eeaa623256c986fb851a4e8"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [17]}}, {name: "amount", type: "uint256", value: "4306012890"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4cc25835845c05876ddb8346e2a19233dfe5... )", async function( ) {
		const txOriginal = {blockNumber: "4538685", timeStamp: "1510489390", hash: "0xa515e99ef77efcc7813d0bda5269eee999293116e527b7e590916e22ff56bf51", nonce: "330210", blockHash: "0x50f0a66d60a0f0855ff6d25eb295d44b62cbe8566f9799382e02561fecbddd93", transactionIndex: "22", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa504cc25835845c05876ddb8346e2a19233dfe5dc496af3de8d2ca3cfa6a10fed5a000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004f763d393336383331333926723d307836383166613866616437353139633566336332393234613434393235323330626162393131316339393433383731323264396164306131383663613464326431000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220f9343431cd69879c994ddc28d61858320ac2fba5f95c4ea8beaa829c3c08fa8c000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "958762", gasUsed: "185921", confirmations: "3199040"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x4cc25835845c05876ddb8346e2a19233dfe5dc496af3de8d2ca3cfa6a10fed5a"}, {type: "string", name: "_result", value: `v=93683139&r=0x681fa8fad7519c5f3c2924a44925230bab9111c994387122d9ad0a186ca4d2d1`}, {type: "bytes", name: "proof", value: "0x1220f9343431cd69879c994ddc28d61858320ac2fba5f95c4ea8beaa829c3c08fa8c"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x4cc25835845c05876ddb8346e2a19233dfe5dc496af3de8d2ca3cfa6a10fed5a", `v=93683139&r=0x681fa8fad7519c5f3c2924a44925230bab9111c994387122d9ad0a186ca4d2d1`, "0x1220f9343431cd69879c994ddc28d61858320ac2fba5f95c4ea8beaa829c3c08fa8c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510489390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x4cc25835845c05876ddb8346e2a19233dfe5dc496af3de8d2ca3cfa6a10fed5a"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [18]}}, {name: "amount", type: "uint256", value: "93683139"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x597c5a6ab5cd12313147c0917c5600d0c8d4... )", async function( ) {
		const txOriginal = {blockNumber: "4538689", timeStamp: "1510489447", hash: "0xeeb0f19c919240f66664bee8e68648991ce2d7f97552cba636da6e49c54d7fa4", nonce: "330212", blockHash: "0xcb696698aa5713a790c541c4f45835c2cf5b799755179efd65034a596780abf7", transactionIndex: "79", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50597c5a6ab5cd12313147c0917c5600d0c8d44ee0b9b1c34c43ca67a8a5a8b9c2000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000050763d33313031353530303726723d3078313138343137666639326230613839303761316330363733633638326464616165613133376536646538333539383438393831343435376535626133363339350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220ad9f517fda95b8abc4b9cbcac50b35a69186c86af628b5ac9469baff13455129000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3197482", gasUsed: "186258", confirmations: "3199036"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x597c5a6ab5cd12313147c0917c5600d0c8d44ee0b9b1c34c43ca67a8a5a8b9c2"}, {type: "string", name: "_result", value: `v=310155007&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`}, {type: "bytes", name: "proof", value: "0x1220ad9f517fda95b8abc4b9cbcac50b35a69186c86af628b5ac9469baff13455129"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x597c5a6ab5cd12313147c0917c5600d0c8d44ee0b9b1c34c43ca67a8a5a8b9c2", `v=310155007&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`, "0x1220ad9f517fda95b8abc4b9cbcac50b35a69186c86af628b5ac9469baff13455129", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510489447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x597c5a6ab5cd12313147c0917c5600d0c8d44ee0b9b1c34c43ca67a8a5a8b9c2"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [19]}}, {name: "amount", type: "uint256", value: "310155007"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xdb12179fb7c48fb2c782b31dca1eb1715118... )", async function( ) {
		const txOriginal = {blockNumber: "4538760", timeStamp: "1510490487", hash: "0x430fb8f9403d92900789a54e19c3e0a87a62998bd6304e06925aff7b52335fa5", nonce: "330221", blockHash: "0x202fe5c913b66dfdd4b12614aad54c60e612c7072c8f55c6561a2a24012b18ef", transactionIndex: "66", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50db12179fb7c48fb2c782b31dca1eb171511882cf84b050af6eca4792c4de7ab6000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000006763d33323233000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220e1af71fc85159a0e57ee58c8d48b5905b8052dea3cb17c99102d3fc445d29fa9000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3685705", gasUsed: "126620", confirmations: "3198965"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xdb12179fb7c48fb2c782b31dca1eb171511882cf84b050af6eca4792c4de7ab6"}, {type: "string", name: "_result", value: `v=3223`}, {type: "bytes", name: "proof", value: "0x1220e1af71fc85159a0e57ee58c8d48b5905b8052dea3cb17c99102d3fc445d29fa9"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xdb12179fb7c48fb2c782b31dca1eb171511882cf84b050af6eca4792c4de7ab6", `v=3223`, "0x1220e1af71fc85159a0e57ee58c8d48b5905b8052dea3cb17c99102d3fc445d29fa9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510490487 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xdb12179fb7c48fb2c782b31dca1eb171511882cf84b050af6eca4792c4de7ab6"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [20]}}, {name: "amount", type: "uint256", value: "3223"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x0618e1cf85d37554d3197296f26878b06ded... )", async function( ) {
		const txOriginal = {blockNumber: "4538909", timeStamp: "1510492291", hash: "0x744e6adc0fcc17db1b26df44da9af58cddcf9bb59f7d71e6ad2ec8a5ea53df31", nonce: "330244", blockHash: "0xb77361dcb0c60e3cbe8d0da7044b96c763833cfe9745c1381f45f783d36d3f8e", transactionIndex: "72", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa500618e1cf85d37554d3197296f26878b06ded79ed96a5b776cae79016232ca98b000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000050763d32303732353136363026723d30786434353135366462393966346261633664633739613366636132336531633731643531366534383833623830306432326330323061343363633761346533323200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212204e14c04269418e3952a387e064ad08c2d242e937bb3f5789623b461a077f42b3000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2298429", gasUsed: "186490", confirmations: "3198816"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x0618e1cf85d37554d3197296f26878b06ded79ed96a5b776cae79016232ca98b"}, {type: "string", name: "_result", value: `v=207251660&r=0xd45156db99f4bac6dc79a3fca23e1c71d516e4883b800d22c020a43cc7a4e322`}, {type: "bytes", name: "proof", value: "0x12204e14c04269418e3952a387e064ad08c2d242e937bb3f5789623b461a077f42b3"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x0618e1cf85d37554d3197296f26878b06ded79ed96a5b776cae79016232ca98b", `v=207251660&r=0xd45156db99f4bac6dc79a3fca23e1c71d516e4883b800d22c020a43cc7a4e322`, "0x12204e14c04269418e3952a387e064ad08c2d242e937bb3f5789623b461a077f42b3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510492291 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x0618e1cf85d37554d3197296f26878b06ded79ed96a5b776cae79016232ca98b"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [21]}}, {name: "amount", type: "uint256", value: "207251660"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4ddb0aaac02d5edcf35bf7e5d4933055792a... )", async function( ) {
		const txOriginal = {blockNumber: "4539075", timeStamp: "1510494862", hash: "0xcaa22f16483a993898f752534e6191ec9c22f09b8283ef5a512af9cb4242280c", nonce: "330256", blockHash: "0x412d7a4bef63cabb42571c6bb7359b57df6f5a9e67f935d66aba5003c2a7ec61", transactionIndex: "75", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa504ddb0aaac02d5edcf35bf7e5d4933055792ab2fedb4401b416d692d23cb832ea000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000b763d31303030303030303000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220d347a105361bb367f9fe05bc64c1c8ec167b72284f2865bcaa3a8401056423d4000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2322579", gasUsed: "128905", confirmations: "3198650"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x4ddb0aaac02d5edcf35bf7e5d4933055792ab2fedb4401b416d692d23cb832ea"}, {type: "string", name: "_result", value: `v=100000000`}, {type: "bytes", name: "proof", value: "0x1220d347a105361bb367f9fe05bc64c1c8ec167b72284f2865bcaa3a8401056423d4"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x4ddb0aaac02d5edcf35bf7e5d4933055792ab2fedb4401b416d692d23cb832ea", `v=100000000`, "0x1220d347a105361bb367f9fe05bc64c1c8ec167b72284f2865bcaa3a8401056423d4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510494862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x4ddb0aaac02d5edcf35bf7e5d4933055792ab2fedb4401b416d692d23cb832ea"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [22]}}, {name: "amount", type: "uint256", value: "100000000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x6cb9f8027ebe3fedbe4578f487f50b2e4e29... )", async function( ) {
		const txOriginal = {blockNumber: "4539109", timeStamp: "1510495377", hash: "0x818c3efe9a05746e363899c5243bf78c95762f61192341de3c211703844bc961", nonce: "330258", blockHash: "0xbd020be4e970e7466e3295bcc855fe7d5f9afff638e49f95aacd8120749ed588", transactionIndex: "76", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa506cb9f8027ebe3fedbe4578f487f50b2e4e29587295ba6145eddd0dc13737dba2000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d763d31303030303035303030300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220f76baa423655753f1dbe76cebcc5cef50eba38ff1b4f8d39b88aedcdea3b873f000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2279581", gasUsed: "114819", confirmations: "3198616"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x6cb9f8027ebe3fedbe4578f487f50b2e4e29587295ba6145eddd0dc13737dba2"}, {type: "string", name: "_result", value: `v=10000050000`}, {type: "bytes", name: "proof", value: "0x1220f76baa423655753f1dbe76cebcc5cef50eba38ff1b4f8d39b88aedcdea3b873f"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x6cb9f8027ebe3fedbe4578f487f50b2e4e29587295ba6145eddd0dc13737dba2", `v=10000050000`, "0x1220f76baa423655753f1dbe76cebcc5cef50eba38ff1b4f8d39b88aedcdea3b873f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510495377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x6cb9f8027ebe3fedbe4578f487f50b2e4e29587295ba6145eddd0dc13737dba2"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [23]}}, {name: "amount", type: "uint256", value: "10000050000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xe383440e16f494524d9825e7d64d4c273680... )", async function( ) {
		const txOriginal = {blockNumber: "4539138", timeStamp: "1510495909", hash: "0x162c5fac56ef0f31201b7176b9fb841883d6311b4dfdb97999bcca5580e73e93", nonce: "330262", blockHash: "0x006de649e1900c0c51f8aabef2c12c9cd5e883a1c0e1182baaa0cf0c150e2b70", transactionIndex: "44", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50e383440e16f494524d9825e7d64d4c2736805d66e7b5f05578d372d0753a2df9000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000003763d30000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220aba83726aee032064f1c663ca4aef89fd8fd32d9517569a6d60d460ad3f497f8000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1300171", gasUsed: "43628", confirmations: "3198587"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xe383440e16f494524d9825e7d64d4c2736805d66e7b5f05578d372d0753a2df9"}, {type: "string", name: "_result", value: `v=0`}, {type: "bytes", name: "proof", value: "0x1220aba83726aee032064f1c663ca4aef89fd8fd32d9517569a6d60d460ad3f497f8"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xe383440e16f494524d9825e7d64d4c2736805d66e7b5f05578d372d0753a2df9", `v=0`, "0x1220aba83726aee032064f1c663ca4aef89fd8fd32d9517569a6d60d460ad3f497f8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510495909 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xe383440e16f494524d9825e7d64d4c2736805d66e7b5f05578d372d0753a2df9"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [24]}}, {name: "amount", type: "uint256", value: "0"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x1a07dc0468ddfbc464c78754b73e5f7eb6c6... )", async function( ) {
		const txOriginal = {blockNumber: "4539153", timeStamp: "1510496196", hash: "0x475c1de93da3bc4938bf506904256280819e9394ce15d5c3323740b49677c4ff", nonce: "330264", blockHash: "0x3f3d02707aa24eb84709fa27e90e2bc1538466c5907c1e836ea92a5a775d8099", transactionIndex: "86", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa501a07dc0468ddfbc464c78754b73e5f7eb6c681ab51fdd02f48e948f677ac34aa000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000003763d300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212205fcc80efb76b8aa1f5ced7cb9f5103a337bba5ed0c48b1c22af90139f2226edf000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3436983", gasUsed: "43628", confirmations: "3198572"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x1a07dc0468ddfbc464c78754b73e5f7eb6c681ab51fdd02f48e948f677ac34aa"}, {type: "string", name: "_result", value: `v=0`}, {type: "bytes", name: "proof", value: "0x12205fcc80efb76b8aa1f5ced7cb9f5103a337bba5ed0c48b1c22af90139f2226edf"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x1a07dc0468ddfbc464c78754b73e5f7eb6c681ab51fdd02f48e948f677ac34aa", `v=0`, "0x12205fcc80efb76b8aa1f5ced7cb9f5103a337bba5ed0c48b1c22af90139f2226edf", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510496196 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x1a07dc0468ddfbc464c78754b73e5f7eb6c681ab51fdd02f48e948f677ac34aa"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [25]}}, {name: "amount", type: "uint256", value: "0"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x0fdad797cdf3dc6f1fe9721d4b6877a0b371... )", async function( ) {
		const txOriginal = {blockNumber: "4539324", timeStamp: "1510498422", hash: "0x00b36e46c1d8eee9779c9c1d29a5d72217489a4256ce7ffdc62766b1bffaa143", nonce: "330281", blockHash: "0x820e1af1a066fa3424f0c9c5b3d2dc87970fb356c10369a81557fd1686aac2cf", transactionIndex: "102", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa500fdad797cdf3dc6f1fe9721d4b6877a0b3710c5868a555799196e3688b0c97af000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000050763d31393835343636393026723d30783638316661386661643735313963356633633239323461343439323532333062616239313131633939343338373132326439616430613138366361346432643100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212201a87536be83725dbcab736e25626cad3964e45e9ddb0f49ef8455959b5a096c7000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4306447", gasUsed: "171378", confirmations: "3198401"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x0fdad797cdf3dc6f1fe9721d4b6877a0b3710c5868a555799196e3688b0c97af"}, {type: "string", name: "_result", value: `v=198546690&r=0x681fa8fad7519c5f3c2924a44925230bab9111c994387122d9ad0a186ca4d2d1`}, {type: "bytes", name: "proof", value: "0x12201a87536be83725dbcab736e25626cad3964e45e9ddb0f49ef8455959b5a096c7"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x0fdad797cdf3dc6f1fe9721d4b6877a0b3710c5868a555799196e3688b0c97af", `v=198546690&r=0x681fa8fad7519c5f3c2924a44925230bab9111c994387122d9ad0a186ca4d2d1`, "0x12201a87536be83725dbcab736e25626cad3964e45e9ddb0f49ef8455959b5a096c7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510498422 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x0fdad797cdf3dc6f1fe9721d4b6877a0b3710c5868a555799196e3688b0c97af"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [26]}}, {name: "amount", type: "uint256", value: "198546690"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xac68e30a723122e8374cd699417493db9ffc... )", async function( ) {
		const txOriginal = {blockNumber: "4539340", timeStamp: "1510498754", hash: "0x38a2fb6c23be826e6bbb8b7672fe488712f8b02ba43b17565d934b1a995ae880", nonce: "330285", blockHash: "0x3d3c2db914eafe0d1b6d711175de631f7464d051a7451909ecf37a0dfa1c9382", transactionIndex: "119", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50ac68e30a723122e8374cd699417493db9ffc1f38ff52af60245354958d1f7891000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004e763d3236303030303026723d307833366432356334613463383763653863613330346635363865313366343463353563616662336461333235623139613631306431363037646239383631373134000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212207910c005ca6a0e1a538a4028116f77065d1bbccebbad51db19ab12e2cad9eab3000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5028810", gasUsed: "185520", confirmations: "3198385"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xac68e30a723122e8374cd699417493db9ffc1f38ff52af60245354958d1f7891"}, {type: "string", name: "_result", value: `v=2600000&r=0x36d25c4a4c87ce8ca304f568e13f44c55cafb3da325b19a610d1607db9861714`}, {type: "bytes", name: "proof", value: "0x12207910c005ca6a0e1a538a4028116f77065d1bbccebbad51db19ab12e2cad9eab3"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xac68e30a723122e8374cd699417493db9ffc1f38ff52af60245354958d1f7891", `v=2600000&r=0x36d25c4a4c87ce8ca304f568e13f44c55cafb3da325b19a610d1607db9861714`, "0x12207910c005ca6a0e1a538a4028116f77065d1bbccebbad51db19ab12e2cad9eab3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510498754 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xac68e30a723122e8374cd699417493db9ffc1f38ff52af60245354958d1f7891"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [27]}}, {name: "amount", type: "uint256", value: "2600000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xdb3ed137980d3a28e3735ca06a7518ba64e9... )", async function( ) {
		const txOriginal = {blockNumber: "4539531", timeStamp: "1510501535", hash: "0x1fb38e370a41516b18c0c0fdd3b837ea3291ca8c2d89718d08e6237978f0a710", nonce: "330305", blockHash: "0xec70dea1304417b2642b0aa1cd0e7527e7d4046e2b5607e162aa9b422d365901", transactionIndex: "79", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50db3ed137980d3a28e3735ca06a7518ba64e966a8317b9a7e677f375e54d130f7000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000c763d37353639393637303438000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220bb21f62366bc4e927de59210d72a912e57e02cdf6d492607736711dee58e84ee000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4214325", gasUsed: "129362", confirmations: "3198194"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xdb3ed137980d3a28e3735ca06a7518ba64e966a8317b9a7e677f375e54d130f7"}, {type: "string", name: "_result", value: `v=7569967048`}, {type: "bytes", name: "proof", value: "0x1220bb21f62366bc4e927de59210d72a912e57e02cdf6d492607736711dee58e84ee"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xdb3ed137980d3a28e3735ca06a7518ba64e966a8317b9a7e677f375e54d130f7", `v=7569967048`, "0x1220bb21f62366bc4e927de59210d72a912e57e02cdf6d492607736711dee58e84ee", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510501535 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xdb3ed137980d3a28e3735ca06a7518ba64e966a8317b9a7e677f375e54d130f7"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [28]}}, {name: "amount", type: "uint256", value: "7569967048"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xaae14020f1f1a96e5dc701b624939e500d7c... )", async function( ) {
		const txOriginal = {blockNumber: "4539536", timeStamp: "1510501631", hash: "0xaa03d29cb9b519c43b3b6317a037463f5f6c5d2165d949fa3a922bdfc98448e2", nonce: "330307", blockHash: "0x5c6046e4e2f8ad31eee984b63139e1d5edc93bb41cf7f3fd73c468ea35b918a2", transactionIndex: "76", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50aae14020f1f1a96e5dc701b624939e500d7c37ba2f5a20d43a30b25e15991735000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000051763d3633353832373532383126723d307831313834313766663932623061383930376131633036373363363832646461616561313337653664653833353938343839383134343537653562613336333935000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212200a0663a1fa08ebe199d13c8dbbaf98bd367ba13f60d6273bfbdde19cd3c8f8cf000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4362404", gasUsed: "171779", confirmations: "3198189"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xaae14020f1f1a96e5dc701b624939e500d7c37ba2f5a20d43a30b25e15991735"}, {type: "string", name: "_result", value: `v=6358275281&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`}, {type: "bytes", name: "proof", value: "0x12200a0663a1fa08ebe199d13c8dbbaf98bd367ba13f60d6273bfbdde19cd3c8f8cf"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xaae14020f1f1a96e5dc701b624939e500d7c37ba2f5a20d43a30b25e15991735", `v=6358275281&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`, "0x12200a0663a1fa08ebe199d13c8dbbaf98bd367ba13f60d6273bfbdde19cd3c8f8cf", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510501631 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xaae14020f1f1a96e5dc701b624939e500d7c37ba2f5a20d43a30b25e15991735"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [29]}}, {name: "amount", type: "uint256", value: "6358275281"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xc57bcbb734224455392ad225061e2e76c508... )", async function( ) {
		const txOriginal = {blockNumber: "4539548", timeStamp: "1510501794", hash: "0x82b12e52ae3b14b8966f91a5cec446dba8024024cd033efcc812715813eb85d4", nonce: "330308", blockHash: "0xa0bef208a3c8c6c1c8ac59e9bc7a8eae219288ca3f32c206cbe1844fc6d37ea5", transactionIndex: "36", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50c57bcbb734224455392ad225061e2e76c5087f903f1620381348d3f7a1e3e884000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000c763d32363037333535303030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220ee82611614cae007f8a82f5788a59d1e4b88deacc750036d16927f20f23f2773000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1127446", gasUsed: "114362", confirmations: "3198177"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xc57bcbb734224455392ad225061e2e76c5087f903f1620381348d3f7a1e3e884"}, {type: "string", name: "_result", value: `v=2607355000`}, {type: "bytes", name: "proof", value: "0x1220ee82611614cae007f8a82f5788a59d1e4b88deacc750036d16927f20f23f2773"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xc57bcbb734224455392ad225061e2e76c5087f903f1620381348d3f7a1e3e884", `v=2607355000`, "0x1220ee82611614cae007f8a82f5788a59d1e4b88deacc750036d16927f20f23f2773", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510501794 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xc57bcbb734224455392ad225061e2e76c5087f903f1620381348d3f7a1e3e884"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [30]}}, {name: "amount", type: "uint256", value: "2607355000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x90d29cc25d92d9037e2a047024ce8e113e40... )", async function( ) {
		const txOriginal = {blockNumber: "4539866", timeStamp: "1510506484", hash: "0x2c72bbcf4e5157b84d9dd1decfbee9f8767375cabd262ddee0d4e747daaff426", nonce: "330367", blockHash: "0xb763c5eb1fbf7b4b52c2f36f0472e02a3ac143331e1a9c2256491848bc40d098", transactionIndex: "72", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5090d29cc25d92d9037e2a047024ce8e113e4087a98dc8b2407799aa0a74a76e2b000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004f763d313132363334393826723d307862323861383361376437386539343865353238653965356338663536613932343734646332373935666532373333323732376366623363643036323363393633000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220c3ec4ddac29f7c80c52674ca2b9cb10135a9a1abe8d09d982ef9c482240f1473000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3936139", gasUsed: "185921", confirmations: "3197859"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x90d29cc25d92d9037e2a047024ce8e113e4087a98dc8b2407799aa0a74a76e2b"}, {type: "string", name: "_result", value: `v=11263498&r=0xb28a83a7d78e948e528e9e5c8f56a92474dc2795fe27332727cfb3cd0623c963`}, {type: "bytes", name: "proof", value: "0x1220c3ec4ddac29f7c80c52674ca2b9cb10135a9a1abe8d09d982ef9c482240f1473"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x90d29cc25d92d9037e2a047024ce8e113e4087a98dc8b2407799aa0a74a76e2b", `v=11263498&r=0xb28a83a7d78e948e528e9e5c8f56a92474dc2795fe27332727cfb3cd0623c963`, "0x1220c3ec4ddac29f7c80c52674ca2b9cb10135a9a1abe8d09d982ef9c482240f1473", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510506484 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x90d29cc25d92d9037e2a047024ce8e113e4087a98dc8b2407799aa0a74a76e2b"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [31]}}, {name: "amount", type: "uint256", value: "11263498"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x45f9030aa31b0f3e4d71687bb1830b1f1f33... )", async function( ) {
		const txOriginal = {blockNumber: "4540155", timeStamp: "1510510854", hash: "0xf423e371da4bf8941fb03fd4bc194870833a7aeb4bea4493209908ff3aada2e3", nonce: "330417", blockHash: "0x4aed4baacee879db81c8fde11605bb2afcd6bdc7465ff019b0705349c10ff886", transactionIndex: "135", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5045f9030aa31b0f3e4d71687bb1830b1f1f33ff6845a52659983ebd171b8ec1e9000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000a763d38343336373437360000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220bd88059980b34de9e7c842f5c8018a116a9e321e05d2e1211927369b5660a6a9000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6003251", gasUsed: "128448", confirmations: "3197570"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x45f9030aa31b0f3e4d71687bb1830b1f1f33ff6845a52659983ebd171b8ec1e9"}, {type: "string", name: "_result", value: `v=84367476`}, {type: "bytes", name: "proof", value: "0x1220bd88059980b34de9e7c842f5c8018a116a9e321e05d2e1211927369b5660a6a9"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x45f9030aa31b0f3e4d71687bb1830b1f1f33ff6845a52659983ebd171b8ec1e9", `v=84367476`, "0x1220bd88059980b34de9e7c842f5c8018a116a9e321e05d2e1211927369b5660a6a9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510510854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x45f9030aa31b0f3e4d71687bb1830b1f1f33ff6845a52659983ebd171b8ec1e9"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [32]}}, {name: "amount", type: "uint256", value: "84367476"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x2d2b5172d5ad2cde96d27abcef9225ebe191... )", async function( ) {
		const txOriginal = {blockNumber: "4540200", timeStamp: "1510511551", hash: "0x808c3d0d39af4d8fb3b1cf0bbd3f948c21e24b66e38ba0838817bb8ed4b8a100", nonce: "330429", blockHash: "0x3343ba2de9d0f9a2c7482c1bfa471fbca4cf18940026f4204dec645c78ce0fd8", transactionIndex: "65", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa502d2b5172d5ad2cde96d27abcef9225ebe19107aabea8a226539e1178f6f04861000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004d763d37363030303026723d30783131383431376666393262306138393037613163303637336336383264646161656131333765366465383335393834383938313434353765356261333633393500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212206ceb8c9776c41d405957c67ce9564e9477a55950ffc1217a30cee69ad43b5fe1000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2671852", gasUsed: "169951", confirmations: "3197525"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x2d2b5172d5ad2cde96d27abcef9225ebe19107aabea8a226539e1178f6f04861"}, {type: "string", name: "_result", value: `v=760000&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`}, {type: "bytes", name: "proof", value: "0x12206ceb8c9776c41d405957c67ce9564e9477a55950ffc1217a30cee69ad43b5fe1"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x2d2b5172d5ad2cde96d27abcef9225ebe19107aabea8a226539e1178f6f04861", `v=760000&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`, "0x12206ceb8c9776c41d405957c67ce9564e9477a55950ffc1217a30cee69ad43b5fe1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510511551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x2d2b5172d5ad2cde96d27abcef9225ebe19107aabea8a226539e1178f6f04861"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [33]}}, {name: "amount", type: "uint256", value: "760000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x0fb70e797f855aa36b572b937e1cac089c54... )", async function( ) {
		const txOriginal = {blockNumber: "4540405", timeStamp: "1510514455", hash: "0xe6eb5756260508d8ca5ff3810cd67b3d3d3762454d40f8d540cc1cf330bad350", nonce: "330468", blockHash: "0x9d3d2f9c9f300811ec10c01e209cff40161f3a6bada784d0bf2f12dc3f71312c", transactionIndex: "60", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa500fb70e797f855aa36b572b937e1cac089c545ba43a083e27099189da93828c9c000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000008763d3734303030300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122058a4311344a1a50a111559fdf18d89239dd3db29c8da4492a458ce78957d637b000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1839421", gasUsed: "112534", confirmations: "3197320"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x0fb70e797f855aa36b572b937e1cac089c545ba43a083e27099189da93828c9c"}, {type: "string", name: "_result", value: `v=740000`}, {type: "bytes", name: "proof", value: "0x122058a4311344a1a50a111559fdf18d89239dd3db29c8da4492a458ce78957d637b"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x0fb70e797f855aa36b572b937e1cac089c545ba43a083e27099189da93828c9c", `v=740000`, "0x122058a4311344a1a50a111559fdf18d89239dd3db29c8da4492a458ce78957d637b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510514455 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x0fb70e797f855aa36b572b937e1cac089c545ba43a083e27099189da93828c9c"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [34]}}, {name: "amount", type: "uint256", value: "740000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xeceda93bfd2fa6860781f075b371d0b13352... )", async function( ) {
		const txOriginal = {blockNumber: "4540466", timeStamp: "1510515251", hash: "0x0111b8ad15a11a065988da139aecb7f26976136b25fe13d7d8c932896b750bbf", nonce: "330472", blockHash: "0x543344897c7f20c37338a695de37b3ebb60c494f5e8dcbcfbffed5c935e668e5", transactionIndex: "74", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50eceda93bfd2fa6860781f075b371d0b1335228506fa64378110d47f600c28173000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000051763d3239393936323931303826723d307831313834313766663932623061383930376131633036373363363832646461616561313337653664653833353938343839383134343537653562613336333935000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212209e4660330037fb1f1e8b8f59a21cffe6d735e52ab58a4daf812b5290ad26789b000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2983822", gasUsed: "171651", confirmations: "3197259"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xeceda93bfd2fa6860781f075b371d0b1335228506fa64378110d47f600c28173"}, {type: "string", name: "_result", value: `v=2999629108&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`}, {type: "bytes", name: "proof", value: "0x12209e4660330037fb1f1e8b8f59a21cffe6d735e52ab58a4daf812b5290ad26789b"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xeceda93bfd2fa6860781f075b371d0b1335228506fa64378110d47f600c28173", `v=2999629108&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`, "0x12209e4660330037fb1f1e8b8f59a21cffe6d735e52ab58a4daf812b5290ad26789b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510515251 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xeceda93bfd2fa6860781f075b371d0b1335228506fa64378110d47f600c28173"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [35]}}, {name: "amount", type: "uint256", value: "2999629108"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x906d25010516618c3375d855c6744bc74ea8... )", async function( ) {
		const txOriginal = {blockNumber: "4540503", timeStamp: "1510515668", hash: "0x4cb199d3301eac53f99b5b9c575efc15b0e8b9e433e72a2bd3c75539d229daf3", nonce: "330473", blockHash: "0x83bdc3fdfdcf93a62db66337eaa3aaa8f293cbae257adcd3ae6430977ee6295d", transactionIndex: "46", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50906d25010516618c3375d855c6744bc74ea8152d582d6dcd41d8fd392777d65f000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000050763d31303031323936333226723d30783037666562313335333338343965356563363937656634363562366635616637316136383166653162383764643039643364373231333737613438623631356500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212207561693b10f5dd999901093732050baf1572c807570fe92261c4fc41b3937be2000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1547950", gasUsed: "186434", confirmations: "3197222"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x906d25010516618c3375d855c6744bc74ea8152d582d6dcd41d8fd392777d65f"}, {type: "string", name: "_result", value: `v=100129632&r=0x07feb13533849e5ec697ef465b6f5af71a681fe1b87dd09d3d721377a48b615e`}, {type: "bytes", name: "proof", value: "0x12207561693b10f5dd999901093732050baf1572c807570fe92261c4fc41b3937be2"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x906d25010516618c3375d855c6744bc74ea8152d582d6dcd41d8fd392777d65f", `v=100129632&r=0x07feb13533849e5ec697ef465b6f5af71a681fe1b87dd09d3d721377a48b615e`, "0x12207561693b10f5dd999901093732050baf1572c807570fe92261c4fc41b3937be2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510515668 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x906d25010516618c3375d855c6744bc74ea8152d582d6dcd41d8fd392777d65f"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [36]}}, {name: "amount", type: "uint256", value: "100129632"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfa91829aabf3fe6ce26eb954371dbcad7788... )", async function( ) {
		const txOriginal = {blockNumber: "4540724", timeStamp: "1510518672", hash: "0xb4ffd33d01c0fd06aad4a1c3e57e432f549a734fedee2ef7c6562c4ca2ad9660", nonce: "330480", blockHash: "0x532447d32c6b831eedb5b3f28ec0af03f652f65e55dab8fd5efe3ef3e4554359", transactionIndex: "11", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50fa91829aabf3fe6ce26eb954371dbcad7788d3a1b6984b74bc75f34e3dfc8b57000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004f763d383034323737343326723d307831313834313766663932623061383930376131633036373363363832646461616561313337653664653833353938343839383134343537653562613336333935000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220211e85fa1e41f42a1c98433f76be994a250e66bbbd55b55036229dabc10912c5000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "537619", gasUsed: "170865", confirmations: "3197001"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xfa91829aabf3fe6ce26eb954371dbcad7788d3a1b6984b74bc75f34e3dfc8b57"}, {type: "string", name: "_result", value: `v=80427743&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`}, {type: "bytes", name: "proof", value: "0x1220211e85fa1e41f42a1c98433f76be994a250e66bbbd55b55036229dabc10912c5"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xfa91829aabf3fe6ce26eb954371dbcad7788d3a1b6984b74bc75f34e3dfc8b57", `v=80427743&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`, "0x1220211e85fa1e41f42a1c98433f76be994a250e66bbbd55b55036229dabc10912c5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510518672 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xfa91829aabf3fe6ce26eb954371dbcad7788d3a1b6984b74bc75f34e3dfc8b57"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [37]}}, {name: "amount", type: "uint256", value: "80427743"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x4deb492a8b7ee2591c7c9afc573741a63590... )", async function( ) {
		const txOriginal = {blockNumber: "4541126", timeStamp: "1510524127", hash: "0x9c0ba73c2ff948efc3cf9e2f197ba4d1d6d39cf3c35bda0625dce7ac201e576e", nonce: "330541", blockHash: "0xbb514f56de89ddf206467281151de4087c830bc313ac504638f6305d72126f53", transactionIndex: "164", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa504deb492a8b7ee2591c7c9afc573741a63590e63ef1956b8ca523799e65a301b9000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004f763d313037393437393926723d307831313834313766663932623061383930376131633036373363363832646461616561313337653664653833353938343839383134343537653562613336333935000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220897975389d8fe43228df3be0ca71f758d64da6a32fa0724fe5665b5216accda5000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5917829", gasUsed: "170865", confirmations: "3196599"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x4deb492a8b7ee2591c7c9afc573741a63590e63ef1956b8ca523799e65a301b9"}, {type: "string", name: "_result", value: `v=10794799&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`}, {type: "bytes", name: "proof", value: "0x1220897975389d8fe43228df3be0ca71f758d64da6a32fa0724fe5665b5216accda5"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x4deb492a8b7ee2591c7c9afc573741a63590e63ef1956b8ca523799e65a301b9", `v=10794799&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`, "0x1220897975389d8fe43228df3be0ca71f758d64da6a32fa0724fe5665b5216accda5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510524127 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x4deb492a8b7ee2591c7c9afc573741a63590e63ef1956b8ca523799e65a301b9"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [38]}}, {name: "amount", type: "uint256", value: "10794799"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xbee8657a7bc30ffec294e51e7cb02710dfe8... )", async function( ) {
		const txOriginal = {blockNumber: "4541157", timeStamp: "1510524584", hash: "0x04aa2884779942965bcc5325fc74e1f3b3defd5ea9204e4b60d59b28c0d3155b", nonce: "330544", blockHash: "0xe7fb6be2d5a6e4e441e55e6fc60517b67097db77b80e79e5eb5273776a2331fd", transactionIndex: "31", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50bee8657a7bc30ffec294e51e7cb02710dfe8cc7927c79884f0f33136eef50440000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004c763d313038363026723d307831313834313766663932623061383930376131633036373363363832646461616561313337653664653833353938343839383134343537653562613336333935000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220fd30854ca21dc151d3b3f5c9f477a04e006659207e6eb3f5588f54c368c13edb000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1866594", gasUsed: "154430", confirmations: "3196568"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xbee8657a7bc30ffec294e51e7cb02710dfe8cc7927c79884f0f33136eef50440"}, {type: "string", name: "_result", value: `v=10860&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`}, {type: "bytes", name: "proof", value: "0x1220fd30854ca21dc151d3b3f5c9f477a04e006659207e6eb3f5588f54c368c13edb"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xbee8657a7bc30ffec294e51e7cb02710dfe8cc7927c79884f0f33136eef50440", `v=10860&r=0x118417ff92b0a8907a1c0673c682ddaaea137e6de83598489814457e5ba36395`, "0x1220fd30854ca21dc151d3b3f5c9f477a04e006659207e6eb3f5588f54c368c13edb", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510524584 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xbee8657a7bc30ffec294e51e7cb02710dfe8cc7927c79884f0f33136eef50440"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [39]}}, {name: "amount", type: "uint256", value: "10860"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x44326fde560f7fe708c6c1fb4112b5f73661... )", async function( ) {
		const txOriginal = {blockNumber: "4541245", timeStamp: "1510526160", hash: "0x7065c91426c6c9fc8446f8c85e220067b0f5c5ebdbf4e61c9e31f6fda1385c8e", nonce: "330566", blockHash: "0xd780e20a6f86dff3e33549530d63b48258c87e74d85087ffad8030c359d76a29", transactionIndex: "65", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa5044326fde560f7fe708c6c1fb4112b5f736614e5702e4283c7caee0f5e4826330000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d763d3330303030303030303030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122031e89ac15a6a31d8b76210dcca145fd48e716c62ccef387699755c4267c45383000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4764047", gasUsed: "114819", confirmations: "3196480"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x44326fde560f7fe708c6c1fb4112b5f736614e5702e4283c7caee0f5e4826330"}, {type: "string", name: "_result", value: `v=30000000000`}, {type: "bytes", name: "proof", value: "0x122031e89ac15a6a31d8b76210dcca145fd48e716c62ccef387699755c4267c45383"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x44326fde560f7fe708c6c1fb4112b5f736614e5702e4283c7caee0f5e4826330", `v=30000000000`, "0x122031e89ac15a6a31d8b76210dcca145fd48e716c62ccef387699755c4267c45383", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510526160 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x44326fde560f7fe708c6c1fb4112b5f736614e5702e4283c7caee0f5e4826330"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [40]}}, {name: "amount", type: "uint256", value: "30000000000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x3197cc6684a907b98a747d3266455494c3c8... )", async function( ) {
		const txOriginal = {blockNumber: "4541271", timeStamp: "1510526446", hash: "0x2780ac6cd71f8c2675260b99bd6336bc821208e3af17817185dd1b10648714b4", nonce: "330573", blockHash: "0xd61a01aea9ddeae60064e0f57f65df6a619766d1c15929c1c3d9084b2d8e702a", transactionIndex: "56", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa503197cc6684a907b98a747d3266455494c3c8000ca51f189425405c7a5e23f087000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000d763d3330303030303530303030000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122021e1359ca80c167912e9b2d41a0e04ad02c3a8af8709189f64c7157073e5d63e000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1562292", gasUsed: "114755", confirmations: "3196454"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x3197cc6684a907b98a747d3266455494c3c8000ca51f189425405c7a5e23f087"}, {type: "string", name: "_result", value: `v=30000050000`}, {type: "bytes", name: "proof", value: "0x122021e1359ca80c167912e9b2d41a0e04ad02c3a8af8709189f64c7157073e5d63e"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x3197cc6684a907b98a747d3266455494c3c8000ca51f189425405c7a5e23f087", `v=30000050000`, "0x122021e1359ca80c167912e9b2d41a0e04ad02c3a8af8709189f64c7157073e5d63e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510526446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x3197cc6684a907b98a747d3266455494c3c8000ca51f189425405c7a5e23f087"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [41]}}, {name: "amount", type: "uint256", value: "30000050000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xafd5802e40d5c1764a739343a403e3fbe907... )", async function( ) {
		const txOriginal = {blockNumber: "4541436", timeStamp: "1510528639", hash: "0x13b5ae53e72b453c41a9e7319e1b8644f7c7ab485f810d89e51f198b9217dc59", nonce: "330617", blockHash: "0x2604552d664ac0a91490438a6b69d3f099611d30795590dcb40e73c94fd21531", transactionIndex: "29", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50afd5802e40d5c1764a739343a403e3fbe907178bb6594eac3d7654aaec62dd29000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000003763d30000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220a0370f22b5f94dcf68bdfcdb464793e4196870ef2ffc3005a49df9d0ab23ef47000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2256903", gasUsed: "43628", confirmations: "3196289"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xafd5802e40d5c1764a739343a403e3fbe907178bb6594eac3d7654aaec62dd29"}, {type: "string", name: "_result", value: `v=0`}, {type: "bytes", name: "proof", value: "0x1220a0370f22b5f94dcf68bdfcdb464793e4196870ef2ffc3005a49df9d0ab23ef47"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xafd5802e40d5c1764a739343a403e3fbe907178bb6594eac3d7654aaec62dd29", `v=0`, "0x1220a0370f22b5f94dcf68bdfcdb464793e4196870ef2ffc3005a49df9d0ab23ef47", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510528639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xafd5802e40d5c1764a739343a403e3fbe907178bb6594eac3d7654aaec62dd29"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [42]}}, {name: "amount", type: "uint256", value: "0"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x727d22e44c384564208a82407d00ce6dafa7... )", async function( ) {
		const txOriginal = {blockNumber: "4541501", timeStamp: "1510529435", hash: "0xccc44faedada0e9878240da3a3bffca7f3353f52ba48c8df43f2b4950521e78e", nonce: "330632", blockHash: "0x33cde97c1ead2c1b5eca0ffc4dd3828e546ffce41c59944cbfb24edccea8cdd5", transactionIndex: "103", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50727d22e44c384564208a82407d00ce6dafa735190568f5fd8c1f3cef1b88382f000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004d763d33393630373426723d3078633632383135396264393065373062663665333564626336376637666432313863313466346534643930643230363434643732326262323539313637343061320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220c9a84974a38e153d76a61b674bea8eb6d350e6b68ced54bb140916deefdd6df4000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6245229", gasUsed: "184971", confirmations: "3196224"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x727d22e44c384564208a82407d00ce6dafa735190568f5fd8c1f3cef1b88382f"}, {type: "string", name: "_result", value: `v=396074&r=0xc628159bd90e70bf6e35dbc67f7fd218c14f4e4d90d20644d722bb25916740a2`}, {type: "bytes", name: "proof", value: "0x1220c9a84974a38e153d76a61b674bea8eb6d350e6b68ced54bb140916deefdd6df4"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x727d22e44c384564208a82407d00ce6dafa735190568f5fd8c1f3cef1b88382f", `v=396074&r=0xc628159bd90e70bf6e35dbc67f7fd218c14f4e4d90d20644d722bb25916740a2`, "0x1220c9a84974a38e153d76a61b674bea8eb6d350e6b68ced54bb140916deefdd6df4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510529435 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x727d22e44c384564208a82407d00ce6dafa735190568f5fd8c1f3cef1b88382f"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [43]}}, {name: "amount", type: "uint256", value: "396074"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x154e196f1761a4e65e2e67e3dbb266954804... )", async function( ) {
		const txOriginal = {blockNumber: "4541525", timeStamp: "1510529671", hash: "0x583b1e146ea2691313c2adf9ef63eda63ac6bac99fefc0a99481f8f5ce208b2b", nonce: "330641", blockHash: "0x8f741a404d78b6d8d0e9d9969c13fc1cfa086aeb3d44523ca6e31fd0fae676f0", transactionIndex: "39", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50154e196f1761a4e65e2e67e3dbb26695480437a7002765428153beea6995fef0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000050763d33303030303030303026723d3078633632383135396264393065373062663665333564626336376637666432313863313466346534643930643230363434643732326262323539313637343061320000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220fe7aa64f82c3b87c0f323eac150b538961ea5a5c300770ef578e43878ab698c7000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1807693", gasUsed: "156342", confirmations: "3196200"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x154e196f1761a4e65e2e67e3dbb26695480437a7002765428153beea6995fef0"}, {type: "string", name: "_result", value: `v=300000000&r=0xc628159bd90e70bf6e35dbc67f7fd218c14f4e4d90d20644d722bb25916740a2`}, {type: "bytes", name: "proof", value: "0x1220fe7aa64f82c3b87c0f323eac150b538961ea5a5c300770ef578e43878ab698c7"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x154e196f1761a4e65e2e67e3dbb26695480437a7002765428153beea6995fef0", `v=300000000&r=0xc628159bd90e70bf6e35dbc67f7fd218c14f4e4d90d20644d722bb25916740a2`, "0x1220fe7aa64f82c3b87c0f323eac150b538961ea5a5c300770ef578e43878ab698c7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510529671 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x154e196f1761a4e65e2e67e3dbb26695480437a7002765428153beea6995fef0"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [44]}}, {name: "amount", type: "uint256", value: "300000000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x7d2c4f1e287bf5fcce2bc64b447527cd9628... )", async function( ) {
		const txOriginal = {blockNumber: "4541592", timeStamp: "1510530437", hash: "0xa8256b30f03901bff13b1ed4ddcfed8e8b5fce766817bcd5701df63e3b5e6857", nonce: "330658", blockHash: "0x7df9e067f7989a72686b427c4d7df10ae0d4ab89accec703cf41514ff906b6ee", transactionIndex: "10", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa507d2c4f1e287bf5fcce2bc64b447527cd9628a3a5a98cef8ffb02c4251302ea9e000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000051763d3135303030303030303026723d3078346663323364376566633864646430366466346264313861653032363838303739373235643539343030313963633032333431373631326664356539616530300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022122012d0f7c94f9835eb357b8fdc557d406e22871e61a25207e3da8925169ab97f20000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "783032", gasUsed: "171891", confirmations: "3196133"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x7d2c4f1e287bf5fcce2bc64b447527cd9628a3a5a98cef8ffb02c4251302ea9e"}, {type: "string", name: "_result", value: `v=1500000000&r=0x4fc23d7efc8ddd06df4bd18ae02688079725d5940019cc023417612fd5e9ae00`}, {type: "bytes", name: "proof", value: "0x122012d0f7c94f9835eb357b8fdc557d406e22871e61a25207e3da8925169ab97f20"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x7d2c4f1e287bf5fcce2bc64b447527cd9628a3a5a98cef8ffb02c4251302ea9e", `v=1500000000&r=0x4fc23d7efc8ddd06df4bd18ae02688079725d5940019cc023417612fd5e9ae00`, "0x122012d0f7c94f9835eb357b8fdc557d406e22871e61a25207e3da8925169ab97f20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510530437 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x7d2c4f1e287bf5fcce2bc64b447527cd9628a3a5a98cef8ffb02c4251302ea9e"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [45]}}, {name: "amount", type: "uint256", value: "1500000000"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0x9fe60b026c64cb36451bc5d7adb7103df8c5... )", async function( ) {
		const txOriginal = {blockNumber: "4542367", timeStamp: "1510541396", hash: "0x7d9372469bc7eaa80c3285d3f45de738ca5eecf3343e07f0f77b42de8769d66e", nonce: "330923", blockHash: "0xfd35d87b2f325701d4b659c345714db28b67b660fb7b9cecb4c6ca966db53f0a", transactionIndex: "15", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa509fe60b026c64cb36451bc5d7adb7103df8c50c1c8801e6c4fdc101a422b17873000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004e763d3238343230323426723d307834626339386133333739663436306361613837643433316133323339626365393930616538666237613432343839393963306530323030313732303765303063000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002212204c17a1be767a73507d6c7d1ee6266b3cd90136423ae753f32e3eddc1cb2b7685000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "607155", gasUsed: "185464", confirmations: "3195358"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0x9fe60b026c64cb36451bc5d7adb7103df8c50c1c8801e6c4fdc101a422b17873"}, {type: "string", name: "_result", value: `v=2842024&r=0x4bc98a3379f460caa87d431a3239bce990ae8fb7a4248999c0e020017207e00c`}, {type: "bytes", name: "proof", value: "0x12204c17a1be767a73507d6c7d1ee6266b3cd90136423ae753f32e3eddc1cb2b7685"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0x9fe60b026c64cb36451bc5d7adb7103df8c50c1c8801e6c4fdc101a422b17873", `v=2842024&r=0x4bc98a3379f460caa87d431a3239bce990ae8fb7a4248999c0e020017207e00c`, "0x12204c17a1be767a73507d6c7d1ee6266b3cd90136423ae753f32e3eddc1cb2b7685", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510541396 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0x9fe60b026c64cb36451bc5d7adb7103df8c50c1c8801e6c4fdc101a422b17873"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [46]}}, {name: "amount", type: "uint256", value: "2842024"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: __callback( \"0xfab75a3114bf947e4678c8204ec32bd84e84... )", async function( ) {
		const txOriginal = {blockNumber: "4543088", timeStamp: "1510551009", hash: "0x6a4e660af8cd4aa8ed2e3c46aeb0a486746e770e54f71e329753f5d36c4b13fa", nonce: "331061", blockHash: "0xe698ccc5aa0c1ecb733ba229de2c5fcc97d6c4bc155a588dfe20aec319988726", transactionIndex: "23", from: "0x26588a9301b0428d95e6fc3a5024fce8bec12d51", to: "0x05852e51e7c86333510327c64d8dddc9d2264d24", value: "0", gas: "200000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x38bbfa50fab75a3114bf947e4678c8204ec32bd84e846d81aaad0b3eebed200b18b120ef000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000051763d3331303834313133393326723d30783037666562313335333338343965356563363937656634363562366635616637316136383166653162383764643039643364373231333737613438623631356500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000221220a4af6eed33387744132b9248622a2a6facabc1fe79bf217d0cc0194a3e656e32000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "965478", gasUsed: "156891", confirmations: "3194637"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes32", name: "_queryId", value: "0xfab75a3114bf947e4678c8204ec32bd84e846d81aaad0b3eebed200b18b120ef"}, {type: "string", name: "_result", value: `v=3108411393&r=0x07feb13533849e5ec697ef465b6f5af71a681fe1b87dd09d3d721377a48b615e`}, {type: "bytes", name: "proof", value: "0x1220a4af6eed33387744132b9248622a2a6facabc1fe79bf217d0cc0194a3e656e32"}], name: "__callback", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "__callback(bytes32,string,bytes)" ]( "0xfab75a3114bf947e4678c8204ec32bd84e846d81aaad0b3eebed200b18b120ef", `v=3108411393&r=0x07feb13533849e5ec697ef465b6f5af71a681fe1b87dd09d3d721377a48b615e`, "0x1220a4af6eed33387744132b9248622a2a6facabc1fe79bf217d0cc0194a3e656e32", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510551009 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "queryId", type: "bytes32"}, {indexed: false, name: "requestId", type: "uint64"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "resultCode", type: "uint8"}], name: "LogReceiveQuery", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogReceiveQuery", events: [{name: "queryId", type: "bytes32", value: "0xfab75a3114bf947e4678c8204ec32bd84e846d81aaad0b3eebed200b18b120ef"}, {name: "requestId", type: "uint64", value: {s: 1, e: 1, c: [47]}}, {name: "amount", type: "uint256", value: "3108411393"}, {name: "resultCode", type: "uint8", value: "0"}], address: "0x05852e51e7c86333510327c64d8dddc9d2264d24"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "14316257042202350" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
