const MainContract = artifacts.require( "./MainContract.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "MainContract" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x73B4C7B80DFFd2Ad1b54A192f56c8c7eDcbF12Ba", "0x172EE25f09D63334CB42eFAcBE206C15978533fF", "0x7d544cF03152eead818cD1bFEe63E41e58508D40", "0x6F7988f576146044cEe254683539B3CBD8FD3135", "0x333F1949f995EE0BdEA3CEc8B9C332a544260AFc", "0xE64417956Ba078715055A9793852615e9A8BbE6A", "0x564286362092D8e7936f0549571a803B203aAceD", "0xA469DFB88d9aef1d456E92904E45e6b7d9FAeAb1", "0xB42f90b683a941663a3B0d3F04398AaabA96A402", "0x2b854d07940e285Fb4F3cdA266D16C9bb840aa61", "0xbf4E10fB6d08fA8669bd33723cF38E2eFCF0341B", "0x04fEFdAbC8130CeC593F1A2296b430D5D56CB8F0"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}, {indexed: true, name: "addr", type: "address"}], name: "logsDataPayable", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "creater", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "text", type: "string"}], name: "logsDataConstructor", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "newInvestor", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "creater", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "text", type: "string"}], name: "investToProject", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayBonus", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "text", type: "string"}], name: "notEnoughETH", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["logsDataPayable(uint256,uint256,address)", "logsDataConstructor(address,uint256,string)", "newInvestor(address,uint256,uint256)", "investToProject(address,uint256,string)", "logPaymentUser(uint256,uint256,address,string)", "logPayDividends(uint256,uint256,address,string)", "logPayBonus(uint256,uint256,address,string)", "notEnoughETH(uint256,string)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x6928248aab57c99590f3f74ae8443e73f1d1c9198b02955c7d4c0949efb68f28", "0x9940e597a94db4a412d9def09f3afc4b3ed749121f2faa18a7b3447e7269d73b", "0x41b2121cb66467389a85e7715af1dca7be90f6c83b647a80cefccd3000d5a1e1", "0x4d859389697ff0cf7acc5113f2d02fb1cb30b586eded2a051ed049370ea97cef", "0x9ee03a2b75c69923a70215b5c0bafed98e95d75f7bf286bfb980d09c79aeb93b", "0x541ccf0a06c67351c775f1cb1629c24c22fe874efc4c4aa8f2177349d27ffdbd", "0xf3af8519cd4099eb27793b20329e75e9d13eae2448e33ff32d7f172342290d5d", "0xbc28346f7285e9d3e7e2d2488475c3fdb6503820989a060bf6e9e5c9b04b6f57"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6642518 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6744926 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "MainContract", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
}

contract( "MainContract", function( accounts ) {

	it( "TEST: MainContract(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6642518", timeStamp: "1541342411", hash: "0x74cc6de30acb0220c716e0ac894df3abc4a223f446d2cfc53c85db810232a8dc", nonce: "2", blockHash: "0xcf297b7b67716b7468d150aa2ae0874931205d3ed38e1dae53abcf220a478083", transactionIndex: "90", from: "0x172ee25f09d63334cb42efacbe206c15978533ff", to: 0, value: "0", gas: "962021", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0xb516cf2e", contractAddress: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", cumulativeGasUsed: "7098461", gasUsed: "962021", confirmations: "1081277"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "MainContract", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = MainContract.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541342411 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = MainContract.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "creater", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "text", type: "string"}], name: "logsDataConstructor", type: "event"} ;
		console.error( "eventCallOriginal[0,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logsDataConstructor", events: [{name: "creater", type: "address", value: "0x172ee25f09d63334cb42efacbe206c15978533ff"}, {name: "when", type: "uint256", value: "1541342411"}, {name: "text", type: "string", value: "constructor"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[0,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "784229923246090557" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setAdvertisingAddress( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "6642523", timeStamp: "1541342513", hash: "0x1e84ceae9eeee7c50d874f0a05c5f5c29dc497a4fa45151fa10c29b44efb5e48", nonce: "3", blockHash: "0x057465b22d7ea5f89a8d6f066fb3fe67f691543b0b1498d68c1d46e860dc7a63", transactionIndex: "9", from: "0x172ee25f09d63334cb42efacbe206c15978533ff", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "43502", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0xcb192f2c0000000000000000000000007d544cf03152eead818cd1bfee63e41e58508d40", contractAddress: "", cumulativeGasUsed: "758874", gasUsed: "43502", confirmations: "1081272"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[4]}], name: "setAdvertisingAddress", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAdvertisingAddress(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541342513 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "784229923246090557" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6642548", timeStamp: "1541342906", hash: "0xd306933ef2b08212ebc604ccd6eaa158ea53866d65f1ba4d8689dc761e653dc2", nonce: "5", blockHash: "0x60c4072b136ab9122fafe95a1b52179cb2db0ffc0231c922e7b01a9a2e9fd3d4", transactionIndex: "35", from: "0x7d544cf03152eead818cd1bfee63e41e58508d40", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "200000000000000000", gas: "200000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1360409", gasUsed: "117432", confirmations: "1081247"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541342906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}, {indexed: true, name: "addr", type: "address"}], name: "logsDataPayable", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logsDataPayable", events: [{name: "value", type: "uint256", value: "200000000000000000"}, {name: "time", type: "uint256", value: "1541342906"}, {name: "addr", type: "address", value: "0x7d544cf03152eead818cd1bfee63e41e58508d40"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "newInvestor", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newInvestor", events: [{name: "addr", type: "address", value: "0x7d544cf03152eead818cd1bfee63e41e58508d40"}, {name: "when", type: "uint256", value: "1541342906"}, {name: "value", type: "uint256", value: "200000000000000000"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "362658752000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6654825", timeStamp: "1541518381", hash: "0x3a389fb1b6c2bf0e2932e84f4dfe7b7286c52e396c4888eee5b90511f58dbd60", nonce: "2", blockHash: "0x26126f8a1f103e30c9043aa64fc25a45b3c20af4d4d306bff8e8edb42be3390a", transactionIndex: "119", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "350000000000000000", gas: "200000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2920749", gasUsed: "117432", confirmations: "1068970"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "350000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541518381 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}, {indexed: true, name: "addr", type: "address"}], name: "logsDataPayable", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logsDataPayable", events: [{name: "value", type: "uint256", value: "350000000000000000"}, {name: "time", type: "uint256", value: "1541518381"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "newInvestor", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newInvestor", events: [{name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "when", type: "uint256", value: "1541518381"}, {name: "value", type: "uint256", value: "350000000000000000"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6654868", timeStamp: "1541519059", hash: "0x302d5108a575e4181bfd509cc593ee4425a7f2855c0e3f5f8a921f3598a65098", nonce: "0", blockHash: "0xf1c4adbe6a74358b254f584d98eb2df18a48687afb6657be7147148371566b64", transactionIndex: "55", from: "0x333f1949f995ee0bdea3cec8b9c332a544260afc", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "900000000000000000", gas: "200000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2225792", gasUsed: "117432", confirmations: "1068927"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "900000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541519059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}, {indexed: true, name: "addr", type: "address"}], name: "logsDataPayable", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logsDataPayable", events: [{name: "value", type: "uint256", value: "900000000000000000"}, {name: "time", type: "uint256", value: "1541519059"}, {name: "addr", type: "address", value: "0x333f1949f995ee0bdea3cec8b9c332a544260afc"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "newInvestor", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newInvestor", events: [{name: "addr", type: "address", value: "0x333f1949f995ee0bdea3cec8b9c332a544260afc"}, {name: "when", type: "uint256", value: "1541519059"}, {name: "value", type: "uint256", value: "900000000000000000"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "165039648000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6655767", timeStamp: "1541531779", hash: "0x58fabdc6a0599e71bb34faa75d4f8b126acfca33a11caa9ce860b71d6fd9ea85", nonce: "3", blockHash: "0xdfeaf0144c91494e3d01d7653d20e904e88f6b68d00188799d086d0f22364409", transactionIndex: "8", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "200000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "230686", gasUsed: "62584", confirmations: "1068028"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541531779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[5,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "3"}, {name: "when", type: "uint256", value: "1541531779"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[5,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "3500000000000000"}, {name: "when", type: "uint256", value: "1541531779"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6656474", timeStamp: "1541541546", hash: "0x3fc06c5e10136ff7e4911cce4117932f51ae69d6e1a34815d00f35dfdf2096fb", nonce: "4", blockHash: "0xca7a28ecbd24c635699288c809cb583bf73176a2e72c8fc9c22ed0baf98247c9", transactionIndex: "15", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "881847", gasUsed: "47584", confirmations: "1067321"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541541546 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[6,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "5"}, {name: "when", type: "uint256", value: "1541541546"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[6,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "2333333333333333"}, {name: "when", type: "uint256", value: "1541541546"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6658888", timeStamp: "1541576466", hash: "0x681a512caa02d4424afaac9a8e71cab96e04e77bd46ada27cc889cf9713a1b7e", nonce: "5", blockHash: "0xdc7f41b33721dfe6219056bc960fed587ecd08760d7956950fb458be2bb5bcc5", transactionIndex: "120", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2893717", gasUsed: "47584", confirmations: "1064907"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541576466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "14"}, {name: "when", type: "uint256", value: "1541576466"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "10500000000000000"}, {name: "when", type: "uint256", value: "1541576466"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6660722", timeStamp: "1541602057", hash: "0x2d6444249cf9adea82bd42337d2e51bbaecf92834da43b2b5338e3858c35cba4", nonce: "6", blockHash: "0xd4c9a9d8827efd23fffad0716728a00206bf5f3a595ca681f10a740d0917ec8c", transactionIndex: "18", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "542064", gasUsed: "47584", confirmations: "1063073"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541602057 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[8,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "21"}, {name: "when", type: "uint256", value: "1541602057"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[8,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "8166666666666666"}, {name: "when", type: "uint256", value: "1541602057"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6660879", timeStamp: "1541604238", hash: "0x0a4cb6153b53322e9bf0d21bb164cbdddd986a4da4bccb42e8cd2016a16918dc", nonce: "1", blockHash: "0x6ba6f64bcba21484699fe6c46902ed73b8427cbdf0c5f26fe2b09c320757e46b", transactionIndex: "30", from: "0x333f1949f995ee0bdea3cec8b9c332a544260afc", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "200000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1249538", gasUsed: "62584", confirmations: "1062916"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541604238 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[9,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "23"}, {name: "when", type: "uint256", value: "1541604238"}, {name: "addr", type: "address", value: "0x333f1949f995ee0bdea3cec8b9c332a544260afc"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[9,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "69000000000000000"}, {name: "when", type: "uint256", value: "1541604238"}, {name: "addr", type: "address", value: "0x333f1949f995ee0bdea3cec8b9c332a544260afc"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "165039648000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6661772", timeStamp: "1541616554", hash: "0xc3ec10a4470377d42cf78ce2686ba59928bd929ded6fb755a64172ec452795fd", nonce: "7", blockHash: "0x7fb605fa9081a4a1d799de1af9d903512b87bee2c84ee4c903a36bb0903e5617", transactionIndex: "9", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "378956", gasUsed: "47584", confirmations: "1062023"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541616554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "25"}, {name: "when", type: "uint256", value: "1541616554"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "4666666666666666"}, {name: "when", type: "uint256", value: "1541616554"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6662406", timeStamp: "1541625731", hash: "0xcbb7853e03d9564f7283c410df9ea9922592628ed8fe1643953dbc16b6149b89", nonce: "0", blockHash: "0xd0d2543968dd93ce474e4e1bec25a847bfa47bf0a3ec9842b3caf4abed1490ee", transactionIndex: "54", from: "0xe64417956ba078715055a9793852615e9a8bbe6a", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "40000000000000000", gas: "200000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x6f7988f576146044cee254683539b3cbd8fd3135", contractAddress: "", cumulativeGasUsed: "1394288", gasUsed: "140584", confirmations: "1061389"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541625731 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}, {indexed: true, name: "addr", type: "address"}], name: "logsDataPayable", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logsDataPayable", events: [{name: "value", type: "uint256", value: "40000000000000000"}, {name: "time", type: "uint256", value: "1541625731"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "newInvestor", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newInvestor", events: [{name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "when", type: "uint256", value: "1541625731"}, {name: "value", type: "uint256", value: "40000000000000000"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "299553000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6663067", timeStamp: "1541634419", hash: "0x8df9246cccd2023342d698a5d6c07f4663c6b4c0fab2e6bcc1dc052a300468a0", nonce: "9", blockHash: "0x69b8dfa0fea9acbad31a963d69ce8515d5559e0d7a65e82a65ab3e7a27d5debb", transactionIndex: "13", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "52711", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "372502", gasUsed: "37711", confirmations: "1060728"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541634419 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[12,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "29"}, {name: "when", type: "uint256", value: "1541634419"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[12,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[12,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "6266666666666666"}, {name: "when", type: "uint256", value: "1541634419"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends with bonus"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[12,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6666669", timeStamp: "1541685911", hash: "0x5811d8d73e2463aab7ee8e8148a92a390cbd2f348c31fff4ac9032035bb1611b", nonce: "10", blockHash: "0xb15b85be66f9987c362a801d3f84d1b9f3a7618f19ba4cdd9422cfec728dc65f", transactionIndex: "28", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "886541", gasUsed: "47584", confirmations: "1057126"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541685911 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "43"}, {name: "when", type: "uint256", value: "1541685911"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[13,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "16333333333333333"}, {name: "when", type: "uint256", value: "1541685911"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[13,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6668029", timeStamp: "1541705159", hash: "0xdc7453860aee9f24976e1fee0c40c8675631a04b3645866eb93b4c2aa11c2acb", nonce: "1006437", blockHash: "0xc4eee1884e5d0f47f33d6fb2af538b9154125ef58ba91512f422586928fe8ba9", transactionIndex: "14", from: "0x564286362092d8e7936f0549571a803b203aaced", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "87781400000000000", gas: "117972", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "525136", gasUsed: "117432", confirmations: "1055766"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "87781400000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541705159 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}, {indexed: true, name: "addr", type: "address"}], name: "logsDataPayable", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logsDataPayable", events: [{name: "value", type: "uint256", value: "87781400000000000"}, {name: "time", type: "uint256", value: "1541705159"}, {name: "addr", type: "address", value: "0x564286362092d8e7936f0549571a803b203aaced"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "newInvestor", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newInvestor", events: [{name: "addr", type: "address", value: "0x564286362092d8e7936f0549571a803b203aaced"}, {name: "when", type: "uint256", value: "1541705159"}, {name: "value", type: "uint256", value: "87781400000000000"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "11317754231087110276771" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6668909", timeStamp: "1541717396", hash: "0xc4cae0842b3e1cc86f4e3a52309f0751f79da708e21e0d4fe92019289b257df9", nonce: "2", blockHash: "0x0ee9894a1423e8895d1fda7ab2dfbcc1d324876c15dcbab847d3b190c2dd21b4", transactionIndex: "35", from: "0xe64417956ba078715055a9793852615e9a8bbe6a", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "64800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1437417", gasUsed: "62584", confirmations: "1054886"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541717396 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[15,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "25"}, {name: "when", type: "uint256", value: "1541717396"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[15,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "3400000000000000"}, {name: "when", type: "uint256", value: "1541717396"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "299553000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6671165", timeStamp: "1541750195", hash: "0xbd52d6e9142a8a36ecf1fcf1e4e5253e10744439a3ee004e13dbfed632a7885a", nonce: "12", blockHash: "0x8d095ca6b8454725a6071de81be3e8f4bf85eadf660b98ca9065de0b88e56338", transactionIndex: "15", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "458378", gasUsed: "47584", confirmations: "1052630"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541750195 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[16,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "60"}, {name: "when", type: "uint256", value: "1541750195"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[16,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "19833333333333333"}, {name: "when", type: "uint256", value: "1541750195"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6673441", timeStamp: "1541781973", hash: "0xcb2acfeb8f7a2269e52ae27e3b699c00c8311ff84f77f64b37a0d095e6b77b04", nonce: "1", blockHash: "0xc8a75959079ff265a57a22eca05611effcf75172028f9551e2065380eccb69e1", transactionIndex: "23", from: "0xa469dfb88d9aef1d456e92904e45e6b7d9faeab1", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "10000000000000000", gas: "21000", gasPrice: "52000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "749713", gasUsed: "21000", confirmations: "1050354"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "15388000000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6676923", timeStamp: "1541831165", hash: "0x42503e0718e79cf2e84de1159bf0ae0a867d518a01c6d01e230b28fd8c957dbb", nonce: "13", blockHash: "0xe660c581adb37595d77ae4b23ada1f8e9195e11d92a9b571aebf372fae442dbd", transactionIndex: "11", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "552683", gasUsed: "47584", confirmations: "1046872"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541831165 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "82"}, {name: "when", type: "uint256", value: "1541831165"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "25666666666666666"}, {name: "when", type: "uint256", value: "1541831165"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6677334", timeStamp: "1541837065", hash: "0x444023e2b17d255d709672645169a61d258b811d88e7bf877c29f3a5577f19f5", nonce: "3", blockHash: "0x448d468bfc34d3cdbf2206f6c206f857d8422ea878306af87e7ac3cd4f5fbe96", transactionIndex: "12", from: "0xe64417956ba078715055a9793852615e9a8bbe6a", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "469245", gasUsed: "47584", confirmations: "1046461"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541837065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[19,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "58"}, {name: "when", type: "uint256", value: "1541837065"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[19,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "4488000000000000"}, {name: "when", type: "uint256", value: "1541837065"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "299553000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6683457", timeStamp: "1541923461", hash: "0x926868d3e5959ff08d228fcfefaa82adf9e158a7bf6b83b99d2aeebc39bce1ae", nonce: "14", blockHash: "0xbc2156f5e00cfbaab9f1af4a4c52ba39c65f06d7369a8418aa72c55531aad368", transactionIndex: "29", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1146908", gasUsed: "47584", confirmations: "1040338"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541923461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[20,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "107"}, {name: "when", type: "uint256", value: "1541923461"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[20,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "29166666666666666"}, {name: "when", type: "uint256", value: "1541923461"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6683731", timeStamp: "1541927652", hash: "0x2233462ce9b390c0abc897a59e14611a4055782000504f0cc47c6ea9a35c4e3c", nonce: "9", blockHash: "0x16f0f1ee503e806cde9c4de2a495044972670b68486aab8e2883e1570a230612", transactionIndex: "87", from: "0xb42f90b683a941663a3b0d3f04398aaaba96a402", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "10000000000000000", gas: "200000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x6f7988f576146044cee254683539b3cbd8fd3135", contractAddress: "", cumulativeGasUsed: "5110159", gasUsed: "140584", confirmations: "1040064"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541927652 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}, {indexed: true, name: "addr", type: "address"}], name: "logsDataPayable", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logsDataPayable", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "time", type: "uint256", value: "1541927652"}, {name: "addr", type: "address", value: "0xb42f90b683a941663a3b0d3f04398aaaba96a402"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "newInvestor", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newInvestor", events: [{name: "addr", type: "address", value: "0xb42f90b683a941663a3b0d3f04398aaaba96a402"}, {name: "when", type: "uint256", value: "1541927652"}, {name: "value", type: "uint256", value: "10000000000000000"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "13667666477671678" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6684177", timeStamp: "1541933866", hash: "0x503303ad15cdb1e18731a1bf2ef70d9c5664f6d113b216301168295efef57b09", nonce: "10", blockHash: "0x9479f707c6b0d7fc40ae847becc991e0417a8d558d08ed65e57de3af900025a4", transactionIndex: "97", from: "0xb42f90b683a941663a3b0d3f04398aaaba96a402", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "200000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4409438", gasUsed: "62584", confirmations: "1039618"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541933866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "1"}, {name: "when", type: "uint256", value: "1541933866"}, {name: "addr", type: "address", value: "0xb42f90b683a941663a3b0d3f04398aaaba96a402"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "34000000000000"}, {name: "when", type: "uint256", value: "1541933866"}, {name: "addr", type: "address", value: "0xb42f90b683a941663a3b0d3f04398aaaba96a402"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "13667666477671678" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6686067", timeStamp: "1541960173", hash: "0x648da4d6f5d6f91d62ec9b53c56a216a54e2c18b32a1687744532e43667b868f", nonce: "4", blockHash: "0x1763c0e97284edc62ef114abcad20f36b4029a78b0002b45d96a78da70ab38ea", transactionIndex: "5", from: "0xe64417956ba078715055a9793852615e9a8bbe6a", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "152584", gasUsed: "47584", confirmations: "1037728"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541960173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[23,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "92"}, {name: "when", type: "uint256", value: "1541960173"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[23,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "4624000000000000"}, {name: "when", type: "uint256", value: "1541960173"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "299553000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6686145", timeStamp: "1541961394", hash: "0x699295610b4fca41b30037ee9a8522fd6b56869c90d8d45989b4f521f1d87d83", nonce: "0", blockHash: "0x4beca7a2e814d289319897f30a59ac57c4231c0a4d37e3cec21edb374abdd1f2", transactionIndex: "3", from: "0x2b854d07940e285fb4f3cda266d16c9bb840aa61", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "78000000000000000", gas: "200000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "213164", gasUsed: "117432", confirmations: "1037650"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "78000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541961394 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}, {indexed: true, name: "addr", type: "address"}], name: "logsDataPayable", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logsDataPayable", events: [{name: "value", type: "uint256", value: "78000000000000000"}, {name: "time", type: "uint256", value: "1541961394"}, {name: "addr", type: "address", value: "0x2b854d07940e285fb4f3cda266d16c9bb840aa61"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "newInvestor", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newInvestor", events: [{name: "addr", type: "address", value: "0x2b854d07940e285fb4f3cda266d16c9bb840aa61"}, {name: "when", type: "uint256", value: "1541961394"}, {name: "value", type: "uint256", value: "78000000000000000"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "52776000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6689994", timeStamp: "1542016324", hash: "0x4bfbca5e4f06ce9b3fca4b906dee4e66d98b853b0a3fcedbdeb5b5cbd329b558", nonce: "16", blockHash: "0xcc4bb27ef167618a9401549567407e613922037d644f5d3d135a2e6019101fcc", transactionIndex: "2", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "52711", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "233533", gasUsed: "37711", confirmations: "1033801"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542016324 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[25,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "132"}, {name: "when", type: "uint256", value: "1542016324"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[25,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "29566666666666666"}, {name: "when", type: "uint256", value: "1542016324"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends with bonus"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6690347", timeStamp: "1542021084", hash: "0x7a6c7fff054e6d7a3006f109d4a7650dd382d99f5ee9794778ee0e951a313516", nonce: "215", blockHash: "0xaf871d349422410def7b3e645407d618d2c4d6f9896b1bf5eedc6a7da68a17db", transactionIndex: "84", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "500000000000000000", gas: "150000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2140258", gasUsed: "117432", confirmations: "1033448"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542021084 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}, {indexed: true, name: "addr", type: "address"}], name: "logsDataPayable", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "logsDataPayable", events: [{name: "value", type: "uint256", value: "500000000000000000"}, {name: "time", type: "uint256", value: "1542021084"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "when", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "newInvestor", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "newInvestor", events: [{name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "when", type: "uint256", value: "1542021084"}, {name: "value", type: "uint256", value: "500000000000000000"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6696006", timeStamp: "1542100046", hash: "0xc9d615664b0ab89e13f2bc502e102b242ffdd71aa03667dd38d934e01a587d0f", nonce: "17", blockHash: "0x3c59673a1fbfdf9412c6804ef5dc7523e9a32e6f2988377fe872e7fa5e5093a0", transactionIndex: "9", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "433316", gasUsed: "47584", confirmations: "1027789"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542100046 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "155"}, {name: "when", type: "uint256", value: "1542100046"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "26833333333333333"}, {name: "when", type: "uint256", value: "1542100046"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6696319", timeStamp: "1542104737", hash: "0xb2ed12e06afa5d88f62ffe18da4b17b223f16014ecb562a8c297c068e1238eef", nonce: "225", blockHash: "0x7d79408219634360cdb5cc083cb6688902e228f01e4bbb2754946663d92d864e", transactionIndex: "12", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "70000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "837627", gasUsed: "62584", confirmations: "1027476"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542104737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "23"}, {name: "when", type: "uint256", value: "1542104737"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "38333333333333333"}, {name: "when", type: "uint256", value: "1542104737"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6696880", timeStamp: "1542112784", hash: "0xdf9a73612760d888581c5ed12c6e5a73a9c08cd328f1e8c071786ce7698e75de", nonce: "6", blockHash: "0xe8b9def65863a3c03d9a41b147e160f59b03687f73032bd87b64c4620e1b1d5a", transactionIndex: "6", from: "0xe64417956ba078715055a9793852615e9a8bbe6a", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "295665", gasUsed: "47584", confirmations: "1026915"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542112784 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "134"}, {name: "when", type: "uint256", value: "1542112784"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[29,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "5712000000000000"}, {name: "when", type: "uint256", value: "1542112784"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[29,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "299553000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6696888", timeStamp: "1542112858", hash: "0xa7fc5c7facaca49c7717f3ba75e2183310c6724645e76971ce13275dfb4cdf3a", nonce: "1", blockHash: "0x2c8d1b0ee6968a660108b7ee107ddba908db082ffbd0740ad2a6239b699c5836", transactionIndex: "1", from: "0x2b854d07940e285fb4f3cda266d16c9bb840aa61", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "64800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "96289", gasUsed: "62584", confirmations: "1026907"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542112858 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "42"}, {name: "when", type: "uint256", value: "1542112858"}, {name: "addr", type: "address", value: "0x2b854d07940e285fb4f3cda266d16c9bb840aa61"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "10920000000000000"}, {name: "when", type: "uint256", value: "1542112858"}, {name: "addr", type: "address", value: "0x2b854d07940e285fb4f3cda266d16c9bb840aa61"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "52776000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6701996", timeStamp: "1542185719", hash: "0xfe4a34c48f9bdeb7c089c6b3c7225bbcda1c3650a9680bd05765c833a5707bf5", nonce: "18", blockHash: "0x7e4e25433c9dd295a307142660fb5ca8f4db60d665993638af9f72c6ca4f1e98", transactionIndex: "13", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "361838", gasUsed: "47584", confirmations: "1021799"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542185719 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[31,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "178"}, {name: "when", type: "uint256", value: "1542185719"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[31,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[31,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "26833333333333333"}, {name: "when", type: "uint256", value: "1542185719"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[31,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6702224", timeStamp: "1542188732", hash: "0x7765151410536746a056806b051dcaf35490cdb14c6e4a4a93b504d614f1865e", nonce: "234", blockHash: "0x16d73f4f44759656f8dc899fabe04488b5f9cd38b37d09a3276afc69fef4221d", transactionIndex: "139", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "60000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3297063", gasUsed: "47584", confirmations: "1021571"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542188732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[32,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "46"}, {name: "when", type: "uint256", value: "1542188732"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[32,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "38333333333333333"}, {name: "when", type: "uint256", value: "1542188732"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6708464", timeStamp: "1542277313", hash: "0xa61c2e0ad87e5fa80e60353a43a43f21f0c6f494fe9de1829912dd60acecff34", nonce: "247", blockHash: "0xf820da78f83d52166ff310de6ae6288e0526fbdb4f114c6c23cf1515276f2f67", transactionIndex: "44", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "60000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2644060", gasUsed: "47584", confirmations: "1015331"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542277313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "70"}, {name: "when", type: "uint256", value: "1542277313"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "40000000000000000"}, {name: "when", type: "uint256", value: "1542277313"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6709724", timeStamp: "1542295111", hash: "0x5143de6c433d2784105d3fe0fe553039c7c0968022d8a590ec63aa26df607881", nonce: "19", blockHash: "0xb72a69be7ede2dc364d6e17441baba72bb6a2f7847048e80072ba6c5d4e76f32", transactionIndex: "20", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2122373", gasUsed: "47584", confirmations: "1014071"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542295111 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[34,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "208"}, {name: "when", type: "uint256", value: "1542295111"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[34,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[34,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "35000000000000000"}, {name: "when", type: "uint256", value: "1542295111"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[34,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6709851", timeStamp: "1542296899", hash: "0x95766f4ce91d3163c6ee75ff1c403b1e699cf6405c69c9e100f51f9fdfcec6c3", nonce: "7", blockHash: "0xdc6693e911e1272a780804267f149e67b4157e65dcc3e028a4f460cbb93427d3", transactionIndex: "33", from: "0xe64417956ba078715055a9793852615e9a8bbe6a", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1077487", gasUsed: "47584", confirmations: "1013944"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542296899 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[35,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "185"}, {name: "when", type: "uint256", value: "1542296899"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[35,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "6936000000000000"}, {name: "when", type: "uint256", value: "1542296899"}, {name: "addr", type: "address", value: "0xe64417956ba078715055a9793852615e9a8bbe6a"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "299553000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6709860", timeStamp: "1542296996", hash: "0xccf0864ac438bd846aba54116f04a47ec9a7a0091b94ff2802164e1df53106b7", nonce: "2", blockHash: "0xf1eef69c01199c5cd9a850281b5ce2882782f8ab409c06607459a9d7ca0908e4", transactionIndex: "3", from: "0x2b854d07940e285fb4f3cda266d16c9bb840aa61", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "237042", gasUsed: "47584", confirmations: "1013935"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542296996 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[36,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "93"}, {name: "when", type: "uint256", value: "1542296996"}, {name: "addr", type: "address", value: "0x2b854d07940e285fb4f3cda266d16c9bb840aa61"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[36,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[36,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "13260000000000000"}, {name: "when", type: "uint256", value: "1542296996"}, {name: "addr", type: "address", value: "0x2b854d07940e285fb4f3cda266d16c9bb840aa61"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[36,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "52776000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6714618", timeStamp: "1542363364", hash: "0x1e817c989f4f268355be51507b5c7e474e10dcb36ee118eb38a87a86090a48da", nonce: "259", blockHash: "0xe3be61a1cae33426dff4a5a0d3c77915cd07bb60f13ddadc0e9df8d496f82312", transactionIndex: "100", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "60000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5227403", gasUsed: "47584", confirmations: "1009177"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542363364 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[37,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "93"}, {name: "when", type: "uint256", value: "1542363364"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[37,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "38333333333333333"}, {name: "when", type: "uint256", value: "1542363364"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6715903", timeStamp: "1542381561", hash: "0xdee37777dfdd46a18809c94d90551d1de69ad27f3773b1b3f725a4d272d9a254", nonce: "20", blockHash: "0x8db3cf0e9248ed6d3ee2023d9e04e479f99d3c9022f2e205a4ee0a0e30210c9d", transactionIndex: "12", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "698295", gasUsed: "47584", confirmations: "1007892"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542381561 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[38,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "232"}, {name: "when", type: "uint256", value: "1542381561"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[38,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "28000000000000000"}, {name: "when", type: "uint256", value: "1542381561"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6720667", timeStamp: "1542449366", hash: "0xe248b3e98a2c0405f1e33c79d09f135b84fbde6d09dbb93364d7a08f194edf7e", nonce: "270", blockHash: "0xd33391a03b80c6b0fd800bab74e0e3a6cf6284b5f6881d070504723d85f07a36", transactionIndex: "18", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "60000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "591636", gasUsed: "47584", confirmations: "1003128"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542449366 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "116"}, {name: "when", type: "uint256", value: "1542449366"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "38333333333333333"}, {name: "when", type: "uint256", value: "1542449366"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6722296", timeStamp: "1542472621", hash: "0xc81acbd5a5c0c1be6af8bb31fef1b2623e1cc712bf39866585d929fb13c1c0e2", nonce: "21", blockHash: "0xe81877b83403a877537651a6e2c64f1b19ffed56620f63e85b41695ba5f5ed79", transactionIndex: "6", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "412834", gasUsed: "47584", confirmations: "1001499"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542472621 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "257"}, {name: "when", type: "uint256", value: "1542472621"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "29166666666666666"}, {name: "when", type: "uint256", value: "1542472621"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6727067", timeStamp: "1542539554", hash: "0x5bc863404c4093552cfe13e8c80c16b408e5dbd8b98f3cc2fe4aaab5706a7b45", nonce: "285", blockHash: "0x2c0a7f44b094493fdfdaa5e06b4fa422e9d1575705e71040f9983808e350f457", transactionIndex: "15", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "60000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1311330", gasUsed: "47584", confirmations: "996728"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542539554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[41,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "141"}, {name: "when", type: "uint256", value: "1542539554"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[41,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "41666666666666666"}, {name: "when", type: "uint256", value: "1542539554"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6727714", timeStamp: "1542548516", hash: "0x19fe88dc37fae578e5b1735ef71ee283160d23b2694b4d18d8bedad4b7c3405d", nonce: "22", blockHash: "0xb7c0fa032ef0569a42d22605ea5734d7b1a398c9cca4508eaba061a8d0a6b8b5", transactionIndex: "24", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1729346", gasUsed: "47584", confirmations: "996081"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542548516 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "278"}, {name: "when", type: "uint256", value: "1542548516"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "24500000000000000"}, {name: "when", type: "uint256", value: "1542548516"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6729788", timeStamp: "1542577151", hash: "0xa7287d3ff1655005faefc4aec188e825e0e3fa1c62bc36197295628ccd2cb053", nonce: "290", blockHash: "0x6110cb9aad8a4989ead0fb284dd85e2035fd1b5defa51757dc5a28bfd9419c2d", transactionIndex: "6", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "389333", gasUsed: "47584", confirmations: "994007"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542577151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[43,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "151"}, {name: "when", type: "uint256", value: "1542577151"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[43,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "16666666666666666"}, {name: "when", type: "uint256", value: "1542577151"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setAdvertisingAddress( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6733049", timeStamp: "1542624078", hash: "0x5f117eb1208fd0008bfa225d61c7c788db4b0df9bb90131a4f7c43c12b0591a3", nonce: "5", blockHash: "0x74ac7ccbb9ac2068913c6ae4ce8c0024a74a9895a2aa7eab039b41a200d21794", transactionIndex: "42", from: "0x172ee25f09d63334cb42efacbe206c15978533ff", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "200000", gasPrice: "22000000000", isError: "0", txreceipt_status: "1", input: "0xcb192f2c00000000000000000000000004fefdabc8130cec593f1a2296b430d5d56cb8f0", contractAddress: "", cumulativeGasUsed: "1303755", gasUsed: "28502", confirmations: "990746"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[13]}], name: "setAdvertisingAddress", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAdvertisingAddress(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542624078 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "784229923246090557" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6734166", timeStamp: "1542639995", hash: "0x1ed26b8b9b5cb338a2f83b9e3c697c61d55d718e873b74870cede3c8c5fed40c", nonce: "23", blockHash: "0x4b73d1aafed19c38aaee7258b8d60cfe7dc5eeef0ad0a09d86588a0d616e2988", transactionIndex: "49", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2231808", gasUsed: "47584", confirmations: "989629"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542639995 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "303"}, {name: "when", type: "uint256", value: "1542639995"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[45,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "29166666666666666"}, {name: "when", type: "uint256", value: "1542639995"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[45,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6734366", timeStamp: "1542643096", hash: "0x92d162ee08275a6fc0d5f03d563d3dc2a8f98952a5a54cdcc8697baf6578ae31", nonce: "307", blockHash: "0xecd683c6949c06e2d5581c35edfeb0d6d6eac0716102add4dc7caf2e318c9fe2", transactionIndex: "39", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2030591", gasUsed: "47584", confirmations: "989429"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542643096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "169"}, {name: "when", type: "uint256", value: "1542643096"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[46,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "30000000000000000"}, {name: "when", type: "uint256", value: "1542643096"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[46,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6739053", timeStamp: "1542710326", hash: "0x806fd22576451c94dd342a1ab44038dfa44c1879a2a1247c3342dca92e187f32", nonce: "320", blockHash: "0xbba98aa937b6a00ed6d739f9e3cd7c45f6f4762543187c7731b47662955c1427", transactionIndex: "28", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2369433", gasUsed: "47584", confirmations: "984742"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542710326 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "187"}, {name: "when", type: "uint256", value: "1542710326"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[47,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "30000000000000000"}, {name: "when", type: "uint256", value: "1542710326"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[47,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6740659", timeStamp: "1542733503", hash: "0x7341c221dcccda5efd193d207a4146d4a86170609b636420307f7073bf82e652", nonce: "24", blockHash: "0xd8d5d6a9b77e29518bb5e65bbfa224345ced0c64b67babb15967ddb08b868d1e", transactionIndex: "6", from: "0x6f7988f576146044cee254683539b3cbd8fd3135", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "173584", gasUsed: "47584", confirmations: "983136"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542733503 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "328"}, {name: "when", type: "uint256", value: "1542733503"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[48,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "29166666666666666"}, {name: "when", type: "uint256", value: "1542733503"}, {name: "addr", type: "address", value: "0x6f7988f576146044cee254683539b3cbd8fd3135"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[48,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1376667000951170" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6744926", timeStamp: "1542794124", hash: "0xdbd6e34fcaf45a2d41e0d95b2272dc9ed8d45180df51cd13590295d22ec1cfbb", nonce: "334", blockHash: "0x50f3b7222af4d24637fe5020b491790536a440484cf8fede3cb93604cd99d16d", transactionIndex: "31", from: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b", to: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba", value: "0", gas: "49800", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2368261", gasUsed: "47584", confirmations: "978869"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542794124 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPaymentUser", type: "event"} ;
		console.error( "eventCallOriginal[49,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPaymentUser", events: [{name: "value", type: "uint256", value: "210"}, {name: "when", type: "uint256", value: "1542794124"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "gotPercent value"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[49,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "when", type: "uint256"}, {indexed: true, name: "addr", type: "address"}, {indexed: false, name: "text", type: "string"}], name: "logPayDividends", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "logPayDividends", events: [{name: "value", type: "uint256", value: "38333333333333333"}, {name: "when", type: "uint256", value: "1542794124"}, {name: "addr", type: "address", value: "0xbf4e10fb6d08fa8669bd33723cf38e2efcf0341b"}, {name: "text", type: "string", value: "dividends"}], address: "0x73b4c7b80dffd2ad1b54a192f56c8c7edcbf12ba"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46081958406335387" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "27916984882852950" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
