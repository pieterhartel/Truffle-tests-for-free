const MigrateController = artifacts.require( "./MigrateController.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "MigrateController" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x8DBC20fAe8a51b035bE3F22162ce962cF4EC9C60", "0x15799D3098715234657b90261FC596914E5003aa", "0xe43ac1714F7394173b15E7CfF31A63d523Ce4fB9", "0x5641519cc28DeF80D631BaA28b949F17A6A22AD1", "0x3e932a03417Ac81aafa037957dF015Ca01DCd1AC", "0xcb44320ecb48e0d858f2de7097b2b9861fdd67Ab", "0xd23628805FF6aC93f9Db8b862B5C9F093E6be1F8", "0x6DcAbD1308Fb517d2A862bAc24560B46da5963Ed", "0x48A9789428F2067338D02B1EF3612DF64F05FeB7", "0xF71BF9f85EF740211fBC243E636Df86f50290B83", "0x7DEAa83765e377c53F9FDa4BDf65C2675F99f03e", "0xCAf04Ef35e87193C25924197949e87116394DCC8", "0xB1351372be287481EE2029a699FAdCAec84e7336", "0x58c5d80403A38Be5D251acC070A3A01273A34B35", "0xb5B578c02B2915f879D7B12CFdf260900d9a51D0", "0x599aD3f92f76E859f7B7A87dBE3AACB81e54C6E6", "0x1A7cAdAf7c4A586F589FB348C2b86C6C233928B6", "0x6BEDc8C3200EbdEdD918A9407643d8139672F54D", "0xa344728a5405836fE1696F8d632802e4Bfb7905a", "0x5e271B784D261777267F01cF01e63acF1A777D43", "0x83cc6645fA8F2755C0Cc164cd9106CeFc381eAB6", "0x1aE6Ad1D0cE859182bc229D5640d4e2b620D9EB0", "0x9ECD610ff859078898bEFbf3143EB6f3b608cF8B", "0xDEAA2e18867c2c620E13C895d6200Ed096D01D6B", "0x6c96C6218Fb371a66DD6e7b223C6C8AF4379E7dA", "0xa86Deb98859E1D565706c49Bc881f9f49A2c944D", "0x7C30c6790229EEa11009Edb58159B68D6f5B9647", "0xEDFF6F043974F22d0aC90E8e02c9EC35a8AFa83A", "0xeE27C9aF11B6A29bB7C161E33B412539524C5EB5", "0xA9Bc22288B177D73b4e407724F1f00f408047D36", "0x47fCb9A5B36E2FE7F73Ea2dd2eb80B651789b1BA", "0x6f5B595409D68De19F6c782030647f2D11D942E7", "0xe2b8885EA036211124c255fF83DB677fF625519c", "0x724ef8C7FBCfdAc39e9fF1892ba00B7F99Dccb89", "0x6171af3769d44726f8f0e67D825f389d140926E2", "0xcF392b3F6B21c080a06f44c980bC3FB0E943AF3e", "0xb5f1ab8aE9c78EADcb0dE34aE0622AAFc0b502C3"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "time", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "pls", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "authority", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "_token", type: "address"}, {indexed: true, name: "_controller", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}], name: "ClaimedTokens", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_newController", type: "address"}], name: "ControllerChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "authority", type: "address"}], name: "LogSetAuthority", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}], name: "LogSetOwner", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["ClaimedTokens(address,address,uint256)", "NewIssue(address,uint256,bytes)", "ControllerChanged(address)", "LogSetAuthority(address)", "LogSetOwner(address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xf931edb47c50b4b4104c187b5814a9aef5f709e17e2ecf9617e860cacade929c", "0xf4b0ce039ec5c89fcad91f235beb5f788e7ffdf9325cc02314194dbffa58fca2", "0x027c3e080ed9215f564a9455a666f7e459b3edc0bb6e02a1bf842fde4d0ccfc1", "0x1abebea81bfa2637f28358c371278fb15ede7ea8dd28d2e03b112ff6d936ada4", "0xce241d7ca1f669fee44b6fc00b8eba2df3bb514eed0f6f668f8f89096e81ed94"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4419770 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4632088 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_pls", value: 4}], name: "MigrateController", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "time", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "time()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pls", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pls()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "authority", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "authority()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "MigrateController", function( accounts ) {

	it( "TEST: MigrateController( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4419770", timeStamp: "1508835920", hash: "0x8b4f3a1a5ba21f6f89dc26969c9331b34a1008b61330904742ae88b7491f7896", nonce: "4", blockHash: "0x44af08a50e38ff0559d21f237c97c47f15333c85c533f5581be0bbc9c31e2ed4", transactionIndex: "48", from: "0x15799d3098715234657b90261fc596914e5003aa", to: 0, value: "0", gas: "785097", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x442efdc1000000000000000000000000e43ac1714f7394173b15e7cff31a63d523ce4fb9", contractAddress: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", cumulativeGasUsed: "3093244", gasUsed: "785097", confirmations: "3304416"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pls", value: addressList[4]}], name: "MigrateController", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = MigrateController.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1508835920 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = MigrateController.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}], name: "LogSetOwner", type: "event"} ;
		console.error( "eventCallOriginal[0,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetOwner", events: [{name: "owner", type: "address", value: "0x15799d3098715234657b90261fc596914e5003aa"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[0,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[3], \"8899791016000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4445711", timeStamp: "1509197021", hash: "0x2e25c9ae5120ebd3945469a59537cb500ab8c6604d3b291129fc6710bc249f83", nonce: "11", blockHash: "0x64c390f3e32c8ebb659e3cf6118536be880719230e8af0e32380a7957e10efe3", transactionIndex: "34", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "82251", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x94d008ef00000000000000000000000015799d3098715234657b90261fc596914e5003aa0000000000000000000000000000000000000000000012d8961ccf6210390000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1122480", gasUsed: "82251", confirmations: "3278475"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[3]}, {type: "uint256", name: "_amount", value: "88997910160000000000000"}, {type: "bytes", name: "data", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[3], "88997910160000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509197021 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x15799d3098715234657b90261fc596914e5003aa"}, {name: "_amount", type: "uint256", value: "88997910160000000000000"}, {name: "data", type: "bytes", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[5], \"69600000000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4482315", timeStamp: "1509709502", hash: "0x484d9c2a86988966a238a438721c9c3406fc433ae5c9d7f7f30b01902b334e34", nonce: "12", blockHash: "0x3603f35396cc8c735c716679d7fa835ac393a47e076b8bad763cfbd985d00316", transactionIndex: "85", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "67367", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000005641519cc28def80d631baa28b949f17a6a22ad1000000000000000000000000000000000000000000000003c5e4df3e4f300000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010100000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3448256", gasUsed: "67367", confirmations: "3241871"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[5]}, {type: "uint256", name: "_amount", value: "69600000000000000000"}, {type: "bytes", name: "data", value: "0x01"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[5], "69600000000000000000", "0x01", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1509709502 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x5641519cc28def80d631baa28b949f17a6a22ad1"}, {name: "_amount", type: "uint256", value: "69600000000000000000"}, {name: "data", type: "bytes", value: "0x01"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[6], \"49255340000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4482913", timeStamp: "1509717765", hash: "0x12de06bba26c2752bf0342e72874075fd724364b831a65f3f23ec36c85f994ff", nonce: "13", blockHash: "0x8e05649d461e935250aca946601c1657baa4e05714cf856ad6ebe8f69fed1d94", transactionIndex: "85", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000003e932a03417ac81aafa037957df015ca01dcd1ac000000000000000000000000000000000000000000000002ab8e1ec39716c000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3567899", gasUsed: "67431", confirmations: "3241273"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[6]}, {type: "uint256", name: "_amount", value: "49255340000000000000"}, {type: "bytes", name: "data", value: "0x02"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[6], "49255340000000000000", "0x02", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1509717765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x3e932a03417ac81aafa037957df015ca01dcd1ac"}, {name: "_amount", type: "uint256", value: "49255340000000000000"}, {name: "data", type: "bytes", value: "0x02"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[7], \"3857549064000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4482971", timeStamp: "1509718590", hash: "0x9923941e2327deabc726365ebcc589250b0246e23020491406b9a2e125751d6a", nonce: "14", blockHash: "0x579ae1ac787b532709b90d0fd64bf49624ee55383ac9ce8307780394a7879001", transactionIndex: "74", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000cb44320ecb48e0d858f2de7097b2b9861fdd67ab00000000000000000000000000000000000000000000082b2e79435f05f50000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010300000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2960735", gasUsed: "67431", confirmations: "3241215"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[7]}, {type: "uint256", name: "_amount", value: "38575490640000000000000"}, {type: "bytes", name: "data", value: "0x03"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[7], "38575490640000000000000", "0x03", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509718590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xcb44320ecb48e0d858f2de7097b2b9861fdd67ab"}, {name: "_amount", type: "uint256", value: "38575490640000000000000"}, {name: "data", type: "bytes", value: "0x03"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[8], \"5000000499510000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4482993", timeStamp: "1509718822", hash: "0xc2eb1ac0fd6778af6f304baf3acedb837613216266bd7dba33c9abef0961e0f3", nonce: "15", blockHash: "0x21566ba5d40e4e3dd777fa5ba9566cb2eaff3fbd71974c34296314ef97064543", transactionIndex: "120", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000d23628805ff6ac93f9db8b862b5c9f093e6be1f80000000000000000000000000000000000000000000422ca91f89e56f4c16000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010400000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4517470", gasUsed: "67559", confirmations: "3241193"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[8]}, {type: "uint256", name: "_amount", value: "5000000499510000000000000"}, {type: "bytes", name: "data", value: "0x04"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[8], "5000000499510000000000000", "0x04", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509718822 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xd23628805ff6ac93f9db8b862b5c9f093e6be1f8"}, {name: "_amount", type: "uint256", value: "5000000499510000000000000"}, {name: "data", type: "bytes", value: "0x04"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[9], \"3004817799000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4483012", timeStamp: "1509719129", hash: "0x353befe66f42b3fb61e4268bf38d9f7eb54bc101bab01637b4c22a66143e4f7a", nonce: "16", blockHash: "0x260b39e323884701fc5f1733f98a49c00ea8cfaa87eb5bad381ce16cb7623a1d", transactionIndex: "90", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000006dcabd1308fb517d2a862bac24560b46da5963ed000000000000000000000000000000000000000000003fa12661ae5962b7c000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010500000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3253129", gasUsed: "67495", confirmations: "3241174"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[9]}, {type: "uint256", name: "_amount", value: "300481779900000000000000"}, {type: "bytes", name: "data", value: "0x05"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[9], "300481779900000000000000", "0x05", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1509719129 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x6dcabd1308fb517d2a862bac24560b46da5963ed"}, {name: "_amount", type: "uint256", value: "300481779900000000000000"}, {name: "data", type: "bytes", value: "0x05"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[10], \"330129529310000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4487235", timeStamp: "1509778097", hash: "0x1bd32675c8f44faf684c6566f3d7e02a86670e9aa234dd8aea97ab4fd34b5d31", nonce: "17", blockHash: "0xe33b3cae924852a0e0f4a7c4aa4847a2885f3462705ad9d4ac94f0875127fc54", transactionIndex: "18", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef00000000000000000000000048a9789428f2067338d02b1ef3612df64f05feb70000000000000000000000000000000000000000000045e85b8e8e3c51b3e000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010600000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "645691", gasUsed: "67495", confirmations: "3236951"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[10]}, {type: "uint256", name: "_amount", value: "330129529310000000000000"}, {type: "bytes", name: "data", value: "0x06"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[10], "330129529310000000000000", "0x06", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1509778097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x48a9789428f2067338d02b1ef3612df64f05feb7"}, {name: "_amount", type: "uint256", value: "330129529310000000000000"}, {name: "data", type: "bytes", value: "0x06"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[11], \"512164282700000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4500293", timeStamp: "1509958357", hash: "0xd8a815038b0205e51522d0674010d3a66e75ed97df9bd0b85f3fe570f097e6eb", nonce: "18", blockHash: "0x7f29aafc95fae1e524a45aa8a0afe3419e648cebb6550b7d0cdf3a9621b1b7fb", transactionIndex: "35", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000f71bf9f85ef740211fbc243e636df86f50290b83000000000000000000000000000000000000000000000ad872b94b4c5834e000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010700000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1210491", gasUsed: "67495", confirmations: "3223893"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[11]}, {type: "uint256", name: "_amount", value: "51216428270000000000000"}, {type: "bytes", name: "data", value: "0x07"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[11], "51216428270000000000000", "0x07", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1509958357 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xf71bf9f85ef740211fbc243e636df86f50290b83"}, {name: "_amount", type: "uint256", value: "51216428270000000000000"}, {name: "data", type: "bytes", value: "0x07"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[5], \"683900000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4500304", timeStamp: "1509958511", hash: "0x0df05faff786d8c5d55c7c8e2e200d8db04bdcd7a20c24077bba865f3907f0dd", nonce: "19", blockHash: "0x672c1b43d97b0ccfa56a3d43f4e05430edd59b747f49c175932673025cfdc8e0", transactionIndex: "44", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000005641519cc28def80d631baa28b949f17a6a22ad10000000000000000000000000000000000000000000000251304e28ae1a60000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010800000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1534089", gasUsed: "52367", confirmations: "3223882"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[5]}, {type: "uint256", name: "_amount", value: "683900000000000000000"}, {type: "bytes", name: "data", value: "0x08"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[5], "683900000000000000000", "0x08", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1509958511 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x5641519cc28def80d631baa28b949f17a6a22ad1"}, {name: "_amount", type: "uint256", value: "683900000000000000000"}, {name: "data", type: "bytes", value: "0x08"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[5], \"4515895875000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4500309", timeStamp: "1509958556", hash: "0x16793750afc7c6e64053cda90cb5675e960ced26f4e0c005a8644afccdf8f13c", nonce: "20", blockHash: "0x3ea3c7bf920a7c06022a6e71299a30856b1a2afcd051fe3e6a62612ac942d288", transactionIndex: "21", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000005641519cc28def80d631baa28b949f17a6a22ad1000000000000000000000000000000000000000000000990127278b50c3fe000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010900000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "809990", gasUsed: "52495", confirmations: "3223877"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[5]}, {type: "uint256", name: "_amount", value: "45158958750000000000000"}, {type: "bytes", name: "data", value: "0x09"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[5], "45158958750000000000000", "0x09", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1509958556 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x5641519cc28def80d631baa28b949f17a6a22ad1"}, {name: "_amount", type: "uint256", value: "45158958750000000000000"}, {name: "data", type: "bytes", value: "0x09"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[12], \"620722806281000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4505865", timeStamp: "1510036249", hash: "0x15923b785f3fb8be66e8c5c8c2b5503e8ea19b01741355a5afdb8745f1aaccaa", nonce: "21", blockHash: "0x2c17a5c24d6484f3ef9a5070a6f25a0d9ebb1166dfd331fa7062b29b954b22b3", transactionIndex: "53", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000007deaa83765e377c53f9fda4bdf65c2675f99f03e00000000000000000000000000000000000000000005226e81ee2dee98c7a000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010a00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1712478", gasUsed: "67559", confirmations: "3218321"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[12]}, {type: "uint256", name: "_amount", value: "6207228062810000000000000"}, {type: "bytes", name: "data", value: "0x0a"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[12], "6207228062810000000000000", "0x0a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510036249 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x7deaa83765e377c53f9fda4bdf65c2675f99f03e"}, {name: "_amount", type: "uint256", value: "6207228062810000000000000"}, {name: "data", type: "bytes", value: "0x0a"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[6], \"1065018950000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4505870", timeStamp: "1510036295", hash: "0x69cf10fd4e5cba4342f7c026df697d9e4d271dd8f96bc8f5bb6b093f0893075c", nonce: "22", blockHash: "0x943b5564adee7dfaea39e2f0daca6cf83d907ab56d5b6801f209df858cee952b", transactionIndex: "4", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000003e932a03417ac81aafa037957df015ca01dcd1ac000000000000000000000000000000000000000000000039bc1b645011826000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "151714", gasUsed: "52431", confirmations: "3218316"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[6]}, {type: "uint256", name: "_amount", value: "1065018950000000000000"}, {type: "bytes", name: "data", value: "0x0b"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[6], "1065018950000000000000", "0x0b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510036295 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x3e932a03417ac81aafa037957df015ca01dcd1ac"}, {name: "_amount", type: "uint256", value: "1065018950000000000000"}, {name: "data", type: "bytes", value: "0x0b"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[6], \"907662120000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4505876", timeStamp: "1510036371", hash: "0x01ec24a67c81488b3de6f8e3a460c501798f5e5668f88d25474925d55b4d434c", nonce: "23", blockHash: "0x69d67af63a79fb3cd304ded2b575cbc24c3996db0fd466325dba9408cae3a9e5", transactionIndex: "28", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000003e932a03417ac81aafa037957df015ca01dcd1ac0000000000000000000000000000000000000000000000313457a123d5fa8000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1394539", gasUsed: "52431", confirmations: "3218310"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[6]}, {type: "uint256", name: "_amount", value: "907662120000000000000"}, {type: "bytes", name: "data", value: "0x0c"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[6], "907662120000000000000", "0x0c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510036371 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x3e932a03417ac81aafa037957df015ca01dcd1ac"}, {name: "_amount", type: "uint256", value: "907662120000000000000"}, {name: "data", type: "bytes", value: "0x0c"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[13], \"27000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4505879", timeStamp: "1510036504", hash: "0x264730b4acf196484d84e3be76dfabea1526b601ff39d9dca3268a5a9e5a08b3", nonce: "24", blockHash: "0x82d208debc72b8803dff4ea0e6d27b9559b6835f1d701a13185c8db0e5040af4", transactionIndex: "80", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "5000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000caf04ef35e87193c25924197949e87116394dcc800000000000000000000000000000000000000000000000176b344f2a78c0000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010d00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2133852", gasUsed: "67367", confirmations: "3218307"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[13]}, {type: "uint256", name: "_amount", value: "27000000000000000000"}, {type: "bytes", name: "data", value: "0x0d"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[13], "27000000000000000000", "0x0d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1510036504 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xcaf04ef35e87193c25924197949e87116394dcc8"}, {name: "_amount", type: "uint256", value: "27000000000000000000"}, {name: "data", type: "bytes", value: "0x0d"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[14], \"121710708100000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4511501", timeStamp: "1510114207", hash: "0x3572d80d3dbb785de493ed5051246c566d0d08d68e1c63be26c37c26b8392c70", nonce: "25", blockHash: "0xff5cfcea85007d760201cc45fd693647146c0159125c04cfb7276000caabcfeb", transactionIndex: "24", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "67379", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000b1351372be287481ee2029a699fadcaec84e7336000000000000000000000000000000000000000000000293cb89c0991fd7a00000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000000e", contractAddress: "", cumulativeGasUsed: "750147", gasUsed: "67379", confirmations: "3212685"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[14]}, {type: "uint256", name: "_amount", value: "12171070810000000000000"}, {type: "bytes", name: "data", value: "0x000000000000000000000000000000000000000000000000000000000000000e"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[14], "12171070810000000000000", "0x000000000000000000000000000000000000000000000000000000000000000e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510114207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xb1351372be287481ee2029a699fadcaec84e7336"}, {name: "_amount", type: "uint256", value: "12171070810000000000000"}, {name: "data", type: "bytes", value: "0x000000000000000000000000000000000000000000000000000000000000000e"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[11], \"212356678574000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4511569", timeStamp: "1510115212", hash: "0x2ae404e39d8f7deb136d0910637ebe3c318861fbefd541dd2a1cc5f28d63a2ff", nonce: "28", blockHash: "0xd88870df4eb5450d34b1733a3c2ce9ebc18b46c192fbba63882e7d0f744299fe", transactionIndex: "64", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000f71bf9f85ef740211fbc243e636df86f50290b8300000000000000000000000000000000000000000001c1aec93f8b7f41c8c000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000010f00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1481756", gasUsed: "52559", confirmations: "3212617"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[11]}, {type: "uint256", name: "_amount", value: "2123566785740000000000000"}, {type: "bytes", name: "data", value: "0x0f"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[11], "2123566785740000000000000", "0x0f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510115212 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xf71bf9f85ef740211fbc243e636df86f50290b83"}, {name: "_amount", type: "uint256", value: "2123566785740000000000000"}, {name: "data", type: "bytes", value: "0x0f"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[15], \"50000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4511569", timeStamp: "1510115212", hash: "0x51dc5df83205a4cc816bdef1da1a832c76f3674a774f9beaf6884bf21c9301e5", nonce: "29", blockHash: "0xd88870df4eb5450d34b1733a3c2ce9ebc18b46c192fbba63882e7d0f744299fe", transactionIndex: "92", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef00000000000000000000000058c5d80403a38be5d251acc070a3a01273a34b35000000000000000000000000000000000000000000000002b5e3af16b1880000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3817397", gasUsed: "67367", confirmations: "3212617"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[15]}, {type: "uint256", name: "_amount", value: "50000000000000000000"}, {type: "bytes", name: "data", value: "0x10"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[15], "50000000000000000000", "0x10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510115212 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x58c5d80403a38be5d251acc070a3a01273a34b35"}, {name: "_amount", type: "uint256", value: "50000000000000000000"}, {name: "data", type: "bytes", value: "0x10"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[16], \"105106296520000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4512241", timeStamp: "1510124248", hash: "0xa445e48560544a9d3347fd09f752f1fdc1ac10b7fb8b7eb160f843787a22afb6", nonce: "30", blockHash: "0xf2d6aaf77e6ccc06edbdd366281639fd7b1ec586b7897def1afd83a63cb5a552", transactionIndex: "70", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000b5b578c02b2915f879d7b12cfdf260900d9a51d0000000000000000000000000000000000000000000001641d2e15fea13d48000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011100000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3667022", gasUsed: "67495", confirmations: "3211945"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[16]}, {type: "uint256", name: "_amount", value: "105106296520000000000000"}, {type: "bytes", name: "data", value: "0x11"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[16], "105106296520000000000000", "0x11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510124248 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xb5b578c02b2915f879d7b12cfdf260900d9a51d0"}, {name: "_amount", type: "uint256", value: "105106296520000000000000"}, {name: "data", type: "bytes", value: "0x11"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[17], \"355198610740000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4512241", timeStamp: "1510124248", hash: "0x7079bbd930bb9e37126bcfe32c4a397456b24d7d50f3b824d41a0f720361f6f3", nonce: "31", blockHash: "0xf2d6aaf77e6ccc06edbdd366281639fd7b1ec586b7897def1afd83a63cb5a552", transactionIndex: "81", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000599ad3f92f76e859f7b7a87dbe3aacb81e54c6e6000000000000000000000000000000000000000000004b375af311227d574000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4468731", gasUsed: "67495", confirmations: "3211945"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[17]}, {type: "uint256", name: "_amount", value: "355198610740000000000000"}, {type: "bytes", name: "data", value: "0x12"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[17], "355198610740000000000000", "0x12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510124248 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x599ad3f92f76e859f7b7a87dbe3aacb81e54c6e6"}, {name: "_amount", type: "uint256", value: "355198610740000000000000"}, {name: "data", type: "bytes", value: "0x12"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[18], \"549644359609000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4512241", timeStamp: "1510124248", hash: "0x645e594759986947e2bb7ccbb6b1a2bef65c10c439dceeeab1cdcae8d420e6b2", nonce: "32", blockHash: "0xf2d6aaf77e6ccc06edbdd366281639fd7b1ec586b7897def1afd83a63cb5a552", transactionIndex: "84", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000001a7cadaf7c4a586f589fb348c2b86c6c233928b6000000000000000000000000000000000000000000048beacdec95988535a000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011300000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4578290", gasUsed: "67559", confirmations: "3211945"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[18]}, {type: "uint256", name: "_amount", value: "5496443596090000000000000"}, {type: "bytes", name: "data", value: "0x13"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[18], "5496443596090000000000000", "0x13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510124248 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x1a7cadaf7c4a586f589fb348c2b86c6c233928b6"}, {name: "_amount", type: "uint256", value: "5496443596090000000000000"}, {name: "data", type: "bytes", value: "0x13"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[18], \"359748226000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4512241", timeStamp: "1510124248", hash: "0x92b50f5035b6ac612b4519df677c1ad4536d7729a9cdea3dbed30c1ad990ade4", nonce: "33", blockHash: "0xf2d6aaf77e6ccc06edbdd366281639fd7b1ec586b7897def1afd83a63cb5a552", transactionIndex: "87", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000001a7cadaf7c4a586f589fb348c2b86c6c233928b6000000000000000000000000000000000000000000004c2dfd8b6f35c1cd0000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011400000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4672721", gasUsed: "52431", confirmations: "3211945"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[18]}, {type: "uint256", name: "_amount", value: "359748226000000000000000"}, {type: "bytes", name: "data", value: "0x14"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[18], "359748226000000000000000", "0x14", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510124248 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x1a7cadaf7c4a586f589fb348c2b86c6c233928b6"}, {name: "_amount", type: "uint256", value: "359748226000000000000000"}, {name: "data", type: "bytes", value: "0x14"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[18], \"467095478675000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4512241", timeStamp: "1510124248", hash: "0xe8348efd1f8f2a1a517fdc0820e50df25d839061d35f9fff909a479473a5d616", nonce: "34", blockHash: "0xf2d6aaf77e6ccc06edbdd366281639fd7b1ec586b7897def1afd83a63cb5a552", transactionIndex: "90", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000001a7cadaf7c4a586f589fb348c2b86c6c233928b600000000000000000000000000000000000000000003dd1cf763f205da71e000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011500000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4767280", gasUsed: "52559", confirmations: "3211945"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[18]}, {type: "uint256", name: "_amount", value: "4670954786750000000000000"}, {type: "bytes", name: "data", value: "0x15"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[18], "4670954786750000000000000", "0x15", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510124248 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x1a7cadaf7c4a586f589fb348c2b86c6c233928b6"}, {name: "_amount", type: "uint256", value: "4670954786750000000000000"}, {name: "data", type: "bytes", value: "0x15"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[19], \"267541416523000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4512817", timeStamp: "1510132693", hash: "0x3321cb34823bf17cbc409b78adb5c247c38f4e50e642894792dcd2bf494e0bf4", nonce: "35", blockHash: "0x481ddb3c9c93f8f357e76d21266cd361d513b5415262bd76e3e8b4137eeee9c6", transactionIndex: "128", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000006bedc8c3200ebdedd918a9407643d8139672f54d00000000000000000000000000000000000000000002368a7e1544ed35d4e000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011600000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6385290", gasUsed: "67559", confirmations: "3211369"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[19]}, {type: "uint256", name: "_amount", value: "2675414165230000000000000"}, {type: "bytes", name: "data", value: "0x16"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[19], "2675414165230000000000000", "0x16", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510132693 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x6bedc8c3200ebdedd918a9407643d8139672f54d"}, {name: "_amount", type: "uint256", value: "2675414165230000000000000"}, {name: "data", type: "bytes", value: "0x16"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[3], \"4482706493400000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4512818", timeStamp: "1510132721", hash: "0x02d3846e0ba549a0145a9445f16b2af4ac1847d59abf9227d9a5d7d7832a1abb", nonce: "36", blockHash: "0x94167c8eee2d0a546590ab47b2b4efd2e2a3544b23456da04d04c1488b56325e", transactionIndex: "110", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef00000000000000000000000015799d3098715234657b90261fc596914e5003aa000000000000000000000000000000000000000000005eecccf3b70a49ebc000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011700000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5553963", gasUsed: "52495", confirmations: "3211368"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[3]}, {type: "uint256", name: "_amount", value: "448270649340000000000000"}, {type: "bytes", name: "data", value: "0x17"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[3], "448270649340000000000000", "0x17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510132721 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x15799d3098715234657b90261fc596914e5003aa"}, {name: "_amount", type: "uint256", value: "448270649340000000000000"}, {name: "data", type: "bytes", value: "0x17"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[20], \"105195363144000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4519325", timeStamp: "1510223390", hash: "0x452b8cee3d0fb3cf6bc3149a002645ee9c13bda583597d127cce6851c1524170", nonce: "37", blockHash: "0x4225925e53cd112694307231ea699476058efe09f5bd69b69b9234a2139b213c", transactionIndex: "82", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000a344728a5405836fe1696f8d632802e4bfb7905a00000000000000000000000000000000000000000000dec28547e178bf1d0000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011800000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3556475", gasUsed: "67431", confirmations: "3204861"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[20]}, {type: "uint256", name: "_amount", value: "1051953631440000000000000"}, {type: "bytes", name: "data", value: "0x18"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[20], "1051953631440000000000000", "0x18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510223390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xa344728a5405836fe1696f8d632802e4bfb7905a"}, {name: "_amount", type: "uint256", value: "1051953631440000000000000"}, {name: "data", type: "bytes", value: "0x18"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[21], \"106727967318000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4519325", timeStamp: "1510223390", hash: "0x5f929ed3ba40e165f9351e1ce23d8cf201b365eb46ec4770f551505a2f63309b", nonce: "38", blockHash: "0x4225925e53cd112694307231ea699476058efe09f5bd69b69b9234a2139b213c", transactionIndex: "111", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000005e271b784d261777267f01cf01e63acf1a777d4300000000000000000000000000000000000000000000e20158d6032704c1c000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011900000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6095782", gasUsed: "67495", confirmations: "3204861"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[21]}, {type: "uint256", name: "_amount", value: "1067279673180000000000000"}, {type: "bytes", name: "data", value: "0x19"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[21], "1067279673180000000000000", "0x19", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510223390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x5e271b784d261777267f01cf01e63acf1a777d43"}, {name: "_amount", type: "uint256", value: "1067279673180000000000000"}, {name: "data", type: "bytes", value: "0x19"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[22], \"277673889250000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4519325", timeStamp: "1510223390", hash: "0xea855d48af5c7ddf01ae7f25ab788932eeab431c2f80865e4a81f3ec5d8214f1", nonce: "39", blockHash: "0x4225925e53cd112694307231ea699476058efe09f5bd69b69b9234a2139b213c", transactionIndex: "118", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef00000000000000000000000083cc6645fa8f2755c0cc164cd9106cefc381eab6000000000000000000000000000000000000000000003accbb50958ecf882000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011a00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6545476", gasUsed: "67495", confirmations: "3204861"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[22]}, {type: "uint256", name: "_amount", value: "277673889250000000000000"}, {type: "bytes", name: "data", value: "0x1a"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[22], "277673889250000000000000", "0x1a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510223390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x83cc6645fa8f2755c0cc164cd9106cefc381eab6"}, {name: "_amount", type: "uint256", value: "277673889250000000000000"}, {name: "data", type: "bytes", value: "0x1a"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[23], \"395780809700000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4519328", timeStamp: "1510223431", hash: "0x4e5cc18977d469ba282ad56c8476cf346a57deecdc6e8fa990f7d74ee5756a19", nonce: "40", blockHash: "0xb3b4cfa87fac57ef80fd3b13d529e753f85795882a1db48127e18b988101e900", transactionIndex: "43", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000001ae6ad1d0ce859182bc229d5640d4e2b620d9eb00000000000000000000000000000000000000000000008618835a48e119ea000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2512146", gasUsed: "67495", confirmations: "3204858"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[23]}, {type: "uint256", name: "_amount", value: "39578080970000000000000"}, {type: "bytes", name: "data", value: "0x1b"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[23], "39578080970000000000000", "0x1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510223431 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x1ae6ad1d0ce859182bc229d5640d4e2b620d9eb0"}, {name: "_amount", type: "uint256", value: "39578080970000000000000"}, {name: "data", type: "bytes", value: "0x1b"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[24], \"124011805342000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4525798", timeStamp: "1510312788", hash: "0xfc5310a9722398838d89e8725d1d53fc4963182bb7f50ebcd82f3d2761599f95", nonce: "41", blockHash: "0x89686cc635d6a83e7de3b6004c5814b98e5e4e5b610fd0f974b5e36aeb3a3f4f", transactionIndex: "93", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000009ecd610ff859078898befbf3143eb6f3b608cf8b00000000000000000000000000000000000000000001069aef33b6727afec000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5552267", gasUsed: "67559", confirmations: "3198388"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[24]}, {type: "uint256", name: "_amount", value: "1240118053420000000000000"}, {type: "bytes", name: "data", value: "0x1c"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[24], "1240118053420000000000000", "0x1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510312788 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x9ecd610ff859078898befbf3143eb6f3b608cf8b"}, {name: "_amount", type: "uint256", value: "1240118053420000000000000"}, {name: "data", type: "bytes", value: "0x1c"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[15], \"884659375050000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4525798", timeStamp: "1510312788", hash: "0xca8be5b8a888881e012e8d02e1ea9357c5baecb9b9784ea3ee53515302e13c87", nonce: "42", blockHash: "0x89686cc635d6a83e7de3b6004c5814b98e5e4e5b610fd0f974b5e36aeb3a3f4f", transactionIndex: "94", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef00000000000000000000000058c5d80403a38be5d251acc070a3a01273a34b3500000000000000000000000000000000000000000000bb557b16d1b98deea000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011d00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5604762", gasUsed: "52495", confirmations: "3198388"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[15]}, {type: "uint256", name: "_amount", value: "884659375050000000000000"}, {type: "bytes", name: "data", value: "0x1d"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[15], "884659375050000000000000", "0x1d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510312788 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x58c5d80403a38be5d251acc070a3a01273a34b35"}, {name: "_amount", type: "uint256", value: "884659375050000000000000"}, {name: "data", type: "bytes", value: "0x1d"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[25], \"461409378767000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4525798", timeStamp: "1510312788", hash: "0x74e5d21f13dafad2b8b1ccdb3f0eee30dc2fe81d70edd77b841b88dfb27f85a5", nonce: "43", blockHash: "0x89686cc635d6a83e7de3b6004c5814b98e5e4e5b610fd0f974b5e36aeb3a3f4f", transactionIndex: "95", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000deaa2e18867c2c620e13c895d6200ed096d01d6b00000000000000000000000000000000000000000003d1128682b93f5d4f6000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011e00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5672321", gasUsed: "67559", confirmations: "3198388"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[25]}, {type: "uint256", name: "_amount", value: "4614093787670000000000000"}, {type: "bytes", name: "data", value: "0x1e"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[25], "4614093787670000000000000", "0x1e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510312788 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xdeaa2e18867c2c620e13c895d6200ed096d01d6b"}, {name: "_amount", type: "uint256", value: "4614093787670000000000000"}, {name: "data", type: "bytes", value: "0x1e"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[26], \"532651498675600000000... )", async function( ) {
		const txOriginal = {blockNumber: "4526441", timeStamp: "1510322066", hash: "0x596d2a89e283478e202406c3124d17039a8ac408fd0390db77e3ae8857eeb33e", nonce: "44", blockHash: "0x81de831b93cd52601bd0de477351bbfe1fd117a81fe66bbdf054629e5abf1144", transactionIndex: "127", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000006c96c6218fb371a66dd6e7b223c6c8af4379e7da0000000000000000000000000000000000000000002c0f558f69d6cf6b2a8000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000011f00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5338597", gasUsed: "67559", confirmations: "3197745"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[26]}, {type: "uint256", name: "_amount", value: "53265149867560000000000000"}, {type: "bytes", name: "data", value: "0x1f"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[26], "53265149867560000000000000", "0x1f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510322066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x6c96c6218fb371a66dd6e7b223c6c8af4379e7da"}, {name: "_amount", type: "uint256", value: "53265149867560000000000000"}, {name: "data", type: "bytes", value: "0x1f"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[27], \"309420097616000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4532147", timeStamp: "1510400485", hash: "0xc47a67ffdba59f65ab1315267ce40a3599b160c50e20291682f86fbaa0776c84", nonce: "46", blockHash: "0xed7fa0881ac6ab3e07a1257f9c84a990ad8bed40ae73c1f420dac81adb82974e", transactionIndex: "5", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000a86deb98859e1d565706c49bc881f9f49a2c944d000000000000000000000000000000000000000000028f38f894f62483d20000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "264975", gasUsed: "67495", confirmations: "3192039"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[27]}, {type: "uint256", name: "_amount", value: "3094200976160000000000000"}, {type: "bytes", name: "data", value: "0x20"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[27], "3094200976160000000000000", "0x20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510400485 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xa86deb98859e1d565706c49bc881f9f49a2c944d"}, {name: "_amount", type: "uint256", value: "3094200976160000000000000"}, {name: "data", type: "bytes", value: "0x20"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[28], \"266294815040000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4551581", timeStamp: "1510669505", hash: "0x09fed4e73f23f14d87815acff92bc973da80f1c3ac060a9ff5fdbc7e1b818a33", nonce: "47", blockHash: "0x799bf198382c7bf6c4b5643c5b04730b3b2d45ea8604db48270c6409a3285941", transactionIndex: "97", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000007c30c6790229eea11009edb58159b68d6f5b9647000000000000000000000000000000000000000000003863deeffc7b5cd40000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012100000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5268067", gasUsed: "67431", confirmations: "3172605"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[28]}, {type: "uint256", name: "_amount", value: "266294815040000000000000"}, {type: "bytes", name: "data", value: "0x21"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[28], "266294815040000000000000", "0x21", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510669505 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x7c30c6790229eea11009edb58159b68d6f5b9647"}, {name: "_amount", type: "uint256", value: "266294815040000000000000"}, {name: "data", type: "bytes", value: "0x21"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[13], \"458761960780000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4556934", timeStamp: "1510744663", hash: "0x94eb2e6700b86e8da2dcca6f24513b92f4a371ae98ccf730a31540a5a99c47ce", nonce: "48", blockHash: "0x3730cf11948eb4852a19bf512c2f4aadc390c03e47d83d231ac010956db96f58", transactionIndex: "70", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000caf04ef35e87193c25924197949e87116394dcc80000000000000000000000000000000000000000000061258925605eb1d0c000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012200000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4837690", gasUsed: "52495", confirmations: "3167252"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[13]}, {type: "uint256", name: "_amount", value: "458761960780000000000000"}, {type: "bytes", name: "data", value: "0x22"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[13], "458761960780000000000000", "0x22", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510744663 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xcaf04ef35e87193c25924197949e87116394dcc8"}, {name: "_amount", type: "uint256", value: "458761960780000000000000"}, {name: "data", type: "bytes", value: "0x22"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[29], \"225728121000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4561963", timeStamp: "1510815171", hash: "0xf6caa86f91eff1b69701fd6b0674f918dd100a446cdaf5d34a730646f11a86e0", nonce: "49", blockHash: "0xf0bf6d0612ebd80ddc6e3b683ed46ff49dc019680b57988dbc552951d6c1e347", transactionIndex: "68", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000edff6f043974f22d0ac90e8e02c9ec35a8afa83a00000000000000000000000000000000000000000001ddff75a7aa95a8390000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012300000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1788313", gasUsed: "67495", confirmations: "3162223"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[29]}, {type: "uint256", name: "_amount", value: "2257281210000000000000000"}, {type: "bytes", name: "data", value: "0x23"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[29], "2257281210000000000000000", "0x23", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510815171 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xedff6f043974f22d0ac90e8e02c9ec35a8afa83a"}, {name: "_amount", type: "uint256", value: "2257281210000000000000000"}, {name: "data", type: "bytes", value: "0x23"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[30], \"407163126490000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4567822", timeStamp: "1510896268", hash: "0x3cdd8507dfbfdc1963ed5db4babd3240d0b8f404a08ff1fd97b1cb6816544f53", nonce: "50", blockHash: "0x37fafc809911cce75b2e4544e0c6d3ccf281cf5af667d0dc83edca34b3d6070a", transactionIndex: "92", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000ee27c9af11b6a29bb7c161e33b412539524c5eb50000000000000000000000000000000000000000000056385b78fbf4a2afa000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012400000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5261220", gasUsed: "67495", confirmations: "3156364"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[30]}, {type: "uint256", name: "_amount", value: "407163126490000000000000"}, {type: "bytes", name: "data", value: "0x24"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[30], "407163126490000000000000", "0x24", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510896268 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xee27c9af11b6a29bb7c161e33b412539524c5eb5"}, {name: "_amount", type: "uint256", value: "407163126490000000000000"}, {name: "data", type: "bytes", value: "0x24"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[31], \"193696584800000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4567823", timeStamp: "1510896272", hash: "0xc43a30953f6b953af4e8b9417135a7b863c74572ae85a9c9fa2f3f57351daa09", nonce: "51", blockHash: "0x14a222879fa6c03d290c30a418577507e4637d09ca604aa9cb27c58c23b62e79", transactionIndex: "60", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000a9bc22288b177d73b4e407724f1f00f408047d36000000000000000000000000000000000000000000002904501a5b1c57260000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012500000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6334811", gasUsed: "67367", confirmations: "3156363"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[31]}, {type: "uint256", name: "_amount", value: "193696584800000000000000"}, {type: "bytes", name: "data", value: "0x25"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[31], "193696584800000000000000", "0x25", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510896272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xa9bc22288b177d73b4e407724f1f00f408047d36"}, {name: "_amount", type: "uint256", value: "193696584800000000000000"}, {name: "data", type: "bytes", value: "0x25"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[32], \"369288188680000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4592082", timeStamp: "1511233691", hash: "0x742347a92d59574613e0a9ee8702aad832ea735d84a3315356cff9808c8f6a25", nonce: "52", blockHash: "0x51ac15c38adf30602852b9b2b89d92a573353e98c1adac2028a52854895977dc", transactionIndex: "169", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef00000000000000000000000047fcb9a5b36e2fe7f73ea2dd2eb80b651789b1ba000000000000000000000000000000000000000000004e33271f57c80d588000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012600000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6537266", gasUsed: "67495", confirmations: "3132104"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[32]}, {type: "uint256", name: "_amount", value: "369288188680000000000000"}, {type: "bytes", name: "data", value: "0x26"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[32], "369288188680000000000000", "0x26", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511233691 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x47fcb9a5b36e2fe7f73ea2dd2eb80b651789b1ba"}, {name: "_amount", type: "uint256", value: "369288188680000000000000"}, {name: "data", type: "bytes", value: "0x26"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[33], \"469834800000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4592083", timeStamp: "1511233699", hash: "0x4374a0328c667244649fbce5f5b6561bd1e0b349e5766bff6259d640bca264d0", nonce: "53", blockHash: "0x3a49e3f6f7cd703ae11c8441c4bce4fd3e19bf8265fb1347c4c345bb7ff2b6d2", transactionIndex: "82", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000006f5b595409d68de19f6c782030647f2d11d942e700000000000000000000000000000000000000000000637dcba8bc8b1b380000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012700000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3207720", gasUsed: "67431", confirmations: "3132103"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[33]}, {type: "uint256", name: "_amount", value: "469834800000000000000000"}, {type: "bytes", name: "data", value: "0x27"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[33], "469834800000000000000000", "0x27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511233699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x6f5b595409d68de19f6c782030647f2d11d942e7"}, {name: "_amount", type: "uint256", value: "469834800000000000000000"}, {name: "data", type: "bytes", value: "0x27"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[33], \"591861203177000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4592083", timeStamp: "1511233699", hash: "0xb67d5808e9c7773e795509361d63e5f1a610a277c7b6a008ef3984c1cf47d00e", nonce: "54", blockHash: "0x3a49e3f6f7cd703ae11c8441c4bce4fd3e19bf8265fb1347c4c345bb7ff2b6d2", transactionIndex: "130", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000006f5b595409d68de19f6c782030647f2d11d942e700000000000000000000000000000000000000000030f52602efd335cf444000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012800000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6151433", gasUsed: "52559", confirmations: "3132103"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[33]}, {type: "uint256", name: "_amount", value: "59186120317700000000000000"}, {type: "bytes", name: "data", value: "0x28"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[33], "59186120317700000000000000", "0x28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511233699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x6f5b595409d68de19f6c782030647f2d11d942e7"}, {name: "_amount", type: "uint256", value: "59186120317700000000000000"}, {name: "data", type: "bytes", value: "0x28"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[33], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4592085", timeStamp: "1511233739", hash: "0x28a493ec8691e9da4ea61956fe7f8bd919da18cc0e7db8f2989c795cdbb247b6", nonce: "55", blockHash: "0x30d81284d520c69ad3686b2c7033ce1b8239272acc003fa30a0bdba9fbd1e090", transactionIndex: "113", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000006f5b595409d68de19f6c782030647f2d11d942e70000000000000000000000000000000000000000000000056bc75e2d63100000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012900000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4823993", gasUsed: "52367", confirmations: "3132101"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[33]}, {type: "uint256", name: "_amount", value: "100000000000000000000"}, {type: "bytes", name: "data", value: "0x29"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[33], "100000000000000000000", "0x29", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1511233739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x6f5b595409d68de19f6c782030647f2d11d942e7"}, {name: "_amount", type: "uint256", value: "100000000000000000000"}, {name: "data", type: "bytes", value: "0x29"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[34], \"350480244870000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4592086", timeStamp: "1511233749", hash: "0x2baaa8aca9ee91deeb8d9417e1dfd5b0c1e36221e3ff397498e6bad5429327fc", nonce: "56", blockHash: "0x5764c666bf873c9a80b100003f276e5e849daeef68900c144e13c2841e516ec3", transactionIndex: "38", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000e2b8885ea036211124c255ff83db677ff625519c000000000000000000000000000000000000000000004a3792781957f0666000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012a00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3385651", gasUsed: "67495", confirmations: "3132100"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[34]}, {type: "uint256", name: "_amount", value: "350480244870000000000000"}, {type: "bytes", name: "data", value: "0x2a"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[34], "350480244870000000000000", "0x2a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1511233749 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xe2b8885ea036211124c255ff83db677ff625519c"}, {name: "_amount", type: "uint256", value: "350480244870000000000000"}, {name: "data", type: "bytes", value: "0x2a"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[35], \"377105985650000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4605116", timeStamp: "1511415004", hash: "0x6be0a26ac4844d05a6212b742e247c49340540045672058020a3d374afc0a22d", nonce: "57", blockHash: "0x49773ac3ecf5e373701ff179206e8b390f8b90a154c127e488d784513436e7aa", transactionIndex: "161", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000724ef8c7fbcfdac39e9ff1892ba00b7f99dccb89000000000000000000000000000000000000000000004fdaf4d993886c812000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6662924", gasUsed: "67495", confirmations: "3119070"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[35]}, {type: "uint256", name: "_amount", value: "377105985650000000000000"}, {type: "bytes", name: "data", value: "0x2b"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[35], "377105985650000000000000", "0x2b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1511415004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x724ef8c7fbcfdac39e9ff1892ba00b7f99dccb89"}, {name: "_amount", type: "uint256", value: "377105985650000000000000"}, {name: "data", type: "bytes", value: "0x2b"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[36], \"148147836230000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4612302", timeStamp: "1511515100", hash: "0x6029cdc0c9f34e52b3d82dc88439d735d9ff3e64253d3444013596798cfb3695", nonce: "58", blockHash: "0x158e159605547952757d77f1519f2e91093526c105fd7451940043dd2cf5745c", transactionIndex: "128", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef0000000000000000000000006171af3769d44726f8f0e67d825f389d140926e2000000000000000000000000000000000000000000001f5f1c3c424ef7726000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5608717", gasUsed: "67495", confirmations: "3111884"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[36]}, {type: "uint256", name: "_amount", value: "148147836230000000000000"}, {type: "bytes", name: "data", value: "0x2c"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[36], "148147836230000000000000", "0x2c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1511515100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0x6171af3769d44726f8f0e67d825f389d140926e2"}, {name: "_amount", type: "uint256", value: "148147836230000000000000"}, {name: "data", type: "bytes", value: "0x2c"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[37], \"203461063853000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4632086", timeStamp: "1511791601", hash: "0x665c089ed31ed882fe159f56782dfa1474834add8db7112b010dbb5affbeab9a", nonce: "59", blockHash: "0x41b5af0772ee2785f3b310a1fcbb9606665c921eae987e2f4b8210bfddf50f7d", transactionIndex: "73", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000cf392b3f6b21c080a06f44c980bc3fb0e943af3e00000000000000000000000000000000000000000001aed876b689de93f62000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012d00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4057699", gasUsed: "67559", confirmations: "3092100"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[37]}, {type: "uint256", name: "_amount", value: "2034610638530000000000000"}, {type: "bytes", name: "data", value: "0x2d"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[37], "2034610638530000000000000", "0x2d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1511791601 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xcf392b3f6b21c080a06f44c980bc3fb0e943af3e"}, {name: "_amount", type: "uint256", value: "2034610638530000000000000"}, {name: "data", type: "bytes", value: "0x2d"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[37], \"140329058580000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4632088", timeStamp: "1511791609", hash: "0x0718bfc3bf04805eaa453b454cf9f4c493d0cc827ee024cc3216f4eed046aacf", nonce: "60", blockHash: "0x1ac953133f320337679e4b9b6a5c82d75705742e9907eb808cda6c918404ff4e", transactionIndex: "21", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000cf392b3f6b21c080a06f44c980bc3fb0e943af3e000000000000000000000000000000000000000000001db740e5f34af9f54000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012e00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "507781", gasUsed: "52495", confirmations: "3092098"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[37]}, {type: "uint256", name: "_amount", value: "140329058580000000000000"}, {type: "bytes", name: "data", value: "0x2e"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[37], "140329058580000000000000", "0x2e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1511791609 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xcf392b3f6b21c080a06f44c980bc3fb0e943af3e"}, {name: "_amount", type: "uint256", value: "140329058580000000000000"}, {name: "data", type: "bytes", value: "0x2e"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[37], \"155446959120000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4632088", timeStamp: "1511791609", hash: "0xed93ae3c6574caf83ff65c384777f6208e834605e40160edfc7230175696d0a3", nonce: "61", blockHash: "0x1ac953133f320337679e4b9b6a5c82d75705742e9907eb808cda6c918404ff4e", transactionIndex: "50", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000cf392b3f6b21c080a06f44c980bc3fb0e943af3e00000000000000000000000000000000000000000001492bf723ef8798aa0000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000012f00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4933920", gasUsed: "52495", confirmations: "3092098"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[37]}, {type: "uint256", name: "_amount", value: "1554469591200000000000000"}, {type: "bytes", name: "data", value: "0x2f"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[37], "1554469591200000000000000", "0x2f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1511791609 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xcf392b3f6b21c080a06f44c980bc3fb0e943af3e"}, {name: "_amount", type: "uint256", value: "1554469591200000000000000"}, {name: "data", type: "bytes", value: "0x2f"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: mint( addressList[38], \"199998890720000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4632088", timeStamp: "1511791609", hash: "0xb58cd8063f226d5de380a73715268decdaa561808b463f7b3329b468a6364ef6", nonce: "62", blockHash: "0x1ac953133f320337679e4b9b6a5c82d75705742e9907eb808cda6c918404ff4e", transactionIndex: "60", from: "0x15799d3098715234657b90261fc596914e5003aa", to: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60", value: "0", gas: "90000", gasPrice: "3000100000", isError: "0", txreceipt_status: "1", input: "0x94d008ef000000000000000000000000b5f1ab8ae9c78eadcb0de34ae0622aafc0b502c3000000000000000000000000000000000000000000002a59f62ace4d888e0000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000013000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5943102", gasUsed: "67431", confirmations: "3092098"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_th", value: addressList[38]}, {type: "uint256", name: "_amount", value: "199998890720000000000000"}, {type: "bytes", name: "data", value: "0x30"}], name: "mint", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mint(address,uint256,bytes)" ]( addressList[38], "199998890720000000000000", "0x30", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1511791609 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_th", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}], name: "NewIssue", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewIssue", events: [{name: "_th", type: "address", value: "0xb5f1ab8ae9c78eadcb0de34ae0622aafc0b502c3"}, {name: "_amount", type: "uint256", value: "199998890720000000000000"}, {name: "data", type: "bytes", value: "0x30"}], address: "0x8dbc20fae8a51b035be3f22162ce962cf4ec9c60"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "409740149152700000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
