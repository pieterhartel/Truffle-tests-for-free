const MarketPrice = artifacts.require( "./MarketPrice.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "MarketPrice" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x2138FfE292fd0953f7fe2569111246E4DE9ff1DC", "0x62A1D743b4d0beC7493293F93Cc682499802eddA", "0x004F3E7fFA2F06EA78e14ED2B13E87d710e8013F", "0xa82ee9C06b39bdE11653aEB5671FB97B2267d3Cd"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "creator", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "USD", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "tokens", outputs: [{name: "name", type: "string"}, {name: "eth", type: "uint256"}, {name: "usd", type: "uint256"}, {name: "eur", type: "uint256"}, {name: "gbp", type: "uint256"}, {name: "block", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "GBP", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sender", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "ETH", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "updatedAt", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_id", type: "uint256"}], name: "EUR", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}], name: "DeletePrice", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}], name: "UpdatedPrice", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}], name: "RequestUpdate", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["NewPrice(uint256,string)", "DeletePrice(uint256)", "UpdatedPrice(uint256)", "RequestUpdate(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xd766911918e4a4ff28516cc02a5ae3c2096061ee7408787974101985cf9e0628", "0x8c8f94f5f1a74ad515cd6e033cb9e9cfae911da33cb003cf67cc57b444fd3dd3", "0xb8240a65b4ca0c774d05dbd16bac0fc0f6e4631fe1d2b0a8a069a73c768582e1", "0xbb23a8e369bdbb341ed2a26729ed4c9e616f51e510b78ef899f5c1791b50de9c"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4268658 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4269052 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "MarketPrice", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "creator", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "creator()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "USD", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "USD(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tokens", outputs: [{name: "name", type: "string"}, {name: "eth", type: "uint256"}, {name: "usd", type: "uint256"}, {name: "eur", type: "uint256"}, {name: "gbp", type: "uint256"}, {name: "block", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokens(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "GBP", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "GBP(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sender", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sender()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "ETH", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ETH(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "updatedAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "updatedAt(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_id", value: random.range( maxRandom )}], name: "EUR", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "EUR(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "MarketPrice", function( accounts ) {

	it( "TEST: MarketPrice(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4268658", blockHash: "0x8a0279400711ec88db2140710a7673bd6c4b754061c78b789a4840f8e4d0118d", timeStamp: "1505285626", hash: "0x1a7e59702e5685cf6ce24a95de91f68823a52e85dd6388803b0ebcb6f4825d63", nonce: "72", transactionIndex: "123", from: "0x62a1d743b4d0bec7493293f93cc682499802edda", to: 0, value: "0", gas: "1173488", gasPrice: "17472000002", input: "0x9dd4fdd3", contractAddress: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", cumulativeGasUsed: "4821295", txreceipt_status: "", gasUsed: "977907", confirmations: "3436605", isError: "0"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "MarketPrice", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = MarketPrice.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1505285626 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = MarketPrice.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "41817623810384746" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: changeSender( addressList[4] )", async function( ) {
		const txOriginal = {blockNumber: "4268672", blockHash: "0x7b6a47d8bd2e173ae26a7d66db91acfba4b03835d2d7b9dfada9218336425678", timeStamp: "1505285937", hash: "0x7d523594f5db8cb83bc7aa711adfe51974255357bcde6f16959aabceac82c568", nonce: "73", transactionIndex: "30", from: "0x62a1d743b4d0bec7493293f93cc682499802edda", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "32771", gasPrice: "22463230501", input: "0xb280a7e7000000000000000000000000004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", contractAddress: "", cumulativeGasUsed: "943960", txreceipt_status: "", gasUsed: "28525", confirmations: "3436591", isError: "0"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_sender", value: addressList[4]}], name: "changeSender", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeSender(address)" ]( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1505285937 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "41817623810384746" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268679", blockHash: "0x0d44566f6b31cccd1c9de4a995a04d50097d2e9af4d40dcdd5553d951a38a4f1", timeStamp: "1505286192", hash: "0x4e7e4877173fbe597bf33eb7e970b93eb3409c0226ae200e8f4118dccceff084", nonce: "0", transactionIndex: "72", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000200b8c5638f000000000000000000000000000000000000000000000000000002666a2f1912000000000000000000000000000000000000000000000000000002aa530ca134000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2444270", txreceipt_status: "", gasUsed: "147522", confirmations: "3436584", isError: "0"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35233971190000"}, {type: "uint256", name: "eur", value: "42222262260000"}, {type: "uint256", name: "gbp", value: "46888976520000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35233971190000", "42222262260000", "46888976520000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1505286192 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188449852746787753" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: donate(  )", async function( ) {
		const txOriginal = {blockNumber: "4268709", blockHash: "0x767c1810c1cd31fa4244849a0f2eb6948c4cb4eadef238377865d5b41fc08e0d", timeStamp: "1505286812", hash: "0xc6b3ad23403886021f0e79ff89b5fc292a138b04969bbe188ea7a47b84504d49", nonce: "10", transactionIndex: "36", from: "0xa82ee9c06b39bde11653aeb5671fb97b2267d3cd", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "5000000000000000", gas: "38053", gasPrice: "22463230501", input: "0xed88c68e", contractAddress: "", cumulativeGasUsed: "1208809", txreceipt_status: "", gasUsed: "29452", confirmations: "3436554", isError: "0"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "5000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "donate", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "donate()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1505286812 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "879302935284548" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268735", blockHash: "0xedd5e5b168428b79f7721766ca9080dee1218cd85d04d4650ca0be3c92478832", timeStamp: "1505287507", hash: "0x6cc542c2ac194fff1b30c316bc0ed68b6bae86dcec7b85f4104a982265f2c85c", nonce: "1", transactionIndex: "111", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000202358f698200000000000000000000000000000000000000000000000000000268327faa93000000000000000000000000000000000000000000000000000002ac4dcc9f6a000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3994647", txreceipt_status: "", gasUsed: "62579", confirmations: "3436528", isError: "0"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35336188500000"}, {type: "uint256", name: "eur", value: "42344753310000"}, {type: "uint256", name: "gbp", value: "47025006180000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35336188500000", "42344753310000", "47025006180000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1505287507 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188449852746787753" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268738", blockHash: "0xd7dae9b59013ef50824906805e1364d5cdfd7748eda90c1af8bfe90a769f0941", timeStamp: "1505287582", hash: "0xd815017b196cfb79966e1da700c11a2a9ca9018173de34f5f723e72d5985c358", nonce: "2", transactionIndex: "145", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000201f83026fd00000000000000000000000000000000000000000000000000000267e8f43f3d000000000000000000000000000000000000000000000000000002abfc20445a000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5664843", txreceipt_status: "", gasUsed: "62579", confirmations: "3436525", isError: "0"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35319714050000"}, {type: "uint256", name: "eur", value: "42325011330000"}, {type: "uint256", name: "gbp", value: "47003082180000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35319714050000", "42325011330000", "47003082180000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1505287582 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188449852746787753" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268744", blockHash: "0x9f6cc5a9b1e1396b9a0586a50a670957ed5e2ab713916d7c66559ba50bf2e4fb", timeStamp: "1505287773", hash: "0x7679db2aa3e6c920c0bdc4e8885f9db1b1af11d2bf32d2cb0d8939e118b8125b", nonce: "3", transactionIndex: "89", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000201f83026fd00000000000000000000000000000000000000000000000000000267e8f43f3d000000000000000000000000000000000000000000000000000002abfc20445a000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3772638", txreceipt_status: "", gasUsed: "62579", confirmations: "3436519", isError: "0"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35319714050000"}, {type: "uint256", name: "eur", value: "42325011330000"}, {type: "uint256", name: "gbp", value: "47003082180000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35319714050000", "42325011330000", "47003082180000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1505287773 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188449852746787753" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268745", blockHash: "0x71a1dcd0e5bb4c19f1b3a4e4d98c55ac637f3c526ad40362803d822460b9d149", timeStamp: "1505287803", hash: "0xc6dd53bc4572a50f3a48014c334dc8d55993e0771d5b31c11860763538c59682", nonce: "4", transactionIndex: "70", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000201f83026fd00000000000000000000000000000000000000000000000000000267e8f43f3d000000000000000000000000000000000000000000000000000002abfc20445a000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3096092", txreceipt_status: "", gasUsed: "62579", confirmations: "3436518", isError: "0"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35319714050000"}, {type: "uint256", name: "eur", value: "42325011330000"}, {type: "uint256", name: "gbp", value: "47003082180000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35319714050000", "42325011330000", "47003082180000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1505287803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188449852746787753" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268750", blockHash: "0x11f939a1687aecdb86e4c95dcd32efa3de0eae98f44029b6a11c005040b53235", timeStamp: "1505287869", hash: "0xbaee0c6f7a3006a5b3b2e319f751bd896be72deb236fbc50cbb6b098f6377ae3", nonce: "5", transactionIndex: "53", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002031625fc59000000000000000000000000000000000000000000000000000002693fa1afa4000000000000000000000000000000000000000000000000000002ad78adc2b2000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1519691", txreceipt_status: "", gasUsed: "62579", confirmations: "3436513", isError: "0"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35396475930000"}, {type: "uint256", name: "eur", value: "42416998120000"}, {type: "uint256", name: "gbp", value: "47105236020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35396475930000", "42416998120000", "47105236020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1505287869 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268753", blockHash: "0x7ebc078e1afed6616fc60febb7ad2a91b7b2a6ae54c8ef98065f087ffcbe31b2", timeStamp: "1505287954", hash: "0x355fdfd14a3010aeb665dc860a3cf4ada0873c1b9f15eb156d9a9e8dd74b802c", nonce: "6", transactionIndex: "56", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002031625fc59000000000000000000000000000000000000000000000000000002693fa1afa4000000000000000000000000000000000000000000000000000002ad78adc2b2000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2565612", txreceipt_status: "", gasUsed: "62579", confirmations: "3436510", isError: "0"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35396475930000"}, {type: "uint256", name: "eur", value: "42416998120000"}, {type: "uint256", name: "gbp", value: "47105236020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35396475930000", "42416998120000", "47105236020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1505287954 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268757", blockHash: "0x5e41946272eb7ced851d06f240681cc3ce63cdb6fa0e0ec8d1c090d39a72b7ef", timeStamp: "1505288048", hash: "0xf6ed46442602245d9c7f9071282593f690fa5a7d899ff76b562dc83017b57cb2", nonce: "7", transactionIndex: "53", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002031625fc59000000000000000000000000000000000000000000000000000002693fa1afa4000000000000000000000000000000000000000000000000000002ad78adc2b2000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1978958", txreceipt_status: "", gasUsed: "62579", confirmations: "3436506", isError: "0"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35396475930000"}, {type: "uint256", name: "eur", value: "42416998120000"}, {type: "uint256", name: "gbp", value: "47105236020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35396475930000", "42416998120000", "47105236020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1505288048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268758", blockHash: "0x692aaa30acc5ca48591600447be9dab05ad0f7ce745ef0994a998c8afafa5bb2", timeStamp: "1505288067", hash: "0x94926b7b7e087de33bafdfe30a7e573d68ff681954d3f1d008f9c28cfe537620", nonce: "8", transactionIndex: "32", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002031625fc59000000000000000000000000000000000000000000000000000002693fa1afa4000000000000000000000000000000000000000000000000000002ad78adc2b2000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1340328", txreceipt_status: "", gasUsed: "62579", confirmations: "3436505", isError: "0"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35396475930000"}, {type: "uint256", name: "eur", value: "42416998120000"}, {type: "uint256", name: "gbp", value: "47105236020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35396475930000", "42416998120000", "47105236020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1505288067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268762", blockHash: "0xdec5c23ca7f7f9017cbf5625d95dcab679f912fc402a7a77bcf3015ed26e34be", timeStamp: "1505288273", hash: "0xf54952b8f93e1f437e654996445f800ba27b303db6de56c8e72e977b1283b0a9", nonce: "9", transactionIndex: "116", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002031625fc59000000000000000000000000000000000000000000000000000002693fa1afa4000000000000000000000000000000000000000000000000000002b19c7e80b5000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3526636", txreceipt_status: "", gasUsed: "62579", confirmations: "3436501", isError: "0"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35396475930000"}, {type: "uint256", name: "eur", value: "42416998120000"}, {type: "uint256", name: "gbp", value: "47389728050000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35396475930000", "42416998120000", "47389728050000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1505288273 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268764", blockHash: "0x14bf8f53c6f37d0c448aad723eec4f44168e4246083feb8dbd602dd79e1c2d3c", timeStamp: "1505288292", hash: "0x50054eecbc8f754a772968c1a643b4eed172407b3383760d434dcbd3da41ff66", nonce: "10", transactionIndex: "30", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002063287976a000000000000000000000000000000000000000000000000000002693fa1afa4000000000000000000000000000000000000000000000000000002b19c7e80b5000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1152714", txreceipt_status: "", gasUsed: "62579", confirmations: "3436499", isError: "0"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35610252900000"}, {type: "uint256", name: "eur", value: "42416998120000"}, {type: "uint256", name: "gbp", value: "47389728050000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35610252900000", "42416998120000", "47389728050000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1505288292 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268768", blockHash: "0xe253e702e5417e8ae088b3e1d1c2ed0735cd9be0e69bac436a4050ce565a74a0", timeStamp: "1505288364", hash: "0xd8bcab914fca662d960b2a62992c4a8aa22c3081f5def89356b764f92f963e4a", nonce: "11", transactionIndex: "53", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002063287976a0000000000000000000000000000000000000000000000000000026cf9f780a1000000000000000000000000000000000000000000000000000002b19c7e80b5000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1627805", txreceipt_status: "", gasUsed: "62579", confirmations: "3436495", isError: "0"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35610252900000"}, {type: "uint256", name: "eur", value: "42673175530000"}, {type: "uint256", name: "gbp", value: "47389728050000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35610252900000", "42673175530000", "47389728050000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1505288364 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268771", blockHash: "0x35108174371067c4e6a1673e6064c0d9a8231be4be073e8624ca06f9c6820c86", timeStamp: "1505288464", hash: "0x0eb6cf7e9748f1e20ca6a09c58e290847f0e04e70844b0cf4e304bee43fb0afb", nonce: "12", transactionIndex: "106", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020662425f3a0000000000000000000000000000000000000000000000000000026cf9f780a1000000000000000000000000000000000000000000000000000002b1dc031dfe000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4252889", txreceipt_status: "", gasUsed: "62579", confirmations: "3436492", isError: "0"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35623065220000"}, {type: "uint256", name: "eur", value: "42673175530000"}, {type: "uint256", name: "gbp", value: "47406778540000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35623065220000", "42673175530000", "47406778540000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1505288464 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268774", blockHash: "0x33d165a7f06e1fa205286d0d04bb01b77e76d3c942d6e61cf1a50910fa4049a7", timeStamp: "1505288557", hash: "0xc35606791019eb79b02499d154318c391dc8bcf3a0b322590e3a7862d2ec5b6f", nonce: "13", transactionIndex: "65", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020662425f3a0000000000000000000000000000000000000000000000000000026d3329c028000000000000000000000000000000000000000000000000000002b1dc031dfe000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3399718", txreceipt_status: "", gasUsed: "62579", confirmations: "3436489", isError: "0"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35623065220000"}, {type: "uint256", name: "eur", value: "42688529040000"}, {type: "uint256", name: "gbp", value: "47406778540000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35623065220000", "42688529040000", "47406778540000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1505288557 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268779", blockHash: "0xc551df9f389e73659d920db1f37014c8bb7c63a118e2bf2e6f0143606690efa4", timeStamp: "1505288593", hash: "0xf1a220600f7afea19dee47e9610c1eebd7f454a20cd5191613cd8759931faaf1", nonce: "14", transactionIndex: "33", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020662425f3a0000000000000000000000000000000000000000000000000000026d3329c028000000000000000000000000000000000000000000000000000002b1dc031dfe000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1102790", txreceipt_status: "", gasUsed: "62579", confirmations: "3436484", isError: "0"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35623065220000"}, {type: "uint256", name: "eur", value: "42688529040000"}, {type: "uint256", name: "gbp", value: "47406778540000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35623065220000", "42688529040000", "47406778540000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1505288593 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268784", blockHash: "0xe63eaef56a396e6138e77b5dc1c9c1b33502ccd3f47775dc970265301b72747f", timeStamp: "1505288719", hash: "0x3ef85262702954ea52c7945c551caaa97a933859e4753c8d8f990401eb693b22", nonce: "15", transactionIndex: "86", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020662425f3a0000000000000000000000000000000000000000000000000000026d3329c028000000000000000000000000000000000000000000000000000002b1dc031dfe000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2848422", txreceipt_status: "", gasUsed: "62579", confirmations: "3436479", isError: "0"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35623065220000"}, {type: "uint256", name: "eur", value: "42688529040000"}, {type: "uint256", name: "gbp", value: "47406778540000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35623065220000", "42688529040000", "47406778540000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1505288719 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268784", blockHash: "0xe63eaef56a396e6138e77b5dc1c9c1b33502ccd3f47775dc970265301b72747f", timeStamp: "1505288719", hash: "0x7066b766a06a88d5f84de14bd2a1dd71449944d64d93c3be00523482b366b3fe", nonce: "16", transactionIndex: "130", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020662425f3a0000000000000000000000000000000000000000000000000000026d8cb8962d000000000000000000000000000000000000000000000000000002b23f77fd64000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6457876", txreceipt_status: "", gasUsed: "62579", confirmations: "3436479", isError: "0"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35623065220000"}, {type: "uint256", name: "eur", value: "42712569570000"}, {type: "uint256", name: "gbp", value: "47433476200000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35623065220000", "42712569570000", "47433476200000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1505288719 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268787", blockHash: "0x53c877abb1e7186926e0e055681238a84eb3f59ffc1bc37d5f19d277fcb9bb2f", timeStamp: "1505288778", hash: "0xedb3ecd7b2c32ab6fad9ef8dbcc6602f8936de773c76021803f1d333754f67fb", nonce: "17", transactionIndex: "125", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000206acfe8c240000000000000000000000000000000000000000000000000000026d8cb8962d000000000000000000000000000000000000000000000000000002b23f77fd64000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4110243", txreceipt_status: "", gasUsed: "62579", confirmations: "3436476", isError: "0"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35643126760000"}, {type: "uint256", name: "eur", value: "42712569570000"}, {type: "uint256", name: "gbp", value: "47433476200000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35643126760000", "42712569570000", "47433476200000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1505288778 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268791", blockHash: "0xef282c58ca9ca300b466dddbf3c37667f9831e78ccbf9631432761faa7818401", timeStamp: "1505288932", hash: "0x45e09f012a37a67a2fa184a38e0e9e12e4ea0de0d9719a57cd5ecd6ed1c7fe7a", nonce: "18", transactionIndex: "85", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000206acfe8c240000000000000000000000000000000000000000000000000000026d8cb8962d000000000000000000000000000000000000000000000000000002b23f77fd64000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3426974", txreceipt_status: "", gasUsed: "62579", confirmations: "3436472", isError: "0"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35643126760000"}, {type: "uint256", name: "eur", value: "42712569570000"}, {type: "uint256", name: "gbp", value: "47433476200000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35643126760000", "42712569570000", "47433476200000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1505288932 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268796", blockHash: "0xe3e53991a0d06eba145194670b48f9267f7d0c80e7b4c4a6bb876c2e6e5da1cf", timeStamp: "1505289056", hash: "0x96c020b27e64e46d216b913c7e563a46ad6529ffeab3de88a544a181d19d9191", nonce: "19", transactionIndex: "46", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000206acfe8c240000000000000000000000000000000000000000000000000000026d8cb8962d000000000000000000000000000000000000000000000000000002b23f77fd64000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2205785", txreceipt_status: "", gasUsed: "62579", confirmations: "3436467", isError: "0"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35643126760000"}, {type: "uint256", name: "eur", value: "42712569570000"}, {type: "uint256", name: "gbp", value: "47433476200000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35643126760000", "42712569570000", "47433476200000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1505289056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268801", blockHash: "0x31bd002257f6dc28c5792de62ca0cd48ca11af4c30ed535816f5ec66cc823e89", timeStamp: "1505289150", hash: "0xc3d118130043f00883002e0ab019616bb6b13b1d1c6d97e2de8681a9f6e78a54", nonce: "20", transactionIndex: "122", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000209019ee7f40000000000000000000000000000000000000000000000000000027057ae9ea7000000000000000000000000000000000000000000000000000002b55973d951000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4180780", txreceipt_status: "", gasUsed: "62579", confirmations: "3436462", isError: "0"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35803282440000"}, {type: "uint256", name: "eur", value: "42904490470000"}, {type: "uint256", name: "gbp", value: "47646609610000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35803282440000", "42904490470000", "47646609610000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1505289150 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268804", blockHash: "0xd792d6450b6f56c515a0026f786b868021aff1435724592edf4806b83223ea95", timeStamp: "1505289201", hash: "0x38609f5abf7916609eadc4cbe5d8b61f6039977bea27b9aee8f0f98f65163293", nonce: "21", transactionIndex: "76", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000209019ee7f40000000000000000000000000000000000000000000000000000027057ae9ea7000000000000000000000000000000000000000000000000000002b55973d951000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2512123", txreceipt_status: "", gasUsed: "62579", confirmations: "3436459", isError: "0"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35803282440000"}, {type: "uint256", name: "eur", value: "42904490470000"}, {type: "uint256", name: "gbp", value: "47646609610000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35803282440000", "42904490470000", "47646609610000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1505289201 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268808", blockHash: "0x860959c6b6ef0fd529966e7bd25370a426b35dba1d98499db103ff01d16efe39", timeStamp: "1505289393", hash: "0x5cfb9a4860325bd72485e36bb3d24dc2aa31fadf08967be6127b570ca05a4761", nonce: "22", transactionIndex: "143", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020bd14f295300000000000000000000000000000000000000000000000000000273b61d012e000000000000000000000000000000000000000000000000000002b91734b7fa000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5183267", txreceipt_status: "", gasUsed: "62579", confirmations: "3436455", isError: "0"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35996472350000"}, {type: "uint256", name: "eur", value: "43135997580000"}, {type: "uint256", name: "gbp", value: "47903704580000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35996472350000", "43135997580000", "47903704580000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1505289393 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268811", blockHash: "0x4900fdfbd1e42da7decaa739ae6638dd86c918b42fdabfc2ee25cbaa2bebc520", timeStamp: "1505289526", hash: "0x12b46c34e6c750519a63a43d794dc3ea43a167c5bec03a93ef859d7f456a93c6", nonce: "23", transactionIndex: "145", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020bd14f295300000000000000000000000000000000000000000000000000000273b61d012e000000000000000000000000000000000000000000000000000002b91734b7fa000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5251746", txreceipt_status: "", gasUsed: "62579", confirmations: "3436452", isError: "0"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35996472350000"}, {type: "uint256", name: "eur", value: "43135997580000"}, {type: "uint256", name: "gbp", value: "47903704580000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35996472350000", "43135997580000", "47903704580000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1505289526 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268814", blockHash: "0x3211fcad05038b1afc4ccc8bb22f7a214867b160d43c7b7637db801aa219975a", timeStamp: "1505289600", hash: "0xcf67eba299d256b80a1f838d98ce076160fec9e40e066b4f4db9170e91e54f64", nonce: "24", transactionIndex: "93", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020bd14f295300000000000000000000000000000000000000000000000000000273b61d012e000000000000000000000000000000000000000000000000000002b91734b7fa000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5687067", txreceipt_status: "", gasUsed: "62579", confirmations: "3436449", isError: "0"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35996472350000"}, {type: "uint256", name: "eur", value: "43135997580000"}, {type: "uint256", name: "gbp", value: "47903704580000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35996472350000", "43135997580000", "47903704580000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1505289600 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268974", blockHash: "0x99f907ff131b3c6ade16871a33411492625eaaa40c0dd23d1beeea58de46b249", timeStamp: "1505293271", hash: "0x3b84549ade095de029d02f4e3975eedf40d114549e68e2a95419ef8dd38325df", nonce: "25", transactionIndex: "60", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002098049b1470000000000000000000000000000000000000000000000000000026e917737cc000000000000000000000000000000000000000000000000000002b602050c8e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1568418", txreceipt_status: "", gasUsed: "62579", confirmations: "3436289", isError: "0"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35837284390000"}, {type: "uint256", name: "eur", value: "42782562680000"}, {type: "uint256", name: "gbp", value: "47691859020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35837284390000", "42782562680000", "47691859020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1505293271 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268975", blockHash: "0xf861998327ffd3bff81d841f3c414ce153196efbe75324cfb11dc906c69dbda4", timeStamp: "1505293275", hash: "0xf0bc7b2441e434f32fa99c5791881c4db7fbc74bfce9eba96cfee976b01859ff", nonce: "26", transactionIndex: "32", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002098049b14700000000000000000000000000000000000000000000000000000270ef78eb43000000000000000000000000000000000000000000000000000002b602050c8e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1087421", txreceipt_status: "", gasUsed: "62579", confirmations: "3436288", isError: "0"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35837284390000"}, {type: "uint256", name: "eur", value: "42945236350000"}, {type: "uint256", name: "gbp", value: "47691859020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35837284390000", "42945236350000", "47691859020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1505293275 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268979", blockHash: "0xf30f9c67b516877d9f6662ed201cf9ab66727ff7f0411393f109bb48da68b241", timeStamp: "1505293379", hash: "0x6b9797cd76ad958dd16ec5fb4089c42837b668c2637b19a28ea851c8e8487887", nonce: "27", transactionIndex: "89", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002098049b14700000000000000000000000000000000000000000000000000000270ef78eb43000000000000000000000000000000000000000000000000000002b602050c8e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5882071", txreceipt_status: "", gasUsed: "62579", confirmations: "3436284", isError: "0"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35837284390000"}, {type: "uint256", name: "eur", value: "42945236350000"}, {type: "uint256", name: "gbp", value: "47691859020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35837284390000", "42945236350000", "47691859020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1505293379 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268984", blockHash: "0x35f286b8fd32fa12ca96a64e6af0414a4833bc9716f181fd109a85d39afa844a", timeStamp: "1505293545", hash: "0x32d5f7817ce37bd9a3dbb59e8c2cf8771db8126041ef965256debc34c26d342a", nonce: "28", transactionIndex: "141", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002098049b14700000000000000000000000000000000000000000000000000000270ef78eb43000000000000000000000000000000000000000000000000000002b602050c8e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4444065", txreceipt_status: "", gasUsed: "62579", confirmations: "3436279", isError: "0"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35837284390000"}, {type: "uint256", name: "eur", value: "42945236350000"}, {type: "uint256", name: "gbp", value: "47691859020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35837284390000", "42945236350000", "47691859020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1505293545 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268987", blockHash: "0x13c0e5bcc2ec33e3e054e6b5532eb478da9af5e1beee794e4233da993ed01658", timeStamp: "1505293596", hash: "0x68076d34510b3e1d9cea4f2036ca9f7263dae4734a6bad54a8ee427b404ab562", nonce: "29", transactionIndex: "63", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020c54bbacee00000000000000000000000000000000000000000000000000000274539a8f20000000000000000000000000000000000000000000000000000002b9c61a780e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2000128", txreceipt_status: "", gasUsed: "62515", confirmations: "3436276", isError: "0"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "36031751180000"}, {type: "uint256", name: "eur", value: "43178273600000"}, {type: "uint256", name: "gbp", value: "47950653260000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "36031751180000", "43178273600000", "47950653260000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1505293596 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4268991", blockHash: "0x81ed3bb68db73b1a3daa8724c1d163322fa9661c8acd606e9daa70477a813eda", timeStamp: "1505293659", hash: "0x5075956ade6492b4d6f262aba9680ca1f54207af375dd27901a8469ec007cbc3", nonce: "30", transactionIndex: "97", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020c54bbacee00000000000000000000000000000000000000000000000000000274539a8f20000000000000000000000000000000000000000000000000000002b9c61a780e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3284366", txreceipt_status: "", gasUsed: "62515", confirmations: "3436272", isError: "0"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "36031751180000"}, {type: "uint256", name: "eur", value: "43178273600000"}, {type: "uint256", name: "gbp", value: "47950653260000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "36031751180000", "43178273600000", "47950653260000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1505293659 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269001", blockHash: "0x3b91ca81b3dcd1f084ae51d697548b3b041ca5a5d144b9988cb5978e116f7a3c", timeStamp: "1505293939", hash: "0xf479c5dd5cc1fc38183d7978413a943a84797edc4249e8a325a86c4135b5b258", nonce: "31", transactionIndex: "173", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020c54bbacee00000000000000000000000000000000000000000000000000000274539a8f20000000000000000000000000000000000000000000000000000002b9c61a780e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5514154", txreceipt_status: "", gasUsed: "62515", confirmations: "3436262", isError: "0"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "36031751180000"}, {type: "uint256", name: "eur", value: "43178273600000"}, {type: "uint256", name: "gbp", value: "47950653260000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "36031751180000", "43178273600000", "47950653260000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1505293939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269003", blockHash: "0xa04af1e70cec5069743b537e73f79fcd5f758b8ef0834570a1f2caa1a5150f89", timeStamp: "1505294016", hash: "0x2ddb306fc171f8896839e36e5118553fa54c839b14a1e8edcc2398ad393b4345", nonce: "32", transactionIndex: "121", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020beb61563100000000000000000000000000000000000000000000000000000273d55aefe2000000000000000000000000000000000000000000000000000002b939e6a664000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4613056", txreceipt_status: "", gasUsed: "62579", confirmations: "3436260", isError: "0"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "36003470730000"}, {type: "uint256", name: "eur", value: "43144384020000"}, {type: "uint256", name: "gbp", value: "47913017960000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "36003470730000", "43144384020000", "47913017960000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1505294016 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269013", blockHash: "0xa788dafadee77de2ddd2b9fcada4ae80107a589dca99f078fe68031a020e34bd", timeStamp: "1505294268", hash: "0xf92c48342d3ea925134d93ee441cfa0ee0543dbd0a7e684d506cad8178c4dc43", nonce: "33", transactionIndex: "125", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020beb61563100000000000000000000000000000000000000000000000000000273d55aefe2000000000000000000000000000000000000000000000000000002b939e6a664000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4193371", txreceipt_status: "", gasUsed: "62579", confirmations: "3436250", isError: "0"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "36003470730000"}, {type: "uint256", name: "eur", value: "43144384020000"}, {type: "uint256", name: "gbp", value: "47913017960000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "36003470730000", "43144384020000", "47913017960000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1505294268 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269014", blockHash: "0x19701f063d441e8faa9cba17d2f37def95cf0956b3e329b9e45f965ca06d6884", timeStamp: "1505294313", hash: "0xcc686dce318a9bbbfde28669df85e8e387aaea545001a0137e6d0e05c2cdebcc", nonce: "34", transactionIndex: "76", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020a781a23ac0000000000000000000000000000000000000000000000000000027218701dbd000000000000000000000000000000000000000000000000000002b74bcee3b1000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2051947", txreceipt_status: "", gasUsed: "62579", confirmations: "3436249", isError: "0"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35903806520000"}, {type: "uint256", name: "eur", value: "43024952450000"}, {type: "uint256", name: "gbp", value: "47780385930000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35903806520000", "43024952450000", "47780385930000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1505294313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269015", blockHash: "0x6e51a17f1364ee2022e7f559f90cffab974d0b0caa5ae728acfb1225876493bc", timeStamp: "1505294319", hash: "0xa2fa060d386155242fbdcff3aa3a5f456c4ab67b70a122de90817ec02912d2bc", nonce: "35", transactionIndex: "41", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020a781a23ac0000000000000000000000000000000000000000000000000000027218701dbd000000000000000000000000000000000000000000000000000002b74bcee3b1000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3105822", txreceipt_status: "", gasUsed: "62579", confirmations: "3436248", isError: "0"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35903806520000"}, {type: "uint256", name: "eur", value: "43024952450000"}, {type: "uint256", name: "gbp", value: "47780385930000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35903806520000", "43024952450000", "47780385930000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1505294319 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269018", blockHash: "0xccb453887caec40fef60d4f202c6519feb3ed044331acbd0a4a119ac4ae025e9", timeStamp: "1505294461", hash: "0x4cc292d28b0b7ca171675f94285ad4e19c57cb0baa20b3e901b062f1a3bd559d", nonce: "36", transactionIndex: "143", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020a781a23ac0000000000000000000000000000000000000000000000000000027218701dbd000000000000000000000000000000000000000000000000000002b74bcee3b1000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4440580", txreceipt_status: "", gasUsed: "62579", confirmations: "3436245", isError: "0"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35903806520000"}, {type: "uint256", name: "eur", value: "43024952450000"}, {type: "uint256", name: "gbp", value: "47780385930000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35903806520000", "43024952450000", "47780385930000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1505294461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269024", blockHash: "0xd3a2bc853959fde02b72cdb9f460cdec11bee6c39d391db6e0746b91527434d6", timeStamp: "1505294652", hash: "0xc524fdc16c5fa5648e3850393511778292db9b5648f06cdf2f4539aa25d53da8", nonce: "37", transactionIndex: "65", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000208d8168b300000000000000000000000000000000000000000000000000000027025e971ee000000000000000000000000000000000000000000000000000002b5222e6be6000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3306507", txreceipt_status: "", gasUsed: "62515", confirmations: "3436239", isError: "0"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35792133600000"}, {type: "uint256", name: "eur", value: "42891130380000"}, {type: "uint256", name: "gbp", value: "47631772860000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35792133600000", "42891130380000", "47631772860000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1505294652 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269028", blockHash: "0xccc27bdc43db85dd44ca7729f3cfe468f3b2d765f6bad5d34325f3c35e694f41", timeStamp: "1505294740", hash: "0x8f317519d77cdcdc226d0cd9d52513c4fed8f0c1db3cdbbc96c09801eaed3818", nonce: "38", transactionIndex: "98", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000208d8168b300000000000000000000000000000000000000000000000000000026fb154aa42000000000000000000000000000000000000000000000000000002b5222e6be6000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4242338", txreceipt_status: "", gasUsed: "62515", confirmations: "3436235", isError: "0"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35792133600000"}, {type: "uint256", name: "eur", value: "42859835860000"}, {type: "uint256", name: "gbp", value: "47631772860000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35792133600000", "42859835860000", "47631772860000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1505294740 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269031", blockHash: "0xdef84639cafabaf5007b83f2c1fb3b37774758b53a9255f85f1cfe0aed53f8bd", timeStamp: "1505294791", hash: "0x7f1ed086dbb5e2eab4a0ce94731927d1510cdc86d7bb16a9e70c0f9d5f16765a", nonce: "39", transactionIndex: "64", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020876cd719f0000000000000000000000000000000000000000000000000000026fb154aa42000000000000000000000000000000000000000000000000000002b4a0b6fa38000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2044576", txreceipt_status: "", gasUsed: "62579", confirmations: "3436232", isError: "0"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35766018710000"}, {type: "uint256", name: "eur", value: "42859835860000"}, {type: "uint256", name: "gbp", value: "47597019440000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35766018710000", "42859835860000", "47597019440000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1505294791 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269034", blockHash: "0xfa2a805d107675806ed980d8779251682867e2e6edd2a9f44036be18303f0093", timeStamp: "1505294833", hash: "0x622e28e7c6718f4b415a8c08c36c7b8fa2aea720174220cbb5bd154a03930e1c", nonce: "40", transactionIndex: "38", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020876cd719f0000000000000000000000000000000000000000000000000000026fb154aa42000000000000000000000000000000000000000000000000000002b4a0b6fa38000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1684634", txreceipt_status: "", gasUsed: "62579", confirmations: "3436229", isError: "0"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35766018710000"}, {type: "uint256", name: "eur", value: "42859835860000"}, {type: "uint256", name: "gbp", value: "47597019440000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35766018710000", "42859835860000", "47597019440000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1505294833 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269037", blockHash: "0x529365c36670850f1b33e00e2efe3ccaa6eda90f70f6d06ffc9435a13460959e", timeStamp: "1505294948", hash: "0x49b9198b5dde5064c12286442882359e043456b0436e2bd7306c373b4caa8e9f", nonce: "41", transactionIndex: "146", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000020876cd719f0000000000000000000000000000000000000000000000000000026fb154aa42000000000000000000000000000000000000000000000000000002b4a0b6fa38000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6164530", txreceipt_status: "", gasUsed: "62579", confirmations: "3436226", isError: "0"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35766018710000"}, {type: "uint256", name: "eur", value: "42859835860000"}, {type: "uint256", name: "gbp", value: "47597019440000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35766018710000", "42859835860000", "47597019440000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1505294948 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269039", blockHash: "0xe4b56777c28201ea6cca1eb6e0aca3d9e33ae434dff63df41a90bf1aa771571d", timeStamp: "1505295033", hash: "0x3a00327b53e275495a26edf3e1710cf142a65cae7fc3e6bdedc88b94d988c068", nonce: "42", transactionIndex: "143", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002080e857c950000000000000000000000000000000000000000000000000000026f345dd9d2000000000000000000000000000000000000000000000000000002b415f04d1e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3934024", txreceipt_status: "", gasUsed: "62579", confirmations: "3436224", isError: "0"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35738025970000"}, {type: "uint256", name: "eur", value: "42826291060000"}, {type: "uint256", name: "gbp", value: "47559767020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35738025970000", "42826291060000", "47559767020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1505295033 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269042", blockHash: "0x1f806c9725830a5a5529de088a26533dad14ab8b2fffd66df5d5df7f5126dc1a", timeStamp: "1505295076", hash: "0xecf323abb328c944fa85f6909ca23689fcb58c74a6c68531827271d8e28afc1d", nonce: "43", transactionIndex: "78", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002080e857c950000000000000000000000000000000000000000000000000000026f345dd9d2000000000000000000000000000000000000000000000000000002b415f04d1e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2612325", txreceipt_status: "", gasUsed: "62579", confirmations: "3436221", isError: "0"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35738025970000"}, {type: "uint256", name: "eur", value: "42826291060000"}, {type: "uint256", name: "gbp", value: "47559767020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35738025970000", "42826291060000", "47559767020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1505295076 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269046", blockHash: "0x1d3ea52547da42bec70c3843e43c87164b0fbd24592b516f7dde249f0bd37bd4", timeStamp: "1505295144", hash: "0x12ba8cd8361dbae95c1f3f4271a44bff5becf6435c3d60ad2867a6b5b3e99174", nonce: "44", transactionIndex: "61", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002080e857c950000000000000000000000000000000000000000000000000000026f345dd9d2000000000000000000000000000000000000000000000000000002b415f04d1e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1599687", txreceipt_status: "", gasUsed: "62579", confirmations: "3436217", isError: "0"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35738025970000"}, {type: "uint256", name: "eur", value: "42826291060000"}, {type: "uint256", name: "gbp", value: "47559767020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35738025970000", "42826291060000", "47559767020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1505295144 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269051", blockHash: "0x368e95e8f03c0a92a2f2f7fc98191cf9e331deec162ceb21a261c7fa441b4604", timeStamp: "1505295236", hash: "0x5b0a7a7046d87a9ad673281b9121ed039251c869642a0d5ce418026f2ff45f0c", nonce: "45", transactionIndex: "66", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002080e857c950000000000000000000000000000000000000000000000000000026f345dd9d2000000000000000000000000000000000000000000000000000002b415f04d1e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3403165", txreceipt_status: "", gasUsed: "62579", confirmations: "3436212", isError: "0"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35738025970000"}, {type: "uint256", name: "eur", value: "42826291060000"}, {type: "uint256", name: "gbp", value: "47559767020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35738025970000", "42826291060000", "47559767020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1505295236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: update( \"0\", `ETH`, \"1000000000000000000\", \... )", async function( ) {
		const txOriginal = {blockNumber: "4269052", blockHash: "0x6ce1bc8539e85c53b787346d57773b1c3cabddb9b7065552f73349251dbeaf24", timeStamp: "1505295274", hash: "0xc04f784c09dca9f993205404951c12f0daf1d3fc7efa1b6b8e3b4ebdfe38c552", nonce: "46", transactionIndex: "64", from: "0x004f3e7ffa2f06ea78e14ed2b13e87d710e8013f", to: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc", value: "0", gas: "150000", gasPrice: "10000000000", input: "0x1833fa4c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000de0b6b3a764000000000000000000000000000000000000000000000000000000002080e857c950000000000000000000000000000000000000000000000000000026f345dd9d2000000000000000000000000000000000000000000000000000002b415f04d1e000000000000000000000000000000000000000000000000000000000000000034554480000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2649387", txreceipt_status: "", gasUsed: "62579", confirmations: "3436211", isError: "0"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "0"}, {type: "string", name: "_token", value: `ETH`}, {type: "uint256", name: "eth", value: "1000000000000000000"}, {type: "uint256", name: "usd", value: "35738025970000"}, {type: "uint256", name: "eur", value: "42826291060000"}, {type: "uint256", name: "gbp", value: "47559767020000"}], name: "update", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "update(uint256,string,uint256,uint256,uint256,uint256)" ]( "0", `ETH`, "1000000000000000000", "35738025970000", "42826291060000", "47559767020000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1505295274 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "id", type: "uint256"}, {indexed: false, name: "token", type: "string"}], name: "NewPrice", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewPrice", events: [{name: "id", type: "uint256", value: "0"}, {name: "token", type: "string", value: "ETH"}], address: "0x2138ffe292fd0953f7fe2569111246e4de9ff1dc"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "188324694746787753" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
