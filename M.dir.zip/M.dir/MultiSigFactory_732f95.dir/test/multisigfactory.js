const MultiSigFactory = artifacts.require( "./MultiSigFactory.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "MultiSigFactory" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x3B9A3c062Bdb640b5039C0cCda4157737d732F95", "0xc0FFeEE61948d8993864a73a099c0E38D887d3F4", "0xEAFF92BC4f35461fa747D14e07bB0380F422C0CB", "0x89bb5a1880608Fe606F6D2c3dc30c3624F3429fC", "0x0019B6D540c44F7af3eB701eEb0548eaCFC49fca", "0x00cE93832b0c878d21Ee78CbE27AD3E6574bba7A", "0x00c58C654b91B3De2b23D24b12534759D72FEd39", "0x7908ff65078a1A994e2C61030752b05EE2e62A19", "0x0dAEa6f111a8d8F28AA3d6504dee9EB0Ea01383f", "0x5f3371793285920351344a1EaaAA48d45e600652", "0xA02378cA1c24767eCD776aAFeC02158a30dc01ac", "0x0778358B4b865cA2c037b27e4584E4178157d6eD"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Create(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x96b5b9b8a7193304150caccf9b80d150675fa3d6af57761d8d8ef1d6f9a1a909"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4459308 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4578034 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "MultiSigFactory", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
}

contract( "MultiSigFactory", function( accounts ) {

	it( "TEST: MultiSigFactory(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4459308", timeStamp: "1509387540", hash: "0x70066c22124f041a2fe878fba956ec74e53e7213c6288d4f0732ab2b017bae99", nonce: "1", blockHash: "0xc844bf9260f71412129d243d0fe2d534bd20a11faeebe6955053053ea3948f51", transactionIndex: "8", from: "0xeaff92bc4f35461fa747d14e07bb0380f422c0cb", to: 0, value: "0", gas: "1308487", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x5317ce80", contractAddress: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", cumulativeGasUsed: "1606846", gasUsed: "1090406", confirmations: "3273321"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "MultiSigFactory", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = MultiSigFactory.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509387540 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = MultiSigFactory.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[6]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4459416", timeStamp: "1509389013", hash: "0x0e3b8eab294926de644ac8552b49330c425116caeb5b40eb234c0feaabceea62", nonce: "155", blockHash: "0xdcc381dd0a339922dcf567ff93d5eb854894845994dcf6b26f9f4f94ede43496", transactionIndex: "111", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000000019b6d540c44f7af3eb701eeb0548eacfc49fca", contractAddress: "", cumulativeGasUsed: "5147957", gasUsed: "816462", confirmations: "3273213"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[6]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[6]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509389013 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xec32ed815f5341e632484b49bb95406eb41ba479"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[7],addressList[8]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4459514", timeStamp: "1509390288", hash: "0x4e72613270689b2ba2a4877e3d18699c21ddda5da4dd51562aadc7a3cd5f2453", nonce: "3", blockHash: "0xc61539b38af361e637ad95000ae9ff01ed9aed5e46d9a760e0f9a890672c5207", transactionIndex: "100", from: "0xeaff92bc4f35461fa747d14e07bb0380f422c0cb", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "992249", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000ce93832b0c878d21ee78cbe27ad3e6574bba7a00000000000000000000000000c58c654b91b3de2b23d24b12534759d72fed39", contractAddress: "", cumulativeGasUsed: "5545347", gasUsed: "816398", confirmations: "3273115"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[7],addressList[8]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[7],addressList[8]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1509390288 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0xeaff92bc4f35461fa747d14e07bb0380f422c0cb"}, {name: "createdContract", type: "address", value: "0x53a2fd0d693c79efd2fe1fd628bfcce3f0a89314"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[9]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4463692", timeStamp: "1509448603", hash: "0x37da0f8da684704573eaadc571931d3aebeb2b54b82a2e19e59020c3c2549474", nonce: "156", blockHash: "0xe260910cc9e3231739cab4f3b5d9c53da0e6b7f4eebad6676d1086e771522092", transactionIndex: "103", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000007908ff65078a1a994e2c61030752b05ee2e62a19", contractAddress: "", cumulativeGasUsed: "5660545", gasUsed: "816526", confirmations: "3268937"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[9]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[9]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1509448603 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x5259834b776054a05306bf5b4420a755b4185051"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[9]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4464280", timeStamp: "1509457232", hash: "0xbc1e2780c6eb2e2ac8ed771a29a61233d5def13b6f20647ff6dd786d9f5fbafe", nonce: "158", blockHash: "0xbb59e5911d46ce127b7d7d7a1ebfab6ae5ef46104420cf78aef997971375dcf4", transactionIndex: "80", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000007908ff65078a1a994e2c61030752b05ee2e62a19", contractAddress: "", cumulativeGasUsed: "4302397", gasUsed: "816526", confirmations: "3268349"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[9]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[9]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509457232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x7d61c06ee6f933d9d697f7030d3bcca448a0fa69"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[9]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4471199", timeStamp: "1509553113", hash: "0x22dbfd1fad894050c68f61fb83a71260e5f91446f965b791bafcca8abe1905ed", nonce: "162", blockHash: "0x63124a6ad8d7840ce2c6e7c8d25b5b4dd14952d9fbdf7517755dd4e5025a6035", transactionIndex: "73", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000007908ff65078a1a994e2c61030752b05ee2e62a19", contractAddress: "", cumulativeGasUsed: "5405192", gasUsed: "816526", confirmations: "3261430"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[9]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[9]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509553113 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xb48b031c51f91c87244aeb3c658276fee03ac166"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[9]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4471201", timeStamp: "1509553131", hash: "0x77e829f4ccc3d233cf3a9734ce4fd5bcdc540105423c4fcf0b4ccc88c19c8ea4", nonce: "163", blockHash: "0x34e6584ed3afed8a851d33d638fab07f09dca46c08ba4b991b9a1ad9072a5f97", transactionIndex: "71", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000007908ff65078a1a994e2c61030752b05ee2e62a19", contractAddress: "", cumulativeGasUsed: "3411067", gasUsed: "816526", confirmations: "3261428"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[9]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[9]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1509553131 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x908e1e4e6e4b185e41add0b73e68455054a2a1c5"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[10]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4471204", timeStamp: "1509553196", hash: "0x772fa56eeb136c94cfe2be221e5448df4e148807db427795120c42574badfa51", nonce: "164", blockHash: "0xb2dd39a3410487aeeaee030edcd98387e9d12d877fd5bb67bd291bb628c16eef", transactionIndex: "119", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000000daea6f111a8d8f28aa3d6504dee9eb0ea01383f", contractAddress: "", cumulativeGasUsed: "5334249", gasUsed: "816526", confirmations: "3261425"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[10]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[10]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1509553196 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xd092dfeec167dc474ecf21f8a467eff1cefb4ca6"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[9]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4471411", timeStamp: "1509556396", hash: "0xf86dee8b0e6f87695f7e992870db05e4737509a071ef887662514167de08ce4e", nonce: "169", blockHash: "0x4ddd08ab6f13ffb0a425a48e8e0ebcf440fa8a88b402067efb7b130426d158ab", transactionIndex: "75", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000007908ff65078a1a994e2c61030752b05ee2e62a19", contractAddress: "", cumulativeGasUsed: "5560007", gasUsed: "816526", confirmations: "3261218"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[9]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[9]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1509556396 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xd9f8a83a14f7f66976f92a7202e4627814db2a93"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[9]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4471430", timeStamp: "1509556695", hash: "0x1b48262da03829fe3eeb777b45a0fefdf36d5452b2b22e7695334076532bf2d6", nonce: "170", blockHash: "0x2f3b0ca26b6e3b5ee045b8f131dd0e9f9b59f08976cc9883d740a52cfd23f00a", transactionIndex: "24", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000007908ff65078a1a994e2c61030752b05ee2e62a19", contractAddress: "", cumulativeGasUsed: "2741309", gasUsed: "816526", confirmations: "3261199"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[9]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[9]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1509556695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x26f895318c920e80da4a83cc534719fa9ba1d6bf"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[9]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4471430", timeStamp: "1509556695", hash: "0x92282c10159ac77c776c0fe8b9de09148ab0b69e77360fefa0679d005bbd6750", nonce: "171", blockHash: "0x2f3b0ca26b6e3b5ee045b8f131dd0e9f9b59f08976cc9883d740a52cfd23f00a", transactionIndex: "29", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000007908ff65078a1a994e2c61030752b05ee2e62a19", contractAddress: "", cumulativeGasUsed: "3945476", gasUsed: "816526", confirmations: "3261199"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[9]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[9]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1509556695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xbdc6d73c4689e1fe1459d6b076c3bfddedc28e76"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[9]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4471430", timeStamp: "1509556695", hash: "0x8b2f471497fd366164d6377db1bd9f6525f12689e87a6d05ba0121a4fa1b4f15", nonce: "172", blockHash: "0x2f3b0ca26b6e3b5ee045b8f131dd0e9f9b59f08976cc9883d740a52cfd23f00a", transactionIndex: "31", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000007908ff65078a1a994e2c61030752b05ee2e62a19", contractAddress: "", cumulativeGasUsed: "4947105", gasUsed: "816526", confirmations: "3261199"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[9]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[9]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1509556695 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x90e56557a5efdbfff2d1a7f7c433e94b6ec7b5cb"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[9]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4471431", timeStamp: "1509556705", hash: "0xc19a2bf9c0947fb9c5fa07f3efb1dfae9a8e92b93a74c89eec2072b69cabd097", nonce: "173", blockHash: "0xfbdf3db8304f34b548a7f34531a3dba6b1e315f4acb5562b5428864fde11ecd1", transactionIndex: "37", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000007908ff65078a1a994e2c61030752b05ee2e62a19", contractAddress: "", cumulativeGasUsed: "2920195", gasUsed: "816526", confirmations: "3261198"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[9]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[9]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1509556705 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x8470e71bbe0fd833b3908cb2a8069eaebab80c15"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[11]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4472320", timeStamp: "1509569493", hash: "0x26467fbb5e19012ad584688e1eb9700f18b4292c2bcb2894930712e0e4f1ac95", nonce: "174", blockHash: "0x8d24497271838c571f57e44e5d453c8ff41a11b05f9add5de62c84e0120244b7", transactionIndex: "29", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000005f3371793285920351344a1eaaaa48d45e600652", contractAddress: "", cumulativeGasUsed: "6112719", gasUsed: "816526", confirmations: "3260309"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[11]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[11]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1509569493 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x9d8f443d1f039d9ec0200f9e53861f4da8006c3c"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475418", timeStamp: "1509613272", hash: "0xda8d3131ce144da6f2657586cadd80bca0b5ac098bf21b1d778e4852ae8cac34", nonce: "175", blockHash: "0x2bdd755ffd02feaa22c4c88ee9717eae690bca9738165f734c3de7f41cfaf73c", transactionIndex: "50", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "2467111", gasUsed: "816526", confirmations: "3257211"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1509613272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x647e25066b9954bacd60c68162c36f7d540ef166"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475439", timeStamp: "1509613528", hash: "0x173ffecac37b26c369130a95e61f34a76d4152d2890c18f7de2193cec240eb4e", nonce: "176", blockHash: "0x51cfadf7572a4525db3af04c4a48afc01ba89920185b6e419e1a63f79a38e292", transactionIndex: "91", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "5143639", gasUsed: "816526", confirmations: "3257190"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1509613528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x61da1b575633c7fbc59f3fe94ccdc646621584d6"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475451", timeStamp: "1509613627", hash: "0x32de2ea4a42f0ef721a04a5390c3c16bb2fd9e91ea4e688d97b6ddacf6a4568a", nonce: "177", blockHash: "0x882e677a4d84441a0b49fd26c6abbfa93824b9dcb8cf46925505e8fc9c0f68be", transactionIndex: "69", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "3950261", gasUsed: "816526", confirmations: "3257178"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1509613627 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xf1ec1e7bacce8215f0b46e5e593562e30b65bedb"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475455", timeStamp: "1509613674", hash: "0x5ef591f55e519d14e5180a14a64b26b1fe9794f2be845b7b08c09bd7af2dfeb0", nonce: "178", blockHash: "0x3979e0648f4c7a621e12fc53c6f9ef2383e281c96659a50aaeaf91f18a90d966", transactionIndex: "88", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "4890620", gasUsed: "816526", confirmations: "3257174"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1509613674 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x7c6937edf4795d971e09128ffcdd9eaeeec18c86"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475455", timeStamp: "1509613674", hash: "0xeb5b39fb253f22bb59cc6664cc0af49714e88aba45ea20bb605d1b9621fb6866", nonce: "179", blockHash: "0x3979e0648f4c7a621e12fc53c6f9ef2383e281c96659a50aaeaf91f18a90d966", transactionIndex: "89", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "5707146", gasUsed: "816526", confirmations: "3257174"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1509613674 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xe9eb037a80da70c5465e185ca6f5588d1dc73a23"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475468", timeStamp: "1509613759", hash: "0x27f372f3c2a2ea95574f4e7af4c98c383677d0caac2e7f8653ce66e422e1ecec", nonce: "180", blockHash: "0xde533a20c7eee3fcba097b1f5ee25792774c4800fa1ab433badbb4fc153241c4", transactionIndex: "17", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "1663772", gasUsed: "816526", confirmations: "3257161"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1509613759 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xd7b22ca21fd8bacd2776bce0c2eb4311ddf07fd3"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475476", timeStamp: "1509613886", hash: "0x224567b7cc39395e8f22fdae96e70ed5633775fe0760536cdd9a51da87af9578", nonce: "181", blockHash: "0x22cb3883ef2575f62c718c1791437e7f303b7f532b10eae805d9f29a9a8b5d6c", transactionIndex: "56", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "3311230", gasUsed: "816526", confirmations: "3257153"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1509613886 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x57b440e5e243353341636dd3f29e571f1fefa1c5"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475485", timeStamp: "1509613981", hash: "0xd97d142ad2148b4d80afe43567a4dd6771e3e29ad44218cec8485372c22df48b", nonce: "182", blockHash: "0xdcfed071531f33c15245deaafce692c48b367f98f1305d1781d9160c594a81e3", transactionIndex: "77", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "4979577", gasUsed: "816526", confirmations: "3257144"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1509613981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x81033347441a133a25a4f1cb9c4b878a6623448f"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475510", timeStamp: "1509614289", hash: "0x193914d5b9c5d3dbaec88fafe24e5ec888a889f5b4e86e5c36ad98742cecd13c", nonce: "183", blockHash: "0xe12665eb54069c261c2c5280133bf279211d7d2a413c8fee2ba0252f0a751c83", transactionIndex: "57", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "2865666", gasUsed: "816526", confirmations: "3257119"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509614289 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x26332f5633a640821e42c5695dc1870df82d1708"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475519", timeStamp: "1509614377", hash: "0x2b774b68af45bd1933340f61cea0a822d1d7eae80bf8a5c97a745071f44acc91", nonce: "184", blockHash: "0xf3c156bc5756139e6ea8f4bda56f93558dd73814629578300f073beac126fe6d", transactionIndex: "13", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "1434240", gasUsed: "816526", confirmations: "3257110"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509614377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xf88f9442e0a70c68aa9550e37151f57600687af5"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475525", timeStamp: "1509614443", hash: "0x590b0f774ddfca7b32dad4235b38e599665f925dbc18ca348f6959cb5dd8be5f", nonce: "185", blockHash: "0xa7f95b5c930a75ef71b63b80a285429762469366dcce97ade6fd03aeb856ec1a", transactionIndex: "34", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "2021106", gasUsed: "816526", confirmations: "3257104"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509614443 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xff4fd9d96ab574a02abaf6155a526f813e35ab0e"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475533", timeStamp: "1509614577", hash: "0x6102a877655f2b1b78492561ca6ab1c226e2b73cc093a26df481585e682360e3", nonce: "186", blockHash: "0x3b40e55712f882bdea920c614e701d7b6fa6dca454524d985b82e96397b28b42", transactionIndex: "81", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "4286457", gasUsed: "816526", confirmations: "3257096"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509614577 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x17dfaf8326fb079decf84aa1ee80cbbb86922f6d"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475537", timeStamp: "1509614613", hash: "0x62226316af503bd844f4f27a5c2df779509c8335a9e11622058408696d7c0c21", nonce: "187", blockHash: "0x3a3aedde208a7048aa5f37c532471cac61519ecbdfd2b54fdbff2c16cf4c74ac", transactionIndex: "35", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "1857292", gasUsed: "816526", confirmations: "3257092"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509614613 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x4f9d74f50bc4b64e343ae49202a923ab0eec15b5"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475548", timeStamp: "1509614772", hash: "0xa175acb98a4ec74b918ca5769cd8956eaf9a8ec9072c4db355fe12f5496295be", nonce: "188", blockHash: "0x727114aeadfa63a7bd63c75ab513a083e1d358f7adacd2193210da30bcec04fa", transactionIndex: "21", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "3677748", gasUsed: "816526", confirmations: "3257081"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1509614772 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x6d3351a5f114f2c5f94bc42bde3740141d2b7710"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475550", timeStamp: "1509614820", hash: "0x560a7dd7fefc1552f93eaea78e774a97e69356acb798a996c307424bf1bb775f", nonce: "189", blockHash: "0x9602d45c590c8776291c572389d5c2c39176798a4cfbfd461e7330e6226015df", transactionIndex: "99", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "4496245", gasUsed: "816526", confirmations: "3257079"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1509614820 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x8624950151f6c5dccd0d557d78a91a1ab7cac028"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475561", timeStamp: "1509614934", hash: "0xce34300b8763b798db75cdd6b94c9ea19cd291735753d217d1d14e5710c547cc", nonce: "190", blockHash: "0x92db966c99b9384e2abbbe7a09d97392ea1814ee8a673e828e1080f406b656fc", transactionIndex: "83", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "6469602", gasUsed: "816526", confirmations: "3257068"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1509614934 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x03176fec3ede17dcf18ed02b0fe4bd0eb7382944"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475586", timeStamp: "1509615380", hash: "0x506758f852175c5f639e687fd4f1e2b69be9f7656f0493c34dfc752338435247", nonce: "191", blockHash: "0x468d946f9c2abffd204d2af1c4a6365f86a0a9903bd41a23ce72714fcf8eb900", transactionIndex: "43", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "2142585", gasUsed: "816526", confirmations: "3257043"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509615380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x7bb116bd18de0a46fb8c21d4287b3d94fb37ba07"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475591", timeStamp: "1509615463", hash: "0x7d5a40cce94d982487ac0873cde1b45099092dcab9172b708fe5aa5ed67db865", nonce: "192", blockHash: "0x1871e99a0ea768934245382a5326c06b0ce8aedfd008439b7d52561e660bfb71", transactionIndex: "35", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "2911817", gasUsed: "816526", confirmations: "3257038"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1509615463 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xa4862be7d3e27781cfe5393af1c4a3ae0a419f3b"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4475591", timeStamp: "1509615463", hash: "0x78090d615c841128489a882285f1af82301f9fcf9ab628f14c9cf36785167b81", nonce: "193", blockHash: "0x1871e99a0ea768934245382a5326c06b0ce8aedfd008439b7d52561e660bfb71", transactionIndex: "36", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "3728343", gasUsed: "816526", confirmations: "3257038"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1509615463 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x30e8e32b63e50cc1dd65d1b8419e013d776aa3ec"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4476684", timeStamp: "1509630513", hash: "0xdbfaf6b7bf3bcbf988b778b4a6ab03174a14982eda12095f1f016c42a8314289", nonce: "217", blockHash: "0x4a87e81817c18ab4dca1106375471f5c9fa0e101bbc3881ee673a07cc6659c4e", transactionIndex: "156", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "6583204", gasUsed: "816526", confirmations: "3255945"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1509630513 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x939c0f124e161ad1c72815c1aec82db038040c97"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4476722", timeStamp: "1509631043", hash: "0x2c707fb5224667d9adb6f8a8a033c78cbb105db3d10659da5db04aa537cc894d", nonce: "218", blockHash: "0x4f5ac9228d9dc0e705d205195774d4f55a9901caa35bdc3c96cc382deb08f05e", transactionIndex: "63", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "4039913", gasUsed: "816526", confirmations: "3255907"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1509631043 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xb116c746879f4dafa847776f0bacfd7184d0de5a"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4481316", timeStamp: "1509695660", hash: "0x72ff2089f564b7a8f11a6e20526fce0952085d4b913f55c653b80bc55bd2ec08", nonce: "221", blockHash: "0x0800bc98b540b39c6557b52e269ae83a97d7eaeec2024b42690490eece7018b5", transactionIndex: "58", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "6429546", gasUsed: "816526", confirmations: "3251313"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1509695660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x69bafd5b86c4a8d379a000a248c8e0d6386a7bbf"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4481317", timeStamp: "1509695662", hash: "0x622da7fd778670ab66814ed682dd0e1c9dabd85b3ed0132938fa38de801d98e5", nonce: "222", blockHash: "0x7a348745a229cb08a6f3f5039aa963ae130edf5d83f0535d04fdd7b0484de6d7", transactionIndex: "14", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "2090145", gasUsed: "816526", confirmations: "3251312"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1509695662 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xa9d4cb6ad2f05e161d06f6ed2c56d79d959856d0"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4481336", timeStamp: "1509695952", hash: "0xf48b8a8260aa8ad0fe4785b7511bbd34508c6cd021a050e9bc9d4668e38273cc", nonce: "223", blockHash: "0xaf80e7b07f7057285552dec061867cf5ad70d4cff33a1a3eb20d7c7559a7eeba", transactionIndex: "28", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "5301844", gasUsed: "816526", confirmations: "3251293"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1509695952 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x7165fdbf2e976852e7d2413513794a23faaf87ab"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4481359", timeStamp: "1509696272", hash: "0x07743b912934375e82000e86be4070098052fe0a7475ebc0b197180b8149f8b6", nonce: "224", blockHash: "0xb0b3f8b1ddfcc06a08af758f79ed0830711ea655f8715d0c1b42ff6d98e85ee9", transactionIndex: "60", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "3188258", gasUsed: "816526", confirmations: "3251270"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1509696272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xb80b92bd0ebe75698900fbc43801685af128f076"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4481360", timeStamp: "1509696289", hash: "0xcc1497a648dc8664122e2afcf1193d702c54962a38d03296a89742f3cd1b48d5", nonce: "225", blockHash: "0xa2fc2cf8ec0e1843191b64600483074ed4b4e901e6ad8f02e775d7abc500f100", transactionIndex: "71", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "6207012", gasUsed: "816526", confirmations: "3251269"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1509696289 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x535685beeb1aafb5c8208af7fd12e05256875e99"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[13]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4483120", timeStamp: "1509720773", hash: "0xe85fb25c331d477632e34c51c5e3f7ca633e23f7ece2d1fdfc3e6c368541f397", nonce: "239", blockHash: "0xb6d43c1295e710f4c9d26990e0c573d0dc41cb9486ec111e97d11b9e47272b49", transactionIndex: "58", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000000778358b4b865ca2c037b27e4584e4178157d6ed", contractAddress: "", cumulativeGasUsed: "6055334", gasUsed: "816526", confirmations: "3249509"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[13]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[13]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1509720773 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x76a9d9e6c715ada0e6c91f5912c1c0142a4f9c2a"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[13]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4489932", timeStamp: "1509815726", hash: "0xb025c042768bfc2308f86c5479d098633e2a0a4c7af1ad7b4bdeed256e4684ad", nonce: "241", blockHash: "0x4e6d38915e3e70808292f363ee7c170dc75fad772797c03bc8f50c4f222c57b1", transactionIndex: "57", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000000778358b4b865ca2c037b27e4584e4178157d6ed", contractAddress: "", cumulativeGasUsed: "2836683", gasUsed: "816526", confirmations: "3242697"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[13]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[13]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1509815726 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x5515409492d8f6469cc32f55ae928e7d1674d14a"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[10]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4500046", timeStamp: "1509954628", hash: "0x1568c955b7897b15d822cf4756025932f8f124f3cc8310cb8421af9449a8901e", nonce: "242", blockHash: "0xd91996033e6f54d2864219a33f592cad1373a4564aeb6d6e512e56475ad2b1c7", transactionIndex: "98", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000000daea6f111a8d8f28aa3d6504dee9eb0ea01383f", contractAddress: "", cumulativeGasUsed: "4704612", gasUsed: "816526", confirmations: "3232583"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[10]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[10]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1509954628 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x9116056375cbcb3100a0fc7aa7c07cda1eb95e36"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[6]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4524714", timeStamp: "1510297799", hash: "0x8cd337164c8ee186d2f40fd92c8f5a18b80dc9133ef84e81f28b25e633f3438e", nonce: "268", blockHash: "0x021cdb2848e55105cda2910db28f439e3a5361964aa221a138c7b9dbc798b9c3", transactionIndex: "57", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc0000000000000000000000000019b6d540c44f7af3eb701eeb0548eacfc49fca", contractAddress: "", cumulativeGasUsed: "3788872", gasUsed: "816462", confirmations: "3207915"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[6]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[6]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510297799 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xa84188e547b8bc51eb5d3d96e5e33cdee6eab80a"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4537710", timeStamp: "1510475901", hash: "0xff21c73365ae35a80d231385801fa168390e7cbaab2a8713d68e0836df3fff0b", nonce: "269", blockHash: "0xf5c1ef8be17406101e308f4866f23231d1d25ab93a10ff9f3dc6030241481a24", transactionIndex: "44", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "2712779", gasUsed: "816526", confirmations: "3194919"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510475901 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x6c4878a773e758494cff541c31b58e7fa9fd43aa"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4539083", timeStamp: "1510495018", hash: "0xa083a7e7d7780ea31fcc40742eb535c93055527786143fd8ffd53f58fe799787", nonce: "271", blockHash: "0x5d130762a00d1b938b73a88428833773c5f5282b253656b456ba00070ec9576d", transactionIndex: "148", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "6460400", gasUsed: "816526", confirmations: "3193546"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510495018 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x67571bd5cb9b2bcf7e139ca8c4cfc0cad09c949f"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4552372", timeStamp: "1510681182", hash: "0xd2fbf5af0b414ae29e8dc04738eeeb23f3d7f0e896d57d3f8d0db6e2e0b2da5e", nonce: "275", blockHash: "0x7fae88d16a912cebe0d965830245c123ad692be8d68d0544be54f49307d1e492", transactionIndex: "44", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "3279605", gasUsed: "816526", confirmations: "3180257"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510681182 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xeda93dacd83a7437725677e11bcd8a614975d1c3"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4578030", timeStamp: "1511038551", hash: "0x67b5ffa30279389521ca740f0907da193fffa9f33e68a4492e3959f6f91db550", nonce: "280", blockHash: "0xbe9be95ce5751a4b8ebdd5678d1b7a32e8f6c43c8a4aabbe54b0b8adc16c3bd7", transactionIndex: "98", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "4452966", gasUsed: "816526", confirmations: "3154599"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1511038551 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0xb3ecc4cd192d01640a8d3ec4a6fc5808338efcb4"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4578033", timeStamp: "1511038584", hash: "0x1171d99494fa565b38902ce3c444324c4d69e22d7c7f776930f651d988234901", nonce: "281", blockHash: "0x5e0619874b7d797b2717b17d08f0cdb8218e107fc88fef8e4b254c78412dae1e", transactionIndex: "23", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "1645229", gasUsed: "816526", confirmations: "3154596"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1511038584 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x1661f7146872ef013f544001b0c53b200cd7da1f"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: create( [addressList[5],addressList[12]], \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4578034", timeStamp: "1511038596", hash: "0x6e71dd841eb71d78b7fe454ae9688e97b6e5c74c40842e5484e3cc69eb213197", nonce: "282", blockHash: "0xc47d100563cca30db87c3674b20deca426929d71efcbd380f2a3e2052adeefaa", transactionIndex: "33", from: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc", to: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95", value: "0", gas: "865000", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf8f7380800000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000200000000000000000000000089bb5a1880608fe606f6d2c3dc30c3624f3429fc000000000000000000000000a02378ca1c24767ecd776aafec02158a30dc01ac", contractAddress: "", cumulativeGasUsed: "1921549", gasUsed: "816526", confirmations: "3154595"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "owners", value: [addressList[5],addressList[12]]}, {type: "uint256", name: "required", value: "2"}], name: "create", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "create(address[],uint256)" ]( [addressList[5],addressList[12]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1511038596 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "createdContract", type: "address"}], name: "Create", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Create", events: [{name: "caller", type: "address", value: "0x89bb5a1880608fe606f6d2c3dc30c3624f3429fc"}, {name: "createdContract", type: "address", value: "0x7bea0ce62f0e25609fa84c4ed10f88c812ce1961"}], address: "0x3b9a3c062bdb640b5039c0ccda4157737d732f95"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "862911254027025405" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
