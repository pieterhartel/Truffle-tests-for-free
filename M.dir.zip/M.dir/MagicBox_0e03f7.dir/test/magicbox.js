const MagicBox = artifacts.require( "./MagicBox.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "MagicBox" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x78A7A77Ef35e63A9d30cc333124c041A330e03F7", "0x60E08885aaa460249a187CD44D69067abbcec320", "0x0384B55daCD00f2Aa740fE125A1Ed5ebB01A5c6D", "0xEF53e26c78C21ec0480fe92E658099d96dad3341", "0x27d99A6d64e8fd38A47Fb87dF2d80867d6c1592c", "0x6a5D3B84c97E47972AE8b98b394e7d4970D9723A", "0xc54d59f4a6ad5E14e0367C02CCdfCA2b01e46894", "0xEeB473525FC724CD2B5408c9f65ac3063b01BE7B", "0x1Ad8fF6e2Dfec529A67b93fe1D44a653a8136Bcf", "0x8847916Be41B3Cc93077CEeF7dD3fd868a3F385d", "0x063c42609FE6EC3dC5C577Bbc5FeD0D084d7D73a", "0xD1BE4202106608748c843EDa9803aB834935B9B9", "0x0904F8a3203f5b52765837FFCA4C345A74C0e9F9", "0x00a3c3A3b8B795e88fa45b84fD9c23b8c5b01241", "0x517FF5B16C6059A5D9957420ccD05D7C8cAbd9fB", "0x275523fd59BA3598E01710DDB18A3312088BDD30"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "keyRequired", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "openNonce", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMagicBoxType", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "prizeRange", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "serverAddressList", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "boxPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "prizeIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "random", type: "uint256"}], name: "getPrizeIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "keyAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "openNonceId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "prizePoolAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "contractAddress", type: "address"}], name: "AddServerAddress", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "contractAddress", type: "address"}], name: "RemoveServerAddress", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "time", type: "uint256"}, {indexed: false, name: "openNonceId", type: "uint256"}], name: "OpenBoxV2", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["AddServerAddress(address)", "RemoveServerAddress(address)", "OpenBoxV2(address,uint256,uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x6941213f05c7c9c91fe0a2fad333b8cd922cfcccfe5263e7291df052f08ff4e3", "0x122bae6ff15711e730844adaef113cefed14bae8f407cf54ff54bca20f051166", "0xf97f33e31c9877e5cdd1f292c6501c6fe1226d2af2d4180fcf7646df061baac2", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6328975 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6665466 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "string", name: "_name", value: "Blue Incubator I"}, {type: "address", name: "_prizePoolAddress", value: 4}, {type: "address[]", name: "_serverAddress", value: [5]}, {type: "address", name: "_keyAddress", value: 6}, {type: "uint256", name: "_keyRequired", value: "30000000000000000000"}, {type: "uint256", name: "_boxPrice", value: "35000000000000000"}], name: "MagicBox", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "keyRequired", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "keyRequired()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "openNonce", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "openNonce(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMagicBoxType", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMagicBoxType()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "prizeRange", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prizeRange(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "serverAddressList", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "serverAddressList(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "boxPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "boxPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "prizeIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prizeIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "random", value: random.range( maxRandom )}], name: "getPrizeIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPrizeIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "keyAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "keyAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "openNonceId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "openNonceId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "prizePoolAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prizePoolAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "MagicBox", function( accounts ) {

	it( "TEST: MagicBox( `Blue Incubator I`, addressList[4], [add... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6328975", timeStamp: "1536911071", hash: "0x4e1f5086ee7721ac17eaf3dc491e1594d2475be24f7a394c5ff399cdd2f75c83", nonce: "350", blockHash: "0x5e293ee754276cbfe9a05a9ea0e4cbf1fb514e23e7e019b7fd7b5c406be56f32", transactionIndex: "49", from: "0x60e08885aaa460249a187cd44d69067abbcec320", to: 0, value: "0", gas: "4712388", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0701c74300000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000384b55dacd00f2aa740fe125a1ed5ebb01a5c6d000000000000000000000000000000000000000000000000000000000000010000000000000000000000000027d99a6d64e8fd38a47fb87df2d80867d6c1592c000000000000000000000000000000000000000000000001a055690d9db80000000000000000000000000000000000000000000000000000007c5850872380000000000000000000000000000000000000000000000000000000000000000010426c756520496e63756261746f722049000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ef53e26c78c21ec0480fe92e658099d96dad3341", contractAddress: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", cumulativeGasUsed: "4773266", gasUsed: "2747927", confirmations: "1378551"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "string", name: "_name", value: `Blue Incubator I`}, {type: "address", name: "_prizePoolAddress", value: addressList[4]}, {type: "address[]", name: "_serverAddress", value: [addressList[5]]}, {type: "address", name: "_keyAddress", value: addressList[6]}, {type: "uint256", name: "_keyRequired", value: "30000000000000000000"}, {type: "uint256", name: "_boxPrice", value: "35000000000000000"}], name: "MagicBox", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = MagicBox.new( `Blue Incubator I`, addressList[4], [addressList[5]], addressList[6], "30000000000000000000", "35000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1536911071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = MagicBox.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "contractAddress", type: "address"}], name: "AddServerAddress", type: "event"} ;
		console.error( "eventCallOriginal[0,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "AddServerAddress", events: [{name: "contractAddress", type: "address", value: "0xef53e26c78c21ec0480fe92e658099d96dad3341"}], address: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7"}] ;
		console.error( "eventResultOriginal[0,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3999459534687500" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setupPrize( [\"1\",\"2\",\"3\",\"4\",\"25\",\"26\",\... )", async function( ) {
		const txOriginal = {blockNumber: "6328983", timeStamp: "1536911164", hash: "0x222a340cc57c8231f3a0bf0591e2cb1b9fe64addc6d2ebb01862b0fe0dd03fc5", nonce: "351", blockHash: "0x0dfdffa49c02e009ab9ce0d20b1a80b418bf45ae4140721384b6674e89f37536", transactionIndex: "29", from: "0x60e08885aaa460249a187cd44d69067abbcec320", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4712388", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x691104b400000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000000000000000000000000000000000000000001b000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000088b8000000000000000000000000000000000000000000000000000000000000e67800000000000000000000000000000000000000000000000000000000000130b000000000000000000000000000000000000000000000000000000000000138800000000000000000000000000000000000000000000000000000000000014c080000000000000000000000000000000000000000000000000000000000015f90000000000000000000000000000000000000000000000000000000000001731800000000000000000000000000000000000000000000000000000000000186a0", contractAddress: "", cumulativeGasUsed: "1594366", gasUsed: "389345", confirmations: "1378543"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[]", name: "_prizeIndex", value: ["1","2","3","4","25","26","27","28"]}, {type: "uint256[]", name: "_prizeRange", value: ["35000","59000","78000","80000","85000","90000","95000","100000"]}], name: "setupPrize", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setupPrize(uint256[],uint256[])" ]( ["1","2","3","4","25","26","27","28"], ["35000","59000","78000","80000","85000","90000","95000","100000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1536911164 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "3999459534687500" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[7], \"200462040\", [\"455860... )", async function( ) {
		const txOriginal = {blockNumber: "6329368", timeStamp: "1536916991", hash: "0x3a0110433afb8bc0176043dc73997717b872a56f775daaf0520baf69f23bf050", nonce: "1814", blockHash: "0x062060397bb8f984b77d98aebb4921aef275cd464b79be86092ba5041d86f85c", transactionIndex: "7", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0x0e402acd0000000000000000000000006a5d3b84c97e47972ae8b98b394e7d4970d9723a000000000000000000000000000000000000000000000000000000000bf2ced800000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000401020200000009000a000007000100050c0801000100000000000000000000000113010000000a0005000f01000d0008090209010100000000000000000000000122010000000600050007030005000a0302000e010000000000000000000000013103000000030007000a0f000a0009050c0d08010000000000000000000000", contractAddress: "", cumulativeGasUsed: "189953", gasUsed: "42953", confirmations: "1378158"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[7]}, {type: "uint256", name: "_random", value: "200462040"}, {type: "uint256[]", name: "_gene", value: ["455860346205531200847663252384953389909485429679960240980919550488686362624","485889844560418550702242094260270297587523969546612868777564434896068280320","512392550532087887893811530577783523160197157980484152585902939506749734912","538909059996452413200044082908922294022401527257614891234622031945957113856"]}, {type: "uint256", name: "_openNonceId", value: "1"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[7], "200462040", ["455860346205531200847663252384953389909485429679960240980919550488686362624","485889844560418550702242094260270297587523969546612868777564434896068280320","512392550532087887893811530577783523160197157980484152585902939506749734912","538909059996452413200044082908922294022401527257614891234622031945957113856"], "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1536916991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[3], \"1503247977\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6329424", timeStamp: "1536917877", hash: "0x9cc9fc0191508123f48e40ce1f5b449c0e22e14bb99c4ff79d5b425b63d7b3c5", nonce: "1818", blockHash: "0xb0eed56b85c481a102c75a725c18bb464e9dfa1033c33b5f55df231b187b1e8e", transactionIndex: "15", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "1", txreceipt_status: "0", input: "0x0e402acd00000000000000000000000060e08885aaa460249a187cd44d69067abbcec320000000000000000000000000000000000000000000000000000000005999be690000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000040102020000000f000800020c000f0002040a0102010000000000000000000000011301000000070000000606000a000c0e0a030e0100000000000000000000000122010000000c000f000e05000e00040f03060f01000000000000000000000001310300000002000c00010f000d00020206000c010000000000000000000000", contractAddress: "", cumulativeGasUsed: "521671", gasUsed: "44173", confirmations: "1378102"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[3]}, {type: "uint256", name: "_random", value: "1503247977"}, {type: "uint256[]", name: "_gene", value: ["455860346205540842426889704615556907692689971838884172007652291916230295552","485889844560413729765506314027841438418991667118980748204063376701111926784","512392550532097529767278992992117068590970610813344998605568445715809566720","538909059996450806384596099888212350178253329277119734317105019622464159744"]}, {type: "uint256", name: "_openNonceId", value: "2"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[3], "1503247977", ["455860346205540842426889704615556907692689971838884172007652291916230295552","485889844560413729765506314027841438418991667118980748204063376701111926784","512392550532097529767278992992117068590970610813344998605568445715809566720","538909059996450806384596099888212350178253329277119734317105019622464159744"], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1536917877 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6329617", timeStamp: "1536920643", hash: "0x724f0e0e2d4d15969344d51d300d1bfa213cf689e6a6c2889ff6f47d0d8187fd", nonce: "1824", blockHash: "0x8cb062ce33024bf14e619e26b0dea3c6e03a5b51e44335d7bfcbbd677d0a4ed2", transactionIndex: "97", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "35000000000000000", gas: "73644", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6007281", gasUsed: "49096", confirmations: "1377909"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "35000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1536920643 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "time", type: "uint256"}, {indexed: false, name: "openNonceId", type: "uint256"}], name: "OpenBoxV2", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OpenBoxV2", events: [{name: "addr", type: "address", value: "0xef53e26c78c21ec0480fe92e658099d96dad3341"}, {name: "time", type: "uint256", value: "1536920643"}, {name: "openNonceId", type: "uint256", value: "3"}], address: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[5], \"1537174258\", [\"45762... )", async function( ) {
		const txOriginal = {blockNumber: "6329618", timeStamp: "1536920660", hash: "0xfe20ad74282509c02bf588779c63e8a2321b7192248718e58f6b72bf8e08efca", nonce: "1825", blockHash: "0x67f53f5a2613d70cf52683367a38cd3eaeb71a9a78210e81d4b3bb05164ec93a", transactionIndex: "13", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000ef53e26c78c21ec0480fe92e658099d96dad3341000000000000000000000000000000000000000000000000000000005b9f6af2000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000004010302000000060000000209000700030d0807040100000000000000000000000113010000000900070001010007000203060e0101000000000000000000000001220100000002000f000e04000c000708080007010000000000000000000000013204000000030005000b0f000400040c0c010e010000000000000000000000", contractAddress: "", cumulativeGasUsed: "2842520", gasUsed: "118927", confirmations: "1377908"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[5]}, {type: "uint256", name: "_random", value: "1537174258"}, {type: "uint256[]", name: "_gene", value: ["457627193270304764117915237588302857077756122343110315343404028334887141376","485889844560416943813232454555701198616000008606672452533587721751120314368","512392550532081460386836401627815411160315563685682603816604882331641053184","540682808807577588044375332002104396644062752251376572821310840968663007232"]}, {type: "uint256", name: "_openNonceId", value: "3"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[5], "1537174258", ["457627193270304764117915237588302857077756122343110315343404028334887141376","485889844560416943813232454555701198616000008606672452533587721751120314368","512392550532081460386836401627815411160315563685682603816604882331641053184","540682808807577588044375332002104396644062752251376572821310840968663007232"], "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1536920660 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6329649", timeStamp: "1536920960", hash: "0xf82f864e40610bcc227744a9b6f2887d0f88c2a462934f7308dc40926308c92d", nonce: "59", blockHash: "0x6fd4383d2b2adfd9d924044a6d3ce2a52f113ce4f650e46bee2a0056825e5ae0", transactionIndex: "104", from: "0xc54d59f4a6ad5e14e0367c02ccdfca2b01e46894", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "35000000000000000", gas: "73644", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6638328", gasUsed: "49096", confirmations: "1377877"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "35000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1536920960 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "time", type: "uint256"}, {indexed: false, name: "openNonceId", type: "uint256"}], name: "OpenBoxV2", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OpenBoxV2", events: [{name: "addr", type: "address", value: "0xc54d59f4a6ad5e14e0367c02ccdfca2b01e46894"}, {name: "time", type: "uint256", value: "1536920960"}, {name: "openNonceId", type: "uint256", value: "4"}], address: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "25819992065987650" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[8], \"1738002173\", [\"45762... )", async function( ) {
		const txOriginal = {blockNumber: "6329653", timeStamp: "1536920993", hash: "0xaa8a78a0427685bdc505399329a30a09a83bfa74432c98676e8a11079db67abf", nonce: "1830", blockHash: "0x08d701d6205cd93963a5e1ebf158eaf55793813c01b9d26cef0502b371ce9b88", transactionIndex: "29", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000c54d59f4a6ad5e14e0367c02ccdfca2b01e46894000000000000000000000000000000000000000000000000000000006797cefd0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000040103020000000c0000000c02000f000a0804060a01000000000000000000000001130100000002000b000d02000900080a080006010000000000000000000000012201000000040002000806000300040900000901000000000000000000000001320300000003000d000c020002000300000101010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1422605", gasUsed: "115870", confirmations: "1377873"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[8]}, {type: "uint256", name: "_random", value: "1738002173"}, {type: "uint256[]", name: "_gene", value: ["457627193270314405746184522743814622982358227784405555980601789929400303616","485889844560405695345006847433765413222361429908097216432262353136172138496","512392550532084673944163605164549239214541353319373701677569139030477504512","540675907061230797676747681621929163051195371404149272002983718925381926912"]}, {type: "uint256", name: "_openNonceId", value: "4"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[8], "1738002173", ["457627193270314405746184522743814622982358227784405555980601789929400303616","485889844560405695345006847433765413222361429908097216432262353136172138496","512392550532084673944163605164549239214541353319373701677569139030477504512","540675907061230797676747681621929163051195371404149272002983718925381926912"], "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1536920993 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"2089505571\", [\"45762... )", async function( ) {
		const txOriginal = {blockNumber: "6334090", timeStamp: "1536984628", hash: "0x4f6a9e98293a1d6c0ba09a413903e540a22a261399c83760a195c44d35e9fede", nonce: "1837", blockHash: "0x75a99becc22a7b271bc136ff71fd048b3e711d5538fc5cb4ec320cb48f0c277a", transactionIndex: "32", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b000000000000000000000000000000000000000000000000000000007c8b53230000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000040103020000000100040009060007000801040b00010000000000000000000000011301000000090003000e03000300070c08000e0100000000000000000000000122010000000a000d0004050007000e070f030a01000000000000000000000001320300000001000600040a000c000b06020d02010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1445069", gasUsed: "116126", confirmations: "1373436"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "2089505571"}, {type: "uint256[]", name: "_gene", value: ["457627193270296729525776271878771220872989702940448173591494158518769942528","485889844560416943715157606740647422320374282883684758521668093889289912320","512392550532094315842146876259509872263710599386205658667067394484328202240","540675907061227583629016681601281382131152924156543893931049944936865595392"]}, {type: "uint256", name: "_openNonceId", value: "5"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "2089505571", ["457627193270296729525776271878771220872989702940448173591494158518769942528","485889844560416943715157606740647422320374282883684758521668093889289912320","512392550532094315842146876259509872263710599386205658667067394484328202240","540675907061227583629016681601281382131152924156543893931049944936865595392"], "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1536984628 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[10], \"2104165233\", [\"4558... )", async function( ) {
		const txOriginal = {blockNumber: "6342332", timeStamp: "1537102435", hash: "0xfa627d6a0d14b8c6ae37b25d777bd69788d09bfe629eef8bf1aac215ee58c742", nonce: "1840", blockHash: "0x7b0dfeb3e7950083c8eb07bb26b2033a4016345c83ff1b9e1358114d7190df04", transactionIndex: "72", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000001ad8ff6e2dfec529a67b93fe1d44a653a8136bcf000000000000000000000000000000000000000000000000000000007d6b037100000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000401020200000006000600050d0009000d08050d050100000000000000000000000113010000000b000d000805000e000507030606010000000000000000000000012201000000080009000008000f0004030a0a0a0100000000000000000000000131040000000d0006000d02000000060c090902010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1775852", gasUsed: "118927", confirmations: "1365194"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[10]}, {type: "uint256", name: "_random", value: "2104165233"}, {type: "uint256[]", name: "_gene", value: ["455860346205526379935452640289993893307941941657208541630346177770499866624","485889844560420157836443169316474365486765087710500919795997839088953589760","512392550532091101867977151470548589106134065646349162228887655854137933824","538915961742815273119755282347198945303203611820936706869218067345007706112"]}, {type: "uint256", name: "_openNonceId", value: "6"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[10], "2104165233", ["455860346205526379935452640289993893307941941657208541630346177770499866624","485889844560420157836443169316474365486765087710500919795997839088953589760","512392550532091101867977151470548589106134065646349162228887655854137933824","538915961742815273119755282347198945303203611820936706869218067345007706112"], "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1537102435 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[7], \"633401670\", [\"457627... )", async function( ) {
		const txOriginal = {blockNumber: "6370938", timeStamp: "1537510776", hash: "0x2e56f02a750183266ddf20a92dd7701938f7f1c703327a0be9ec7275c7bbf32d", nonce: "1847", blockHash: "0x521f961109d780938832a008cc7e4d3a8625361d16111d1a99526500325c408b", transactionIndex: "54", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000006a5d3b84c97e47972ae8b98b394e7d4970d9723a0000000000000000000000000000000000000000000000000000000025c0f14600000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000007000000000000000000000000000000000000000000000000000000000000000401030200000009000c000201000d000503070609010000000000000000000000011301000000070005000105000f00020d0b0a0e0100000000000000000000000122010000000400030003020008000d0d07000201000000000000000000000001320400000002000d00000c0009000304040602010000000000000000000000", contractAddress: "", cumulativeGasUsed: "2325224", gasUsed: "116126", confirmations: "1336588"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[7]}, {type: "uint256", name: "_random", value: "633401670"}, {type: "uint256[]", name: "_gene", value: ["457627193270309585226287146713500850260070854854048240076288898879092424704","485889844560413729888104085113626626522866300554998661809049185782868213760","512392550532084673968681657250412634862815145133159560354971014022092029952","540682808807575981302486382269658496111547438691401876530593258278104334336"]}, {type: "uint256", name: "_openNonceId", value: "7"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[7], "633401670", ["457627193270309585226287146713500850260070854854048240076288898879092424704","485889844560413729888104085113626626522866300554998661809049185782868213760","512392550532084673968681657250412634862815145133159560354971014022092029952","540682808807575981302486382269658496111547438691401876530593258278104334336"], "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1537510776 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"1457134177\", [\"4540... )", async function( ) {
		const txOriginal = {blockNumber: "6373420", timeStamp: "1537546704", hash: "0x78825201fc28f1efa005bc8c121ac3430f2d8caf2ef9cd4a206f876cc5433718", nonce: "1850", blockHash: "0x4452f34f7496da444c3a748c13cc82615de7f8e20ef1627c970f231388866c96", transactionIndex: "22", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d0000000000000000000000000000000000000000000000000000000056da1a610000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000040101020000000f00070003060004000b030f0400010000000000000000000000011301000000050005000909000e000b010005070100000000000000000000000122010000000a000a0009060003000e00010703010000000000000000000000013001000000090000000f0d0006000c070a0f0d010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1492333", gasUsed: "115998", confirmations: "1334106"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "1457134177"}, {type: "uint256[]", name: "_gene", value: ["454093499140762458072786843836123795032912746039981307643479550728515616768","485889844560410516012018566134413047912804590674866957230954769621134082048","512392550532094315768588962481455424958976830959222762848530758686704926720","537128409438990089199513837060131828028718876015853677047999453889860468736"]}, {type: "uint256", name: "_openNonceId", value: "8"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "1457134177", ["454093499140762458072786843836123795032912746039981307643479550728515616768","485889844560410516012018566134413047912804590674866957230954769621134082048","512392550532094315768588962481455424958976830959222762848530758686704926720","537128409438990089199513837060131828028718876015853677047999453889860468736"], "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1537546704 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[12], \"995648331\", [\"45762... )", async function( ) {
		const txOriginal = {blockNumber: "6381562", timeStamp: "1537661609", hash: "0xb604b245d636ae837c03d0f5ef134b79462d1227293308afba97be5a77c1cab8", nonce: "1852", blockHash: "0x7cd869ac938b341f9920345183c8f5d302f9499fc9b9e3a8f4d3bb62305a7919", transactionIndex: "62", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000063c42609fe6ec3dc5c577bbc5fed0d084d7d73a000000000000000000000000000000000000000000000000000000003b58634b0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000040103020000000200040003080005000407030b0f01000000000000000000000001130100000002000c00070a0008000807060f0301000000000000000000000001220100000004000000020b00070008070700050100000000000000000000000132030000000e00060003030005000207050b0b010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1485027", gasUsed: "120083", confirmations: "1325964"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[12]}, {type: "uint256", name: "_random", value: "995648331"}, {type: "uint256[]", name: "_gene", value: ["457627193270298336463818288925490494386449167586753781850051438429511614464","485889844560405695369524542913095492587239671906323987129730360719316090880","512392550532084673895121510297923246474007958554932177889590166040543756288","540675907061248473823591664099776701333299620085423532670082535313670930432"]}, {type: "uint256", name: "_openNonceId", value: "9"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[12], "995648331", ["457627193270298336463818288925490494386449167586753781850051438429511614464","485889844560405695369524542913095492587239671906323987129730360719316090880","512392550532084673895121510297923246474007958554932177889590166040543756288","540675907061248473823591664099776701333299620085423532670082535313670930432"], "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1537661609 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"450839824\", [\"454093... )", async function( ) {
		const txOriginal = {blockNumber: "6382304", timeStamp: "1537672232", hash: "0xac5da671266788a1ee6462d2d7446d620b1be48b1293b49347e76468fb36fce6", nonce: "1853", blockHash: "0x2b694d9688aae45be21fbf900817967afa0427c72344495d457faef15fac5c06", transactionIndex: "8", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b000000000000000000000000000000000000000000000000000000001adf45100000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000004010102000000000006000e0a000c000a00090d0a0100000000000000000000000113010000000f000900050c000a00010c070a0501000000000000000000000001220100000009000300090c000f000e0802090d0100000000000000000000000133030000000b000e000e070001000f050e0606010000000000000000000000", contractAddress: "", cumulativeGasUsed: "569875", gasUsed: "120083", confirmations: "1325222"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "450839824"}, {type: "uint256[]", name: "_gene", value: ["454093499140738353977607151762932122631310634187422711284789579372984008704","485889844560426585490539378459324433247822889659582497805857200584962080768","512392550532092708658905211683477763799188557075831731254051303291487256576","542442754126022037535205735295054842419212654712561453464491486315118854144"]}, {type: "uint256", name: "_openNonceId", value: "10"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "450839824", ["454093499140738353977607151762932122631310634187422711284789579372984008704","485889844560426585490539378459324433247822889659582497805857200584962080768","512392550532092708658905211683477763799188557075831731254051303291487256576","542442754126022037535205735295054842419212654712561453464491486315118854144"], "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1537672232 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"291469974\", [\"455860... )", async function( ) {
		const txOriginal = {blockNumber: "6382442", timeStamp: "1537674533", hash: "0xb996d6abe1e6128f866d0de2f9be35dcb5ebd56f2fb35942e804b348c5d7eece", nonce: "1854", blockHash: "0x151e3d859f1faa80543ae534f2e6068870e9737a74489d7d4c5df208a1601c09", transactionIndex: "5", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b00000000000000000000000000000000000000000000000000000000115f7a960000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000000401020200000004000c000d0300040002040804080100000000000000000000000113010000000f000d0008090003000c070b0c08010000000000000000000000012201000000030007000602000600050908050401000000000000000000000001310400000006000c0002060005000a00030903010000000000000000000000", contractAddress: "", cumulativeGasUsed: "316644", gasUsed: "118991", confirmations: "1325084"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "291469974"}, {type: "uint256[]", name: "_gene", value: ["455860346205523166206486672772793512691905666405525473617097263651233988608","485889844560426585588620211123337776843580516995444916375307631771066040320","512392550532083067128718235308766845751130579408560787488287571806594793472","538915961742804024700560931595902812543092780675518630406318412469282799616"]}, {type: "uint256", name: "_openNonceId", value: "11"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "291469974", ["455860346205523166206486672772793512691905666405525473617097263651233988608","485889844560426585588620211123337776843580516995444916375307631771066040320","512392550532083067128718235308766845751130579408560787488287571806594793472","538915961742804024700560931595902812543092780675518630406318412469282799616"], "11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1537674533 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[13], \"1255029086\", [\"4576... )", async function( ) {
		const txOriginal = {blockNumber: "6395338", timeStamp: "1537857066", hash: "0x16448c94d11130d005cabef19e88ea63f6db7688321dfd81f859a49a66678952", nonce: "1855", blockHash: "0x2511c0f2e79b39dfdcf462cd7968c20de253a66426c92a0419b12b118aeca4a0", transactionIndex: "45", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000d1be4202106608748c843eda9803ab834935b9b9000000000000000000000000000000000000000000000000000000004ace395e0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000000000000000000000401030200000006000d000403000d000b0f0e0a0d0100000000000000000000000113010000000d00010001040002000302000c080100000000000000000000000122010000000600000004020000000d080b0404010000000000000000000000013204000000050007000a0c000d00040f03090e010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1919866", gasUsed: "116062", confirmations: "1312188"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[13]}, {type: "uint256", name: "_random", value: "1255029086"}, {type: "uint256[]", name: "_gene", value: ["457627193270304764436675049608370036249308705494260216286911568556310134784","485889844560423371418289922978071444667606105279779948196858847006921064448","512392550532087887771210763413641804328732695809938953150736404429641089024","540682808807580801969503328761640562042586615874198422433667841123122413568"]}, {type: "uint256", name: "_openNonceId", value: "12"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[13], "1255029086", ["457627193270304764436675049608370036249308705494260216286911568556310134784","485889844560423371418289922978071444667606105279779948196858847006921064448","512392550532087887771210763413641804328732695809938953150736404429641089024","540682808807580801969503328761640562042586615874198422433667841123122413568"], "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1537857066 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[13], \"1954569340\", [\"4540... )", async function( ) {
		const txOriginal = {blockNumber: "6401500", timeStamp: "1537944246", hash: "0x2426fddb17fbd3c123bf48e0f7dc3ba2c54e9c729dfd1b522cdd61b05e384738", nonce: "1856", blockHash: "0x223c4ea2228f1a0e635743640b52e9f665b3bc6af6ab581fc621097afa2322bb", transactionIndex: "44", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "4300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000d1be4202106608748c843eda9803ab834935b9b90000000000000000000000000000000000000000000000000000000074805c7c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000000000000000000000401010200000006000f000f07000c00000905070b0100000000000000000000000113010000000c000f000d0a0004000f010105090100000000000000000000000122010000000d0001000308000900030609080201000000000000000000000001300100000004000600020c0005000d0d0b030d010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1763265", gasUsed: "118991", confirmations: "1306026"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[13]}, {type: "uint256", name: "_random", value: "1954569340"}, {type: "uint256[]", name: "_gene", value: ["454093499140747995826552433349187611335023450554961053679570543824928243712","485889844560421764823529163643839317069427015841740972747933807846644252672","512392550532099136362040139624216190372677432246137751446633902375859912704","537128409438982054656407248692906473647907937922912349144365305617132290048"]}, {type: "uint256", name: "_openNonceId", value: "13"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[13], "1954569340", ["454093499140747995826552433349187611335023450554961053679570543824928243712","485889844560421764823529163643839317069427015841740972747933807846644252672","512392550532099136362040139624216190372677432246137751446633902375859912704","537128409438982054656407248692906473647907937922912349144365305617132290048"], "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1537944246 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[8], \"292666867\", [\"455860... )", async function( ) {
		const txOriginal = {blockNumber: "6426079", timeStamp: "1538292639", hash: "0x13694333878afb68a82fd94e201277153073bfdb37a819216c46053aae52078c", nonce: "1860", blockHash: "0xd7cb133bd2a53dcb8ae731638d6471345ad2e5b50d7749bf58031a0199251b8b", transactionIndex: "113", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "156289", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000c54d59f4a6ad5e14e0367c02ccdfca2b01e46894000000000000000000000000000000000000000000000000000000001171bdf30000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000004010202000000090003000301000e0008020109060100000000000000000000000113010000000d000c000909000f0008040906080100000000000000000000000122010000000f00080006010000000e0508080001000000000000000000000001310400000001000c000e0a0007000302000304010000000000000000000000", contractAddress: "", cumulativeGasUsed: "6382558", gasUsed: "118863", confirmations: "1281447"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[8]}, {type: "uint256", name: "_random", value: "292666867"}, {type: "uint256[]", name: "_gene", value: ["455860346205531200676024865472511394616473769409410398727461630681769050112","485889844560423371688012138633619235474064051897567235981655596903180533760","512392550532102350409769270384292132285102574687284622412904041562958200832","538915961742795990010344132223606131701070719682530049738004821395852230656"]}, {type: "uint256", name: "_openNonceId", value: "14"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[8], "292666867", ["455860346205531200676024865472511394616473769409410398727461630681769050112","485889844560423371688012138633619235474064051897567235981655596903180533760","512392550532102350409769270384292132285102574687284622412904041562958200832","538915961742795990010344132223606131701070719682530049738004821395852230656"], "14", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1538292639 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"925060626\", [\"45409... )", async function( ) {
		const txOriginal = {blockNumber: "6426924", timeStamp: "1538304941", hash: "0x89d12c3f7eb95b1a6aeb3fa29aba9656304224d48a374f5cc23ec6be1f05ffee", nonce: "1861", blockHash: "0x03e413bb9bf1d67da95943fc19ea21f54bb6063c1e576d39eab6981abe7211c9", transactionIndex: "40", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "156161", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d0000000000000000000000000000000000000000000000000000000037234e1200000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000401010200000001000b0009040003000a0f010f0d0100000000000000000000000113010000000b000c000b090003000900000d0c0100000000000000000000000122010000000e000b000700000a000b050609010100000000000000000000000130010000000f0004000c0500000000060d080a010000000000000000000000", contractAddress: "", cumulativeGasUsed: "2036286", gasUsed: "118735", confirmations: "1280602"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "925060626"}, {type: "uint256[]", name: "_gene", value: ["454093499140739961038249174531172459034028074339490427891528101766409224192","485889844560420157811924368941638856364709988941149975835155237545518825472","512392550532100743545285170038719781335582874004049946979060110765626228736","537128409438999730925857971491797589399649226559786609817302826130031509504"]}, {type: "uint256", name: "_openNonceId", value: "16"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "925060626", ["454093499140739961038249174531172459034028074339490427891528101766409224192","485889844560420157811924368941638856364709988941149975835155237545518825472","512392550532100743545285170038719781335582874004049946979060110765626228736","537128409438999730925857971491797589399649226559786609817302826130031509504"], "16", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1538304941 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"1488792562\", [\"4558... )", async function( ) {
		const txOriginal = {blockNumber: "6427605", timeStamp: "1538314609", hash: "0x46f5ba5bcac6120d2ff94fa495f67c0b38dd821c2dcc79282499c03015934c0b", nonce: "1862", blockHash: "0x1c07eff6bf1c4a35d0ab7fe6049d675d111c422911645daf4c39bb6dd8349faa", transactionIndex: "84", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "99595", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d0000000000000000000000000000000000000000000000000000000058bd2bf2000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000004010202000000040002000903000d000f0906060601000000000000000000000001130100000005000e00020b0003000009020505010000000000000000000000012201000000000009000c00000b000c0704020101000000000000000000000001310300000006000c00070a00010007030f0e0d010000000000000000000000", contractAddress: "", cumulativeGasUsed: "7621458", gasUsed: "64272", confirmations: "1279921"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "1488792562"}, {type: "uint256[]", name: "_gene", value: ["455860346205523165961285889656775379647075242860251541236684755309632159744","485889844560410516232695307930924909270537313405320998137287047658118053888","512392550532078246363627557589271835042687120540456154814117500640129187840","538909059996457234136775373408053664399396173596476943415195355229603233792"]}, {type: "uint256", name: "_openNonceId", value: "17"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "1488792562", ["455860346205523165961285889656775379647075242860251541236684755309632159744","485889844560410516232695307930924909270537313405320998137287047658118053888","512392550532078246363627557589271835042687120540456154814117500640129187840","538909059996457234136775373408053664399396173596476943415195355229603233792"], "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1538314609 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"1027661627\", [\"4576... )", async function( ) {
		const txOriginal = {blockNumber: "6427605", timeStamp: "1538314609", hash: "0x839868ff44f22c5bb5646f2abfc54001998938687809d8c6f9a1a5d659d3b56e", nonce: "1863", blockHash: "0x1c07eff6bf1c4a35d0ab7fe6049d675d111c422911645daf4c39bb6dd8349faa", transactionIndex: "85", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "156353", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d000000000000000000000000000000000000000000000000000000003d40df3b000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000110000000000000000000000000000000000000000000000000000000000000004010302000000080008000e0a000a00010b05000901000000000000000000000001130100000001000d0004050006000e0f09000b01000000000000000000000001220100000009000e00080f0006000e0d0c01090100000000000000000000000132030000000f000800090e0005000303040709010000000000000000000000", contractAddress: "", cumulativeGasUsed: "7650358", gasUsed: "28900", confirmations: "1279921"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "1027661627"}, {type: "uint256[]", name: "_gene", value: ["457627193270307978190167675994286134288833547631721703399313849189157306368","485889844560404088455999082835863916132871349263634608326738947223972741120","512392550532092708928624057115759251451730453085070097257275178903821877248","540675907061250080810678041340793638004633708570117686347627855462250053632"]}, {type: "uint256", name: "_openNonceId", value: "17"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "1027661627", ["457627193270307978190167675994286134288833547631721703399313849189157306368","485889844560404088455999082835863916132871349263634608326738947223972741120","512392550532092708928624057115759251451730453085070097257275178903821877248","540675907061250080810678041340793638004633708570117686347627855462250053632"], "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1538314609 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"1488000473\", [\"4540... )", async function( ) {
		const txOriginal = {blockNumber: "6427816", timeStamp: "1538317372", hash: "0xe4b7eacda9a3d1c03fa61d465c77fe9a83e44251a52b8acf70d76f1dddba9592", nonce: "1864", blockHash: "0x7c6871c0ab2d3c0c94fda50b4dc95a8126dcc661690c8beb47101bcfb92356f4", transactionIndex: "112", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153552", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d0000000000000000000000000000000000000000000000000000000058b115d90000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000000000000000000040101020000000e0000000c0a00060008040106070100000000000000000000000113010000000e0006000007000f000b0b080b0c010000000000000000000000012201000000070005000405000200090b020f080100000000000000000000000133030000000e000d000a03000d000f0901080f010000000000000000000000", contractAddress: "", cumulativeGasUsed: "5295846", gasUsed: "116126", confirmations: "1279710"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "1488000473"}, {type: "uint256[]", name: "_gene", value: ["454093499140760850963106457414692261129427289383787520292113417732114874368","485889844560424978478933455477993763001772306921927767796838508717315981312","512392550532089494831854670057737967085410324057196150170611903468719308800","542442754126026858324817081188611679351188033257505850080064800803344351232"]}, {type: "uint256", name: "_openNonceId", value: "18"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "1488000473", ["454093499140760850963106457414692261129427289383787520292113417732114874368","485889844560424978478933455477993763001772306921927767796838508717315981312","512392550532089494831854670057737967085410324057196150170611903468719308800","542442754126026858324817081188611679351188033257505850080064800803344351232"], "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1538317372 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[10], \"1424086478\", [\"4558... )", async function( ) {
		const txOriginal = {blockNumber: "6432724", timeStamp: "1538386856", hash: "0x3ea261658077c1ef0407ac5b5a06f259df1b582078e6cb555a736e524fa65951", nonce: "1865", blockHash: "0xd73d75d927b9b394b2fc62913e2b2dc565625d5af21f597ab328cb660a1610a4", transactionIndex: "98", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "100879", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000001ad8ff6e2dfec529a67b93fe1d44a653a8136bcf0000000000000000000000000000000000000000000000000000000054e1d5ce000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000130000000000000000000000000000000000000000000000000000000000000004010202000000060009000305000a00060206010c0100000000000000000000000113010000000d000500060800080007010e0a0d01000000000000000000000001220100000009000b00010a00030008040e070b010000000000000000000000013104000000010009000f0b0006000a0f000101010000000000000000000000", contractAddress: "", cumulativeGasUsed: "7207037", gasUsed: "65556", confirmations: "1274802"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[10]}, {type: "uint256", name: "_random", value: "1424086478"}, {type: "uint256[]", name: "_gene", value: ["455860346205526380009011666270727444794876676708713594821536794811958296576","485889844560423371516371514161724470312951363962884188800866168901711429632","512392550532092708855061644835687398328743444849722251085597805973832990720","538915961742795989936784721867941962195978001692445137036006629875084427264"]}, {type: "uint256", name: "_openNonceId", value: "19"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[10], "1424086478", ["455860346205526380009011666270727444794876676708713594821536794811958296576","485889844560423371516371514161724470312951363962884188800866168901711429632","512392550532092708855061644835687398328743444849722251085597805973832990720","538915961742795989936784721867941962195978001692445137036006629875084427264"], "19", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1538386856 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"37593274\", [\"457627... )", async function( ) {
		const txOriginal = {blockNumber: "6472568", timeStamp: "1538946343", hash: "0xf3108b4ef0510c8d13cdc3d7055ee7c75e01c86cb2dd34d035ce52a0c3c63688", nonce: "1866", blockHash: "0xbc45170c727e400c3a2150a0bfcd6201f72689736f56ece1899a7a91bec880d0", transactionIndex: "56", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "84357", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d00000000000000000000000000000000000000000000000000000000023da0ba0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001400000000000000000000000000000000000000000000000000000000000000040103020000000d000600000f000200070c050a0c01000000000000000000000001130100000004000600020d0000000c06010d0901000000000000000000000001220100000005000e00050d0000000d0b0e0e0101000000000000000000000001320400000002000d000c0700020001050f0203010000000000000000000000", contractAddress: "", cumulativeGasUsed: "3781395", gasUsed: "49272", confirmations: "1234958"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "37593274"}, {type: "uint256[]", name: "_gene", value: ["457627193270316012831343882923416989411719285185972063928023279672873713664","485889844560408909098491622632751969944182486648661717093418830909363191808","512392550532086281176445895798262533993992712577197924401414672501631352832","540682808807575981302490864695024084095229383399734687300357073953575927808"]}, {type: "uint256", name: "_openNonceId", value: "20"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "37593274", ["457627193270316012831343882923416989411719285185972063928023279672873713664","485889844560408909098491622632751969944182486648661717093418830909363191808","512392550532086281176445895798262533993992712577197924401414672501631352832","540682808807575981302490864695024084095229383399734687300357073953575927808"], "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1538946343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"881731693\", [\"454093... )", async function( ) {
		const txOriginal = {blockNumber: "6480373", timeStamp: "1539054920", hash: "0x427193baa4d0fe955d120ac0267050ce9bdf5258efdc89b4170a4f0bdfb26e80", nonce: "1867", blockHash: "0xd69e9626db50e8c2b7990024a45c7e27f606cf04f856526b962249c263cb87bc", transactionIndex: "31", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153552", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b00000000000000000000000000000000000000000000000000000000348e286d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001500000000000000000000000000000000000000000000000000000000000000040101020000000d0003000e020005000b0b0404080100000000000000000000000113010000000d00040003050000000f010809010100000000000000000000000122010000000e0006000b050000000104020409010000000000000000000000013001000000090007000f010009000a0706060c010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1321658", gasUsed: "116126", confirmations: "1227153"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "881731693"}, {type: "uint256[]", name: "_gene", value: ["454093499140759244098622720982782299428575082696708353385447923937884241920","485889844560423371491850458689929463213707391855549876780960202737126998016","512392550532100743422687030654410475309858870021476312200660300979280805888","537128409438990089371153320099158633749028630831669258556158454820092510208"]}, {type: "uint256", name: "_openNonceId", value: "21"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "881731693", ["454093499140759244098622720982782299428575082696708353385447923937884241920","485889844560423371491850458689929463213707391855549876780960202737126998016","512392550532100743422687030654410475309858870021476312200660300979280805888","537128409438990089371153320099158633749028630831669258556158454820092510208"], "21", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1539054920 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"939240416\", [\"455860... )", async function( ) {
		const txOriginal = {blockNumber: "6486685", timeStamp: "1539143732", hash: "0x6cbf32f74f44b172952ba40cbc3405e0ae2ffa420f38a9d4d4b7017af640cc55", nonce: "1868", blockHash: "0x2784be59a60c230f6b2e1aa5893eab78cc7e7f5813e6d784f6579bd5d21c5ca2", transactionIndex: "72", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "157445", gasPrice: "5900000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b0000000000000000000000000000000000000000000000000000000037fbabe000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000000000000000000000000000000000000401020200000003000500000f000e000b04040f0e010000000000000000000000011301000000090006000f02000c000601080e07010000000000000000000000012201000000010006000e01000b00010107000b010000000000000000000000013103000000000008000707000b000b0b0e040e010000000000000000000000", contractAddress: "", cumulativeGasUsed: "3715493", gasUsed: "120019", confirmations: "1220841"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "939240416"}, {type: "uint256[]", name: "_gene", value: ["455860346205521559096798066866332039834107757697485039950856037598207410176","485889844560416943788717765385328313253702266259370538910210506282313449472","512392550532079853228112780368324658805709975903168448644245484480338329600","538909059996447592410430100466701622522942365111909653486171233134120534016"]}, {type: "uint256", name: "_openNonceId", value: "22"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "939240416", ["455860346205521559096798066866332039834107757697485039950856037598207410176","485889844560416943788717765385328313253702266259370538910210506282313449472","512392550532079853228112780368324658805709975903168448644245484480338329600","538909059996447592410430100466701622522942365111909653486171233134120534016"], "22", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1539143732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"2045293063\", [\"4576... )", async function( ) {
		const txOriginal = {blockNumber: "6487557", timeStamp: "1539156009", hash: "0x9d197b0d3849f7441f1549daffafd88df7c9c37cb6ac0f14dcb21fd64413dc9d", nonce: "1869", blockHash: "0xf545a94191a89c7d6fe003a308f2761321b2a9a1059815c4062503971d4f91de", transactionIndex: "105", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "84293", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d0000000000000000000000000000000000000000000000000000000079e8b207000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000170000000000000000000000000000000000000000000000000000000000000004010302000000050001000c0a000a0006000d0f070100000000000000000000000113010000000c000e00050800060000020408060100000000000000000000000122010000000e0009000a0f0008000b0006070f010000000000000000000000013203000000080008000905000100060506000d010000000000000000000000", contractAddress: "", cumulativeGasUsed: "4625061", gasUsed: "49208", confirmations: "1219969"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "2045293063"}, {type: "uint256[]", name: "_gene", value: ["457627193270303157204394650157641644530959705920059408570614742776698372096","485889844560421764799006238911673163372217568781539920683777530086872317952","512392550532100743496246457086748766468057481939631487048160395841631158272","540675907061238832244368215255260906334582733794318109893586485714926698496"]}, {type: "uint256", name: "_openNonceId", value: "23"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "2045293063", ["457627193270303157204394650157641644530959705920059408570614742776698372096","485889844560421764799006238911673163372217568781539920683777530086872317952","512392550532100743496246457086748766468057481939631487048160395841631158272","540675907061238832244368215255260906334582733794318109893586485714926698496"], "23", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1539156009 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"2065591667\", [\"4540... )", async function( ) {
		const txOriginal = {blockNumber: "6487617", timeStamp: "1539156633", hash: "0x92aaac29ba0eab36f39b76b0eda1edc321da74acf3d274d696d0dc0e73b46980", nonce: "1870", blockHash: "0x575e6fe67dd8dd9eb08e49e4937e01783a3d8175b0e6c7378959c852d56c187a", transactionIndex: "124", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "84357", gasPrice: "6900000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d000000000000000000000000000000000000000000000000000000007b1e6d7300000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000000401010200000002000f000905000a000a06040b0c01000000000000000000000001130100000009000f000f01000e00010a08070d0100000000000000000000000122010000000d00010000010007000402030b0a01000000000000000000000001330300000001000200000d000300010a040400010000000000000000000000", contractAddress: "", cumulativeGasUsed: "6546804", gasUsed: "49272", confirmations: "1219909"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "2065591667"}, {type: "uint256[]", name: "_gene", value: ["454093499140741568074373149598522630466399701525033105096118041129384935424","485889844560416944009397121808559271327349457067486975134725501258018324480","512392550532099136362039006960402657767453125781811026965862541107904118784","542442754126005967860518772293234988755883381412641040967719067561475702784"]}, {type: "uint256", name: "_openNonceId", value: "24"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "2065591667", ["454093499140741568074373149598522630466399701525033105096118041129384935424","485889844560416944009397121808559271327349457067486975134725501258018324480","512392550532099136362039006960402657767453125781811026965862541107904118784","542442754126005967860518772293234988755883381412641040967719067561475702784"], "24", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1539156633 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[14], \"107937284\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6488008", timeStamp: "1539161823", hash: "0xbe071e4375b182bf43a8480a0d62764a3f3ebd00305200585ab503046180119a", nonce: "1871", blockHash: "0x7ba569d05e8b4f15d4db7e295b97b008cd8fb3fca3e57279253e92701fa044ca", transactionIndex: "179", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "157509", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000000904f8a3203f5b52765837ffca4c345a74c0e9f900000000000000000000000000000000000000000000000000000000066efe0400000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000000401020200000002000e000f040001000101050b040100000000000000000000000113010000000f000b00070b0001000008060706010000000000000000000000012201000000040001000b0b000400010f08010701000000000000000000000001310400000007000c000906000900060003030f010000000000000000000000", contractAddress: "", cumulativeGasUsed: "7725278", gasUsed: "120083", confirmations: "1219518"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[14]}, {type: "uint256", name: "_random", value: "107937284"}, {type: "uint256[]", name: "_gene", value: ["455860346205519952379438761850223920408504049431110659324944485539301556224","485889844560426585539579982594168845754289889034130778014460761005384269824","512392550532084673919644806251482974001131928667201642236185168270076149760","538915961742805631638607809597201653102879076906433997469225089851205877760"]}, {type: "uint256", name: "_openNonceId", value: "25"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[14], "107937284", ["455860346205519952379438761850223920408504049431110659324944485539301556224","485889844560426585539579982594168845754289889034130778014460761005384269824","512392550532084673919644806251482974001131928667201642236185168270076149760","538915961742805631638607809597201653102879076906433997469225089851205877760"], "25", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1539161823 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[14], \"1780859826\", [\"4576... )", async function( ) {
		const txOriginal = {blockNumber: "6488010", timeStamp: "1539161873", hash: "0x2b0ea7ce96349e59d6ce93753be114726076ebaba0937047f1cdb3508b1d03bf", nonce: "1872", blockHash: "0x5faeba089da7bb1dcca0b4279b93c2e5b219287d6f8e165a990d8479d584a56b", transactionIndex: "40", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "156289", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000000904f8a3203f5b52765837ffca4c345a74c0e9f9000000000000000000000000000000000000000000000000000000006a25c3b20000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001a0000000000000000000000000000000000000000000000000000000000000004010302000000000000000b0e000a00050e06040c01000000000000000000000001130100000004000a000e070009000101020501010000000000000000000000012201000000040000000e0800090002030a0c0a01000000000000000000000001320400000006000400090c000a00080e080d01010000000000000000000000", contractAddress: "", cumulativeGasUsed: "2676684", gasUsed: "118863", confirmations: "1219516"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[14]}, {type: "uint256", name: "_random", value: "1780859826"}, {type: "uint256[]", name: "_gene", value: ["457627193270295122489653058253997105277519316575739793481251052048391077888","485889844560408909196575818212389616384503537786761162471720956190959599616","512392550532084673895125995646492814458465694076828072201112280812522307584","540682808807582408833987427645867381216561928992778235339673751269268258816"]}, {type: "uint256", name: "_openNonceId", value: "26"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[14], "1780859826", ["457627193270295122489653058253997105277519316575739793481251052048391077888","485889844560408909196575818212389616384503537786761162471720956190959599616","512392550532084673895125995646492814458465694076828072201112280812522307584","540682808807582408833987427645867381216561928992778235339673751269268258816"], "26", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1539161873 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"236483860\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6493641", timeStamp: "1539241253", hash: "0xa50ba61e621d08181df61e7f6dff4ba1414e34bec07dec0938d657389340b890", nonce: "1873", blockHash: "0xc90f9ba02f73977b5492da74748ec897b354eb8f15adb0782bdd03b3b81a2fa4", transactionIndex: "70", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "97984", gasPrice: "4281250000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d000000000000000000000000000000000000000000000000000000000e1875140000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b00000000000000000000000000000000000000000000000000000000000000040102020000000b00080004040007000605020a0d0100000000000000000000000113010000000e0005000703000b00090e0303060100000000000000000000000122010000000b0000000d0d000f00030d0e070c0100000000000000000000000131030000000d0007000f06000900010007080c010000000000000000000000", contractAddress: "", cumulativeGasUsed: "6470947", gasUsed: "62661", confirmations: "1213885"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "236483860"}, {type: "uint256[]", name: "_gene", value: ["455860346205534414674713405251101550020220477578364198083453402313807364096","485889844560424978454416139988977885265059206109976916954757370820125786112","512392550532095922461435441741644442961266111641631998417770072363057020928","538909059996468482580488530380236457746804307218060630531051877603792125952"]}, {type: "uint256", name: "_openNonceId", value: "27"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "236483860", ["455860346205534414674713405251101550020220477578364198083453402313807364096","485889844560424978454416139988977885265059206109976916954757370820125786112","512392550532095922461435441741644442961266111641631998417770072363057020928","538909059996468482580488530380236457746804307218060630531051877603792125952"], "27", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1539241253 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[15], \"582166624\", [\"45409... )", async function( ) {
		const txOriginal = {blockNumber: "6500258", timeStamp: "1539334206", hash: "0xba2a0833306d81fd40af1c1d34759d48681a69d8825d69fd7f2a9135a151f703", nonce: "1875", blockHash: "0xb2bb413c3ac4781368a6af189151a1236405679409b1822a085c12ce69a7b93c", transactionIndex: "67", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "156417", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd00000000000000000000000000a3c3a3b8b795e88fa45b84fd9c23b8c5b012410000000000000000000000000000000000000000000000000000000022b328600000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000040101020000000b0006000e06000f00010d0f050c0100000000000000000000000113010000000b0005000f0c000b0005010a0e0701000000000000000000000001220100000007000700050b000100040c0b0d040100000000000000000000000133030000000e00030003050003000a03070802010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1913635", gasUsed: "118991", confirmations: "1207268"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[15]}, {type: "uint256", name: "_random", value: "582166624"}, {type: "uint256[]", name: "_gene", value: ["454093499140756030296093994810023434081079959367824171765721548039743602688","485889844560420157640286369327019247667712065236656034014738247671756095488","512392550532089494880894910278853088804207550849378234638579402971138752512","542442754126026858079615178561915630536287568257973745097773788261037113344"]}, {type: "uint256", name: "_openNonceId", value: "28"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[15], "582166624", ["454093499140756030296093994810023434081079959367824171765721548039743602688","485889844560420157640286369327019247667712065236656034014738247671756095488","512392550532089494880894910278853088804207550849378234638579402971138752512","542442754126026858079615178561915630536287568257973745097773788261037113344"], "28", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1539334206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"1649811975\", [\"4558... )", async function( ) {
		const txOriginal = {blockNumber: "6502292", timeStamp: "1539363133", hash: "0x946575e206600dcb753f22ca181958b0ce3f2a409908db95346f5b3c9a45833c", nonce: "1876", blockHash: "0x11b7ee36ff9f9ad10601938bef89c7196a3e4467a01321ed6b3b9cef8ffdf426", transactionIndex: "56", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153488", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d00000000000000000000000000000000000000000000000000000000625622070000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000000401020200000002000900090b000c000f0a07030b0100000000000000000000000113010000000f000b000c0a000c00040b0d05090100000000000000000000000122010000000a0006000900000e000c0a03020401000000000000000000000001310400000008000d000006000e00060309000f010000000000000000000000", contractAddress: "", cumulativeGasUsed: "5308218", gasUsed: "116062", confirmations: "1205234"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "1649811975"}, {type: "uint256[]", name: "_gene", value: ["455860346205519952256836883945194645762384602423773703724830233977054822400","485889844560426585539581851855008301541459565823572340546503762188020219904","512392550532094315670509239097274021568546778230920317413690603497137897472","538915961742807238601168629941670510128392859250571712514875985454992195584"]}, {type: "uint256", name: "_openNonceId", value: "30"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "1649811975", ["455860346205519952256836883945194645762384602423773703724830233977054822400","485889844560426585539581851855008301541459565823572340546503762188020219904","512392550532094315670509239097274021568546778230920317413690603497137897472","538915961742807238601168629941670510128392859250571712514875985454992195584"], "30", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1539363133 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[11], \"1107209869\", [\"4576... )", async function( ) {
		const txOriginal = {blockNumber: "6502312", timeStamp: "1539363394", hash: "0x95961ec8ea23c19682cb9b96d3d9b425cc76788d440886c5112a755cd1ed1cb0", nonce: "1877", blockHash: "0x41bdddcdea816c913206aba11075d4101ade68fcbd57bf18c34c735151054e59", transactionIndex: "86", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153616", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000008847916be41b3cc93077ceef7dd3fd868a3f385d0000000000000000000000000000000000000000000000000000000041feae8d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001d00000000000000000000000000000000000000000000000000000000000000040103020000000d000400050b000c00070e0108000100000000000000000000000113010000000e000b000107000800060e0407090100000000000000000000000122010000000e000b000505000b0009030e09080100000000000000000000000132040000000500050005030009000301010307010000000000000000000000", contractAddress: "", cumulativeGasUsed: "7778864", gasUsed: "116190", confirmations: "1205214"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[11]}, {type: "uint256", name: "_random", value: "1107209869"}, {type: "uint256[]", name: "_gene", value: ["457627193270316012782305890492020787630998759739002608172863785466196918272","485889844560424978601533472891527921467752413703184316668731685347239395328","512392550532100743545284429057411954629820224454999953090163571710677221376","540682808807580801920461587578232395701561758258373899546807385163508482048"]}, {type: "uint256", name: "_openNonceId", value: "29"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[11], "1107209869", ["457627193270316012782305890492020787630998759739002608172863785466196918272","485889844560424978601533472891527921467752413703184316668731685347239395328","512392550532100743545284429057411954629820224454999953090163571710677221376","540682808807580801920461587578232395701561758258373899546807385163508482048"], "29", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1539363394 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"1543608157\", [\"45762... )", async function( ) {
		const txOriginal = {blockNumber: "6511883", timeStamp: "1539497413", hash: "0xcce3f1baac1c2d8fee16171d5be1c6cd0381118c103bb9e4a3e9b257b6ced713", nonce: "1880", blockHash: "0xa880260367a73b46cc01873d8e4731e81e92fde4ba3b79a39715d298357a148d", transactionIndex: "72", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153552", gasPrice: "1700000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b000000000000000000000000000000000000000000000000000000005c01975d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001f00000000000000000000000000000000000000000000000000000000000000040103020000000c000f000a000004000c010f0c010100000000000000000000000113010000000d00090003020003000c020d090c01000000000000000000000001220100000009000300090200050009060b0e0301000000000000000000000001320300000009000e000e00000a0002040c0f01010000000000000000000000", contractAddress: "", cumulativeGasUsed: "4719202", gasUsed: "116126", confirmations: "1195643"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "1543608157"}, {type: "uint256[]", name: "_gene", value: ["457627193270314406113982701339541053378395094870149409180607850370379546624","485889844560423371614450097574762561105770080874716707754258569404140748800","512392550532092708658905197068238381334150609502799104410179490105480183808","540675907061240439329533909583450080944656636256804392292536375081797943296"]}, {type: "uint256", name: "_openNonceId", value: "31"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "1543608157", ["457627193270314406113982701339541053378395094870149409180607850370379546624","485889844560423371614450097574762561105770080874716707754258569404140748800","512392550532092708658905197068238381334150609502799104410179490105480183808","540675907061240439329533909583450080944656636256804392292536375081797943296"], "31", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1539497413 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"1104102744\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6556786", timeStamp: "1540131245", hash: "0x0dd6cf3fb7181f56a0bd2359175045f8f1e1b205914225b1bc03b228984f87c2", nonce: "1885", blockHash: "0xfbb8474f7bb74c11cbd01cefc96fa3d37f38da0b91ff5c333737fb343dbb2f19", transactionIndex: "51", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153616", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b0000000000000000000000000000000000000000000000000000000041cf45580000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000040102020000000e000d000904000e00060c0604020100000000000000000000000113010000000f000e00030c0008000e0701040a010000000000000000000000012201000000050008000204000e00000208070a0100000000000000000000000131030000000b000e00020c000b000709070a0b010000000000000000000000", contractAddress: "", cumulativeGasUsed: "6000111", gasUsed: "116190", confirmations: "1150740"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "1104102744"}, {type: "uint256[]", name: "_gene", value: ["455860346205539235611447696213451173356615520908734267106018092785986437120","485889844560426585613138273439712631420792825212497237676783792416998031360","512392550532086281029325188288677203477138265452405482498837248751154757632","538909059996465268876034657868270316243314574512245071060175511851880153088"]}, {type: "uint256", name: "_openNonceId", value: "32"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "1104102744", ["455860346205539235611447696213451173356615520908734267106018092785986437120","485889844560426585613138273439712631420792825212497237676783792416998031360","512392550532086281029325188288677203477138265452405482498837248751154757632","538909059996465268876034657868270316243314574512245071060175511851880153088"], "32", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540131245 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[16], \"778584433\", [\"45409... )", async function( ) {
		const txOriginal = {blockNumber: "6563145", timeStamp: "1540221007", hash: "0xe9a7af88973a5e8f64cccf895d1f9777f1565b305ec62dda51316579e6d52f71", nonce: "1887", blockHash: "0xfa666df55052541523b6a5b3828e953250bac7842090a49a155723c656f1239b", transactionIndex: "96", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "98048", gasPrice: "8800000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000517ff5b16c6059a5d9957420ccd05d7c8cabd9fb000000000000000000000000000000000000000000000000000000002e684171000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000210000000000000000000000000000000000000000000000000000000000000004010102000000080008000504000a000d0d060b0c0100000000000000000000000113010000000f000d000c0200000006050c0d0c0100000000000000000000000122010000000f0001000c0100020003090b060d01000000000000000000000001330300000007000200030d0001000c0c030b03010000000000000000000000", contractAddress: "", cumulativeGasUsed: "5087010", gasUsed: "62725", confirmations: "1144381"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[16]}, {type: "uint256", name: "_random", value: "778584433"}, {type: "uint256[]", name: "_gene", value: ["454093499140751209530997704924018066957489804009886946714394341580902236160","485889844560426585588621697470436038091905293652475357690621722876530655232","512392550532102350238132014673872118168473542961175192754344426916020224000","542442754126015609488785448668101112917240989611510736974281309136741203968"]}, {type: "uint256", name: "_openNonceId", value: "33"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[16], "778584433", ["454093499140751209530997704924018066957489804009886946714394341580902236160","485889844560426585588621697470436038091905293652475357690621722876530655232","512392550532102350238132014673872118168473542961175192754344426916020224000","542442754126015609488785448668101112917240989611510736974281309136741203968"], "33", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540221007 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"1855479000\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6579328", timeStamp: "1540449005", hash: "0xd2932fda6996e87916f7571488657ad854dbb3859b6c73e34e49d5cb547a2c94", nonce: "1888", blockHash: "0x52d0d7cb86a84e8dca83ff4a3aab9104191e9d1b5253c68214bd5771b1cbcad3", transactionIndex: "36", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "157836", gasPrice: "8835992700", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b000000000000000000000000000000000000000000000000000000006e985cd8000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000220000000000000000000000000000000000000000000000000000000000000004010202000000080003000c0000080006050b0c0d01000000000000000000000001130100000000000a00070b00090003000b000c01000000000000000000000001220100000003000e000d0e00050006060e0b0f01000000000000000000000001310400000000000d00040c0002000c020e0801010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1757304", gasUsed: "120410", confirmations: "1128198"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "1855479000"}, {type: "uint256[]", name: "_gene", value: ["455860346205529593737983972320372820576085802110017525337735371609702662144","485889844560402481444396169086359901560998560925150770846764456275177635840","512392550532083067300360372434677842427257314554394434887245790873353453568","538915961742794383096816063365885018359668608431651897102313343665127292928"]}, {type: "uint256", name: "_openNonceId", value: "34"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "1855479000", ["455860346205529593737983972320372820576085802110017525337735371609702662144","485889844560402481444396169086359901560998560925150770846764456275177635840","512392550532083067300360372434677842427257314554394434887245790873353453568","538915961742794383096816063365885018359668608431651897102313343665127292928"], "34", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540449005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"1392124674\", [\"45762... )", async function( ) {
		const txOriginal = {blockNumber: "6610620", timeStamp: "1540891262", hash: "0x0c4876870c1a059388d8b374951f992b2a0619ab35d91fbcbe50f0b5867490f7", nonce: "1889", blockHash: "0xba7c2f2aea7f50dc5214cc7a023696e66bec379ce786e2ea3525acbc8023edc1", transactionIndex: "36", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153552", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b0000000000000000000000000000000000000000000000000000000052fa230200000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000000401030200000009000e00080c0000000e0b0c0e0a0100000000000000000000000113010000000d000700040f0007000403090b0d01000000000000000000000001220100000003000100060c000a000a040404050100000000000000000000000132030000000b000d000c000004000e0b020f0d010000000000000000000000", contractAddress: "", cumulativeGasUsed: "3765750", gasUsed: "116126", confirmations: "1096906"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "1392124674"}, {type: "uint256[]", name: "_gene", value: ["457627193270309585275329264963952338019972772799977545723747834838390931456","485889844560423371565410633411083759911031659374583396104679809495007756288","512392550532083066981598678000747093333297474566697733401243199600733454336","540675907061243653181101750621174829334263539126029499279790845468449177600"]}, {type: "uint256", name: "_openNonceId", value: "35"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "1392124674", ["457627193270309585275329264963952338019972772799977545723747834838390931456","485889844560423371565410633411083759911031659374583396104679809495007756288","512392550532083066981598678000747093333297474566697733401243199600733454336","540675907061243653181101750621174829334263539126029499279790845468449177600"], "35", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540891262 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"1251418435\", [\"45409... )", async function( ) {
		const txOriginal = {blockNumber: "6616804", timeStamp: "1540978215", hash: "0x15745903f330cd2cb6b3a6f55e896f29c9a5de6cf04e8f46319bfaf1df85b0ce", nonce: "1890", blockHash: "0x19469939616a29341cc5e91fba8f67990571af5da5df0d9b691444e562373528", transactionIndex: "156", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153360", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b000000000000000000000000000000000000000000000000000000004a9721430000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002400000000000000000000000000000000000000000000000000000000000000040101020000000e000d0004000002000f0102000f0100000000000000000000000113010000000d0000000302000300070d0d02040100000000000000000000000122010000000c000c0000010008000308040300010000000000000000000000013303000000050006000e0c000800010708050d010000000000000000000000", contractAddress: "", cumulativeGasUsed: "6870389", gasUsed: "115934", confirmations: "1090722"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "1251418435"}, {type: "uint256[]", name: "_gene", value: ["454093499140760851281862522144338316066957641050540667157897628193816313856","485889844560423371393770739690074563815377639703321416922421307934834163712","512392550532097529693713963162545855289326422319875569043709490093682065408","542442754126012395710780759430232103886368639231589326593625685034197319680"]}, {type: "uint256", name: "_openNonceId", value: "36"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "1251418435", ["454093499140760851281862522144338316066957641050540667157897628193816313856","485889844560423371393770739690074563815377639703321416922421307934834163712","512392550532097529693713963162545855289326422319875569043709490093682065408","542442754126012395710780759430232103886368639231589326593625685034197319680"], "36", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540978215 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[9], \"2077355834\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6629185", timeStamp: "1541155071", hash: "0x28b229f2d9ed602f8092f6df427f4ec0d31b2882b3f373697ba6efce8c3a0616", nonce: "1891", blockHash: "0xdd1dc1f8d6b1bbbe4774906e00b37085e12b1e796ceeaaf166a512d3a10dfa9e", transactionIndex: "22", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "157637", gasPrice: "6625000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000eeb473525fc724cd2b5408c9f65ac3063b01be7b000000000000000000000000000000000000000000000000000000007bd1ef3a00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000025000000000000000000000000000000000000000000000000000000000000000401020200000003000d00020100020004070c0b0b0100000000000000000000000113010000000f000d000201000c00090e03020801000000000000000000000001220100000005000a000e0c000d000e05080a02010000000000000000000000013103000000040006000205000f000a05050e0d010000000000000000000000", contractAddress: "", cumulativeGasUsed: "7053886", gasUsed: "120211", confirmations: "1078341"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[9]}, {type: "uint256", name: "_random", value: "2077355834"}, {type: "uint256[]", name: "_gene", value: ["455860346205521559292958223924713593173299647678403759390369358113503444992","485889844560426585588617954565010443624677340123051729481249461948284665856","512392550532086281078369547021406330148335788141255353754917288890754662400","538909059996454020113565405475085491318793347439613550873591784554645946368"]}, {type: "uint256", name: "_openNonceId", value: "37"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[9], "2077355834", ["455860346205521559292958223924713593173299647678403759390369358113503444992","485889844560426585588617954565010443624677340123051729481249461948284665856","512392550532086281078369547021406330148335788141255353754917288890754662400","538909059996454020113565405475085491318793347439613550873591784554645946368"], "37", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541155071 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[17], \"840154206\", [\"45762... )", async function( ) {
		const txOriginal = {blockNumber: "6658807", timeStamp: "1541575223", hash: "0xd3753e5d0a09fce98fb8a42aa262534bf3dfd216320c3401ae0683850a6d9ffa", nonce: "1893", blockHash: "0x897559aabdd5edfe4793c7745cf56b2dc5c7937fc3925d4853bc26e3d91126e7", transactionIndex: "75", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "157445", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd000000000000000000000000275523fd59ba3598e01710ddb18a3312088bdd30000000000000000000000000000000000000000000000000000000003213bc5e000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000004010302000000050004000f01000c00000003010f01000000000000000000000001130100000006000400070c000800080d0a04000100000000000000000000000122010000000a000a000b03000e000d0108090b01000000000000000000000001320300000008000f000f0f0005000c0a04060b010000000000000000000000", contractAddress: "", cumulativeGasUsed: "5670319", gasUsed: "120019", confirmations: "1048719"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[17]}, {type: "uint256", name: "_random", value: "840154206"}, {type: "uint256[]", name: "_gene", value: ["457627193270303157277955545398991643336125933252220072413867252150255484928","485889844560412122925542152566367161235542367306817672707842211709624254464","512392550532094315768589706386034134246829281840860211957971357278605934592","540675907061238832416009975313860977075753344671309848076527736312997871616"]}, {type: "uint256", name: "_openNonceId", value: "38"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[17], "840154206", ["457627193270303157277955545398991643336125933252220072413867252150255484928","485889844560412122925542152566367161235542367306817672707842211709624254464","512392550532094315768589706386034134246829281840860211957971357278605934592","540675907061238832416009975313860977075753344671309848076527736312997871616"], "38", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541575223 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[14], \"1476169160\", [\"4540... )", async function( ) {
		const txOriginal = {blockNumber: "6659479", timeStamp: "1541584819", hash: "0x725ddf0bea4f68adaabe5f46ebc84be385b9ba431834f5d64bafe012421371cb", nonce: "1895", blockHash: "0xb7117ff3edacf930733d212eb6958f21463aea16739ed1ea3f359473640a52df", transactionIndex: "91", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "156353", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000000904f8a3203f5b52765837ffca4c345a74c0e9f90000000000000000000000000000000000000000000000000000000057fc8dc800000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000027000000000000000000000000000000000000000000000000000000000000000401010200000007000b000304000d0003010d0d00010000000000000000000000011301000000050003000103000f000d040c000a010000000000000000000000012201000000070008000c0c000300070e0d0c09010000000000000000000000013303000000080008000c050005000408060309010000000000000000000000", contractAddress: "", cumulativeGasUsed: "7786577", gasUsed: "118927", confirmations: "1048047"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[14]}, {type: "uint256", name: "_random", value: "1476169160"}, {type: "uint256[]", name: "_gene", value: ["454093499140749602666512483606533775591161572266576897559988669105169235968","485889844560410515962975706902363828200556650277722761589549287832025038848","512392550532089494905417459405187647360786425198804814019318530165130133504","542442754126017216573952635189350497288068531289505379420073908903318913024"]}, {type: "uint256", name: "_openNonceId", value: "39"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[14], "1476169160", ["454093499140749602666512483606533775591161572266576897559988669105169235968","485889844560410515962975706902363828200556650277722761589549287832025038848","512392550532089494905417459405187647360786425198804814019318530165130133504","542442754126017216573952635189350497288068531289505379420073908903318913024"], "39", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1541584819 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[14], \"884043958\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6659481", timeStamp: "1541584837", hash: "0xaded8118b06a77e50df2b5746453b512522467c6dc63c4ceb00110c78958ad89", nonce: "1896", blockHash: "0xf16901b985faa4bb1469957396215a721b2fa3f44e4e0d3fb1a1e7ad5e825043", transactionIndex: "39", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "157573", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000000904f8a3203f5b52765837ffca4c345a74c0e9f90000000000000000000000000000000000000000000000000000000034b170b6000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000280000000000000000000000000000000000000000000000000000000000000004010202000000030002000709000a0005060c0b0301000000000000000000000001130100000000000b00050a0007000f030701030100000000000000000000000122010000000c0001000c03000c000a0105040e0100000000000000000000000131040000000c000c00060f00040009070e0b0e010000000000000000000000", contractAddress: "", cumulativeGasUsed: "3180011", gasUsed: "120147", confirmations: "1048045"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[14]}, {type: "uint256", name: "_random", value: "884043958"}, {type: "uint256[]", name: "_gene", value: ["455860346205521559023240891146604442605730600522474414868537875965488922624","485889844560402481468915347989829575138493351043491773786913875995807186944","512392550532097529423999240626271776767299212325700312266199703725639991296","538915961742813666328827995268725126062242187185753249537482204316407169024"]}, {type: "uint256", name: "_openNonceId", value: "40"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[14], "884043958", ["455860346205521559023240891146604442605730600522474414868537875965488922624","485889844560402481468915347989829575138493351043491773786913875995807186944","512392550532097529423999240626271776767299212325700312266199703725639991296","538915961742813666328827995268725126062242187185753249537482204316407169024"], "40", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1541584837 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[10], \"163810403\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6665039", timeStamp: "1541662955", hash: "0xa3b76432039708e6affd072f33238babd9227fc54d6d05d3f60f3c981665fdcc", nonce: "1899", blockHash: "0x622dfecc9a990fb82b59f2d8294ff1306db923e305374ac2028c080a818266d7", transactionIndex: "72", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153552", gasPrice: "6625000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000001ad8ff6e2dfec529a67b93fe1d44a653a8136bcf0000000000000000000000000000000000000000000000000000000009c38c6300000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000029000000000000000000000000000000000000000000000000000000000000000401020200000008000e000704000f000d0c03050d0100000000000000000000000113010000000a0009000003000700070e0c0503010000000000000000000000012201000000030008000a0400000003020c0708010000000000000000000000013103000000030005000d040006000f0a0a050e010000000000000000000000", contractAddress: "", cumulativeGasUsed: "7516667", gasUsed: "116126", confirmations: "1042487"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[10]}, {type: "uint256", name: "_random", value: "163810403"}, {type: "uint256[]", name: "_gene", value: ["455860346205529594007701322636836133022660449413944296876636604517580800000","485889844560418550800316199632269303712282544858384851724575121308691464192","512392550532083067153239663463167163830218505341549545656766130547782057984","538909059996452413151005331957864109115979175212587657073709919013598920704"]}, {type: "uint256", name: "_openNonceId", value: "41"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[10], "163810403", ["455860346205529594007701322636836133022660449413944296876636604517580800000","485889844560418550800316199632269303712282544858384851724575121308691464192","512392550532083067153239663463167163830218505341549545656766130547782057984","538909059996452413151005331957864109115979175212587657073709919013598920704"], "41", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1541662955 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[14], \"1266370965\", [\"4576... )", async function( ) {
		const txOriginal = {blockNumber: "6665370", timeStamp: "1541667622", hash: "0x6b4957fa720c0cefdc5b1d56133bf339c9630ce05144dfbce6472f35934b9153", nonce: "1900", blockHash: "0x8f95036ff792535615d120651dc4bf0139c3e6592e25bac79ec77df526b6ba30", transactionIndex: "72", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "156353", gasPrice: "9900000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000000904f8a3203f5b52765837ffca4c345a74c0e9f9000000000000000000000000000000000000000000000000000000004b7b49950000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002b000000000000000000000000000000000000000000000000000000000000000401030200000009000c00090c0002000e040c00070100000000000000000000000113010000000c0002000e07000d000509010f0801000000000000000000000001220100000006000f00060e000f000d00070f030100000000000000000000000132030000000d000c000604000c00080f0f0905010000000000000000000000", contractAddress: "", cumulativeGasUsed: "4973279", gasUsed: "118927", confirmations: "1042156"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[14]}, {type: "uint256", name: "_random", value: "1266370965"}, {type: "uint256[]", name: "_gene", value: ["457627193270309585226289781800707652744744909158854548876440914106146357248","485889844560421764504770460903849382563926272836775727591218162680471748608","512392550532087888139010459048647602895188710277552547685991566243608395776","540675907061246867032668100927541704506722313945185074594874894773506801664"]}, {type: "uint256", name: "_openNonceId", value: "43"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[14], "1266370965", ["457627193270309585226289781800707652744744909158854548876440914106146357248","485889844560421764504770460903849382563926272836775727591218162680471748608","512392550532087888139010459048647602895188710277552547685991566243608395776","540675907061246867032668100927541704506722313945185074594874894773506801664"], "43", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1541667622 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[10], \"440374436\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6665396", timeStamp: "1541667979", hash: "0xadf014c7ea95af82631b9be9f7fad6177b5c8dc03db19546b6c356e929e61ca3", nonce: "1901", blockHash: "0x9ea47ef9c6ceff625f297b17ae69d42b7b276924c6b325e54e906d48d9c8b3dc", transactionIndex: "66", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "156353", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000001ad8ff6e2dfec529a67b93fe1d44a653a8136bcf000000000000000000000000000000000000000000000000000000001a3f94a40000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002a000000000000000000000000000000000000000000000000000000000000000401020200000008000c000b09000d000c08060906010000000000000000000000011301000000070004000500000e000102020b0401000000000000000000000001220100000006000c000203000f000f0e0309060100000000000000000000000131040000000f000200000400030004030f030a010000000000000000000000", contractAddress: "", cumulativeGasUsed: "6423667", gasUsed: "118927", confirmations: "1042130"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[10]}, {type: "uint256", name: "_random", value: "440374436"}, {type: "uint256[]", name: "_gene", value: ["455860346205529593958662969214267901218315493452082951154245970289575854080","485889844560413729863585645729918543879057280996125344040327529311682691072","512392550532087888065449160432890300908620747299194320989025605307882012672","538915961742818486897759224757954281252446977738770673708080760200567455744"]}, {type: "uint256", name: "_openNonceId", value: "42"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[10], "440374436", ["455860346205529593958662969214267901218315493452082951154245970289575854080","485889844560413729863585645729918543879057280996125344040327529311682691072","512392550532087888065449160432890300908620747299194320989025605307882012672","538915961742818486897759224757954281252446977738770673708080760200567455744"], "42", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1541667979 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[10], \"2016388686\", [\"4576... )", async function( ) {
		const txOriginal = {blockNumber: "6665428", timeStamp: "1541668334", hash: "0x2cde5bca0c3104252ecceaf9141dab21528fc85b1052643f85ed6e37751381bf", nonce: "1902", blockHash: "0x46594ff78c81c22e50a7d0e36d3cabe006681ca9dc9bbfd52c20f9621866c8b6", transactionIndex: "121", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "85641", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000001ad8ff6e2dfec529a67b93fe1d44a653a8136bcf00000000000000000000000000000000000000000000000000000000782fa64e0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002d00000000000000000000000000000000000000000000000000000000000000040103020000000b000b0006030004000c0d0a0303010000000000000000000000011301000000080003000600000800080f0f03040100000000000000000000000122010000000d0007000e09000c0005010b050b01000000000000000000000001320400000001000a000b05000b0005060b0106010000000000000000000000", contractAddress: "", cumulativeGasUsed: "6490517", gasUsed: "50556", confirmations: "1042098"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[10]}, {type: "uint256", name: "_random", value: "2016388686"}, {type: "uint256[]", name: "_gene", value: ["457627193270312799077857235540676909645413650089609104401249586954211688448","485889844560415336777110350210625218746695816120448154501417876579567009792","512392550532099136509163828597520784838123836824659870888972181006912061440","540682808807574374290886442675964153628208170438883819254109280954302332928"]}, {type: "uint256", name: "_openNonceId", value: "45"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[10], "2016388686", ["457627193270312799077857235540676909645413650089609104401249586954211688448","485889844560415336777110350210625218746695816120448154501417876579567009792","512392550532099136509163828597520784838123836824659870888972181006912061440","540682808807574374290886442675964153628208170438883819254109280954302332928"], "45", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1541668334 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[10], \"1089204325\", [\"4558... )", async function( ) {
		const txOriginal = {blockNumber: "6665440", timeStamp: "1541668505", hash: "0x5f3d09f5d620eec036f16b4a1c5e27fb2a28f380af46afe3cbd8ad530cf02cb9", nonce: "1903", blockHash: "0x9217ae0a595256631081e31a32f16ef821f4dc005848b88e7e72d8a33d01b8eb", transactionIndex: "22", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153616", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000001ad8ff6e2dfec529a67b93fe1d44a653a8136bcf0000000000000000000000000000000000000000000000000000000040ebf0650000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002f000000000000000000000000000000000000000000000000000000000000000401020200000008000700040a0002000b020d0e070100000000000000000000000113010000000c000e000a0a000d0005050b030b010000000000000000000000012201000000050005000b020005000c010a080c0100000000000000000000000131030000000d000a000600000900080f01040e010000000000000000000000", contractAddress: "", cumulativeGasUsed: "1382243", gasUsed: "116190", confirmations: "1042086"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[10]}, {type: "uint256", name: "_random", value: "1089204325"}, {type: "uint256[]", name: "_gene", value: ["455860346205529593836060708395319024357116104299603894566078225773792067584","485889844560421764799008112556928328511584183921635816028471007568384229376","512392550532086280955768766703682971389738117513461377127242825837437779968","538909059996468482654044940273016890964147667640321580524231104611120840704"]}, {type: "uint256", name: "_openNonceId", value: "47"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[10], "1089204325", ["455860346205529593836060708395319024357116104299603894566078225773792067584","485889844560421764799008112556928328511584183921635816028471007568384229376","512392550532086280955768766703682971389738117513461377127242825837437779968","538909059996468482654044940273016890964147667640321580524231104611120840704"], "47", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1541668505 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: openBoxFromServer( addressList[10], \"974317770\", [\"45586... )", async function( ) {
		const txOriginal = {blockNumber: "6665466", timeStamp: "1541668806", hash: "0x4df8c55d9cd175eba3169c3a98de56191c5efa13d9ccdac0389057a0945eae66", nonce: "1904", blockHash: "0xf1fe65b33eb6a63a6878353834ce194fc8e6efc2ad0f247f3a3ddf9f38ae6419", transactionIndex: "144", from: "0xef53e26c78c21ec0480fe92e658099d96dad3341", to: "0x78a7a77ef35e63a9d30cc333124c041a330e03f7", value: "0", gas: "153552", gasPrice: "7096413807", isError: "0", txreceipt_status: "1", input: "0x0e402acd0000000000000000000000001ad8ff6e2dfec529a67b93fe1d44a653a8136bcf000000000000000000000000000000000000000000000000000000003a12e8ca00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000000401020200000001000800020700040002030a0d08010000000000000000000000011301000000060008000707000b00070f0e000b01000000000000000000000001220100000004000a000c06000900010c0e030f0100000000000000000000000131040000000f000c0008030007000502000f09010000000000000000000000", contractAddress: "", cumulativeGasUsed: "7329959", gasUsed: "116126", confirmations: "1042060"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_userAddress", value: addressList[10]}, {type: "uint256", name: "_random", value: "974317770"}, {type: "uint256[]", name: "_gene", value: ["455860346205518345294270071443945825370369783557967107716052408428306366464","485889844560412123023621859874342763413954355895374784676017508748317687808","512392550532084674140324530973193443383402533809887823820200087751101513728","538915961742818487142961502990437318267725685300201462673334441589904244736"]}, {type: "uint256", name: "_openNonceId", value: "48"}], name: "openBoxFromServer", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "openBoxFromServer(address,uint256,uint256[],uint256)" ]( addressList[10], "974317770", ["455860346205518345294270071443945825370369783557967107716052408428306366464","485889844560412123023621859874342763413954355895374784676017508748317687808","512392550532084674140324530973193443383402533809887823820200087751101513728","538915961742818487142961502990437318267725685300201462673334441589904244736"], "48", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1541668806 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "955921970921321384" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "350000000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
