const Mentoring = artifacts.require( "./Mentoring.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Mentoring" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x6c602F1798A453f90F249E208e2b64C7c09226F7", "0xEdbBdf2c29ccf6A0272b36B10eaDC1B17b8D7e67", "0xd2BaE9A30A40376d25353773010FFe52dBa0D688", "0xe9601d9A1F804e7b983bD58E454FCD69165223dd", "0x4189f423E18877bdbb1E48723A3e4a7FA7503D5D", "0xFc7a64183f49f71A1D604496E62c08f20aF5b5d6", "0xb06AcD8fb3AD6a2b852BEa57c06a168f823Aad39", "0xc8235574F64a8ac6391492e16e833b48aebdFDb5"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_mentorId", type: "uint256"}], name: "isMentor", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "tokenId", type: "uint256"}], name: "getLastLecture", outputs: [{name: "lectureId", type: "uint256"}, {name: "mentorId", type: "uint256"}, {name: "studentId", type: "uint256"}, {name: "mentorLevel", type: "uint256"}, {name: "studentLevel", type: "uint256"}, {name: "levelUp", type: "uint256"}, {name: "levelPrice", type: "uint256"}, {name: "cost", type: "uint256"}, {name: "startedAt", type: "uint256"}, {name: "endsAt", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "heroes", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "inStudying", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getLastLectureIdAsStudent", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_mentorId", type: "uint256"}], name: "getMentor", outputs: [{name: "level", type: "uint256"}, {name: "price", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "inLecture", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "lectureId", type: "uint256"}], name: "getLecture", outputs: [{name: "mentorId", type: "uint256"}, {name: "studentId", type: "uint256"}, {name: "mentorLevel", type: "uint256"}, {name: "studentLevel", type: "uint256"}, {name: "levelUp", type: "uint256"}, {name: "levelPrice", type: "uint256"}, {name: "cost", type: "uint256"}, {name: "startedAt", type: "uint256"}, {name: "endsAt", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_mentorId", type: "uint256"}, {name: "_studentId", type: "uint256"}], name: "calcCost", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "levelUpTime", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "fee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "inMentoring", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_lectureId", type: "uint256"}], name: "lectureExists", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_mentorId", type: "uint256"}, {name: "_studentId", type: "uint256"}], name: "isRaceSuitable", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getLastLectureIdAsMentor", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BreakMentoring", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["BecomeMentor(uint256)", "BreakMentoring(uint256)", "ChangeLevelPrice(uint256,uint256)", "Income(address,uint256)", "StartLecture(uint256,uint256,uint256,uint256,uint256,uint256,uint256,uint256,uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x0ace9a284cbaf022c3396d879fcfe7ad3843167c19f4493e4edfd186efd48a96", "0xe915e5ee020091d04485e69797eefc0680771c43bd87f60de3ca3d4ffcdc03ac", "0xd5ff1816fc1e1872c8898e0fbd6de6fe5bded21494bfdd85c466d209b1920497", "0x0d2e009b696be50eaeafa43283c2e91362ec7d038b2af93783ec767d536ad278", "0xca8eb43dd243d57b1415a66a4b10fb68e3a605a8028e74e4da07028fd91a7380", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6841278 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6848286 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_heroes", value: 4}], name: "Mentoring", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "_mentorId", value: random.range( maxRandom )}], name: "isMentor", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isMentor(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "tokenId", value: random.range( maxRandom )}], name: "getLastLecture", outputs: [{name: "lectureId", type: "uint256"}, {name: "mentorId", type: "uint256"}, {name: "studentId", type: "uint256"}, {name: "mentorLevel", type: "uint256"}, {name: "studentLevel", type: "uint256"}, {name: "levelUp", type: "uint256"}, {name: "levelPrice", type: "uint256"}, {name: "cost", type: "uint256"}, {name: "startedAt", type: "uint256"}, {name: "endsAt", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLastLecture(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "heroes", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "heroes()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "inStudying", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "inStudying(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getLastLectureIdAsStudent", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLastLectureIdAsStudent(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_mentorId", value: random.range( maxRandom )}], name: "getMentor", outputs: [{name: "level", type: "uint256"}, {name: "price", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMentor(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "inLecture", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "inLecture(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "lectureId", value: random.range( maxRandom )}], name: "getLecture", outputs: [{name: "mentorId", type: "uint256"}, {name: "studentId", type: "uint256"}, {name: "mentorLevel", type: "uint256"}, {name: "studentLevel", type: "uint256"}, {name: "levelUp", type: "uint256"}, {name: "levelPrice", type: "uint256"}, {name: "cost", type: "uint256"}, {name: "startedAt", type: "uint256"}, {name: "endsAt", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLecture(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_mentorId", value: random.range( maxRandom )}, {type: "uint256", name: "_studentId", value: random.range( maxRandom )}], name: "calcCost", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcCost(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "levelUpTime", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "levelUpTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "fee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "fee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "inMentoring", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "inMentoring(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_lectureId", value: random.range( maxRandom )}], name: "lectureExists", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lectureExists(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_mentorId", value: random.range( maxRandom )}, {type: "uint256", name: "_studentId", value: random.range( maxRandom )}], name: "isRaceSuitable", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isRaceSuitable(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getLastLectureIdAsMentor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLastLectureIdAsMentor(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Mentoring", function( accounts ) {

	it( "TEST: Mentoring( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6841278", timeStamp: "1544166632", hash: "0x3e78abce8805541ed4b0121380c5b71f38ae7254aa6de54d29d32d766013c784", nonce: "1898", blockHash: "0xd660e719d1b9005c48c1f2193feaae8876f7f61f73e82de9e934fe8587db8515", transactionIndex: "46", from: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67", to: 0, value: "0", gas: "2067757", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x285cb05d000000000000000000000000d2bae9a30a40376d25353773010ffe52dba0d688", contractAddress: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", cumulativeGasUsed: "7526047", gasUsed: "2067757", confirmations: "838040"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_heroes", value: addressList[4]}], name: "Mentoring", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Mentoring.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1544166632 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Mentoring.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"} ;
		console.error( "eventCallOriginal[0,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "OwnershipTransferred", events: [{name: "previousOwner", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "newOwner", type: "address", value: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[0,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "54006985835754189" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"497\", \"2000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6841714", timeStamp: "1544172958", hash: "0x06492fbec734e4e1649a3ff8696b278c79fa599798a98982402d025634c0ae1b", nonce: "1905", blockHash: "0x4b5d5c56f148db924142dc30c3f7020b158df912317ac9c602febdacbf8b1147", transactionIndex: "86", from: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84011", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000001f100000000000000000000000000000000000000000000000000071afd498d0000", contractAddress: "", cumulativeGasUsed: "7315975", gasUsed: "84011", confirmations: "837604"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "497"}, {type: "uint256", name: "_levelPrice", value: "2000000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "497", "2000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1544172958 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "497"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[1,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "497"}, {name: "newLevelPrice", type: "uint256", value: "2000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[1,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "54006985835754189" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"618\", \"2500000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6842450", timeStamp: "1544183918", hash: "0x95dbabbff5b1c08bba1985bfb0f23837bcc7ddb4386f6b6e209afb8d8c48fc61", nonce: "1983", blockHash: "0x610494e24939b117817694c3d072f09532ec2f713127a9f75e50a529bcd2150a", transactionIndex: "99", from: "0xedbbdf2c29ccf6a0272b36b10eadc1b17b8d7e67", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84075", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed000000000000000000000000000000000000000000000000000000000000026a0000000000000000000000000000000000000000000000000008e1bc9bf04000", contractAddress: "", cumulativeGasUsed: "6665762", gasUsed: "84075", confirmations: "836868"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "618"}, {type: "uint256", name: "_levelPrice", value: "2500000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "618", "2500000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1544183918 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "618"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "618"}, {name: "newLevelPrice", type: "uint256", value: "2500000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "54006985835754189" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"224\", \"100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843039", timeStamp: "1544191998", hash: "0x7f02eed9ccbdbdb7efaeccb417dcf76e8e29a89bd39201e64ab16b97a12145bc", nonce: "51", blockHash: "0xc13cdf859434f78986bdd36c2bf252141cdf6f809d384bd11e78bec7e3d48373", transactionIndex: "126", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "83947", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000005af3107a4000", contractAddress: "", cumulativeGasUsed: "6597405", gasUsed: "83947", confirmations: "836279"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}, {type: "uint256", name: "_levelPrice", value: "100000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "224", "100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1544191998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "224"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "224"}, {name: "newLevelPrice", type: "uint256", value: "100000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"224\", \"719\" )", async function( ) {
		const txOriginal = {blockNumber: "6843129", timeStamp: "1544193292", hash: "0x82d79bfe9681db249918b3c014918b6fff84e92c232d4531e6e4696dcb681650", nonce: "54", blockHash: "0x65bda9b153c5d84cebc613d4e219a474aacc6940ed2daa6a5da669e282fd83ad", transactionIndex: "210", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "100000000000000", gas: "409757", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000002cf", contractAddress: "", cumulativeGasUsed: "7701342", gasUsed: "408927", confirmations: "836189"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}, {type: "uint256", name: "_studentId", value: "719"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "224", "719", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1544193292 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "2900000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[4,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "1"}, {name: "mentorId", type: "uint256", value: "224"}, {name: "studentId", type: "uint256", value: "719"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "29"}, {name: "levelUp", type: "uint256", value: "1"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544193292"}, {name: "endsAt", type: "uint256", value: "1544194492"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[4,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"720\", \"10000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843134", timeStamp: "1544193358", hash: "0x916c1b4cfba0fe88549ab9b6e9f6f9044ddff9fae58dcb94b017c3fa10c7d828", nonce: "56", blockHash: "0x8c139125dc83a3e129ef70c2fb43ce994660d15f665182773022686b21694891", transactionIndex: "87", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84011", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000002d0000000000000000000000000000000000000000000000000000009184e72a000", contractAddress: "", cumulativeGasUsed: "5082059", gasUsed: "84011", confirmations: "836184"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "720"}, {type: "uint256", name: "_levelPrice", value: "10000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "720", "10000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1544193358 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "720"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "720"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"309\", \"100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843140", timeStamp: "1544193427", hash: "0xf7685de7e31d158ace3001783438d61ee46f538916da8255eba8510d83608567", nonce: "122", blockHash: "0x8fbeb3554a5140bf4dc6b308b9b85aff5ef560c95ee807f3168156fb17b5d6ce", transactionIndex: "100", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84011", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed000000000000000000000000000000000000000000000000000000000000013500000000000000000000000000000000000000000000000000005af3107a4000", contractAddress: "", cumulativeGasUsed: "4043711", gasUsed: "84011", confirmations: "836178"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "309"}, {type: "uint256", name: "_levelPrice", value: "100000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "309", "100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1544193427 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "309"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "309"}, {name: "newLevelPrice", type: "uint256", value: "100000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"309\", \"731\" )", async function( ) {
		const txOriginal = {blockNumber: "6843150", timeStamp: "1544193629", hash: "0x68690087d0cd1cd8d56bf96f8dcc510cb0283aace12648e550e3d255362a2de4", nonce: "123", blockHash: "0xadd315c3f13e8d2f0df12c24ab0e9cb246b9c20de8392c88a28c5deff52811df", transactionIndex: "161", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "1500000000000000", gas: "409821", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xae1e0330000000000000000000000000000000000000000000000000000000000000013500000000000000000000000000000000000000000000000000000000000002db", contractAddress: "", cumulativeGasUsed: "7157348", gasUsed: "408991", confirmations: "836168"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "309"}, {type: "uint256", name: "_studentId", value: "731"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "309", "731", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1544193629 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "43500000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[7,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "2"}, {name: "mentorId", type: "uint256", value: "309"}, {name: "studentId", type: "uint256", value: "731"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "1"}, {name: "levelUp", type: "uint256", value: "15"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544193629"}, {name: "endsAt", type: "uint256", value: "1544211629"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[7,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"184\", \"100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843153", timeStamp: "1544193699", hash: "0x71c359e2a330eaccfe66a388022f718109e643607562bd3ce42df6c65c424228", nonce: "124", blockHash: "0x1c95858899f45f21bc796c5280cc679380b6f85291d522d992b53770777ba49c", transactionIndex: "12", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "83947", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000000b800000000000000000000000000000000000000000000000000005af3107a4000", contractAddress: "", cumulativeGasUsed: "2698361", gasUsed: "83947", confirmations: "836165"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "184"}, {type: "uint256", name: "_levelPrice", value: "100000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "184", "100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1544193699 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "184"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "184"}, {name: "newLevelPrice", type: "uint256", value: "100000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"310\", \"100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843159", timeStamp: "1544193844", hash: "0x0e8a446698d5916ef6fb7b2da7a86dee3ca0f48315f73a4cc19721c7ccca8cfa", nonce: "125", blockHash: "0xd8f95154b15b2b18c439a051bce1901568b5014b02dd5a5df7f084c1efa42bd0", transactionIndex: "77", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84011", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed000000000000000000000000000000000000000000000000000000000000013600000000000000000000000000000000000000000000000000005af3107a4000", contractAddress: "", cumulativeGasUsed: "5260273", gasUsed: "84011", confirmations: "836159"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "310"}, {type: "uint256", name: "_levelPrice", value: "100000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "310", "100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1544193844 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "310"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "310"}, {name: "newLevelPrice", type: "uint256", value: "100000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"720\", \"716\" )", async function( ) {
		const txOriginal = {blockNumber: "6843159", timeStamp: "1544193844", hash: "0xd7694f5d442aef2d050a9aa1b6c1e251fa21776d2db2c9ea44286fd21dd1a44e", nonce: "58", blockHash: "0xd8f95154b15b2b18c439a051bce1901568b5014b02dd5a5df7f084c1efa42bd0", transactionIndex: "83", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "10000000000000", gas: "409832", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000002cc", contractAddress: "", cumulativeGasUsed: "5819569", gasUsed: "409002", confirmations: "836159"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "720"}, {type: "uint256", name: "_studentId", value: "716"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "720", "716", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1544193844 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "290000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[10,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "3"}, {name: "mentorId", type: "uint256", value: "720"}, {name: "studentId", type: "uint256", value: "716"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "29"}, {name: "levelUp", type: "uint256", value: "1"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544193844"}, {name: "endsAt", type: "uint256", value: "1544195044"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[10,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"184\", \"743\" )", async function( ) {
		const txOriginal = {blockNumber: "6843161", timeStamp: "1544193881", hash: "0x0475c0d7e53910b9df3ebc1cbe26fbc0619946d7b9a93cd4c27f04b3853057dd", nonce: "126", blockHash: "0x967262f7e416d19f877a1bfa39d9977f9918edabec09cd5e3ca7dedef9550db3", transactionIndex: "19", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "400000000000000", gas: "409768", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000b800000000000000000000000000000000000000000000000000000000000002e7", contractAddress: "", cumulativeGasUsed: "1693092", gasUsed: "408938", confirmations: "836157"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "400000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "184"}, {type: "uint256", name: "_studentId", value: "743"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "184", "743", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1544193881 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "11600000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "4"}, {name: "mentorId", type: "uint256", value: "184"}, {name: "studentId", type: "uint256", value: "743"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "23"}, {name: "levelUp", type: "uint256", value: "4"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544193881"}, {name: "endsAt", type: "uint256", value: "1544198681"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"545\", \"100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843163", timeStamp: "1544193889", hash: "0x608ad5a85f8134ee8d659afe97b2bc45fc0dac736a6ea0c45660f6f152ffe1f5", nonce: "127", blockHash: "0xbabccf517f43d4d64b94ec4c4136be579394b0e140ff736fb7f61ffff1fb6463", transactionIndex: "204", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84011", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed000000000000000000000000000000000000000000000000000000000000022100000000000000000000000000000000000000000000000000005af3107a4000", contractAddress: "", cumulativeGasUsed: "6151196", gasUsed: "84011", confirmations: "836155"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "545"}, {type: "uint256", name: "_levelPrice", value: "100000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "545", "100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1544193889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "545"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "545"}, {name: "newLevelPrice", type: "uint256", value: "100000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"310\", \"734\" )", async function( ) {
		const txOriginal = {blockNumber: "6843171", timeStamp: "1544194005", hash: "0xe13eed573ca91c761a2db3bfa28af1b9638949c9fb76d0c43097fc1b0fc29cbd", nonce: "128", blockHash: "0x349e1dae5e05e511ee8553d7626bb1e5a962017d8ff8c4bdee20cb64fb491e6d", transactionIndex: "105", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "200000000000000", gas: "409832", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xae1e0330000000000000000000000000000000000000000000000000000000000000013600000000000000000000000000000000000000000000000000000000000002de", contractAddress: "", cumulativeGasUsed: "6638755", gasUsed: "409002", confirmations: "836147"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "200000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "310"}, {type: "uint256", name: "_studentId", value: "734"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "310", "734", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1544194005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[13,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "5800000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[13,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[13,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "5"}, {name: "mentorId", type: "uint256", value: "310"}, {name: "studentId", type: "uint256", value: "734"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "27"}, {name: "levelUp", type: "uint256", value: "2"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544194005"}, {name: "endsAt", type: "uint256", value: "1544196405"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[13,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"545\", \"733\" )", async function( ) {
		const txOriginal = {blockNumber: "6843175", timeStamp: "1544194108", hash: "0x5369c6a38e4434167662a05633d3ff64b6560e6be4063bb026820e289506eff2", nonce: "129", blockHash: "0x0c2aa6a8691c64bd29c3ec785e251b6cfb68b88ebf2aad1750b9706764bfe412", transactionIndex: "79", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "200000000000000", gas: "409832", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xae1e0330000000000000000000000000000000000000000000000000000000000000022100000000000000000000000000000000000000000000000000000000000002dd", contractAddress: "", cumulativeGasUsed: "7052124", gasUsed: "409002", confirmations: "836143"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "200000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "545"}, {type: "uint256", name: "_studentId", value: "733"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "545", "733", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1544194108 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "5800000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[14,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "6"}, {name: "mentorId", type: "uint256", value: "545"}, {name: "studentId", type: "uint256", value: "733"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "27"}, {name: "levelUp", type: "uint256", value: "2"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544194108"}, {name: "endsAt", type: "uint256", value: "1544196508"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[14,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"741\", \"16000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843176", timeStamp: "1544194118", hash: "0xa635e55ccb235cb8d14823e4e032732c233cac70d925663697f00c5561e00654", nonce: "86", blockHash: "0xce80f4e56638a18c24e3060e5978cdfb641ecc2abcde2a80845ee449ea285b08", transactionIndex: "63", from: "0xfc7a64183f49f71a1d604496e62c08f20af5b5d6", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84011", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000002e50000000000000000000000000000000000000000000000000038d7ea4c680000", contractAddress: "", cumulativeGasUsed: "4532351", gasUsed: "84011", confirmations: "836142"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "741"}, {type: "uint256", name: "_levelPrice", value: "16000000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "741", "16000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1544194118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "741"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "741"}, {name: "newLevelPrice", type: "uint256", value: "16000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "343585168071982989" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"742\", \"24000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843182", timeStamp: "1544194197", hash: "0xcdf803f486f1a3d62aceda749b29a755557ffe12c7191101c8eab395b7d23858", nonce: "87", blockHash: "0x83fa9b7990a4a89166306c5e40bb42e26405f6a661fb86fe71b2814c2aa4dd5b", transactionIndex: "186", from: "0xfc7a64183f49f71a1d604496e62c08f20af5b5d6", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84011", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000002e6000000000000000000000000000000000000000000000000005543df729c0000", contractAddress: "", cumulativeGasUsed: "6483811", gasUsed: "84011", confirmations: "836136"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "742"}, {type: "uint256", name: "_levelPrice", value: "24000000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "742", "24000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1544194197 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "742"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "742"}, {name: "newLevelPrice", type: "uint256", value: "24000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "343585168071982989" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"182\", \"100000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843187", timeStamp: "1544194236", hash: "0x9cef1816a16884f07b209f8cffe5634e89c641d420e2721bff3298321b7c6a3a", nonce: "130", blockHash: "0x091e7a4bad628c81a8e5622d5ae5dcbd9b21583e135b783e4757b6b44c44af1f", transactionIndex: "113", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "83947", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000000b600000000000000000000000000000000000000000000000000005af3107a4000", contractAddress: "", cumulativeGasUsed: "4839918", gasUsed: "83947", confirmations: "836131"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "182"}, {type: "uint256", name: "_levelPrice", value: "100000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "182", "100000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1544194236 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "182"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "182"}, {name: "newLevelPrice", type: "uint256", value: "100000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"182\", \"729\" )", async function( ) {
		const txOriginal = {blockNumber: "6843196", timeStamp: "1544194402", hash: "0xd825603ce1be97c25411a2c35f986e14dd0c0c5b7762a34160df801375577cd2", nonce: "131", blockHash: "0x6e789adb646e8ad742492bf2da6bb99e647ae005a7825bc8329d8dc57e4e9370", transactionIndex: "99", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "700000000000000", gas: "409757", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000b600000000000000000000000000000000000000000000000000000000000002d9", contractAddress: "", cumulativeGasUsed: "5550952", gasUsed: "408927", confirmations: "836122"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "700000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "182"}, {type: "uint256", name: "_studentId", value: "729"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "182", "729", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1544194402 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "20300000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "7"}, {name: "mentorId", type: "uint256", value: "182"}, {name: "studentId", type: "uint256", value: "729"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "16"}, {name: "levelUp", type: "uint256", value: "7"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544194402"}, {name: "endsAt", type: "uint256", value: "1544202802"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"728\", \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843206", timeStamp: "1544194475", hash: "0x424d58d3231b205ca6cbd0c79b8e63605c88282725a240d0004ebb84bee4fdef", nonce: "132", blockHash: "0x57c222b6cc9f04d91ed945b8d93b75fcbdbf80bbd961284e9a0f8706e84c9692", transactionIndex: "106", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84011", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000002d8000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "3746565", gasUsed: "84011", confirmations: "836112"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "728"}, {type: "uint256", name: "_levelPrice", value: "10000000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "728", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1544194475 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "728"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "728"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"183\", \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843217", timeStamp: "1544194685", hash: "0x45e5fee5079cd170e41422c6dbc8ce671b32e243149ad31b5be25cbb0176124b", nonce: "133", blockHash: "0x8101625b928174f53755e7aa0f0c36067bbc8ce64ec34402ee5777c69ebf4735", transactionIndex: "43", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "83947", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000000b7000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "2627719", gasUsed: "83947", confirmations: "836101"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "183"}, {type: "uint256", name: "_levelPrice", value: "10000000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "183", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1544194685 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "183"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "183"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"720\", \"1002\" )", async function( ) {
		const txOriginal = {blockNumber: "6843444", timeStamp: "1544197901", hash: "0x5b8629dbb357855cd507a3845ca67cb91a896b99537141374f7e0c64f8da5f1b", nonce: "60", blockHash: "0x1b5397d8dd6e6e81707f415013357e9a7e24f47020fb2f07b4edab4e0001a593", transactionIndex: "23", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "150000000000000", gas: "379832", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000003ea", contractAddress: "", cumulativeGasUsed: "7072329", gasUsed: "379002", confirmations: "835874"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "150000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "720"}, {type: "uint256", name: "_studentId", value: "1002"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "720", "1002", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1544197901 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[21,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "4350000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[21,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "8"}, {name: "mentorId", type: "uint256", value: "720"}, {name: "studentId", type: "uint256", value: "1002"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "1"}, {name: "levelUp", type: "uint256", value: "15"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544197901"}, {name: "endsAt", type: "uint256", value: "1544215901"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"224\", \"715\" )", async function( ) {
		const txOriginal = {blockNumber: "6843455", timeStamp: "1544198026", hash: "0xe5d655245c4df29165a6b3941763c1be7ef1de25805fd1aaed6a0bd2b9b8e2fd", nonce: "62", blockHash: "0x9b0843062a7b5666bf97f0078cda52b00919c66f6628e96de411e2902dc5f260", transactionIndex: "15", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "100000000000000", gas: "379757", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000002cb", contractAddress: "", cumulativeGasUsed: "6124430", gasUsed: "378927", confirmations: "835863"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}, {type: "uint256", name: "_studentId", value: "715"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "224", "715", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1544198026 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "2900000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "9"}, {name: "mentorId", type: "uint256", value: "224"}, {name: "studentId", type: "uint256", value: "715"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "29"}, {name: "levelUp", type: "uint256", value: "1"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544198026"}, {name: "endsAt", type: "uint256", value: "1544199226"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: changeLevelPrice( \"224\", \"10000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843457", timeStamp: "1544198054", hash: "0xdd2cb0b4f59a0d461c0e20b2996806e8db13c7318ffe69697851b960cc64deee", nonce: "63", blockHash: "0x5489ae574a982e95b081113e5aeb13ec1d1e7e0dd25577d2fcf0118589eec81a", transactionIndex: "76", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "38194", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x075f447b00000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000009184e72a000", contractAddress: "", cumulativeGasUsed: "5645979", gasUsed: "38194", confirmations: "835861"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}, {type: "uint256", name: "_levelPrice", value: "10000000000000"}], name: "changeLevelPrice", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeLevelPrice(uint256,uint256)" ]( "224", "10000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1544198054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "224"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: breakMentoring( \"224\" )", async function( ) {
		const txOriginal = {blockNumber: "6843457", timeStamp: "1544198054", hash: "0x0fc9ff80b13b097efbba4cde9c32b2e6e2274f516719fef0d216c88d57d33a8b", nonce: "64", blockHash: "0x5489ae574a982e95b081113e5aeb13ec1d1e7e0dd25577d2fcf0118589eec81a", transactionIndex: "77", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "46000", gasPrice: "6000000000", isError: "1", txreceipt_status: "0", input: "0x1fede9d900000000000000000000000000000000000000000000000000000000000000e0", contractAddress: "", cumulativeGasUsed: "5677561", gasUsed: "31582", confirmations: "835861"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}], name: "breakMentoring", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "breakMentoring(uint256)" ]( "224", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1544198054 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"720\", \"1002\" )", async function( ) {
		const txOriginal = {blockNumber: "6843461", timeStamp: "1544198086", hash: "0xc17e42a45f04fe99e63891defef0b2af1a480e9224cbe0ef89f0ac5a00c1c9c7", nonce: "66", blockHash: "0x4fd662eebeac9b2756a128863273387948e2256106ef92c562feff9bb793300f", transactionIndex: "19", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "150000000000000", gas: "379832", gasPrice: "8000000000", isError: "1", txreceipt_status: "0", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000003ea", contractAddress: "", cumulativeGasUsed: "1487718", gasUsed: "46739", confirmations: "835857"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "150000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "720"}, {type: "uint256", name: "_studentId", value: "1002"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "720", "1002", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1544198086 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"224\", \"718\" )", async function( ) {
		const txOriginal = {blockNumber: "6843561", timeStamp: "1544199633", hash: "0xa1f1b5d162b204ab245bdc9af3d0a259bf9da220a2d576bedfc993004e48610a", nonce: "72", blockHash: "0xe660079a2c079a184e7b8c3493fed4e3d64eda4798bf3083c3ec380910aba16c", transactionIndex: "49", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "10000000000000", gas: "379757", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000002ce", contractAddress: "", cumulativeGasUsed: "5991319", gasUsed: "378927", confirmations: "835757"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}, {type: "uint256", name: "_studentId", value: "718"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "224", "718", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1544199633 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "290000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[26,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "10"}, {name: "mentorId", type: "uint256", value: "224"}, {name: "studentId", type: "uint256", value: "718"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "29"}, {name: "levelUp", type: "uint256", value: "1"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544199633"}, {name: "endsAt", type: "uint256", value: "1544200833"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[26,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"184\", \"743\" )", async function( ) {
		const txOriginal = {blockNumber: "6843676", timeStamp: "1544201395", hash: "0x485df4b4205b2ecd320c933c651ab13424d57ea17b9dde7228cb18a4421c1e28", nonce: "134", blockHash: "0x3c726cb24662a989db7324780d4d29a3a8fa1e0463204b6d0978760875c27a73", transactionIndex: "124", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "200000000000000", gas: "349768", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000b800000000000000000000000000000000000000000000000000000000000002e7", contractAddress: "", cumulativeGasUsed: "6829505", gasUsed: "348938", confirmations: "835642"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "200000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "184"}, {type: "uint256", name: "_studentId", value: "743"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "184", "743", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1544201395 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "5800000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[27,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "11"}, {name: "mentorId", type: "uint256", value: "184"}, {name: "studentId", type: "uint256", value: "743"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "27"}, {name: "levelUp", type: "uint256", value: "2"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544201395"}, {name: "endsAt", type: "uint256", value: "1544203795"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[27,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"545\", \"733\" )", async function( ) {
		const txOriginal = {blockNumber: "6843682", timeStamp: "1544201434", hash: "0xece126412bba3b9ef9c98220cf9e4c10bf9d2d145473715c75496f815f8b0ab3", nonce: "135", blockHash: "0xdd83450fd7f07e6db2a3b84a7d6519ca48f718b9314fea10d54a78142dad8bea", transactionIndex: "72", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "100000000000000", gas: "349832", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xae1e0330000000000000000000000000000000000000000000000000000000000000022100000000000000000000000000000000000000000000000000000000000002dd", contractAddress: "", cumulativeGasUsed: "3912027", gasUsed: "349002", confirmations: "835636"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "545"}, {type: "uint256", name: "_studentId", value: "733"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "545", "733", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1544201434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "2900000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[28,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "12"}, {name: "mentorId", type: "uint256", value: "545"}, {name: "studentId", type: "uint256", value: "733"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "29"}, {name: "levelUp", type: "uint256", value: "1"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544201434"}, {name: "endsAt", type: "uint256", value: "1544202634"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[28,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"310\", \"734\" )", async function( ) {
		const txOriginal = {blockNumber: "6843687", timeStamp: "1544201487", hash: "0x3f8f0b5ab7e20657ee0379a374e3c6ae2fd8b8599e01494719c140f3a7d45544", nonce: "136", blockHash: "0xd8fa447193c5520f6f86056f9e279860e6608c333f603d42268b45d185c0fe1f", transactionIndex: "181", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "100000000000000", gas: "349832", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xae1e0330000000000000000000000000000000000000000000000000000000000000013600000000000000000000000000000000000000000000000000000000000002de", contractAddress: "", cumulativeGasUsed: "6355660", gasUsed: "349002", confirmations: "835631"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "310"}, {type: "uint256", name: "_studentId", value: "734"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "310", "734", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1544201487 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "2900000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[29,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "13"}, {name: "mentorId", type: "uint256", value: "310"}, {name: "studentId", type: "uint256", value: "734"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "29"}, {name: "levelUp", type: "uint256", value: "1"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544201487"}, {name: "endsAt", type: "uint256", value: "1544202687"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[29,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"224\", \"740\" )", async function( ) {
		const txOriginal = {blockNumber: "6843710", timeStamp: "1544201807", hash: "0xd6978a80cde045f7250de0120fcea3e3b54045b2d42ce2e62444f28cca8e24c9", nonce: "74", blockHash: "0x475bbf27c537e05e0e063fd6e7b1c2b03d5639bf8acfd8e96198ae128b8e8004", transactionIndex: "113", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "20000000000000", gas: "379757", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000002e4", contractAddress: "", cumulativeGasUsed: "7027496", gasUsed: "378927", confirmations: "835608"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "20000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}, {type: "uint256", name: "_studentId", value: "740"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "224", "740", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1544201807 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "580000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[30,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "14"}, {name: "mentorId", type: "uint256", value: "224"}, {name: "studentId", type: "uint256", value: "740"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "27"}, {name: "levelUp", type: "uint256", value: "2"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544201807"}, {name: "endsAt", type: "uint256", value: "1544204207"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[30,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: changeLevelPrice( \"742\", \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843732", timeStamp: "1544202143", hash: "0x50294b94fee90d4e529f385c8d71c9fa99470be9632c554fd7c0bc85422ae77f", nonce: "98", blockHash: "0x793903cef866a74d96416f617edf5c71204edea4a64b442afcd559565be20c28", transactionIndex: "46", from: "0xfc7a64183f49f71a1d604496e62c08f20af5b5d6", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "38258", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x075f447b00000000000000000000000000000000000000000000000000000000000002e6000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "5250682", gasUsed: "38258", confirmations: "835586"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "742"}, {type: "uint256", name: "_levelPrice", value: "10000000000000000"}], name: "changeLevelPrice", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeLevelPrice(uint256,uint256)" ]( "742", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1544202143 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "742"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "343585168071982989" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: changeLevelPrice( \"741\", \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843740", timeStamp: "1544202245", hash: "0x2843cdec0adb1c689d48b2231550d406eb45e52872ff64ca0500cb7afa319f86", nonce: "99", blockHash: "0x7141c9aeaa81193cd64fd0755e3f6da631c12ccefef2973fd04ca01b4d20c4c5", transactionIndex: "57", from: "0xfc7a64183f49f71a1d604496e62c08f20af5b5d6", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "38258", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x075f447b00000000000000000000000000000000000000000000000000000000000002e5000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "7906289", gasUsed: "38258", confirmations: "835578"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "741"}, {type: "uint256", name: "_levelPrice", value: "10000000000000000"}], name: "changeLevelPrice", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeLevelPrice(uint256,uint256)" ]( "741", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1544202245 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "741"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "343585168071982989" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"182\", \"729\" )", async function( ) {
		const txOriginal = {blockNumber: "6843849", timeStamp: "1544203642", hash: "0x4d2fab36aae245323f2809904759a996fc0213903cca3a6aaabf2952b9afc2d0", nonce: "137", blockHash: "0x6455cdbdf3e6ea2a020d8a381a8e5977bd6431cd25a1a86f613add231c969e67", transactionIndex: "59", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "400000000000000", gas: "349757", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000b600000000000000000000000000000000000000000000000000000000000002d9", contractAddress: "", cumulativeGasUsed: "5827153", gasUsed: "348927", confirmations: "835469"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "400000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "182"}, {type: "uint256", name: "_studentId", value: "729"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "182", "729", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1544203642 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "11600000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[33,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "15"}, {name: "mentorId", type: "uint256", value: "182"}, {name: "studentId", type: "uint256", value: "729"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "23"}, {name: "levelUp", type: "uint256", value: "4"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544203642"}, {name: "endsAt", type: "uint256", value: "1544208442"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[33,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: changeLevelPrice( \"545\", \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843853", timeStamp: "1544203689", hash: "0x3c1b24701df8b50489af60561d288babd674edceaa93e8b1e76320d4d7914838", nonce: "138", blockHash: "0xdb2ff2876f57037d7deabdb1cfcff1e143fdd2e26b4551a602f4741b6bcf66c2", transactionIndex: "123", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "38258", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x075f447b0000000000000000000000000000000000000000000000000000000000000221000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "6784297", gasUsed: "38258", confirmations: "835465"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "545"}, {type: "uint256", name: "_levelPrice", value: "10000000000000000"}], name: "changeLevelPrice", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeLevelPrice(uint256,uint256)" ]( "545", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1544203689 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "545"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: changeLevelPrice( \"310\", \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843857", timeStamp: "1544203729", hash: "0x9e4726477fa194e4b42ca996e7d249853d15222d01cd20e80cda6b07c3ddfa00", nonce: "139", blockHash: "0xb097c952d54bf0f47a23d29e841c73c7351fa83d3bd151309f5f27d25ee2c9f6", transactionIndex: "68", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "38258", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x075f447b0000000000000000000000000000000000000000000000000000000000000136000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "5954548", gasUsed: "38258", confirmations: "835461"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "310"}, {type: "uint256", name: "_levelPrice", value: "10000000000000000"}], name: "changeLevelPrice", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeLevelPrice(uint256,uint256)" ]( "310", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1544203729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "310"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: breakMentoring( \"183\" )", async function( ) {
		const txOriginal = {blockNumber: "6843898", timeStamp: "1544204324", hash: "0x4711d86f8a5ae0fa606de48f44403f62ae58ab47f1e29f79701601fc3e6f49fe", nonce: "140", blockHash: "0xa7ffefa49cfe4a832fc37422df8c50f43b66497b7ef6c6c51ee53415821e837d", transactionIndex: "67", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "46000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x1fede9d900000000000000000000000000000000000000000000000000000000000000b7", contractAddress: "", cumulativeGasUsed: "4974980", gasUsed: "31000", confirmations: "835420"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "183"}], name: "breakMentoring", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "breakMentoring(uint256)" ]( "183", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1544204324 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BreakMentoring", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BreakMentoring", events: [{name: "mentorId", type: "uint256", value: "183"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: changeLevelPrice( \"184\", \"10000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6843900", timeStamp: "1544204350", hash: "0x9273018f6af8ef12f6dd34be79def6054f3e1d8ffccbd53d9c3e1cdcc5d725a0", nonce: "141", blockHash: "0x8545a072046dd9ee06046c66f7aaaafe1748e606fefd4106bc35a12841cc8b7b", transactionIndex: "90", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "38194", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x075f447b00000000000000000000000000000000000000000000000000000000000000b8000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "5224712", gasUsed: "38194", confirmations: "835418"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "184"}, {type: "uint256", name: "_levelPrice", value: "10000000000000000"}], name: "changeLevelPrice", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeLevelPrice(uint256,uint256)" ]( "184", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1544204350 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "184"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"368\", \"9000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6844003", timeStamp: "1544205669", hash: "0xc2af220072c4bcbdbfbac70984d5033cd2350ff1177a0306835f821b6296da43", nonce: "26", blockHash: "0xb711c02bb183e39a28ff4a03ad1a49b1978092a96e0e516b0637410bba359283", transactionIndex: "128", from: "0xb06acd8fb3ad6a2b852bea57c06a168f823aad39", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84075", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed0000000000000000000000000000000000000000000000000000000000000170000000000000000000000000000000000000000000000000001ff973cafa8000", contractAddress: "", cumulativeGasUsed: "6719137", gasUsed: "84075", confirmations: "835315"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "368"}, {type: "uint256", name: "_levelPrice", value: "9000000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "368", "9000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1544205669 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "368"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "368"}, {name: "newLevelPrice", type: "uint256", value: "9000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1631501060074103" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"224\", \"740\" )", async function( ) {
		const txOriginal = {blockNumber: "6844014", timeStamp: "1544205869", hash: "0xab84517e098ec1c5ce374f0fecdb09207ca61e58a4fd57051e50912f40de5b87", nonce: "75", blockHash: "0xda264f8be0d01711923c630ced33d36ccb3bcefaafb5312364ad675d0d3da9ed", transactionIndex: "66", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "10000000000000", gas: "349757", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000002e4", contractAddress: "", cumulativeGasUsed: "7549701", gasUsed: "348927", confirmations: "835304"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}, {type: "uint256", name: "_studentId", value: "740"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "224", "740", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1544205869 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "290000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[39,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "16"}, {name: "mentorId", type: "uint256", value: "224"}, {name: "studentId", type: "uint256", value: "740"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "29"}, {name: "levelUp", type: "uint256", value: "1"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544205869"}, {name: "endsAt", type: "uint256", value: "1544207069"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[39,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"224\", \"1008\" )", async function( ) {
		const txOriginal = {blockNumber: "6844141", timeStamp: "1544207527", hash: "0xdb241c0da2fb484f0d64cb28e638913d7dae224101580653ceac13b8e44abe93", nonce: "77", blockHash: "0x8f5f180a30a5f11f87382d6abf0fe0a5fa1a17ef76019d1d26bbc8d192012829", transactionIndex: "56", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "150000000000000", gas: "379757", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000003f0", contractAddress: "", cumulativeGasUsed: "3783318", gasUsed: "378927", confirmations: "835177"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "150000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}, {type: "uint256", name: "_studentId", value: "1008"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "224", "1008", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544207527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "4350000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[40,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "17"}, {name: "mentorId", type: "uint256", value: "224"}, {name: "studentId", type: "uint256", value: "1008"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "1"}, {name: "levelUp", type: "uint256", value: "15"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544207527"}, {name: "endsAt", type: "uint256", value: "1544225527"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[40,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"683\", \"100000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6845961", timeStamp: "1544233971", hash: "0x287965c94294241667510b79fa6f59f9712b590eb80eb5219c941ff72c78016a", nonce: "47", blockHash: "0x54689d101a0a50c857905085d1ee64c60b75ebd962ed20ca24314fccff000c32", transactionIndex: "12", from: "0xc8235574f64a8ac6391492e16e833b48aebdfdb5", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84075", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000002ab000000000000000000000000000000000000000000000000016345785d8a0000", contractAddress: "", cumulativeGasUsed: "417933", gasUsed: "84075", confirmations: "833357"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "683"}, {type: "uint256", name: "_levelPrice", value: "100000000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "683", "100000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544233971 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "683"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "683"}, {name: "newLevelPrice", type: "uint256", value: "100000000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "49245376414170479" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"720\", \"742\" )", async function( ) {
		const txOriginal = {blockNumber: "6846709", timeStamp: "1544244890", hash: "0xe134c08064f29afac50103fa22b40091c5871918333aabc8af48cc7bc2bde989", nonce: "106", blockHash: "0x78cc31062c975b7be14d60fb12bd78259b41d9365b1df8be07eb7e5d8f50315b", transactionIndex: "38", from: "0xfc7a64183f49f71a1d604496e62c08f20af5b5d6", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "20000000000000", gas: "380052", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000002e6", contractAddress: "", cumulativeGasUsed: "2845192", gasUsed: "379222", confirmations: "832609"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "20000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "720"}, {type: "uint256", name: "_studentId", value: "742"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "720", "742", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544244890 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[42,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "580000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[42,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[42,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "18"}, {name: "mentorId", type: "uint256", value: "720"}, {name: "studentId", type: "uint256", value: "742"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "27"}, {name: "levelUp", type: "uint256", value: "2"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544244890"}, {name: "endsAt", type: "uint256", value: "1544247290"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[42,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "343585168071982989" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"720\", \"742\" )", async function( ) {
		const txOriginal = {blockNumber: "6847048", timeStamp: "1544249574", hash: "0x4f8e0db3c218deced7bdc0636ba1f558158c28e2c26f12bae43898569fb901b1", nonce: "107", blockHash: "0x4c9e9d28e6a12fb942fb0e584ad6d84a6aadf7ddca3f2b76b5d7ee6c88334c09", transactionIndex: "119", from: "0xfc7a64183f49f71a1d604496e62c08f20af5b5d6", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "10000000000000", gas: "321111", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000002e6", contractAddress: "", cumulativeGasUsed: "7137947", gasUsed: "320940", confirmations: "832270"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "720"}, {type: "uint256", name: "_studentId", value: "742"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "720", "742", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544249574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "343585168071982989" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"720\", \"742\" )", async function( ) {
		const txOriginal = {blockNumber: "6847081", timeStamp: "1544250048", hash: "0x5b1c1b7c990af496dfe6c37ee8187afee53b980abc31b5bfd6eaae72db5374a8", nonce: "108", blockHash: "0x2502257d4b8492f13f7974c907eabb81d6e42908656f1edbaef6461e0804cd27", transactionIndex: "45", from: "0xfc7a64183f49f71a1d604496e62c08f20af5b5d6", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "10000000000000", gas: "350052", gasPrice: "4300000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000002e6", contractAddress: "", cumulativeGasUsed: "7823176", gasUsed: "349222", confirmations: "832237"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "720"}, {type: "uint256", name: "_studentId", value: "742"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "720", "742", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544250048 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "290000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[44,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "19"}, {name: "mentorId", type: "uint256", value: "720"}, {name: "studentId", type: "uint256", value: "742"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "29"}, {name: "levelUp", type: "uint256", value: "1"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544250048"}, {name: "endsAt", type: "uint256", value: "1544251248"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[44,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "343585168071982989" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"224\", \"1007\" )", async function( ) {
		const txOriginal = {blockNumber: "6847131", timeStamp: "1544250830", hash: "0xb71f7397c5dde51e498c7ff0198f2c04d2e34e8d0e999b0f15cfc47c19dc9725", nonce: "78", blockHash: "0x3bdc0e018db9d19e6e095b7834d5dca856534851d55ae0578e14cdd2d25b4ef2", transactionIndex: "73", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "150000000000000", gas: "379757", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000003ef", contractAddress: "", cumulativeGasUsed: "4810136", gasUsed: "378927", confirmations: "832187"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "150000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "224"}, {type: "uint256", name: "_studentId", value: "1007"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "224", "1007", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544250830 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "4350000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[45,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "20"}, {name: "mentorId", type: "uint256", value: "224"}, {name: "studentId", type: "uint256", value: "1007"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "1"}, {name: "levelUp", type: "uint256", value: "15"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544250830"}, {name: "endsAt", type: "uint256", value: "1544268830"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[45,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"720\", \"1005\" )", async function( ) {
		const txOriginal = {blockNumber: "6847174", timeStamp: "1544251336", hash: "0x1a8ffdd9e48cd3144624a34d08af0748644181affa5d6f8b24508cf67790ab20", nonce: "79", blockHash: "0x60ae291230e6963ebe1f3bcbb9c37f7aee8f5b8e229da872a3c0d1533ed6adcf", transactionIndex: "82", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "150000000000000", gas: "379832", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000002d000000000000000000000000000000000000000000000000000000000000003ed", contractAddress: "", cumulativeGasUsed: "6694941", gasUsed: "379002", confirmations: "832144"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "150000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "720"}, {type: "uint256", name: "_studentId", value: "1005"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "720", "1005", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544251336 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "4350000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "21"}, {name: "mentorId", type: "uint256", value: "720"}, {name: "studentId", type: "uint256", value: "1005"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "1"}, {name: "levelUp", type: "uint256", value: "15"}, {name: "levelPrice", type: "uint256", value: "10000000000000"}, {name: "startedAt", type: "uint256", value: "1544251336"}, {name: "endsAt", type: "uint256", value: "1544269336"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"182\", \"732\" )", async function( ) {
		const txOriginal = {blockNumber: "6847983", timeStamp: "1544263166", hash: "0x74b26200a87333f4dbcbb5bc5c67672245ea3f9f31280561a290430b5ea57fcb", nonce: "142", blockHash: "0x5729bd09fa557a5a3d626c084f50db8e4b865a1d721a17c9d8c7c356a8987a02", transactionIndex: "48", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "1500000000000000", gas: "379762", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xae1e033000000000000000000000000000000000000000000000000000000000000000b600000000000000000000000000000000000000000000000000000000000002dc", contractAddress: "", cumulativeGasUsed: "7617271", gasUsed: "378927", confirmations: "831335"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1500000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "182"}, {type: "uint256", name: "_studentId", value: "732"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "182", "732", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544263166 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "43500000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[47,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "22"}, {name: "mentorId", type: "uint256", value: "182"}, {name: "studentId", type: "uint256", value: "732"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "1"}, {name: "levelUp", type: "uint256", value: "15"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544263166"}, {name: "endsAt", type: "uint256", value: "1544281166"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[47,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: startLecture( \"309\", \"731\" )", async function( ) {
		const txOriginal = {blockNumber: "6848011", timeStamp: "1544263627", hash: "0x306dfe235b711a4dcf65dd1baed5b236b6f9b5294dd16089d276cb76c3282426", nonce: "143", blockHash: "0x7f8c5328f6dc29a3f9df5b18832d51079225c63bdfc46ae6225f363ef75e647e", transactionIndex: "56", from: "0x4189f423e18877bdbb1e48723a3e4a7fa7503d5d", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "700000000000000", gas: "349830", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xae1e0330000000000000000000000000000000000000000000000000000000000000013500000000000000000000000000000000000000000000000000000000000002db", contractAddress: "", cumulativeGasUsed: "7869819", gasUsed: "348991", confirmations: "831307"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "700000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "309"}, {type: "uint256", name: "_studentId", value: "731"}], name: "startLecture", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startLecture(uint256,uint256)" ]( "309", "731", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544263627 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "source", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "Income", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Income", events: [{name: "source", type: "address", value: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}, {name: "amount", type: "uint256", value: "20300000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "lectureId", type: "uint256"}, {indexed: true, name: "mentorId", type: "uint256"}, {indexed: true, name: "studentId", type: "uint256"}, {indexed: false, name: "mentorLevel", type: "uint256"}, {indexed: false, name: "studentLevel", type: "uint256"}, {indexed: false, name: "levelUp", type: "uint256"}, {indexed: false, name: "levelPrice", type: "uint256"}, {indexed: false, name: "startedAt", type: "uint256"}, {indexed: false, name: "endsAt", type: "uint256"}], name: "StartLecture", type: "event"} ;
		console.error( "eventCallOriginal[48,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartLecture", events: [{name: "lectureId", type: "uint256", value: "23"}, {name: "mentorId", type: "uint256", value: "309"}, {name: "studentId", type: "uint256", value: "731"}, {name: "mentorLevel", type: "uint256", value: "30"}, {name: "studentLevel", type: "uint256", value: "16"}, {name: "levelUp", type: "uint256", value: "7"}, {name: "levelPrice", type: "uint256", value: "100000000000000"}, {name: "startedAt", type: "uint256", value: "1544263627"}, {name: "endsAt", type: "uint256", value: "1544272027"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[48,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1648398971596981" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: becomeMentor( \"740\", \"10000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6848286", timeStamp: "1544267405", hash: "0x06864b4f8789f5dd9307757e6a13573d07c32811df67a9e865e2ebc075740ca1", nonce: "80", blockHash: "0x8fe0a374ec4c74e04aee2e752eadd108919af030136bd9192ba19b390bd5800b", transactionIndex: "107", from: "0xe9601d9a1f804e7b983bd58e454fcd69165223dd", to: "0x6c602f1798a453f90f249e208e2b64c7c09226f7", value: "0", gas: "84011", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x99a3b8ed00000000000000000000000000000000000000000000000000000000000002e4000000000000000000000000000000000000000000000000000009184e72a000", contractAddress: "", cumulativeGasUsed: "6086057", gasUsed: "69011", confirmations: "831032"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_mentorId", value: "740"}, {type: "uint256", name: "_levelPrice", value: "10000000000000"}], name: "becomeMentor", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "becomeMentor(uint256,uint256)" ]( "740", "10000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544267405 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}], name: "BecomeMentor", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BecomeMentor", events: [{name: "mentorId", type: "uint256", value: "740"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "mentorId", type: "uint256"}, {indexed: false, name: "newLevelPrice", type: "uint256"}], name: "ChangeLevelPrice", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeLevelPrice", events: [{name: "mentorId", type: "uint256", value: "740"}, {name: "newLevelPrice", type: "uint256", value: "10000000000000"}], address: "0x6c602f1798a453f90f249e208e2b64c7c09226f7"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "5939115332844772" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
