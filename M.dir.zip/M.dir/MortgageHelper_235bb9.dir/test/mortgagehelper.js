const MortgageHelper = artifacts.require( "./MortgageHelper.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "MortgageHelper" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x90263Ea5C57Dc6603CA7202920735A6E31235bB9", "0x06779a9848e5Df60ce0F5f63F88c5310C4c7289C", "0x9ABf1295086aFA0E49C60e95c437aa400c5333B8", "0xbA5a17f8ad40dc2C955D95C0547F3e6318Bd72e7", "0x8e5660b4Ab70168b5a6fEeA0e0315cb49c8Cd539", "0x2AaF69A2Df2828B55fA4A5e30ee8C3C7CD9e5d5B", "0x223fE3c346bf47334eACcF1400717CB00D403372", "0x56783153D0A8cCB009dcB79dF5337835eD1a9d6c", "0x7D7cfEfB91C8Bb2C330EC66D99c225d47C9131c0", "0xa5FA2f5ef3e1f4aCAf99DE54567388C180D69f8c", "0x3B81DB7c9FE71A2c6d78F9ae2Fe4DF4C92272622", "0xAf592460D6a44517aba2fB0BCb02eE8F4103B502", "0xeA4e02D04E2209468e9a2D97431ceA4833884034", "0xEe8eEeC3E7a5ad82827480A9E00D01B1EC0a9F3B", "0x981DE60e39A72a1e5Af2eCEd4106a118fC158dd2", "0x05b8e6E10044DD5C67DF3A262d2Babf3Ad1EeFbC", "0x7a72a2E270265AddA6E038ddaa8f418E51b81eBB", "0xf0Fc268473A4FFAF2a652C3A8510Bf79b787A68f", "0x102c6EFF91c6b39d52ED47cE979585e4dC889c3F", "0xA2aD10f6058E80dDe620617e5f84618964a01046", "0x46540e20b067698B6Bc5419a36e3319EAbA525f4", "0x9798Ab37DDEEbaaE867F0F24a48638293E6B8240", "0x166A16Ff95A16D8a8f797C4f33578d5abddcf531", "0xC45ea7A85E220C50584918273cf2B709D411901d", "0x3A1948C2993047abBF93B85CccE1f1FF983dA65B", "0xe92e1aAa54f863ab48A39161a166f852B701b439", "0x86BF3AB3576Cc3Ea26284f7dA376471697E63cDf"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "rcn", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "marginSpend", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxSpend", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "landMarket", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "requiredTotal", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "mortgageManager", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "nanoLoanEngine", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "manaOracle", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "rebuyThreshold", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokenConverter", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "converterRamp", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "mana", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MANA_CURRENCY", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "engine", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "PaidLoan", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetRebuyThreshold", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetMarginSpend", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetMaxSpend", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetRequiredTotal", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "address"}, {indexed: false, name: "_new", type: "address"}], name: "SetTokenConverter", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "address"}, {indexed: false, name: "_new", type: "address"}], name: "SetConverterRamp", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_manaOracle", type: "address"}], name: "SetManaOracle", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_engine", type: "address"}], name: "SetEngine", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_landMarket", type: "address"}], name: "SetLandMarket", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_mortgageManager", type: "address"}], name: "SetMortgageManager", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_owner", type: "address"}], name: "SetOwner", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["NewMortgage(address,uint256,uint256,uint256)", "PaidLoan(address,uint256,uint256)", "SetRebuyThreshold(uint256,uint256)", "SetMarginSpend(uint256,uint256)", "SetMaxSpend(uint256,uint256)", "SetRequiredTotal(uint256,uint256)", "SetTokenConverter(address,address)", "SetConverterRamp(address,address)", "SetManaOracle(address)", "SetEngine(address)", "SetLandMarket(address)", "SetMortgageManager(address)", "SetOwner(address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x757ece6aef793d2488167dd37c3907b9e1292daf2e2581aeecbf9ff2c86e00f8", "0x10cf3851bc898c44f28125caa65875f0601136426fbffc7ec797697d4fa16ab2", "0x140828d3c8f7cdb392b0131e0cb1e7a24e97c91cee7c3e73afd36a7a9264df4e", "0x844564ce9c0f0a799518f7f624d8f61dd979455d57a1c79ccbb2f1271edd3fa3", "0x803bd25f19cba818b1563c9b0cb6999082325db98554d58a0df6da12876b577d", "0x62435ef53be23ea3c6e7798ebcfd33c2928674b3bb8b9fb2d762f9671a9c69dd", "0xc5b6ae9e3b4a82a521a68fb2b106185044d464ab524ececb4c9682f6714cdbfa", "0x342e3c8d003279a81250c360ff8bf17a6562ecb46fbc54aba8470bd2ccaff1f0", "0x3b025b4b8bc9992cd67c0e6651441cf67f450238c664e1f04c9d1ec54190f0cd", "0x9540b27a7849a6776171454eba547cf7ae768209f4584efd62e6ccf23634a59e", "0xa6697531d4f26aba58a34e1fcfa202b8e20fa739997f16b983c0a8a123f4da1b", "0x83afd0b3eb6af0acc9ed9a351082160944ccd781ba5dcc409d8cbe5723eb644d", "0x167d3e9c1016ab80e58802ca9da10ce5c6a0f4debc46a2e7a2cd9e56899a4fb5"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6606931 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6734533 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_mortgageManager", value: 4}, {type: "address", name: "_nanoLoanEngine", value: 5}, {type: "address", name: "_landMarket", value: 6}, {type: "address", name: "_manaOracle", value: 7}, {type: "address", name: "_tokenConverter", value: 8}, {type: "address", name: "_converterRamp", value: 9}], name: "MortgageHelper", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "rcn", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rcn()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "marginSpend", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "marginSpend()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxSpend", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxSpend()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "landMarket", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "landMarket()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "requiredTotal", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "requiredTotal()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "mortgageManager", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "mortgageManager()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "nanoLoanEngine", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "nanoLoanEngine()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "manaOracle", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "manaOracle()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "rebuyThreshold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "rebuyThreshold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokenConverter", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenConverter()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "converterRamp", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "converterRamp()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "mana", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "mana()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MANA_CURRENCY", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MANA_CURRENCY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "MortgageHelper", function( accounts ) {

	it( "TEST: MortgageHelper( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6606931", timeStamp: "1540838974", hash: "0x8ed407a0d73d5b07d9bccb26bcdd5e03053fcd5152c17895abe33cf4f26d2ecb", nonce: "49", blockHash: "0x981ccb6d3fdd0b673615b3ea10870220e93170dd419366a33e67c4d20dd11da7", transactionIndex: "101", from: "0x06779a9848e5df60ce0f5f63f88c5310c4c7289c", to: 0, value: "0", gas: "2426431", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xec99c8540000000000000000000000009abf1295086afa0e49c60e95c437aa400c5333b8000000000000000000000000ba5a17f8ad40dc2c955d95c0547f3e6318bd72e70000000000000000000000008e5660b4ab70168b5a6feea0e0315cb49c8cd5390000000000000000000000002aaf69a2df2828b55fa4a5e30ee8c3c7cd9e5d5b000000000000000000000000223fe3c346bf47334eaccf1400717cb00d40337200000000000000000000000056783153d0a8ccb009dcb79df5337835ed1a9d6c", contractAddress: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", cumulativeGasUsed: "7913963", gasUsed: "2426431", confirmations: "1126652"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_mortgageManager", value: addressList[4]}, {type: "address", name: "_nanoLoanEngine", value: addressList[5]}, {type: "address", name: "_landMarket", value: addressList[6]}, {type: "address", name: "_manaOracle", value: addressList[7]}, {type: "address", name: "_tokenConverter", value: addressList[8]}, {type: "address", name: "_converterRamp", value: addressList[9]}], name: "MortgageHelper", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = MortgageHelper.new( addressList[4], addressList[5], addressList[6], addressList[7], addressList[8], addressList[9], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540838974 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = MortgageHelper.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetRebuyThreshold", type: "event"} ;
		console.error( "eventCallOriginal[0,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetRebuyThreshold", events: [{name: "_prev", type: "uint256", value: "0"}, {name: "_new", type: "uint256", value: "1000000000000000"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetMarginSpend", type: "event"} ;
		console.error( "eventCallOriginal[0,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetMarginSpend", events: [{name: "_prev", type: "uint256", value: "0"}, {name: "_new", type: "uint256", value: "500"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetMaxSpend", type: "event"} ;
		console.error( "eventCallOriginal[0,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetMaxSpend", events: [{name: "_prev", type: "uint256", value: "0"}, {name: "_new", type: "uint256", value: "300"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetRequiredTotal", type: "event"} ;
		console.error( "eventCallOriginal[0,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetRequiredTotal", events: [{name: "_prev", type: "uint256", value: "0"}, {name: "_new", type: "uint256", value: "105"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "address"}, {indexed: false, name: "_new", type: "address"}], name: "SetTokenConverter", type: "event"} ;
		console.error( "eventCallOriginal[0,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetTokenConverter", events: [{name: "_prev", type: "address", value: "0x223fe3c346bf47334eaccf1400717cb00d403372"}, {name: "_new", type: "address", value: "0x223fe3c346bf47334eaccf1400717cb00d403372"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "address"}, {indexed: false, name: "_new", type: "address"}], name: "SetConverterRamp", type: "event"} ;
		console.error( "eventCallOriginal[0,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetConverterRamp", events: [{name: "_prev", type: "address", value: "0x56783153d0a8ccb009dcb79df5337835ed1a9d6c"}, {name: "_new", type: "address", value: "0x56783153d0a8ccb009dcb79df5337835ed1a9d6c"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_manaOracle", type: "address"}], name: "SetManaOracle", type: "event"} ;
		console.error( "eventCallOriginal[0,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetManaOracle", events: [{name: "_manaOracle", type: "address", value: "0x2aaf69a2df2828b55fa4a5e30ee8c3c7cd9e5d5b"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_engine", type: "address"}], name: "SetEngine", type: "event"} ;
		console.error( "eventCallOriginal[0,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetEngine", events: [{name: "_engine", type: "address", value: "0xba5a17f8ad40dc2c955d95c0547f3e6318bd72e7"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_landMarket", type: "address"}], name: "SetLandMarket", type: "event"} ;
		console.error( "eventCallOriginal[0,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetLandMarket", events: [{name: "_landMarket", type: "address", value: "0x8e5660b4ab70168b5a6feea0e0315cb49c8cd539"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_mortgageManager", type: "address"}], name: "SetMortgageManager", type: "event"} ;
		console.error( "eventCallOriginal[0,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetMortgageManager", events: [{name: "_mortgageManager", type: "address", value: "0x9abf1295086afa0e49c60e95c437aa400c5333b8"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_owner", type: "address"}], name: "SetOwner", type: "event"} ;
		console.error( "eventCallOriginal[0,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetOwner", events: [{name: "_owner", type: "address", value: "0x06779a9848e5df60ce0f5f63f88c5310c4c7289c"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[0,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "214758652459631" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9100000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6611591", timeStamp: "1540904632", hash: "0x2f436228bf21fbde8daec5700d62d79c57a7cb8bc0bad8f13939845dbb6f4d79", nonce: "45", blockHash: "0x7192d9fa649a8d5352f649a4b0a07f86a9fa4ad26a9debf5cc0bbfd992f117a2", transactionIndex: "59", from: "0x7d7cfefb91c8bb2c330ec66d99c225d47c9131c0", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1216035", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000001ed4fde7a2236b0000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000076a70000000000000000000000000000000000000000000000000000000000002398800000000000000000000000000000000000000000000000000000016761ea3c000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffbbffffffffffffffffffffffffffffff95000000000000000000000000000000000000000000000000000000000000001ce012ec522efedb7e939da062161ba265e6986761dc43e9b387858c0d48fcb4dd496e8740313c28814334eb72d79ac84ae7b6d2edab6e3e729762dac35551fcf00000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4195228", gasUsed: "780690", confirmations: "1121992"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9100000000000000000000","15552000000000","10367989632000","7776000","2332800","1543536000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xe012ec522efedb7e939da062161ba265e6986761dc43e9b387858c0d48fcb4dd"}, {type: "bytes32", name: "s", value: "0x496e8740313c28814334eb72d79ac84ae7b6d2edab6e3e729762dac35551fcf0"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9100000000000000000000","15552000000000","10367989632000","7776000","2332800","1543536000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907830130783715016748523948110702552891260821", "28", "0xe012ec522efedb7e939da062161ba265e6986761dc43e9b387858c0d48fcb4dd", "0x496e8740313c28814334eb72d79ac84ae7b6d2edab6e3e729762dac35551fcf0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540904632 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x7d7cfefb91c8bb2c330ec66d99c225d47c9131c0"}, {name: "loanId", type: "uint256", value: "322"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {name: "mortgageId", type: "uint256", value: "1"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "9060197675439861" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9500000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6612010", timeStamp: "1540910427", hash: "0xb7522ee0099c8a5f6ae6fddc537097b4a3320a576d0d3c57311555c828f1f3b5", nonce: "48", blockHash: "0x1ec8f2426332ee9c832dfc46121894a7c01801aae40d3f85a66058cbba0f4f98", transactionIndex: "136", from: "0x7d7cfefb91c8bb2c330ec66d99c225d47c9131c0", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1216035", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c000000000000000000000000000000000000000000000202fefbf2d7c2f0000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc000000000000000000000000000000000000000000000000000000000000093a80000000000000000000000000000000000000000000000000000000000002a3000000000000000000000000000000000000000000000000000000016761ea3c000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffbeffffffffffffffffffffffffffffffe5000000000000000000000000000000000000000000000000000000000000001ca96e83e362700b8d5a2cc56f82de42f6e8c5b7a06e30d3b8043f65948c41f0b22451155eeb13c40c833c6b267306b2980a13fe887a9c950ee1f31477d68bf3910000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7309922", gasUsed: "780690", confirmations: "1121573"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9500000000000000000000","15552000000000","10367989632000","604800","172800","1543536000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907831151630815779563914338234524848195895269"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xa96e83e362700b8d5a2cc56f82de42f6e8c5b7a06e30d3b8043f65948c41f0b2"}, {type: "bytes32", name: "s", value: "0x2451155eeb13c40c833c6b267306b2980a13fe887a9c950ee1f31477d68bf391"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9500000000000000000000","15552000000000","10367989632000","604800","172800","1543536000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907831151630815779563914338234524848195895269", "28", "0xa96e83e362700b8d5a2cc56f82de42f6e8c5b7a06e30d3b8043f65948c41f0b2", "0x2451155eeb13c40c833c6b267306b2980a13fe887a9c950ee1f31477d68bf391", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540910427 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x7d7cfefb91c8bb2c330ec66d99c225d47c9131c0"}, {name: "loanId", type: "uint256", value: "324"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907831151630815779563914338234524848195895269"}, {name: "mortgageId", type: "uint256", value: "2"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "9060197675439861" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9200000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6612728", timeStamp: "1540920994", hash: "0xf4bc75404cb3a3d86e67a048d032f9c3b645304f285a432103fbcf52a44ee735", nonce: "8", blockHash: "0x3cda3af790bc52404322245d37e42e46a2bcb43440f758b42ead46928acfb2e2", transactionIndex: "96", from: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191903", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000001f2bba5d84f99c0000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000001518000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016761ea3c00000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000029ffffffffffffffffffffffffffffffa5000000000000000000000000000000000000000000000000000000000000001cf2d80dd71eb583b2e2fcacd385870950abf9f0a6f24b64452a435e027101605a0c505e19d64f0feb63941299bc4d3e68bebfb0daba01fff4b00e5c170e0cd9990000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5622954", gasUsed: "764602", confirmations: "1120855"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9200000000000000000000","15552000000000","10367989632000","86400","0","1543536000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "14291859410679415465461733512134264881061"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xf2d80dd71eb583b2e2fcacd385870950abf9f0a6f24b64452a435e027101605a"}, {type: "bytes32", name: "s", value: "0x0c505e19d64f0feb63941299bc4d3e68bebfb0daba01fff4b00e5c170e0cd999"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9200000000000000000000","15552000000000","10367989632000","86400","0","1543536000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "14291859410679415465461733512134264881061", "28", "0xf2d80dd71eb583b2e2fcacd385870950abf9f0a6f24b64452a435e027101605a", "0x0c505e19d64f0feb63941299bc4d3e68bebfb0daba01fff4b00e5c170e0cd999", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540920994 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c"}, {name: "loanId", type: "uint256", value: "326"}, {name: "landId", type: "uint256", value: "14291859410679415465461733512134264881061"}, {name: "mortgageId", type: "uint256", value: "3"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "40998713800000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setRequiredTotal( \"110\" )", async function( ) {
		const txOriginal = {blockNumber: "6612768", timeStamp: "1540921677", hash: "0x87d4a9b29ef9805765c574508eff445f8e912161214d2e9992662257148ac2fb", nonce: "54", blockHash: "0x7d72b9ac44506beabf76bd256b6bebf59890c37ed25a0c7e5bbeac30e2b52034", transactionIndex: "91", from: "0x06779a9848e5df60ce0f5f63f88c5310c4c7289c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "42880", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x1348ab3a000000000000000000000000000000000000000000000000000000000000006e", contractAddress: "", cumulativeGasUsed: "7845130", gasUsed: "28587", confirmations: "1120815"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_requiredTotal", value: "110"}], name: "setRequiredTotal", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRequiredTotal(uint256)" ]( "110", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540921677 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetRequiredTotal", type: "event"} ;
		console.error( "eventCallOriginal[4,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetRequiredTotal", events: [{name: "_prev", type: "uint256", value: "105"}, {name: "_new", type: "uint256", value: "110"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[4,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "214758652459631" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9499000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6612789", timeStamp: "1540922059", hash: "0xadd7351216cff59b1659f8ab3704adc26e59cf4f6d41d0612eef9017768f0210", nonce: "10", blockHash: "0xc7539edb2a8c76771021d5b1f8e7282448c5721060d57aadbdbd97f645bd041a", transactionIndex: "90", from: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191807", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c000000000000000000000000000000000000000000000202f11b3c241b8c000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000001518000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016761ea3c00000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000029ffffffffffffffffffffffffffffffa5000000000000000000000000000000000000000000000000000000000000001c2806b5ed1c793fa3ede9858439bdc7b46fe494fb9128dbf838b82b3bd3454c195e00ce04ad7f1e6fffd820980ce554e348154f45ed8b4203709ce929809ceb450000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3061694", gasUsed: "764538", confirmations: "1120794"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9499000000000000000000","15552000000000","10367989632000","86400","0","1543536000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "14291859410679415465461733512134264881061"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x2806b5ed1c793fa3ede9858439bdc7b46fe494fb9128dbf838b82b3bd3454c19"}, {type: "bytes32", name: "s", value: "0x5e00ce04ad7f1e6fffd820980ce554e348154f45ed8b4203709ce929809ceb45"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9499000000000000000000","15552000000000","10367989632000","86400","0","1543536000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "14291859410679415465461733512134264881061", "28", "0x2806b5ed1c793fa3ede9858439bdc7b46fe494fb9128dbf838b82b3bd3454c19", "0x5e00ce04ad7f1e6fffd820980ce554e348154f45ed8b4203709ce929809ceb45", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540922059 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c"}, {name: "loanId", type: "uint256", value: "328"}, {name: "landId", type: "uint256", value: "14291859410679415465461733512134264881061"}, {name: "mortgageId", type: "uint256", value: "4"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "40998713800000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenConverter( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6612970", timeStamp: "1540924677", hash: "0xb00bdfb2c706efd9fc2bd2cb30609ca2534b6f47cd1b3b01736eb63da4fe8442", nonce: "62", blockHash: "0x7d379b3e68fb6fead0e7b1b0c958bc95f8782683b70ba3a667ebb1870e6c6d23", transactionIndex: "128", from: "0x06779a9848e5df60ce0f5f63f88c5310c4c7289c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "47400", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xc56aa1660000000000000000000000003b81db7c9fe71a2c6d78f9ae2fe4df4c92272622", contractAddress: "", cumulativeGasUsed: "5258317", gasUsed: "31600", confirmations: "1120613"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_tokenConverter", value: addressList[12]}], name: "setTokenConverter", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenConverter(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540924677 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "address"}, {indexed: false, name: "_new", type: "address"}], name: "SetTokenConverter", type: "event"} ;
		console.error( "eventCallOriginal[6,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetTokenConverter", events: [{name: "_prev", type: "address", value: "0x223fe3c346bf47334eaccf1400717cb00d403372"}, {name: "_new", type: "address", value: "0x3b81db7c9fe71a2c6d78f9ae2fe4df4c92272622"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[6,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "214758652459631" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setRequiredTotal( \"105\" )", async function( ) {
		const txOriginal = {blockNumber: "6612999", timeStamp: "1540925096", hash: "0x2b08dfea0dbc5c57397ae2fcd5051d35d6fa8c50a40e1a062b83284a7d2cd4f1", nonce: "63", blockHash: "0xd905e14edf53cab216f8b61514cc46c70fa9293716860a206500b41733849fb7", transactionIndex: "43", from: "0x06779a9848e5df60ce0f5f63f88c5310c4c7289c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "42880", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1348ab3a0000000000000000000000000000000000000000000000000000000000000069", contractAddress: "", cumulativeGasUsed: "2247512", gasUsed: "28587", confirmations: "1120584"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_requiredTotal", value: "105"}], name: "setRequiredTotal", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setRequiredTotal(uint256)" ]( "105", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540925096 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetRequiredTotal", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetRequiredTotal", events: [{name: "_prev", type: "uint256", value: "110"}, {name: "_new", type: "uint256", value: "105"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "214758652459631" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9495000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6613007", timeStamp: "1540925199", hash: "0xdd99168dd66f84c748ac1248489191a5909ee2e9442a5b75ae249e0bbe78c0a2", nonce: "12", blockHash: "0xaa7752eba3af4c6fe63c8c9a93a29ade48b56851974d8afb1d0e96a2df4412e9", transactionIndex: "71", from: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193343", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c000000000000000000000000000000000000000000000202b99861557dfc000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000001518000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000016761ea3c000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffbbffffffffffffffffffffffffffffff95000000000000000000000000000000000000000000000000000000000000001c417deef24f6554e9e447e9649d561c42873fad35056f5e766e8756ece49a2ff5282d8a157b1024a4a724da547e723cf7be127b1a4a7be4f6119ed3fd990b2df50000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4244237", gasUsed: "765562", confirmations: "1120576"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9495000000000000000000","15552000000000","10367989632000","86400","0","1543536000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x417deef24f6554e9e447e9649d561c42873fad35056f5e766e8756ece49a2ff5"}, {type: "bytes32", name: "s", value: "0x282d8a157b1024a4a724da547e723cf7be127b1a4a7be4f6119ed3fd990b2df5"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9495000000000000000000","15552000000000","10367989632000","86400","0","1543536000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907830130783715016748523948110702552891260821", "28", "0x417deef24f6554e9e447e9649d561c42873fad35056f5e766e8756ece49a2ff5", "0x282d8a157b1024a4a724da547e723cf7be127b1a4a7be4f6119ed3fd990b2df5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540925199 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c"}, {name: "loanId", type: "uint256", value: "329"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {name: "mortgageId", type: "uint256", value: "5"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "40998713800000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: pay( addressList[5], \"329\", \"7500000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6613043", timeStamp: "1540925814", hash: "0xda6a88676e68c4d4e343624aeedbdfa6f727b14e07e7b7cd3ae91d93396099e6", nonce: "13", blockHash: "0x43ac91cee54c8021d34e42b3b79eaa938eda2915617e506b7a4e52e60605423b", transactionIndex: "148", from: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "600000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x5f065346000000000000000000000000ba5a17f8ad40dc2c955d95c0547f3e6318bd72e70000000000000000000000000000000000000000000000000000000000000149000000000000000000000000000000000000000000000028a857425466f80000", contractAddress: "", cumulativeGasUsed: "4922597", gasUsed: "591147", confirmations: "1120540"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "engine", value: addressList[5]}, {type: "uint256", name: "loan", value: "329"}, {type: "uint256", name: "amount", value: "750000000000000000000"}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(address,uint256,uint256)" ]( addressList[5], "329", "750000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540925814 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "40998713800000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: pay( addressList[5], \"329\", \"1000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6613062", timeStamp: "1540926035", hash: "0x8f2a1938878d43d9fad9cc7f220f19fa8fe43ea98e9f2dd25c6ad7896010a108", nonce: "14", blockHash: "0x09d87f22cc8b5751b0745e2eb23bddeaba3762d5d386cdda895010fe56547fa0", transactionIndex: "58", from: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "2000000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x5f065346000000000000000000000000ba5a17f8ad40dc2c955d95c0547f3e6318bd72e700000000000000000000000000000000000000000000000000000000000001490000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "6112842", gasUsed: "1889385", confirmations: "1120521"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "engine", value: addressList[5]}, {type: "uint256", name: "loan", value: "329"}, {type: "uint256", name: "amount", value: "100000000000000000000"}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(address,uint256,uint256)" ]( addressList[5], "329", "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540926035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "40998713800000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: setMaxSpend( \"1000\" )", async function( ) {
		const txOriginal = {blockNumber: "6613154", timeStamp: "1540927351", hash: "0x75c2f68fc0993db3433ce7b7326dca84d0c29d5ed4863fce278308c4878c1fa1", nonce: "64", blockHash: "0x99f595cde99ff579be409373555a114d21028aa9f881ee7ae0e4a422c373dbeb", transactionIndex: "51", from: "0x06779a9848e5df60ce0f5f63f88c5310c4c7289c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "43207", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x62d2ecb900000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3648824", gasUsed: "28805", confirmations: "1120429"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_maxSpend", value: "1000"}], name: "setMaxSpend", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMaxSpend(uint256)" ]( "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540927351 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetMaxSpend", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetMaxSpend", events: [{name: "_prev", type: "uint256", value: "300"}, {name: "_new", type: "uint256", value: "1000"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "214758652459631" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: pay( addressList[5], \"329\", \"1000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6613170", timeStamp: "1540927659", hash: "0x0a41ca5dd5919b3763f0f6d2a25fb06656003e8c4581b2b290d77e93bbfe1e05", nonce: "15", blockHash: "0x8808fc83d7446af3aa9ad78691d9495f600b03b140d8ceeef902c8cb76906868", transactionIndex: "31", from: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "2740608", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x5f065346000000000000000000000000ba5a17f8ad40dc2c955d95c0547f3e6318bd72e700000000000000000000000000000000000000000000000000000000000001490000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "3695978", gasUsed: "1574084", confirmations: "1120413"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "engine", value: addressList[5]}, {type: "uint256", name: "loan", value: "329"}, {type: "uint256", name: "amount", value: "100000000000000000000"}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(address,uint256,uint256)" ]( addressList[5], "329", "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540927659 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "engine", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "PaidLoan", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PaidLoan", events: [{name: "engine", type: "address", value: "0xba5a17f8ad40dc2c955d95c0547f3e6318bd72e7"}, {name: "loanId", type: "uint256", value: "329"}, {name: "amount", type: "uint256", value: "100000000000000000000"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "40998713800000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: pay( addressList[5], \"329\", \"6000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6613237", timeStamp: "1540928525", hash: "0x4e47c17345f01810c598bfe9acb7442b6b356599a47541896e6638420a8b1a26", nonce: "16", blockHash: "0x6851150bbb08a9e9a98130b7b9e8f5f6ae6526d744e3b136f029c14e0789b3c4", transactionIndex: "52", from: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "2813673", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x5f065346000000000000000000000000ba5a17f8ad40dc2c955d95c0547f3e6318bd72e7000000000000000000000000000000000000000000000000000000000000014900000000000000000000000000000000000000000000014542ba12a337c00000", contractAddress: "", cumulativeGasUsed: "6313481", gasUsed: "1622034", confirmations: "1120346"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "engine", value: addressList[5]}, {type: "uint256", name: "loan", value: "329"}, {type: "uint256", name: "amount", value: "6000000000000000000000"}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(address,uint256,uint256)" ]( addressList[5], "329", "6000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540928525 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "engine", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "PaidLoan", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PaidLoan", events: [{name: "engine", type: "address", value: "0xba5a17f8ad40dc2c955d95c0547f3e6318bd72e7"}, {name: "loanId", type: "uint256", value: "329"}, {name: "amount", type: "uint256", value: "6000000000000000000000"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "40998713800000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: pay( addressList[5], \"329\", \"4000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6613329", timeStamp: "1540929862", hash: "0x8eabf882054a100554228f3d368fcb46ea29ba0411bfd74c9398f5e8e82a9a01", nonce: "17", blockHash: "0xa1ea995e593d0079327f9962acb367915c986be391c749b05f1beba90cc1cbac", transactionIndex: "56", from: "0xa5fa2f5ef3e1f4acaf99de54567388c180d69f8c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "4167912", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x5f065346000000000000000000000000ba5a17f8ad40dc2c955d95c0547f3e6318bd72e700000000000000000000000000000000000000000000000000000000000001490000000000000000000000000000000000000000000000d8d726b7177a800000", contractAddress: "", cumulativeGasUsed: "6021322", gasUsed: "2315752", confirmations: "1120254"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "engine", value: addressList[5]}, {type: "uint256", name: "loan", value: "329"}, {type: "uint256", name: "amount", value: "4000000000000000000000"}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(address,uint256,uint256)" ]( addressList[5], "329", "4000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540929862 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "engine", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "PaidLoan", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PaidLoan", events: [{name: "engine", type: "address", value: "0xba5a17f8ad40dc2c955d95c0547f3e6318bd72e7"}, {name: "loanId", type: "uint256", value: "329"}, {name: "amount", type: "uint256", value: "4000000000000000000000"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "40998713800000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"1000000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6624869", timeStamp: "1541093088", hash: "0x5838df673fade20631574e968a8b1b2717103f1f79d780a8d48c9132d91bbe3c", nonce: "3", blockHash: "0x225854d98c67c6991135d12fe2737a92da8cffcd6d37669fedc8ba3565815a24", transactionIndex: "46", from: "0xaf592460d6a44517aba2fb0bcb02ee8f4103b502", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193247", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000003635c9adc5dea0000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000000151800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001676c36f4000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffbbffffffffffffffffffffffffffffff95000000000000000000000000000000000000000000000000000000000000001b0e78312cded35ef2eb50d4d3925b7c938340fa513aeacf56cae7fb3c97eed48e43d06a30c8be7309de51b701d1a3ea6d806e022ec068d9c9454dc5ced4e35a2b0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3920243", gasUsed: "765498", confirmations: "1108714"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["1000000000000000000000","15552000000000","10367989632000","86400","0","1543708800000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x0e78312cded35ef2eb50d4d3925b7c938340fa513aeacf56cae7fb3c97eed48e"}, {type: "bytes32", name: "s", value: "0x43d06a30c8be7309de51b701d1a3ea6d806e022ec068d9c9454dc5ced4e35a2b"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["1000000000000000000000","15552000000000","10367989632000","86400","0","1543708800000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907830130783715016748523948110702552891260821", "27", "0x0e78312cded35ef2eb50d4d3925b7c938340fa513aeacf56cae7fb3c97eed48e", "0x43d06a30c8be7309de51b701d1a3ea6d806e022ec068d9c9454dc5ced4e35a2b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541093088 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xaf592460d6a44517aba2fb0bcb02ee8f4103b502"}, {name: "loanId", type: "uint256", value: "348"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {name: "mortgageId", type: "uint256", value: "6"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "174047162416805800" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"1000000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6624971", timeStamp: "1541094579", hash: "0x94a1e81778f284b912cad624c06465a56a4d303b16b6ab19083b18cda7926664", nonce: "5", blockHash: "0x38db3e194684f6893f0236f30d4ecbda3e0f54879ccf4fc738765e221f6e01f9", transactionIndex: "136", from: "0xaf592460d6a44517aba2fb0bcb02ee8f4103b502", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193247", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000003635c9adc5dea0000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc000000000000000000000000000000000000000000000000000000000000015180000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000167715d50000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffbbffffffffffffffffffffffffffffff95000000000000000000000000000000000000000000000000000000000000001cccc6d5e40d43ac17e6bfb9e0de7841d717da79510995f3f7288d1b08f515ea3a5f0cbc33bdc95a517a162f208d899dd07aa20fa368f6297b7f79187eb3489a560000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6518404", gasUsed: "765498", confirmations: "1108612"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["1000000000000000000000","15552000000000","10367989632000","86400","0","1543795200000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xccc6d5e40d43ac17e6bfb9e0de7841d717da79510995f3f7288d1b08f515ea3a"}, {type: "bytes32", name: "s", value: "0x5f0cbc33bdc95a517a162f208d899dd07aa20fa368f6297b7f79187eb3489a56"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["1000000000000000000000","15552000000000","10367989632000","86400","0","1543795200000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907830130783715016748523948110702552891260821", "28", "0xccc6d5e40d43ac17e6bfb9e0de7841d717da79510995f3f7288d1b08f515ea3a", "0x5f0cbc33bdc95a517a162f208d899dd07aa20fa368f6297b7f79187eb3489a56", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541094579 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xaf592460d6a44517aba2fb0bcb02ee8f4103b502"}, {name: "loanId", type: "uint256", value: "349"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {name: "mortgageId", type: "uint256", value: "7"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "174047162416805800" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"1000000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6624999", timeStamp: "1541094931", hash: "0xdc57c48e0c7beb47bce9ffd3a227899ed51419ddfc8634f3cc095dd7e3b1cad9", nonce: "7", blockHash: "0xac3d496ebdce1db0b1314d94fdb2b6915962f337e46a667ca06d6dddee18521f", transactionIndex: "53", from: "0xaf592460d6a44517aba2fb0bcb02ee8f4103b502", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193151", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000003635c9adc5dea0000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000000151800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001677683ac000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffbbffffffffffffffffffffffffffffff95000000000000000000000000000000000000000000000000000000000000001b8a13bfb8fc79f30a90009f999bf399f3e7be752d807891b8e13ce68e66463f5830f4e7632df3e7a6f8e3050d2d9532fc853cdde9ffcdebdd0e1b7d43304b57a30000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3875332", gasUsed: "765434", confirmations: "1108584"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["1000000000000000000000","15552000000000","10367989632000","86400","0","1543881600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x8a13bfb8fc79f30a90009f999bf399f3e7be752d807891b8e13ce68e66463f58"}, {type: "bytes32", name: "s", value: "0x30f4e7632df3e7a6f8e3050d2d9532fc853cdde9ffcdebdd0e1b7d43304b57a3"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["1000000000000000000000","15552000000000","10367989632000","86400","0","1543881600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907830130783715016748523948110702552891260821", "27", "0x8a13bfb8fc79f30a90009f999bf399f3e7be752d807891b8e13ce68e66463f58", "0x30f4e7632df3e7a6f8e3050d2d9532fc853cdde9ffcdebdd0e1b7d43304b57a3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541094931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xaf592460d6a44517aba2fb0bcb02ee8f4103b502"}, {name: "loanId", type: "uint256", value: "351"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907830130783715016748523948110702552891260821"}, {name: "mortgageId", type: "uint256", value: "8"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "174047162416805800" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: pay( addressList[5], \"351\", \"1001000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6625150", timeStamp: "1541097258", hash: "0x34822efe0fdf7a9c193bc270312f8e999f6eb6dad67f8958741528145d8c1075", nonce: "8", blockHash: "0x2a890062dc155a7356a584f54c41700c1b1c22e42dbe92c8895bf0e39ac4ed5b", transactionIndex: "107", from: "0xaf592460d6a44517aba2fb0bcb02ee8f4103b502", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "2740608", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x5f065346000000000000000000000000ba5a17f8ad40dc2c955d95c0547f3e6318bd72e7000000000000000000000000000000000000000000000000000000000000015f00000000000000000000000000000000000000000000003643aa647986040000", contractAddress: "", cumulativeGasUsed: "6499790", gasUsed: "1432447", confirmations: "1108433"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "engine", value: addressList[5]}, {type: "uint256", name: "loan", value: "351"}, {type: "uint256", name: "amount", value: "1001000000000000000000"}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(address,uint256,uint256)" ]( addressList[5], "351", "1001000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541097258 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "engine", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "PaidLoan", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PaidLoan", events: [{name: "engine", type: "address", value: "0xba5a17f8ad40dc2c955d95c0547f3e6318bd72e7"}, {name: "loanId", type: "uint256", value: "351"}, {name: "amount", type: "uint256", value: "1001000000000000000000"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "174047162416805800" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: pay( addressList[5], \"351\", \"1000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6625218", timeStamp: "1541098133", hash: "0x16027741bd81809d4dff94ad8f2eb4eb4ba89ea43cef35153dc956e467b16867", nonce: "9", blockHash: "0x411516d16c222f0418a855a2aa726c41e9aa8de6c5b1223242b7a2d19414538d", transactionIndex: "71", from: "0xaf592460d6a44517aba2fb0bcb02ee8f4103b502", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "4145055", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x5f065346000000000000000000000000ba5a17f8ad40dc2c955d95c0547f3e6318bd72e7000000000000000000000000000000000000000000000000000000000000015f0000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "5588763", gasUsed: "2285752", confirmations: "1108365"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "engine", value: addressList[5]}, {type: "uint256", name: "loan", value: "351"}, {type: "uint256", name: "amount", value: "100000000000000000000"}], name: "pay", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pay(address,uint256,uint256)" ]( addressList[5], "351", "100000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541098133 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "engine", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "amount", type: "uint256"}], name: "PaidLoan", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PaidLoan", events: [{name: "engine", type: "address", value: "0xba5a17f8ad40dc2c955d95c0547f3e6318bd72e7"}, {name: "loanId", type: "uint256", value: "351"}, {name: "amount", type: "uint256", value: "100000000000000000000"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "174047162416805800" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: setMarginSpend( \"3000\" )", async function( ) {
		const txOriginal = {blockNumber: "6625246", timeStamp: "1541098428", hash: "0xe4bfc5c27021476f9318c798042171e6975f8514c0ed4bfc050a04f2635bf435", nonce: "65", blockHash: "0x2457a90067c8bf4e32b878fc0ec74bfd1fda2ae13409e3962c9f7bfe7bec3b9c", transactionIndex: "54", from: "0x06779a9848e5df60ce0f5f63f88c5310c4c7289c", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "43801", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xffe496f20000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "6305514", gasUsed: "29201", confirmations: "1108337"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_marginSpend", value: "3000"}], name: "setMarginSpend", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setMarginSpend(uint256)" ]( "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541098428 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_prev", type: "uint256"}, {indexed: false, name: "_new", type: "uint256"}], name: "SetMarginSpend", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetMarginSpend", events: [{name: "_prev", type: "uint256", value: "500"}, {name: "_new", type: "uint256", value: "3000"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "214758652459631" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9500000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6649130", timeStamp: "1541437560", hash: "0xefb8c16f4e640729e39a75c0ff7e7aec0e22e307f648e1c7a21dd699d6dfef0a", nonce: "2", blockHash: "0xf63107ff55a5587f808d81be2cb9f0f6843f22badcc3c86ba9c226c6a004912b", transactionIndex: "16", from: "0xea4e02d04e2209468e9a2d97431cea4833884034", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "3000000", gasPrice: "11000000000", isError: "1", txreceipt_status: "0", input: "0xacddb63c000000000000000000000000000000000000000000000202fefbf2d7c2f0000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000004f1a00000000000000000000000000000000000000000000000000000000000017bb000000000000000000000000000000000000000000000000000000016780d064000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffa5ffffffffffffffffffffffffffffffa5000000000000000000000000000000000000000000000000000000000000001bb7499a9c5b8097428af4aa65152dddf810346638896afd13b6eff8ef57f0616735f5d135733c12e02d33093da5876c18b2b84d84a70669607da142e8de603ba70000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1518111", gasUsed: "432743", confirmations: "1084453"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9500000000000000000000","15552000000000","10367989632000","5184000","1555200","1544054400000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907822644571642756102327753869339053990608805"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xb7499a9c5b8097428af4aa65152dddf810346638896afd13b6eff8ef57f06167"}, {type: "bytes32", name: "s", value: "0x35f5d135733c12e02d33093da5876c18b2b84d84a70669607da142e8de603ba7"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9500000000000000000000","15552000000000","10367989632000","5184000","1555200","1544054400000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907822644571642756102327753869339053990608805", "27", "0xb7499a9c5b8097428af4aa65152dddf810346638896afd13b6eff8ef57f06167", "0x35f5d135733c12e02d33093da5876c18b2b84d84a70669607da142e8de603ba7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541437560 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9405000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6649190", timeStamp: "1541438508", hash: "0x38eb4ccad662fff6d3807ee2a9f382c3f62dea8d0410955732c9ae8e378be484", nonce: "5", blockHash: "0xe9a05715034da878ec2cceb12d81d4c4d72dac6b07156344e0aaa9c698347847", transactionIndex: "50", from: "0xea4e02d04e2209468e9a2d97431cea4833884034", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1216035", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000001fdd898262ca4d4000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000076a70000000000000000000000000000000000000000000000000000000000002398800000000000000000000000000000000000000000000000000000016780d064000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffa5ffffffffffffffffffffffffffffffa5000000000000000000000000000000000000000000000000000000000000001c72caa0bd4e72c3e93b23bea153884d3059dc73ae7da7afb5c36bd29c73a2df4f143e71a2d02ccca10ac266a39321f0d85d7b3a1d2e2999a7ce73ac610c82dcb90000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4711844", gasUsed: "780690", confirmations: "1084393"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9405000000000000000000","15552000000000","10367989632000","7776000","2332800","1544054400000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907822644571642756102327753869339053990608805"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x72caa0bd4e72c3e93b23bea153884d3059dc73ae7da7afb5c36bd29c73a2df4f"}, {type: "bytes32", name: "s", value: "0x143e71a2d02ccca10ac266a39321f0d85d7b3a1d2e2999a7ce73ac610c82dcb9"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9405000000000000000000","15552000000000","10367989632000","7776000","2332800","1544054400000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907822644571642756102327753869339053990608805", "28", "0x72caa0bd4e72c3e93b23bea153884d3059dc73ae7da7afb5c36bd29c73a2df4f", "0x143e71a2d02ccca10ac266a39321f0d85d7b3a1d2e2999a7ce73ac610c82dcb9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541438508 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xea4e02d04e2209468e9a2d97431cea4833884034"}, {name: "loanId", type: "uint256", value: "373"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907822644571642756102327753869339053990608805"}, {name: "mortgageId", type: "uint256", value: "9"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"16000000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6653202", timeStamp: "1541495118", hash: "0x6a0a415d4e0b0138684e152912e1e51363bc8bd0fdbaa4295e72632a4a229b58", nonce: "19", blockHash: "0xe9d7e21d6525fc226638bc3a0168e3e996e1bc805d04e0dca1eb337af9a1690c", transactionIndex: "72", from: "0xee8eeec3e7a5ad82827480a9e00d01b1ec0a9f3b", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191999", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000003635c9adc5dea00000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000018b8200000000000000000000000000000000000000000000000000000000000076a7000000000000000000000000000000000000000000000000000000016785f6c000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000040ffffffffffffffffffffffffffffff8a000000000000000000000000000000000000000000000000000000000000001cf0104d2bd089a92e5901a34ab48c85c4c29fd1bf2cb4d8f198357e3e3528f0ea12e5a57a4426bb9a683c0d9f291f1805ba120dbb3268a645b992558691a49ddf0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6478183", gasUsed: "764666", confirmations: "1080381"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["16000000000000000000000","15552000000000","10367989632000","25920000","7776000","1544140800000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "22118353849861000125119349483064933744522"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xf0104d2bd089a92e5901a34ab48c85c4c29fd1bf2cb4d8f198357e3e3528f0ea"}, {type: "bytes32", name: "s", value: "0x12e5a57a4426bb9a683c0d9f291f1805ba120dbb3268a645b992558691a49ddf"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["16000000000000000000000","15552000000000","10367989632000","25920000","7776000","1544140800000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "22118353849861000125119349483064933744522", "28", "0xf0104d2bd089a92e5901a34ab48c85c4c29fd1bf2cb4d8f198357e3e3528f0ea", "0x12e5a57a4426bb9a683c0d9f291f1805ba120dbb3268a645b992558691a49ddf", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541495118 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xee8eeec3e7a5ad82827480a9e00d01b1ec0a9f3b"}, {name: "loanId", type: "uint256", value: "381"}, {name: "landId", type: "uint256", value: "22118353849861000125119349483064933744522"}, {name: "mortgageId", type: "uint256", value: "10"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "106289673061647241" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"15000000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6653313", timeStamp: "1541496680", hash: "0xb61895ed128e97822fb44dadacf64ca6faac0ba5eee7baaa0ec21734ed0db9a1", nonce: "20", blockHash: "0xb28dcfcb55015c49386259433de1420878bc0846fbb11134e61e6b72ab555931", transactionIndex: "118", from: "0xee8eeec3e7a5ad82827480a9e00d01b1ec0a9f3b", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1192095", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000032d26d12e980b60000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000018b8200000000000000000000000000000000000000000000000000000000000076a7000000000000000000000000000000000000000000000000000000016785f6c00000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000003fffffffffffffffffffffffffffffff8a000000000000000000000000000000000000000000000000000000000000001b89547d04ee05aa3536457b196c1ae793cdd633993ecbb627180d3c1d50c78a8b2bd2de02c95a0867aa4ed2c567aa18b945b5aa12c2e83046dcb8b2dfc5ed12300000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5358935", gasUsed: "764730", confirmations: "1080270"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["15000000000000000000000","15552000000000","10367989632000","25920000","7776000","1544140800000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "21778071482940061661655974875633165533066"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x89547d04ee05aa3536457b196c1ae793cdd633993ecbb627180d3c1d50c78a8b"}, {type: "bytes32", name: "s", value: "0x2bd2de02c95a0867aa4ed2c567aa18b945b5aa12c2e83046dcb8b2dfc5ed1230"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["15000000000000000000000","15552000000000","10367989632000","25920000","7776000","1544140800000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "21778071482940061661655974875633165533066", "27", "0x89547d04ee05aa3536457b196c1ae793cdd633993ecbb627180d3c1d50c78a8b", "0x2bd2de02c95a0867aa4ed2c567aa18b945b5aa12c2e83046dcb8b2dfc5ed1230", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541496680 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xee8eeec3e7a5ad82827480a9e00d01b1ec0a9f3b"}, {name: "loanId", type: "uint256", value: "383"}, {name: "landId", type: "uint256", value: "21778071482940061661655974875633165533066"}, {name: "mortgageId", type: "uint256", value: "11"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "106289673061647241" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"5000000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6654609", timeStamp: "1541515491", hash: "0xb9c4941db1ddb4b07b62dbf38f139847432b2bd4e289f519e3e518efd21754ef", nonce: "37", blockHash: "0xd42302c7a4a0beda570ad1812fb77755103428cccaf474eae5f3f1347329112b", transactionIndex: "90", from: "0x981de60e39a72a1e5af2eced4106a118fc158dd2", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1190655", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000010f0cf064dd5920000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000bdd8000000000000000000000000000000000000000000000000000000167aa03440000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000001800000000000000000000000000000096000000000000000000000000000000000000000000000000000000000000001cc124369362f928bfdcde8ac0c6674bc59416cf87997779e77c41a4ef612a17526faf611b4e661f72f15eb66291504c16c5be2010329e60b3c0c022463ec3bd850000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6855720", gasUsed: "763770", confirmations: "1078974"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["5000000000000000000000","15552000000000","10367989632000","2592000","777600","1544745600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "8166776806102523123120990578362437075094"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc124369362f928bfdcde8ac0c6674bc59416cf87997779e77c41a4ef612a1752"}, {type: "bytes32", name: "s", value: "0x6faf611b4e661f72f15eb66291504c16c5be2010329e60b3c0c022463ec3bd85"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["5000000000000000000000","15552000000000","10367989632000","2592000","777600","1544745600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "8166776806102523123120990578362437075094", "28", "0xc124369362f928bfdcde8ac0c6674bc59416cf87997779e77c41a4ef612a1752", "0x6faf611b4e661f72f15eb66291504c16c5be2010329e60b3c0c022463ec3bd85", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541515491 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x981de60e39a72a1e5af2eced4106a118fc158dd2"}, {name: "loanId", type: "uint256", value: "389"}, {name: "landId", type: "uint256", value: "8166776806102523123120990578362437075094"}, {name: "mortgageId", type: "uint256", value: "12"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "3215984242103002225" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9500000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6655738", timeStamp: "1541531267", hash: "0xfe704a4994ded9d85648e932edacd3c13ead83d23dfbb95dbaf259efa1e21c91", nonce: "10", blockHash: "0xc801aeedeaccff58ac656ea8ac7bab24df973cce36a0ecea31077a60e6bad872", transactionIndex: "15", from: "0x05b8e6e10044dd5c67df3a262d2babf3ad1eefbc", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "953599", gasPrice: "14000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c000000000000000000000000000000000000000000000202fefbf2d7c2f0000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000083d6000000000000000000000000000000000000000000000000000000000000278d000000000000000000000000000000000000000000000000000000016785f6c000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000010ffffffffffffffffffffffffffffff8f000000000000000000000000000000000000000000000000000000000000001b4e081abc94a9734646fd2b448e8b4a72aac3fcf643761e4a81cebf452a65742d427512d11fb3cde5141ece6d2c525b75f1e78a9c40e02c9a06a79575406c454e0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1410146", gasUsed: "764666", confirmations: "1077845"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9500000000000000000000","15552000000000","10367989632000","8640000","2592000","1544140800000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "5784800237655953878877368326340059594639"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x4e081abc94a9734646fd2b448e8b4a72aac3fcf643761e4a81cebf452a65742d"}, {type: "bytes32", name: "s", value: "0x427512d11fb3cde5141ece6d2c525b75f1e78a9c40e02c9a06a79575406c454e"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9500000000000000000000","15552000000000","10367989632000","8640000","2592000","1544140800000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "5784800237655953878877368326340059594639", "27", "0x4e081abc94a9734646fd2b448e8b4a72aac3fcf643761e4a81cebf452a65742d", "0x427512d11fb3cde5141ece6d2c525b75f1e78a9c40e02c9a06a79575406c454e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541531267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x05b8e6e10044dd5c67df3a262d2babf3ad1eefbc"}, {name: "loanId", type: "uint256", value: "395"}, {name: "landId", type: "uint256", value: "5784800237655953878877368326340059594639"}, {name: "mortgageId", type: "uint256", value: "13"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9978000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6656259", timeStamp: "1541538591", hash: "0xa3765cc3d57ae391d887ffa531bcf1ebd70e88f2816462ca343692fe41dd20c4", nonce: "100", blockHash: "0x89744574cd072a6edd314a437546679e7136ca196d4a0bdbe476c0145feb4127", transactionIndex: "31", from: "0x7a72a2e270265adda6e038ddaa8f418e51b81ebb", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193535", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000021ce891164a4fa8000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000bdd8000000000000000000000000000000000000000000000000000000169d63214000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffd6ffffffffffffffffffffffffffffff91000000000000000000000000000000000000000000000000000000000000001bf16309d951e762ff3acdad2a899f4eb70e653630ea325446d393eeaded40c6896f7ed3c56f08ef890c8120058211fbc3114155943956a73546357b057efe4c360000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7494680", gasUsed: "765690", confirmations: "1077324"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9978000000000000000000","15552000000000","10367989632000","2592000","777600","1554076800000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907839318407621882087037459225103210632970129"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xf16309d951e762ff3acdad2a899f4eb70e653630ea325446d393eeaded40c689"}, {type: "bytes32", name: "s", value: "0x6f7ed3c56f08ef890c8120058211fbc3114155943956a73546357b057efe4c36"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9978000000000000000000","15552000000000","10367989632000","2592000","777600","1554076800000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907839318407621882087037459225103210632970129", "27", "0xf16309d951e762ff3acdad2a899f4eb70e653630ea325446d393eeaded40c689", "0x6f7ed3c56f08ef890c8120058211fbc3114155943956a73546357b057efe4c36", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541538591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x7a72a2e270265adda6e038ddaa8f418e51b81ebb"}, {name: "loanId", type: "uint256", value: "397"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907839318407621882087037459225103210632970129"}, {name: "mortgageId", type: "uint256", value: "14"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "20999873445278907" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"9900000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6661286", timeStamp: "1541609673", hash: "0x350a599b6bcf29f5927e613e6120984b1a12151028679516d3780246dedbf252", nonce: "6", blockHash: "0x947434f962a3082347fe9cc5316f10ec106d78ec13b849a5a5b75cb78b6ce609", transactionIndex: "87", from: "0xf0fc268473a4ffaf2a652c3a8510bf79b787a68f", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191999", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c000000000000000000000000000000000000000000000218ae196b8d4f30000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000bdd80000000000000000000000000000000000000000000000000000001670f847c00000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000010ffffffffffffffffffffffffffffff8f000000000000000000000000000000000000000000000000000000000000001bfe643cf3630011bc136f3c4aa00d947b6ad8dd9130d1a6afd23770c29d569540219ac4bb2b37187994eb254e3741fa7282dd21c13ab237f1770b22b3256e94390000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5560518", gasUsed: "764666", confirmations: "1072297"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["9900000000000000000000","15552000000000","10367989632000","2592000","777600","1542153600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "5784800237655953878877368326340059594639"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xfe643cf3630011bc136f3c4aa00d947b6ad8dd9130d1a6afd23770c29d569540"}, {type: "bytes32", name: "s", value: "0x219ac4bb2b37187994eb254e3741fa7282dd21c13ab237f1770b22b3256e9439"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["9900000000000000000000","15552000000000","10367989632000","2592000","777600","1542153600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "5784800237655953878877368326340059594639", "27", "0xfe643cf3630011bc136f3c4aa00d947b6ad8dd9130d1a6afd23770c29d569540", "0x219ac4bb2b37187994eb254e3741fa7282dd21c13ab237f1770b22b3256e9439", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541609673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xf0fc268473a4ffaf2a652c3a8510bf79b787a68f"}, {name: "loanId", type: "uint256", value: "403"}, {name: "landId", type: "uint256", value: "5784800237655953878877368326340059594639"}, {name: "mortgageId", type: "uint256", value: "15"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "189545598093536913" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"17399000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6661593", timeStamp: "1541614053", hash: "0x49303dd9def31730435f4e9420f275386d345b9730690c39c071926baad0f8a6", nonce: "7", blockHash: "0x76e75dfa1b7da4ebfd5a7b7735a016d7102dae2d6b2be766ec03d44b592900b9", transactionIndex: "64", from: "0xf0fc268473a4ffaf2a652c3a8510bf79b787a68f", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1190655", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000003af33a14c25ad7c000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000bdd800000000000000000000000000000000000000000000000000000016714aad80000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000007000000000000000000000000000000023000000000000000000000000000000000000000000000000000000000000001c62eb467652dfc180036e84aa87a01bddbc1e3a289692fb176e5314795204e3af6df0c89f4a9c1168e4f36296289420b92ea4e925c2265770e912f02e385e8ad10000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3612619", gasUsed: "763770", confirmations: "1071990"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["17399000000000000000000","15552000000000","10367989632000","2592000","777600","1542240000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "38111625095145107907897956032358039683107"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x62eb467652dfc180036e84aa87a01bddbc1e3a289692fb176e5314795204e3af"}, {type: "bytes32", name: "s", value: "0x6df0c89f4a9c1168e4f36296289420b92ea4e925c2265770e912f02e385e8ad1"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["17399000000000000000000","15552000000000","10367989632000","2592000","777600","1542240000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "38111625095145107907897956032358039683107", "28", "0x62eb467652dfc180036e84aa87a01bddbc1e3a289692fb176e5314795204e3af", "0x6df0c89f4a9c1168e4f36296289420b92ea4e925c2265770e912f02e385e8ad1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541614053 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xf0fc268473a4ffaf2a652c3a8510bf79b787a68f"}, {name: "loanId", type: "uint256", value: "406"}, {name: "landId", type: "uint256", value: "38111625095145107907897956032358039683107"}, {name: "mortgageId", type: "uint256", value: "16"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "189545598093536913" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"23989000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6664194", timeStamp: "1541650857", hash: "0xf1f34384533eeae73f210a9ad04ae8fbcc7f54d20079f9ad6fff0aab7b82a05a", nonce: "10", blockHash: "0x78544a7e55094a28f80e53c5913872b0ec164ef32c4e1947a8d797a8f4dda35d", transactionIndex: "61", from: "0xf0fc268473a4ffaf2a652c3a8510bf79b787a68f", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191903", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c000000000000000000000000000000000000000000000514724070d4adb4000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000004f1a00000000000000000000000000000000000000000000000000000000000017bb0000000000000000000000000000000000000000000000000000000166f5c4b0000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffd000000000000000000000000000000081000000000000000000000000000000000000000000000000000000000000001c303c8700af835f0ad365abd0a8eaa14f809d6aa2dcc01093402d33f0da5be47d302c15ae3d03804cbd545b59c30a83b6952c85b0a79de0d46ff42ef3b5faa8a00000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5868282", gasUsed: "764602", confirmations: "1069389"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["23989000000000000000000","15552000000000","10367989632000","5184000","1555200","1541721600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907836936431053435517793215602851188255490177"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x303c8700af835f0ad365abd0a8eaa14f809d6aa2dcc01093402d33f0da5be47d"}, {type: "bytes32", name: "s", value: "0x302c15ae3d03804cbd545b59c30a83b6952c85b0a79de0d46ff42ef3b5faa8a0"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["23989000000000000000000","15552000000000","10367989632000","5184000","1555200","1541721600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907836936431053435517793215602851188255490177", "28", "0x303c8700af835f0ad365abd0a8eaa14f809d6aa2dcc01093402d33f0da5be47d", "0x302c15ae3d03804cbd545b59c30a83b6952c85b0a79de0d46ff42ef3b5faa8a0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541650857 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xf0fc268473a4ffaf2a652c3a8510bf79b787a68f"}, {name: "loanId", type: "uint256", value: "410"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907836936431053435517793215602851188255490177"}, {name: "mortgageId", type: "uint256", value: "17"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "189545598093536913" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"12399000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6664319", timeStamp: "1541652425", hash: "0x7cc5ddf06dfb373e1a674ca652e6fdcf9c68e7b803fc61d1d34cd710a01d0a5d", nonce: "11", blockHash: "0x09f9db9b87288248c1f6e38f45c6b4297ef9b484a54b529696e9f1326b49cf92", transactionIndex: "83", from: "0xf0fc268473a4ffaf2a652c3a8510bf79b787a68f", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193343", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000002a026b0e748545c000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc000000000000000000000000000000000000000000000000000000000000127500000000000000000000000000000000000000000000000000000000000012750000000000000000000000000000000000000000000000000000000166faeb0c000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffd7ffffffffffffffffffffffffffffffba000000000000000000000000000000000000000000000000000000000000001be4511026d626beb50b2ff4cc00f5162988ad5ab1d04d657bb3f53f4596e379d6025efbee8553873eb011074b342a0b85a9635f953e1969e99fdbf767b5d39a9b0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3409352", gasUsed: "765562", confirmations: "1069264"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["12399000000000000000000","15552000000000","10367989632000","1209600","1209600","1541808000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907839658689988803025500922599710642401181626"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xe4511026d626beb50b2ff4cc00f5162988ad5ab1d04d657bb3f53f4596e379d6"}, {type: "bytes32", name: "s", value: "0x025efbee8553873eb011074b342a0b85a9635f953e1969e99fdbf767b5d39a9b"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["12399000000000000000000","15552000000000","10367989632000","1209600","1209600","1541808000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907839658689988803025500922599710642401181626", "27", "0xe4511026d626beb50b2ff4cc00f5162988ad5ab1d04d657bb3f53f4596e379d6", "0x025efbee8553873eb011074b342a0b85a9635f953e1969e99fdbf767b5d39a9b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541652425 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xf0fc268473a4ffaf2a652c3a8510bf79b787a68f"}, {name: "loanId", type: "uint256", value: "411"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907839658689988803025500922599710642401181626"}, {name: "mortgageId", type: "uint256", value: "18"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "189545598093536913" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"12500000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6667240", timeStamp: "1541694065", hash: "0x41ee60e4e44c28474955289b3d77e33809520b9ef6dec379b40683d96c01ce8d", nonce: "5", blockHash: "0x38dae1ee48c30bceef4014b5a8e9f7dd68f6e162f5aaff921b35774ff8c3a60b", transactionIndex: "3", from: "0x102c6eff91c6b39d52ed47ce979585e4dc889c3f", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "953599", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000002a5a058fc295ed0000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000004f1a0000000000000000000000000000000000000000000000000000000000004f1a000000000000000000000000000000000000000000000000000000016790437800000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000071fffffffffffffffffffffffffffffffc000000000000000000000000000000000000000000000000000000000000001c8b861d5dcdefaed571b25c7e91541d3eb9c3fbd239f9b014726b92b7b14961443a70ba8c392ab9bc63e053b27b6eb271861b2bc67bca981ced60583442dad6e10000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "827666", gasUsed: "764666", confirmations: "1066343"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["12500000000000000000000","15552000000000","10367989632000","5184000","5184000","1544313600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "38792189828986984834824705247221576105980"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x8b861d5dcdefaed571b25c7e91541d3eb9c3fbd239f9b014726b92b7b1496144"}, {type: "bytes32", name: "s", value: "0x3a70ba8c392ab9bc63e053b27b6eb271861b2bc67bca981ced60583442dad6e1"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["12500000000000000000000","15552000000000","10367989632000","5184000","5184000","1544313600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "38792189828986984834824705247221576105980", "28", "0x8b861d5dcdefaed571b25c7e91541d3eb9c3fbd239f9b014726b92b7b1496144", "0x3a70ba8c392ab9bc63e053b27b6eb271861b2bc67bca981ced60583442dad6e1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541694065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x102c6eff91c6b39d52ed47ce979585e4dc889c3f"}, {name: "loanId", type: "uint256", value: "417"}, {name: "landId", type: "uint256", value: "38792189828986984834824705247221576105980"}, {name: "mortgageId", type: "uint256", value: "19"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"7000000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6670554", timeStamp: "1541741146", hash: "0x4b46c50f3c3f55eaf15defc34707e5e119d81545e0de0e1e0e6431ecd3353804", nonce: "4", blockHash: "0xbdb28130c897924b4a636ffd74c7e9a1a424176e43b12b60ea07dc0a7bd596fe", transactionIndex: "11", from: "0xa2ad10f6058e80dde620617e5f84618964a01046", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "7600000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xacddb63c00000000000000000000000000000000000000000000017b7883c0691660000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000076a7000000000000000000000000000000000000000000000000000000000000239880000000000000000000000000000000000000000000000000000001679043780000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001b6580a9edfc0c377107144a68ce0a142ef194db2fc5d3eb44862eddf2ba718e3f7e90dcaf6d2bec815e5d9f5bc61ed63aa6d4430781712a07fe9b98a59dc9f7a00000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "738909", gasUsed: "466213", confirmations: "1063029"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["7000000000000000000000","15552000000000","10367989632000","7776000","2332800","1544313600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "0"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x6580a9edfc0c377107144a68ce0a142ef194db2fc5d3eb44862eddf2ba718e3f"}, {type: "bytes32", name: "s", value: "0x7e90dcaf6d2bec815e5d9f5bc61ed63aa6d4430781712a07fe9b98a59dc9f7a0"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["7000000000000000000000","15552000000000","10367989632000","7776000","2332800","1544313600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "0", "27", "0x6580a9edfc0c377107144a68ce0a142ef194db2fc5d3eb44862eddf2ba718e3f", "0x7e90dcaf6d2bec815e5d9f5bc61ed63aa6d4430781712a07fe9b98a59dc9f7a0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541741146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"7000000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6670554", timeStamp: "1541741146", hash: "0x8bbdabea35d00f81122df9fc7d40804d99c301dbd564a4be53c65fe7fdab0db1", nonce: "5", blockHash: "0xbdb28130c897924b4a636ffd74c7e9a1a424176e43b12b60ea07dc0a7bd596fe", transactionIndex: "12", from: "0xa2ad10f6058e80dde620617e5f84618964a01046", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1192095", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000017b7883c0691660000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000076a70000000000000000000000000000000000000000000000000000000000002398800000000000000000000000000000000000000000000000000000016790437800000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000005ffffffffffffffffffffffffffffff90000000000000000000000000000000000000000000000000000000000000001b6580a9edfc0c377107144a68ce0a142ef194db2fc5d3eb44862eddf2ba718e3f7e90dcaf6d2bec815e5d9f5bc61ed63aa6d4430781712a07fe9b98a59dc9f7a00000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1503639", gasUsed: "764730", confirmations: "1063029"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["7000000000000000000000","15552000000000","10367989632000","7776000","2332800","1544313600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "2041694201525630780780247644590609268624"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x6580a9edfc0c377107144a68ce0a142ef194db2fc5d3eb44862eddf2ba718e3f"}, {type: "bytes32", name: "s", value: "0x7e90dcaf6d2bec815e5d9f5bc61ed63aa6d4430781712a07fe9b98a59dc9f7a0"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["7000000000000000000000","15552000000000","10367989632000","7776000","2332800","1544313600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "2041694201525630780780247644590609268624", "27", "0x6580a9edfc0c377107144a68ce0a142ef194db2fc5d3eb44862eddf2ba718e3f", "0x7e90dcaf6d2bec815e5d9f5bc61ed63aa6d4430781712a07fe9b98a59dc9f7a0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541741146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xa2ad10f6058e80dde620617e5f84618964a01046"}, {name: "loanId", type: "uint256", value: "421"}, {name: "landId", type: "uint256", value: "2041694201525630780780247644590609268624"}, {name: "mortgageId", type: "uint256", value: "20"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"7000000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6672436", timeStamp: "1541767530", hash: "0x1f663d851133aa50322b6a665105f424a7a9f4f41139160e50287ace78909791", nonce: "7", blockHash: "0x519749abcf68aeb03467331e27af18db16da095980fe5d67800ec6d1eb838d46", transactionIndex: "64", from: "0xa2ad10f6058e80dde620617e5f84618964a01046", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191999", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000017b7883c0691660000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000009e340000000000000000000000000000000000000000000000000000000000002f7600000000000000000000000000000000000000000000000000000001679569d400000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000005ffffffffffffffffffffffffffffff8f000000000000000000000000000000000000000000000000000000000000001c39559a5ff742ced3f11931d8d54215a1c88bf5f75bec13423cb1d220ba1d9ca26f3e952ebb973242487945c2f132e1f3b4d05ad6020ac8ea975d056652e66fb80000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7512007", gasUsed: "764666", confirmations: "1061147"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["7000000000000000000000","15552000000000","10367989632000","10368000","3110400","1544400000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "2041694201525630780780247644590609268623"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x39559a5ff742ced3f11931d8d54215a1c88bf5f75bec13423cb1d220ba1d9ca2"}, {type: "bytes32", name: "s", value: "0x6f3e952ebb973242487945c2f132e1f3b4d05ad6020ac8ea975d056652e66fb8"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["7000000000000000000000","15552000000000","10367989632000","10368000","3110400","1544400000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "2041694201525630780780247644590609268623", "28", "0x39559a5ff742ced3f11931d8d54215a1c88bf5f75bec13423cb1d220ba1d9ca2", "0x6f3e952ebb973242487945c2f132e1f3b4d05ad6020ac8ea975d056652e66fb8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541767530 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xa2ad10f6058e80dde620617e5f84618964a01046"}, {name: "loanId", type: "uint256", value: "422"}, {name: "landId", type: "uint256", value: "2041694201525630780780247644590609268623"}, {name: "mortgageId", type: "uint256", value: "21"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "0" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"22999000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6687941", timeStamp: "1541986598", hash: "0x206c157371d7d5c1f16e7ffd5dfb34f0133a0d4e809d67e062ffb9e9821b6e38", nonce: "16", blockHash: "0x4689d238fa9e2e03664c9eb882271d42eeca5553844dccaddabfb51b2688509a", transactionIndex: "79", from: "0x46540e20b067698b6bc5419a36e3319eaba525f4", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191999", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000004dec73de61358fc000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000004f1a00000000000000000000000000000000000000000000000000000000000017bb0000000000000000000000000000000000000000000000000000000167a4dce80000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000fffffffffffffffffffffffffffffff6f000000000000000000000000000000000000000000000000000000000000001b707fa4bcd30938ae3f3f9eab745a64c48d15deeaa37f25e82a476e805a82c5f723eb68dc5e92e58093542fc2c62a135a3fd4a5fb52380788bc9d82f5796585050000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4917515", gasUsed: "764666", confirmations: "1045642"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["22999000000000000000000","15552000000000","10367989632000","5184000","1555200","1544659200000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "5444517870735015415413993718908291383151"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x707fa4bcd30938ae3f3f9eab745a64c48d15deeaa37f25e82a476e805a82c5f7"}, {type: "bytes32", name: "s", value: "0x23eb68dc5e92e58093542fc2c62a135a3fd4a5fb52380788bc9d82f579658505"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["22999000000000000000000","15552000000000","10367989632000","5184000","1555200","1544659200000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "5444517870735015415413993718908291383151", "27", "0x707fa4bcd30938ae3f3f9eab745a64c48d15deeaa37f25e82a476e805a82c5f7", "0x23eb68dc5e92e58093542fc2c62a135a3fd4a5fb52380788bc9d82f579658505", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541986598 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x46540e20b067698b6bc5419a36e3319eaba525f4"}, {name: "loanId", type: "uint256", value: "432"}, {name: "landId", type: "uint256", value: "5444517870735015415413993718908291383151"}, {name: "mortgageId", type: "uint256", value: "22"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "24586473553210200" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"7989000000000000000000\",\"7776000000... )", async function( ) {
		const txOriginal = {blockNumber: "6688086", timeStamp: "1541988412", hash: "0x1dfe7ec814d856c675ce0f0c0052142c0449f2844d27a03bb35211a91589ec7d", nonce: "18", blockHash: "0xf40f5d86b298e6ee15d16395243cf5ee29f292d4d2cd78ebadc269b2d487cfc3", transactionIndex: "75", from: "0x46540e20b067698b6bc5419a36e3319eaba525f4", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193535", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000001b115a59476c3b40000000000000000000000000000000000000000000000000000000007127db7c0000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000000003f48000000000000000000000000000000000000000000000000000000167a4dce8000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffc9ffffffffffffffffffffffffffffff6a000000000000000000000000000000000000000000000000000000000000001cee26b86d215c3ec0e9fdd9169ff28b823383bf7cba19b6bc7b71b6570a8eb9096dbe45d4f3dcfe83c2cc5ce1705c22c398e24684d05886f2bdc6539244a2acb60000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6321984", gasUsed: "765690", confirmations: "1045497"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["7989000000000000000000","7776000000000","10367989632000","864000","259200","1544659200000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907834894736851909887012435355206597646221162"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xee26b86d215c3ec0e9fdd9169ff28b823383bf7cba19b6bc7b71b6570a8eb909"}, {type: "bytes32", name: "s", value: "0x6dbe45d4f3dcfe83c2cc5ce1705c22c398e24684d05886f2bdc6539244a2acb6"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["7989000000000000000000","7776000000000","10367989632000","864000","259200","1544659200000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907834894736851909887012435355206597646221162", "28", "0xee26b86d215c3ec0e9fdd9169ff28b823383bf7cba19b6bc7b71b6570a8eb909", "0x6dbe45d4f3dcfe83c2cc5ce1705c22c398e24684d05886f2bdc6539244a2acb6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541988412 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x46540e20b067698b6bc5419a36e3319eaba525f4"}, {name: "loanId", type: "uint256", value: "434"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907834894736851909887012435355206597646221162"}, {name: "mortgageId", type: "uint256", value: "23"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "24586473553210200" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"8990000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6690891", timeStamp: "1542028866", hash: "0x8e3597e521b4ca45b6fb991fc3403dc948d50ce98f43f4ff1b90a0ba913d0a04", nonce: "102", blockHash: "0x95cd72a6b50a117015956bd733e619562313a6350fb2d9564555fd369b439ae1", transactionIndex: "90", from: "0x7a72a2e270265adda6e038ddaa8f418e51b81ebb", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "953599", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000001e7594ff8f049b8000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc000000000000000000000000000000000000000000000000000000000000ed4e00000000000000000000000000000000000000000000000000000000000047310000000000000000000000000000000000000000000000000000000167a4dce800000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000010ffffffffffffffffffffffffffffff8f000000000000000000000000000000000000000000000000000000000000001c466585b6a19cd37e08d5b43422c08fc3aae7a4a8f1a7fb67916f09af9773d5d96c7d40981251fdd6f47d0da56f549b6fa11c3e1df0afd6a39f5c533f3389ae550000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3414120", gasUsed: "764666", confirmations: "1042692"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["8990000000000000000000","15552000000000","10367989632000","15552000","4665600","1544659200000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "5784800237655953878877368326340059594639"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x466585b6a19cd37e08d5b43422c08fc3aae7a4a8f1a7fb67916f09af9773d5d9"}, {type: "bytes32", name: "s", value: "0x6c7d40981251fdd6f47d0da56f549b6fa11c3e1df0afd6a39f5c533f3389ae55"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["8990000000000000000000","15552000000000","10367989632000","15552000","4665600","1544659200000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "5784800237655953878877368326340059594639", "28", "0x466585b6a19cd37e08d5b43422c08fc3aae7a4a8f1a7fb67916f09af9773d5d9", "0x6c7d40981251fdd6f47d0da56f549b6fa11c3e1df0afd6a39f5c533f3389ae55", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542028866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x7a72a2e270265adda6e038ddaa8f418e51b81ebb"}, {name: "loanId", type: "uint256", value: "436"}, {name: "landId", type: "uint256", value: "5784800237655953878877368326340059594639"}, {name: "mortgageId", type: "uint256", value: "24"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "20999873445278907" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"13000000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6696001", timeStamp: "1542099999", hash: "0x326e1196513a07b7171e655e3f807872f75d0380178cf9645cea77aa5d97a47c", nonce: "15", blockHash: "0x65cbf210a8fcda167c9b9fc8c22af8fccdc27a74e622091332785c56bbfc03e8", transactionIndex: "99", from: "0x9798ab37ddeebaae867f0f24a48638293e6b8240", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1192191", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000002c0bb3dd30c4e20000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000000e8080000000000000000000000000000000000000000000000000000000000003f48000000000000000000000000000000000000000000000000000000167aa034400000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000033ffffffffffffffffffffffffffffff91000000000000000000000000000000000000000000000000000000000000001c2f3b6a979b631a23b92f1d663887a4ab1355f09a37884d9c8883fd40e6a6276731493543fbf6abcba2eb3bd2414183b498e25c43de16fea0d01c1e2be38127e60000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6876089", gasUsed: "764794", confirmations: "1037582"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["13000000000000000000000","15552000000000","10367989632000","950400","259200","1544745600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "17694683079888800100095479586451946995601"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x2f3b6a979b631a23b92f1d663887a4ab1355f09a37884d9c8883fd40e6a62767"}, {type: "bytes32", name: "s", value: "0x31493543fbf6abcba2eb3bd2414183b498e25c43de16fea0d01c1e2be38127e6"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["13000000000000000000000","15552000000000","10367989632000","950400","259200","1544745600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "17694683079888800100095479586451946995601", "28", "0x2f3b6a979b631a23b92f1d663887a4ab1355f09a37884d9c8883fd40e6a62767", "0x31493543fbf6abcba2eb3bd2414183b498e25c43de16fea0d01c1e2be38127e6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542099999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x9798ab37ddeebaae867f0f24a48638293e6b8240"}, {name: "loanId", type: "uint256", value: "442"}, {name: "landId", type: "uint256", value: "17694683079888800100095479586451946995601"}, {name: "mortgageId", type: "uint256", value: "25"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "19450021290050000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"13000000000000000000000\",\"124416000... )", async function( ) {
		const txOriginal = {blockNumber: "6696581", timeStamp: "1542108394", hash: "0x5a713dd32d1f50c1fe1f91038694c575efa3ef152a5d81eb8d7883cd30ed769c", nonce: "18", blockHash: "0xecdf9f7c6f79f55844dacfdfc7f57c8aa414412d55d7160e77184e35563196f4", transactionIndex: "1", from: "0x9798ab37ddeebaae867f0f24a48638293e6b8240", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191999", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000002c0bb3dd30c4e20000000000000000000000000000000000000000000000000000000000b50c92600000000000000000000000000000000000000000000000000000000096dfc56cc000000000000000000000000000000000000000000000000000000000000278d0000000000000000000000000000000000000000000000000000000000000bdd8000000000000000000000000000000000000000000000000000000167aa034400000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000033ffffffffffffffffffffffffffffff91000000000000000000000000000000000000000000000000000000000000001c26e89986d53630f7d701d922ff3e40afe00201c9f19531f05486a820608ae12415f021732114132b65b1476e55b6263ef1da4d8f65eab9f2a6728e3970e7f7ff0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1169041", gasUsed: "764666", confirmations: "1037002"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["13000000000000000000000","12441600000000","10367989632000","2592000","777600","1544745600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "17694683079888800100095479586451946995601"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x26e89986d53630f7d701d922ff3e40afe00201c9f19531f05486a820608ae124"}, {type: "bytes32", name: "s", value: "0x15f021732114132b65b1476e55b6263ef1da4d8f65eab9f2a6728e3970e7f7ff"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["13000000000000000000000","12441600000000","10367989632000","2592000","777600","1544745600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "17694683079888800100095479586451946995601", "28", "0x26e89986d53630f7d701d922ff3e40afe00201c9f19531f05486a820608ae124", "0x15f021732114132b65b1476e55b6263ef1da4d8f65eab9f2a6728e3970e7f7ff", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542108394 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x9798ab37ddeebaae867f0f24a48638293e6b8240"}, {name: "loanId", type: "uint256", value: "443"}, {name: "landId", type: "uint256", value: "17694683079888800100095479586451946995601"}, {name: "mortgageId", type: "uint256", value: "26"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "19450021290050000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"7999000000000000000000\",\"1555200000... )", async function( ) {
		const txOriginal = {blockNumber: "6700212", timeStamp: "1542159575", hash: "0x84bf3cd3a9a8aa5a9cde8c46a4ef6cf5269d15980fc2fa2bdb31f0fd192e96bb", nonce: "105", blockHash: "0xdc9baca44f57b911432777578327dcc783926658afd2482cdc425cc4d118542c", transactionIndex: "49", from: "0x7a72a2e270265adda6e038ddaa8f418e51b81ebb", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193535", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000001b1a06cb77b4d9c000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000076a7000000000000000000000000000000000000000000000000000000000000239880000000000000000000000000000000000000000000000000000001671ef790000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffff76ffffffffffffffffffffffffffffff92000000000000000000000000000000000000000000000000000000000000001c069f635f5532d96fba8867825062b0489b368b69d6d9397043ad43187ca0a6c46f7bc53bd59107285c986ddbf1436de4b82fe42a65eefdb0e0979d61e035661d0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7309331", gasUsed: "765690", confirmations: "1033371"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["7999000000000000000000","15552000000000","10367989632000","7776000","2332800","1542412800000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907806651300397471994544975262789760884670354"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x069f635f5532d96fba8867825062b0489b368b69d6d9397043ad43187ca0a6c4"}, {type: "bytes32", name: "s", value: "0x6f7bc53bd59107285c986ddbf1436de4b82fe42a65eefdb0e0979d61e035661d"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["7999000000000000000000","15552000000000","10367989632000","7776000","2332800","1542412800000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907806651300397471994544975262789760884670354", "28", "0x069f635f5532d96fba8867825062b0489b368b69d6d9397043ad43187ca0a6c4", "0x6f7bc53bd59107285c986ddbf1436de4b82fe42a65eefdb0e0979d61e035661d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542159575 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x7a72a2e270265adda6e038ddaa8f418e51b81ebb"}, {name: "loanId", type: "uint256", value: "450"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907806651300397471994544975262789760884670354"}, {name: "mortgageId", type: "uint256", value: "27"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "20999873445278907" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"10500000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6705446", timeStamp: "1542234129", hash: "0x4c640df05a2bb8573bae11e81154ff8ee1e8253ef0af0d067c70f55d87ff80b8", nonce: "9", blockHash: "0x5d5a4d40146e1fd48cf565f56b9071798d071c7c0aeba59f7e8a14b70eebcb8f", transactionIndex: "108", from: "0x166a16ff95a16d8a8f797c4f33578d5abddcf531", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "794666", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000023934c5a09da190000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000004f1a00000000000000000000000000000000000000000000000000000000000017bb0000000000000000000000000000000000000000000000000000000167af29a000000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000036ffffffffffffffffffffffffffffff91000000000000000000000000000000000000000000000000000000000000001bed1ed079fa1fe5a263f09f641ff4e469f0e97387bc674a3629056bd83b3ecf1123b25069c9479446f93f877caaef34aa55c771b16b5191deeea8ad91dc5c2cab0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7798928", gasUsed: "764666", confirmations: "1028137"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["10500000000000000000000","15552000000000","10367989632000","5184000","1555200","1544832000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "18715530180651615490485603408747251629969"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xed1ed079fa1fe5a263f09f641ff4e469f0e97387bc674a3629056bd83b3ecf11"}, {type: "bytes32", name: "s", value: "0x23b25069c9479446f93f877caaef34aa55c771b16b5191deeea8ad91dc5c2cab"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["10500000000000000000000","15552000000000","10367989632000","5184000","1555200","1544832000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "18715530180651615490485603408747251629969", "27", "0xed1ed079fa1fe5a263f09f641ff4e469f0e97387bc674a3629056bd83b3ecf11", "0x23b25069c9479446f93f877caaef34aa55c771b16b5191deeea8ad91dc5c2cab", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542234129 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x166a16ff95a16d8a8f797c4f33578d5abddcf531"}, {name: "loanId", type: "uint256", value: "460"}, {name: "landId", type: "uint256", value: "18715530180651615490485603408747251629969"}, {name: "mortgageId", type: "uint256", value: "28"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "743849187266474" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"16000000000000000000000\",\"311040000... )", async function( ) {
		const txOriginal = {blockNumber: "6724738", timeStamp: "1542506961", hash: "0xdd4576a90aa7182b4d119b19cf43a56c3845696dfdb25ba737a48b42f69e218f", nonce: "62", blockHash: "0x707946f0a647b12277518479dc42844c24cf4d714b2da2fc64f499631f2e76c3", transactionIndex: "3", from: "0xc45ea7a85e220c50584918273cf2b709d411901d", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "7600027", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xacddb63c0000000000000000000000000000000000000000000003635c9adc5dea00000000000000000000000000000000000000000000000000000000001c49f6df000000000000000000000000000000000000000000000000000000000e24fb6f8000000000000000000000000000000000000000000000000000000000000076a7000000000000000000000000000000000000000000000000000000000000239880000000000000000000000000000000000000000000000000000001672e6aa400000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000015ffffffffffffffffffffffffffffff71000000000000000000000000000000000000000000000000000000000000001b8f33c419097481528ed06817c7d756eb416d3b78b0d5bd28777f479eb1123f852c1019bcad0f9e9ca8f1211f7f113c33eea4ac7f05ae95763bfc64d557091e0e0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "583630", gasUsed: "467173", confirmations: "1008845"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["16000000000000000000000","31104000000000","15552000000000","7776000","2332800","1542672000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "7486212072260646196194241363498900651889"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x8f33c419097481528ed06817c7d756eb416d3b78b0d5bd28777f479eb1123f85"}, {type: "bytes32", name: "s", value: "0x2c1019bcad0f9e9ca8f1211f7f113c33eea4ac7f05ae95763bfc64d557091e0e"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["16000000000000000000000","31104000000000","15552000000000","7776000","2332800","1542672000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "7486212072260646196194241363498900651889", "27", "0x8f33c419097481528ed06817c7d756eb416d3b78b0d5bd28777f479eb1123f85", "0x2c1019bcad0f9e9ca8f1211f7f113c33eea4ac7f05ae95763bfc64d557091e0e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542506961 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"16750000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6724754", timeStamp: "1542507153", hash: "0xbc30b622b7802e2e3b4d12a06bbd25ddb37edfc2a64d4d129e5a85f1b577eb2d", nonce: "64", blockHash: "0x17fe1e947abcb449692d87af1719e74746dfd9889faef3479a57c5272ab7362a", transactionIndex: "2", from: "0xc45ea7a85e220c50584918273cf2b709d411901d", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "7600000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xacddb63c00000000000000000000000000000000000000000000038c04f21eb250f8000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000076a700000000000000000000000000000000000000000000000000000000000023988000000000000000000000000000000000000000000000000000000167be9cb40000000000000000000000000000000000000000000000000000000000000001600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001cbf20c8b788d8bcb4270afe9f2cbd4a5098ccdb3d47eaad697aba9ef42d84316362e629f335b3133b7c6332b90a6dd0cbee1f6c0d5f706311456deb7739cb08120000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "490374", gasUsed: "430759", confirmations: "1008829"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["16750000000000000000000","15552000000000","10367989632000","7776000","2332800","1545091200000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "0"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xbf20c8b788d8bcb4270afe9f2cbd4a5098ccdb3d47eaad697aba9ef42d843163"}, {type: "bytes32", name: "s", value: "0x62e629f335b3133b7c6332b90a6dd0cbee1f6c0d5f706311456deb7739cb0812"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["16750000000000000000000","15552000000000","10367989632000","7776000","2332800","1545091200000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "0", "28", "0xbf20c8b788d8bcb4270afe9f2cbd4a5098ccdb3d47eaad697aba9ef42d843163", "0x62e629f335b3133b7c6332b90a6dd0cbee1f6c0d5f706311456deb7739cb0812", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542507153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "0" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"16750000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6724785", timeStamp: "1542507616", hash: "0xa7220e0b37374f91fa1ea79017e52465a924a4c008739696ca80f96dde66793e", nonce: "69", blockHash: "0xe00cfbc28254d4d64724084d19193e0deb9bdc20e0ac5c702fe38b016af9ef1f", transactionIndex: "57", from: "0xc45ea7a85e220c50584918273cf2b709d411901d", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1192095", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c00000000000000000000000000000000000000000000038c04f21eb250f8000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc00000000000000000000000000000000000000000000000000000000000076a700000000000000000000000000000000000000000000000000000000000023988000000000000000000000000000000000000000000000000000000167be9cb400000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000009ffffffffffffffffffffffffffffff72000000000000000000000000000000000000000000000000000000000000001c8e5538fb4355e8217728d3d08c7286e04127d8c1fcf7b7bfb76bfa8d64513f5b3cd2f4d9f7b49c4e795e7488642d8849fc0340c74d8f4458918c5196bd0d71ac0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4380325", gasUsed: "764730", confirmations: "1008798"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["16750000000000000000000","15552000000000","10367989632000","7776000","2332800","1545091200000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "3402823669209384634633746074317682114418"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x8e5538fb4355e8217728d3d08c7286e04127d8c1fcf7b7bfb76bfa8d64513f5b"}, {type: "bytes32", name: "s", value: "0x3cd2f4d9f7b49c4e795e7488642d8849fc0340c74d8f4458918c5196bd0d71ac"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["16750000000000000000000","15552000000000","10367989632000","7776000","2332800","1545091200000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "3402823669209384634633746074317682114418", "28", "0x8e5538fb4355e8217728d3d08c7286e04127d8c1fcf7b7bfb76bfa8d64513f5b", "0x3cd2f4d9f7b49c4e795e7488642d8849fc0340c74d8f4458918c5196bd0d71ac", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542507616 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xc45ea7a85e220c50584918273cf2b709d411901d"}, {name: "loanId", type: "uint256", value: "484"}, {name: "landId", type: "uint256", value: "3402823669209384634633746074317682114418"}, {name: "mortgageId", type: "uint256", value: "29"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"14000000000000000000000\",\"207359792... )", async function( ) {
		const txOriginal = {blockNumber: "6725399", timeStamp: "1542516434", hash: "0x573cda787ee7883e01882caca2224c57a539ad8e0c84405a525d9213314587df", nonce: "79", blockHash: "0xf824a5e75ad63f64c219af74f71995415bf6e34522b37a4c6ac2638343ddc26a", transactionIndex: "2", from: "0xc45ea7a85e220c50584918273cf2b709d411901d", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191903", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000002f6f10780d22cc00000000000000000000000000000000000000000000000000000000012dbf8ad980000000000000000000000000000000000000000000000000000000b50c926000000000000000000000000000000000000000000000000000000000000004f1a00000000000000000000000000000000000000000000000000000000000017bb00000000000000000000000000000000000000000000000000000001672e6aa400000000000000000000000000000000000000000000000000000000000000016000000000000000000000000000000015ffffffffffffffffffffffffffffff71000000000000000000000000000000000000000000000000000000000000001b0199bdcd095e9af22de978af6640972eaf045117928a59111ea5521cadbecacc523a061bae12f3280e3bcfaa8a969b5a295e4f91c3de4dc4c8ee7e3a052f1b870000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6451554", gasUsed: "764602", confirmations: "1008184"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["14000000000000000000000","20735979264000","12441600000000","5184000","1555200","1542672000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "7486212072260646196194241363498900651889"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x0199bdcd095e9af22de978af6640972eaf045117928a59111ea5521cadbecacc"}, {type: "bytes32", name: "s", value: "0x523a061bae12f3280e3bcfaa8a969b5a295e4f91c3de4dc4c8ee7e3a052f1b87"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["14000000000000000000000","20735979264000","12441600000000","5184000","1555200","1542672000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "7486212072260646196194241363498900651889", "27", "0x0199bdcd095e9af22de978af6640972eaf045117928a59111ea5521cadbecacc", "0x523a061bae12f3280e3bcfaa8a969b5a295e4f91c3de4dc4c8ee7e3a052f1b87", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542516434 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xc45ea7a85e220c50584918273cf2b709d411901d"}, {name: "loanId", type: "uint256", value: "485"}, {name: "landId", type: "uint256", value: "7486212072260646196194241363498900651889"}, {name: "mortgageId", type: "uint256", value: "30"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "0" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"3000000000000000000000\",\"3888000000... )", async function( ) {
		const txOriginal = {blockNumber: "6729232", timeStamp: "1542569618", hash: "0x874666c1d342ec7dfdfb692150c39e4cdbdb35f82af6b8b7ee331c7d389727aa", nonce: "91", blockHash: "0x5d579eb56d609101851682ad4d9a1f990bbe7c3e209cd71ffe49878a3962aa17", transactionIndex: "47", from: "0x3a1948c2993047abbf93b85ccce1f1ff983da65b", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193343", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000000a2a15d09519be000000000000000000000000000000000000000000000000000000000235c7496c00000000000000000000000000000000000000000000000000000000c4cacfd48000000000000000000000000000000000000000000000000000000000000d2f00000000000000000000000000000000000000000000000000000000000003f480000000000000000000000000000000000000000000000000000000167c3c310000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffffcbffffffffffffffffffffffffffffff6a000000000000000000000000000000000000000000000000000000000000001cb84e72a731d561dd3e7f0577907a853d85fa07ead3a6617b0243779992e0e5175a7f230830e035126e8c03dbfe48116f3af05c50f43579fbcff6f981a096cd990000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3503516", gasUsed: "765562", confirmations: "1004351"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["3000000000000000000000","38880000000000","13523459328000","13824000","4147200","1545177600000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907835575301585751763939362104421461182644074"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xb84e72a731d561dd3e7f0577907a853d85fa07ead3a6617b0243779992e0e517"}, {type: "bytes32", name: "s", value: "0x5a7f230830e035126e8c03dbfe48116f3af05c50f43579fbcff6f981a096cd99"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["3000000000000000000000","38880000000000","13523459328000","13824000","4147200","1545177600000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907835575301585751763939362104421461182644074", "28", "0xb84e72a731d561dd3e7f0577907a853d85fa07ead3a6617b0243779992e0e517", "0x5a7f230830e035126e8c03dbfe48116f3af05c50f43579fbcff6f981a096cd99", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542569618 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x3a1948c2993047abbf93b85ccce1f1ff983da65b"}, {name: "loanId", type: "uint256", value: "488"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907835575301585751763939362104421461182644074"}, {name: "mortgageId", type: "uint256", value: "31"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "93025905500300180" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"27000000000000000000000\",\"622080000... )", async function( ) {
		const txOriginal = {blockNumber: "6733496", timeStamp: "1542630574", hash: "0xaed12aefe68552d5f9967a47e9e74c069707f81cc2b1b212d16061055546b5ac", nonce: "6", blockHash: "0x51f4c66254a39d7cc496666395c5bc1d035a3553d224c0c4fbb63f71b60421a2", transactionIndex: "65", from: "0xe92e1aaa54f863ab48a39161a166f852b701b439", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1193247", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000005b7ac4553de7ae0000000000000000000000000000000000000000000000000000000003893edbe000000000000000000000000000000000000000000000000000000001c49f6df0000000000000000000000000000000000000000000000000000000000000076a7000000000000000000000000000000000000000000000000000000000000278d000000000000000000000000000000000000000000000000000000016738b75c000000000000000000000000000000000000000000000000000000000000000160fffffffffffffffffffffffffffffff9ffffffffffffffffffffffffffffff80000000000000000000000000000000000000000000000000000000000000001cee642506c293bc5453e39d69b70cb91dbf712423d34c5dc7e1e78957a37b4d5e1ec901e4144f21c1f07b832d5b428d7106a4ddab02a0f8f64f8aca7ad14f9c9d0000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3665928", gasUsed: "765498", confirmations: "1000087"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["27000000000000000000000","62208000000000","31104000000000","7776000","2592000","1542844800000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907851228290464114933258677336363322520371072"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xee642506c293bc5453e39d69b70cb91dbf712423d34c5dc7e1e78957a37b4d5e"}, {type: "bytes32", name: "s", value: "0x1ec901e4144f21c1f07b832d5b428d7106a4ddab02a0f8f64f8aca7ad14f9c9d"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["27000000000000000000000","62208000000000","31104000000000","7776000","2592000","1542844800000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907851228290464114933258677336363322520371072", "28", "0xee642506c293bc5453e39d69b70cb91dbf712423d34c5dc7e1e78957a37b4d5e", "0x1ec901e4144f21c1f07b832d5b428d7106a4ddab02a0f8f64f8aca7ad14f9c9d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542630574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0xe92e1aaa54f863ab48a39161a166f852b701b439"}, {name: "loanId", type: "uint256", value: "492"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907851228290464114933258677336363322520371072"}, {name: "mortgageId", type: "uint256", value: "32"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "193622300000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: requestMortgage( [\"80000000000000000000000\",\"155520000... )", async function( ) {
		const txOriginal = {blockNumber: "6734533", timeStamp: "1542645602", hash: "0x44647bc4515c90a087cfdfdabc31a61ce9a8469b93e339d21e3bb79cd4bd2d19", nonce: "34", blockHash: "0x6c4c883f72562d0109f1276273c35559af213d9fb5ff8c6e4b4ea62ade4c5c99", transactionIndex: "48", from: "0x86bf3ab3576cc3ea26284f7da376471697e63cdf", to: "0x90263ea5c57dc6603ca7202920735a6e31235bb9", value: "0", gas: "1191903", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xacddb63c0000000000000000000000000000000000000000000010f0cf064dd59200000000000000000000000000000000000000000000000000000000000e24fb6f80000000000000000000000000000000000000000000000000000000096dfc56cc0000000000000000000000000000000000000000000000000000000000004f1a00000000000000000000000000000000000000000000000000000000000017bb0000000000000000000000000000000000000000000000000000000167c8e96c000000000000000000000000000000000000000000000000000000000000000160ffffffffffffffffffffffffffffff9e0000000000000000000000000000001e000000000000000000000000000000000000000000000000000000000000001b1ecfb86c0ddd9e25d044bed13dd1d6e311ac892982b965aea352d0c8cb8ff6d41d719a9858551d64a4d4d778b19b963aed49712c1023200c545dfb94eb83a3960000000000000000000000000000000000000000000000000000000000000047236d6f727467616765202372657175697265642d636f7369676e65723a30783961626631323935303836616661306534396336306539356334333761613430306335333333623800000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2531861", gasUsed: "764602", confirmations: "999050"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256[6]", name: "loanParams", value: ["80000000000000000000000","15552000000000","10367989632000","5184000","1555200","1545264000000"]}, {type: "string", name: "metadata", value: `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`}, {type: "uint256", name: "landId", value: "115792089237316195423570985008687907819922312707388594620046872479599844917278"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x1ecfb86c0ddd9e25d044bed13dd1d6e311ac892982b965aea352d0c8cb8ff6d4"}, {type: "bytes32", name: "s", value: "0x1d719a9858551d64a4d4d778b19b963aed49712c1023200c545dfb94eb83a396"}], name: "requestMortgage", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "requestMortgage(uint256[6],string,uint256,uint8,bytes32,bytes32)" ]( ["80000000000000000000000","15552000000000","10367989632000","5184000","1555200","1545264000000"], `#mortgage #required-cosigner:0x9abf1295086afa0e49c60e95c437aa400c5333b8`, "115792089237316195423570985008687907819922312707388594620046872479599844917278", "27", "0x1ecfb86c0ddd9e25d044bed13dd1d6e311ac892982b965aea352d0c8cb8ff6d4", "0x1d719a9858551d64a4d4d778b19b963aed49712c1023200c545dfb94eb83a396", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542645602 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "borrower", type: "address"}, {indexed: false, name: "loanId", type: "uint256"}, {indexed: false, name: "landId", type: "uint256"}, {indexed: false, name: "mortgageId", type: "uint256"}], name: "NewMortgage", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "NewMortgage", events: [{name: "borrower", type: "address", value: "0x86bf3ab3576cc3ea26284f7da376471697e63cdf"}, {name: "loanId", type: "uint256", value: "494"}, {name: "landId", type: "uint256", value: "115792089237316195423570985008687907819922312707388594620046872479599844917278"}, {name: "mortgageId", type: "uint256", value: "33"}], address: "0x90263ea5c57dc6603ca7202920735a6e31235bb9"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "5332592113896749" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
