const MyDice75 = artifacts.require( "./MyDice75.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "MyDice75" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x86a9925d7aA172F2c0307154fB736e89f32c6155", "0x5590844099dC04B3df7d1484F099fb90C1a27aB4"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "numElements", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxProfitAsPercentOfHouse", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "payoutsPaused", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxBetDivisor", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "addressToCheck", type: "address"}], name: "playerGetPendingTxByAddress", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "contractBalance", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalUserProfit", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalBets", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "gamePaused", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "houseEdge", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "houseEdgeDivisor", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "betID", type: "uint256"}], name: "LogBetStart", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "BetID", type: "uint256"}, {indexed: true, name: "PlayerAddress", type: "address"}, {indexed: true, name: "PlayerNumber", type: "uint256"}, {indexed: false, name: "DiceResult", type: "uint256"}, {indexed: false, name: "Value", type: "uint256"}, {indexed: false, name: "Status", type: "int256"}, {indexed: false, name: "BetValue", type: "uint256"}, {indexed: false, name: "targetNumber", type: "uint256"}], name: "LogResult", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "SentToAddress", type: "address"}, {indexed: true, name: "AmountTransferred", type: "uint256"}], name: "LogOwnerTransfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogBetStart(uint256)", "LogResult(uint256,address,uint256,uint256,uint256,int256,uint256,uint256)", "LogOwnerTransfer(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x299550d99d9de36d5daecf3a1e2dacf4752229cb04140e35fa3a7d0fb216a909", "0xae70609e7baecfecb9098ff43b75f20cce8f4cb687c29322eef3cfc15dd7b707", "0x42c501a185f41a8eb77b0a3e7b72a6435ea7aa752f8a1a0a13ca4628495eca91"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4352779 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4353085 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "MyDice75", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "numElements", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numElements()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfitAsPercentOfHouse", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfitAsPercentOfHouse()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "payoutsPaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "payoutsPaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxBetDivisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxBetDivisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addressToCheck", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "playerGetPendingTxByAddress", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "playerGetPendingTxByAddress(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contractBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contractBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minBet", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minBet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalUserProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalUserProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalBets", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalBets()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gamePaused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gamePaused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "houseEdge", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "houseEdge()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "houseEdgeDivisor", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "houseEdgeDivisor()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "MyDice75", function( accounts ) {

	it( "TEST: MyDice75(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4352779", timeStamp: "1507620187", hash: "0x2e3e9929d0c3c9f49667905ffbcd6fd385d92b9258fd1cfa4a7ac7eb1c2f39b1", nonce: "59", blockHash: "0x97feb128aa4f8ff92e278fe3a159d0bcc1722b142ac55a52c37f8ae524c6d40b", transactionIndex: "0", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: 0, value: "0", gas: "4712388", gasPrice: "100000000000", isError: "0", txreceipt_status: "", input: "0x16706514", contractAddress: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", cumulativeGasUsed: "1494748", gasUsed: "1494748", confirmations: "3364021"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "MyDice75", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = MyDice75.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1507620187 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = MyDice75.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"98138453\" )", async function( ) {
		const txOriginal = {blockNumber: "4353065", timeStamp: "1507628261", hash: "0xad47430ae347ebb869a12de8624aac12b1092c62488bedd11eaaea94ff47eb79", nonce: "66", blockHash: "0xacd5fd506f8872c56d121a41e5c569dc3672f0b46e30cae0816533e1d4eabf06", transactionIndex: "94", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000005d97955", contractAddress: "", cumulativeGasUsed: "4271507", gasUsed: "22605", confirmations: "3363735"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "98138453"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "98138453", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1507628261 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"19196938\" )", async function( ) {
		const txOriginal = {blockNumber: "4353065", timeStamp: "1507628261", hash: "0x11fafa8edb454d0fe352a9bf0705aad6c73cef0208894b963a84409dded02718", nonce: "67", blockHash: "0xacd5fd506f8872c56d121a41e5c569dc3672f0b46e30cae0816533e1d4eabf06", transactionIndex: "95", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e6000000000000000000000000000000000000000000000000000000000124ec0a", contractAddress: "", cumulativeGasUsed: "4294112", gasUsed: "22605", confirmations: "3363735"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "19196938"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "19196938", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1507628261 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"29336535\" )", async function( ) {
		const txOriginal = {blockNumber: "4353065", timeStamp: "1507628261", hash: "0xc8e2e6361451ccf10474b6f496e07d9efb4b62e9d4f9b53f6b575c4174cac328", nonce: "68", blockHash: "0xacd5fd506f8872c56d121a41e5c569dc3672f0b46e30cae0816533e1d4eabf06", transactionIndex: "96", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000001bfa3d7", contractAddress: "", cumulativeGasUsed: "4316717", gasUsed: "22605", confirmations: "3363735"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "29336535"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "29336535", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1507628261 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"13040988\" )", async function( ) {
		const txOriginal = {blockNumber: "4353066", timeStamp: "1507628279", hash: "0x2155a9317fa1385872f139a3f645e998306c217857211f9e625a7c2922936314", nonce: "69", blockHash: "0xf808b1651bdd6a7707a5c944d1b77653da1dee245c58960c0d0128a47d031ce5", transactionIndex: "51", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000000c6fd5c", contractAddress: "", cumulativeGasUsed: "1289934", gasUsed: "22541", confirmations: "3363734"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "13040988"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "13040988", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1507628279 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"64317878\" )", async function( ) {
		const txOriginal = {blockNumber: "4353066", timeStamp: "1507628279", hash: "0x745b55887da83cba71ff25075502325da1979d27b8379304acc86182eafcdeb4", nonce: "70", blockHash: "0xf808b1651bdd6a7707a5c944d1b77653da1dee245c58960c0d0128a47d031ce5", transactionIndex: "52", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000003d569b6", contractAddress: "", cumulativeGasUsed: "1312539", gasUsed: "22605", confirmations: "3363734"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "64317878"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "64317878", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1507628279 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"11236827\" )", async function( ) {
		const txOriginal = {blockNumber: "4353067", timeStamp: "1507628312", hash: "0x409177c6719e34fca2a58233dfc79c6312658950c8262377e8c11086445be957", nonce: "71", blockHash: "0x7e58d75c6c064ef5b99500cc212cf4bb7a3bfa8ea89f60afa38419a0a0df0942", transactionIndex: "24", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000000ab75db", contractAddress: "", cumulativeGasUsed: "1553584", gasUsed: "22541", confirmations: "3363733"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "11236827"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "11236827", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1507628312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"3476366\" )", async function( ) {
		const txOriginal = {blockNumber: "4353068", timeStamp: "1507628313", hash: "0xb4a69bd11c79d2c34095f09e7c1a45b499c20aace4c8da466b1c2d68731b9cf6", nonce: "72", blockHash: "0xceaf1954f9e439b0916115c5c5e334964104b31c85a39cf2b06948a543b82c4c", transactionIndex: "4", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000000350b8e", contractAddress: "", cumulativeGasUsed: "122699", gasUsed: "22541", confirmations: "3363732"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "3476366"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "3476366", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1507628313 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"92196559\" )", async function( ) {
		const txOriginal = {blockNumber: "4353069", timeStamp: "1507628328", hash: "0xa3383a02ed8bd82e9d47927bed6490218f282c53c5cc339360b2d65a21d0e024", nonce: "73", blockHash: "0xfc0bae783dfeea8b25e3e501e074d1cc58ce0945936a5f6f352e402c4940f1aa", transactionIndex: "11", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000057ececf", contractAddress: "", cumulativeGasUsed: "424337", gasUsed: "22605", confirmations: "3363731"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "92196559"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "92196559", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1507628328 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"18395039\" )", async function( ) {
		const txOriginal = {blockNumber: "4353071", timeStamp: "1507628415", hash: "0xacb8fda6b5fcfc6febf881ffda7ebe71742d02858ad1a1642e0b483d0199720e", nonce: "74", blockHash: "0xd8fd2e885f25f2958f63d6f2512df198c3626798653f43fc04c7364185b036c2", transactionIndex: "46", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e6000000000000000000000000000000000000000000000000000000000118af9f", contractAddress: "", cumulativeGasUsed: "2522532", gasUsed: "22605", confirmations: "3363729"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "18395039"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "18395039", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1507628415 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"7609451\" )", async function( ) {
		const txOriginal = {blockNumber: "4353072", timeStamp: "1507628453", hash: "0x574bc1ed8e98fb6234e751ccd36ebae10a39fbc3acbdec25245e67715497535c", nonce: "75", blockHash: "0x1f0b18bb71f063bd16d780aa15f2af8caa455b0ea3d02bf907c24375a16a20fe", transactionIndex: "23", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000000741c6b", contractAddress: "", cumulativeGasUsed: "993026", gasUsed: "22541", confirmations: "3363728"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "7609451"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "7609451", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1507628453 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"48024516\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x5a3cc8d07891df3c9ff85aab571bf705f581d6dfba46aea6099dd102bfd9c0d6", nonce: "76", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "47", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000002dccbc4", contractAddress: "", cumulativeGasUsed: "2165234", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "48024516"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "48024516", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"74541827\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x64588b0c85a19570a0b934fb2b51fb9aecc9a8fd871d2e0f662b7afe36719651", nonce: "77", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "48", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000004716b03", contractAddress: "", cumulativeGasUsed: "2187839", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "74541827"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "74541827", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"20071234\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x21960ac5e77907bd7814a68e2067f3b41d1f3dc5d12013de08c3dc53b5a3d778", nonce: "78", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "49", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000001324342", contractAddress: "", cumulativeGasUsed: "2210444", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "20071234"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "20071234", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"8830674\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x14b6e2d5c94e8bcb806dedd1c8f80db18a1af2f2741b8ea1d7e71777d3c84011", nonce: "79", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "50", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e6000000000000000000000000000000000000000000000000000000000086bed2", contractAddress: "", cumulativeGasUsed: "2232985", gasUsed: "22541", confirmations: "3363727"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "8830674"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "8830674", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"64320376\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0xa74986a6352769132a22c4be910ae4de2e3d695a7c6270381a3de65c3d64e1aa", nonce: "80", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "51", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000003d57378", contractAddress: "", cumulativeGasUsed: "2255590", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "64320376"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "64320376", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"58031043\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x2a68f431ab7083cf8249b0aa84aeddf18efe21e9c721ad15e63eff58d41ff23d", nonce: "81", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "52", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000003757bc3", contractAddress: "", cumulativeGasUsed: "2278195", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "58031043"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "58031043", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"91177435\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x34cebe33b586c27035b3e2b1c4e6f22915a0f2284e82e1f04de818938ab095ba", nonce: "82", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "53", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000056f41db", contractAddress: "", cumulativeGasUsed: "2300800", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "91177435"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "91177435", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"87110567\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0xae80350f6c8f7aada17f4218c8e5e17e128027b27a201905de2e0f2d161bd961", nonce: "83", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "54", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000053133a7", contractAddress: "", cumulativeGasUsed: "2323405", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "87110567"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "87110567", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"3773356\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x79f7e5fc047206cbf9ab49a1c8b3f67aad4d449ff07a50e0fc3b5ae9c2ff83d9", nonce: "84", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "55", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000003993ac", contractAddress: "", cumulativeGasUsed: "2345946", gasUsed: "22541", confirmations: "3363727"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "3773356"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "3773356", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"85404069\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x7d2bd2aeadb7305073b23b5b4503905b26788c8a96acda57558bfef866982a1f", nonce: "85", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "56", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000051729a5", contractAddress: "", cumulativeGasUsed: "2368551", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "85404069"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "85404069", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"83482297\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0xbc9d57037de57ea71aaf812013574dfaa10d89c97def1a7a5bbeef6607a4f17c", nonce: "86", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "57", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000004f9d6b9", contractAddress: "", cumulativeGasUsed: "2391156", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "83482297"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "83482297", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"47134856\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x0bd764b3e3b0c1c47d47ee9a8a861866f2b59159aa9cd7929ae8f62dd97d0660", nonce: "87", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "58", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000002cf3888", contractAddress: "", cumulativeGasUsed: "2413761", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "47134856"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "47134856", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"82237505\" )", async function( ) {
		const txOriginal = {blockNumber: "4353073", timeStamp: "1507628456", hash: "0x856074f896863db67a285957140a3792f6d44eaf2bdf6e83c7c143c419b809f4", nonce: "88", blockHash: "0x3be6ce696d60ff05eb19d4e4bfaca5a41ee21deac51b92352e64a36e44c15d3d", transactionIndex: "59", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000004e6d841", contractAddress: "", cumulativeGasUsed: "2436366", gasUsed: "22605", confirmations: "3363727"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "82237505"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "82237505", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1507628456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"43734004\" )", async function( ) {
		const txOriginal = {blockNumber: "4353074", timeStamp: "1507628523", hash: "0x4341305c5dcf33f756cb54e4ed74d44096dd3b923a0db16fe9a4ae9238c74d2a", nonce: "89", blockHash: "0xc46fdb8342d90433cfe2f2d47bb2073b2936261d175be68821c5df40b49af197", transactionIndex: "69", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000029b53f4", contractAddress: "", cumulativeGasUsed: "2934224", gasUsed: "22605", confirmations: "3363726"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "43734004"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "43734004", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1507628523 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"65565543\" )", async function( ) {
		const txOriginal = {blockNumber: "4353075", timeStamp: "1507628530", hash: "0xbcee0ef82aef8a8def6b7b0978ac5ff8991d5df21d0eacf4e8bc0aa9f690476a", nonce: "90", blockHash: "0x1bc6e7b771d0268262a2aee30b7e42304fa30bb9e71c700011be8af7704af4c9", transactionIndex: "7", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000003e87367", contractAddress: "", cumulativeGasUsed: "273047", gasUsed: "22605", confirmations: "3363725"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "65565543"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "65565543", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1507628530 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"99694161\" )", async function( ) {
		const txOriginal = {blockNumber: "4353079", timeStamp: "1507628801", hash: "0x8296365936765ce1abef62cb052aba6287af1db9a72fa6e483a29efd6ad54e60", nonce: "91", blockHash: "0x322bdf2d61b6c5b60f07e0f0d50fc91535f08b1dc05f3b18cfebe4fce50313e7", transactionIndex: "26", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000005f13651", contractAddress: "", cumulativeGasUsed: "1147474", gasUsed: "22605", confirmations: "3363721"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "99694161"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "99694161", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1507628801 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"5817880\" )", async function( ) {
		const txOriginal = {blockNumber: "4353080", timeStamp: "1507628809", hash: "0x917cb29a9bc9202f29d523086a2912361598367928ef878c63640576700a20cc", nonce: "92", blockHash: "0x876a9b5088a53101f7374ff9eb99f6974ef0da7e98c2b932df242f2edde87065", transactionIndex: "13", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e6000000000000000000000000000000000000000000000000000000000058c618", contractAddress: "", cumulativeGasUsed: "980032", gasUsed: "22541", confirmations: "3363720"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "5817880"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "5817880", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1507628809 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"76045949\" )", async function( ) {
		const txOriginal = {blockNumber: "4353081", timeStamp: "1507628835", hash: "0xac8b9f2fb43e60be532ccf2f729ac6bdcf45c5d7ab886c055a57040f684e586b", nonce: "93", blockHash: "0x1fc92b283a3fa1e0c0a93c4e69e7cba25968444d609cffc62a4e57f34c7dd62a", transactionIndex: "29", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000004885e7d", contractAddress: "", cumulativeGasUsed: "1498091", gasUsed: "22605", confirmations: "3363719"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "76045949"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "76045949", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1507628835 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"98184244\" )", async function( ) {
		const txOriginal = {blockNumber: "4353083", timeStamp: "1507628888", hash: "0xdccd96de2c0c45fc5a9b2c8fad4c090fd0147cdfab8ac192d68b39ef0ab605b5", nonce: "94", blockHash: "0xc0be6ae3ff6863ec49dae9a4b6be77ca1068c80313217ddd838c0303583939b5", transactionIndex: "38", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000005da2c34", contractAddress: "", cumulativeGasUsed: "2095940", gasUsed: "22605", confirmations: "3363717"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "98184244"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "98184244", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1507628888 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"87532972\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x8253223030561a07e953e574284ac8fa64af885c3fed79d8e08e4c9dbbe05dd7", nonce: "95", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "24", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e6000000000000000000000000000000000000000000000000000000000537a5ac", contractAddress: "", cumulativeGasUsed: "1064259", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "87532972"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "87532972", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"18498762\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x67874805bd141a2a8c403f659f62cb2c079a65647c42cb82a67e2a1bb9c21521", nonce: "96", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "45", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000011a44ca", contractAddress: "", cumulativeGasUsed: "1961223", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "18498762"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "18498762", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"31992889\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x64c557bab18c224cb2bb3fe43a4b16b22c16af35c0a89851dca394a7c4ed7e25", nonce: "97", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "64", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000001e82c39", contractAddress: "", cumulativeGasUsed: "2486629", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "31992889"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "31992889", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"37738113\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x6643b0adc2971c9e500fc70bf0a3a0541886a825373319771aca489e05727167", nonce: "98", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "77", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000023fd681", contractAddress: "", cumulativeGasUsed: "2839163", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "37738113"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "37738113", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"6487973\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xd9692384f3e10de6dace211db7d4244e5a2670e81efa155f3db71a59715db80f", nonce: "99", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "95", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e6000000000000000000000000000000000000000000000000000000000062ffa5", contractAddress: "", cumulativeGasUsed: "3327244", gasUsed: "22541", confirmations: "3363715"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "6487973"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "6487973", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"82044703\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xdf928deee275f50fa6599eaae10db916fc4134353a6f51a0c787666d827658e4", nonce: "100", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "104", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000004e3e71f", contractAddress: "", cumulativeGasUsed: "3627226", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "82044703"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "82044703", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"69338105\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xbf27b5ebc2b3169b17cc1fd132c1ccbce361d6d7cf4e2d6853dda66423cfcebe", nonce: "101", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "110", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000042203f9", contractAddress: "", cumulativeGasUsed: "3861817", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "69338105"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "69338105", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"2255393\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x34cc0166901faed24f4e50d9ef629eb4bd6f9d6cf0a0f520e3e7f077419b74ad", nonce: "102", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "114", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000000226a21", contractAddress: "", cumulativeGasUsed: "4025561", gasUsed: "22541", confirmations: "3363715"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "2255393"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "2255393", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"129736\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xa4f1140b81d180c1fbb7337423c4cf1b5f2a51b806355627949485b43d8f86b2", nonce: "103", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "121", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e6000000000000000000000000000000000000000000000000000000000001fac8", contractAddress: "", cumulativeGasUsed: "4265387", gasUsed: "22541", confirmations: "3363715"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "129736"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "129736", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"1258199\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x22056ad4485f1bc8ce549adc273cdc6a2dc94ab32c3f87c00a584a800013782a", nonce: "104", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "124", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000001332d7", contractAddress: "", cumulativeGasUsed: "4376784", gasUsed: "22541", confirmations: "3363715"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "1258199"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "1258199", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"27130363\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x32dff782689c8437c5a13e25bb7c70f9baff9f63ec5dc6ca8a06f163be40880f", nonce: "105", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "129", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000019df9fb", contractAddress: "", cumulativeGasUsed: "4561010", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "27130363"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "27130363", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"45592042\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xc0409c6344e338c023e1d6c55e93d30512ef55276953d890d59f6c29933d5425", nonce: "106", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "133", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000002b7adea", contractAddress: "", cumulativeGasUsed: "4708407", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "45592042"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "45592042", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"51351996\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xf56b43fe658408ac3538c6d13e19c39187c1fb20cc88018d60a842e871c0bbe0", nonce: "107", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "138", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000030f91bc", contractAddress: "", cumulativeGasUsed: "4878172", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "51351996"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "51351996", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"23845547\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x6da6ac3392f2e6fdddb7a5dc809f8d17c2460d9077233066f6d0036ca19bca24", nonce: "108", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "142", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e600000000000000000000000000000000000000000000000000000000016bdaab", contractAddress: "", cumulativeGasUsed: "5025062", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "23845547"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "23845547", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"72853046\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xc83e1c7e99462f1d0b949215a504034eaaa7ed1c6b62f577d1cc605ce4fb1599", nonce: "109", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "146", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e6000000000000000000000000000000000000000000000000000000000457a636", contractAddress: "", cumulativeGasUsed: "5172586", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "72853046"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "72853046", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"70498890\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x9d4cfc41af27132cdbc427ea06ff0c4c5114467d7e10a0699e31e4779674bff0", nonce: "110", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "149", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e6000000000000000000000000000000000000000000000000000000000433ba4a", contractAddress: "", cumulativeGasUsed: "5268320", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "70498890"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "70498890", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"98766695\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xeb354c76c07d4afadb99a012fc952db0b45e4b511779b37f256ebe5429f821c8", nonce: "111", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "152", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000005e30f67", contractAddress: "", cumulativeGasUsed: "5332925", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "98766695"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "98766695", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"95111767\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xdf761e1140e0f72d09fce05c46b8aa47292576c9ca8ff6a2312d576223e0406b", nonce: "112", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "155", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000005ab4a57", contractAddress: "", cumulativeGasUsed: "5397530", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "95111767"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "95111767", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"52598936\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0xf753f6e263577c860027008e22ad4da7e5702e04322d46415123eac06c78cde3", nonce: "113", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "157", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000003229898", contractAddress: "", cumulativeGasUsed: "5441135", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "52598936"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "52598936", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: StartRollDice( \"47325320\" )", async function( ) {
		const txOriginal = {blockNumber: "4353085", timeStamp: "1507628927", hash: "0x949edd67bbedc87442e282193885a160e009a399b75273ea3d9804ecd8159cc9", nonce: "114", blockHash: "0x2477f56fa915efcbca69762eda93c829e14aa311bb229bff8cf9a4866037d451", transactionIndex: "161", from: "0x5590844099dc04b3df7d1484f099fb90c1a27ab4", to: "0x86a9925d7aa172f2c0307154fb736e89f32c6155", value: "0", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x143bb3e60000000000000000000000000000000000000000000000000000000002d22088", contractAddress: "", cumulativeGasUsed: "5526740", gasUsed: "22605", confirmations: "3363715"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint32", name: "seed", value: "47325320"}], name: "StartRollDice", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "StartRollDice(uint32)" ]( "47325320", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1507628927 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "16770592823995561" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4119019202560341378" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
