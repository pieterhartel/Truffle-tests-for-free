const MultiSigWallet = artifacts.require( "./MultiSigWallet.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "MultiSigWallet" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x0F4a28085713c1a5DEdc5D6f471c79AFe2d9321e", "0x62fe4618FD2Fc2bfC9b55a4B5bDEea38f1cDd2F9", "0x251698D6b3bEBc4Ea832298b1590f24129abF019", "0x180d78d45c334A4036080203E4382c793b10Ae4e", "0xA76cbD14D314AF489775118008A572244E7aB416", "0xc95dd06013f5C96D87a1e38B118e441b2f5bC749", "0x2D5FAD21f6Db9dd744bD80554Ce0f4D27bf0b618", "0x6979b9a44F1d9432876fDFE8043Cbb9A1F3dA82a", "0xfF0F75e25D28D25c91E7e735604253Cc4014A48e", "0x009248c8121Ba5bB41BaB11017cB9563ca5099Ab", "0x53ee38E76092D91abC67c6f8753FCcFbE7F938af", "0xba2184520A1cC49a6159c57e61E1844E085615B6", "0xC464a555d8405d3dF27d6f883913C51781FD5059", "0xc878298E73cCC979bAa6D475c2aCa111c5a4Afb6"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "uint256"}], name: "owners", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "isOwner", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}, {name: "", type: "address"}], name: "confirmations", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "pending", type: "bool"}, {name: "executed", type: "bool"}], name: "getTransactionCount", outputs: [{name: "count", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "transactionId", type: "uint256"}], name: "isConfirmed", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "transactionId", type: "uint256"}], name: "getConfirmationCount", outputs: [{name: "count", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "transactions", outputs: [{name: "destination", type: "address"}, {name: "value", type: "uint256"}, {name: "data", type: "bytes"}, {name: "executed", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "getOwners", outputs: [{name: "", type: "address[]"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "from", type: "uint256"}, {name: "to", type: "uint256"}, {name: "pending", type: "bool"}, {name: "executed", type: "bool"}], name: "getTransactionIds", outputs: [{name: "_transactionIds", type: "uint256[]"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "transactionId", type: "uint256"}], name: "getConfirmations", outputs: [{name: "_confirmations", type: "address[]"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "transactionCount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "MAX_OWNER_COUNT", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "required", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Revocation", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "ExecutionFailure", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Deposit", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}], name: "OwnerAddition", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}], name: "OwnerRemoval", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "required", type: "uint256"}], name: "RequirementChange", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["Confirmation(address,uint256)", "Revocation(address,uint256)", "Submission(uint256)", "Execution(uint256)", "ExecutionFailure(uint256)", "Deposit(address,uint256)", "OwnerAddition(address)", "OwnerRemoval(address)", "RequirementChange(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x4a504a94899432a9846e1aa406dceb1bcfd538bb839071d49d1e5e23f5be30ef", "0xf6a317157440607f36269043eb55f1287a5a19ba2216afeab88cd46cbcfb88e9", "0xc0ba8fe4b176c1714197d43b9cc6bcf797a4a7461c5fe8d0ef6e184ae7601e51", "0x33e13ecb54c3076d8e8bb8c2881800a4d972b792045ffae98fdf46df365fed75", "0x526441bb6c1aba3c9a4a6ca1d6545da9c2333c8c48343ef398eb858d72b79236", "0xe1fffcc4923d04b559f4d29a8bfc6cda04eb5b0d3c460751c2402c5c5cc9109c", "0xf39e6e1eb0edcf53c221607b54b00cd28f3196fed0a24994dc308b8f611b682d", "0x8001553a916ef2f495d26a907cc54d96ed840d7bda71e73194bf5a9df7a76b90", "0xa3f1ee9126a074d9326c682f561767f710e927faa811f7a99829d49dc421797a"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4361377 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4705358 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address[]", name: "_owners", value: [4, 5, 6, 3]}, {type: "uint256", name: "_required", value: "2"}], name: "MultiSigWallet", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "owners", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owners(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isOwner", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isOwner(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}, {type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "confirmations", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "confirmations(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bool", name: "pending", value: ( random.range( 2 ) === 0 )}, {type: "bool", name: "executed", value: ( random.range( 2 ) === 0 )}], name: "getTransactionCount", outputs: [{name: "count", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTransactionCount(bool,bool)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "transactionId", value: random.range( maxRandom )}], name: "isConfirmed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isConfirmed(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "transactionId", value: random.range( maxRandom )}], name: "getConfirmationCount", outputs: [{name: "count", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getConfirmationCount(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "transactions", outputs: [{name: "destination", type: "address"}, {name: "value", type: "uint256"}, {name: "data", type: "bytes"}, {name: "executed", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "transactions(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getOwners", outputs: [{name: "", type: "address[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getOwners()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "from", value: random.range( maxRandom )}, {type: "uint256", name: "to", value: random.range( maxRandom )}, {type: "bool", name: "pending", value: ( random.range( 2 ) === 0 )}, {type: "bool", name: "executed", value: ( random.range( 2 ) === 0 )}], name: "getTransactionIds", outputs: [{name: "_transactionIds", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTransactionIds(uint256,uint256,bool,bool)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "transactionId", value: random.range( maxRandom )}], name: "getConfirmations", outputs: [{name: "_confirmations", type: "address[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getConfirmations(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "transactionCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "transactionCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_OWNER_COUNT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_OWNER_COUNT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "required", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "required()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "MultiSigWallet", function( accounts ) {

	it( "TEST: MultiSigWallet( [addressList[4],addressList[5],addressLi... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4361377", timeStamp: "1507874511", hash: "0xd7871d0bb6caee9c9207ce260ab1759a96000ddb07539a762c4af32c412ea2b5", nonce: "22", blockHash: "0x5f4665942a5ad04ce52e51ab1bdfadec372d61c8b7014dcd52b94bd1e362b5a3", transactionIndex: "21", from: "0x62fe4618fd2fc2bfc9b55a4b5bdeea38f1cdd2f9", to: 0, value: "0", gas: "3046440", gasPrice: "32982836542", isError: "0", txreceipt_status: "", input: "0xe5c46944000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000004000000000000000000000000251698d6b3bebc4ea832298b1590f24129abf019000000000000000000000000180d78d45c334a4036080203e4382c793b10ae4e000000000000000000000000a76cbd14d314af489775118008a572244e7ab41600000000000000000000000062fe4618fd2fc2bfc9b55a4b5bdeea38f1cdd2f9", contractAddress: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", cumulativeGasUsed: "3725582", gasUsed: "2538700", confirmations: "3357147"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_owners", value: [addressList[4],addressList[5],addressList[6],addressList[3]]}, {type: "uint256", name: "_required", value: "2"}], name: "MultiSigWallet", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = MultiSigWallet.new( [addressList[4],addressList[5],addressList[6],addressList[3]], "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1507874511 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = MultiSigWallet.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245341696973734745" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4388228", timeStamp: "1508399709", hash: "0x95211d8e356870b41b700264efc311c37f42dbbee56d8041dfb93695d576c1e7", nonce: "18", blockHash: "0x41b34844b2cb22f1d325b717c46a9c6702668a8a28c9929ed2b9fea2f2c9d987", transactionIndex: "86", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "200000000000000000", gas: "21000", gasPrice: "1000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "4509005", gasUsed: "21000", confirmations: "3330296"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4388248", timeStamp: "1508399902", hash: "0x820914eeabbc6ee3d86d59906e361e6d237356bd2200815c7981c3784a6865d2", nonce: "19", blockHash: "0xeee9e4591a8c666918ad0ff90f2d66088a611dcdfef1040e3d2947f15f732955", transactionIndex: "30", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "200000000000000000", gas: "21000", gasPrice: "1000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "3689694", gasUsed: "21000", confirmations: "3330276"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4388268", timeStamp: "1508400214", hash: "0x9c43b818455f4548b091897127a80393574c956f323b04964169643a7a2d2121", nonce: "20", blockHash: "0x565c30358bffd1afe04152098f65eace58166315a30b15d188834245585a0192", transactionIndex: "11", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "200000000000000000", gas: "51000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1132718", gasUsed: "22510", confirmations: "3330256"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1508400214 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "value", type: "uint256", value: "200000000000000000"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[4], \"200000000000000000\", ... )", async function( ) {
		const txOriginal = {blockNumber: "4388347", timeStamp: "1508401182", hash: "0xc967688f921a504996039c12f125efe6c0c0c1dc15e68a42cbd701cf55fe2104", nonce: "0", blockHash: "0x8a14c05da881f3d59a8c24c3a457a37317a207f7b2992e49993765c37c8f7ca7", transactionIndex: "32", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "142872", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000251698d6b3bebc4ea832298b1590f24129abf01900000000000000000000000000000000000000000000000002c68af0bb140000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1445647", gasUsed: "142872", confirmations: "3330177"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[4]}, {type: "uint256", name: "value", value: "200000000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[4], "200000000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1508401182 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "0"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "0"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4388362", timeStamp: "1508401367", hash: "0xa14f452d574c60020037d796f4aa42741bba69b985e107d3d44ebb4634ff26c0", nonce: "21", blockHash: "0x17c5fca4ef6aebab841d65e9925044a6233a190949ac11b10bc547d5d0c0ef80", transactionIndex: "27", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "79961", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "844893", gasUsed: "78902", confirmations: "3330162"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "0"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1508401367 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "0"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "0"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4388418", timeStamp: "1508402079", hash: "0x0c676aa34eba78b78e93dc39bc680ffc0c7b5eb97d984384427e6b7ae08b35d0", nonce: "22", blockHash: "0x8996426d53fe175dbf9ba414fc3947f7a284528edb8ae3ef351fe11057e2fdde", transactionIndex: "4", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "101800000000000000000", gas: "22510", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "106510", gasUsed: "22510", confirmations: "3330106"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "101800000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1508402079 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Deposit", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Deposit", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "value", type: "uint256", value: "101800000000000000000"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"79676400000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4413633", timeStamp: "1508750802", hash: "0x35acd63b36b8e2615c6dba3454eb7c105a5fbbbf65f7c836295d51be49bdada2", nonce: "1", blockHash: "0xb2e9069e89c35c6555bc0338a55d4e27f5559d1c718f884da7701d55c6ca253d", transactionIndex: "29", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127936", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc74900000000000000000000000000000000000000000000000451bb6fa805ef0000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1696901", gasUsed: "127936", confirmations: "3304891"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "79676400000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "79676400000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1508750802 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "1"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "1"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4413675", timeStamp: "1508751370", hash: "0x3103b9520dda13546aa943b78ec1f5435d6e1d613c112b10696a5c7daf3191c0", nonce: "24", blockHash: "0x932646f183267e781c91c24e5d315b45d021fdd7edf62e87c1425456832cfafe", transactionIndex: "62", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "110025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1968666", gasUsed: "78966", confirmations: "3304849"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "1"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1508751370 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "1"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "1"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[8], \"122270000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4414241", timeStamp: "1508759601", hash: "0x023d5c9f7b61367112e6c4477a15b76ec3d7d2d29efaf7a0343cb2cb5a78f484", nonce: "2", blockHash: "0x97cfb2268efb819578b73a2c15ad41f62d9e6dda3e76d378d9ca7575daceb0ae", transactionIndex: "86", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127936", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc64274740000000000000000000000002d5fad21f6db9dd744bd80554ce0f4d27bf0b618000000000000000000000000000000000000000000000006a0d64d2f8f030000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3801111", gasUsed: "127936", confirmations: "3304283"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[8]}, {type: "uint256", name: "value", value: "122270000000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[8], "122270000000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1508759601 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "2"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "2"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4417737", timeStamp: "1508807280", hash: "0xe0069182b83419d99c1fab3b5d00dbdddfd20ecbbf91d2c265238f2f6a54b165", nonce: "25", blockHash: "0x2d629d5f934aeb95c10aaf4343761667a6fca10356113603e44ee21484b4d891", transactionIndex: "22", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "135025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "1690651", gasUsed: "103966", confirmations: "3300787"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "2"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1508807280 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "2"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "2"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[9], \"10000000000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4419161", timeStamp: "1508827597", hash: "0xd17de8db9fdb0b72ee14a2b4ee131453a0ba58dc7ddf9862edb9f66d47533b18", nonce: "3", blockHash: "0xb1404ed0d20d9abb909681dce797bbdb5950aedb0099a9e72f4909e8ad6c4891", transactionIndex: "49", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127872", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc64274740000000000000000000000006979b9a44f1d9432876fdfe8043cbb9a1f3da82a0000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1399073", gasUsed: "127872", confirmations: "3299363"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[9]}, {type: "uint256", name: "value", value: "10000000000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[9], "10000000000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1508827597 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "3"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "3"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4420220", timeStamp: "1508842062", hash: "0x8e263a6719911641df8b5680240184e6543cccd8e9ed6588608e474ba3fe1e9e", nonce: "26", blockHash: "0xcde98027b8f5419236abff2fbd4875eb78d1ec29fbb64eea1cfb3a7288309cf0", transactionIndex: "58", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "110025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "6586469", gasUsed: "78966", confirmations: "3298304"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "3"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1508842062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "3"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "3"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"174893300000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4431649", timeStamp: "1509001507", hash: "0x61799175ca451dd5bc7720c07244fd242b9b6a0f0fa44b589643ecaa31c75aba", nonce: "4", blockHash: "0xcf5d1606659efc5a58609c552be22b2ff85d600d66028ec802a08cf2caf97f6e", transactionIndex: "52", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "128000", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc7490000000000000000000000000000000000000000000000097b21d1b9bfd34000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5365758", gasUsed: "128000", confirmations: "3286875"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "174893300000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "174893300000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1509001507 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "4"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "4"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"4\" )", async function( ) {
		const txOriginal = {blockNumber: "4431869", timeStamp: "1509004282", hash: "0x2aa6fc2c03f41f8c856fc174d9306f8aae9d75e5c718b8020a0aa8ef00c853bf", nonce: "27", blockHash: "0xe9ac28367c7aee4cbb851f81761a32547389feb5ba9ad94760379984c20c367d", transactionIndex: "89", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "110025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000004", contractAddress: "", cumulativeGasUsed: "5711118", gasUsed: "78966", confirmations: "3286655"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "4"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "4", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1509004282 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "4"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "4"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"76845200000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4432457", timeStamp: "1509013077", hash: "0x8432977302a16702589133cacc3d3b028ffdde97bc883e9b8eef348d6626d17d", nonce: "5", blockHash: "0xa4b35ec3a544e6e031f0b9568881b1795e49ba1cb5cf8222fb4d1ee9f3e2c9a5", transactionIndex: "43", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127936", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc7490000000000000000000000000000000000000000000000042a70fe41b5d90000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4911991", gasUsed: "127936", confirmations: "3286067"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "76845200000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "76845200000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1509013077 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "5"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "5"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4432760", timeStamp: "1509017488", hash: "0x76ab2c2d1149426e2e405aa8488ad7578471005d9d774f65567abfa9b16f092d", nonce: "28", blockHash: "0xd21063c6fd0dd11303e9f38fa5aed01fba423bc6877cb3483bbfd4d9b741f468", transactionIndex: "47", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "110025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "2279888", gasUsed: "78966", confirmations: "3285764"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "5"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1509017488 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "5"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "5"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"166214600000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4456906", timeStamp: "1509353906", hash: "0x751e088bf6988c20c7799051e900a9380c276c3bf047c6194b74b8f2de8d5658", nonce: "6", blockHash: "0xfbd4dc279c8aefc78cede45f5c45812ec473bc8d5f3570fed0171a1e43555723", transactionIndex: "98", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "128000", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc74900000000000000000000000000000000000000000000000902b0e20eaba48000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6647870", gasUsed: "128000", confirmations: "3261618"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "166214600000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "166214600000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1509353906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "6"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "6"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"6\" )", async function( ) {
		const txOriginal = {blockNumber: "4456942", timeStamp: "1509354389", hash: "0xc4184a4f438a6fe28cab241da59f2227fb6892508c5da2ff509ca57a187482f2", nonce: "29", blockHash: "0xb21beae9fe7d628ce251a08be4076f53d7cef494e48be27c16bf2c46c1a07af2", transactionIndex: "67", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "110025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000006", contractAddress: "", cumulativeGasUsed: "5740892", gasUsed: "78966", confirmations: "3261582"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "6"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1509354389 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "6"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "6"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[10], \"667000000000000000\",... )", async function( ) {
		const txOriginal = {blockNumber: "4457755", timeStamp: "1509365616", hash: "0xcfe3137099bdd90468d14b78c19985dcb8f971b4819fbc153339d1623aa556c8", nonce: "7", blockHash: "0x18ef1665ee7ff373450919b00a989d26581a200d64217e1e1cdf19b1d5151826", transactionIndex: "80", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127936", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000ff0f75e25d28d25c91e7e735604253cc4014a48e0000000000000000000000000000000000000000000000000941a8f7512f8000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6671413", gasUsed: "127936", confirmations: "3260769"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[10]}, {type: "uint256", name: "value", value: "667000000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[10], "667000000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1509365616 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "7"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "7"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "4458095", timeStamp: "1509370179", hash: "0xde631cf8db1c5ea09bf4525e17bc7f8221fbe2ef5e723103a7ef578c58a7294d", nonce: "30", blockHash: "0x57b47c33d6d9459f974908c16e19eda282f62b101702d67feeff4d763ed925ec", transactionIndex: "45", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "110025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "4477405", gasUsed: "78966", confirmations: "3260429"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "7"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1509370179 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "7"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "7"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[10], \"166000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4461781", timeStamp: "1509422605", hash: "0x7d9598863270c1c856927d4cff9faa2d08e7f5d9fd99f35cfa6e134829d42d76", nonce: "8", blockHash: "0x4edc73e3ce926eafe2fa6cf97c1a5d7f5d665cceee324162df3515e0e858a2b3", transactionIndex: "48", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127936", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000ff0f75e25d28d25c91e7e735604253cc4014a48e000000000000000000000000000000000000000000000008ffb6787e8ad80000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6343375", gasUsed: "127936", confirmations: "3256743"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[10]}, {type: "uint256", name: "value", value: "166000000000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[10], "166000000000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1509422605 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "8"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "8"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"8\" )", async function( ) {
		const txOriginal = {blockNumber: "4462556", timeStamp: "1509433180", hash: "0xc693ff92dabd5542fd42a2f3e43df198113df32f7f3b6361c69a94444143a791", nonce: "31", blockHash: "0x30c1a83fb6b4b548a8505a0a7b1abd8cdbfb184a697296d8475ac809f00091b4", transactionIndex: "112", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "110025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000008", contractAddress: "", cumulativeGasUsed: "3313331", gasUsed: "78966", confirmations: "3255968"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "8"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509433180 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "8"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "8"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[11], \"2578500000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4475338", timeStamp: "1509612264", hash: "0xe2cb110b14ecf2455f598282d4251f23292f943a7d9ae28e55715f8e8265f4d1", nonce: "9", blockHash: "0xcd6707055420100c2679aeab1bd63078683e0f7d302a389010b61014536f8b28", transactionIndex: "42", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127872", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000009248c8121ba5bb41bab11017cb9563ca5099ab00000000000000000000000000000000000000000000000023c8ac16a9584000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5767390", gasUsed: "127872", confirmations: "3243186"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[11]}, {type: "uint256", name: "value", value: "2578500000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[11], "2578500000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509612264 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "9"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "9"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "4475808", timeStamp: "1509618357", hash: "0xe37181203cfe6e12cd7a46f7e4b8357180eecea8b3b1e3c4da6688058802fc26", nonce: "32", blockHash: "0x52847810234b62395593a953791749a0ecf58c3ea57f5a359fc19b26bcb4e8f0", transactionIndex: "49", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "135025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "1640736", gasUsed: "103966", confirmations: "3242716"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "9"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509618357 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "9"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "9"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"204748500000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4481499", timeStamp: "1509697977", hash: "0x8197920b248f43fc9933c829744441145e7b54f35944adb45083f8a15ca46339", nonce: "10", blockHash: "0x988574a9d9e72bdd61dc4b7a6f8789ad7a2a6e2a23efbbb4d068379fbc885724", transactionIndex: "104", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "128000", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc74900000000000000000000000000000000000000000000000b1974cbf22a114000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5724219", gasUsed: "128000", confirmations: "3237025"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "204748500000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "204748500000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509697977 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "10"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "10"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4481560", timeStamp: "1509698779", hash: "0x33dc3b6d11bbb67daf2afde1a36c0def93253655a078809a19335efc290c2e36", nonce: "33", blockHash: "0x0d4a712641137fab5fbd800de06996f0063819518227d92e5ad1b03a0e5aa941", transactionIndex: "75", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "110025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c84000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "2345826", gasUsed: "78966", confirmations: "3236964"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "10"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509698779 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "10"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "10"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4512472", timeStamp: "1510127538", hash: "0x30ca89df1c19b8132c7ca25c2a16f74437cbf1d1d5c93cd9217e62c161795dde", nonce: "87", blockHash: "0x73496a47bc3d1f09ca10953ffd91374680175a86f86ab0e966ba046de8fc5b8f", transactionIndex: "10", from: "0x53ee38e76092d91abc67c6f8753fccfbe7f938af", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "28000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x66756e6374696f6e2077697468647261772829207b0d0a202020206d73672e73656e6465722e7472616e7366657228746869732e62616c616e6365293b0d0a7d", contractAddress: "", cumulativeGasUsed: "316272", gasUsed: "25901", confirmations: "3206052"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510127538 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "24988550000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"11\", \"0x\" )", async function( ) {
		const txOriginal = {blockNumber: "4525997", timeStamp: "1510315853", hash: "0x6b33e418cbf09d1f84aed537ec4f1be64a976bba4de2cd0b40e5c9264b3dac4b", nonce: "11", blockHash: "0x39ab0e5e453f12cb8facb6d022b2e519af2027c85256679cb1af63913fbadab3", transactionIndex: "133", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127552", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc749000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5924685", gasUsed: "127552", confirmations: "3192527"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "11"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "11", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510315853 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "11"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "11"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"11\" )", async function( ) {
		const txOriginal = {blockNumber: "4527112", timeStamp: "1510331206", hash: "0x4bdca2548f9fcf644c5496722b5591544506b8fdb4d1d1fe4fdc55528542fc84", nonce: "36", blockHash: "0x19e2a270d260976472ddf23f22c3b505d65ebaea3fdfb7d169caa3187419c073", transactionIndex: "29", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "110025", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c84000000000000000000000000000000000000000000000000000000000000000b", contractAddress: "", cumulativeGasUsed: "1058044", gasUsed: "78966", confirmations: "3191412"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "11"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510331206 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "11"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "11"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"266997700000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4529543", timeStamp: "1510364367", hash: "0x2a89b78169ceaec441de3a19bf8220ca5d5e35948fad68fb7985d80545f8f211", nonce: "12", blockHash: "0x89f3d0d8d0c867a4065e318d2740471affc78326ffff5e9111081c4359eb5dd7", transactionIndex: "142", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "128000", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc74900000000000000000000000000000000000000000000000e795661891a504000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6674922", gasUsed: "128000", confirmations: "3188981"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "266997700000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "266997700000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510364367 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "12"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "12"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "4529593", timeStamp: "1510365167", hash: "0x0f3d8ced9fd504d6e59ff226e18890daec8ada2ef24b2ee835739d7f1c4cf2e1", nonce: "17", blockHash: "0x025933f418d17860e560d758d13bf5bc171a416e871203df064ef1371a004ef5", transactionIndex: "0", from: "0xa76cbd14d314af489775118008a572244e7ab416", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "111466", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c84000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "80407", gasUsed: "80407", confirmations: "3188931"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "12"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510365167 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0xa76cbd14d314af489775118008a572244e7ab416"}, {name: "transactionId", type: "uint256", value: "12"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "12"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "108675609500000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"12662200000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4529665", timeStamp: "1510366038", hash: "0xb36c7bcb8b65c0fd71cdefeb55524123fc36f9ab09bf07e8689303e9bc3f10c9", nonce: "13", blockHash: "0x51ade1b9937506a99d115571d3969ab1a12c9f86cba4b8e5bf674ba8fed64a55", transactionIndex: "17", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127936", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc749000000000000000000000000000000000000000000000000afb92bd012f38000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "580383", gasUsed: "127936", confirmations: "3188859"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "12662200000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "12662200000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510366038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "13"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "13"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "4529813", timeStamp: "1510368185", hash: "0x0a8480d6f4b4f9c83d0b56dbd67d9268a393ddc8e50276a3da4a0f87330d5de4", nonce: "18", blockHash: "0x717e412c391d7f896567c05179661f79bd9551d7fcb2a04e4c04b3bfa903bf4f", transactionIndex: "21", from: "0xa76cbd14d314af489775118008a572244e7ab416", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "111466", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c84000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "986761", gasUsed: "80407", confirmations: "3188711"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "13"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510368185 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0xa76cbd14d314af489775118008a572244e7ab416"}, {name: "transactionId", type: "uint256", value: "13"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "13"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "108675609500000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[13], \"0\", \"0xa9059cbb0000... )", async function( ) {
		const txOriginal = {blockNumber: "4531066", timeStamp: "1510385670", hash: "0xd29ac929a12e823dbad76b22527152695909724e34481c650eb63a3677f3f787", nonce: "19", blockHash: "0x160a32a3853bd339fd61f099fc83aea48a32f44af4f6ca90678afb7fdb9ea55c", transactionIndex: "3", from: "0xa76cbd14d314af489775118008a572244e7ab416", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "174925", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000ba2184520a1cc49a6159c57e61e1844e085615b6000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000044a9059cbb000000000000000000000000edb26d4abfbf40cd4a1a2ef0b89e8244f892f6930000000000000000000000000000000000000000000000000000095e27d7580000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "237925", gasUsed: "174925", confirmations: "3187458"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[13]}, {type: "uint256", name: "value", value: "0"}, {type: "bytes", name: "data", value: "0xa9059cbb000000000000000000000000edb26d4abfbf40cd4a1a2ef0b89e8244f892f6930000000000000000000000000000000000000000000000000000095e27d75800"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[13], "0", "0xa9059cbb000000000000000000000000edb26d4abfbf40cd4a1a2ef0b89e8244f892f6930000000000000000000000000000000000000000000000000000095e27d75800", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510385670 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0xa76cbd14d314af489775118008a572244e7ab416"}, {name: "transactionId", type: "uint256", value: "14"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "14"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "108675609500000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"14\" )", async function( ) {
		const txOriginal = {blockNumber: "4531154", timeStamp: "1510386966", hash: "0x13ec124338779eaf874eb9186af5f01e945bf4fa4c86a1ac665eef92db53fcd3", nonce: "14", blockHash: "0xaa5ec14b42da40ff0c1467204b01761ed2a5d3c9d3904f5e624d9800b3a8327d", transactionIndex: "115", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "257342", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c84000000000000000000000000000000000000000000000000000000000000000e", contractAddress: "", cumulativeGasUsed: "4471673", gasUsed: "212094", confirmations: "3187370"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "14"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "14", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510386966 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "14"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[35,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "14"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[35,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"208701500000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4593704", timeStamp: "1511256165", hash: "0x20e844d3086eb01956e2f62a9c17710d3f2b79118fe336aec454ca20343b9c32", nonce: "15", blockHash: "0x7517e57ecd0742982cad9dc6b89801a8924a9fbf374338df7f1839634b8ea9c1", transactionIndex: "47", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "128000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc74900000000000000000000000000000000000000000000000b5050ac80872fc000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2352211", gasUsed: "128000", confirmations: "3124820"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "208701500000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "208701500000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1511256165 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "15"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "15"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"15\" )", async function( ) {
		const txOriginal = {blockNumber: "4593831", timeStamp: "1511257883", hash: "0x8bb088c3796ca8b822783b4775820e22f4dce6380b171087d190c4110454c183", nonce: "33", blockHash: "0xa85b609d6d2f82d5714fd783ebada7cdd15cfc311e7a151f81ec3d3373ae752d", transactionIndex: "67", from: "0x62fe4618fd2fc2bfc9b55a4b5bdeea38f1cdd2f9", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "82907", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c84000000000000000000000000000000000000000000000000000000000000000f", contractAddress: "", cumulativeGasUsed: "4264332", gasUsed: "81848", confirmations: "3124693"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "15"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "15", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1511257883 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x62fe4618fd2fc2bfc9b55a4b5bdeea38f1cdd2f9"}, {name: "transactionId", type: "uint256", value: "15"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[37,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "15"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[37,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245341696973734745" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"92356100000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4612505", timeStamp: "1511518131", hash: "0xc3a2eeec7945a60e0d6a1202a45ba0a301ad5f312129389f4b6453d6ac0244e6", nonce: "16", blockHash: "0xb9807f415c0efcad6353f888f669d5e95f72587a4ceea40aec6369e339a40927", transactionIndex: "118", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "128000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc74900000000000000000000000000000000000000000000000501b2c7a05c744000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5071957", gasUsed: "128000", confirmations: "3106019"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "92356100000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "92356100000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1511518131 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "16"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "16"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"16\" )", async function( ) {
		const txOriginal = {blockNumber: "4613363", timeStamp: "1511530273", hash: "0xd9aa9f79008cc9b4277d4a2773e574dcdb0ee1035c8118e244144aa226874e3b", nonce: "20", blockHash: "0x54840d0a80b4201cea404dc2abb3b14d8df9eda2e85f209fe7a17241d7f858ac", transactionIndex: "26", from: "0xa76cbd14d314af489775118008a572244e7ab416", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "111466", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000010", contractAddress: "", cumulativeGasUsed: "1075739", gasUsed: "80407", confirmations: "3105161"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "16"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "16", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1511530273 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0xa76cbd14d314af489775118008a572244e7ab416"}, {name: "transactionId", type: "uint256", value: "16"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "16"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "108675609500000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"80298600000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "4640906", timeStamp: "1511917459", hash: "0xf527c43e674d22d0f35c84137501b44cbc1774f326acd9a7ad44d6b308d6d0b1", nonce: "17", blockHash: "0x4295839ed0ab5085bd71474b9947f4eb46cd5704235018675b6081f7ff1fefc8", transactionIndex: "94", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "128000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc7490000000000000000000000000000000000000000000000045a5def42812e8000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2658635", gasUsed: "128000", confirmations: "3077618"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "80298600000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "80298600000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1511917459 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "17"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "17"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"17\" )", async function( ) {
		const txOriginal = {blockNumber: "4640976", timeStamp: "1511918527", hash: "0x4f1bf4da827b53eab14b0b8264a7d7bac93aa342927003c4916885b9160c924c", nonce: "21", blockHash: "0xcb815f9f1586efdffd7c7f1d5d8fb541f3f29f89b2a1b4a538c03cdf1df22765", transactionIndex: "18", from: "0xa76cbd14d314af489775118008a572244e7ab416", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "111466", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000011", contractAddress: "", cumulativeGasUsed: "537604", gasUsed: "80407", confirmations: "3077548"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "17"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1511918527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0xa76cbd14d314af489775118008a572244e7ab416"}, {name: "transactionId", type: "uint256", value: "17"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "17"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "108675609500000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"533452500000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4653968", timeStamp: "1512100961", hash: "0x500affa337d7c67e9b4a1fee3ad4c5e43ebc501939a9824c33b96468edd1451a", nonce: "18", blockHash: "0xeb351c250cd2e3d44cb7cee1da0b30c790bece76201d3f815dfb1953d266f704", transactionIndex: "90", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "128000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc74900000000000000000000000000000000000000000000001ceb23fe65c4114000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3038573", gasUsed: "128000", confirmations: "3064556"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "533452500000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "533452500000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1512100961 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "18"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "18"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"18\" )", async function( ) {
		const txOriginal = {blockNumber: "4654007", timeStamp: "1512101561", hash: "0x8862511a5c2ddcecd662ab1bf6b37e4cdb73e76826b839e8b7b7b706da3a49c5", nonce: "22", blockHash: "0xa4ab9702b347ce184c836950ef5f19baeb0697f0deb3ebf2ad286380fce2ddbd", transactionIndex: "33", from: "0xa76cbd14d314af489775118008a572244e7ab416", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "111466", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000012", contractAddress: "", cumulativeGasUsed: "1405054", gasUsed: "80407", confirmations: "3064517"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "18"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1512101561 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0xa76cbd14d314af489775118008a572244e7ab416"}, {name: "transactionId", type: "uint256", value: "18"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "18"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "108675609500000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[7], \"100000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4673992", timeStamp: "1512387900", hash: "0x5395ea51afcb48a0e845060fc851d4ada261a038a41f0bf725e41976cec2450c", nonce: "20", blockHash: "0x96ce435024f130ea80d75f1187e5c023d08795704bc8f2a28b3d27f3410adc06", transactionIndex: "116", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127936", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c95dd06013f5c96d87a1e38b118e441b2f5bc7490000000000000000000000000000000000000000000000056bc75e2d63100000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3883559", gasUsed: "127936", confirmations: "3044532"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[7]}, {type: "uint256", name: "value", value: "100000000000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[7], "100000000000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1512387900 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "19"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "19"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"19\" )", async function( ) {
		const txOriginal = {blockNumber: "4674088", timeStamp: "1512389276", hash: "0xccd3be08b65d764e6d079dbb2cd131fce7279402259b826e90b5d552633c7590", nonce: "23", blockHash: "0x8f6352c3f7e86d45423966ef469d8e8a6a4d214d79b93e51418f2a7aa356e314", transactionIndex: "151", from: "0xa76cbd14d314af489775118008a572244e7ab416", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "111466", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000013", contractAddress: "", cumulativeGasUsed: "3775347", gasUsed: "80407", confirmations: "3044436"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "19"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "19", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1512389276 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0xa76cbd14d314af489775118008a572244e7ab416"}, {name: "transactionId", type: "uint256", value: "19"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "19"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "108675609500000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[14], \"76492000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4690703", timeStamp: "1512647274", hash: "0xf5161f43fd01e7f00dda4f08631006a4c2b3a3af1352f69cef2b80fb9d8f4938", nonce: "21", blockHash: "0xf178e735fb5fa2e70b8c5f484a6b051196df57c33ab46b541719e7318bf8da2d", transactionIndex: "130", from: "0x180d78d45c334a4036080203e4382c793b10ae4e", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127936", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c464a555d8405d3df27d6f883913c51781fd5059000000000000000000000000000000000000000000000004258a2cba5f2e0000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5012428", gasUsed: "127936", confirmations: "3027821"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[14]}, {type: "uint256", name: "value", value: "76492000000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[14], "76492000000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1512647274 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x180d78d45c334a4036080203e4382c793b10ae4e"}, {name: "transactionId", type: "uint256", value: "20"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "20"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "800534083300000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"20\" )", async function( ) {
		const txOriginal = {blockNumber: "4690800", timeStamp: "1512648873", hash: "0xa947a6a374505df7fd904a95b7311807ac7167f0ea68c7306331e5d485a89f84", nonce: "35", blockHash: "0x798fd1dae0f72cf745947d850cd89fee38be50ffea56895c8e78fd4bd41b52ea", transactionIndex: "26", from: "0x62fe4618fd2fc2bfc9b55a4b5bdeea38f1cdd2f9", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "199488", gasPrice: "65000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000014", contractAddress: "", cumulativeGasUsed: "984883", gasUsed: "81848", confirmations: "3027724"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "20"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "20", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1512648873 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x62fe4618fd2fc2bfc9b55a4b5bdeea38f1cdd2f9"}, {name: "transactionId", type: "uint256", value: "20"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "20"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "245341696973734745" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: submitTransaction( addressList[15], \"66534000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4701807", timeStamp: "1512812611", hash: "0xc564683e3be58aef6c7dea09945bec78cbf5840bc01a28626236fc98cb2452a1", nonce: "24", blockHash: "0x0e44a7330a9fb2940964553d1bddbeb4a8d3a01a280959ea13ca7a16e06a3de3", transactionIndex: "19", from: "0xa76cbd14d314af489775118008a572244e7ab416", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "127936", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0xc6427474000000000000000000000000c878298e73ccc979baa6d475c2aca111c5a4afb60000000000000000000000000000000000000000000000039b58407cddd70000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "874355", gasUsed: "127936", confirmations: "3016717"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "destination", value: addressList[15]}, {type: "uint256", name: "value", value: "66534000000000000000"}, {type: "bytes", name: "data", value: "0x"}], name: "submitTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "submitTransaction(address,uint256,bytes)" ]( addressList[15], "66534000000000000000", "0x", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1512812611 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0xa76cbd14d314af489775118008a572244e7ab416"}, {name: "transactionId", type: "uint256", value: "21"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Submission", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Submission", events: [{name: "transactionId", type: "uint256", value: "21"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "108675609500000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: confirmTransaction( \"21\" )", async function( ) {
		const txOriginal = {blockNumber: "4705358", timeStamp: "1512865173", hash: "0xf9e47f3aebf5712e966ec8fa4d1fe116b4c81b5fdb9269894b27918d3f04f414", nonce: "37", blockHash: "0x3d67e828f0a2c6011f5daae6df024a0c226acf540eab07972da418922dea45e6", transactionIndex: "90", from: "0x251698d6b3bebc4ea832298b1590f24129abf019", to: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e", value: "0", gas: "111466", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xc01a8c840000000000000000000000000000000000000000000000000000000000000015", contractAddress: "", cumulativeGasUsed: "5188670", gasUsed: "80407", confirmations: "3013166"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "transactionId", value: "21"}], name: "confirmTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "confirmTransaction(uint256)" ]( "21", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1512865173 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: true, name: "transactionId", type: "uint256"}], name: "Confirmation", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "Confirmation", events: [{name: "sender", type: "address", value: "0x251698d6b3bebc4ea832298b1590f24129abf019"}, {name: "transactionId", type: "uint256", value: "21"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "transactionId", type: "uint256"}], name: "Execution", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Execution", events: [{name: "transactionId", type: "uint256", value: "21"}], address: "0x0f4a28085713c1a5dedc5d6f471c79afe2d9321e"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "193120086329999999989" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
