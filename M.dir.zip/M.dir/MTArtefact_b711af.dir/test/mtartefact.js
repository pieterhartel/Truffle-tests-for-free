const MTArtefact = artifacts.require( "./MTArtefact.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "MTArtefact" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x4a152c146Ec60251C50817E2CFf25700d6b711AF", "0xeDA8256F424EAcbb9b2a6513de98D819E7496fb1", "0xF3E693175Db47264c99ECa0F1C1C4A2C1AeD3Bd7", "0xAaE1bE740222fB3F1125A7326fce947bbdB62b7E", "0x1feD8Ba9A9FDd72EF9038046ad148bEb413491b8", "0x7D2b3165093fE265E46c006430dBD4ad9ff3b4e9", "0x193Ce09Fa6E4fAB06A8B0d12e09C8b01Bc2F8826", "0xFc466835fB6CB2e74104Be497bea840921ed3931", "0xEc9D96c6dBd6b49536288BEf492475987142b556", "0xF1dF86E8B7c68835f35BF215eb2a464ce0397C2e", "0x5240aA95DD7E00046B7D55084e19EFb99369C4Fc", "0x112Ca729D9529F33Ea4d7a2150517cbB2B72B7FC", "0x398a20F8A91A7406343e75F4Ac1Eaad6902D3862", "0x02306C88829cBd1f4e7d23F371ec5c727F8b330C", "0x983961F34fC4cFC5EAfec371CDBA9d56fF8C1935", "0x9097bC3AAca7Ee7d92675951cB06dcDbEf1a878D", "0xbA7ffAFDa99Db8d7659cDFC3F0CA442a88CA398e", "0x0e8Ef4810093bcA816C69C3EB47fAA0fc9411BF2", "0xf2b670f65958Bd61561Dd3ab43c7E96cE7B7D40D", "0xE74ef81A02219a2646C2D1FB2e45A9a123Fd6fAC", "0x20C0C6Aad19f86B838C320D6deb140275Ce89d8A"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getApproved", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_index", type: "uint256"}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "TVTokenAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "manager", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "typesCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "exists", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_index", type: "uint256"}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "ownerOf", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "packs", outputs: [{name: "id", type: "uint256"}, {name: "name", type: "string"}, {name: "count", type: "uint256"}, {name: "price", type: "uint256"}, {name: "disabled", type: "bool"}, {name: "created", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "tokenURI", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "artefacts", outputs: [{name: "id", type: "uint256"}, {name: "typeId", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_operator", type: "address"}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "TVCrowdsaleAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}, {indexed: false, name: "packId", type: "uint256"}], name: "TokenReceived", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "rate", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "packId", type: "uint256"}], name: "ChangeAndBuyPack", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_approved", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_operator", type: "address"}, {indexed: false, name: "_approved", type: "bool"}], name: "ApprovalForAll", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TokenReceived(address,uint256,bytes,uint256)", "ChangeAndBuyPack(address,uint256,uint256,uint256)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)", "ApprovalForAll(address,address,bool)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x524c80c58733e169ff976380a0c7f2845b2b9263b1931ebfaf58ca70e6f1c76d", "0xcdc358e4c9a8abe9cf9abeb3a0c51769590448fa74b2b6fff07c1fccbe211189", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6366884 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6618006 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_TVTokenAddress", value: 4}, {type: "address", name: "_TVCrowdsaleAddress", value: 5}, {type: "address", name: "_manager", value: 6}, {type: "address", name: "_wallet", value: 3}, {type: "uint256", name: "_typesCount", value: "100"}], name: "MTArtefact", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getApproved", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getApproved(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "tokenOfOwnerByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenOfOwnerByIndex(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "TVTokenAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TVTokenAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "manager", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "manager()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "typesCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "typesCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "exists", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "exists(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_index", value: random.range( maxRandom )}], name: "tokenByIndex", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenByIndex(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "wallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "packs", outputs: [{name: "id", type: "uint256"}, {name: "name", type: "string"}, {name: "count", type: "uint256"}, {name: "price", type: "uint256"}, {name: "disabled", type: "bool"}, {name: "created", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "packs(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "tokenURI", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenURI(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "artefacts", outputs: [{name: "id", type: "uint256"}, {name: "typeId", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "artefacts(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isApprovedForAll(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "TVCrowdsaleAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TVCrowdsaleAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "MTArtefact", function( accounts ) {

	it( "TEST: MTArtefact( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6366884", timeStamp: "1537451931", hash: "0xbf437bce28b58ff98626de1330d307f38a241d70234b02174f31064172487c44", nonce: "2", blockHash: "0x9c84e112f431e1e686c1ea0c3f39ef56cfed0808756a560ebb2d463ee1a0faac", transactionIndex: "43", from: "0xeda8256f424eacbb9b2a6513de98d819e7496fb1", to: 0, value: "0", gas: "5000000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x27648803000000000000000000000000f3e693175db47264c99eca0f1c1c4a2c1aed3bd7000000000000000000000000aae1be740222fb3f1125a7326fce947bbdb62b7e0000000000000000000000001fed8ba9a9fdd72ef9038046ad148beb413491b8000000000000000000000000eda8256f424eacbb9b2a6513de98d819e7496fb10000000000000000000000000000000000000000000000000000000000000064", contractAddress: "0x4a152c146ec60251c50817e2cff25700d6b711af", cumulativeGasUsed: "6365862", gasUsed: "4388076", confirmations: "1342064"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_TVTokenAddress", value: addressList[4]}, {type: "address", name: "_TVCrowdsaleAddress", value: addressList[5]}, {type: "address", name: "_manager", value: addressList[6]}, {type: "address", name: "_wallet", value: addressList[3]}, {type: "uint256", name: "_typesCount", value: "100"}], name: "MTArtefact", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = MTArtefact.new( addressList[4], addressList[5], addressList[6], addressList[3], "100", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1537451931 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = MTArtefact.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "72883561900000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setPack( \"3\", `Gold`, \"10\", \"550000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6366958", timeStamp: "1537452912", hash: "0x221834e014d90692f7595a461bb7494979b21ae2d84ae4eb0c3f5fb163755c3e", nonce: "95", blockHash: "0x379319a3a29af859d92b7f344d78408b1ebc2db146b8a389ab497bd9b4b5d1c8", transactionIndex: "80", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "400000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0a069289000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000002fb474098f67c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004476f6c6400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3726434", gasUsed: "110806", confirmations: "1341990"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "3"}, {type: "string", name: "name", value: `Gold`}, {type: "uint256", name: "count", value: "10"}, {type: "uint256", name: "price", value: "55000000000000000000"}, {type: "bool", name: "disabled", value: false}], name: "setPack", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPack(uint256,string,uint256,uint256,bool)" ]( "3", `Gold`, "10", "55000000000000000000", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1537452912 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setPack( \"1\", `Wood`, \"3\", \"2000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6366964", timeStamp: "1537452985", hash: "0x2f6bea730fd250763f15023c2f0da37a198d430af6b163086d39841495bd3b2a", nonce: "96", blockHash: "0x8ca4ee0342f9c814dd5659b87e70f45605e3640cd7ca9643802186978579f5c6", transactionIndex: "28", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "400000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0a069289000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000001158e460913d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004576f6f6400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7220529", gasUsed: "110806", confirmations: "1341984"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}, {type: "string", name: "name", value: `Wood`}, {type: "uint256", name: "count", value: "3"}, {type: "uint256", name: "price", value: "20000000000000000000"}, {type: "bool", name: "disabled", value: false}], name: "setPack", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPack(uint256,string,uint256,uint256,bool)" ]( "1", `Wood`, "3", "20000000000000000000", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1537452985 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setPack( \"2\", `Silver`, \"5\", \"30000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6366972", timeStamp: "1537453109", hash: "0xbbc360276c118f51e0c604634efb4ec93417f976babaf706370dd77cd527ba9a", nonce: "97", blockHash: "0xbf61e42dddfc944250ce4e7bbc9c8b0eea1639eccaedc79c509e9939ce8eb5eb", transactionIndex: "69", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "400000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x0a069289000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000001a055690d9db800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000653696c7665720000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4863806", gasUsed: "110934", confirmations: "1341976"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "2"}, {type: "string", name: "name", value: `Silver`}, {type: "uint256", name: "count", value: "5"}, {type: "uint256", name: "price", value: "30000000000000000000"}, {type: "bool", name: "disabled", value: false}], name: "setPack", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPack(uint256,string,uint256,uint256,bool)" ]( "2", `Silver`, "5", "30000000000000000000", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1537453109 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[7], addressList[8], \"53\" )", async function( ) {
		const txOriginal = {blockNumber: "6396783", timeStamp: "1537877308", hash: "0xd5b712e9c8b9378f9d34193a816d5fcb5316498e6f3693fe1ad6d43d9d7e84b1", nonce: "2", blockHash: "0x8c966e3c20ba09302dee09f6ef030912fd46391bc1ca44ec6b50be09968271ee", transactionIndex: "19", from: "0x7d2b3165093fe265e46c006430dbd4ad9ff3b4e9", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "216627", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd0000000000000000000000007d2b3165093fe265e46c006430dbd4ad9ff3b4e9000000000000000000000000193ce09fa6e4fab06a8b0d12e09c8b01bc2f88260000000000000000000000000000000000000000000000000000000000000035", contractAddress: "", cumulativeGasUsed: "1378610", gasUsed: "99418", confirmations: "1312165"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[7]}, {type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_tokenId", value: "53"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[7], addressList[8], "53", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1537877308 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x7d2b3165093fe265e46c006430dbd4ad9ff3b4e9"}, {name: "_to", type: "address", value: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826"}, {name: "_tokenId", type: "uint256", value: "53"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1187992468767174528" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[9], addressList[8], \"82\" )", async function( ) {
		const txOriginal = {blockNumber: "6397004", timeStamp: "1537880556", hash: "0xdcf39a55458449d918a25e06e2e749bb57e24ddc9336c510fd8432f47c1f47d5", nonce: "148", blockHash: "0x5593632129800c56d0338e9668d204f0ddc9c104429018db28e4e1c65dadad97", transactionIndex: "57", from: "0xfc466835fb6cb2e74104be497bea840921ed3931", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "173378", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000fc466835fb6cb2e74104be497bea840921ed3931000000000000000000000000193ce09fa6e4fab06a8b0d12e09c8b01bc2f88260000000000000000000000000000000000000000000000000000000000000052", contractAddress: "", cumulativeGasUsed: "7610491", gasUsed: "99482", confirmations: "1311944"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[9]}, {type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_tokenId", value: "82"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[9], addressList[8], "82", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1537880556 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xfc466835fb6cb2e74104be497bea840921ed3931"}, {name: "_to", type: "address", value: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826"}, {name: "_tokenId", type: "uint256", value: "82"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "38994019316452157" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[8], addressList[9], \"22\" )", async function( ) {
		const txOriginal = {blockNumber: "6397150", timeStamp: "1537882829", hash: "0xb569e0b082fe8cc1d73e1c42f33d387581f425c7b9c0638177655a29809730ba", nonce: "1", blockHash: "0x1dcc71afd14f52ad63310423917a427a38cd7056e595424771ceb35b4f68d3c5", transactionIndex: "54", from: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "216723", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826000000000000000000000000fc466835fb6cb2e74104be497bea840921ed39310000000000000000000000000000000000000000000000000000000000000016", contractAddress: "", cumulativeGasUsed: "6934772", gasUsed: "99482", confirmations: "1311798"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[8]}, {type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_tokenId", value: "22"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[8], addressList[9], "22", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1537882829 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826"}, {name: "_to", type: "address", value: "0xfc466835fb6cb2e74104be497bea840921ed3931"}, {name: "_tokenId", type: "uint256", value: "22"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "393601907850597384" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[9], addressList[8], \"79\" )", async function( ) {
		const txOriginal = {blockNumber: "6397185", timeStamp: "1537883380", hash: "0x01436ed7ec5dcf5fdab271912d504322bc4f89bc2f51d228a23b93350c7ead0c", nonce: "149", blockHash: "0xa42dc1ac81f259b150bb09d333a7a9b02a6a703d260b68837ac20c25eb4099cc", transactionIndex: "125", from: "0xfc466835fb6cb2e74104be497bea840921ed3931", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "173378", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000fc466835fb6cb2e74104be497bea840921ed3931000000000000000000000000193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826000000000000000000000000000000000000000000000000000000000000004f", contractAddress: "", cumulativeGasUsed: "7548157", gasUsed: "99482", confirmations: "1311763"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[9]}, {type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_tokenId", value: "79"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[9], addressList[8], "79", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1537883380 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xfc466835fb6cb2e74104be497bea840921ed3931"}, {name: "_to", type: "address", value: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826"}, {name: "_tokenId", type: "uint256", value: "79"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "38994019316452157" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[8], addressList[9], \"23\" )", async function( ) {
		const txOriginal = {blockNumber: "6397189", timeStamp: "1537883498", hash: "0xe8e51048beae7780c4fe9c99cfc437fcbf1a578de81e4acd7ade4b8791c0e426", nonce: "2", blockHash: "0x9e46a2c7b26e7e0de1708e179b91c5dab1096ae06e4ff811d811c2410ca80c14", transactionIndex: "145", from: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "216723", gasPrice: "4259925188", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826000000000000000000000000fc466835fb6cb2e74104be497bea840921ed39310000000000000000000000000000000000000000000000000000000000000017", contractAddress: "", cumulativeGasUsed: "7230822", gasUsed: "99482", confirmations: "1311759"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[8]}, {type: "address", name: "_to", value: addressList[9]}, {type: "uint256", name: "_tokenId", value: "23"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[8], addressList[9], "23", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1537883498 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826"}, {name: "_to", type: "address", value: "0xfc466835fb6cb2e74104be497bea840921ed3931"}, {name: "_tokenId", type: "uint256", value: "23"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "393601907850597384" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[10], addressList[11], \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "6402518", timeStamp: "1537958724", hash: "0x760f647046897efcff8b8d04b0dc039a4a2ba6bfcadc6ae3b67cdc0382faab00", nonce: "2", blockHash: "0xcc3498e475ca8aa18956018008c6aa4afc0854e3f9c736f11d0fefe16a097fd0", transactionIndex: "99", from: "0xec9d96c6dbd6b49536288bef492475987142b556", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "239223", gasPrice: "10326511294", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000ec9d96c6dbd6b49536288bef492475987142b556000000000000000000000000f1df86e8b7c68835f35bf215eb2a464ce0397c2e0000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "7400563", gasUsed: "114482", confirmations: "1306430"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[10]}, {type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_tokenId", value: "9"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[10], addressList[11], "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1537958724 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xec9d96c6dbd6b49536288bef492475987142b556"}, {name: "_to", type: "address", value: "0xf1df86e8b7c68835f35bf215eb2a464ce0397c2e"}, {name: "_tokenId", type: "uint256", value: "9"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "36132000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[10], addressList[11], \"9\" )", async function( ) {
		const txOriginal = {blockNumber: "6402980", timeStamp: "1537964885", hash: "0x216a206661f6f5602b58bed41a35244bc113ea3e0c802e608cf17fa2208d7637", nonce: "3", blockHash: "0xb72bf7b7d35ab89edfb6288558f0633a1242ba287a2ea68ea5455adb9a3ca33c", transactionIndex: "74", from: "0xec9d96c6dbd6b49536288bef492475987142b556", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "239223", gasPrice: "6660464813", isError: "1", txreceipt_status: "0", input: "0x23b872dd000000000000000000000000ec9d96c6dbd6b49536288bef492475987142b556000000000000000000000000f1df86e8b7c68835f35bf215eb2a464ce0397c2e0000000000000000000000000000000000000000000000000000000000000009", contractAddress: "", cumulativeGasUsed: "7443790", gasUsed: "26042", confirmations: "1305968"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[10]}, {type: "address", name: "_to", value: addressList[11]}, {type: "uint256", name: "_tokenId", value: "9"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[10], addressList[11], "9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1537964885 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "36132000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: changeAndBuyPack( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6410549", timeStamp: "1538072870", hash: "0x84e05058fba25e90f05f70205b158023efa8eeadc09c7c3bb9e77e712460106c", nonce: "4", blockHash: "0xc18777b4d41e3b39dca617355b75c36e874236329ef3a5f925ec3cfaadc477a7", transactionIndex: "28", from: "0x5240aa95dd7e00046b7d55084e19efb99369c4fc", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "40000000000000000", gas: "1089291", gasPrice: "8800000000", isError: "0", txreceipt_status: "1", input: "0x5fc755900000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4383919", gasUsed: "664868", confirmations: "1298399"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "packId", value: "1"}], name: "changeAndBuyPack", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeAndBuyPack(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1538072870 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}, {indexed: false, name: "packId", type: "uint256"}], name: "TokenReceived", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenReceived", events: [{name: "from", type: "address", value: "0x5240aa95dd7e00046b7d55084e19efb99369c4fc"}, {name: "value", type: "uint256", value: "20000000000000000000"}, {name: "data", type: "bytes", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "packId", type: "uint256", value: "1"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "rate", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "packId", type: "uint256"}], name: "ChangeAndBuyPack", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeAndBuyPack", events: [{name: "buyer", type: "address", value: "0x5240aa95dd7e00046b7d55084e19efb99369c4fc"}, {name: "rate", type: "uint256", value: "500"}, {name: "price", type: "uint256", value: "40000000000000000"}, {name: "packId", type: "uint256", value: "1"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x5240aa95dd7e00046b7d55084e19efb99369c4fc"}, {name: "_tokenId", type: "uint256", value: "93"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x5240aa95dd7e00046b7d55084e19efb99369c4fc"}, {name: "_tokenId", type: "uint256", value: "94"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x5240aa95dd7e00046b7d55084e19efb99369c4fc"}, {name: "_tokenId", type: "uint256", value: "95"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "36426163838336446" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[6], addressList[8], \"34\" )", async function( ) {
		const txOriginal = {blockNumber: "6425224", timeStamp: "1538279992", hash: "0x2101869bb645d31dbce0846056348f1a17f4b3c531a6a81a4018dad530832332", nonce: "99", blockHash: "0x62ecb1ab0dce6572f2a42e3873e45e4f3ae9f99327104ac39bd165a2216959b2", transactionIndex: "86", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "50000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0x23b872dd0000000000000000000000001fed8ba9a9fdd72ef9038046ad148beb413491b8000000000000000000000000193ce09fa6e4fab06a8b0d12e09c8b01bc2f88260000000000000000000000000000000000000000000000000000000000000022", contractAddress: "", cumulativeGasUsed: "3911929", gasUsed: "50000", confirmations: "1283724"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[6]}, {type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_tokenId", value: "34"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[6], addressList[8], \"34\" )", async function( ) {
		const txOriginal = {blockNumber: "6477573", timeStamp: "1539016578", hash: "0xbdf10644fca4e44f5fa96bb61116b013914838c3bd8fdcb29c6808579e0dff65", nonce: "100", blockHash: "0x6559a3f4a01d3ff183915ff69ba7f92e55cb4755af954b9818e5f3296243b11a", transactionIndex: "33", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "216723", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd0000000000000000000000001fed8ba9a9fdd72ef9038046ad148beb413491b8000000000000000000000000193ce09fa6e4fab06a8b0d12e09c8b01bc2f88260000000000000000000000000000000000000000000000000000000000000022", contractAddress: "", cumulativeGasUsed: "1692848", gasUsed: "99482", confirmations: "1231375"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[6]}, {type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_tokenId", value: "34"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[6], addressList[8], "34", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1539016578 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8"}, {name: "_to", type: "address", value: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826"}, {name: "_tokenId", type: "uint256", value: "34"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[13], addressList[8], \"19\" )", async function( ) {
		const txOriginal = {blockNumber: "6482577", timeStamp: "1539086234", hash: "0x1b9ff3645554f9a6d6095820c8c776100a52ba1701995a491a391146d3ebbdd5", nonce: "3", blockHash: "0xf7147c413d0dd11c937fe971b5e9427b1e437f8bfe932475b7195c8d6b1ae7d4", transactionIndex: "51", from: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "216723", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000112ca729d9529f33ea4d7a2150517cbb2b72b7fc000000000000000000000000193ce09fa6e4fab06a8b0d12e09c8b01bc2f88260000000000000000000000000000000000000000000000000000000000000013", contractAddress: "", cumulativeGasUsed: "2622491", gasUsed: "99482", confirmations: "1226371"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[13]}, {type: "address", name: "_to", value: addressList[8]}, {type: "uint256", name: "_tokenId", value: "19"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[13], addressList[8], "19", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1539086234 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc"}, {name: "_to", type: "address", value: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826"}, {name: "_tokenId", type: "uint256", value: "19"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "30043330287500000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[8], addressList[13], \"121\" )", async function( ) {
		const txOriginal = {blockNumber: "6482590", timeStamp: "1539086439", hash: "0xf38ea2e0fd3ae8741a21ae080db8139fa6fc8456c15cdb57cab470c819ef56f0", nonce: "4", blockHash: "0x9620c70a1096130f063b51845b99589c43c83f03077730e1a8c1e54345542d1a", transactionIndex: "64", from: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "216723", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826000000000000000000000000112ca729d9529f33ea4d7a2150517cbb2b72b7fc0000000000000000000000000000000000000000000000000000000000000079", contractAddress: "", cumulativeGasUsed: "2740576", gasUsed: "99482", confirmations: "1226358"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[8]}, {type: "address", name: "_to", value: addressList[13]}, {type: "uint256", name: "_tokenId", value: "121"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[8], addressList[13], "121", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1539086439 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x193ce09fa6e4fab06a8b0d12e09c8b01bc2f8826"}, {name: "_to", type: "address", value: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc"}, {name: "_tokenId", type: "uint256", value: "121"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "393601907850597384" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: changeAndBuyPack( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6496967", timeStamp: "1539288467", hash: "0x0388baa72addc73bff6c8794d08077b3e3dedd1ee555754dafe8348c795e2d60", nonce: "41", blockHash: "0xdc223fe1fc27ca3510a8bd047eb4b2701a1da6b161dc800d3fd62c9417faff9b", transactionIndex: "29", from: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "40000000000000000", gas: "1089291", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x5fc755900000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2335420", gasUsed: "664868", confirmations: "1211981"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "packId", value: "1"}], name: "changeAndBuyPack", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeAndBuyPack(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1539288467 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}, {indexed: false, name: "packId", type: "uint256"}], name: "TokenReceived", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenReceived", events: [{name: "from", type: "address", value: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862"}, {name: "value", type: "uint256", value: "20000000000000000000"}, {name: "data", type: "bytes", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "packId", type: "uint256", value: "1"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "rate", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "packId", type: "uint256"}], name: "ChangeAndBuyPack", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeAndBuyPack", events: [{name: "buyer", type: "address", value: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862"}, {name: "rate", type: "uint256", value: "500"}, {name: "price", type: "uint256", value: "40000000000000000"}, {name: "packId", type: "uint256", value: "1"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862"}, {name: "_tokenId", type: "uint256", value: "136"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862"}, {name: "_tokenId", type: "uint256", value: "137"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862"}, {name: "_tokenId", type: "uint256", value: "138"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "245465107272659624" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: changeAndBuyPack( \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "6499413", timeStamp: "1539322286", hash: "0x97444053c414e68f124de95a6aa4c474287da41e43f6c90e8c0bb4b33ed0ff3c", nonce: "199", blockHash: "0x7fe6402beae1e16a7d97b1dd84a16f8257326876336fcf1e4a6e1a7523863ae0", transactionIndex: "40", from: "0x02306c88829cbd1f4e7d23f371ec5c727f8b330c", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "40000000000000000", gas: "1089291", gasPrice: "4200000000", isError: "0", txreceipt_status: "1", input: "0x5fc755900000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2188721", gasUsed: "664868", confirmations: "1209535"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "packId", value: "1"}], name: "changeAndBuyPack", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeAndBuyPack(uint256)" ]( "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1539322286 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}, {indexed: false, name: "packId", type: "uint256"}], name: "TokenReceived", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenReceived", events: [{name: "from", type: "address", value: "0x02306c88829cbd1f4e7d23f371ec5c727f8b330c"}, {name: "value", type: "uint256", value: "20000000000000000000"}, {name: "data", type: "bytes", value: "0x0000000000000000000000000000000000000000000000000000000000000001"}, {name: "packId", type: "uint256", value: "1"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "rate", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "packId", type: "uint256"}], name: "ChangeAndBuyPack", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeAndBuyPack", events: [{name: "buyer", type: "address", value: "0x02306c88829cbd1f4e7d23f371ec5c727f8b330c"}, {name: "rate", type: "uint256", value: "500"}, {name: "price", type: "uint256", value: "40000000000000000"}, {name: "packId", type: "uint256", value: "1"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x02306c88829cbd1f4e7d23f371ec5c727f8b330c"}, {name: "_tokenId", type: "uint256", value: "139"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x02306c88829cbd1f4e7d23f371ec5c727f8b330c"}, {name: "_tokenId", type: "uint256", value: "140"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x02306c88829cbd1f4e7d23f371ec5c727f8b330c"}, {name: "_tokenId", type: "uint256", value: "141"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "234259328427645777" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[14], addressList[14], \"138\... )", async function( ) {
		const txOriginal = {blockNumber: "6500364", timeStamp: "1539335872", hash: "0xbb225f9b6422a09f742b393b9fe054052af602742b1d6bba4f170fbc30cadaa0", nonce: "42", blockHash: "0xe1551463e2a3c8e721b84b7b88a77c844b57ddb143450c8f12bc4f35e0f2de3b", transactionIndex: "167", from: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "216723", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000398a20f8a91a7406343e75f4ac1eaad6902d3862000000000000000000000000398a20f8a91a7406343e75f4ac1eaad6902d3862000000000000000000000000000000000000000000000000000000000000008a", contractAddress: "", cumulativeGasUsed: "7520310", gasUsed: "99482", confirmations: "1208584"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[14]}, {type: "address", name: "_to", value: addressList[14]}, {type: "uint256", name: "_tokenId", value: "138"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[14], addressList[14], "138", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1539335872 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862"}, {name: "_to", type: "address", value: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862"}, {name: "_tokenId", type: "uint256", value: "138"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "245465107272659624" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: changeAndBuyPack( \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "6515674", timeStamp: "1539550168", hash: "0xdbb13bb4fcd0ae0ad61046fadc6d5e43521586ffbfa4627008676bd8a8ffe0cc", nonce: "1600", blockHash: "0x235edb1f57080cd35377eb14dab1c2ab47d8cba002ddeb9ac1991079b05a011d", transactionIndex: "49", from: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "60000000000000000", gas: "1628446", gasPrice: "2300000000", isError: "0", txreceipt_status: "1", input: "0x5fc755900000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "4030659", gasUsed: "1013161", confirmations: "1193274"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "60000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "packId", value: "2"}], name: "changeAndBuyPack", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeAndBuyPack(uint256)" ]( "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1539550168 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "data", type: "bytes"}, {indexed: false, name: "packId", type: "uint256"}], name: "TokenReceived", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TokenReceived", events: [{name: "from", type: "address", value: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935"}, {name: "value", type: "uint256", value: "30000000000000000000"}, {name: "data", type: "bytes", value: "0x0000000000000000000000000000000000000000000000000000000000000002"}, {name: "packId", type: "uint256", value: "2"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "buyer", type: "address"}, {indexed: false, name: "rate", type: "uint256"}, {indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "packId", type: "uint256"}], name: "ChangeAndBuyPack", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ChangeAndBuyPack", events: [{name: "buyer", type: "address", value: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935"}, {name: "rate", type: "uint256", value: "500"}, {name: "price", type: "uint256", value: "60000000000000000"}, {name: "packId", type: "uint256", value: "2"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935"}, {name: "_tokenId", type: "uint256", value: "142"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935"}, {name: "_tokenId", type: "uint256", value: "143"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935"}, {name: "_tokenId", type: "uint256", value: "144"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935"}, {name: "_tokenId", type: "uint256", value: "145"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}, {name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935"}, {name: "_tokenId", type: "uint256", value: "146"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "958909627072477490" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[6], addressList[17], \"25\",... )", async function( ) {
		const txOriginal = {blockNumber: "6538568", timeStamp: "1539872890", hash: "0x7e62da2937d727fec8c6007859d5d6b95962c4e3ad144c55209dcb4b4c6093d4", nonce: "108", blockHash: "0x5043cf83721da41ed3fc94f072463c161e149e604a31fe8d143835dfe618d346", transactionIndex: "181", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "312688", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde0000000000000000000000001fed8ba9a9fdd72ef9038046ad148beb413491b80000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d000000000000000000000000000000000000000000000000000000000000001900000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "4985535", gasUsed: "162990", confirmations: "1170380"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[6]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "25"}, {type: "bytes", name: "_data", value: "0x000000000000000000000000000000000000000000000002b5e3af16b1880000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[6], addressList[17], "25", "0x000000000000000000000000000000000000000000000002b5e3af16b1880000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1539872890 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "25"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[10], addressList[17], \"112\... )", async function( ) {
		const txOriginal = {blockNumber: "6538624", timeStamp: "1539873729", hash: "0x67d0a1b670ab2057e23de51b03923797803c7b426024267f7eb9bbe903d307f2", nonce: "8", blockHash: "0xdea3cdd62dec8a558b4cd13eacffb5ffc17f35da55db95dd3c8cb58c62f736a8", transactionIndex: "7", from: "0xec9d96c6dbd6b49536288bef492475987142b556", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000ec9d96c6dbd6b49536288bef492475987142b5560000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000700000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "2456103", gasUsed: "147990", confirmations: "1170324"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[10]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "112"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000001b1ae4d6e2ef500000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[10], addressList[17], "112", "0x00000000000000000000000000000000000000000000001b1ae4d6e2ef500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1539873729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xec9d96c6dbd6b49536288bef492475987142b556"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "112"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "36132000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[13], addressList[3], \"71\" )", async function( ) {
		const txOriginal = {blockNumber: "6538689", timeStamp: "1539874897", hash: "0x883d5ee6f7f3ccbf04ced13d106d16eb2a8ab05d373e8c5eba103045f44cacfe", nonce: "4", blockHash: "0x7559ad8021d4ee2c871c95cdba3c8a829630e34b51b772eb9ceabf12bcf94b6c", transactionIndex: "121", from: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "239223", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000112ca729d9529f33ea4d7a2150517cbb2b72b7fc000000000000000000000000eda8256f424eacbb9b2a6513de98d819e7496fb10000000000000000000000000000000000000000000000000000000000000047", contractAddress: "", cumulativeGasUsed: "7720619", gasUsed: "114482", confirmations: "1170259"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[13]}, {type: "address", name: "_to", value: addressList[3]}, {type: "uint256", name: "_tokenId", value: "71"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[13], addressList[3], "71", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1539874897 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc"}, {name: "_to", type: "address", value: "0xeda8256f424eacbb9b2a6513de98d819e7496fb1"}, {name: "_tokenId", type: "uint256", value: "71"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "30043330287500000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[13], addressList[17], \"21\"... )", async function( ) {
		const txOriginal = {blockNumber: "6538707", timeStamp: "1539875160", hash: "0xa6d4b162337591aa0f1c53eef55fa0b7056295f078bb8f990e97a739ad56992e", nonce: "5", blockHash: "0x83d9195b2e4c5e0b722cde33d48c62bc018677cb4cbafc4dbec93c9f314b4e9f", transactionIndex: "150", from: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "5218750000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000112ca729d9529f33ea4d7a2150517cbb2b72b7fc0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d000000000000000000000000000000000000000000000000000000000000001500000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000018aa64b94e82bc0000", contractAddress: "", cumulativeGasUsed: "7663610", gasUsed: "147990", confirmations: "1170241"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[13]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "21"}, {type: "bytes", name: "_data", value: "0x000000000000000000000000000000000000000000000018aa64b94e82bc0000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[13], addressList[17], "21", "0x000000000000000000000000000000000000000000000018aa64b94e82bc0000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1539875160 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "21"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "30043330287500000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[18], addressList[17], \"61\"... )", async function( ) {
		const txOriginal = {blockNumber: "6538711", timeStamp: "1539875207", hash: "0x8bcb9a316b4e279a4e2d79c85ee73957698b4cbcc704eb2420ce3e837fef4861", nonce: "1", blockHash: "0x37b9bb01f8406a21b9d78e7154fb23b5cb1dc6d79afbd395c58335938311855b", transactionIndex: "142", from: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "5218750000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000ba7ffafda99db8d7659cdfc3f0ca442a88ca398e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d000000000000000000000000000000000000000000000000000000000000003d0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000009513ea9de024380000", contractAddress: "", cumulativeGasUsed: "6623402", gasUsed: "147990", confirmations: "1170237"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[18]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "61"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000009513ea9de024380000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[18], addressList[17], "61", "0x00000000000000000000000000000000000000000000009513ea9de024380000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1539875207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "61"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "38234147148189997" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[19], addressList[17], \"2\",... )", async function( ) {
		const txOriginal = {blockNumber: "6538711", timeStamp: "1539875207", hash: "0x5f0da52df0e4a0cbb779a1bde589c4803061180f20e384e6abad23d65d296af6", nonce: "1", blockHash: "0x37b9bb01f8406a21b9d78e7154fb23b5cb1dc6d79afbd395c58335938311855b", transactionIndex: "150", from: "0x0e8ef4810093bca816c69c3eb47faa0fc9411bf2", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290092", gasPrice: "5218750000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde0000000000000000000000000e8ef4810093bca816c69c3eb47faa0fc9411bf20000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "6955307", gasUsed: "147926", confirmations: "1170237"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[19]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "2"}, {type: "bytes", name: "_data", value: "0x0000000000000000000000000000000000000000000000056bc75e2d63100000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[19], addressList[17], "2", "0x0000000000000000000000000000000000000000000000056bc75e2d63100000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1539875207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0e8ef4810093bca816c69c3eb47faa0fc9411bf2"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "2"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "69540111039898888" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[6], addressList[17], \"27\",... )", async function( ) {
		const txOriginal = {blockNumber: "6538758", timeStamp: "1539875893", hash: "0xc3d7e62255c0fad0a22edc28644cdd93c1c030f3f67398aa6e672c5297daed42", nonce: "134", blockHash: "0x139a432d395d6b955ab4c5f07875894558fbfa435e37d46dc98869ce0cb68952", transactionIndex: "125", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde0000000000000000000000001fed8ba9a9fdd72ef9038046ad148beb413491b80000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d000000000000000000000000000000000000000000000000000000000000001b0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000003635c9adc5dea00000", contractAddress: "", cumulativeGasUsed: "5158614", gasUsed: "147990", confirmations: "1170190"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[6]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "27"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000003635c9adc5dea00000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[6], addressList[17], "27", "0x00000000000000000000000000000000000000000000003635c9adc5dea00000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1539875893 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "27"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[13], addressList[17], \"12\"... )", async function( ) {
		const txOriginal = {blockNumber: "6538813", timeStamp: "1539876731", hash: "0xb3506fb168e9dee70861ab430861c610ae87e40e2d2f80a3422973ff5cbe9946", nonce: "6", blockHash: "0x62eee8f68b0505e172423bd0e9b803809fc883eac6a03f102d98ad68111f23aa", transactionIndex: "63", from: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "3400000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000112ca729d9529f33ea4d7a2150517cbb2b72b7fc0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000005150ae84a8cdf00000", contractAddress: "", cumulativeGasUsed: "7380634", gasUsed: "147990", confirmations: "1170135"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[13]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "12"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000005150ae84a8cdf00000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[13], addressList[17], "12", "0x00000000000000000000000000000000000000000000005150ae84a8cdf00000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1539876731 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "12"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "30043330287500000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[11], addressList[17], \"9\",... )", async function( ) {
		const txOriginal = {blockNumber: "6553555", timeStamp: "1540084876", hash: "0xff9573eb0d3ce921f32bc88dd26b35f35a226b8101582ce8aa3fdb4e0919ede3", nonce: "101", blockHash: "0x8923ba39d0423d9b018be070ecb77964ffb386e0fe26d37fb8aa9c496ac64626", transactionIndex: "92", from: "0xf1df86e8b7c68835f35bf215eb2a464ce0397c2e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "3200000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000f1df86e8b7c68835f35bf215eb2a464ce0397c2e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000028a857425466f80000", contractAddress: "", cumulativeGasUsed: "7830771", gasUsed: "147990", confirmations: "1155393"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[11]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "9"}, {type: "bytes", name: "_data", value: "0x000000000000000000000000000000000000000000000028a857425466f80000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[11], addressList[17], "9", "0x000000000000000000000000000000000000000000000028a857425466f80000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1540084876 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xf1df86e8b7c68835f35bf215eb2a464ce0397c2e"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "9"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "218756568593486067" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[11], addressList[17], \"9\",... )", async function( ) {
		const txOriginal = {blockNumber: "6553704", timeStamp: "1540087176", hash: "0x8e40276168f5a6950e2d2ff3d763d929388bd75a9eccfdfda492ba8f0e1e2414", nonce: "102", blockHash: "0xd8bb9ec36c6cf5a63cee789cdd7256aab24c39bcec672f6835e36ddd2673f2a1", transactionIndex: "92", from: "0xf1df86e8b7c68835f35bf215eb2a464ce0397c2e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xb88d4fde000000000000000000000000f1df86e8b7c68835f35bf215eb2a464ce0397c2e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000012f939c99edab80000", contractAddress: "", cumulativeGasUsed: "7343794", gasUsed: "27660", confirmations: "1155244"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[11]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "9"}, {type: "bytes", name: "_data", value: "0x000000000000000000000000000000000000000000000012f939c99edab80000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[11], addressList[17], "9", "0x000000000000000000000000000000000000000000000012f939c99edab80000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1540087176 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "218756568593486067" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[11], addressList[17], \"9\",... )", async function( ) {
		const txOriginal = {blockNumber: "6553706", timeStamp: "1540087207", hash: "0x44dc5b1bc5b5e0fd47ad44cf99b35e2558abe1d1f641fbf936e054cb135e4a4b", nonce: "103", blockHash: "0x3249a421a2ea7deb42b70ec9570876a5279d592400222a2017bfb612005e7d10", transactionIndex: "103", from: "0xf1df86e8b7c68835f35bf215eb2a464ce0397c2e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "3210000000", isError: "1", txreceipt_status: "0", input: "0xb88d4fde000000000000000000000000f1df86e8b7c68835f35bf215eb2a464ce0397c2e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "7483169", gasUsed: "27660", confirmations: "1155242"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[11]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "9"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000001b1ae4d6e2ef500000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[11], addressList[17], "9", "0x00000000000000000000000000000000000000000000001b1ae4d6e2ef500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1540087207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "218756568593486067" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[11], addressList[17], \"96\"... )", async function( ) {
		const txOriginal = {blockNumber: "6553708", timeStamp: "1540087229", hash: "0x1b7348372eee5010cf59f35b8213ccfa37ec394a6c8aa0e6c072e6f71705e644", nonce: "104", blockHash: "0xa804d9ca606fa78c30e8ea254d0b8367a240da8cbf3811403cdcb93c27ef262b", transactionIndex: "24", from: "0xf1df86e8b7c68835f35bf215eb2a464ce0397c2e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000f1df86e8b7c68835f35bf215eb2a464ce0397c2e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000bed1d0263d9f00000", contractAddress: "", cumulativeGasUsed: "2644169", gasUsed: "147990", confirmations: "1155240"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[11]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "96"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000000bed1d0263d9f00000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[11], addressList[17], "96", "0x00000000000000000000000000000000000000000000000bed1d0263d9f00000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1540087229 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xf1df86e8b7c68835f35bf215eb2a464ce0397c2e"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "96"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "218756568593486067" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[13], addressList[17], \"6\",... )", async function( ) {
		const txOriginal = {blockNumber: "6562399", timeStamp: "1540209850", hash: "0x6be563f801736250e7d779eb0a8c3221a08a6cc8d2c7ebc88600b55a446fcd58", nonce: "7", blockHash: "0x3fbaa8e9d4c09bcb0d55b240992891aaaf20ee45370de4c32ffc304cee4c9fd1", transactionIndex: "68", from: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290092", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000112ca729d9529f33ea4d7a2150517cbb2b72b7fc0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d0000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "6878590", gasUsed: "147926", confirmations: "1146549"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[13]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "6"}, {type: "bytes", name: "_data", value: "0x0000000000000000000000000000000000000000000000008ac7230489e80000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[13], addressList[17], "6", "0x0000000000000000000000000000000000000000000000008ac7230489e80000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1540209850 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "6"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "30043330287500000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[13], addressList[17], \"70\"... )", async function( ) {
		const txOriginal = {blockNumber: "6587497", timeStamp: "1540564240", hash: "0x693d6442683095ef4a25750719a705328635a7f5168aabd2fdc33d187a0e69e1", nonce: "8", blockHash: "0x48540b85d58a147e01c60fb20832fb30260b7206ca2aefef5663c17af26aa6a3", transactionIndex: "115", from: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "13100000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000112ca729d9529f33ea4d7a2150517cbb2b72b7fc0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d000000000000000000000000000000000000000000000000000000000000004600000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "3520390", gasUsed: "147990", confirmations: "1121451"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[13]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "70"}, {type: "bytes", name: "_data", value: "0x000000000000000000000000000000000000000000000002b5e3af16b1880000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[13], addressList[17], "70", "0x000000000000000000000000000000000000000000000002b5e3af16b1880000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1540564240 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x112ca729d9529f33ea4d7a2150517cbb2b72b7fc"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "70"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "30043330287500000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[16], addressList[17], \"142\... )", async function( ) {
		const txOriginal = {blockNumber: "6600706", timeStamp: "1540750824", hash: "0x85e9cb442d3d6af8c1b61a33ec00dc9ede82e90fe1658166c70a0d96e5d30905", nonce: "1804", blockHash: "0x1e1108aef5329e10a2bb987dc3eb9cc2755e09be993debcbbb8506fd1660416a", transactionIndex: "104", from: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000983961f34fc4cfc5eafec371cdba9d56ff8c19350000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d000000000000000000000000000000000000000000000000000000000000008e00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "6867714", gasUsed: "147990", confirmations: "1108242"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[16]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "142"}, {type: "bytes", name: "_data", value: "0x000000000000000000000000000000000000000000000002b5e3af16b1880000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[16], addressList[17], "142", "0x000000000000000000000000000000000000000000000002b5e3af16b1880000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1540750824 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x983961f34fc4cfc5eafec371cdba9d56ff8c1935"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "142"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "958909627072477490" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[14], addressList[20], \"136\... )", async function( ) {
		const txOriginal = {blockNumber: "6602197", timeStamp: "1540771707", hash: "0xd723d465f6750d11b5dd75def467239743edcdab643baa498a27f76dcef2fddc", nonce: "47", blockHash: "0x49c52bed1a657bb0816e349073fa1063112099f251c2c1891ea52856fec0347c", transactionIndex: "1", from: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "239223", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000398a20f8a91a7406343e75f4ac1eaad6902d3862000000000000000000000000f2b670f65958bd61561dd3ab43c7e96ce7b7d40d0000000000000000000000000000000000000000000000000000000000000088", contractAddress: "", cumulativeGasUsed: "187794", gasUsed: "114482", confirmations: "1106751"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[14]}, {type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_tokenId", value: "136"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[14], addressList[20], "136", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1540771707 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862"}, {name: "_to", type: "address", value: "0xf2b670f65958bd61561dd3ab43c7e96ce7b7d40d"}, {name: "_tokenId", type: "uint256", value: "136"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "245465107272659624" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[14], addressList[20], \"136\... )", async function( ) {
		const txOriginal = {blockNumber: "6602199", timeStamp: "1540771730", hash: "0x9db02a75142ff5a5a50b7fb91b042093f27bd5d92b2e47578036a29cdd390c86", nonce: "48", blockHash: "0x945c0bcfabac51661a3134c6b5bc62171d4d0705888854c941fa4b3e56fda178", transactionIndex: "39", from: "0x398a20f8a91a7406343e75f4ac1eaad6902d3862", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "239223", gasPrice: "4630000000", isError: "1", txreceipt_status: "0", input: "0x23b872dd000000000000000000000000398a20f8a91a7406343e75f4ac1eaad6902d3862000000000000000000000000f2b670f65958bd61561dd3ab43c7e96ce7b7d40d0000000000000000000000000000000000000000000000000000000000000088", contractAddress: "", cumulativeGasUsed: "2085450", gasUsed: "26042", confirmations: "1106749"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[14]}, {type: "address", name: "_to", value: addressList[20]}, {type: "uint256", name: "_tokenId", value: "136"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[14], addressList[20], "136", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1540771730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "245465107272659624" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: transferFrom( addressList[9], addressList[21], \"74\" )", async function( ) {
		const txOriginal = {blockNumber: "6611965", timeStamp: "1540909739", hash: "0x0a0bb098906b0166d6266ac1c0318f622e2bde84e0c46bbc26073748293edec6", nonce: "152", blockHash: "0xdd40f3b80d3d22393ee2b102867aeae5bbf852c10e004f941ecdac87f98ee290", transactionIndex: "84", from: "0xfc466835fb6cb2e74104be497bea840921ed3931", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "191378", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x23b872dd000000000000000000000000fc466835fb6cb2e74104be497bea840921ed3931000000000000000000000000e74ef81a02219a2646c2d1fb2e45a9a123fd6fac000000000000000000000000000000000000000000000000000000000000004a", contractAddress: "", cumulativeGasUsed: "3720724", gasUsed: "114482", confirmations: "1096983"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[9]}, {type: "address", name: "_to", value: addressList[21]}, {type: "uint256", name: "_tokenId", value: "74"}], name: "transferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferFrom(address,address,uint256)" ]( addressList[9], addressList[21], "74", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1540909739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xfc466835fb6cb2e74104be497bea840921ed3931"}, {name: "_to", type: "address", value: "0xe74ef81a02219a2646c2d1fb2e45a9a123fd6fac"}, {name: "_tokenId", type: "uint256", value: "74"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "38994019316452157" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[22], addressList[17], \"66\"... )", async function( ) {
		const txOriginal = {blockNumber: "6617344", timeStamp: "1540986013", hash: "0x0ac7b94e01d2c1f3885b96d26e093cf78bfbbd44ec81aa0aa4938b328620b6b7", nonce: "4", blockHash: "0x1b416d47cb045a09de771ce49e16911b12a210606edc10d55e26e91d7dbbdbf8", transactionIndex: "44", from: "0x20c0c6aad19f86b838c320d6deb140275ce89d8a", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde00000000000000000000000020c0c6aad19f86b838c320d6deb140275ce89d8a0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "7496878", gasUsed: "147990", confirmations: "1091604"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[22]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "66"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000001b1ae4d6e2ef500000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[22], addressList[17], "66", "0x00000000000000000000000000000000000000000000001b1ae4d6e2ef500000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1540986013 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x20c0c6aad19f86b838c320d6deb140275ce89d8a"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "66"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "1461513340000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[22], addressList[17], \"172\... )", async function( ) {
		const txOriginal = {blockNumber: "6617347", timeStamp: "1540986067", hash: "0x959b64a3cbd4b6b6a39145b85a91bbc463878f517aaad644378501f20d369023", nonce: "5", blockHash: "0x62585def5d4e0f9ec5f84f82014bf1bcac75d44c5ce231c02aa50d7b1cf99ad9", transactionIndex: "93", from: "0x20c0c6aad19f86b838c320d6deb140275ce89d8a", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "4100000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde00000000000000000000000020c0c6aad19f86b838c320d6deb140275ce89d8a0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000ac0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000ee86442fcd06c0000", contractAddress: "", cumulativeGasUsed: "7778089", gasUsed: "147990", confirmations: "1091601"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[22]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "172"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000000ee86442fcd06c0000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[22], addressList[17], "172", "0x00000000000000000000000000000000000000000000000ee86442fcd06c0000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1540986067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x20c0c6aad19f86b838c320d6deb140275ce89d8a"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "172"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "1461513340000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[22], addressList[17], \"170\... )", async function( ) {
		const txOriginal = {blockNumber: "6617349", timeStamp: "1540986097", hash: "0xf9a649c331b1e2b11fe3669a44bb4c08cf781e4d6d939421a061148d74612341", nonce: "6", blockHash: "0xbb56ba021e68c460a03cadafd1c5a257f0db9e6c2ff8a9265af13bff3d5026e7", transactionIndex: "105", from: "0x20c0c6aad19f86b838c320d6deb140275ce89d8a", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde00000000000000000000000020c0c6aad19f86b838c320d6deb140275ce89d8a0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000aa000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000120d4da7b0bd140000", contractAddress: "", cumulativeGasUsed: "3380655", gasUsed: "147990", confirmations: "1091599"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[22]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "170"}, {type: "bytes", name: "_data", value: "0x0000000000000000000000000000000000000000000000120d4da7b0bd140000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[22], addressList[17], "170", "0x0000000000000000000000000000000000000000000000120d4da7b0bd140000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1540986097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x20c0c6aad19f86b838c320d6deb140275ce89d8a"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "170"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "1461513340000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[22], addressList[17], \"167\... )", async function( ) {
		const txOriginal = {blockNumber: "6617385", timeStamp: "1540986604", hash: "0xee4f42106b4d76f017930e58cbdbfd5a26a9d9be732e0b32cc4a265c55893b92", nonce: "7", blockHash: "0x39ea2a926e1720eac26968bd6bf7cad534ec62661fda13719bbc09d13e4db7a6", transactionIndex: "112", from: "0x20c0c6aad19f86b838c320d6deb140275ce89d8a", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "4100000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde00000000000000000000000020c0c6aad19f86b838c320d6deb140275ce89d8a0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000a70000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000579a814e10a740000", contractAddress: "", cumulativeGasUsed: "7171880", gasUsed: "147990", confirmations: "1091563"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[22]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "167"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000000579a814e10a740000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[22], addressList[17], "167", "0x00000000000000000000000000000000000000000000000579a814e10a740000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1540986604 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x20c0c6aad19f86b838c320d6deb140275ce89d8a"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "167"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "1461513340000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[18], addressList[17], \"198\... )", async function( ) {
		const txOriginal = {blockNumber: "6617881", timeStamp: "1540993788", hash: "0xe31efb1165153fb3929ffa49b2cfb3a1486ab31800f40391263990a0c2c4909e", nonce: "5", blockHash: "0xa10f57856e39a31fcd7e60f9ac7726db1db371daa1511ce9a236bd79c051401c", transactionIndex: "69", from: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000ba7ffafda99db8d7659cdfc3f0ca442a88ca398e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000c600000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000012f939c99edab80000", contractAddress: "", cumulativeGasUsed: "3675196", gasUsed: "147990", confirmations: "1091067"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[18]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "198"}, {type: "bytes", name: "_data", value: "0x000000000000000000000000000000000000000000000012f939c99edab80000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[18], addressList[17], "198", "0x000000000000000000000000000000000000000000000012f939c99edab80000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1540993788 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "198"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "38234147148189997" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[18], addressList[17], \"200\... )", async function( ) {
		const txOriginal = {blockNumber: "6617883", timeStamp: "1540993827", hash: "0x53e0ee9b4a5ab60ee75be98d1c752b019e29527ed0e60aa4957e748d91a4910b", nonce: "6", blockHash: "0x20d62fd54528e6a48181ccf5d9f2da940844bef01a9c13b3b379b415dd7a2e1f", transactionIndex: "127", from: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000ba7ffafda99db8d7659cdfc3f0ca442a88ca398e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000c80000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000001d8b64f4775be40000", contractAddress: "", cumulativeGasUsed: "6293290", gasUsed: "147990", confirmations: "1091065"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[18]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "200"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000001d8b64f4775be40000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[18], addressList[17], "200", "0x00000000000000000000000000000000000000000000001d8b64f4775be40000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1540993827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "200"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "38234147148189997" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[18], addressList[17], \"206\... )", async function( ) {
		const txOriginal = {blockNumber: "6617886", timeStamp: "1540993866", hash: "0xdd6ca35e57fbf96a8ea0e2bd60c838867408f771f8b97edbd8e7743632fd991a", nonce: "7", blockHash: "0xa813008f7e2e9b124f7b633f7a034efd452a7e590c64edae898d23b6139ad53a", transactionIndex: "75", from: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000ba7ffafda99db8d7659cdfc3f0ca442a88ca398e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000ce0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000003ba1910bf341b00000", contractAddress: "", cumulativeGasUsed: "6917164", gasUsed: "147990", confirmations: "1091062"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[18]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "206"}, {type: "bytes", name: "_data", value: "0x00000000000000000000000000000000000000000000003ba1910bf341b00000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[18], addressList[17], "206", "0x00000000000000000000000000000000000000000000003ba1910bf341b00000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1540993866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "206"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "38234147148189997" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[18], addressList[17], \"204\... )", async function( ) {
		const txOriginal = {blockNumber: "6617893", timeStamp: "1540994009", hash: "0xcae54d305980eb6b0846dcef50c412e389091a0a816ff1180aea3b0919436e72", nonce: "8", blockHash: "0x8c7ed1ba4a21c139bacf88563245580bdf421e35a4882d7cda89481ff37c9d20", transactionIndex: "151", from: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000ba7ffafda99db8d7659cdfc3f0ca442a88ca398e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000cc000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000068155a43676e00000", contractAddress: "", cumulativeGasUsed: "6093644", gasUsed: "147990", confirmations: "1091055"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[18]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "204"}, {type: "bytes", name: "_data", value: "0x0000000000000000000000000000000000000000000000068155a43676e00000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[18], addressList[17], "204", "0x0000000000000000000000000000000000000000000000068155a43676e00000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1540994009 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "204"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "38234147148189997" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: safeTransferFrom( addressList[18], addressList[17], \"205\... )", async function( ) {
		const txOriginal = {blockNumber: "6617901", timeStamp: "1540994145", hash: "0xb3409780f650f37554a25bb82a84eb38f95a29d2f0137ca2375d37c33cca3a71", nonce: "9", blockHash: "0xb2ff61b4f5537e70fd7af0aecf3391f2b6f3ac9146a1e4b5110c789f3e9b694b", transactionIndex: "53", from: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "290188", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb88d4fde000000000000000000000000ba7ffafda99db8d7659cdfc3f0ca442a88ca398e0000000000000000000000009097bc3aaca7ee7d92675951cb06dcdbef1a878d00000000000000000000000000000000000000000000000000000000000000cd000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000056bc75e2d63100000", contractAddress: "", cumulativeGasUsed: "6064853", gasUsed: "147990", confirmations: "1091047"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_from", value: addressList[18]}, {type: "address", name: "_to", value: addressList[17]}, {type: "uint256", name: "_tokenId", value: "205"}, {type: "bytes", name: "_data", value: "0x0000000000000000000000000000000000000000000000056bc75e2d63100000"}], name: "safeTransferFrom", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "safeTransferFrom(address,address,uint256,bytes)" ]( addressList[18], addressList[17], "205", "0x0000000000000000000000000000000000000000000000056bc75e2d63100000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1540994145 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: false, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xba7ffafda99db8d7659cdfc3f0ca442a88ca398e"}, {name: "_to", type: "address", value: "0x9097bc3aaca7ee7d92675951cb06dcdbef1a878d"}, {name: "_tokenId", type: "uint256", value: "205"}], address: "0x4a152c146ec60251c50817e2cff25700d6b711af"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "38234147148189997" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: setPack( \"3\", `Gold`, \"10\", \"550000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6618002", timeStamp: "1540995591", hash: "0xbc1c6f4e0b938b649fd826f344eb76ee9c1072e75ff1e9b252f4c01aba6c9db8", nonce: "138", blockHash: "0x821a84e97985b3262b2986165e29e639a0d8e165c9ad70cf217c0727e71f6004", transactionIndex: "20", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "6500000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0a069289000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000001dd0c885f9a0d8000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004476f6c6400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "539738", gasUsed: "55863", confirmations: "1090946"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "3"}, {type: "string", name: "name", value: `Gold`}, {type: "uint256", name: "count", value: "10"}, {type: "uint256", name: "price", value: "550000000000000000000"}, {type: "bool", name: "disabled", value: false}], name: "setPack", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPack(uint256,string,uint256,uint256,bool)" ]( "3", `Gold`, "10", "550000000000000000000", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1540995591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setPack( \"2\", `Silver`, \"5\", \"30000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6618002", timeStamp: "1540995591", hash: "0x37a5b874525ad751b149f4060665e06862ad77e289c609e2be5a8c4bca3d06a4", nonce: "139", blockHash: "0x821a84e97985b3262b2986165e29e639a0d8e165c9ad70cf217c0727e71f6004", transactionIndex: "21", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "6500000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0a069289000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000001043561a88293000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000653696c7665720000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "595729", gasUsed: "55991", confirmations: "1090946"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "2"}, {type: "string", name: "name", value: `Silver`}, {type: "uint256", name: "count", value: "5"}, {type: "uint256", name: "price", value: "300000000000000000000"}, {type: "bool", name: "disabled", value: false}], name: "setPack", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPack(uint256,string,uint256,uint256,bool)" ]( "2", `Silver`, "5", "300000000000000000000", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1540995591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setPack( \"1\", `Wood`, \"3\", \"2000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6618006", timeStamp: "1540995634", hash: "0xc1acbe06a30ff628005f711f2ce35e1b325fd60f16c106bfadd27a5bea91affa", nonce: "140", blockHash: "0x2483a51affae4e58873f50655a9adac2784f91d5b01ae126a0cca7379d1044f2", transactionIndex: "11", from: "0x1fed8ba9a9fdd72ef9038046ad148beb413491b8", to: "0x4a152c146ec60251c50817e2cff25700d6b711af", value: "0", gas: "6500000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x0a069289000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000ad78ebc5ac620000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004576f6f6400000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1333617", gasUsed: "55863", confirmations: "1090942"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "id", value: "1"}, {type: "string", name: "name", value: `Wood`}, {type: "uint256", name: "count", value: "3"}, {type: "uint256", name: "price", value: "200000000000000000000"}, {type: "bool", name: "disabled", value: false}], name: "setPack", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPack(uint256,string,uint256,uint256,bool)" ]( "1", `Wood`, "3", "200000000000000000000", false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1540995634 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "7076591097790148" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
