const KStarCoin = artifacts.require( "./KStarCoin.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "KStarCoin" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x990E081A7B7d3Ccba26a2f49746A68CC4fF73280", "0xEc6BCfDDEC156d9f49e81cDFfa734E02aA95ce71", "0xE187D43F9a4c48E5f9B319CF3d8d6cFF51129af8", "0xFB3A1eE18ad572A5dF36d21509952509D3eb66a0", "0x344b7dDba139913DAaB5C836FBe79865De53a086", "0x50aB4C1ad2cDD621203dF2E82D5AEBF7e40c99F0", "0x2Da1b5Cc751Bf78a97DC8965Fe47648A7f3f2a95", "0xd67F067e2BD30c47DC7E2e753FA450107601C0Ae", "0xf21A77532Aa1a3797E5450Cd92bC3d8b736f8658", "0xE870e97FEBdE31B5F42543eDeF3edD0D57dCC605", "0x2E13AcE74b9EDae6b71AA12F9d5AA3071bBDBC66", "0xEeAD97E7931df6a711544F429134Ea6C685cE219", "0x2A8855bCfC4D15acE64a113108189382B4B5f7EF", "0x09356678898Bc9df23Cbc45a199eD947E0B8F30C", "0x87741bDbC3E01Fbed29CaEAD759734dA7F1336DC", "0xD7BE0A835f1daBd569Bf5472024aa7B85e3410B0", "0x305d2BA085c5FCC1a6c4de6a74471FD9e17cc85e", "0xcD761146adDAC8A4D20F0265289285F9FbeD01E4", "0x4cE9D45C6550d8702a43Ee815fe65345e00160C0", "0xE68BA179c4fc6444fa8fb5A8978decDde751A016", "0x8dcdc06c2aCC184a2DEbF0Fc41deEae966e3ee43", "0x24292D717b67A1D57679DC9C76Ac65839bE3DfDE", "0x5eB08b376Add73af1F9BbDC76a9bB61c11020C12", "0x73f9f89a12f8C8D75561601DcFa66C9D1b79b31f", "0x3E11A42bCb96A95D2262B736A97e7651E2C3a895", "0x6911168E426104f52a523BCB207E6Ca40b0682B8", "0xA3CCB8F2c5a78645801c12eC886e2f16dcd54e58", "0xa61F5c6D1D8eA9E5A7127E709B620b12f8b37784", "0x24a30224a92ED63818511B7559b30a19D7c95135", "0x0F98524E32f788b9392238b4a3D20C5b6c31bf65", "0xD5486e1BF4b1A06056a4b6276d8fb75EF1Bd5878", "0x97661c6A48F1A71Ef1B950b7AB417CC2d4932932", "0xC0a2F75A9158CF0d76719E1329538a558b72DF89", "0xEf4e3140FE267f2067F323ebAe83C359CEF5FB1F"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "address"}], name: "owners", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "INITIAL_SUPPLY", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "delayLockBeforeValues", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "LOCK_MAX", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMyUnlockValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "unlockAddrs", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "candidateSuperOwnerMap", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "superOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "delayLockTimes", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "lockValues", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_spender", type: "address"}], name: "allowance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "ownerList", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "root", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "delayLockValues", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "receiveType", type: "uint8"}], name: "TransferedToKSCDapp", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransferFrom", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCMintTo", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCBurnFrom", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "controller", type: "address"}, {indexed: true, name: "from", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCBurnWhenMoveToMainnet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCSell", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "processIdHash", type: "uint256"}, {indexed: false, name: "userIdHash", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCSellByOtherCoin", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransferToTeam", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransferToPartner", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "processIdHash", type: "uint256"}, {indexed: false, name: "userIdHash", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransferToEcosystem", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "processIdHash", type: "uint256"}, {indexed: false, name: "userIdHash", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransferToBounty", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "time", type: "uint256"}], name: "SetDelayLockValue", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "Locked", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "LockedTo", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "SetLockValue", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newRoot", type: "address"}], name: "ChangedRoot", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newSuperOwner", type: "address"}], name: "ChangedSuperOwner", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "deletedOwner", type: "address"}], name: "DeletedOwner", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TransferedToKSCDapp(address,address,address,uint256,uint8)", "KSCTransfer(address,address,uint256,string)", "KSCTransferFrom(address,address,address,uint256,string)", "KSCApproval(address,address,uint256,string)", "KSCMintTo(address,address,uint256,string)", "KSCBurnFrom(address,address,uint256,string)", "KSCBurnWhenMoveToMainnet(address,address,uint256,string)", "KSCSell(address,address,address,uint256,string)", "KSCSellByOtherCoin(address,address,address,uint256,uint256,uint256,string)", "KSCTransferToTeam(address,address,address,uint256,string)", "KSCTransferToPartner(address,address,address,uint256,string)", "KSCTransferToEcosystem(address,address,address,uint256,uint256,uint256,string)", "KSCTransferToBounty(address,address,address,uint256,uint256,uint256,string)", "SetDelayLockValue(address,uint256,uint256)", "Locked(bool,string)", "LockedTo(address,bool,string)", "SetLockValue(address,uint256,string)", "ChangedRoot(address)", "ChangedSuperOwner(address)", "AddedNewOwner(address)", "DeletedOwner(address)", "Approval(address,address,uint256)", "Transfer(address,address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xc8e7ea09f288f5ec19ac88fb74928e1e3b8e33976067636454bcca8e89b288ea", "0xf8c83dd2123ea3dc7804f44ca59137f0dc06dfb7fe6e821c8d18e0c9dbb35af0", "0x231d0124a8336036805fce94d719c3d1b6df71528dde9d2d61a75d8735dc89bd", "0x11df11f09b0ba23e705e16af1b61809e2b4b2e31147065fadab4e55603007516", "0xfe626f25dbc6d473da376b3d741078b605d2840f9e9571c3f782e27aff54d65f", "0x90bfe73c777234e28e547dab10018ff4a1a72792c298c700b5e4c22f8291234b", "0x5513400315f143ad4b27ad1d27f5e1b70f44f10be6a682911031002e96cca295", "0xe85177e5f6b1e79ca62e899dada6437a93bcd353e42695b57a7a299964e5b37e", "0xd1eeefb15b40f2cd79a9f59312406c24c8ac4aa23f444c493e9bc5ca587fd2bf", "0xaeef32f569c4d2b700d8acc51d15d5c61d856554ec3420f7889278e7fed468cf", "0xfe6d65dd5249c3a7684e855384a75ecc395b1e1a7715f31e561115d53741fdb4", "0xc5ff608abdc758e0b8038104f3fbbd2301f5b9261eea7963297c2d6471160e66", "0x0bf0225be82b0e35bf95a165e871255021221312a120febdba85e9650024d35f", "0x29f8b22a98b13376caf4551cf7eb973ad73a6b94bb83780818b808e04bf86af5", "0xc1086893b0a3f1d991fd25e26cd28cad11de174842b04a55cc2423ed178e4382", "0x4bf46282901af80a4309ce07c36d841184ce98297f8735f7769d169497ac7a4c", "0xb19425af6288c6bb0d88f64d6d1cfe5eb7e2d31ee92f1012798df97a9b6b011a", "0x43ddeae7116ae634a7d05c2d1c588bca11b7bbc8cb96fbb2cb9c5b1afdf9ce12", "0x94b17f1a4844062cbed00809347b0f8149fc88c5a3ea720c7aed42c559eed46d", "0x5446d64d957daf41eca8227aa8fa5eb7f92c617adf03fbd9df64e8eb564d824e", "0x1e64d9a491033a9731fa82493f0ab60e9f74294eca27edd93629f1fbaa15d287", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6571156 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6855978 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "KStarCoin", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "owners", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owners(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSupply", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSupply()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "INITIAL_SUPPLY", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "INITIAL_SUPPLY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "delayLockBeforeValues", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "delayLockBeforeValues(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "LOCK_MAX", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "LOCK_MAX()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMyUnlockValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMyUnlockValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "unlockAddrs", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "unlockAddrs(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "candidateSuperOwnerMap", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "candidateSuperOwnerMap(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "superOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "superOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "delayLockTimes", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "delayLockTimes(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "lockValues", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lockValues(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "locked", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "locked()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_spender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "allowance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowance(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "ownerList", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerList(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "root", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "root()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "delayLockValues", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "delayLockValues(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "KStarCoin", function( accounts ) {

	it( "TEST: KStarCoin(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6571156", timeStamp: "1540333587", hash: "0xc1daf0bddd26055dc85e28fb780b0b3835fba14ba3380a63c97e3043e35b5700", nonce: "167", blockHash: "0xd6c41c5b4eff7c6a03479fb22e20074a4d5558c362d0bc56a6d7fb36aa08704b", transactionIndex: "13", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: 0, value: "0", gas: "5656815", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xe6891995", contractAddress: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", cumulativeGasUsed: "6268428", gasUsed: "5656815", confirmations: "1168417"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "KStarCoin", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = KStarCoin.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540333587 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = KStarCoin.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "LockedTo", type: "event"} ;
		console.error( "eventCallOriginal[0,15] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedTo", events: [{name: "addr", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "locked", type: "bool", value: false}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[0,15] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[0,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "to", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "value", type: "uint256", value: "1000000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[0,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[4], \"2000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6579409", timeStamp: "1540450019", hash: "0x421a6fe57bcd5c9378013dc9861dc5df866aa02903295728d6e76148738cf670", nonce: "171", blockHash: "0x6bac62ab9cc436ac434b1b97773196983c4ec1e634b428308ac676f2dcbb4dbe", transactionIndex: "102", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "11486790510", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000e187d43f9a4c48e5f9b319cf3d8d6cff51129af800000000000000000000000000000000000000000001a784379d99db42000000", contractAddress: "", cumulativeGasUsed: "4588074", gasUsed: "48570", confirmations: "1160164"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[4]}, {type: "uint256", name: "value", value: "2000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[4], "2000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540450019 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[1,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xe187d43f9a4c48e5f9b319cf3d8d6cff51129af8"}, {name: "value", type: "uint256", value: "2000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[1,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[1,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xe187d43f9a4c48e5f9b319cf3d8d6cff51129af8"}, {name: "value", type: "uint256", value: "2000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[1,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[4], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6581589", timeStamp: "1540480700", hash: "0xa16317aa12bf86597ff8722a343a08f79889c990f06729b114052addf4aaedb6", nonce: "174", blockHash: "0xe86e21cbed45aa0e20b621008c96aa2d55869649da1fbe8ddcccfefdad56e60d", transactionIndex: "93", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "33058", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000e187d43f9a4c48e5f9b319cf3d8d6cff51129af80000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3426085", gasUsed: "18058", confirmations: "1157984"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[4]}, {type: "uint256", name: "value", value: "0"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[4], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540480700 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xe187d43f9a4c48e5f9b319cf3d8d6cff51129af8"}, {name: "value", type: "uint256", value: "0"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[2,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xe187d43f9a4c48e5f9b319cf3d8d6cff51129af8"}, {name: "value", type: "uint256", value: "0"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[2,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[5], \"2000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6581627", timeStamp: "1540481181", hash: "0xcf1844d7163cbb3bf5ecce96370d52a5e520510a6763e86105d85731bdc05473", nonce: "179", blockHash: "0xabe1f879ba21e514aba7226dd00baf0df49ce1a32398cd60bd9bb0c56f962f2e", transactionIndex: "27", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000fb3a1ee18ad572a5df36d21509952509d3eb66a0000000000000000000000000000000000000000000108b2a2c28029094000000", contractAddress: "", cumulativeGasUsed: "1551746", gasUsed: "48570", confirmations: "1157946"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[5]}, {type: "uint256", name: "value", value: "20000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[5], "20000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540481181 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xfb3a1ee18ad572a5df36d21509952509d3eb66a0"}, {name: "value", type: "uint256", value: "20000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[3,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xfb3a1ee18ad572a5df36d21509952509d3eb66a0"}, {name: "value", type: "uint256", value: "20000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[3,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: kscTransfer( addressList[6], \"600000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6582058", timeStamp: "1540486923", hash: "0x54be761adbf04a74067ba05056f4e29e7542feb96ec649a5271b02f9fa72743f", nonce: "195", blockHash: "0x303390d51fe5a2f28b79dc66cd4abaaf5ea09ef8b258791f40f719194be33f34", transactionIndex: "30", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "65192", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x803cc0d0000000000000000000000000344b7ddba139913daab5c836fbe79865de53a08600000000000000000000000000000000000000000000002086ac3510526000000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000002e49742773206d6f7665642066726f6d20616e206f6c642061646472657373206f66204b53746172436f696e56322e000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2754064", gasUsed: "65192", confirmations: "1157515"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[6]}, {type: "uint256", name: "value", value: "600000000000000000000"}, {type: "string", name: "note", value: `It's moved from an old address of KStarCoinV2.`}], name: "kscTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "kscTransfer(address,uint256,string)" ]( addressList[6], "600000000000000000000", `It's moved from an old address of KStarCoinV2.`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540486923 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransfer", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCTransfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x344b7ddba139913daab5c836fbe79865de53a086"}, {name: "value", type: "uint256", value: "600000000000000000000"}, {name: "note", type: "string", value: "It's moved from an old address of KStarCoinV2."}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x344b7ddba139913daab5c836fbe79865de53a086"}, {name: "value", type: "uint256", value: "600000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[4,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: kscTransfer( addressList[7], \"200000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6582059", timeStamp: "1540486930", hash: "0xd8c5978a2fbb2902d39426558deffa15a3cd88624eaed0453013cec9924e6877", nonce: "196", blockHash: "0x87d5bfee11a634bbc7704ed7eec6b66afad0fd92e311045242a446737011b039", transactionIndex: "14", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "67564", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x803cc0d000000000000000000000000050ab4c1ad2cdd621203df2e82d5aebf7e40c99f000000000000000000000000000000000000000000000000ad78ebc5ac62000000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000002e49742773206d6f7665642066726f6d20616e206f6c642061646472657373206f66204b53746172436f696e56322e000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "685678", gasUsed: "67564", confirmations: "1157514"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[7]}, {type: "uint256", name: "value", value: "200000000000000000000"}, {type: "string", name: "note", value: `It's moved from an old address of KStarCoinV2.`}], name: "kscTransfer", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "kscTransfer(address,uint256,string)" ]( addressList[7], "200000000000000000000", `It's moved from an old address of KStarCoinV2.`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540486930 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "receiveType", type: "uint8"}], name: "TransferedToKSCDapp", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferedToKSCDapp", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x50ab4c1ad2cdd621203df2e82d5aebf7e40c99f0"}, {name: "value", type: "uint256", value: "200000000000000000000"}, {name: "receiveType", type: "uint8", value: "0"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransfer", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCTransfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x50ab4c1ad2cdd621203df2e82d5aebf7e40c99f0"}, {name: "value", type: "uint256", value: "200000000000000000000"}, {name: "note", type: "string", value: "It's moved from an old address of KStarCoinV2."}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x50ab4c1ad2cdd621203df2e82d5aebf7e40c99f0"}, {name: "value", type: "uint256", value: "200000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[5,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[5], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6584482", timeStamp: "1540521208", hash: "0xd42b083de36daea823d3c572f15f8d96d9634c2fde023c23656040836646c6e2", nonce: "201", blockHash: "0xbb91596ffc318478a37125017164ecdac0728e7b0b8d5f62495403fd11a6fc68", transactionIndex: "63", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "33058", gasPrice: "7200000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000fb3a1ee18ad572a5df36d21509952509d3eb66a00000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6161811", gasUsed: "18058", confirmations: "1155091"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[5]}, {type: "uint256", name: "value", value: "0"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[5], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540521208 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xfb3a1ee18ad572a5df36d21509952509d3eb66a0"}, {name: "value", type: "uint256", value: "0"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[6,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xfb3a1ee18ad572a5df36d21509952509d3eb66a0"}, {name: "value", type: "uint256", value: "0"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[6,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[9], \"500000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6584810", timeStamp: "1540525929", hash: "0x69665cfd61a406e094068508bed16f56d2660e37edf6c3bd0f7012997cd2b00b", nonce: "50", blockHash: "0x4a1af8deecaeb032bb6037397f0d9c0b36c2bc2b259841a54f782c89ea126482", transactionIndex: "21", from: "0x2da1b5cc751bf78a97dc8965fe47648a7f3f2a95", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "100000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000d67f067e2bd30c47dc7e2e753fa450107601c0ae00000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "4160290", gasUsed: "26317", confirmations: "1154763"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[9]}, {type: "uint256", name: "value", value: "500000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[9], "500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540525929 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "663862000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6588265", timeStamp: "1540574915", hash: "0xf6b8346e5509a9116c8a141ef34c30ac6e55067eac0b721d5ec48bcc7eab7fa4", nonce: "208", blockHash: "0xe113ff901cdd04c07a9a45362c9040d0fa8beebe4a24f4545503566551c81f2c", transactionIndex: "106", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "9100830000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000f21a77532aa1a3797e5450cd92bc3d8b736f8658000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "7052266", gasUsed: "48570", confirmations: "1151308"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[10]}, {type: "uint256", name: "value", value: "10000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540574915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xf21a77532aa1a3797e5450cd92bc3d8b736f8658"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[8,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xf21a77532aa1a3797e5450cd92bc3d8b736f8658"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[8,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6588265", timeStamp: "1540574915", hash: "0x865e6cf62c0e57a3154b0cf970d011bf912d7bf5b664809b43d659d3c0bc5ced", nonce: "209", blockHash: "0xe113ff901cdd04c07a9a45362c9040d0fa8beebe4a24f4545503566551c81f2c", transactionIndex: "107", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "71377", gasPrice: "9100830000", isError: "0", txreceipt_status: "1", input: "0x85952454000000000000000000000000f21a77532aa1a3797e5450cd92bc3d8b736f8658", contractAddress: "", cumulativeGasUsed: "7123643", gasUsed: "71377", confirmations: "1151308"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[10]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540574915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[9,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0xf21a77532aa1a3797e5450cd92bc3d8b736f8658"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[9,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[11], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6588265", timeStamp: "1540574915", hash: "0x9b956157e58e28db86d298c0f9dc0900f91a9c033fb170174c2254bd26c5f4d2", nonce: "210", blockHash: "0xe113ff901cdd04c07a9a45362c9040d0fa8beebe4a24f4545503566551c81f2c", transactionIndex: "108", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "9100830000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000e870e97febde31b5f42543edef3edd0d57dcc605000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "7172213", gasUsed: "48570", confirmations: "1151308"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[11]}, {type: "uint256", name: "value", value: "10000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[11], "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540574915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[10,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xe870e97febde31b5f42543edef3edd0d57dcc605"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[10,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[10,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xe870e97febde31b5f42543edef3edd0d57dcc605"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[10,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "6588265", timeStamp: "1540574915", hash: "0xb5ccca87f1b0d0581dde46e2f09a95b6d8d3460ed5f929041afc126c5d0d40a4", nonce: "211", blockHash: "0xe113ff901cdd04c07a9a45362c9040d0fa8beebe4a24f4545503566551c81f2c", transactionIndex: "109", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "71377", gasPrice: "9100830000", isError: "0", txreceipt_status: "1", input: "0x85952454000000000000000000000000e870e97febde31b5f42543edef3edd0d57dcc605", contractAddress: "", cumulativeGasUsed: "7243590", gasUsed: "71377", confirmations: "1151308"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[11]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540574915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[11,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0xe870e97febde31b5f42543edef3edd0d57dcc605"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[11,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[12], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6588265", timeStamp: "1540574915", hash: "0xc71b690265f190ba954f7170e0a9ec1bcb6d9f9c6d8db514a999bee3b1dd4c38", nonce: "212", blockHash: "0xe113ff901cdd04c07a9a45362c9040d0fa8beebe4a24f4545503566551c81f2c", transactionIndex: "110", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "9100830000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000002e13ace74b9edae6b71aa12f9d5aa3071bbdbc66000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "7292160", gasUsed: "48570", confirmations: "1151308"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[12]}, {type: "uint256", name: "value", value: "10000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[12], "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540574915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0x2e13ace74b9edae6b71aa12f9d5aa3071bbdbc66"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[12,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0x2e13ace74b9edae6b71aa12f9d5aa3071bbdbc66"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[12,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6588265", timeStamp: "1540574915", hash: "0x27e56c2571118e1a5d3c874844d71a7b98e1d2059edddbaacc4473d9dec675a4", nonce: "213", blockHash: "0xe113ff901cdd04c07a9a45362c9040d0fa8beebe4a24f4545503566551c81f2c", transactionIndex: "111", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "71377", gasPrice: "9100830000", isError: "0", txreceipt_status: "1", input: "0x859524540000000000000000000000002e13ace74b9edae6b71aa12f9d5aa3071bbdbc66", contractAddress: "", cumulativeGasUsed: "7363537", gasUsed: "71377", confirmations: "1151308"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[12]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540574915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[13,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0x2e13ace74b9edae6b71aa12f9d5aa3071bbdbc66"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[13,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[13], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6588265", timeStamp: "1540574915", hash: "0x3e0ca7505cddee5d6d0499c31706d57d707f411e56e7db7a06fc0f280732e128", nonce: "214", blockHash: "0xe113ff901cdd04c07a9a45362c9040d0fa8beebe4a24f4545503566551c81f2c", transactionIndex: "112", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "9100830000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000eead97e7931df6a711544f429134ea6c685ce219000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "7412107", gasUsed: "48570", confirmations: "1151308"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[13]}, {type: "uint256", name: "value", value: "10000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[13], "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540574915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[14,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xeead97e7931df6a711544f429134ea6c685ce219"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[14,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[14,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xeead97e7931df6a711544f429134ea6c685ce219"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[14,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6588265", timeStamp: "1540574915", hash: "0xa00928aac31bb30e366b774a9eec690ad467cf19e160b6dcfd788c0be0ba646b", nonce: "215", blockHash: "0xe113ff901cdd04c07a9a45362c9040d0fa8beebe4a24f4545503566551c81f2c", transactionIndex: "113", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "71377", gasPrice: "9100830000", isError: "0", txreceipt_status: "1", input: "0x85952454000000000000000000000000eead97e7931df6a711544f429134ea6c685ce219", contractAddress: "", cumulativeGasUsed: "7483484", gasUsed: "71377", confirmations: "1151308"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[13]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540574915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[15,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0xeead97e7931df6a711544f429134ea6c685ce219"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[15,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[13], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6588314", timeStamp: "1540575590", hash: "0x7dea1f0ea0919e0be8bcd595a9cbf24ac63d7509f47282143168cdbc28c33682", nonce: "223", blockHash: "0xd8de4d096d2a442b310474834da0757b73bf00f36ca8857e9dc95717988f7ff5", transactionIndex: "27", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "33058", gasPrice: "8760000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000eead97e7931df6a711544f429134ea6c685ce2190000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1302714", gasUsed: "18058", confirmations: "1151259"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[13]}, {type: "uint256", name: "value", value: "0"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[13], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540575590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xeead97e7931df6a711544f429134ea6c685ce219"}, {name: "value", type: "uint256", value: "0"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[16,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xeead97e7931df6a711544f429134ea6c685ce219"}, {name: "value", type: "uint256", value: "0"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[16,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: deleteOwner( addressList[13] )", async function( ) {
		const txOriginal = {blockNumber: "6588314", timeStamp: "1540575590", hash: "0xe4538cf73f42a3d543583117547d6a09adc7a4446efbd670cf93eb0cd70b607c", nonce: "224", blockHash: "0xd8de4d096d2a442b310474834da0757b73bf00f36ca8857e9dc95717988f7ff5", transactionIndex: "31", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "52913", gasPrice: "8760000000", isError: "0", txreceipt_status: "1", input: "0xcd5c4c70000000000000000000000000eead97e7931df6a711544f429134ea6c685ce219", contractAddress: "", cumulativeGasUsed: "1681335", gasUsed: "26457", confirmations: "1151259"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[13]}], name: "deleteOwner", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deleteOwner(address)" ]( addressList[13], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540575590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deletedOwner", type: "address"}], name: "DeletedOwner", type: "event"} ;
		console.error( "eventCallOriginal[17,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeletedOwner", events: [{name: "deletedOwner", type: "address", value: "0xeead97e7931df6a711544f429134ea6c685ce219"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[17,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[12], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6588314", timeStamp: "1540575590", hash: "0x8f9236477b6a2b6c1274f29b025ec613e47c21defc91fdfc1c761cbdaf4b9c16", nonce: "225", blockHash: "0xd8de4d096d2a442b310474834da0757b73bf00f36ca8857e9dc95717988f7ff5", transactionIndex: "32", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "33058", gasPrice: "8760000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b30000000000000000000000002e13ace74b9edae6b71aa12f9d5aa3071bbdbc660000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1699393", gasUsed: "18058", confirmations: "1151259"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[12]}, {type: "uint256", name: "value", value: "0"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[12], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540575590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0x2e13ace74b9edae6b71aa12f9d5aa3071bbdbc66"}, {name: "value", type: "uint256", value: "0"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[18,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0x2e13ace74b9edae6b71aa12f9d5aa3071bbdbc66"}, {name: "value", type: "uint256", value: "0"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[18,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: deleteOwner( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "6588314", timeStamp: "1540575590", hash: "0x8fbcccbef5eef7abefe0a0897cff27cc16952d934648c4967c9f44e00e493382", nonce: "226", blockHash: "0xd8de4d096d2a442b310474834da0757b73bf00f36ca8857e9dc95717988f7ff5", transactionIndex: "33", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "52002", gasPrice: "8760000000", isError: "0", txreceipt_status: "1", input: "0xcd5c4c700000000000000000000000002e13ace74b9edae6b71aa12f9d5aa3071bbdbc66", contractAddress: "", cumulativeGasUsed: "1725394", gasUsed: "26001", confirmations: "1151259"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[12]}], name: "deleteOwner", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deleteOwner(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540575590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deletedOwner", type: "address"}], name: "DeletedOwner", type: "event"} ;
		console.error( "eventCallOriginal[19,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeletedOwner", events: [{name: "deletedOwner", type: "address", value: "0x2e13ace74b9edae6b71aa12f9d5aa3071bbdbc66"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[19,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[11], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6588314", timeStamp: "1540575590", hash: "0x68bfa60c075061f0cebf820f30c1ed5fc66e9959ed6b7ed98c6b068c3d8851f6", nonce: "227", blockHash: "0xd8de4d096d2a442b310474834da0757b73bf00f36ca8857e9dc95717988f7ff5", transactionIndex: "34", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "33058", gasPrice: "8760000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000e870e97febde31b5f42543edef3edd0d57dcc6050000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1743452", gasUsed: "18058", confirmations: "1151259"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[11]}, {type: "uint256", name: "value", value: "0"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[11], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1540575590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[20,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xe870e97febde31b5f42543edef3edd0d57dcc605"}, {name: "value", type: "uint256", value: "0"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[20,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[20,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xe870e97febde31b5f42543edef3edd0d57dcc605"}, {name: "value", type: "uint256", value: "0"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[20,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: deleteOwner( addressList[11] )", async function( ) {
		const txOriginal = {blockNumber: "6588314", timeStamp: "1540575590", hash: "0x878097b7b5a2044548eda07963d14b765df7b01b3167f2d47109aa036b2c6b42", nonce: "228", blockHash: "0xd8de4d096d2a442b310474834da0757b73bf00f36ca8857e9dc95717988f7ff5", transactionIndex: "35", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "51091", gasPrice: "8760000000", isError: "0", txreceipt_status: "1", input: "0xcd5c4c70000000000000000000000000e870e97febde31b5f42543edef3edd0d57dcc605", contractAddress: "", cumulativeGasUsed: "1768998", gasUsed: "25546", confirmations: "1151259"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[11]}], name: "deleteOwner", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deleteOwner(address)" ]( addressList[11], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1540575590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deletedOwner", type: "address"}], name: "DeletedOwner", type: "event"} ;
		console.error( "eventCallOriginal[21,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeletedOwner", events: [{name: "deletedOwner", type: "address", value: "0xe870e97febde31b5f42543edef3edd0d57dcc605"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[21,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[10], \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6588314", timeStamp: "1540575590", hash: "0x7a059271630f3f08805a2fdb4a1091e2b2b7bc318944611081f1b0a9190089bf", nonce: "229", blockHash: "0xd8de4d096d2a442b310474834da0757b73bf00f36ca8857e9dc95717988f7ff5", transactionIndex: "36", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "33058", gasPrice: "8760000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000f21a77532aa1a3797e5450cd92bc3d8b736f86580000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1787056", gasUsed: "18058", confirmations: "1151259"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[10]}, {type: "uint256", name: "value", value: "0"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[10], "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1540575590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xf21a77532aa1a3797e5450cd92bc3d8b736f8658"}, {name: "value", type: "uint256", value: "0"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[22,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xf21a77532aa1a3797e5450cd92bc3d8b736f8658"}, {name: "value", type: "uint256", value: "0"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[22,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: deleteOwner( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "6588314", timeStamp: "1540575590", hash: "0xedb867adc8666ee044badbfcffe925670bcd9fd48e407e2fddda967905efa626", nonce: "230", blockHash: "0xd8de4d096d2a442b310474834da0757b73bf00f36ca8857e9dc95717988f7ff5", transactionIndex: "37", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "50180", gasPrice: "8760000000", isError: "0", txreceipt_status: "1", input: "0xcd5c4c70000000000000000000000000f21a77532aa1a3797e5450cd92bc3d8b736f8658", contractAddress: "", cumulativeGasUsed: "1812146", gasUsed: "25090", confirmations: "1151259"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[10]}], name: "deleteOwner", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "deleteOwner(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1540575590 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "deletedOwner", type: "address"}], name: "DeletedOwner", type: "event"} ;
		console.error( "eventCallOriginal[23,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeletedOwner", events: [{name: "deletedOwner", type: "address", value: "0xf21a77532aa1a3797e5450cd92bc3d8b736f8658"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[23,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[3], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6588324", timeStamp: "1540575729", hash: "0x68e65e2463d192c5d76339fcfe06bee46bfe82344cabd0ea2da5f09f6fdb81ac", nonce: "231", blockHash: "0x51aa7b24c1fd65b5b088ef7ca450f68c9d577bc94cfc5d70a7cf4a5e09b09da3", transactionIndex: "24", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "7500000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000ec6bcfddec156d9f49e81cdffa734e02aa95ce7100000000000000000000000000000000000000000052b7d2dcc80cd2e4000000", contractAddress: "", cumulativeGasUsed: "5346613", gasUsed: "48570", confirmations: "1151249"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[3]}, {type: "uint256", name: "value", value: "100000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[3], "100000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1540575729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "value", type: "uint256", value: "100000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[24,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "value", type: "uint256", value: "100000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[24,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: kscBatchTransferToEcosystem( addressList[3], [addressList[14]], [\"20... )", async function( ) {
		const txOriginal = {blockNumber: "6588349", timeStamp: "1540576108", hash: "0x94cae37490a45dba76ef10c5d884edf08e5e6ad8717f933691646ef601e46819", nonce: "232", blockHash: "0x2b03109ebe414ef787384b568aa7f3d27af35f11fb62600a8e0f5e749cdf8c33", transactionIndex: "86", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "71636", gasPrice: "7680000000", isError: "0", txreceipt_status: "1", input: "0x31b9d81d000000000000000000000000ec6bcfddec156d9f49e81cdffa734e02aa95ce7100000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000018000000000000000000000000000000000000000000000000000000000000000010000000000000000000000002a8855bcfc4d15ace64a113108189382b4b5f7ef000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000001a784379d99db4200000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001665636f73797374656d20776974682054636f6e6f6d7900000000000000000000", contractAddress: "", cumulativeGasUsed: "5380975", gasUsed: "71636", confirmations: "1151224"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address[]", name: "to", value: [addressList[14]]}, {type: "uint256[]", name: "values", value: ["2000000000000000000000000"]}, {type: "uint256", name: "processIdHash", value: "0"}, {type: "uint256[]", name: "userIdHash", value: ["0"]}, {type: "string", name: "note", value: `ecosystem with Tconomy`}], name: "kscBatchTransferToEcosystem", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "kscBatchTransferToEcosystem(address,address[],uint256[],uint256,uint256[],string)" ]( addressList[3], [addressList[14]], ["2000000000000000000000000"], "0", ["0"], `ecosystem with Tconomy`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1540576108 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "processIdHash", type: "uint256"}, {indexed: false, name: "userIdHash", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransferToEcosystem", type: "event"} ;
		console.error( "eventCallOriginal[25,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCTransferToEcosystem", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x2a8855bcfc4d15ace64a113108189382b4b5f7ef"}, {name: "value", type: "uint256", value: "2000000000000000000000000"}, {name: "processIdHash", type: "uint256", value: "0"}, {name: "userIdHash", type: "uint256", value: "0"}, {name: "note", type: "string", value: "ecosystem with Tconomy"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[25,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x2a8855bcfc4d15ace64a113108189382b4b5f7ef"}, {name: "value", type: "uint256", value: "2000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[25,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6602978", timeStamp: "1540783057", hash: "0x87209cfed1e99c01331e9be2fb5d2c1e983e089aaa887cf0de960e717bdeb90b", nonce: "51", blockHash: "0x1e09a6fe5e3113ea2b3583d524ab7ee7044cf315a23e8d189ef811eb9670a2ca", transactionIndex: "64", from: "0x2da1b5cc751bf78a97dc8965fe47648a7f3f2a95", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "57000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb00000000000000000000000009356678898bc9df23cbc45a199ed947e0b8f30c00000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "7116067", gasUsed: "26317", confirmations: "1136595"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[15]}, {type: "uint256", name: "value", value: "500000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[15], "500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1540783057 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "663862000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[15], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6603006", timeStamp: "1540783459", hash: "0x599c6a56cb7dda1a12df0643b38db64e016fc1580b2ed568ef6377b9a3e7011d", nonce: "52", blockHash: "0x7fd2fecba3c826621bb4648a5a9477fb04768f2142c32e10fa1640be7036d258", transactionIndex: "135", from: "0x2da1b5cc751bf78a97dc8965fe47648a7f3f2a95", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "100000", gasPrice: "2000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb00000000000000000000000009356678898bc9df23cbc45a199ed947e0b8f30c00000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "7785184", gasUsed: "26317", confirmations: "1136567"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[15]}, {type: "uint256", name: "value", value: "500000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[15], "500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1540783459 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "663862000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setLockValue( addressList[14], \"150000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6642817", timeStamp: "1541346986", hash: "0x2a72abc80fae1b871aa2c8195617ad6c2a0e867e5ed01794b472a6a76ccd5118", nonce: "233", blockHash: "0x3c847ff49ded8caca3041bc3e9b7dd3dfc3dfc7e431c5e1e20d5ede9756dfe90", transactionIndex: "111", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "49071", gasPrice: "9281259281", isError: "0", txreceipt_status: "1", input: "0xd712800f0000000000000000000000002a8855bcfc4d15ace64a113108189382b4b5f7ef000000000000000000000000000000000000000000013da329b63364718000000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000b666f722054636f6e6f6d79000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5650806", gasUsed: "49071", confirmations: "1096756"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[14]}, {type: "uint256", name: "value", value: "1500000000000000000000000"}, {type: "string", name: "note", value: `for Tconomy`}], name: "setLockValue", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setLockValue(address,uint256,string)" ]( addressList[14], "1500000000000000000000000", `for Tconomy`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541346986 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "SetLockValue", type: "event"} ;
		console.error( "eventCallOriginal[28,16] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "SetLockValue", events: [{name: "addr", type: "address", value: "0x2a8855bcfc4d15ace64a113108189382b4b5f7ef"}, {name: "value", type: "uint256", value: "1500000000000000000000000"}, {name: "note", type: "string", value: "for Tconomy"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[28,16] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: unlockTo( addressList[14], `for Tconomy` )", async function( ) {
		const txOriginal = {blockNumber: "6642825", timeStamp: "1541347121", hash: "0xed9abc2e02a416404bc666dc22df323f6450bd712be91d1809e716fa68fd362c", nonce: "234", blockHash: "0xfddd546f2e76d1d0562bd695a39519e6bf1741a9363ec33515ce79412846499b", transactionIndex: "72", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "47928", gasPrice: "9900000000", isError: "0", txreceipt_status: "1", input: "0x003078b00000000000000000000000002a8855bcfc4d15ace64a113108189382b4b5f7ef0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000b666f722054636f6e6f6d79000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5123579", gasUsed: "47928", confirmations: "1096748"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[14]}, {type: "string", name: "note", value: `for Tconomy`}], name: "unlockTo", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "unlockTo(address,string)" ]( addressList[14], `for Tconomy`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541347121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "addr", type: "address"}, {indexed: false, name: "locked", type: "bool"}, {indexed: false, name: "note", type: "string"}], name: "LockedTo", type: "event"} ;
		console.error( "eventCallOriginal[29,15] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LockedTo", events: [{name: "addr", type: "address", value: "0x2a8855bcfc4d15ace64a113108189382b4b5f7ef"}, {name: "locked", type: "bool", value: false}, {name: "note", type: "string", value: "for Tconomy"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[29,15] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[16], \"400000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6666756", timeStamp: "1541687098", hash: "0x3ca014486161c77c3340b6306fc16faa73edc61e2bf4a589addb517c1f51af30", nonce: "400", blockHash: "0x5fdc64e932b876427d59f871e5e12f524c99d858720e743789fbce732633ef6d", transactionIndex: "39", from: "0x87741bdbc3e01fbed29caead759734da7f1336dc", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "51690", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb00000000000000000000000087741bdbc3e01fbed29caead759734da7f1336dc000000000000000000000000000000000000000000000015af1d78b58c400000", contractAddress: "", cumulativeGasUsed: "2960283", gasUsed: "26317", confirmations: "1072817"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[16]}, {type: "uint256", name: "value", value: "400000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[16], "400000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541687098 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "8719162319462346" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[18], \"800000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6676303", timeStamp: "1541822554", hash: "0x06eaf83256c5c4e311798e7d7dc7bb90273880750f87c46d0b578fac8de923d9", nonce: "13", blockHash: "0x17d6ff80db57d9c46fac61f6282a6e04d40eccaedab62f83e28aebdc1e4a6ddb", transactionIndex: "80", from: "0xd7be0a835f1dabd569bf5472024aa7b85e3410b0", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "60000", gasPrice: "7100000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000305d2ba085c5fcc1a6c4de6a74471fd9e17cc85e00000000000000000000000000000000000000000000002b5e3af16b18800000", contractAddress: "", cumulativeGasUsed: "4939887", gasUsed: "26317", confirmations: "1063270"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[18]}, {type: "uint256", name: "value", value: "800000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[18], "800000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541822554 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[18], \"800000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6682126", timeStamp: "1541904667", hash: "0x85477d71253e67d2cbdacf94b0ff581661d2ca26409058ad70096c482f36a919", nonce: "14", blockHash: "0xa9f602010700f31be2718917570af357f92126262ad48022ffa0ce5dba7ff434", transactionIndex: "144", from: "0xd7be0a835f1dabd569bf5472024aa7b85e3410b0", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "60000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb000000000000000000000000305d2ba085c5fcc1a6c4de6a74471fd9e17cc85e00000000000000000000000000000000000000000000002b5e3af16b18800000", contractAddress: "", cumulativeGasUsed: "7416933", gasUsed: "26317", confirmations: "1057447"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[18]}, {type: "uint256", name: "value", value: "800000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[18], "800000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541904667 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "0" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: kscSell( addressList[3], addressList[19], \"40000... )", async function( ) {
		const txOriginal = {blockNumber: "6689864", timeStamp: "1542014461", hash: "0x4428b821d3d262fd78348ec31d05894053ebe4d714d2ae3d08df2f1ed3bed435", nonce: "235", blockHash: "0x99cfdd0960b3b52c8f351fb046c6159defae8dac42c4f2ff2c2923fc6356d188", transactionIndex: "96", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "68584", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xc926aae6000000000000000000000000ec6bcfddec156d9f49e81cdffa734e02aa95ce71000000000000000000000000cd761146addac8a4d20f0265289285f9fbed01e40000000000000000000000000000000000000000000054b40b1f852bda000000000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000104b534320507269766174652053616c6500000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4139307", gasUsed: "68584", confirmations: "1049709"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "to", value: addressList[19]}, {type: "uint256", name: "value", value: "400000000000000000000000"}, {type: "string", name: "note", value: `KSC Private Sale`}], name: "kscSell", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "kscSell(address,address,uint256,string)" ]( addressList[3], addressList[19], "400000000000000000000000", `KSC Private Sale`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542014461 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCSell", type: "event"} ;
		console.error( "eventCallOriginal[33,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCSell", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0xcd761146addac8a4d20f0265289285f9fbed01e4"}, {name: "value", type: "uint256", value: "400000000000000000000000"}, {name: "note", type: "string", value: "KSC Private Sale"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[33,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0xcd761146addac8a4d20f0265289285f9fbed01e4"}, {name: "value", type: "uint256", value: "400000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[33,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: kscBatchTransferToBounty( addressList[3], [addressList[20],address... )", async function( ) {
		const txOriginal = {blockNumber: "6689882", timeStamp: "1542014856", hash: "0x5896f382932e516c8c0f72767ef347bd7c21db85211a173014d75da1fe9cf522", nonce: "236", blockHash: "0x753b14e72b8aab782ae7de7910d7bf7922320faa73f728126819dbb4e95ed4fc", transactionIndex: "198", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "160205", gasPrice: "11600000000", isError: "0", txreceipt_status: "1", input: "0xe1567997000000000000000000000000ec6bcfddec156d9f49e81cdffa734e02aa95ce7100000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000024000000000000000000000000000000000000000000000000000000000000000030000000000000000000000004ce9d45c6550d8702a43ee815fe65345e00160c0000000000000000000000000e68ba179c4fc6444fa8fb5a8978decdde751a0160000000000000000000000008dcdc06c2acc184a2debf0fc41deeae966e3ee43000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000006c6b935b8bbd40000000000000000000000000000000000000000000000000006c6b935b8bbd40000000000000000000000000000000000000000000000000006c6b935b8bbd4000000000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001a4b53432050726976617465204d65657475702041697264726f70000000000000", contractAddress: "", cumulativeGasUsed: "6259453", gasUsed: "160205", confirmations: "1049691"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address[]", name: "to", value: [addressList[20],addressList[21],addressList[22]]}, {type: "uint256[]", name: "values", value: ["2000000000000000000000","2000000000000000000000","2000000000000000000000"]}, {type: "uint256", name: "processIdHash", value: "0"}, {type: "uint256[]", name: "userIdHash", value: ["0","0","0"]}, {type: "string", name: "note", value: `KSC Private Meetup Airdrop`}], name: "kscBatchTransferToBounty", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "kscBatchTransferToBounty(address,address[],uint256[],uint256,uint256[],string)" ]( addressList[3], [addressList[20],addressList[21],addressList[22]], ["2000000000000000000000","2000000000000000000000","2000000000000000000000"], "0", ["0","0","0"], `KSC Private Meetup Airdrop`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542014856 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "processIdHash", type: "uint256"}, {indexed: false, name: "userIdHash", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCTransferToBounty", type: "event"} ;
		console.error( "eventCallOriginal[34,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCTransferToBounty", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x4ce9d45c6550d8702a43ee815fe65345e00160c0"}, {name: "value", type: "uint256", value: "2000000000000000000000"}, {name: "processIdHash", type: "uint256", value: "0"}, {name: "userIdHash", type: "uint256", value: "0"}, {name: "note", type: "string", value: "KSC Private Meetup Airdrop"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}, {name: "KSCTransferToBounty", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0xe68ba179c4fc6444fa8fb5a8978decdde751a016"}, {name: "value", type: "uint256", value: "2000000000000000000000"}, {name: "processIdHash", type: "uint256", value: "0"}, {name: "userIdHash", type: "uint256", value: "0"}, {name: "note", type: "string", value: "KSC Private Meetup Airdrop"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}, {name: "KSCTransferToBounty", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x8dcdc06c2acc184a2debf0fc41deeae966e3ee43"}, {name: "value", type: "uint256", value: "2000000000000000000000"}, {name: "processIdHash", type: "uint256", value: "0"}, {name: "userIdHash", type: "uint256", value: "0"}, {name: "note", type: "string", value: "KSC Private Meetup Airdrop"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[34,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x4ce9d45c6550d8702a43ee815fe65345e00160c0"}, {name: "value", type: "uint256", value: "2000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0xe68ba179c4fc6444fa8fb5a8978decdde751a016"}, {name: "value", type: "uint256", value: "2000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}, {name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x8dcdc06c2acc184a2debf0fc41deeae966e3ee43"}, {name: "value", type: "uint256", value: "2000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[34,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6712768", timeStamp: "1542338065", hash: "0xbfb5bf6b39b7a7688b045aedabfe257201ed7c866ebcbe3e56c7a40af8026512", nonce: "41", blockHash: "0xdd201a993bf367c601f8ee23ceb3f8deb8ab12bab932acdca8dc3af671766a59", transactionIndex: "78", from: "0x24292d717b67a1d57679dc9c76ac65839be3dfde", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "100000", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7550725", gasUsed: "21046", confirmations: "1026805"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542338065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "525202991230545" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[25], \"982500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6721105", timeStamp: "1542455564", hash: "0xc3a6004e703fca667e6dc35b1ba7c32b256def255b0f3c1fbd4e112290cca41f", nonce: "125", blockHash: "0x2e84431d6937125e74b0c0f6b8ffe7d356bc8d1e8f08b42b4e7c3c9f210aa2e2", transactionIndex: "48", from: "0x5eb08b376add73af1f9bbdc76a9bb61c11020c12", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "55420", gasPrice: "3000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb00000000000000000000000073f9f89a12f8c8d75561601dcfa66c9d1b79b31f0000000000000000000000000000000000000000000002149d43e4eb44e40000", contractAddress: "", cumulativeGasUsed: "6146309", gasUsed: "26381", confirmations: "1018468"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[25]}, {type: "uint256", name: "value", value: "9825000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[25], "9825000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542455564 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "508048914379000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: kscSell( addressList[3], addressList[26], \"20000... )", async function( ) {
		const txOriginal = {blockNumber: "6738246", timeStamp: "1542698557", hash: "0x42f12e6df938b4355560204a51b2debfc70739b3793d89d4f3ddd360b0a76960", nonce: "237", blockHash: "0x8641325b5a04289b663ff369b9d0704aa7cb568436d25e2256da24d18645af58", transactionIndex: "52", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "68328", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xc926aae6000000000000000000000000ec6bcfddec156d9f49e81cdffa734e02aa95ce710000000000000000000000003e11a42bcb96a95d2262b736a97e7651e2c3a895000000000000000000000000000000000000000000002a5a058fc295ed0000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000c507269766174652053616c650000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1939131", gasUsed: "68328", confirmations: "1001327"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "to", value: addressList[26]}, {type: "uint256", name: "value", value: "200000000000000000000000"}, {type: "string", name: "note", value: `Private Sale`}], name: "kscSell", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "kscSell(address,address,uint256,string)" ]( addressList[3], addressList[26], "200000000000000000000000", `Private Sale`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542698557 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCSell", type: "event"} ;
		console.error( "eventCallOriginal[37,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCSell", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x3e11a42bcb96a95d2262b736a97e7651e2c3a895"}, {name: "value", type: "uint256", value: "200000000000000000000000"}, {name: "note", type: "string", value: "Private Sale"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[37,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x3e11a42bcb96a95d2262b736a97e7651e2c3a895"}, {name: "value", type: "uint256", value: "200000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[37,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: kscSell( addressList[3], addressList[27], \"12000... )", async function( ) {
		const txOriginal = {blockNumber: "6738315", timeStamp: "1542699469", hash: "0xcb1d134eae2906680e052d49bced0ae2a6453ea83d7a8938c800b8842e3e7a44", nonce: "238", blockHash: "0xde2860836dd65d37dbe26e6816a7d636fe476b230901068fb8faf08ea80c74e0", transactionIndex: "136", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "68328", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xc926aae6000000000000000000000000ec6bcfddec156d9f49e81cdffa734e02aa95ce710000000000000000000000006911168e426104f52a523bcb207e6ca40b0682b8000000000000000000000000000000000000000000001969368974c05b0000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000c507269766174652053616c650000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5925863", gasUsed: "68328", confirmations: "1001258"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "to", value: addressList[27]}, {type: "uint256", name: "value", value: "120000000000000000000000"}, {type: "string", name: "note", value: `Private Sale`}], name: "kscSell", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "kscSell(address,address,uint256,string)" ]( addressList[3], addressList[27], "120000000000000000000000", `Private Sale`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542699469 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCSell", type: "event"} ;
		console.error( "eventCallOriginal[38,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCSell", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x6911168e426104f52a523bcb207e6ca40b0682b8"}, {name: "value", type: "uint256", value: "120000000000000000000000"}, {name: "note", type: "string", value: "Private Sale"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[38,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[38,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0x6911168e426104f52a523bcb207e6ca40b0682b8"}, {name: "value", type: "uint256", value: "120000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[38,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: kscSell( addressList[3], addressList[28], \"12000... )", async function( ) {
		const txOriginal = {blockNumber: "6738323", timeStamp: "1542699543", hash: "0x34ddc0ba85e66def3e28ad5fbdd615eaee6a0a25a604fb6cf2ad8b32cbf246f3", nonce: "239", blockHash: "0xa20ad7d34b9ac2e09b85e483215450bcc0a5c28953321838988c3e90b53c8343", transactionIndex: "92", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "68328", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xc926aae6000000000000000000000000ec6bcfddec156d9f49e81cdffa734e02aa95ce71000000000000000000000000a3ccb8f2c5a78645801c12ec886e2f16dcd54e58000000000000000000000000000000000000000000001969368974c05b0000000000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000c507269766174652053616c650000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2921111", gasUsed: "68328", confirmations: "1001250"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "from", value: addressList[3]}, {type: "address", name: "to", value: addressList[28]}, {type: "uint256", name: "value", value: "120000000000000000000000"}, {type: "string", name: "note", value: `Private Sale`}], name: "kscSell", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "kscSell(address,address,uint256,string)" ]( addressList[3], addressList[28], "120000000000000000000000", `Private Sale`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542699543 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCSell", type: "event"} ;
		console.error( "eventCallOriginal[39,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCSell", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0xa3ccb8f2c5a78645801c12ec886e2f16dcd54e58"}, {name: "value", type: "uint256", value: "120000000000000000000000"}, {name: "note", type: "string", value: "Private Sale"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[39,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "from", type: "address"}, {indexed: true, name: "to", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "from", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "to", type: "address", value: "0xa3ccb8f2c5a78645801c12ec886e2f16dcd54e58"}, {name: "value", type: "uint256", value: "120000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[39,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[30], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6834364", timeStamp: "1544067446", hash: "0x63322b9350079700adee78b3161bd74d8d0a0cbd700d6e4bfd2f199ac6a7a71a", nonce: "247", blockHash: "0x005e1c5777497adb88d9e8395e7557ff371fd0c48f06f1918f30634104af39b0", transactionIndex: "36", from: "0xa61f5c6d1d8ea9e5a7127e709b620b12f8b37784", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "35000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb00000000000000000000000024a30224a92ed63818511b7559b30a19d7c9513500000000000000000000000000000000000000000000000ad78ebc5ac6200000", contractAddress: "", cumulativeGasUsed: "1872976", gasUsed: "26317", confirmations: "905209"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[30]}, {type: "uint256", name: "value", value: "200000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[30], "200000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1544067446 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "275234859507954" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: transfer( addressList[31], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6851212", timeStamp: "1544309019", hash: "0x52aaeb522c2527ce45382c58b1a8a1a3a76449a399b12dfd5cfaf04cfd0299bc", nonce: "57", blockHash: "0x225ff867114579afbb5df429bf5e112a7e17cdae56cd0942fb612b2dd14a7167", transactionIndex: "46", from: "0x2da1b5cc751bf78a97dc8965fe47648a7f3f2a95", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "100000", gasPrice: "4000000000", isError: "1", txreceipt_status: "0", input: "0xa9059cbb0000000000000000000000000f98524e32f788b9392238b4a3d20c5b6c31bf6500000000000000000000000000000000000000000000001b1ae4d6e2ef500000", contractAddress: "", cumulativeGasUsed: "3235255", gasUsed: "26317", confirmations: "888361"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "to", value: addressList[31]}, {type: "uint256", name: "value", value: "500000000000000000000"}], name: "transfer", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transfer(address,uint256)" ]( addressList[31], "500000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1544309019 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "663862000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[32], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6855978", timeStamp: "1544376825", hash: "0xb72809d7677a6480d62a03f0696e83760868aa40b8d5a03ff3a1100ea69bc7ad", nonce: "284", blockHash: "0xe553712bd68c0b4b58d6d017e5e3c80b2127313b6efa01a02deb524b82cb846f", transactionIndex: "14", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000d5486e1bf4b1a06056a4b6276d8fb75ef1bd5878000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "6281131", gasUsed: "48570", confirmations: "883595"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[32]}, {type: "uint256", name: "value", value: "10000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[32], "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1544376825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[42,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xd5486e1bf4b1a06056a4b6276d8fb75ef1bd5878"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[42,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[42,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xd5486e1bf4b1a06056a4b6276d8fb75ef1bd5878"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[42,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[32] )", async function( ) {
		const txOriginal = {blockNumber: "6855978", timeStamp: "1544376825", hash: "0xe8a374c00bd18d5b6353266b7920f146b40d07876c0eb782ff0e89aefe368256", nonce: "285", blockHash: "0xe553712bd68c0b4b58d6d017e5e3c80b2127313b6efa01a02deb524b82cb846f", transactionIndex: "15", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "71377", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x85952454000000000000000000000000d5486e1bf4b1a06056a4b6276d8fb75ef1bd5878", contractAddress: "", cumulativeGasUsed: "6352508", gasUsed: "71377", confirmations: "883595"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[32]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[32], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1544376825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[43,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0xd5486e1bf4b1a06056a4b6276d8fb75ef1bd5878"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[43,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[33], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6855978", timeStamp: "1544376825", hash: "0xc766bba53ea3dd46b8f49d6b6f371a1cf0121a47991a3f7ce821c5e9b81913ec", nonce: "286", blockHash: "0xe553712bd68c0b4b58d6d017e5e3c80b2127313b6efa01a02deb524b82cb846f", transactionIndex: "16", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b300000000000000000000000097661c6a48f1a71ef1b950b7ab417cc2d4932932000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "6401078", gasUsed: "48570", confirmations: "883595"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[33]}, {type: "uint256", name: "value", value: "10000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[33], "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1544376825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0x97661c6a48f1a71ef1b950b7ab417cc2d4932932"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[44,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0x97661c6a48f1a71ef1b950b7ab417cc2d4932932"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[44,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[33] )", async function( ) {
		const txOriginal = {blockNumber: "6855978", timeStamp: "1544376825", hash: "0x8b750ec1218c493815c65eed23ee7a275fa2c03229bfe2f286b90144661aebc6", nonce: "287", blockHash: "0xe553712bd68c0b4b58d6d017e5e3c80b2127313b6efa01a02deb524b82cb846f", transactionIndex: "17", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "71377", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x8595245400000000000000000000000097661c6a48f1a71ef1b950b7ab417cc2d4932932", contractAddress: "", cumulativeGasUsed: "6472455", gasUsed: "71377", confirmations: "883595"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[33]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[33], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1544376825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[45,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0x97661c6a48f1a71ef1b950b7ab417cc2d4932932"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[45,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[34], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6855978", timeStamp: "1544376825", hash: "0x1323c345222bcc0cbabbd929a3dc81660e536c8a584e785831df5df8df7756c5", nonce: "288", blockHash: "0xe553712bd68c0b4b58d6d017e5e3c80b2127313b6efa01a02deb524b82cb846f", transactionIndex: "18", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000c0a2f75a9158cf0d76719e1329538a558b72df89000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "6521025", gasUsed: "48570", confirmations: "883595"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[34]}, {type: "uint256", name: "value", value: "10000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[34], "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1544376825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xc0a2f75a9158cf0d76719e1329538a558b72df89"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[46,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xc0a2f75a9158cf0d76719e1329538a558b72df89"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[46,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[34] )", async function( ) {
		const txOriginal = {blockNumber: "6855978", timeStamp: "1544376825", hash: "0xef71f3f881a5f63b5d9e5ce42282ae324eca4d82e62fd29a5b0080c497c2e889", nonce: "289", blockHash: "0xe553712bd68c0b4b58d6d017e5e3c80b2127313b6efa01a02deb524b82cb846f", transactionIndex: "19", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "71377", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x85952454000000000000000000000000c0a2f75a9158cf0d76719e1329538a558b72df89", contractAddress: "", cumulativeGasUsed: "6592402", gasUsed: "71377", confirmations: "883595"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[34]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[34], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1544376825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[47,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0xc0a2f75a9158cf0d76719e1329538a558b72df89"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[47,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: approve( addressList[35], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6855978", timeStamp: "1544376825", hash: "0xac9e0af80cf09fe40029f41f917e77f717774df618b9910466a41b94e78e501e", nonce: "290", blockHash: "0xe553712bd68c0b4b58d6d017e5e3c80b2127313b6efa01a02deb524b82cb846f", transactionIndex: "20", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "48570", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x095ea7b3000000000000000000000000ef4e3140fe267f2067f323ebae83c359cef5fb1f000000000000000000000000000000000000000000084595161401484a000000", contractAddress: "", cumulativeGasUsed: "6640972", gasUsed: "48570", confirmations: "883595"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "spender", value: addressList[35]}, {type: "uint256", name: "value", value: "10000000000000000000000000"}], name: "approve", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "approve(address,uint256)" ]( addressList[35], "10000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1544376825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "note", type: "string"}], name: "KSCApproval", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "KSCApproval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xef4e3140fe267f2067f323ebae83c359cef5fb1f"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}, {name: "note", type: "string", value: ""}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "owner", type: "address"}, {indexed: true, name: "spender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "Approval", type: "event"} ;
		console.error( "eventCallOriginal[48,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Approval", events: [{name: "owner", type: "address", value: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71"}, {name: "spender", type: "address", value: "0xef4e3140fe267f2067f323ebae83c359cef5fb1f"}, {name: "value", type: "uint256", value: "10000000000000000000000000"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[48,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: newOwner( addressList[35] )", async function( ) {
		const txOriginal = {blockNumber: "6855978", timeStamp: "1544376825", hash: "0x44289601fd5b1456ac9e99bdc05d22c3b7fa36d6bf12d26a9f9f781722469403", nonce: "291", blockHash: "0xe553712bd68c0b4b58d6d017e5e3c80b2127313b6efa01a02deb524b82cb846f", transactionIndex: "21", from: "0xec6bcfddec156d9f49e81cdffa734e02aa95ce71", to: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280", value: "0", gas: "71377", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x85952454000000000000000000000000ef4e3140fe267f2067f323ebae83c359cef5fb1f", contractAddress: "", cumulativeGasUsed: "6712349", gasUsed: "71377", confirmations: "883595"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[35]}], name: "newOwner", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "newOwner(address)" ]( addressList[35], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1544376825 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newOwner", type: "address"}], name: "AddedNewOwner", type: "event"} ;
		console.error( "eventCallOriginal[49,19] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddedNewOwner", events: [{name: "newOwner", type: "address", value: "0xef4e3140fe267f2067f323ebae83c359cef5fb1f"}], address: "0x990e081a7b7d3ccba26a2f49746a68cc4ff73280"}] ;
		console.error( "eventResultOriginal[49,19] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "2029020488184450165" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
