const KYCCrowdsale = artifacts.require( "./KYCCrowdsale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "KYCCrowdsale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xEF0F5D9A8435E217038d6417670013Cc06aA5E38", "0xa684A3371E0d46bCA4A6DB1FF538a44f1440A855", "0x1a7a8BD9106F2B8D977E08582DC7d24c723ab0DB", "0xe74BE15Ae490c348fD75615cEfF8657f30ac074C", "0x5311724C476327Db0d5D1Fc41Cc58a466F3974bd", "0x4D79e7a45c067D7698B838F8AEe4ce6f340eFB30", "0xDA60A8bBdF59e60d344781c6fd531adc429A6644", "0x1c5e4db864861D9b6203bd86Af0C0B5ffcD6115d", "0x7cdBD9D29C9280061e095Ce1Bd819B295F426Df6", "0xb6a34Bd460f02241e80e031023ec20ce6FC310AE", "0x728b54B93E6e8666c24b21c0bf36bd6296DD9EfA", "0x93d18eA8694B7D9019bcf11018BC36a6f89b0d7E", "0x1186Fe1aD46255bEAdcdCcBD6724d8Dfd639CB4e", "0xca0d9fCA102C5535867410C36aEFAF114b97E202", "0xCf477dd4bFddFe8a006c709C752206b353D6E231", "0x777ea5Df73EcA53A1f4eF84487154fBf15e22767", "0xa6229D804a9B55DD6A1010CEe80F7C49b5aB79b7", "0x40da6678c89D778Af74d4AF11Fd67b73A6Ed52d3", "0x08548AF3414D04416F96f60CB1c39dC8EA927B4c", "0x3dac0161a9a713399E9Fa1a0551E9F66B1C55748", "0x67646CeD30F8e29d134aA82fd8F22D4e4dd03250", "0x9Caa1741231D19D82f5A9bE4712Fea74C0Eb11F3", "0xF99eea25C277f490C6Db0BdD9B10A756E6590c5b", "0xD0A5F731Eb92c1a4eb7b4945A8CF4CBDae77CE44", "0x9eF5468fCd0D9B1a05c84FeBFBEc979e2f100f5f", "0xFF6E18566c66855719595D1dAfE706e238c32e5A", "0xAA4284c28DA8c59F249D3cf93B508cF16b5CdA3d", "0x8042c891AA3487f8B56DeEe3E90264e6D9ea9793", "0xC30FF49429b3077fc2B9A910B072F2300dC41B9A", "0xEE4CB0c022E87c2B6598Ed12Af6a06bB390c2ae2", "0x1Ee51a66A15bC4FbbC08B47E3C0caDD798467D11", "0x35Af967ACeAB29501D27E02a74d82B98898081E4", "0x316b97c21Bc987d9B3642d6077C3efeC6D30fD23", "0x93Dc33d2EAFcD212879d4833202F99eC453A6e18", "0xE121FE7868969D5CdcAF8dab89848Ea2B0C65dd4", "0xe3D53f82f44b07b5d144a099c4E6AdA5EF8B5775", "0xE18c718Dcb06f42385E37d470A5eBC6E66022A5E", "0x9D8D9D80Cb04B4a326E881F64E1D69beBBba0795", "0x4A9A3815060C3Bd08fb4d44C9e74513874771b0C", "0xbaEb1F9fD567f4c46Dc47298cB28961CB9a83D4e", "0x40cf5AbEEBaDeD527d751d829f82214Aff60eEcD"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "ownerTestValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isPricingSane", outputs: [{name: "sane", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "endsAt", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minimumFundingGoal", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getState", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "investedAmountOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "finalizeAgent", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "beneficiary", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isCrowdsale", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "testState", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "signerAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "weiRefunded", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MAX_INVESTMENTS_BEFORE_MULTISIG_CHANGE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "dataframe", type: "bytes"}], name: "getKYCPayload", outputs: [{name: "whitelistedAddress", type: "address"}, {name: "customerId", type: "uint128"}, {name: "minEth", type: "uint32"}, {name: "maxEth", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "pricingStrategy", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "loadedRefund", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isMinimumGoalReached", outputs: [{name: "reached", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multisigWallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "tokenAmountOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "weiAmount", type: "uint256"}, {name: "tokenAmount", type: "uint256"}, {name: "weiRaisedTotal", type: "uint256"}, {name: "tokensSoldTotal", type: "uint256"}], name: "isBreakingCap", outputs: [{name: "limitBroken", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isFinalizerSane", outputs: [{name: "sane", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startsAt", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "finalized", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "earlyParticipantWhitelist", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isCrowdsaleFull", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getTokensLeft", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "presaleWeiRaised", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "signer", type: "address"}], name: "SignerChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}], name: "Refund", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newRequireCustomerId", type: "bool"}, {indexed: false, name: "newRequiredSignedAddress", type: "bool"}, {indexed: false, name: "newSignerAddress", type: "address"}], name: "InvestmentPolicyChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newEndsAt", type: "uint256"}], name: "EndsAtChanged", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["SignerChanged(address)", "Invested(address,uint256,uint256,uint128)", "Refund(address,uint256)", "InvestmentPolicyChanged(bool,bool,address)", "Whitelisted(address,bool)", "EndsAtChanged(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x5719a5656c5cfdaafa148ecf366fd3b0a7fae06449ce2a46225977fb7417e29d", "0x0396f60aaad038749091d273dc13aaabc63db6e2271c7bad442d5cf25cc43350", "0xbb28353e4598c3b9199101a66e0989549b659a59a54d2c27fbb183f1932c8e6d", "0x48d826081348f5f00e8a33c9ae8ce89ed4c6e88400b585a478bc203d9e8177d3", "0xa54714518c5d275fdcd3d2a461e4858e4e8cb04fb93cd0bca9d6d34115f26440", "0xd34bb772c4ae9baa99db852f622773b31c7827e8ee818449fef20d30980bd310"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4501657 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4502444 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}, {type: "address", name: "_pricingStrategy", value: 5}, {type: "address", name: "_multisigWallet", value: 6}, {type: "uint256", name: "_start", value: "1509955200"}, {type: "uint256", name: "_end", value: "1512579600"}, {type: "uint256", name: "_minimumFundingGoal", value: "1"}, {type: "address", name: "_beneficiary", value: 3}], name: "KYCCrowdsale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "ownerTestValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerTestValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isPricingSane", outputs: [{name: "sane", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPricingSane()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endsAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endsAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimumFundingGoal", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimumFundingGoal()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "investedAmountOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investedAmountOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finalizeAgent", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalizeAgent()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "beneficiary", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "beneficiary()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isCrowdsale", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isCrowdsale()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "testState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "testState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "signerAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "signerAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRefunded", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRefunded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_INVESTMENTS_BEFORE_MULTISIG_CHANGE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_INVESTMENTS_BEFORE_MULTISIG_CHANGE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getKYCPayload", outputs: [{name: "whitelistedAddress", type: "address"}, {name: "customerId", type: "uint128"}, {name: "minEth", type: "uint32"}, {name: "maxEth", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getKYCPayload(bytes)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pricingStrategy", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pricingStrategy()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "loadedRefund", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "loadedRefund()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isMinimumGoalReached", outputs: [{name: "reached", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isMinimumGoalReached()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multisigWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multisigWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokenAmountOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenAmountOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "weiAmount", value: random.range( maxRandom )}, {type: "uint256", name: "tokenAmount", value: random.range( maxRandom )}, {type: "uint256", name: "weiRaisedTotal", value: random.range( maxRandom )}, {type: "uint256", name: "tokensSoldTotal", value: random.range( maxRandom )}], name: "isBreakingCap", outputs: [{name: "limitBroken", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isBreakingCap(uint256,uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isFinalizerSane", outputs: [{name: "sane", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isFinalizerSane()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startsAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startsAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finalized", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalized()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "halted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "earlyParticipantWhitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "earlyParticipantWhitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isCrowdsaleFull", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isCrowdsaleFull()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTokensLeft", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokensLeft()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "presaleWeiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "presaleWeiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "KYCCrowdsale", function( accounts ) {

	it( "TEST: KYCCrowdsale( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4501657", timeStamp: "1509977644", hash: "0x39007aec079c8e908c40e622552455728158610f3b3c1cb86de9dc4fc07fde98", nonce: "6", blockHash: "0xaa12e43cccde98c7d07f89ed2f8c50408b635fbda7a3632c1767058253cb9e2b", transactionIndex: "34", from: "0xa684a3371e0d46bca4a6db1ff538a44f1440a855", to: 0, value: "0", gas: "2766373", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xcd0412d70000000000000000000000001a7a8bd9106f2b8d977e08582dc7d24c723ab0db000000000000000000000000e74be15ae490c348fd75615ceff8657f30ac074c0000000000000000000000005311724c476327db0d5d1fc41cc58a466f3974bd000000000000000000000000000000000000000000000000000000005a001680000000000000000000000000000000000000000000000000000000005a2822100000000000000000000000000000000000000000000000000000000000000001000000000000000000000000a684a3371e0d46bca4a6db1ff538a44f1440a855", contractAddress: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", cumulativeGasUsed: "4397019", gasUsed: "2666373", confirmations: "3234325"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "address", name: "_pricingStrategy", value: addressList[5]}, {type: "address", name: "_multisigWallet", value: addressList[6]}, {type: "uint256", name: "_start", value: "1509955200"}, {type: "uint256", name: "_end", value: "1512579600"}, {type: "uint256", name: "_minimumFundingGoal", value: "1"}, {type: "address", name: "_beneficiary", value: addressList[3]}], name: "KYCCrowdsale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = KYCCrowdsale.new( addressList[4], addressList[5], addressList[6], "1509955200", "1512579600", "1", addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509977644 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = KYCCrowdsale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "860123965495000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setFinalizeAgent( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4501668", timeStamp: "1509977757", hash: "0x469bf42fcc0ccb53ae3da774a1a7d106e93f42ca5e733640f8f2ad6c61983e49", nonce: "12", blockHash: "0xa21d8ec0902ee1d19cb8041502550ef0691305fb05fc98de37f3765871312159", transactionIndex: "104", from: "0xa684a3371e0d46bca4a6db1ff538a44f1440a855", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "0", gas: "145537", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x19b667da0000000000000000000000004d79e7a45c067d7698b838f8aee4ce6f340efb30", contractAddress: "", cumulativeGasUsed: "4556152", gasUsed: "45537", confirmations: "3234314"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[7]}], name: "setFinalizeAgent", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFinalizeAgent(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509977757 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "860123965495000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setSignerAddress( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "4501670", timeStamp: "1509977791", hash: "0xa41c62adf4c0f611beac6020a0e2415042d74f4d75071a472d5b1cca29cb55a9", nonce: "13", blockHash: "0x40c363132ce33011fddcf9859c87c21009c3d18dfcf93064e2f69c0c0f9fe5fc", transactionIndex: "72", from: "0xa684a3371e0d46bca4a6db1ff538a44f1440a855", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "0", gas: "144733", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x046dc166000000000000000000000000da60a8bbdf59e60d344781c6fd531adc429a6644", contractAddress: "", cumulativeGasUsed: "2362612", gasUsed: "44733", confirmations: "3234312"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_signerAddress", value: addressList[8]}], name: "setSignerAddress", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setSignerAddress(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1509977791 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "signer", type: "address"}], name: "SignerChanged", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SignerChanged", events: [{name: "signer", type: "address", value: "0xda60a8bbdf59e60d344781c6fd531adc429a6644"}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "860123965495000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setEarlyParicipantWhitelist( addressList[3], true )", async function( ) {
		const txOriginal = {blockNumber: "4501676", timeStamp: "1509977864", hash: "0x18999b1609feafd0a712a0c32b0b70804729002ebd4c68681b3aa927056ebcd9", nonce: "16", blockHash: "0x502ff7bf51a2d059ad7617e893d9f0e047b858c779dee47d65fd0b8c5db1f9e0", transactionIndex: "4", from: "0xa684a3371e0d46bca4a6db1ff538a44f1440a855", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "0", gas: "146193", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xeac24932000000000000000000000000a684a3371e0d46bca4a6db1ff538a44f1440a8550000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "192315", gasUsed: "46193", confirmations: "3234306"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[3]}, {type: "bool", name: "status", value: true}], name: "setEarlyParicipantWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEarlyParicipantWhitelist(address,bool)" ]( addressList[3], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1509977864 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Whitelisted", events: [{name: "addr", type: "address", value: "0xa684a3371e0d46bca4a6db1ff538a44f1440a855"}, {name: "status", type: "bool", value: true}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "860123965495000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x\", \"0\", \"0x000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4501686", timeStamp: "1509978104", hash: "0xf0e07e0a7d5b32df5d212d70e1e5b7d72e57d3ca89d866030e7a2a428924df99", nonce: "17", blockHash: "0x19df762ec21b27860db055ae1b0a0b32d889dd1d2c699f91d0e1f8cca5dd3361", transactionIndex: "137", from: "0xa684a3371e0d46bca4a6db1ff538a44f1440a855", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "10000000000000000", gas: "2111333", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4436788", gasUsed: "199405", confirmations: "3234296"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x"}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x", "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509978104 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xa684a3371e0d46bca4a6db1ff538a44f1440a855"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "42780001957612889580"}, {name: "customerId", type: "uint128", value: {s: 1, e: 3, c: [4096]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "860123965495000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x1c5e4db864861d9b6203bd86af0c0b5ffcd6... )", async function( ) {
		const txOriginal = {blockNumber: "4501733", timeStamp: "1509978750", hash: "0x2ad1c3f327fc44fa291ba906f629d0366208967e2245fb379d0af0532aaaa1cd", nonce: "158", blockHash: "0x2cc91f6ad4c64be57ae77eb1786c399b9346f936ab4a633ecba021f787d06a20", transactionIndex: "18", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "100000000000000000", gas: "250000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b312fa7e425551bb53a6c0a8247b28bd9b7e5c88ae3a5c2364f0d5c149f9f9c067581f9382c71f81e643ea7159b1010e7f55fae1d1c62acdd89c1cda1b9fef7fb000000000000000000000000000000000000000000000000000000000000002c1c5e4db864861d9b6203bd86af0c0b5ffcd6115d480640fe717c4fd7b1d5f4de414d4fc80000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "875047", gasUsed: "212048", confirmations: "3234249"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d480640fe717c4fd7b1d5f4de414d4fc80000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x312fa7e425551bb53a6c0a8247b28bd9b7e5c88ae3a5c2364f0d5c149f9f9c06"}, {type: "bytes32", name: "s", value: "0x7581f9382c71f81e643ea7159b1010e7f55fae1d1c62acdd89c1cda1b9fef7fb"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d480640fe717c4fd7b1d5f4de414d4fc80000002100028d38", "27", "0x312fa7e425551bb53a6c0a8247b28bd9b7e5c88ae3a5c2364f0d5c149f9f9c06", "0x7581f9382c71f81e643ea7159b1010e7f55fae1d1c62acdd89c1cda1b9fef7fb", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509978750 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "weiAmount", type: "uint256", value: "100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "427800019576128895803"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [9573688771, 9551541021549, 19585663242184]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x1c5e4db864861d9b6203bd86af0c0b5ffcd6... )", async function( ) {
		const txOriginal = {blockNumber: "4501913", timeStamp: "1509981218", hash: "0x0f01a96462066f1423a480d4e49cefbe6ceadc923fefb252e1d3e65aed72a417", nonce: "159", blockHash: "0xa63598ab122fbd9779b4e417cb00ad3ff36ce4da7ef5b24a549486b9f2ea6188", transactionIndex: "8", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "150000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be37fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd000000000000000000000000000000000000000000000000000000000000002c1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "506991", gasUsed: "161833", confirmations: "3234069"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3"}, {type: "bytes32", name: "s", value: "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38", "27", "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3", "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1509981218 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "weiAmount", type: "uint256", value: "150000000000000000"}, {name: "tokenAmount", type: "uint256", value: "641700029364193343705"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10387462282, 84503913417459, 63653638617576]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x7cdbd9d29c9280061e095ce1bd819b295f42... )", async function( ) {
		const txOriginal = {blockNumber: "4501966", timeStamp: "1509981837", hash: "0x6281e65765a21c58ce1f450c9a79b95c97266b44c6472ccd2a6e20145a765947", nonce: "14", blockHash: "0xfbdd5affce5d77848751f3432c4f6fb260bd04b936b6d38536f505948b50b908", transactionIndex: "3", from: "0x7cdbd9d29c9280061e095ce1bd819b295f426df6", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "100000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c75f87520a89ca4de20a9ee6d100c038aee694b88f815c58a586755315f3b1a9d686d3681f6c3b09eba71c14d6a70f70803ffe1f30cc01da9085ce6a04613d8c8000000000000000000000000000000000000000000000000000000000000002c7cdbd9d29c9280061e095ce1bd819b295f426df6c48e41c13e1d44f9993921ff9b9be27b0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "316945", gasUsed: "212048", confirmations: "3234016"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x7cdbd9d29c9280061e095ce1bd819b295f426df6c48e41c13e1d44f9993921ff9b9be27b0000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x75f87520a89ca4de20a9ee6d100c038aee694b88f815c58a586755315f3b1a9d"}, {type: "bytes32", name: "s", value: "0x686d3681f6c3b09eba71c14d6a70f70803ffe1f30cc01da9085ce6a04613d8c8"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x7cdbd9d29c9280061e095ce1bd819b295f426df6c48e41c13e1d44f9993921ff9b9be27b0000002100028d38", "28", "0x75f87520a89ca4de20a9ee6d100c038aee694b88f815c58a586755315f3b1a9d", "0x686d3681f6c3b09eba71c14d6a70f70803ffe1f30cc01da9085ce6a04613d8c8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1509981837 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x7cdbd9d29c9280061e095ce1bd819b295f426df6"}, {name: "weiAmount", type: "uint256", value: "100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "427800019576128895803"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [26126732699, 46385144068854, 47758755127931]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "53466498079979000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x1c5e4db864861d9b6203bd86af0c0b5ffcd6... )", async function( ) {
		const txOriginal = {blockNumber: "4501995", timeStamp: "1509982295", hash: "0x888c87a7d8198fdc064e9dd54833135dc449493beb0589cd127a3037ba402a29", nonce: "160", blockHash: "0x18b0fa147360c9d792e94b2a7e914b2d8fd0c33ac9438e0c1ebd2564270329bc", transactionIndex: "28", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "10000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be37fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd000000000000000000000000000000000000000000000000000000000000002c1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1262262", gasUsed: "161833", confirmations: "3233987"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3"}, {type: "bytes32", name: "s", value: "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38", "27", "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3", "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1509982295 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "42780001957612889580"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10387462282, 84503913417459, 63653638617576]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x7cdbd9d29c9280061e095ce1bd819b295f42... )", async function( ) {
		const txOriginal = {blockNumber: "4501998", timeStamp: "1509982399", hash: "0x84cd2228c0480239918f90c79122e72513064862f372a9cbb8057cb0715de163", nonce: "15", blockHash: "0x72378f187e4b2991a670883fe2c594b8f7aeb2f702a75c66027c0045701c1f3e", transactionIndex: "16", from: "0x7cdbd9d29c9280061e095ce1bd819b295f426df6", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "40000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c75f87520a89ca4de20a9ee6d100c038aee694b88f815c58a586755315f3b1a9d686d3681f6c3b09eba71c14d6a70f70803ffe1f30cc01da9085ce6a04613d8c8000000000000000000000000000000000000000000000000000000000000002c7cdbd9d29c9280061e095ce1bd819b295f426df6c48e41c13e1d44f9993921ff9b9be27b0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "651327", gasUsed: "161833", confirmations: "3233984"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x7cdbd9d29c9280061e095ce1bd819b295f426df6c48e41c13e1d44f9993921ff9b9be27b0000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x75f87520a89ca4de20a9ee6d100c038aee694b88f815c58a586755315f3b1a9d"}, {type: "bytes32", name: "s", value: "0x686d3681f6c3b09eba71c14d6a70f70803ffe1f30cc01da9085ce6a04613d8c8"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x7cdbd9d29c9280061e095ce1bd819b295f426df6c48e41c13e1d44f9993921ff9b9be27b0000002100028d38", "28", "0x75f87520a89ca4de20a9ee6d100c038aee694b88f815c58a586755315f3b1a9d", "0x686d3681f6c3b09eba71c14d6a70f70803ffe1f30cc01da9085ce6a04613d8c8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1509982399 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x7cdbd9d29c9280061e095ce1bd819b295f426df6"}, {name: "weiAmount", type: "uint256", value: "40000000000000000"}, {name: "tokenAmount", type: "uint256", value: "171120007830451558321"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [26126732699, 46385144068854, 47758755127931]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "53466498079979000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x1c5e4db864861d9b6203bd86af0c0b5ffcd6... )", async function( ) {
		const txOriginal = {blockNumber: "4502022", timeStamp: "1509982740", hash: "0x40335efa738d8a3057259f39f1b3c277cdc1c73fb581dbf30d9b0365ff554cf0", nonce: "161", blockHash: "0x4c072e0da689bdbef238a77afa016b847b83d962cfa95d2fb58a075c1748be57", transactionIndex: "11", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "20000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be37fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd000000000000000000000000000000000000000000000000000000000000002c1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "596808", gasUsed: "161833", confirmations: "3233960"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3"}, {type: "bytes32", name: "s", value: "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38", "27", "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3", "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1509982740 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "weiAmount", type: "uint256", value: "20000000000000000"}, {name: "tokenAmount", type: "uint256", value: "85560003915225779160"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10387462282, 84503913417459, 63653638617576]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x1c5e4db864861d9b6203bd86af0c0b5ffcd6... )", async function( ) {
		const txOriginal = {blockNumber: "4502089", timeStamp: "1509983597", hash: "0x5cad6e2c7118b2f900959fd8d28eb62831279a477e9913d63eb5c0c2adb59d2a", nonce: "162", blockHash: "0xd8cdd118254bb0b6848dafc0c083460f8e4a832e1adeddb49eabab5293d57275", transactionIndex: "4", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "30000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be37fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd000000000000000000000000000000000000000000000000000000000000002c1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "312513", gasUsed: "161833", confirmations: "3233893"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "30000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3"}, {type: "bytes32", name: "s", value: "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38", "27", "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3", "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1509983597 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "weiAmount", type: "uint256", value: "30000000000000000"}, {name: "tokenAmount", type: "uint256", value: "128340005872838668741"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10387462282, 84503913417459, 63653638617576]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x1c5e4db864861d9b6203bd86af0c0b5ffcd6... )", async function( ) {
		const txOriginal = {blockNumber: "4502117", timeStamp: "1509983965", hash: "0x3164a87269fc29dbdecd9798b7e69cbe2c48936b6caebb68eade5169f5f15cee", nonce: "163", blockHash: "0x922da754ae3dc8409419ffee83e3ee1ade31516a541ae89af72f4e1c7e5fd539", transactionIndex: "12", from: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "20000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be37fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd000000000000000000000000000000000000000000000000000000000000002c1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "607801", gasUsed: "161833", confirmations: "3233865"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "20000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3"}, {type: "bytes32", name: "s", value: "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d4e25864fe7304e8e8d40d5f17f0f79e80000002100028d38", "27", "0x812981650a3b0bd3a27eefac76c305c52fec405eb5fa142130bdca7431d89be3", "0x7fcd7394718dfff516d479ae1e27abfeb03b2947bbb4db96a922a666f6c432cd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1509983965 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1c5e4db864861d9b6203bd86af0c0b5ffcd6115d"}, {name: "weiAmount", type: "uint256", value: "20000000000000000"}, {name: "tokenAmount", type: "uint256", value: "85560003915225779160"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10387462282, 84503913417459, 63653638617576]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "23902529324282097331" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xb6a34bd460f02241e80e031023ec20ce6fc3... )", async function( ) {
		const txOriginal = {blockNumber: "4502198", timeStamp: "1509985110", hash: "0x1c64fe6a58ca32ef4c1cb3dfeb9cd3e2f54fccf7db4c2be81b4f6d820d99a0d7", nonce: "251", blockHash: "0xff120b3ce08849011a47744eb6d281418ccbdd42d28468f9ab15739e8f8d6a84", transactionIndex: "1", from: "0xb6a34bd460f02241e80e031023ec20ce6fc310ae", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "6600000000000000000", gas: "260300", gasPrice: "29800000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bf36fe746877af8eb2321b2c80c715190b0ad91be193ab6b4bc2d02c3d186664816318ce86016bba958c94c4feaec14c6cf120cb14c4432f057d2f67f013f6cd9000000000000000000000000000000000000000000000000000000000000002cb6a34bd460f02241e80e031023ec20ce6fc310ae578b7db5f18d4166880b8a9a0fb15e780000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "241878", gasUsed: "212048", confirmations: "3233784"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "6600000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xb6a34bd460f02241e80e031023ec20ce6fc310ae578b7db5f18d4166880b8a9a0fb15e780000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xf36fe746877af8eb2321b2c80c715190b0ad91be193ab6b4bc2d02c3d1866648"}, {type: "bytes32", name: "s", value: "0x16318ce86016bba958c94c4feaec14c6cf120cb14c4432f057d2f67f013f6cd9"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xb6a34bd460f02241e80e031023ec20ce6fc310ae578b7db5f18d4166880b8a9a0fb15e780000002100028d38", "27", "0xf36fe746877af8eb2321b2c80c715190b0ad91be193ab6b4bc2d02c3d1866648", "0x16318ce86016bba958c94c4feaec14c6cf120cb14c4432f057d2f67f013f6cd9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1509985110 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xb6a34bd460f02241e80e031023ec20ce6fc310ae"}, {name: "weiAmount", type: "uint256", value: "6600000000000000000"}, {name: "tokenAmount", type: "uint256", value: "28234801292024507123041"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [11636711461, 28785482763472, 38801831190136]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "390375997157802028" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x7cdbd9d29c9280061e095ce1bd819b295f42... )", async function( ) {
		const txOriginal = {blockNumber: "4502236", timeStamp: "1509985659", hash: "0xc066db086cebffc17309f3e64c622a9eaa0f697db918d63e2f6b9bb6356a4dae", nonce: "16", blockHash: "0xfb03baffe2262ca9cc5a51af6fe11ad7c53747c1c36c765afa3efad37fba072a", transactionIndex: "9", from: "0x7cdbd9d29c9280061e095ce1bd819b295f426df6", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "40000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c250cbc3939e8dc27f5db103cf12c6b9147f41f5833469bd6130e5c5c5825ebe34d2992348f5000caa727174108781a4eccd04d5014411f66f91a793cca1f0874000000000000000000000000000000000000000000000000000000000000002c7cdbd9d29c9280061e095ce1bd819b295f426df6f8682ab98bd2406fbeb738bc1b425ce80000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "438995", gasUsed: "161769", confirmations: "3233746"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x7cdbd9d29c9280061e095ce1bd819b295f426df6f8682ab98bd2406fbeb738bc1b425ce80000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x250cbc3939e8dc27f5db103cf12c6b9147f41f5833469bd6130e5c5c5825ebe3"}, {type: "bytes32", name: "s", value: "0x4d2992348f5000caa727174108781a4eccd04d5014411f66f91a793cca1f0874"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x7cdbd9d29c9280061e095ce1bd819b295f426df6f8682ab98bd2406fbeb738bc1b425ce80000002100028d38", "28", "0x250cbc3939e8dc27f5db103cf12c6b9147f41f5833469bd6130e5c5c5825ebe3", "0x4d2992348f5000caa727174108781a4eccd04d5014411f66f91a793cca1f0874", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1509985659 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x7cdbd9d29c9280061e095ce1bd819b295f426df6"}, {name: "weiAmount", type: "uint256", value: "40000000000000000"}, {name: "tokenAmount", type: "uint256", value: "171120007830451558321"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [33018940838, 96327721426436, 30844942638312]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "53466498079979000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x728b54b93e6e8666c24b21c0bf36bd6296dd... )", async function( ) {
		const txOriginal = {blockNumber: "4502236", timeStamp: "1509985659", hash: "0x7d4991b8ea4e498b7f2cb72d3fda6b08e9289372b77fa682b356e6a04dfd34d2", nonce: "68", blockHash: "0xfb03baffe2262ca9cc5a51af6fe11ad7c53747c1c36c765afa3efad37fba072a", transactionIndex: "14", from: "0x728b54b93e6e8666c24b21c0bf36bd6296dd9efa", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "2000000000000000000", gas: "260000", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b0726ee87a7a188460b83aa0f23c3ac40e8f6041791c7c04cf950c2a299d5a69d685bed3009674822c1da7258170853ce251c867b8f8f4a274fe437ce540bdbc8000000000000000000000000000000000000000000000000000000000000002c728b54b93e6e8666c24b21c0bf36bd6296dd9efab271339c632f4561bd1db58fc58a003b0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "795959", gasUsed: "211984", confirmations: "3233746"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x728b54b93e6e8666c24b21c0bf36bd6296dd9efab271339c632f4561bd1db58fc58a003b0000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x0726ee87a7a188460b83aa0f23c3ac40e8f6041791c7c04cf950c2a299d5a69d"}, {type: "bytes32", name: "s", value: "0x685bed3009674822c1da7258170853ce251c867b8f8f4a274fe437ce540bdbc8"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x728b54b93e6e8666c24b21c0bf36bd6296dd9efab271339c632f4561bd1db58fc58a003b0000002100028d38", "27", "0x0726ee87a7a188460b83aa0f23c3ac40e8f6041791c7c04cf950c2a299d5a69d", "0x685bed3009674822c1da7258170853ce251c867b8f8f4a274fe437ce540bdbc8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1509985659 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x728b54b93e6e8666c24b21c0bf36bd6296dd9efa"}, {name: "weiAmount", type: "uint256", value: "2000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "8556000391522577916073"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [23719035958, 79087624914136, 78924677906491]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "5081482718174359057" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x93d18ea8694b7d9019bcf11018bc36a6f89b... )", async function( ) {
		const txOriginal = {blockNumber: "4502249", timeStamp: "1509985852", hash: "0x0fc1b341fb45690e57edbd40a29cc274d023fb2863f01e9aa9a1e132d0cd90fe", nonce: "0", blockHash: "0xeada02032dcb85b3661082869bf0fb611d177dcfe32fc3e6fb8ff56479fd3174", transactionIndex: "149", from: "0x93d18ea8694b7d9019bcf11018bc36a6f89b0d7e", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "25000000000000000", gas: "260300", gasPrice: "31000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b1de9678e63cb3063b1a7dee62a38502e531ad2142318203feddad10ac9feb5563628bcf109510fcfe2471974f53631d084d96f3011fefdc1aa77410e92fb240e000000000000000000000000000000000000000000000000000000000000002c93d18ea8694b7d9019bcf11018bc36a6f89b0d7e0f1f5c03c25c4ef3af138c7d829d5e520000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5447618", gasUsed: "212048", confirmations: "3233733"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "25000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x93d18ea8694b7d9019bcf11018bc36a6f89b0d7e0f1f5c03c25c4ef3af138c7d829d5e520000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x1de9678e63cb3063b1a7dee62a38502e531ad2142318203feddad10ac9feb556"}, {type: "bytes32", name: "s", value: "0x3628bcf109510fcfe2471974f53631d084d96f3011fefdc1aa77410e92fb240e"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x93d18ea8694b7d9019bcf11018bc36a6f89b0d7e0f1f5c03c25c4ef3af138c7d829d5e520000002100028d38", "27", "0x1de9678e63cb3063b1a7dee62a38502e531ad2142318203feddad10ac9feb556", "0x3628bcf109510fcfe2471974f53631d084d96f3011fefdc1aa77410e92fb240e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1509985852 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x93d18ea8694b7d9019bcf11018bc36a6f89b0d7e"}, {name: "weiAmount", type: "uint256", value: "25000000000000000"}, {name: "tokenAmount", type: "uint256", value: "106950004894032223950"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2010124741, 89080271670191, 11630474403410]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "39139000000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x1186fe1ad46255beadcdccbd6724d8dfd639... )", async function( ) {
		const txOriginal = {blockNumber: "4502253", timeStamp: "1509985924", hash: "0x472b41fa81c34fe1a9c3d3439536f3752e6361ea9296cd45da216a31d1148ed4", nonce: "4", blockHash: "0x5702a1a9f7b687547d30becb21280f4e6d30029e14f6d412c632ba792a52555e", transactionIndex: "3", from: "0x1186fe1ad46255beadcdccbd6724d8dfd639cb4e", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "102164970000000000", gas: "260300", gasPrice: "30100000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001be4ce9f173196e5d8bde461480c170ec646664d4eac8269ce43ace90876e03a547dbd34921597658904754784c5540533b443e963ca78bb3fa93f260e0f618e78000000000000000000000000000000000000000000000000000000000000002c1186fe1ad46255beadcdccbd6724d8dfd639cb4e98a632b7393b49c59e394b74cefbc1f30000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "291218", gasUsed: "212048", confirmations: "3233729"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "102164970000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x1186fe1ad46255beadcdccbd6724d8dfd639cb4e98a632b7393b49c59e394b74cefbc1f30000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xe4ce9f173196e5d8bde461480c170ec646664d4eac8269ce43ace90876e03a54"}, {type: "bytes32", name: "s", value: "0x7dbd34921597658904754784c5540533b443e963ca78bb3fa93f260e0f618e78"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x1186fe1ad46255beadcdccbd6724d8dfd639cb4e98a632b7393b49c59e394b74cefbc1f30000002100028d38", "27", "0xe4ce9f173196e5d8bde461480c170ec646664d4eac8269ce43ace90876e03a54", "0x7dbd34921597658904754784c5540533b443e963ca78bb3fa93f260e0f618e78", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1509985924 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1186fe1ad46255beadcdccbd6724d8dfd639cb4e"}, {name: "weiAmount", type: "uint256", value: "102164970000000000"}, {name: "tokenAmount", type: "uint256", value: "437061761659946213559"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [20290560527, 47702373229467, 3474598593011]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "18953478000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xca0d9fca102c5535867410c36aefaf114b97... )", async function( ) {
		const txOriginal = {blockNumber: "4502266", timeStamp: "1509986183", hash: "0x71c583005cf190aa2f2dc0478ea39e8491a0981524002a44951a24e6e91aca76", nonce: "0", blockHash: "0xc6b63578e692fb74b7c8b31751644c824d5f8be801cef9576c4301209e6f55ae", transactionIndex: "45", from: "0xca0d9fca102c5535867410c36aefaf114b97e202", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "350000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b93ce55ef89fcb73741eedb3e84bbdb8aacd27f50743feaaac84ca2292184b38d16b86789aae02dfc9bbec998f4bd78b5cbd41a539c825d3460e311e64d3d63e6000000000000000000000000000000000000000000000000000000000000002cca0d9fca102c5535867410c36aefaf114b97e2022d61901545cc444ca8e7b4f754d898d70000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1965442", gasUsed: "212048", confirmations: "3233716"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "350000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xca0d9fca102c5535867410c36aefaf114b97e2022d61901545cc444ca8e7b4f754d898d70000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x93ce55ef89fcb73741eedb3e84bbdb8aacd27f50743feaaac84ca2292184b38d"}, {type: "bytes32", name: "s", value: "0x16b86789aae02dfc9bbec998f4bd78b5cbd41a539c825d3460e311e64d3d63e6"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xca0d9fca102c5535867410c36aefaf114b97e2022d61901545cc444ca8e7b4f754d898d70000002100028d38", "27", "0x93ce55ef89fcb73741eedb3e84bbdb8aacd27f50743feaaac84ca2292184b38d", "0x16b86789aae02dfc9bbec998f4bd78b5cbd41a539c825d3460e311e64d3d63e6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1509986183 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xca0d9fca102c5535867410c36aefaf114b97e202"}, {name: "weiAmount", type: "uint256", value: "350000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1497300068516451135312"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [6032183495, 79748402806493, 88048973863127]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "154282271604938" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xcf477dd4bfddfe8a006c709c752206b353d6... )", async function( ) {
		const txOriginal = {blockNumber: "4502266", timeStamp: "1509986183", hash: "0x0f8d4263d389b65ee81a7b355bebcf053ed99aab225af226fd9e71bfcd5f58b0", nonce: "2", blockHash: "0xc6b63578e692fb74b7c8b31751644c824d5f8be801cef9576c4301209e6f55ae", transactionIndex: "103", from: "0xcf477dd4bfddfe8a006c709c752206b353d6e231", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "6000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001ca0100f73aa4f5d7290b9e6e4acb2d68f2f9f883a61d19a63083f02d9daa20c444d37a9c91c5f47ecaa0d9048ca70c04d06b4ee0c05c4a25747e42e3aa1850e11000000000000000000000000000000000000000000000000000000000000002ccf477dd4bfddfe8a006c709c752206b353d6e23137583f1ea4974776a91209782da24e7b0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4534090", gasUsed: "211984", confirmations: "3233716"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "6000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xcf477dd4bfddfe8a006c709c752206b353d6e23137583f1ea4974776a91209782da24e7b0000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xa0100f73aa4f5d7290b9e6e4acb2d68f2f9f883a61d19a63083f02d9daa20c44"}, {type: "bytes32", name: "s", value: "0x4d37a9c91c5f47ecaa0d9048ca70c04d06b4ee0c05c4a25747e42e3aa1850e11"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xcf477dd4bfddfe8a006c709c752206b353d6e23137583f1ea4974776a91209782da24e7b0000002100028d38", "28", "0xa0100f73aa4f5d7290b9e6e4acb2d68f2f9f883a61d19a63083f02d9daa20c44", "0x4d37a9c91c5f47ecaa0d9048ca70c04d06b4ee0c05c4a25747e42e3aa1850e11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1509986183 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xcf477dd4bfddfe8a006c709c752206b353d6e231"}, {name: "weiAmount", type: "uint256", value: "6000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "25668001174567733748219"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [7356574211, 13097702105682, 3548078788219]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "5916663387966564875" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x777ea5df73eca53a1f4ef84487154fbf15e2... )", async function( ) {
		const txOriginal = {blockNumber: "4502284", timeStamp: "1509986283", hash: "0x153d1c00174e1af8e478655d1086555e4a8240f8086c86021bfad9c5110dc09b", nonce: "15", blockHash: "0x928128d7b098e859502d319543ef90136d2d1015df2c870b06e9fb40196c571b", transactionIndex: "13", from: "0x777ea5df73eca53a1f4ef84487154fbf15e22767", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "4000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b9c39f08eea99f0b9876b5f07fbfa963d6b16047f76b091ff5a45409599452e1a4bd6007ddbea887e1f3674801414f4bfa348286876fe0a533584507ba3c42076000000000000000000000000000000000000000000000000000000000000002c777ea5df73eca53a1f4ef84487154fbf15e2276710b8e33e4df54c5c90c84f4bce090b420000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "747081", gasUsed: "211984", confirmations: "3233698"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "4000000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x777ea5df73eca53a1f4ef84487154fbf15e2276710b8e33e4df54c5c90c84f4bce090b420000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x9c39f08eea99f0b9876b5f07fbfa963d6b16047f76b091ff5a45409599452e1a"}, {type: "bytes32", name: "s", value: "0x4bd6007ddbea887e1f3674801414f4bfa348286876fe0a533584507ba3c42076"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x777ea5df73eca53a1f4ef84487154fbf15e2276710b8e33e4df54c5c90c84f4bce090b420000002100028d38", "27", "0x9c39f08eea99f0b9876b5f07fbfa963d6b16047f76b091ff5a45409599452e1a", "0x4bd6007ddbea887e1f3674801414f4bfa348286876fe0a533584507ba3c42076", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1509986283 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x777ea5df73eca53a1f4ef84487154fbf15e22767"}, {name: "weiAmount", type: "uint256", value: "4000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "17112000783045155832146"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2222763959, 77820602531206, 74152556596034]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "1684845686611200731" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4502290", timeStamp: "1509986317", hash: "0xa5531aee822c055005e6375aa3a4c8409bccb89a2a29bccde42f552ecad8e20f", nonce: "27", blockHash: "0xc96b22d7c4e1c2fe252a3b816e764bb5e3edb356cee847ba0d838cf100b6386f", transactionIndex: "0", from: "0xa6229d804a9b55dd6a1010cee80f7c49b5ab79b7", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "15000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "21044", gasUsed: "21044", confirmations: "3233692"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "15000000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1509986317 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "4404071000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x40da6678c89d778af74d4af11fd67b73a6ed... )", async function( ) {
		const txOriginal = {blockNumber: "4502312", timeStamp: "1509986557", hash: "0xc692ad6133fc1de853cf4adb640ec4e9cca105d1621befc664acbdb114a4564d", nonce: "0", blockHash: "0x710ed4208f60093f01e60404391993e88b4a60cfcee200652c9578212fb867a0", transactionIndex: "11", from: "0x40da6678c89d778af74d4af11fd67b73a6ed52d3", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "100000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b4f41118a11183ba01fa2f8d2c5abbd94231ddeb49e9eeedf64b0908329aee17a02d00e1b6a7ca2fc2181f7df00cc632806def9598b8878aafbb2fb2efd8eefab000000000000000000000000000000000000000000000000000000000000002c40da6678c89d778af74d4af11fd67b73a6ed52d3d58ff5e584004a2299e2a418558da7bd0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "632149", gasUsed: "211920", confirmations: "3233670"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x40da6678c89d778af74d4af11fd67b73a6ed52d3d58ff5e584004a2299e2a418558da7bd0000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x4f41118a11183ba01fa2f8d2c5abbd94231ddeb49e9eeedf64b0908329aee17a"}, {type: "bytes32", name: "s", value: "0x02d00e1b6a7ca2fc2181f7df00cc632806def9598b8878aafbb2fb2efd8eefab"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x40da6678c89d778af74d4af11fd67b73a6ed52d3d58ff5e584004a2299e2a418558da7bd0000002100028d38", "27", "0x4f41118a11183ba01fa2f8d2c5abbd94231ddeb49e9eeedf64b0908329aee17a", "0x02d00e1b6a7ca2fc2181f7df00cc632806def9598b8878aafbb2fb2efd8eefab", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509986557 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x40da6678c89d778af74d4af11fd67b73a6ed52d3"}, {name: "weiAmount", type: "uint256", value: "100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "427800019576128895803"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [28387304892, 74120430949931, 26401424336829]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "65152336750000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x08548af3414d04416f96f60cb1c39dc8ea92... )", async function( ) {
		const txOriginal = {blockNumber: "4502312", timeStamp: "1509986557", hash: "0xfb30f79edb78c05966159d4ae1f962d56f1ba40997b1d8591effc2da545f5398", nonce: "52", blockHash: "0x710ed4208f60093f01e60404391993e88b4a60cfcee200652c9578212fb867a0", transactionIndex: "100", from: "0x08548af3414d04416f96f60cb1c39dc8ea927b4c", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "10000000000000000000", gas: "260300", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c33fbed366d60a603625154d26667c3136605aafaaa7d25941a13620989354e1b39e6b39a90ae8dbd3a90e9301080e57deec633738aca0ab8fce349a0384a7ff8000000000000000000000000000000000000000000000000000000000000002c08548af3414d04416f96f60cb1c39dc8ea927b4c6cd6b975a26441f283328cab1e19caf50000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4806262", gasUsed: "212048", confirmations: "3233670"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x08548af3414d04416f96f60cb1c39dc8ea927b4c6cd6b975a26441f283328cab1e19caf50000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x33fbed366d60a603625154d26667c3136605aafaaa7d25941a13620989354e1b"}, {type: "bytes32", name: "s", value: "0x39e6b39a90ae8dbd3a90e9301080e57deec633738aca0ab8fce349a0384a7ff8"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x08548af3414d04416f96f60cb1c39dc8ea927b4c6cd6b975a26441f283328cab1e19caf50000002100028d38", "28", "0x33fbed366d60a603625154d26667c3136605aafaaa7d25941a13620989354e1b", "0x39e6b39a90ae8dbd3a90e9301080e57deec633738aca0ab8fce349a0384a7ff8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509986557 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x08548af3414d04416f96f60cb1c39dc8ea927b4c"}, {name: "weiAmount", type: "uint256", value: "10000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "42780001957612889580365"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [14467153663, 82268327144792, 7060772342517]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "73143522530500051" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x3dac0161a9a713399e9fa1a0551e9f66b1c5... )", async function( ) {
		const txOriginal = {blockNumber: "4502327", timeStamp: "1509986804", hash: "0xec5f415f5386ee3d8b0854de82db65968cc3bf736ad9f81040d0e0c356b27d03", nonce: "0", blockHash: "0xe388ed4e0a51046ac0349fa96fe62341a123335d047361ad8217d75c1f8305e0", transactionIndex: "16", from: "0x3dac0161a9a713399e9fa1a0551e9f66b1c55748", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "340000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b7db48bfa3096b80287594e9262e423d75a488d427be5be3fcaf41ce2a729cecd52de836a462bb6de464ab9e03d637318c7b4104fb66f58b107a41d10ea5524d7000000000000000000000000000000000000000000000000000000000000002c3dac0161a9a713399e9fa1a0551e9f66b1c5574812e9de79c3a1445a8e58022c1292033c0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1077441", gasUsed: "212048", confirmations: "3233655"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "340000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x3dac0161a9a713399e9fa1a0551e9f66b1c5574812e9de79c3a1445a8e58022c1292033c0000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7db48bfa3096b80287594e9262e423d75a488d427be5be3fcaf41ce2a729cecd"}, {type: "bytes32", name: "s", value: "0x52de836a462bb6de464ab9e03d637318c7b4104fb66f58b107a41d10ea5524d7"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x3dac0161a9a713399e9fa1a0551e9f66b1c5574812e9de79c3a1445a8e58022c1292033c0000002100028d38", "27", "0x7db48bfa3096b80287594e9262e423d75a488d427be5be3fcaf41ce2a729cecd", "0x52de836a462bb6de464ab9e03d637318c7b4104fb66f58b107a41d10ea5524d7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509986804 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x3dac0161a9a713399e9fa1a0551e9f66b1c55748"}, {name: "weiAmount", type: "uint256", value: "340000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1454520066558838245732"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2514042143, 42513122100400, 93846201828156]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "678883026187998" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x67646ced30f8e29d134aa82fd8f22d4e4dd0... )", async function( ) {
		const txOriginal = {blockNumber: "4502331", timeStamp: "1509986854", hash: "0xeaa7df8d94ae3335c9a3c5c28e13c989a5daca1fc5504c445618e40d3ef0917c", nonce: "2", blockHash: "0x6037f8a598769ad01265afffcd1a4d756d79f41e603c6bc84c9aade9e0311386", transactionIndex: "2", from: "0x67646ced30f8e29d134aa82fd8f22d4e4dd03250", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "1090000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001baf6daa77cec6ddf5b824a2734aae829f6e91005a2373d00299d25d40fa13ae8d533d5139635512c5154bf3438768087307e64dc2daa0707ecb1a93ae12dc3d5d000000000000000000000000000000000000000000000000000000000000002c67646ced30f8e29d134aa82fd8f22d4e4dd03250953170be573a4b3ea3e37b8bf04af9ed0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "300787", gasUsed: "211984", confirmations: "3233651"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "1090000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x67646ced30f8e29d134aa82fd8f22d4e4dd03250953170be573a4b3ea3e37b8bf04af9ed0000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xaf6daa77cec6ddf5b824a2734aae829f6e91005a2373d00299d25d40fa13ae8d"}, {type: "bytes32", name: "s", value: "0x533d5139635512c5154bf3438768087307e64dc2daa0707ecb1a93ae12dc3d5d"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x67646ced30f8e29d134aa82fd8f22d4e4dd03250953170be573a4b3ea3e37b8bf04af9ed0000002100028d38", "27", "0xaf6daa77cec6ddf5b824a2734aae829f6e91005a2373d00299d25d40fa13ae8d", "0x533d5139635512c5154bf3438768087307e64dc2daa0707ecb1a93ae12dc3d5d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509986854 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x67646ced30f8e29d134aa82fd8f22d4e4dd03250"}, {name: "weiAmount", type: "uint256", value: "1090000000000000000"}, {name: "tokenAmount", type: "uint256", value: "4663020213379804964259"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [19831168062, 82428271987653, 6920827550189]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x9caa1741231d19d82f5a9be4712fea74c0eb... )", async function( ) {
		const txOriginal = {blockNumber: "4502339", timeStamp: "1509986983", hash: "0x2862a25ab83d1c9564fa55f009366fe1a7fc7f3a246a032efa8bc8dd87631190", nonce: "9", blockHash: "0x6f5e81f097d5e5f95dec0e83a3cf1cc86c2172e8d78c245f3bbc7cdfa11b6fd7", transactionIndex: "5", from: "0x9caa1741231d19d82f5a9be4712fea74c0eb11f3", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "250000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001cc46e40997deb53b7a21f8e4deae39fa767caf6314be2152d97f627324375a9fa1e7481f6b89ed5345e6355f55fe9f1a81341652d54e7b3e4c0ddd93128aab135000000000000000000000000000000000000000000000000000000000000002c9caa1741231d19d82f5a9be4712fea74c0eb11f310496c5cb5884e119e51e747324bd1930000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "360652", gasUsed: "212048", confirmations: "3233643"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x9caa1741231d19d82f5a9be4712fea74c0eb11f310496c5cb5884e119e51e747324bd1930000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc46e40997deb53b7a21f8e4deae39fa767caf6314be2152d97f627324375a9fa"}, {type: "bytes32", name: "s", value: "0x1e7481f6b89ed5345e6355f55fe9f1a81341652d54e7b3e4c0ddd93128aab135"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x9caa1741231d19d82f5a9be4712fea74c0eb11f310496c5cb5884e119e51e747324bd1930000002100028d38", "28", "0xc46e40997deb53b7a21f8e4deae39fa767caf6314be2152d97f627324375a9fa", "0x1e7481f6b89ed5345e6355f55fe9f1a81341652d54e7b3e4c0ddd93128aab135", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509986983 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9caa1741231d19d82f5a9be4712fea74c0eb11f3"}, {name: "weiAmount", type: "uint256", value: "250000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1069500048940322239509"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2164888344, 86414114347879, 97822114058643]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "10763788564507136" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xf99eea25c277f490c6db0bdd9b10a756e659... )", async function( ) {
		const txOriginal = {blockNumber: "4502339", timeStamp: "1509986983", hash: "0x0c274c4b0c5cd0e32481388a9557d82799e08ff853ebb07401030188c9f11b97", nonce: "0", blockHash: "0x6f5e81f097d5e5f95dec0e83a3cf1cc86c2172e8d78c245f3bbc7cdfa11b6fd7", transactionIndex: "36", from: "0xf99eea25c277f490c6db0bdd9b10a756e6590c5b", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "390989930000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001be32477e5a8d0d27ec32d5d8ed0ea296b46c2052cb186a6c2861da29b4b211b42737f4c1aca4b3b28948745ce488b92774e1fb685890c0390272ae186abf08408000000000000000000000000000000000000000000000000000000000000002cf99eea25c277f490c6db0bdd9b10a756e6590c5be6e1e8416a1c4212ae1e3c789c8415b80000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1426324", gasUsed: "212048", confirmations: "3233643"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "390989930000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xf99eea25c277f490c6db0bdd9b10a756e6590c5be6e1e8416a1c4212ae1e3c789c8415b80000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xe32477e5a8d0d27ec32d5d8ed0ea296b46c2052cb186a6c2861da29b4b211b42"}, {type: "bytes32", name: "s", value: "0x737f4c1aca4b3b28948745ce488b92774e1fb685890c0390272ae186abf08408"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xf99eea25c277f490c6db0bdd9b10a756e6590c5be6e1e8416a1c4212ae1e3c789c8415b80000002100028d38", "27", "0xe32477e5a8d0d27ec32d5d8ed0ea296b46c2052cb186a6c2861da29b4b211b42", "0x737f4c1aca4b3b28948745ce488b92774e1fb685890c0390272ae186abf08408", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1509986983 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xf99eea25c277f490c6db0bdd9b10a756e6590c5b"}, {name: "weiAmount", type: "uint256", value: "390989930000000000"}, {name: "tokenAmount", type: "uint256", value: "1672654997080692666412"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [30689541652, 53991705838028, 66606903924152]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "18689738000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4502340", timeStamp: "1509986989", hash: "0xd69ef5922fa329044cf9446e1742fcecde19ccca6df41ac77389bc064104bb87", nonce: "28", blockHash: "0xa2a9ca6befc40254134ac2ee4b305c565bc7efb835fa386aeb2d52055728da9d", transactionIndex: "1", from: "0xa6229d804a9b55dd6a1010cee80f7c49b5ab79b7", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "15000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "72502", gasUsed: "21044", confirmations: "3233642"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "15000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1509986989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "4404071000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xd0a5f731eb92c1a4eb7b4945a8cf4cbdae77... )", async function( ) {
		const txOriginal = {blockNumber: "4502349", timeStamp: "1509987145", hash: "0xdb0b1ab15efe343b137d780290a8afa1f8df7ff8dab15826c2d9571adce7f38a", nonce: "0", blockHash: "0x292cf20a082bef0f19c01590076fb6ef8f1ffa6459b72a5a4098bf48b1399aa8", transactionIndex: "12", from: "0xd0a5f731eb92c1a4eb7b4945a8cf4cbdae77ce44", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "170000000000000000", gas: "210000", gasPrice: "21000000000", isError: "1", txreceipt_status: "0", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b7dcd4ca95f8f42c2bf9a4cb50f5347681d730b54c7fd00c72ec67b4a619b428f2f5bb4ed16b0f46212cbab35cd6b0c0e8f89c51d71bf201e58515e0b44aac6be000000000000000000000000000000000000000000000000000000000000002cd0a5f731eb92c1a4eb7b4945a8cf4cbdae77ce44ec26656542314451a73f99b1f124b0190000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "524897", gasUsed: "210000", confirmations: "3233633"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "170000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xd0a5f731eb92c1a4eb7b4945a8cf4cbdae77ce44ec26656542314451a73f99b1f124b0190000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7dcd4ca95f8f42c2bf9a4cb50f5347681d730b54c7fd00c72ec67b4a619b428f"}, {type: "bytes32", name: "s", value: "0x2f5bb4ed16b0f46212cbab35cd6b0c0e8f89c51d71bf201e58515e0b44aac6be"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "8248706000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4502350", timeStamp: "1509987150", hash: "0x2fa71587ea751d31382b1a627ddf24347c9fe80c253748426bdf145c4cc40f88", nonce: "1", blockHash: "0x5178077711fae11f518a1519dbd8a44edb00aacf9aab64041a68b3056445f94d", transactionIndex: "2", from: "0x9ef5468fcd0d9b1a05c84febfbec979e2f100f5f", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "1821061560000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "476673", gasUsed: "21044", confirmations: "3233632"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "1821061560000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509987150 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "99948012900000001" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xff6e18566c66855719595d1dafe706e238c3... )", async function( ) {
		const txOriginal = {blockNumber: "4502368", timeStamp: "1509987354", hash: "0xa92d9a06ba1c8773cfc6316575578a0206af128d3d82725e7a1a5888ef433a07", nonce: "0", blockHash: "0x0d3304eca6df48f51cdba35e3cb2857c9b8ad9f53e8b7e68688ab68237f4bbd3", transactionIndex: "7", from: "0xff6e18566c66855719595d1dafe706e238c32e5a", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "722460550000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b6167bee6e5c804998fba0ef9f52e5bef344303f39d9c5215e2b85503a691896472745f2a6fa889807836efd4057cf65abd569a29a7f363efab17fdf0e15522c7000000000000000000000000000000000000000000000000000000000000002cff6e18566c66855719595d1dafe706e238c32e5a9449f720bd9044daa759723a1ace3bbf0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "519006", gasUsed: "212048", confirmations: "3233614"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "722460550000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xff6e18566c66855719595d1dafe706e238c32e5a9449f720bd9044daa759723a1ace3bbf0000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x6167bee6e5c804998fba0ef9f52e5bef344303f39d9c5215e2b85503a6918964"}, {type: "bytes32", name: "s", value: "0x72745f2a6fa889807836efd4057cf65abd569a29a7f363efab17fdf0e15522c7"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xff6e18566c66855719595d1dafe706e238c32e5a9449f720bd9044daa759723a1ace3bbf0000002100028d38", "27", "0x6167bee6e5c804998fba0ef9f52e5bef344303f39d9c5215e2b85503a6918964", "0x72745f2a6fa889807836efd4057cf65abd569a29a7f363efab17fdf0e15522c7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1509987354 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xff6e18566c66855719595d1dafe706e238c32e5a"}, {name: "weiAmount", type: "uint256", value: "722460550000000000"}, {name: "tokenAmount", type: "uint256", value: "3090686374329808489332"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [19710979339, 59809713543282, 51983840820159]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "3292840000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xaa4284c28da8c59f249d3cf93b508cf16b5c... )", async function( ) {
		const txOriginal = {blockNumber: "4502374", timeStamp: "1509987466", hash: "0x7ebc594340df558262f11b28ff7755a69a6c893ced74922d83cd92ce7c1d9e86", nonce: "95", blockHash: "0xc1e082d9ac47a8886ccb35addfeafeeceddb6600175c111b42c54f54ec767727", transactionIndex: "0", from: "0xaa4284c28da8c59f249d3cf93b508cf16b5cda3d", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "610960657552786025", gas: "260300", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b79ba6dfd50e99c32aa8f80e0d11b43b281188362d367fb99b3b3f3c0d075494f0cde197842682f2048459b9715f89d811b02ee1e6fa3c06e4352f567e9d22a18000000000000000000000000000000000000000000000000000000000000002caa4284c28da8c59f249d3cf93b508cf16b5cda3ddbc257b7e9494fb2b2cd3c5fb7a2c9a60000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "212048", gasUsed: "212048", confirmations: "3233608"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "610960657552786025" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xaa4284c28da8c59f249d3cf93b508cf16b5cda3ddbc257b7e9494fb2b2cd3c5fb7a2c9a60000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x79ba6dfd50e99c32aa8f80e0d11b43b281188362d367fb99b3b3f3c0d075494f"}, {type: "bytes32", name: "s", value: "0x0cde197842682f2048459b9715f89d811b02ee1e6fa3c06e4352f567e9d22a18"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xaa4284c28da8c59f249d3cf93b508cf16b5cda3ddbc257b7e9494fb2b2cd3c5fb7a2c9a60000002100028d38", "27", "0x79ba6dfd50e99c32aa8f80e0d11b43b281188362d367fb99b3b3f3c0d075494f", "0x0cde197842682f2048459b9715f89d811b02ee1e6fa3c06e4352f567e9d22a18", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1509987466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xaa4284c28da8c59f249d3cf93b508cf16b5cda3d"}, {name: "weiAmount", type: "uint256", value: "610960657552786025"}, {name: "tokenAmount", type: "uint256", value: "2613689812613264440132"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [29211001580, 80402257681312, 6774345877926]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "7770660000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4502374", timeStamp: "1509987466", hash: "0x602173a66f7a0e3b818f555c0ca8a4b437a2fc80ae3c4d30a402a79cb416cc39", nonce: "6", blockHash: "0xc1e082d9ac47a8886ccb35addfeafeeceddb6600175c111b42c54f54ec767727", transactionIndex: "24", from: "0x8042c891aa3487f8b56deee3e90264e6d9ea9793", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "3700000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1127986", gasUsed: "21044", confirmations: "3233608"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "3700000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1509987466 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "503447141777777777" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xa6229d804a9b55dd6a1010cee80f7c49b5ab... )", async function( ) {
		const txOriginal = {blockNumber: "4502377", timeStamp: "1509987508", hash: "0x254854cf16ba70f9a0da0a60e67b0c1b15bd2a2455589034823b0c9a8684e49d", nonce: "29", blockHash: "0xad4c77842e296aa7f9601806fcb89067b003e90a9b0be64d672574c6a8782791", transactionIndex: "13", from: "0xa6229d804a9b55dd6a1010cee80f7c49b5ab79b7", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "15000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001ccec43863884511b9f0305bbd278b7c6dca90726509bcd27493023cf66b9e06d054865378e713dd37121ec70600409328b029ced0ad4c8dfb10542b7fa56630e9000000000000000000000000000000000000000000000000000000000000002ca6229d804a9b55dd6a1010cee80f7c49b5ab79b76e4567488b6f49b98fe5f68746f1164f0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "503547", gasUsed: "211984", confirmations: "3233605"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "15000000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xa6229d804a9b55dd6a1010cee80f7c49b5ab79b76e4567488b6f49b98fe5f68746f1164f0000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xcec43863884511b9f0305bbd278b7c6dca90726509bcd27493023cf66b9e06d0"}, {type: "bytes32", name: "s", value: "0x54865378e713dd37121ec70600409328b029ced0ad4c8dfb10542b7fa56630e9"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xa6229d804a9b55dd6a1010cee80f7c49b5ab79b76e4567488b6f49b98fe5f68746f1164f0000002100028d38", "28", "0xcec43863884511b9f0305bbd278b7c6dca90726509bcd27493023cf66b9e06d0", "0x54865378e713dd37121ec70600409328b029ced0ad4c8dfb10542b7fa56630e9", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1509987508 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xa6229d804a9b55dd6a1010cee80f7c49b5ab79b7"}, {name: "weiAmount", type: "uint256", value: "15000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "64170002936419334370548"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [14657544285, 53494815617874, 10469067232847]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "4404071000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xc30ff49429b3077fc2b9a910b072f2300dc4... )", async function( ) {
		const txOriginal = {blockNumber: "4502389", timeStamp: "1509987657", hash: "0xb3586341b2e6ff657b212fe00b4babf135a0648c54f8c1b836b7522aaf1fc871", nonce: "318", blockHash: "0x75f0bc299d7cb7b37fa940c131fbcb2061ab0012d64b5a1ad03c4022994ea86c", transactionIndex: "5", from: "0xc30ff49429b3077fc2b9a910b072f2300dc41b9a", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "2500000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bbc688b0b41e7202e5b67c2333e328753d4c513fa03936ef3d8f14eebd493c7f73f5a55cfa755ef4992a1b278a29299e107b8415215e066923ad22574460317aa000000000000000000000000000000000000000000000000000000000000002cc30ff49429b3077fc2b9a910b072f2300dc41b9a7cd047021fae4e168f2ba394c5a629910000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1187827", gasUsed: "212048", confirmations: "3233593"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "2500000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xc30ff49429b3077fc2b9a910b072f2300dc41b9a7cd047021fae4e168f2ba394c5a629910000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xbc688b0b41e7202e5b67c2333e328753d4c513fa03936ef3d8f14eebd493c7f7"}, {type: "bytes32", name: "s", value: "0x3f5a55cfa755ef4992a1b278a29299e107b8415215e066923ad22574460317aa"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xc30ff49429b3077fc2b9a910b072f2300dc41b9a7cd047021fae4e168f2ba394c5a629910000002100028d38", "27", "0xbc688b0b41e7202e5b67c2333e328753d4c513fa03936ef3d8f14eebd493c7f7", "0x3f5a55cfa755ef4992a1b278a29299e107b8415215e066923ad22574460317aa", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1509987657 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xc30ff49429b3077fc2b9a910b072f2300dc41b9a"}, {name: "weiAmount", type: "uint256", value: "2500000000000000000"}, {name: "tokenAmount", type: "uint256", value: "10695000489403222395091"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [16590570944, 32477538417403, 89444762347921]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "46537465000000003" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4502402", timeStamp: "1509987832", hash: "0x8f9f61849c52eefd792c2bdba9e4e1baa4f31d032ebbdcdce9e2afd8d34bb46b", nonce: "0", blockHash: "0x375fd10b1ca79b60918659f0d2f2353367d287685fffd1d952be65806ede2e3c", transactionIndex: "26", from: "0xee4cb0c022e87c2b6598ed12af6a06bb390c2ae2", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "23300000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "1144253", gasUsed: "21044", confirmations: "3233580"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "23300000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1509987832 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "711358000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x1ee51a66a15bc4fbbc08b47e3c0cadd79846... )", async function( ) {
		const txOriginal = {blockNumber: "4502403", timeStamp: "1509987861", hash: "0x20f5c1d14eb96e4d699a4d36d797c05119d46a00356f6e1bd28cc84d62c0abaf", nonce: "0", blockHash: "0xeb9e2720ac06ffe8bc3425bf0a0aa4ad747fafa1bab6a3158433525249a8b9fb", transactionIndex: "6", from: "0x1ee51a66a15bc4fbbc08b47e3c0cadd798467d11", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "100000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b637c28e336409630e75a1c239441d29db1a8b25c78b542259a18c76d5308fdec14f2908c30c567a68d8024b45aa9ea6200c72182d9d74b05a883acf986eadf31000000000000000000000000000000000000000000000000000000000000002c1ee51a66a15bc4fbbc08b47e3c0cadd798467d112abb9a8f17794c6eaa3c995cb6b0c18e0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "469548", gasUsed: "211984", confirmations: "3233579"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x1ee51a66a15bc4fbbc08b47e3c0cadd798467d112abb9a8f17794c6eaa3c995cb6b0c18e0000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x637c28e336409630e75a1c239441d29db1a8b25c78b542259a18c76d5308fdec"}, {type: "bytes32", name: "s", value: "0x14f2908c30c567a68d8024b45aa9ea6200c72182d9d74b05a883acf986eadf31"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x1ee51a66a15bc4fbbc08b47e3c0cadd798467d112abb9a8f17794c6eaa3c995cb6b0c18e0000002100028d38", "27", "0x637c28e336409630e75a1c239441d29db1a8b25c78b542259a18c76d5308fdec", "0x14f2908c30c567a68d8024b45aa9ea6200c72182d9d74b05a883acf986eadf31", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1509987861 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1ee51a66a15bc4fbbc08b47e3c0cadd798467d11"}, {name: "weiAmount", type: "uint256", value: "100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "427800019576128895803"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [5680167016, 34834775168663, 64119249371534]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "986799600000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x35af967aceab29501d27e02a74d82b988980... )", async function( ) {
		const txOriginal = {blockNumber: "4502404", timeStamp: "1509987880", hash: "0x5f79d378802bcf44d1a129fc742bb4f5380875903f1e9ac2101596a1fb65386f", nonce: "0", blockHash: "0xf3ff02dda00db361b073700f51dc70a8027aeddb6fdbae1a2008de1db448ad73", transactionIndex: "14", from: "0x35af967aceab29501d27e02a74d82b98898081e4", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "141128770000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001ceeafcd5d8d806196fc137fb32a78d1bb9f6e19b2d7426e763b6eebcf8c67425f4dfc31b765d262db73e58fe86095432fae22314389f7f7673adde0199c2bf480000000000000000000000000000000000000000000000000000000000000002c35af967aceab29501d27e02a74d82b98898081e4a4c684d77d524ef2b1b43509893d1ec40000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1032543", gasUsed: "212048", confirmations: "3233578"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "141128770000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x35af967aceab29501d27e02a74d82b98898081e4a4c684d77d524ef2b1b43509893d1ec40000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xeeafcd5d8d806196fc137fb32a78d1bb9f6e19b2d7426e763b6eebcf8c67425f"}, {type: "bytes32", name: "s", value: "0x4dfc31b765d262db73e58fe86095432fae22314389f7f7673adde0199c2bf480"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x35af967aceab29501d27e02a74d82b98898081e4a4c684d77d524ef2b1b43509893d1ec40000002100028d38", "28", "0xeeafcd5d8d806196fc137fb32a78d1bb9f6e19b2d7426e763b6eebcf8c67425f", "0x4dfc31b765d262db73e58fe86095432fae22314389f7f7673adde0199c2bf480", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1509987880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x35af967aceab29501d27e02a74d82b98898081e4"}, {name: "weiAmount", type: "uint256", value: "141128770000000000"}, {name: "tokenAmount", type: "uint256", value: "603748905687549924262"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [21902416043, 76238525803811, 20616837488324]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "148533760000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x316b97c21bc987d9b3642d6077c3efec6d30... )", async function( ) {
		const txOriginal = {blockNumber: "4502405", timeStamp: "1509987892", hash: "0x2b861be1ff59bae44803723c2d8d7aceda661ed4cd10a0603c4482900233a020", nonce: "2", blockHash: "0x7e4b1acbbd83dbbc31d026b511690408f71c86ce9aff5dff8014a41d53dd6fc7", transactionIndex: "17", from: "0x316b97c21bc987d9b3642d6077c3efec6d30fd23", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "220000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001cf8b697ef5958c6a47ba61c76d5956f4961ef4e285d54ba159e127b4df6b348d66389a97c7768e93cabeaa642e762546d43f8a3e68e8085e3913ce5d2c7123207000000000000000000000000000000000000000000000000000000000000002c316b97c21bc987d9b3642d6077c3efec6d30fd23807100ea94c944abba9201686b4dc1e10000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "740002", gasUsed: "211984", confirmations: "3233577"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "220000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x316b97c21bc987d9b3642d6077c3efec6d30fd23807100ea94c944abba9201686b4dc1e10000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xf8b697ef5958c6a47ba61c76d5956f4961ef4e285d54ba159e127b4df6b348d6"}, {type: "bytes32", name: "s", value: "0x6389a97c7768e93cabeaa642e762546d43f8a3e68e8085e3913ce5d2c7123207"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x316b97c21bc987d9b3642d6077c3efec6d30fd23807100ea94c944abba9201686b4dc1e10000002100028d38", "28", "0xf8b697ef5958c6a47ba61c76d5956f4961ef4e285d54ba159e127b4df6b348d6", "0x6389a97c7768e93cabeaa642e762546d43f8a3e68e8085e3913ce5d2c7123207", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1509987892 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x316b97c21bc987d9b3642d6077c3efec6d30fd23"}, {name: "weiAmount", type: "uint256", value: "220000000000000000"}, {name: "tokenAmount", type: "uint256", value: "941160043067483570768"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [17072793159, 9207954236257, 38451604586977]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "4020744243777779677" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x93dc33d2eafcd212879d4833202f99ec453a... )", async function( ) {
		const txOriginal = {blockNumber: "4502411", timeStamp: "1509987984", hash: "0x2fa9920d3e7c78d667bf527f9abbe2c95712f2ce7cf63b3063644f44fd174ea2", nonce: "0", blockHash: "0x0e563afec14e1d78703f248c66195d91cbb319a0d82f53f056a25611afc87a03", transactionIndex: "23", from: "0x93dc33d2eafcd212879d4833202f99ec453a6e18", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "350000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b7621910aa3543b64a2e65049d55cf3c420361a3f5e36a0ca177b1eeffd1346e73bf05640763a92e349f6bd3ac63e1a69e6bf915d2cd8497ba006c1015b389fa5000000000000000000000000000000000000000000000000000000000000002c93dc33d2eafcd212879d4833202f99ec453a6e18acc0f81ec74a4349a5167de6d2899f960000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1186844", gasUsed: "212048", confirmations: "3233571"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "350000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x93dc33d2eafcd212879d4833202f99ec453a6e18acc0f81ec74a4349a5167de6d2899f960000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7621910aa3543b64a2e65049d55cf3c420361a3f5e36a0ca177b1eeffd1346e7"}, {type: "bytes32", name: "s", value: "0x3bf05640763a92e349f6bd3ac63e1a69e6bf915d2cd8497ba006c1015b389fa5"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x93dc33d2eafcd212879d4833202f99ec453a6e18acc0f81ec74a4349a5167de6d2899f960000002100028d38", "27", "0x7621910aa3543b64a2e65049d55cf3c420361a3f5e36a0ca177b1eeffd1346e7", "0x3bf05640763a92e349f6bd3ac63e1a69e6bf915d2cd8497ba006c1015b389fa5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1509987984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x93dc33d2eafcd212879d4833202f99ec453a6e18"}, {name: "weiAmount", type: "uint256", value: "350000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1497300068516451135312"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [22962916874, 79480933084895, 91166327168918]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "6124337240127793275" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xd0a5f731eb92c1a4eb7b4945a8cf4cbdae77... )", async function( ) {
		const txOriginal = {blockNumber: "4502411", timeStamp: "1509987984", hash: "0xcaa48970b93e57dd18e59ebfd8744bce18c51cd7adcb892396980c63ac6539dd", nonce: "1", blockHash: "0x0e563afec14e1d78703f248c66195d91cbb319a0d82f53f056a25611afc87a03", transactionIndex: "24", from: "0xd0a5f731eb92c1a4eb7b4945a8cf4cbdae77ce44", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "167000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b7dcd4ca95f8f42c2bf9a4cb50f5347681d730b54c7fd00c72ec67b4a619b428f2f5bb4ed16b0f46212cbab35cd6b0c0e8f89c51d71bf201e58515e0b44aac6be000000000000000000000000000000000000000000000000000000000000002cd0a5f731eb92c1a4eb7b4945a8cf4cbdae77ce44ec26656542314451a73f99b1f124b0190000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1398828", gasUsed: "211984", confirmations: "3233571"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "167000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xd0a5f731eb92c1a4eb7b4945a8cf4cbdae77ce44ec26656542314451a73f99b1f124b0190000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7dcd4ca95f8f42c2bf9a4cb50f5347681d730b54c7fd00c72ec67b4a619b428f"}, {type: "bytes32", name: "s", value: "0x2f5bb4ed16b0f46212cbab35cd6b0c0e8f89c51d71bf201e58515e0b44aac6be"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xd0a5f731eb92c1a4eb7b4945a8cf4cbdae77ce44ec26656542314451a73f99b1f124b0190000002100028d38", "27", "0x7dcd4ca95f8f42c2bf9a4cb50f5347681d730b54c7fd00c72ec67b4a619b428f", "0x2f5bb4ed16b0f46212cbab35cd6b0c0e8f89c51d71bf201e58515e0b44aac6be", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1509987984 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xd0a5f731eb92c1a4eb7b4945a8cf4cbdae77ce44"}, {name: "weiAmount", type: "uint256", value: "167000000000000000"}, {name: "tokenAmount", type: "uint256", value: "714426032692135255992"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [31389717083, 17644228551220, 57296135630873]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "8248706000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xe121fe7868969d5cdcaf8dab89848ea2b0c6... )", async function( ) {
		const txOriginal = {blockNumber: "4502415", timeStamp: "1509988042", hash: "0xb3322ee18d01e16359dcc2121b0d9722f3b27f6944cc8f40c5d36ba269501524", nonce: "16", blockHash: "0xec67ff9fddbb1f1d000df2f13d6f3921363e341705ff315b5862f5336befebd0", transactionIndex: "1", from: "0xe121fe7868969d5cdcaf8dab89848ea2b0c65dd4", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "245000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bcb0f676b893927ca784622dea46147057275e23046f812acdcd8d7a92c16b6d3541152f92068ead5bed3b147622428d86f4f33dd62dac80f51e3309c2dce79de000000000000000000000000000000000000000000000000000000000000002ce121fe7868969d5cdcaf8dab89848ea2b0c65dd4f6e4adbc1dd943eea1b4d076151b35c60000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "297515", gasUsed: "212048", confirmations: "3233567"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "245000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xe121fe7868969d5cdcaf8dab89848ea2b0c65dd4f6e4adbc1dd943eea1b4d076151b35c60000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xcb0f676b893927ca784622dea46147057275e23046f812acdcd8d7a92c16b6d3"}, {type: "bytes32", name: "s", value: "0x541152f92068ead5bed3b147622428d86f4f33dd62dac80f51e3309c2dce79de"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xe121fe7868969d5cdcaf8dab89848ea2b0c65dd4f6e4adbc1dd943eea1b4d076151b35c60000002100028d38", "27", "0xcb0f676b893927ca784622dea46147057275e23046f812acdcd8d7a92c16b6d3", "0x541152f92068ead5bed3b147622428d86f4f33dd62dac80f51e3309c2dce79de", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1509988042 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xe121fe7868969d5cdcaf8dab89848ea2b0c65dd4"}, {name: "weiAmount", type: "uint256", value: "245000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1048110047961515794718"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [32817745440, 78289528425272, 91127287723462]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "18152785274758780" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xe3d53f82f44b07b5d144a099c4e6ada5ef8b... )", async function( ) {
		const txOriginal = {blockNumber: "4502415", timeStamp: "1509988042", hash: "0x23bce0b6c00926534a0cfdeae4a025af00c36c99a9fddff35f8b189a9039a63a", nonce: "0", blockHash: "0xec67ff9fddbb1f1d000df2f13d6f3921363e341705ff315b5862f5336befebd0", transactionIndex: "19", from: "0xe3d53f82f44b07b5d144a099c4e6ada5ef8b5775", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "40000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001cc8eca47ae6e1a10cfa5b8766e6c5c0e0447af08e4e2d9bb9370419784b6f97a47dbac211444bde19a18ef0edc264f670763f041b2c81779213b8e1c2688ef0d8000000000000000000000000000000000000000000000000000000000000002ce3d53f82f44b07b5d144a099c4e6ada5ef8b5775d8e34f084fe44016813ebf5a902f77cc0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1736080", gasUsed: "212048", confirmations: "3233567"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "40000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xe3d53f82f44b07b5d144a099c4e6ada5ef8b5775d8e34f084fe44016813ebf5a902f77cc0000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc8eca47ae6e1a10cfa5b8766e6c5c0e0447af08e4e2d9bb9370419784b6f97a4"}, {type: "bytes32", name: "s", value: "0x7dbac211444bde19a18ef0edc264f670763f041b2c81779213b8e1c2688ef0d8"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xe3d53f82f44b07b5d144a099c4e6ada5ef8b5775d8e34f084fe44016813ebf5a902f77cc0000002100028d38", "28", "0xc8eca47ae6e1a10cfa5b8766e6c5c0e0447af08e4e2d9bb9370419784b6f97a4", "0x7dbac211444bde19a18ef0edc264f670763f041b2c81779213b8e1c2688ef0d8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1509988042 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xe3d53f82f44b07b5d144a099c4e6ada5ef8b5775"}, {name: "weiAmount", type: "uint256", value: "40000000000000000"}, {name: "tokenAmount", type: "uint256", value: "171120007830451558321"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [28829350144, 53384765243317, 903620868044]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "5546992000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xe18c718dcb06f42385e37d470a5ebc6e6602... )", async function( ) {
		const txOriginal = {blockNumber: "4502426", timeStamp: "1509988221", hash: "0x18b4f8422165d6555e0280f5aabb6d18834ab66f596e0c3af3850a6df7b25ca2", nonce: "41", blockHash: "0x2f37933b4c2cd622edb10c093e0e0b4e92d993ade35475bad8a056eb0dc7878b", transactionIndex: "4", from: "0xe18c718dcb06f42385e37d470a5ebc6e66022a5e", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "100000000000000000", gas: "260300", gasPrice: "31500000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001ca841fb873ada9b9959eb3ccb63e03e304e8128a7cc4adf1aaa0379eb120e3893025b4bd256c57fbf5f709964c35ab666b80059815aaec85af95aef86c220e0ba000000000000000000000000000000000000000000000000000000000000002ce18c718dcb06f42385e37d470a5ebc6e66022a5e5ad7dadb54f3472ea440bf025aed1e0b0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "328659", gasUsed: "211984", confirmations: "3233556"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xe18c718dcb06f42385e37d470a5ebc6e66022a5e5ad7dadb54f3472ea440bf025aed1e0b0000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xa841fb873ada9b9959eb3ccb63e03e304e8128a7cc4adf1aaa0379eb120e3893"}, {type: "bytes32", name: "s", value: "0x025b4bd256c57fbf5f709964c35ab666b80059815aaec85af95aef86c220e0ba"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xe18c718dcb06f42385e37d470a5ebc6e66022a5e5ad7dadb54f3472ea440bf025aed1e0b0000002100028d38", "28", "0xa841fb873ada9b9959eb3ccb63e03e304e8128a7cc4adf1aaa0379eb120e3893", "0x025b4bd256c57fbf5f709964c35ab666b80059815aaec85af95aef86c220e0ba", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1509988221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xe18c718dcb06f42385e37d470a5ebc6e66022a5e"}, {name: "weiAmount", type: "uint256", value: "100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "427800019576128895803"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [12075130238, 77794491370845, 67258269556235]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "890812644200000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x9d8d9d80cb04b4a326e881f64e1d69bebbba... )", async function( ) {
		const txOriginal = {blockNumber: "4502426", timeStamp: "1509988221", hash: "0x7a45322fc85dba9d1b8eaa6d3eac43715382668232e0db7a9b9a4b5bf9543742", nonce: "6", blockHash: "0x2f37933b4c2cd622edb10c093e0e0b4e92d993ade35475bad8a056eb0dc7878b", transactionIndex: "12", from: "0x9d8d9d80cb04b4a326e881f64e1d69bebbba0795", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "310518654517920000", gas: "250600", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c441aaf3f5ecda9edb0d9af7e28e26f86e4b64618ade25865eb7954e839d3802c1f62e84b8e5b8f80dfdafa5675947341d778dc219a5263d3e54b37c5ad10d517000000000000000000000000000000000000000000000000000000000000002c9d8d9d80cb04b4a326e881f64e1d69bebbba07955f5bd3280fd24e3f9886eccd400cb82b0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "955328", gasUsed: "212048", confirmations: "3233556"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "310518654517920000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x9d8d9d80cb04b4a326e881f64e1d69bebbba07955f5bd3280fd24e3f9886eccd400cb82b0000002100028d38"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x441aaf3f5ecda9edb0d9af7e28e26f86e4b64618ade25865eb7954e839d3802c"}, {type: "bytes32", name: "s", value: "0x1f62e84b8e5b8f80dfdafa5675947341d778dc219a5263d3e54b37c5ad10d517"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x9d8d9d80cb04b4a326e881f64e1d69bebbba07955f5bd3280fd24e3f9886eccd400cb82b0000002100028d38", "28", "0x441aaf3f5ecda9edb0d9af7e28e26f86e4b64618ade25865eb7954e839d3802c", "0x1f62e84b8e5b8f80dfdafa5675947341d778dc219a5263d3e54b37c5ad10d517", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1509988221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9d8d9d80cb04b4a326e881f64e1d69bebbba0795"}, {name: "weiAmount", type: "uint256", value: "310518654517920000"}, {name: "tokenAmount", type: "uint256", value: "1328398864815193813943"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [12675344137, 61430674002514, 23444890859563]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "1788055000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x9ef5468fcd0d9b1a05c84febfbec979e2f10... )", async function( ) {
		const txOriginal = {blockNumber: "4502426", timeStamp: "1509988221", hash: "0xa6a42c2f2830849dab8b50d8b468a8120197329133779b4882c1f20af9296dd6", nonce: "2", blockHash: "0x2f37933b4c2cd622edb10c093e0e0b4e92d993ade35475bad8a056eb0dc7878b", transactionIndex: "13", from: "0x9ef5468fcd0d9b1a05c84febfbec979e2f100f5f", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "1820619636000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bc3ec2940f290e0d75ee9aa19dc97933e34f95fc1d21432bf7e9aae0bdc8e84cd602e2c245323f692cab88f6005aa826c72a9b9e4ebf8bca178e3f0afa3d2e097000000000000000000000000000000000000000000000000000000000000002c9ef5468fcd0d9b1a05c84febfbec979e2f100f5fec2dbd5f269a47a4a8457919b095a8c80000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1167376", gasUsed: "212048", confirmations: "3233556"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "1820619636000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x9ef5468fcd0d9b1a05c84febfbec979e2f100f5fec2dbd5f269a47a4a8457919b095a8c80000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xc3ec2940f290e0d75ee9aa19dc97933e34f95fc1d21432bf7e9aae0bdc8e84cd"}, {type: "bytes32", name: "s", value: "0x602e2c245323f692cab88f6005aa826c72a9b9e4ebf8bca178e3f0afa3d2e097"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x9ef5468fcd0d9b1a05c84febfbec979e2f100f5fec2dbd5f269a47a4a8457919b095a8c80000002100028d38", "27", "0xc3ec2940f290e0d75ee9aa19dc97933e34f95fc1d21432bf7e9aae0bdc8e84cd", "0x602e2c245323f692cab88f6005aa826c72a9b9e4ebf8bca178e3f0afa3d2e097", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1509988221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9ef5468fcd0d9b1a05c84febfbec979e2f100f5f"}, {name: "weiAmount", type: "uint256", value: "1820619636000000000"}, {name: "tokenAmount", type: "uint256", value: "7788611159214846645671"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [31393530127, 79116855442478, 44038776301768]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "99948012900000001" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4502426", timeStamp: "1509988221", hash: "0xba807e133f37287d8bd2f5cec5395b33dac3e1ae4d1c6fb19efa5c752c7b8b8f", nonce: "4", blockHash: "0x2f37933b4c2cd622edb10c093e0e0b4e92d993ade35475bad8a056eb0dc7878b", transactionIndex: "27", from: "0x4a9a3815060c3bd08fb4d44c9e74513874771b0c", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "1334000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0xdf33a32b967578692b46720d639b57ef40a91966cfe1be256761f620c48916cca44fa0a36b286de520439d000000000000000000000000000000000000000000000000000000000000002c4a9a3815060c3bd08fb4d44c9e74513874771b0cee3fc9d4bf524ffb9c4631c0c4ee8c0d0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1711737", gasUsed: "28093", confirmations: "3233556"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "1334000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1509988221 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "82036790000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xe2073845c6a61e863d9bb860097a3a2654bc... )", async function( ) {
		const txOriginal = {blockNumber: "4502440", timeStamp: "1509988408", hash: "0x5d48437e5ad5bae07a8890c90f0a4680e0c05115db93775955dd3ed323a297b8", nonce: "2", blockHash: "0x899a50e65a9bfb46d056982711a3e8aad1210d39b78237d9917f63d781bce36b", transactionIndex: "7", from: "0xbaeb1f9fd567f4c46dc47298cb28961cb9a83d4e", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "16712400000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "0", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b30bb5d49699f68aeed7a250195a629861d3a74087dc36443a7ec29abcaeb22ff7ae9cfa23b436d0e7152cdedc4b44fe7c6fe97b3e80067eb8567f518e4cae57b000000000000000000000000000000000000000000000000000000000000002ce2073845c6a61e863d9bb860097a3a2654bc2964e7667661e7ef41909a1daaa77b9154860000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "370204", gasUsed: "65542", confirmations: "3233542"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "16712400000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xe2073845c6a61e863d9bb860097a3a2654bc2964e7667661e7ef41909a1daaa77b9154860000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x30bb5d49699f68aeed7a250195a629861d3a74087dc36443a7ec29abcaeb22ff"}, {type: "bytes32", name: "s", value: "0x7ae9cfa23b436d0e7152cdedc4b44fe7c6fe97b3e80067eb8567f518e4cae57b"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xe2073845c6a61e863d9bb860097a3a2654bc2964e7667661e7ef41909a1daaa77b9154860000002100028d38", "27", "0x30bb5d49699f68aeed7a250195a629861d3a74087dc36443a7ec29abcaeb22ff", "0x7ae9cfa23b436d0e7152cdedc4b44fe7c6fe97b3e80067eb8567f518e4cae57b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1509988408 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "1290505502000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x40cf5abeebaded527d751d829f82214aff60... )", async function( ) {
		const txOriginal = {blockNumber: "4502444", timeStamp: "1509988471", hash: "0xe9b1a6b13d406bdc42c3bbcf2b244684d022d46570fc22c9f28def6b2347b92d", nonce: "157", blockHash: "0xf90ae5640b597d773d5bc1385af4c625d1121729f3e1463af3015619496fae1e", transactionIndex: "6", from: "0x40cf5abeebaded527d751d829f82214aff60eecd", to: "0xef0f5d9a8435e217038d6417670013cc06aa5e38", value: "16712400000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bb9d87ce34d82f4dbf9dd400ae662124f1533cd8e24a71fb1b3d8da4e3c93d1a4465d11d59cd62de7ead1f3c36bacc5cf67346e9029d708c13c1fc02ae8e05350000000000000000000000000000000000000000000000000000000000000002c40cf5abeebaded527d751d829f82214aff60eecd556c60738f774276be12c26d0db450cc0000002100028d380000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "575340", gasUsed: "212048", confirmations: "3233538"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "16712400000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x40cf5abeebaded527d751d829f82214aff60eecd556c60738f774276be12c26d0db450cc0000002100028d38"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xb9d87ce34d82f4dbf9dd400ae662124f1533cd8e24a71fb1b3d8da4e3c93d1a4"}, {type: "bytes32", name: "s", value: "0x465d11d59cd62de7ead1f3c36bacc5cf67346e9029d708c13c1fc02ae8e05350"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x40cf5abeebaded527d751d829f82214aff60eecd556c60738f774276be12c26d0db450cc0000002100028d38", "27", "0xb9d87ce34d82f4dbf9dd400ae662124f1533cd8e24a71fb1b3d8da4e3c93d1a4", "0x465d11d59cd62de7ead1f3c36bacc5cf67346e9029d708c13c1fc02ae8e05350", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1509988471 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x40cf5abeebaded527d751d829f82214aff60eecd"}, {name: "weiAmount", type: "uint256", value: "16712400000000000000"}, {name: "tokenAmount", type: "uint256", value: "71495650471640965582290"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [11354710396, 94007827250507, 94905231970508]}}], address: "0xef0f5d9a8435e217038d6417670013cc06aa5e38"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "194075244000000003" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
