const KassaNetwork = artifacts.require( "./KassaNetwork.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "KassaNetwork" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xaB0b48266f362F82C9226B1CA5FB2C8b07aD01A5", "0x7A21fedDC0EB49e817474727f855682210140A50", "0xf433e0Ec467b3d96Ca14B5C8619428130A5a9503", "0x261b9210962CafB55576168a3d83e6bdCaDBa2FB", "0xDc8862DfCCf67F50EB755e16f27E560fcAB4fEFD", "0x7eFe4672fFc7Db035b0Aa22c2f48D7FC7376608d", "0xeD0F52911188616c27dF1Aafeb2CbFD9eE0979C0", "0xc3f2668AF9F4281d687930e1c94E8f021891541d", "0xF09Af3CbE324CbFc2C27C7F8c4b01AF80B99bc86", "0xbA659ae227f026F7cf7e148918C116b3299Db8Bf", "0x9C53360622306b4b1b19ee118B530501c0F4c822", "0xe821C7322f727fEdd0cc2d69fAC48289faE1b8bc", "0xA5555e2AF5bC9444D2c3cCEBC2d66B1bDcD5A0BE", "0x05F52D5F2dCd75c1fC5B389fA54AD0e3e2bA7e54", "0x065B44220c91BCFeD8cB27D03287CFF4b5bfDFC8", "0xdB7E85a6A4d57AFdD72aFa3042898109395Cf84F", "0x78eAF48B9c9AB3a7A57Ba04EA4B50F8Fa7f97b0e", "0x02382E890c9865cdCE2C28877D356aCC4c7A9818", "0xA74aEc9daEb2ef2ACB659Aab5beE289314B4a878", "0xa5A07fA8014FD9cCa3bFe3Dadcdf7c7e605Dc493", "0xd4010069cCf3C1b05c03D5178552Ea938770dcE7", "0x9F9e7f57232C9eB54a0aFB7cE15286E33A2E733D", "0x4a66adf5907f15F43Fafc36a84C5d54221B98418", "0x1E76Dd58faAddc79D31681cCA565a1DFe4475c76", "0x4F0Acc54994bf27Baa11D5C24ddaEd6920Eaf7a7", "0xABD1eaD4c68C4ADc0Fb530D7d969a8eCA2CDE308", "0xAEAAC442433bDCA145678050aD43e082f75A5599", "0x61Ea5720b2fE33A8aD4a5b3b1780b35fe31f2344", "0xE61f129697A34Ca51D73cE51d6F73F127b23F68C", "0xe0D6772fc01F7a4E571f1a4EaD3B94Ca43A22E71", "0x386f506E05704401B3769fF818DBd6c80F3BA3CA"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "nDay", type: "uint256"}], name: "getDayRestDepositLimit", outputs: [{name: "restLimit", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentDayDepositLimit", outputs: [{name: "limit", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "bonusReferrer", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxDepositDays", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "procReturn", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "countInvestors", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentDay", outputs: [{name: "nday", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxDepositProgressProc", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "progressProcKoef", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalInvest", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maximalDepositStart", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "addr", type: "address"}], name: "getUser", outputs: [{name: "balance", type: "uint256"}, {name: "timestamp", type: "uint256"}, {name: "paidInteres", type: "uint256"}, {name: "totalInteres", type: "uint256"}, {name: "countReferrals", type: "uint256"}, {name: "earnOnReferrals", type: "uint256"}, {name: "paidReferrals", type: "uint256"}, {name: "referrer", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minimalDeposit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "procKoef", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getTotals", outputs: [{name: "_maxDepositDays", type: "uint256"}, {name: "_perDay", type: "uint256"}, {name: "_startTimestamp", type: "uint256"}, {name: "_minimalDeposit", type: "uint256"}, {name: "_maximalDeposit", type: "uint256"}, {name: "_bonusReferrer", type: "uint256[3]"}, {name: "_minimalDepositForBonusReferrer", type: "uint256"}, {name: "_ownerFee", type: "uint256"}, {name: "_countInvestors", type: "uint256"}, {name: "_totalInvest", type: "uint256"}, {name: "_totalPenalty", type: "uint256"}, {name: "_totalPaid", type: "uint256"}, {name: "_currentDayDepositLimit", type: "uint256"}, {name: "_currentDayRestDepositLimit", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentDayRestDepositLimit", outputs: [{name: "restLimit", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "nDay", type: "uint256"}], name: "getDayDepositLimit", outputs: [{name: "limit", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "totalSelfInvest", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "perDay", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "start", type: "uint256"}, {name: "proc", type: "uint256"}, {name: "nDay", type: "uint256"}], name: "calcProgress", outputs: [{name: "res", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "dayLimitStart", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minimalDepositForBonusReferrer", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ownerFee", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "dayLimitProgressProc", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalPenalty", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startTimestamp", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalPaid", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCurrentMaximalDeposit", outputs: [{name: "maximalDeposit", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "nDay", type: "uint256"}], name: "getMaximalDeposit", outputs: [{name: "limit", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "date", type: "uint256"}], name: "getNDay", outputs: [{name: "nday", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_value", type: "uint256"}], name: "LogSelfInvestment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}], name: "LogSkipPreparePayment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_totalPenalty", type: "uint256"}], name: "LogMinimalDepositPayment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "currentSenderDeposit", type: "uint256"}, {indexed: false, name: "referrerAdressLength", type: "uint256"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "currentReferrerDeposit", type: "uint256"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_sendBackAmount", type: "uint256"}, {indexed: false, name: "_totalPenalty", type: "uint256"}], name: "LogPenaltyPayment", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_badDeposit", type: "uint256"}, {indexed: false, name: "_sendBackAmount", type: "uint256"}, {indexed: false, name: "_totalPenalty", type: "uint256"}, {indexed: false, name: "_willDeposit", type: "uint256"}], name: "LogExceededRestDepositPerDay", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogInvestment(address,uint256,bytes)", "LogTransfer(address,uint256,uint256)", "LogSelfInvestment(uint256)", "LogPreparePayment(address,uint256,uint256,uint256)", "LogSkipPreparePayment(address,uint256,uint256)", "LogPreparePaymentReferrer(address,uint256,uint256,uint256)", "LogSkipPreparePaymentReferrer(address,uint256,uint256)", "LogMinimalDepositPayment(address,uint256,uint256)", "LogPenaltyPayment(address,uint256,uint256,address,uint256,uint256,uint256,uint256)", "LogExceededRestDepositPerDay(address,address,uint256,uint256,uint256,uint256,uint256,uint256,uint256)", "LogUsedRestDepositPerDay(address,address,uint256,uint256,uint256,uint256,uint256)", "LogCalcBonusReferrer(address,uint256,uint256,uint256,uint256,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x99e2484dc464ddf092d71c20d980a682dbf05009ca71f79590e2d3f5675efe5f", "0x18b0800c80490f5a2cdb8878912fa0744819cf79cb6bda0573399ceee459b66a", "0x3585958531221565c883e7a8ba901a55ac36449b6bfe60a9dbe534db7c21f0f5", "0x57c51513ed5ecca02e35c0a9c73f9031060fffb0ee67e5ba2ae3a7876bcc4660", "0x269d6e9105178515061a0776774390056c694e459c03ba0bcf1fe366e44ca123", "0x00260dbd6ad9a7bc95a107bbd98c073edf3b09c4bec03b39f37d0dc88b8d3475", "0x7d11a9324c66449899d527db8661c450d2049209ed0afc56d94d759f31da6e73", "0x3654ed221c1eb7340b328ed3408f7cc02d706326934eec02698a25eda9ffcb5c", "0x5e8cddbb251d1b21cc4db87b9d1157cc97d91a4439b41aa4d01567dc8060a6ed", "0x17eaccf7da42210592a965bb9e884cd2664e53ad0faaff1e8d8439052f17b0a9", "0x761add23ed054f41556a04f26f05e19442fefa49e127dde0e9bb6a385976d290", "0x7e12d55f7c1ae1ac0321507b7d010aab01dc2ede8a458d9c22e24116c608c19b"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6568747 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6729306 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [], name: "KassaNetwork", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "nDay", value: random.range( maxRandom )}], name: "getDayRestDepositLimit", outputs: [{name: "restLimit", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDayRestDepositLimit(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentDayDepositLimit", outputs: [{name: "limit", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentDayDepositLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "bonusReferrer", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bonusReferrer(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxDepositDays", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxDepositDays()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "procReturn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "procReturn()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "countInvestors", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "countInvestors()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentDay", outputs: [{name: "nday", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentDay()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxDepositProgressProc", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxDepositProgressProc()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "progressProcKoef", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "progressProcKoef()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalInvest", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalInvest()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maximalDepositStart", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maximalDepositStart()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getUser", outputs: [{name: "balance", type: "uint256"}, {name: "timestamp", type: "uint256"}, {name: "paidInteres", type: "uint256"}, {name: "totalInteres", type: "uint256"}, {name: "countReferrals", type: "uint256"}, {name: "earnOnReferrals", type: "uint256"}, {name: "paidReferrals", type: "uint256"}, {name: "referrer", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getUser(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimalDeposit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimalDeposit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "procKoef", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "procKoef()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTotals", outputs: [{name: "_maxDepositDays", type: "uint256"}, {name: "_perDay", type: "uint256"}, {name: "_startTimestamp", type: "uint256"}, {name: "_minimalDeposit", type: "uint256"}, {name: "_maximalDeposit", type: "uint256"}, {name: "_bonusReferrer", type: "uint256[3]"}, {name: "_minimalDepositForBonusReferrer", type: "uint256"}, {name: "_ownerFee", type: "uint256"}, {name: "_countInvestors", type: "uint256"}, {name: "_totalInvest", type: "uint256"}, {name: "_totalPenalty", type: "uint256"}, {name: "_totalPaid", type: "uint256"}, {name: "_currentDayDepositLimit", type: "uint256"}, {name: "_currentDayRestDepositLimit", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTotals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentDayRestDepositLimit", outputs: [{name: "restLimit", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentDayRestDepositLimit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "nDay", value: random.range( maxRandom )}], name: "getDayDepositLimit", outputs: [{name: "limit", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDayDepositLimit(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalSelfInvest", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalSelfInvest()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "perDay", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "perDay()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "start", value: random.range( maxRandom )}, {type: "uint256", name: "proc", value: random.range( maxRandom )}, {type: "uint256", name: "nDay", value: random.range( maxRandom )}], name: "calcProgress", outputs: [{name: "res", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcProgress(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "dayLimitStart", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dayLimitStart()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimalDepositForBonusReferrer", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimalDepositForBonusReferrer()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ownerFee", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerFee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "dayLimitProgressProc", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dayLimitProgressProc()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalPenalty", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalPenalty()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startTimestamp", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startTimestamp()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalPaid", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalPaid()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCurrentMaximalDeposit", outputs: [{name: "maximalDeposit", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCurrentMaximalDeposit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "nDay", value: random.range( maxRandom )}], name: "getMaximalDeposit", outputs: [{name: "limit", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMaximalDeposit(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "date", value: random.range( maxRandom )}], name: "getNDay", outputs: [{name: "nday", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNDay(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "KassaNetwork", function( accounts ) {

	it( "TEST: KassaNetwork(  )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6568747", timeStamp: "1540299445", hash: "0x5e898bc649eb31c7a71c5c20a62e4b5c10979cd52da31c8538754d3411b54186", nonce: "6", blockHash: "0x662df5135e9c2b94d1ae468ddafba63f096342e8acf95e2de07a7ad82c5220f6", transactionIndex: "46", from: "0x7a21feddc0eb49e817474727f855682210140a50", to: 0, value: "0", gas: "1791055", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9ffcc536", contractAddress: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", cumulativeGasUsed: "4108401", gasUsed: "1791055", confirmations: "1171793"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "KassaNetwork", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = KassaNetwork.new( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540299445 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = KassaNetwork.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "121675973451726120" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6572530", timeStamp: "1540353086", hash: "0x07a3e479242a2c67c1535e08b8e8392122f5798fb5ca96ab5842a53c45adc2f6", nonce: "2", blockHash: "0x58615894ee75548d8c715934e7beacc79c8aeba7c2a6edf45d962052f173c32f", transactionIndex: "157", from: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "1080000000000000000", gas: "210030", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0x7a21feddc0eb49e817474727f855682210140a50", contractAddress: "", cumulativeGasUsed: "7057963", gasUsed: "210030", confirmations: "1168010"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1080000000000000000" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "918504947000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6572537", timeStamp: "1540353182", hash: "0xa9694ba7685eb80f4e69656acc21322bbb46e33be53b3e8c2cf0b2be12dc5db1", nonce: "3", blockHash: "0xdd4ed5bfd6ffa6e8529c574cc7389b0b905a1bf57618ae3a2fa35e0588b37a8a", transactionIndex: "89", from: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "1080000000000000000", gas: "300030", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x7a21feddc0eb49e817474727f855682210140a50", contractAddress: "", cumulativeGasUsed: "4111368", gasUsed: "241891", confirmations: "1168003"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "1080000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540353182 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_value", type: "uint256", value: "1080000000000000000"}, {name: "_refData", type: "bytes", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "75600000000000000"}, {name: "_contactBalance", type: "uint256", value: "1080000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "64800000000000000"}, {name: "_contactBalance", type: "uint256", value: "1004400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[2,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "64800000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "64800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[2,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[2,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "1080000000000000000"}, {name: "_nDay", type: "uint256", value: "0"}, {name: "_restDepositPerDay", type: "uint256", value: "50000000000000000000"}, {name: "_realDeposit", type: "uint256", value: "1080000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "1080000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[2,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[2,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "1080000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "64800000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[2,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "918504947000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6572600", timeStamp: "1540353972", hash: "0xbf8626090d980513bc8975ed8abc523a34a8f924b1022f8ab983cf70b708ed6b", nonce: "3", blockHash: "0xeaa3f7ffe2a04a705c77f8d7f440449bd9b04b8f4326e8c03ed3cbcc34a8e4d2", transactionIndex: "99", from: "0x261b9210962cafb55576168a3d83e6bdcadba2fb", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "1080000000000000000", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503", contractAddress: "", cumulativeGasUsed: "6067302", gasUsed: "244960", confirmations: "1167940"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "1080000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540353972 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_value", type: "uint256", value: "1080000000000000000"}, {name: "_refData", type: "bytes", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "75600000000000000"}, {name: "_contactBalance", type: "uint256", value: "2019600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_amount", type: "uint256", value: "64800000000000000"}, {name: "_contactBalance", type: "uint256", value: "1944000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "21600000000000000"}, {name: "_contactBalance", type: "uint256", value: "1879200000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_totalReferrals", type: "uint256", value: "64800000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "64800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "86400000000000000"}, {name: "_paidReferrals", type: "uint256", value: "64800000000000000"}, {name: "_amount", type: "uint256", value: "21600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[3,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_referrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_money", type: "uint256", value: "1080000000000000000"}, {name: "_nDay", type: "uint256", value: "0"}, {name: "_restDepositPerDay", type: "uint256", value: "48920000000000000000"}, {name: "_realDeposit", type: "uint256", value: "1080000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "2160000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[3,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[3,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_money", type: "uint256", value: "1080000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "64800000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "1080000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "21600000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[3,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "70956698000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6575347", timeStamp: "1540392774", hash: "0x95a8dada91de07a3fde6b246aba4e9273d88a58d99b6bf1e149665c350c468d7", nonce: "7", blockHash: "0x8e57c527f0bdb503c1425e971009376e572157e657fe19d54ee7d7bf3d9632a0", transactionIndex: "148", from: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "1080000000000000000", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x261b9210962cafb55576168a3d83e6bdcadba2fb", contractAddress: "", cumulativeGasUsed: "7416294", gasUsed: "262102", confirmations: "1165193"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1080000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540392774 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_value", type: "uint256", value: "1080000000000000000"}, {name: "_refData", type: "bytes", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "75600000000000000"}, {name: "_contactBalance", type: "uint256", value: "2937600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_amount", type: "uint256", value: "64800000000000000"}, {name: "_contactBalance", type: "uint256", value: "2862000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_amount", type: "uint256", value: "21600000000000000"}, {name: "_contactBalance", type: "uint256", value: "2797200000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[4,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "64800000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "64800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_totalReferrals", type: "uint256", value: "86400000000000000"}, {name: "_paidReferrals", type: "uint256", value: "64800000000000000"}, {name: "_amount", type: "uint256", value: "21600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[4,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[4,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "97200000000000000"}, {name: "_paidReferrals", type: "uint256", value: "86400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[4,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[4,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "1080000000000000000"}, {name: "_nDay", type: "uint256", value: "1"}, {name: "_restDepositPerDay", type: "uint256", value: "51500000000000000000"}, {name: "_realDeposit", type: "uint256", value: "1080000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "1080000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[4,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[4,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "1080000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "64800000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_money", type: "uint256", value: "1080000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "21600000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "1080000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "10800000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[4,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "58715965765718892" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6575484", timeStamp: "1540394622", hash: "0xd9fa04730cb2db6e3e2359044443d85eb71ac486204965ec30599be65e21dcc2", nonce: "8", blockHash: "0x358ec1a650274987f58f09ea8871ee563b965a5e67fc5121d6a9eb254a046507", transactionIndex: "72", from: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "15000000000000000000", gas: "375439", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd", contractAddress: "", cumulativeGasUsed: "7348807", gasUsed: "268330", confirmations: "1165056"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "15000000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540394622 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_value", type: "uint256", value: "15000000000000000000"}, {name: "_refData", type: "bytes", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "1050000000000000000"}, {name: "_contactBalance", type: "uint256", value: "17775600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_amount", type: "uint256", value: "900000000000000000"}, {name: "_contactBalance", type: "uint256", value: "16725600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_amount", type: "uint256", value: "300000000000000000"}, {name: "_contactBalance", type: "uint256", value: "15825600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_amount", type: "uint256", value: "150000000000000000"}, {name: "_contactBalance", type: "uint256", value: "15525600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "900000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "900000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "364800000000000000"}, {name: "_paidReferrals", type: "uint256", value: "64800000000000000"}, {name: "_amount", type: "uint256", value: "300000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_totalReferrals", type: "uint256", value: "236400000000000000"}, {name: "_paidReferrals", type: "uint256", value: "86400000000000000"}, {name: "_amount", type: "uint256", value: "150000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[5,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "15000000000000000000"}, {name: "_nDay", type: "uint256", value: "1"}, {name: "_restDepositPerDay", type: "uint256", value: "50420000000000000000"}, {name: "_realDeposit", type: "uint256", value: "15000000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "16080000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[5,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[5,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "15000000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "900000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "15000000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "300000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_money", type: "uint256", value: "15000000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "150000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[5,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "7041091504680778460" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6582095", timeStamp: "1540487531", hash: "0xc0cbcd17bf0885f6af5f702dd3d04985a7668f6e5ecb590058d97361d8489055", nonce: "71", blockHash: "0x6a4bbcdf5aa3d87e9883eed6f1bebdae3e0b1c469242537859b3205f10fdd90d", transactionIndex: "88", from: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "260000000000000000", gas: "300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x7a21feddc0eb49e817474727f855682210140a50", contractAddress: "", cumulativeGasUsed: "6418794", gasUsed: "168003", confirmations: "1158445"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "260000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1540487531 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_value", type: "uint256", value: "260000000000000000"}, {name: "_refData", type: "bytes", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "18200000000000000"}, {name: "_contactBalance", type: "uint256", value: "15635600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "26400000000000000"}, {name: "_contactBalance", type: "uint256", value: "15617400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "112800000000000000"}, {name: "_paidReferrals", type: "uint256", value: "86400000000000000"}, {name: "_amount", type: "uint256", value: "26400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[6,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_nDay", type: "uint256", value: "2"}, {name: "_restDepositPerDay", type: "uint256", value: "53045000000000000000"}, {name: "_realDeposit", type: "uint256", value: "260000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "260000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[6,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[6,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15600000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[6,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "14801465785069086843" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6582161", timeStamp: "1540488478", hash: "0x31f6e94d5055d296f31de4481f56362974b520ab47292d55afbb1d1512376a4e", nonce: "1", blockHash: "0xc9713e9a52e5f39604982d8b1c97a496ae76d98ba534d4cb3ab16dec026d5b3c", transactionIndex: "181", from: "0xc3f2668af9f4281d687930e1c94e8f021891541d", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "260000000000000000", gas: "300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0", contractAddress: "", cumulativeGasUsed: "7549082", gasUsed: "215131", confirmations: "1158379"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "260000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1540488478 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_value", type: "uint256", value: "260000000000000000"}, {name: "_refData", type: "bytes", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "18200000000000000"}, {name: "_contactBalance", type: "uint256", value: "15851000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_amount", type: "uint256", value: "15600000000000000"}, {name: "_contactBalance", type: "uint256", value: "15832800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_totalReferrals", type: "uint256", value: "15600000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "15600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[7,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "118000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "112800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[7,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[7,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_referrer", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_nDay", type: "uint256", value: "2"}, {name: "_restDepositPerDay", type: "uint256", value: "52785000000000000000"}, {name: "_realDeposit", type: "uint256", value: "260000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "520000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[7,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[7,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15600000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5200000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[7,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "25075971800000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6582223", timeStamp: "1540489167", hash: "0xc7de46631d67c30525dc9dd83736729b442c1dff2049598673db0c925cb468b7", nonce: "1", blockHash: "0xd88a614171230b0690a1336cd431d3f9d4498b23d1f3fb23245dbe4eca0486f5", transactionIndex: "60", from: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "260000000000000000", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xc3f2668af9f4281d687930e1c94e8f021891541d", contractAddress: "", cumulativeGasUsed: "5627725", gasUsed: "226430", confirmations: "1158317"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "260000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1540489167 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}, {name: "_value", type: "uint256", value: "260000000000000000"}, {name: "_refData", type: "bytes", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "18200000000000000"}, {name: "_contactBalance", type: "uint256", value: "16077200000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_amount", type: "uint256", value: "15600000000000000"}, {name: "_contactBalance", type: "uint256", value: "16059000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_totalReferrals", type: "uint256", value: "15600000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "15600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[8,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_totalReferrals", type: "uint256", value: "20800000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "120600000000000000"}, {name: "_paidReferrals", type: "uint256", value: "112800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[8,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[8,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}, {name: "_referrer", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_nDay", type: "uint256", value: "2"}, {name: "_restDepositPerDay", type: "uint256", value: "52525000000000000000"}, {name: "_realDeposit", type: "uint256", value: "260000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "780000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[8,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[8,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15600000000000000"}, {name: "_nextReferrer", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5200000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2600000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[8,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "118234582200000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6586010", timeStamp: "1540543039", hash: "0xe0d7486e354152563378005c559bbdf8e77917546a4e11de45d399299345f82e", nonce: "1", blockHash: "0xc29190b4506ba7c4d4998e01e281c6f12a21febf420beeda835b7c7cbae90af4", transactionIndex: "148", from: "0xba659ae227f026f7cf7e148918c116b3299db8bf", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "754390", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "6982503", gasUsed: "226430", confirmations: "1154530"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1540543039 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "16293400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "16275900000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "15000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[9,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "905000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "900000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "367300000000000000"}, {name: "_paidReferrals", type: "uint256", value: "364800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[9,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[9,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "2"}, {name: "_restDepositPerDay", type: "uint256", value: "52265000000000000000"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "1030000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[9,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[9,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2500000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[9,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "170126524200000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6586158", timeStamp: "1540545250", hash: "0xb1871f649c9e8e1383e5e9de198ca3ed421df9c52ca8e455285e10c65471a931", nonce: "1", blockHash: "0x4bb60bd487ebb60f3ebdb84af232c472fe397033e99c84b6f4afaee292814dba", transactionIndex: "164", from: "0x9c53360622306b4b1b19ee118b530501c0f4c822", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "754390", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xba659ae227f026f7cf7e148918c116b3299db8bf", contractAddress: "", cumulativeGasUsed: "7210667", gasUsed: "226430", confirmations: "1154382"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1540545250 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "16510900000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "16493400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[10,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_totalReferrals", type: "uint256", value: "15000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[10,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[10,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "20000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "907500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "900000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[10,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[10,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_referrer", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "2"}, {name: "_restDepositPerDay", type: "uint256", value: "52015000000000000000"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "1280000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[10,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[10,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2500000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[10,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "171795042100000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6586266", timeStamp: "1540546627", hash: "0x6499d3a8789896c33b6cd74a71d37110a1f8f3a12bd271f686590d7f70107909", nonce: "1", blockHash: "0xe56f1d95ea3be2204494dae4e4310ee0eceff515ee0bb9550ded17e8be608fa7", transactionIndex: "71", from: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "754390", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x9c53360622306b4b1b19ee118b530501c0f4c822", contractAddress: "", cumulativeGasUsed: "3625193", gasUsed: "226430", confirmations: "1154274"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1540546627 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "16728400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "16710900000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_totalReferrals", type: "uint256", value: "15000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[11,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_totalReferrals", type: "uint256", value: "20000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "22500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[11,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[11,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_referrer", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "2"}, {name: "_restDepositPerDay", type: "uint256", value: "51765000000000000000"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "1530000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[11,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[11,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2500000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[11,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "2408497900600000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6586288", timeStamp: "1540546891", hash: "0xce0f379f953b97518dc4ec590d2ad8abd66f0c3a5d9c9ec6ad15db10466aefe9", nonce: "1", blockHash: "0xcaf79f0f781faefa0eb64429024f879bfa443b24875c78f66be011079c47d0a2", transactionIndex: "13", from: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "500000000000000000", gas: "300000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "491942", gasUsed: "202658", confirmations: "1154252"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1540546891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be"}, {name: "_value", type: "uint256", value: "500000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "35000000000000000"}, {name: "_contactBalance", type: "uint256", value: "17195900000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "37500000000000000"}, {name: "_contactBalance", type: "uint256", value: "17160900000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "17123400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[12,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "52500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15000000000000000"}, {name: "_amount", type: "uint256", value: "37500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "917500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "900000000000000000"}, {name: "_amount", type: "uint256", value: "17500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[12,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[12,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "372300000000000000"}, {name: "_paidReferrals", type: "uint256", value: "364800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[12,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[12,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "500000000000000000"}, {name: "_nDay", type: "uint256", value: "2"}, {name: "_restDepositPerDay", type: "uint256", value: "51515000000000000000"}, {name: "_realDeposit", type: "uint256", value: "500000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "2030000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[12,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[12,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "500000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "30000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "500000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "10000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "500000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[12,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2978834000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6586293", timeStamp: "1540546974", hash: "0x0dbbfbf57c953a2c9175424031e35d87f9750c1f2dd494d8d37e40e2bcdf9a73", nonce: "2", blockHash: "0xa86f533c155b6de8faf33380057fe066e4d639f5dd07450ec2f8d1400c9dc3c3", transactionIndex: "20", from: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "500000000000000000", gas: "300000", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "593784", gasUsed: "58129", confirmations: "1154247"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1540546974 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be"}, {name: "_value", type: "uint256", value: "500000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "currentSenderDeposit", type: "uint256"}, {indexed: false, name: "referrerAdressLength", type: "uint256"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "currentReferrerDeposit", type: "uint256"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_sendBackAmount", type: "uint256"}, {indexed: false, name: "_totalPenalty", type: "uint256"}], name: "LogPenaltyPayment", type: "event"} ;
		console.error( "eventCallOriginal[13,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPenaltyPayment", events: [{name: "_addr", type: "address", value: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be"}, {name: "currentSenderDeposit", type: "uint256", value: "500000000000000000"}, {name: "referrerAdressLength", type: "uint256", value: "20"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "currentReferrerDeposit", type: "uint256", value: "15000000000000000000"}, {name: "_money", type: "uint256", value: "500000000000000000"}, {name: "_sendBackAmount", type: "uint256", value: "450000000000000000"}, {name: "_totalPenalty", type: "uint256", value: "50000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[13,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2978834000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6587418", timeStamp: "1540563201", hash: "0x89e1f7d7a0d7646e1dc78c35af9e30a90b89ba3c9d0387285aa1ad468290ed23", nonce: "1", blockHash: "0x8ba94235031b1efa3461284466c365abfc68dab9a642ffdea9574eafe8f41afd", transactionIndex: "81", from: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "559390", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc", contractAddress: "", cumulativeGasUsed: "5317671", gasUsed: "241986", confirmations: "1153122"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1540563201 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "17405900000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "17388400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_totalReferrals", type: "uint256", value: "15000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[14,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_totalReferrals", type: "uint256", value: "20000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_totalReferrals", type: "uint256", value: "22500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[14,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[14,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}, {name: "_referrer", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "3"}, {name: "_restDepositPerDay", type: "uint256", value: "54636350000000000000"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "250000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[14,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[14,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2500000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[14,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "2162690743800000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6591930", timeStamp: "1540626673", hash: "0x8468a4f67163407811fc7014f51647dfaeb2c6a28d07c412431a7519fe51c720", nonce: "0", blockHash: "0x289b2cef4b5bc4ceb243508a5b0975a12a03a027cdc1eff8f4e3d3d4113286cc", transactionIndex: "54", from: "0x065b44220c91bcfed8cb27d03287cff4b5bfdfc8", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "600000000000000000", gas: "300000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "5054540", gasUsed: "181986", confirmations: "1148610"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "600000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1540626673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x065b44220c91bcfed8cb27d03287cff4b5bfdfc8"}, {name: "_value", type: "uint256", value: "600000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "42000000000000000"}, {name: "_contactBalance", type: "uint256", value: "17973400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "36000000000000000"}, {name: "_contactBalance", type: "uint256", value: "17931400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "88500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "52500000000000000"}, {name: "_amount", type: "uint256", value: "36000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[15,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "929500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "917500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "378300000000000000"}, {name: "_paidReferrals", type: "uint256", value: "364800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[15,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[15,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x065b44220c91bcfed8cb27d03287cff4b5bfdfc8"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "600000000000000000"}, {name: "_nDay", type: "uint256", value: "3"}, {name: "_restDepositPerDay", type: "uint256", value: "54386350000000000000"}, {name: "_realDeposit", type: "uint256", value: "600000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "850000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[15,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[15,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "600000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "36000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "600000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "12000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "600000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "6000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[15,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "2836793155000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6605058", timeStamp: "1540813075", hash: "0x6900712293dd7a25ff64f9f4c9883b51260ebabff39efc8372bfbdaefeed4e8d", nonce: "1", blockHash: "0x9e1d7b063d4f5f9fa7daf683b6f8f41cb215eab73d82e45631668774632f743b", transactionIndex: "56", from: "0xdb7e85a6a4d57afdd72afa3042898109395cf84f", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "800000000000000000", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "2463064", gasUsed: "240554", confirmations: "1135482"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "800000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1540813075 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xdb7e85a6a4d57afdd72afa3042898109395cf84f"}, {name: "_value", type: "uint256", value: "800000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "56000000000000000"}, {name: "_contactBalance", type: "uint256", value: "18695400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "48000000000000000"}, {name: "_contactBalance", type: "uint256", value: "18639400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_amount", type: "uint256", value: "28000000000000000"}, {name: "_contactBalance", type: "uint256", value: "18591400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_amount", type: "uint256", value: "21500000000000000"}, {name: "_contactBalance", type: "uint256", value: "18563400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "136500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "88500000000000000"}, {name: "_amount", type: "uint256", value: "48000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "945500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "917500000000000000"}, {name: "_amount", type: "uint256", value: "28000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "386300000000000000"}, {name: "_paidReferrals", type: "uint256", value: "364800000000000000"}, {name: "_amount", type: "uint256", value: "21500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[16,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xdb7e85a6a4d57afdd72afa3042898109395cf84f"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "800000000000000000"}, {name: "_nDay", type: "uint256", value: "5"}, {name: "_restDepositPerDay", type: "uint256", value: "57963703715000000000"}, {name: "_realDeposit", type: "uint256", value: "800000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "800000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[16,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[16,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "800000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "48000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "800000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "16000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "800000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "8000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[16,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "3060422948000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6611043", timeStamp: "1540897004", hash: "0x22dff1e5924781b8e7f542b5d670e54ac7ec52e55f696a663fb0730bfd9c7870", nonce: "6", blockHash: "0xf18f99a4b7085c439d0710ad252291c0f59e54136b1b808fd7f03e143d08f084", transactionIndex: "9", from: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "165352", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "434804", gasUsed: "63169", confirmations: "1129497"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1540897004 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[17,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[17,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be"}, {name: "_amount", type: "uint256", value: "28000000000000000"}, {name: "_contactBalance", type: "uint256", value: "18541900000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xa5555e2af5bc9444d2c3ccebc2d66b1bdcd5a0be"}, {name: "_totalInteres", type: "uint256", value: "28000000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "28000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "2978834000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6615844", timeStamp: "1540964997", hash: "0x5cb46d1a2441ef15e275457f3e33439afb91a27292613089be1ea977fbc3825f", nonce: "2", blockHash: "0x425b3a8eeaa98ad77907cb123f8c3825a5fdd8b78a85cb89084ac9facd8dc870", transactionIndex: "38", from: "0x78eaf48b9c9ab3a7a57ba04ea4b50f8fa7f97b0e", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "250000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x7a21feddc0eb49e817474727f855682210140a50", contractAddress: "", cumulativeGasUsed: "1787096", gasUsed: "170783", confirmations: "1124696"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1540964997 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x78eaf48b9c9ab3a7a57ba04ea4b50f8fa7f97b0e"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "18763900000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "22800000000000000"}, {name: "_contactBalance", type: "uint256", value: "18746400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "135600000000000000"}, {name: "_paidReferrals", type: "uint256", value: "112800000000000000"}, {name: "_amount", type: "uint256", value: "22800000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[18,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x78eaf48b9c9ab3a7a57ba04ea4b50f8fa7f97b0e"}, {name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "7"}, {name: "_restDepositPerDay", type: "uint256", value: "61493693271243500000"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "250000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[18,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[18,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[18,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "223523088700000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6616264", timeStamp: "1540970785", hash: "0x788772449c1c84bf5d50cd424ef5bf8614da491e66cca9eb3160924ddbe1c4ac", nonce: "1", blockHash: "0xa486bafb6530df0d1577a21472622325bcdcd63f4da10d9e110ccce3f902f22d", transactionIndex: "109", from: "0x02382e890c9865cdce2c28877d356acc4c7a9818", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "2000000000000000000", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "7026924", gasUsed: "226666", confirmations: "1124276"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1540970785 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x02382e890c9865cdce2c28877d356acc4c7a9818"}, {name: "_value", type: "uint256", value: "2000000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "140000000000000000"}, {name: "_contactBalance", type: "uint256", value: "20723600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "120000000000000000"}, {name: "_contactBalance", type: "uint256", value: "20583600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_amount", type: "uint256", value: "40000000000000000"}, {name: "_contactBalance", type: "uint256", value: "20463600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_amount", type: "uint256", value: "20000000000000000"}, {name: "_contactBalance", type: "uint256", value: "20423600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "256500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "136500000000000000"}, {name: "_amount", type: "uint256", value: "120000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "985500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "945500000000000000"}, {name: "_amount", type: "uint256", value: "40000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "406300000000000000"}, {name: "_paidReferrals", type: "uint256", value: "386300000000000000"}, {name: "_amount", type: "uint256", value: "20000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[19,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x02382e890c9865cdce2c28877d356acc4c7a9818"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "2000000000000000000"}, {name: "_nDay", type: "uint256", value: "7"}, {name: "_restDepositPerDay", type: "uint256", value: "61243693271243500000"}, {name: "_realDeposit", type: "uint256", value: "2000000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "2250000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[19,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[19,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "2000000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "120000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "2000000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "40000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "2000000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "20000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[19,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "17345940000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6624623", timeStamp: "1541089472", hash: "0xa1977119f5cbfb6918060935ff172e0d484fb5df8a96b96795c2e5817bd41d81", nonce: "1", blockHash: "0x5f29f14029fd9432ae116a02c75c3d244a8a89c43a675f99e434dff9fe018779", transactionIndex: "91", from: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "2000000000000000000", gas: "300000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "7527080", gasUsed: "242778", confirmations: "1115917"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "2000000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541089472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_value", type: "uint256", value: "2000000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "140000000000000000"}, {name: "_contactBalance", type: "uint256", value: "22403600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "120000000000000000"}, {name: "_contactBalance", type: "uint256", value: "22263600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_amount", type: "uint256", value: "40000000000000000"}, {name: "_contactBalance", type: "uint256", value: "22143600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_amount", type: "uint256", value: "20000000000000000"}, {name: "_contactBalance", type: "uint256", value: "22103600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "376500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "256500000000000000"}, {name: "_amount", type: "uint256", value: "120000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "1025500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "985500000000000000"}, {name: "_amount", type: "uint256", value: "40000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "426300000000000000"}, {name: "_paidReferrals", type: "uint256", value: "406300000000000000"}, {name: "_amount", type: "uint256", value: "20000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[20,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "2000000000000000000"}, {name: "_nDay", type: "uint256", value: "9"}, {name: "_restDepositPerDay", type: "uint256", value: "65238659191462229150"}, {name: "_realDeposit", type: "uint256", value: "2000000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "2000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[20,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[20,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "2000000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "120000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "2000000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "40000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "2000000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "20000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[20,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "1351417727000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6624756", timeStamp: "1541091491", hash: "0xaaa037c90252ee5bb8e8439ad84d1510a888dd7054b1bad18befbce38a0ca385", nonce: "41", blockHash: "0xee4c3496abf7db39cc325cc10175723f9be5efff69b705244bc6e32597cd49a0", transactionIndex: "5", from: "0xa5a07fa8014fd9cca3bfe3dadcdf7c7e605dc493", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "270000000000000000", gas: "300000", gasPrice: "55000000000", isError: "0", txreceipt_status: "1", input: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86", contractAddress: "", cumulativeGasUsed: "367226", gasUsed: "230322", confirmations: "1115784"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "270000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541091491 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[21,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xa5a07fa8014fd9cca3bfe3dadcdf7c7e605dc493"}, {name: "_value", type: "uint256", value: "270000000000000000"}, {name: "_refData", type: "bytes", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[21,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "18900000000000000"}, {name: "_contactBalance", type: "uint256", value: "22353600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}, {name: "_amount", type: "uint256", value: "16200000000000000"}, {name: "_contactBalance", type: "uint256", value: "22334700000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[21,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}, {name: "_totalReferrals", type: "uint256", value: "16200000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "16200000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[21,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[21,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_totalReferrals", type: "uint256", value: "21000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_totalReferrals", type: "uint256", value: "23500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[21,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[21,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xa5a07fa8014fd9cca3bfe3dadcdf7c7e605dc493"}, {name: "_referrer", type: "address", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}, {name: "_money", type: "uint256", value: "270000000000000000"}, {name: "_nDay", type: "uint256", value: "9"}, {name: "_restDepositPerDay", type: "uint256", value: "63238659191462229150"}, {name: "_realDeposit", type: "uint256", value: "270000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "2270000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[21,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[21,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}, {name: "_money", type: "uint256", value: "270000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "16200000000000000"}, {name: "_nextReferrer", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_money", type: "uint256", value: "270000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5400000000000000"}, {name: "_nextReferrer", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}, {name: "_money", type: "uint256", value: "270000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2700000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[21,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "711554025155715719" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6629660", timeStamp: "1541161666", hash: "0x0fa07a9411683c25ecc8c63860061526872b2a2da0aa6bfbb94f0c2c969c4afa", nonce: "2", blockHash: "0x08710de3457f35f371ff097e921e7e2d67eec7a104b3e983f7615073e31d44aa", transactionIndex: "86", from: "0xd4010069ccf3c1b05c03d5178552ea938770dce7", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "500000000000000000", gas: "300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "6115275", gasUsed: "185322", confirmations: "1110880"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541161666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xd4010069ccf3c1b05c03d5178552ea938770dce7"}, {name: "_value", type: "uint256", value: "500000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "35000000000000000"}, {name: "_contactBalance", type: "uint256", value: "22818500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "30000000000000000"}, {name: "_contactBalance", type: "uint256", value: "22783500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "406500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "376500000000000000"}, {name: "_amount", type: "uint256", value: "30000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[22,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "1035500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "1025500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "431300000000000000"}, {name: "_paidReferrals", type: "uint256", value: "426300000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[22,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[22,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xd4010069ccf3c1b05c03d5178552ea938770dce7"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "500000000000000000"}, {name: "_nDay", type: "uint256", value: "9"}, {name: "_restDepositPerDay", type: "uint256", value: "62968659191462229150"}, {name: "_realDeposit", type: "uint256", value: "500000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "2770000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[22,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[22,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "500000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "30000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "500000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "10000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "500000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[22,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "1500757712900000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6630600", timeStamp: "1541174868", hash: "0x48af1aa9e5e3064ea978771942d2cb34ee8cb6ac9f90a36010e32f1a49d5148a", nonce: "138", blockHash: "0xda1538badbe6b14fd0b25075a610419c8f854ead8e008deee6986294754c21b0", transactionIndex: "22", from: "0x9f9e7f57232c9eb54a0afb7ce15286e33a2e733d", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "300000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xa5a07fa8014fd9cca3bfe3dadcdf7c7e605dc493", contractAddress: "", cumulativeGasUsed: "1291129", gasUsed: "245878", confirmations: "1109940"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541174868 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x9f9e7f57232c9eb54a0afb7ce15286e33a2e733d"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0xa5a07fa8014fd9cca3bfe3dadcdf7c7e605dc493"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "23003500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xa5a07fa8014fd9cca3bfe3dadcdf7c7e605dc493"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "22986000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xa5a07fa8014fd9cca3bfe3dadcdf7c7e605dc493"}, {name: "_totalReferrals", type: "uint256", value: "15000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[23,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}, {name: "_totalReferrals", type: "uint256", value: "21200000000000000"}, {name: "_paidReferrals", type: "uint256", value: "16200000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_totalReferrals", type: "uint256", value: "23500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[23,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[23,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x9f9e7f57232c9eb54a0afb7ce15286e33a2e733d"}, {name: "_referrer", type: "address", value: "0xa5a07fa8014fd9cca3bfe3dadcdf7c7e605dc493"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "10"}, {name: "_restDepositPerDay", type: "uint256", value: "67195818967206096024"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "250000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[23,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[23,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xa5a07fa8014fd9cca3bfe3dadcdf7c7e605dc493"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xf09af3cbe324cbfc2c27c7f8c4b01af80b99bc86"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xc3f2668af9f4281d687930e1c94e8f021891541d"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2500000000000000"}, {name: "_nextReferrer", type: "address", value: "0xed0f52911188616c27df1aafeb2cbfd9ee0979c0"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[23,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "7993741459728338075" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6635144", timeStamp: "1541239469", hash: "0xb245ec0d1e78ccff0dd340b400c0964d35bac2173c1aa5c12d1f8fbc7b449be3", nonce: "4", blockHash: "0x504473a082a38bdc9c4884c03f9a12f3babbb920d05f718d33e7750399b38d96", transactionIndex: "43", from: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6157814", gasUsed: "63169", confirmations: "1105396"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541239469 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_amount", type: "uint256", value: "28000000000000000"}, {name: "_contactBalance", type: "uint256", value: "22971000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_totalInteres", type: "uint256", value: "28000000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "28000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "1351417727000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6635698", timeStamp: "1541247153", hash: "0xcf67efa82766bfcaa9c6f28b47421831ce76d171ea3c0641bac174245767e38d", nonce: "1", blockHash: "0x8bef26eb2e7236c47240eb906740f2383a33f565a839d0f49555d8f1fb9a51aa", transactionIndex: "276", from: "0x4a66adf5907f15f43fafc36a84c5d54221b98418", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "373572", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x7a21feddc0eb49e817474727f855682210140a50", contractAddress: "", cumulativeGasUsed: "7438003", gasUsed: "157451", confirmations: "1104842"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541247153 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "23193000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "23175500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[25,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "150600000000000000"}, {name: "_paidReferrals", type: "uint256", value: "135600000000000000"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[25,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[25,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}, {name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "10"}, {name: "_restDepositPerDay", type: "uint256", value: "66945818967206096024"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "500000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[25,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[25,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[25,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "267529040000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6635758", timeStamp: "1541247859", hash: "0x9ad66feccd74406111fece9c4f70f00d054d0b951c0766ccf96ceee264801f74", nonce: "1", blockHash: "0x81c670e78ee89ec0c35f4ea33ecc0b13f2585342005a695b3c2ce9d18f5048e8", transactionIndex: "85", from: "0x1e76dd58faaddc79d31681cca565a1dfe4475c76", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "319579", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x4a66adf5907f15f43fafc36a84c5d54221b98418", contractAddress: "", cumulativeGasUsed: "7244886", gasUsed: "219579", confirmations: "1104782"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1541247859 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x1e76dd58faaddc79d31681cca565a1dfe4475c76"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "23410500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "23393000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}, {name: "_totalReferrals", type: "uint256", value: "15000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[26,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "155600000000000000"}, {name: "_paidReferrals", type: "uint256", value: "150600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[26,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[26,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x1e76dd58faaddc79d31681cca565a1dfe4475c76"}, {name: "_referrer", type: "address", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "10"}, {name: "_restDepositPerDay", type: "uint256", value: "66695818967206096024"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "750000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[26,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[26,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[26,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "52798605000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6637069", timeStamp: "1541266033", hash: "0x2041c57b66c47a90dcdaaa670a68bec0e795a914101a09b5488c0ae1d1b33feb", nonce: "0", blockHash: "0xafd4efcc14dc9f6175d085652f3f1cddbfa69db993dec702c10f0941a55673f9", transactionIndex: "6", from: "0x4f0acc54994bf27baa11d5c24ddaed6920eaf7a7", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "355939", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1e76dd58faaddc79d31681cca565a1dfe4475c76", contractAddress: "", cumulativeGasUsed: "5413138", gasUsed: "246434", confirmations: "1103471"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1541266033 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x4f0acc54994bf27baa11d5c24ddaed6920eaf7a7"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0x1e76dd58faaddc79d31681cca565a1dfe4475c76"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "23628000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x1e76dd58faaddc79d31681cca565a1dfe4475c76"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "23610500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x1e76dd58faaddc79d31681cca565a1dfe4475c76"}, {name: "_totalReferrals", type: "uint256", value: "15000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[27,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}, {name: "_totalReferrals", type: "uint256", value: "20000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "158100000000000000"}, {name: "_paidReferrals", type: "uint256", value: "150600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[27,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[27,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x4f0acc54994bf27baa11d5c24ddaed6920eaf7a7"}, {name: "_referrer", type: "address", value: "0x1e76dd58faaddc79d31681cca565a1dfe4475c76"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "11"}, {name: "_restDepositPerDay", type: "uint256", value: "69211693536222278904"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "250000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[27,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[27,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x1e76dd58faaddc79d31681cca565a1dfe4475c76"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x4a66adf5907f15f43fafc36a84c5d54221b98418"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2500000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[27,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "32753050000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6640206", timeStamp: "1541309817", hash: "0x48adb801a3532ebafcd17cbef206f56690a2cdbc9542b6747d8c2215319a05e5", nonce: "16", blockHash: "0xf0fcefe976067bf866241133b92ee134d0d0d7ebf5c0f8dd50701816c073c3d6", transactionIndex: "89", from: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "384957", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7630843", gasUsed: "63169", confirmations: "1100334"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1541309817 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "2100000000000000000"}, {name: "_contactBalance", type: "uint256", value: "23595500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalInteres", type: "uint256", value: "2100000000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "2100000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "7041091504680778460" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6641409", timeStamp: "1541327063", hash: "0x0531e53514f3200658215fbe462d516c17faf68f967e7382c645b7e47ec5bf46", nonce: "8", blockHash: "0xd8388c5efbd4806e962c3365bc0b23a3c65bf78f22f7707366f329bccb0d7755", transactionIndex: "42", from: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "365352", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2329267", gasUsed: "63169", confirmations: "1099131"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1541327063 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_amount", type: "uint256", value: "166320000000000000"}, {name: "_contactBalance", type: "uint256", value: "21495500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[29,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}, {name: "_totalInteres", type: "uint256", value: "166320000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "166320000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[29,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "918504947000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6641478", timeStamp: "1541328252", hash: "0x30befa1192aef8d2cde912742d85ed19ba481ac1612d260637ef4d738a397b34", nonce: "10", blockHash: "0x8ed6e8a9cbc607f5c65a5af645ad228d1e9ba90bcc00be3e6926c35c7a3b8d79", transactionIndex: "119", from: "0x261b9210962cafb55576168a3d83e6bdcadba2fb", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "365352", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6106419", gasUsed: "63169", confirmations: "1099062"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1541328252 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_amount", type: "uint256", value: "166320000000000000"}, {name: "_contactBalance", type: "uint256", value: "21329180000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalInteres", type: "uint256", value: "166320000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "166320000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "70956698000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6647436", timeStamp: "1541413042", hash: "0x533fa7b1ca3b665e193b1936c0deba608c41c4b457cacba6deed38b2472c74c6", nonce: "44", blockHash: "0x88a9dac47734df46d2bae79ec8cbcf2009878804633b07471a57d8151129d3af", transactionIndex: "109", from: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "300000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x7a21feddc0eb49e817474727f855682210140a50", contractAddress: "", cumulativeGasUsed: "7545437", gasUsed: "173563", confirmations: "1093104"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1541413042 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "21412860000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "22500000000000000"}, {name: "_contactBalance", type: "uint256", value: "21395360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[31,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "173100000000000000"}, {name: "_paidReferrals", type: "uint256", value: "150600000000000000"}, {name: "_amount", type: "uint256", value: "22500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[31,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[31,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "12"}, {name: "_restDepositPerDay", type: "uint256", value: "71288044342308947271"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "250000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[31,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[31,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[31,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "13039335214705966388" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6649169", timeStamp: "1541438212", hash: "0x6032de0a1c5404d9fe19bfcd3f6d948def26e3aa4aa0ec5164b95089d16522bd", nonce: "3", blockHash: "0xdc37c82bd7f4925720f15d285d5e64ce764b20a9d9d76d72b4e8173a8e9f60b2", transactionIndex: "18", from: "0xaeaac442433bdca145678050ad43e082f75a5599", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "343030", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "991173", gasUsed: "223774", confirmations: "1091371"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1541438212 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xaeaac442433bdca145678050ad43e082f75a5599"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "21622860000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "21605360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "21590360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "421500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "406500000000000000"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "1040500000000000000"}, {name: "_paidReferrals", type: "uint256", value: "1025500000000000000"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[32,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "433800000000000000"}, {name: "_paidReferrals", type: "uint256", value: "426300000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[32,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[32,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xaeaac442433bdca145678050ad43e082f75a5599"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "13"}, {name: "_restDepositPerDay", type: "uint256", value: "73426685672578215689"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "250000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[32,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[32,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2500000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[32,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "10696561000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6659400", timeStamp: "1541583729", hash: "0x58b8e1b301fd1d4a0e7769aea2d5d504f243f771f8da2eebeb2c0d3ebf13bc62", nonce: "59", blockHash: "0x4b26d95350a7e59d68b9889616675f48efdd380007caafb44790455c75bd0adb", transactionIndex: "23", from: "0x61ea5720b2fe33a8ad4a5b3b1780b35fe31f2344", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "250000000000000000", gas: "300000", gasPrice: "54000000000", isError: "0", txreceipt_status: "1", input: "0x7a21feddc0eb49e817474727f855682210140a50", contractAddress: "", cumulativeGasUsed: "674313", gasUsed: "174675", confirmations: "1081140"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1541583729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x61ea5720b2fe33a8ad4a5b3b1780b35fe31f2344"}, {name: "_value", type: "uint256", value: "250000000000000000"}, {name: "_refData", type: "bytes", value: "0x7a21feddc0eb49e817474727f855682210140a50"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "17500000000000000"}, {name: "_contactBalance", type: "uint256", value: "21825360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "15000000000000000"}, {name: "_contactBalance", type: "uint256", value: "21807860000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_totalReferrals", type: "uint256", value: "188100000000000000"}, {name: "_paidReferrals", type: "uint256", value: "173100000000000000"}, {name: "_amount", type: "uint256", value: "15000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[33,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x61ea5720b2fe33a8ad4a5b3b1780b35fe31f2344"}, {name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_nDay", type: "uint256", value: "14"}, {name: "_restDepositPerDay", type: "uint256", value: "75629486242755562159"}, {name: "_realDeposit", type: "uint256", value: "250000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "250000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[33,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[33,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_money", type: "uint256", value: "250000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x0000000000000000000000000000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[33,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "15184606951945803915" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6666428", timeStamp: "1541682448", hash: "0xba1f8b70998f5e4cd8448a99421ce42ac51cfaba0eb76b12f40ab380ef7bda24", nonce: "54", blockHash: "0x9faa7b44c52f5a9e96a1612be0c7919d1a0282c4b1dd2bab889c59722bed3db5", transactionIndex: "99", from: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "7725456", gasUsed: "63169", confirmations: "1074112"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1541682448 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_amount", type: "uint256", value: "10500000000000000"}, {name: "_contactBalance", type: "uint256", value: "21792860000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_totalInteres", type: "uint256", value: "10500000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "10500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "13039335214705966388" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6670502", timeStamp: "1541740465", hash: "0x90bd47a5676bbce0d1d07af4ec9de7edfb3edb7a52271ae5958a70dab7434e20", nonce: "8", blockHash: "0xf5dfd9d7b41262fdbeeab5b6093790cbce78f9799201f82651ada505cbe6d334", transactionIndex: "118", from: "0xba659ae227f026f7cf7e148918c116b3299db8bf", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "849570", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5507899", gasUsed: "63169", confirmations: "1070038"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1541740465 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_amount", type: "uint256", value: "45500000000000000"}, {name: "_contactBalance", type: "uint256", value: "21782360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[35,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}, {name: "_totalInteres", type: "uint256", value: "45500000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "45500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[35,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "10029438300000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6670542", timeStamp: "1541740962", hash: "0xaa5d8ab211565a4716beb457e02529856addd92237ba99d0ac4ec927018fa5d2", nonce: "3", blockHash: "0x60f537760c24d10f738e79e59589216b414313043061272f907ee28b4a25bd02", transactionIndex: "71", from: "0x9c53360622306b4b1b19ee118b530501c0f4c822", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "849570", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6834763", gasUsed: "63169", confirmations: "1069998"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1541740962 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_amount", type: "uint256", value: "45500000000000000"}, {name: "_contactBalance", type: "uint256", value: "21736860000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[36,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_totalInteres", type: "uint256", value: "45500000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "45500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[36,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "11676956200000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6670562", timeStamp: "1541741220", hash: "0x6123883d917bdb102b337b48409e78da4a52e5e51cb8165678387421cf797886", nonce: "3", blockHash: "0x96d75cf2cfcfccaab2f370dad50a467da8bf446aab525498ae8f38ec6a9eb672", transactionIndex: "109", from: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "849570", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6764365", gasUsed: "63169", confirmations: "1069978"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1541741220 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_amount", type: "uint256", value: "45500000000000000"}, {name: "_contactBalance", type: "uint256", value: "21691360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[37,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_totalInteres", type: "uint256", value: "45500000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "45500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[37,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "2428444914700000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6670596", timeStamp: "1541741684", hash: "0x228ff23cb6b9f5a634f3b086abb5c9613061883b891a2fb76bfb55bc22b738e8", nonce: "3", blockHash: "0xe2d35a79bc3e612c8a4e06b85d87a3db05d15c0e66d5caab6f2aa767ed1a786d", transactionIndex: "123", from: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "849570", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5967599", gasUsed: "63169", confirmations: "1069944"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1541741684 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}, {name: "_amount", type: "uint256", value: "45500000000000000"}, {name: "_contactBalance", type: "uint256", value: "21645860000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[38,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}, {name: "_totalInteres", type: "uint256", value: "45500000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "45500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[38,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "2182637757900000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6670994", timeStamp: "1541747501", hash: "0x61a8e09717003053293291c2048a4a5ffbd37d929ccf3f6d81b9072a82d1bd94", nonce: "3", blockHash: "0x824ebfef6bd7270379b72bd621a6531425923af0f76c28a968845141ead157dd", transactionIndex: "133", from: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "12000000000000000000", gas: "55939", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4883802", gasUsed: "40805", confirmations: "1069546"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "12000000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1541747501 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c"}, {name: "_value", type: "uint256", value: "12000000000000000000"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "currentSenderDeposit", type: "uint256"}, {indexed: false, name: "referrerAdressLength", type: "uint256"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "currentReferrerDeposit", type: "uint256"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_sendBackAmount", type: "uint256"}, {indexed: false, name: "_totalPenalty", type: "uint256"}], name: "LogPenaltyPayment", type: "event"} ;
		console.error( "eventCallOriginal[39,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPenaltyPayment", events: [{name: "_addr", type: "address", value: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c"}, {name: "currentSenderDeposit", type: "uint256", value: "0"}, {name: "referrerAdressLength", type: "uint256", value: "0"}, {name: "_referrer", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "currentReferrerDeposit", type: "uint256", value: "0"}, {name: "_money", type: "uint256", value: "12000000000000000000"}, {name: "_sendBackAmount", type: "uint256", value: "10800000000000000000"}, {name: "_totalPenalty", type: "uint256", value: "1250000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[39,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "19016495859900000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6671049", timeStamp: "1541748280", hash: "0x317ec533ea47cad4e783e43571774e2dde194d9c3763ac4afc0398a2760a157d", nonce: "4", blockHash: "0xe70e2bb0219546fd4065231b5d16ea8af6a59364d6a02b942a4808b1c86b4ce7", transactionIndex: "138", from: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "10800000000000000000", gas: "559390", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54", contractAddress: "", cumulativeGasUsed: "7358472", gasUsed: "291670", confirmations: "1069491"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "10800000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1541748280 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[40,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c"}, {name: "_value", type: "uint256", value: "10800000000000000000"}, {name: "_refData", type: "bytes", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[40,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "756000000000000000"}, {name: "_contactBalance", type: "uint256", value: "33600360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}, {name: "_amount", type: "uint256", value: "648000000000000000"}, {name: "_contactBalance", type: "uint256", value: "32844360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_amount", type: "uint256", value: "216000000000000000"}, {name: "_contactBalance", type: "uint256", value: "32196360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_amount", type: "uint256", value: "113000000000000000"}, {name: "_contactBalance", type: "uint256", value: "31980360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}, {name: "_totalReferrals", type: "uint256", value: "648000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "648000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_totalReferrals", type: "uint256", value: "231000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15000000000000000"}, {name: "_amount", type: "uint256", value: "216000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_totalReferrals", type: "uint256", value: "128000000000000000"}, {name: "_paidReferrals", type: "uint256", value: "15000000000000000"}, {name: "_amount", type: "uint256", value: "113000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[40,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c"}, {name: "_referrer", type: "address", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}, {name: "_money", type: "uint256", value: "10800000000000000000"}, {name: "_nDay", type: "uint256", value: "16"}, {name: "_restDepositPerDay", type: "uint256", value: "80235321954939375893"}, {name: "_realDeposit", type: "uint256", value: "10800000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "10800000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[40,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[40,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x05f52d5f2dcd75c1fc5b389fa54ad0e3e2ba7e54"}, {name: "_money", type: "uint256", value: "10800000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "648000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_money", type: "uint256", value: "10800000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "216000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x9c53360622306b4b1b19ee118b530501c0f4c822"}, {name: "_money", type: "uint256", value: "10800000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "108000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xba659ae227f026f7cf7e148918c116b3299db8bf"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[40,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "19016495859900000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6686614", timeStamp: "1541967742", hash: "0x8cde4a6482b7958901dca3113d95e089e08b0c0f72469687b2acf28f2eb9a872", nonce: "61", blockHash: "0x3a2556194f48ed94c47e7807e2bbac907a78937364a1a76ebe247834877d1c66", transactionIndex: "29", from: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "300000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1821841", gasUsed: "48169", confirmations: "1053926"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1541967742 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_amount", type: "uint256", value: "10500000000000000"}, {name: "_contactBalance", type: "uint256", value: "31867360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_totalInteres", type: "uint256", value: "21000000000000000"}, {name: "_paidInteres", type: "uint256", value: "10500000000000000"}, {name: "_amount", type: "uint256", value: "10500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "13039335214705966388" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6690364", timeStamp: "1542021300", hash: "0xe811577c3913fb12d3b24c707a0a1528cbadba4677d8d005a01a20302254de05", nonce: "2", blockHash: "0xc0bedc01f72a91a81178b52f50dcc86b083c4d018acc1da34d971e551b69cf04", transactionIndex: "120", from: "0xe0d6772fc01f7a4e571f1a4ead3b94ca43a22e71", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "260000000000000000", gas: "300000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "5155990", gasUsed: "205882", confirmations: "1050176"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "260000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542021300 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xe0d6772fc01f7a4e571f1a4ead3b94ca43a22e71"}, {name: "_value", type: "uint256", value: "260000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "18200000000000000"}, {name: "_contactBalance", type: "uint256", value: "32116860000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "15600000000000000"}, {name: "_contactBalance", type: "uint256", value: "32098660000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "437100000000000000"}, {name: "_paidReferrals", type: "uint256", value: "421500000000000000"}, {name: "_amount", type: "uint256", value: "15600000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}], name: "LogSkipPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[42,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "1045700000000000000"}, {name: "_paidReferrals", type: "uint256", value: "1040500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogSkipPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "436400000000000000"}, {name: "_paidReferrals", type: "uint256", value: "426300000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[42,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[42,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0xe0d6772fc01f7a4e571f1a4ead3b94ca43a22e71"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_nDay", type: "uint256", value: "19"}, {name: "_restDepositPerDay", type: "uint256", value: "87675302653855039400"}, {name: "_realDeposit", type: "uint256", value: "260000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "260000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[42,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[42,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "15600000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "5200000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "260000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "2600000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[42,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "724598679000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6690572", timeStamp: "1542024340", hash: "0x8c73b7d3c4b8204c4e6cdb1ffb7abbe82610205bb134e8ca38f058514ba78e39", nonce: "38", blockHash: "0xfaf21ce65a4d1c1c212245b54f30bc84a0d570915c2e5d11f6c21ff73f97f8dc", transactionIndex: "58", from: "0x386f506e05704401b3769ff818dbd6c80f3ba3ca", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "1000000000000000000", gas: "300000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d", contractAddress: "", cumulativeGasUsed: "4202658", gasUsed: "233338", confirmations: "1049968"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542024340 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x386f506e05704401b3769ff818dbd6c80f3ba3ca"}, {name: "_value", type: "uint256", value: "1000000000000000000"}, {name: "_refData", type: "bytes", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7a21feddc0eb49e817474727f855682210140a50"}, {name: "_amount", type: "uint256", value: "70000000000000000"}, {name: "_contactBalance", type: "uint256", value: "33083060000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_amount", type: "uint256", value: "60000000000000000"}, {name: "_contactBalance", type: "uint256", value: "33013060000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_amount", type: "uint256", value: "25200000000000000"}, {name: "_contactBalance", type: "uint256", value: "32953060000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_amount", type: "uint256", value: "20100000000000000"}, {name: "_contactBalance", type: "uint256", value: "32927860000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalReferrals", type: "uint256"}, {indexed: false, name: "_paidReferrals", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePaymentReferrer", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_totalReferrals", type: "uint256", value: "497100000000000000"}, {name: "_paidReferrals", type: "uint256", value: "437100000000000000"}, {name: "_amount", type: "uint256", value: "60000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_totalReferrals", type: "uint256", value: "1065700000000000000"}, {name: "_paidReferrals", type: "uint256", value: "1040500000000000000"}, {name: "_amount", type: "uint256", value: "25200000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogPreparePaymentReferrer", events: [{name: "_addr", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_totalReferrals", type: "uint256", value: "446400000000000000"}, {name: "_paidReferrals", type: "uint256", value: "426300000000000000"}, {name: "_amount", type: "uint256", value: "20100000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_nDay", type: "uint256"}, {indexed: false, name: "_restDepositPerDay", type: "uint256"}, {indexed: false, name: "_realDeposit", type: "uint256"}, {indexed: false, name: "_usedDepositPerDay", type: "uint256"}], name: "LogUsedRestDepositPerDay", type: "event"} ;
		console.error( "eventCallOriginal[43,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogUsedRestDepositPerDay", events: [{name: "_addr", type: "address", value: "0x386f506e05704401b3769ff818dbd6c80f3ba3ca"}, {name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "1000000000000000000"}, {name: "_nDay", type: "uint256", value: "19"}, {name: "_restDepositPerDay", type: "uint256", value: "87415302653855039400"}, {name: "_realDeposit", type: "uint256", value: "1000000000000000000"}, {name: "_usedDepositPerDay", type: "uint256", value: "1260000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[43,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_referrer", type: "address"}, {indexed: false, name: "_money", type: "uint256"}, {indexed: false, name: "_index", type: "uint256"}, {indexed: false, name: "_bonusReferrer", type: "uint256"}, {indexed: false, name: "_amountReferrer", type: "uint256"}, {indexed: false, name: "_nextReferrer", type: "address"}], name: "LogCalcBonusReferrer", type: "event"} ;
		console.error( "eventCallOriginal[43,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x7efe4672ffc7db035b0aa22c2f48d7fc7376608d"}, {name: "_money", type: "uint256", value: "1000000000000000000"}, {name: "_index", type: "uint256", value: "0"}, {name: "_bonusReferrer", type: "uint256", value: "600"}, {name: "_amountReferrer", type: "uint256", value: "60000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0xdc8862dfccf67f50eb755e16f27e560fcab4fefd"}, {name: "_money", type: "uint256", value: "1000000000000000000"}, {name: "_index", type: "uint256", value: "1"}, {name: "_bonusReferrer", type: "uint256", value: "200"}, {name: "_amountReferrer", type: "uint256", value: "20000000000000000"}, {name: "_nextReferrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}, {name: "LogCalcBonusReferrer", events: [{name: "_referrer", type: "address", value: "0x261b9210962cafb55576168a3d83e6bdcadba2fb"}, {name: "_money", type: "uint256", value: "1000000000000000000"}, {name: "_index", type: "uint256", value: "2"}, {name: "_bonusReferrer", type: "uint256", value: "100"}, {name: "_amountReferrer", type: "uint256", value: "10000000000000000"}, {name: "_nextReferrer", type: "address", value: "0xf433e0ec467b3d96ca14b5c8619428130a5a9503"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[43,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "0" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6690819", timeStamp: "1542027641", hash: "0x055f227d897973e5420c0f5243a00c2851312b268757bc590b3ce70f52b22b63", nonce: "4", blockHash: "0x1008b280e2affc5f6443c172d228012155971b74f590f74d89384e76a960bb63", transactionIndex: "167", from: "0x065b44220c91bcfed8cb27d03287cff4b5bfdfc8", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "300000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "6703771", gasUsed: "63169", confirmations: "1049721"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542027641 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0x065b44220c91bcfed8cb27d03287cff4b5bfdfc8"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0x065b44220c91bcfed8cb27d03287cff4b5bfdfc8"}, {name: "_amount", type: "uint256", value: "134400000000000000"}, {name: "_contactBalance", type: "uint256", value: "32907760000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0x065b44220c91bcfed8cb27d03287cff4b5bfdfc8"}, {name: "_totalInteres", type: "uint256", value: "134400000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "134400000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "2836793155000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6698754", timeStamp: "1542139778", hash: "0x69ecbc39b7020905a874263d05a7911a76570ebb03099c8f2ca9a14266b3b727", nonce: "7", blockHash: "0x89b845c20e004fd95e2ceb6f198ffb5b2d74eb0d69d03138c3715c31abe140d6", transactionIndex: "48", from: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2282745", gasUsed: "48169", confirmations: "1041786"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542139778 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_amount", type: "uint256", value: "308000000000000000"}, {name: "_contactBalance", type: "uint256", value: "32773360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_totalInteres", type: "uint256", value: "336000000000000000"}, {name: "_paidInteres", type: "uint256", value: "28000000000000000"}, {name: "_amount", type: "uint256", value: "308000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "1351417727000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6704149", timeStamp: "1542216378", hash: "0x3aa5ad474202bfe7914cbba1d8a2f0d63d0514082713a5b813ac3e6a2216b790", nonce: "66", blockHash: "0xa28be274bdbe921587d91e35b1887f051f1f8c1d72b446d9e540d2d6ecc63a7b", transactionIndex: "47", from: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2288104", gasUsed: "48169", confirmations: "1036391"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542216378 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[46,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[46,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_amount", type: "uint256", value: "10500000000000000"}, {name: "_contactBalance", type: "uint256", value: "32465360000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xabd1ead4c68c4adc0fb530d7d969a8eca2cde308"}, {name: "_totalInteres", type: "uint256", value: "31500000000000000"}, {name: "_paidInteres", type: "uint256", value: "21000000000000000"}, {name: "_amount", type: "uint256", value: "10500000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "13039335214705966388" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6712993", timeStamp: "1542341035", hash: "0x73d3ee7eea1130da70964df6be04742730ecb5fd1a5f2bea60926a6796657556", nonce: "6", blockHash: "0x800730074313c553ec7a7a0fef292e9b169fe8cadf0fc566f805b90b1270a08b", transactionIndex: "55", from: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2644112", gasUsed: "63169", confirmations: "1027547"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542341035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c"}, {name: "_amount", type: "uint256", value: "907200000000000000"}, {name: "_contactBalance", type: "uint256", value: "32454860000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xe61f129697a34ca51d73ce51d6f73f127b23f68c"}, {name: "_totalInteres", type: "uint256", value: "907200000000000000"}, {name: "_paidInteres", type: "uint256", value: "0"}, {name: "_amount", type: "uint256", value: "907200000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "19016495859900000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6714657", timeStamp: "1542363917", hash: "0x726eb898789345fd11f13f5666a771e8fb0bcf48d05a78907f2af550fd4b9d69", nonce: "6", blockHash: "0x557f38e545a693fa94fcbeaaacb134a631b5719ecfdef2111768432e89d98178", transactionIndex: "45", from: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5440076", gasUsed: "48169", confirmations: "1025883"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542363917 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_amount", type: "uint256", value: "28000000000000000"}, {name: "_contactBalance", type: "uint256", value: "31547660000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xe821c7322f727fedd0cc2d69fac48289fae1b8bc"}, {name: "_totalInteres", type: "uint256", value: "73500000000000000"}, {name: "_paidInteres", type: "uint256", value: "45500000000000000"}, {name: "_amount", type: "uint256", value: "28000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "2428444914700000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6729306", timeStamp: "1542570720", hash: "0xd3476237b4a6267d58ec149e62952d058657ffcc21d9b13cfbaaa075a9f664df", nonce: "10", blockHash: "0x96e9c948f23b6999c8bb5d60f2f718959013a7d1a9c2703bf5dfa50ba1a56f4a", transactionIndex: "65", from: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878", to: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5", value: "0", gas: "300000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5261052", gasUsed: "48169", confirmations: "1011234"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542570720 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_value", type: "uint256"}, {indexed: false, name: "_refData", type: "bytes"}], name: "LogInvestment", type: "event"} ;
		console.error( "eventCallOriginal[49,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "LogInvestment", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_value", type: "uint256", value: "0"}, {name: "_refData", type: "bytes", value: "0x"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[49,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_amount", type: "uint256"}, {indexed: false, name: "_contactBalance", type: "uint256"}], name: "LogTransfer", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogTransfer", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_amount", type: "uint256", value: "140000000000000000"}, {name: "_contactBalance", type: "uint256", value: "31519660000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_addr", type: "address"}, {indexed: false, name: "_totalInteres", type: "uint256"}, {indexed: false, name: "_paidInteres", type: "uint256"}, {indexed: false, name: "_amount", type: "uint256"}], name: "LogPreparePayment", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogPreparePayment", events: [{name: "_addr", type: "address", value: "0xa74aec9daeb2ef2acb659aab5bee289314b4a878"}, {name: "_totalInteres", type: "uint256", value: "476000000000000000"}, {name: "_paidInteres", type: "uint256", value: "336000000000000000"}, {name: "_amount", type: "uint256", value: "140000000000000000"}], address: "0xab0b48266f362f82c9226b1ca5fb2c8b07ad01a5"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "1351417727000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "1542100000000000000" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
