const KYCCrowdsale = artifacts.require( "./KYCCrowdsale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "KYCCrowdsale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x8ac03A3304519879e2Ddb114c2Eb2163043AB4B0", "0x083f24C0E1220179Da4a752363871f3a88479624", "0xCA0e7269600d353F70b14Ad118A49575455C0f2f", "0x71e01346e052C13B386e4baAA3070b6517304eD4", "0x519c5DcAa311Ca31009A3fcC7E03F7B24A55Ff42", "0x65CC2557A3f041728085343dc8eC5cE2eC11C834", "0xDA60A8bBdF59e60d344781c6fd531adc429A6644", "0x9cC9c3de8e710781983a65b90B7efEaaD2D3D7D8", "0x8B9efa58B9f1FFd33032Cd7E68d5F2dC9fB03C0f", "0x16c69f351aAdC768f73c2673c02431efBFb2E33f", "0xa39c41822dA7Ac313A6cA84157525A3BaADcFf7f", "0x1B3B08371b071fA46F8Ed489a53ba81422D44fe8", "0xADAeC55A84D03bcAf5030cfA6DA242Dd11c52a12", "0x4376F30bf747BB115549Da88e879A33069B12B0E", "0x6a2F9F2a88E945956dfd8e74be26Bc5911374151", "0x6fd8f3CFdD99953Eb489596deDc5Eb3e0ec42499", "0x97F31237cfD2C0aE415feEEc78FB527f081ee065", "0x9fa3AFD7068583048c23cA49A637007fAfCE8819", "0xd3AC35FD0fc81687E5EA21880A7DFd0eD506949d", "0x57Dc45C77fDbef96DD369D85aB1380cDFe2800F1", "0x946775d90D0CF9D7a219160428C1cF9b1042a74C", "0x82EAc4f99b1a1a5Ca7a074A9339e39dffdde2Fd5", "0xe3f4F251CB553F9321d711cE32669af32C3e2a09", "0x5a22Dfbcb53C7F75f99ab4eF24A8C97cEefb1037", "0xBD6A8ccA8d7e3Aa526B929De4B97c89260Ec9e86", "0xc7B060925c4cF46f1F1a4CC1402B1C0c6E7A502a", "0x0fd91f04D342ce20293FbC6A93117ABa72e20c01", "0xE337f2592aca17509C487B5B0A0638d1277F4a3C", "0xF67fc8284747D0dcc11525b987CF1c7075b3d145", "0x51213d7e84e29DB099E7a81E54F9dFd34d9CFA36", "0x87Af85a2DF9638005CCd5d87C22eF5489FE101CC", "0xeBE87Ba8Cd704b70055A40c229068934477Da077"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "ownerTestValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isPricingSane", outputs: [{name: "sane", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "endsAt", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minimumFundingGoal", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getState", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "investedAmountOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "finalizeAgent", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "beneficiary", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isCrowdsale", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "testState", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "signerAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "weiRefunded", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MAX_INVESTMENTS_BEFORE_MULTISIG_CHANGE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "dataframe", type: "bytes"}], name: "getKYCPayload", outputs: [{name: "whitelistedAddress", type: "address"}, {name: "customerId", type: "uint128"}, {name: "minEth", type: "uint32"}, {name: "maxEth", type: "uint32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "pricingStrategy", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "loadedRefund", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isMinimumGoalReached", outputs: [{name: "reached", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "multisigWallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "tokenAmountOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "weiAmount", type: "uint256"}, {name: "tokenAmount", type: "uint256"}, {name: "weiRaisedTotal", type: "uint256"}, {name: "tokensSoldTotal", type: "uint256"}], name: "isBreakingCap", outputs: [{name: "limitBroken", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isFinalizerSane", outputs: [{name: "sane", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startsAt", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "finalized", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "earlyParticipantWhitelist", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isCrowdsaleFull", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getTokensLeft", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "presaleWeiRaised", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "signer", type: "address"}], name: "SignerChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}], name: "Refund", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newRequireCustomerId", type: "bool"}, {indexed: false, name: "newRequiredSignedAddress", type: "bool"}, {indexed: false, name: "newSignerAddress", type: "address"}], name: "InvestmentPolicyChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newEndsAt", type: "uint256"}], name: "EndsAtChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["SignerChanged(address)", "Invested(address,uint256,uint256,uint128)", "Refund(address,uint256)", "InvestmentPolicyChanged(bool,bool,address)", "Whitelisted(address,bool)", "EndsAtChanged(uint256)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x5719a5656c5cfdaafa148ecf366fd3b0a7fae06449ce2a46225977fb7417e29d", "0x0396f60aaad038749091d273dc13aaabc63db6e2271c7bad442d5cf25cc43350", "0xbb28353e4598c3b9199101a66e0989549b659a59a54d2c27fbb183f1932c8e6d", "0x48d826081348f5f00e8a33c9ae8ce89ed4c6e88400b585a478bc203d9e8177d3", "0xa54714518c5d275fdcd3d2a461e4858e4e8cb04fb93cd0bca9d6d34115f26440", "0xd34bb772c4ae9baa99db852f622773b31c7827e8ee818449fef20d30980bd310", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4527663 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4720407 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}, {type: "address", name: "_pricingStrategy", value: 5}, {type: "address", name: "_multisigWallet", value: 6}, {type: "uint256", name: "_start", value: "1510592400"}, {type: "uint256", name: "_end", value: "1514739600"}, {type: "uint256", name: "_minimumFundingGoal", value: "1"}, {type: "address", name: "_beneficiary", value: 3}], name: "KYCCrowdsale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "ownerTestValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerTestValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isPricingSane", outputs: [{name: "sane", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isPricingSane()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "endsAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endsAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimumFundingGoal", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimumFundingGoal()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "investedAmountOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investedAmountOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finalizeAgent", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalizeAgent()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "beneficiary", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "beneficiary()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isCrowdsale", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isCrowdsale()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "tokensSold", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokensSold()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "testState", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "testState()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "signerAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "signerAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "weiRefunded", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "weiRefunded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_INVESTMENTS_BEFORE_MULTISIG_CHANGE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_INVESTMENTS_BEFORE_MULTISIG_CHANGE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getKYCPayload", outputs: [{name: "whitelistedAddress", type: "address"}, {name: "customerId", type: "uint128"}, {name: "minEth", type: "uint32"}, {name: "maxEth", type: "uint32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getKYCPayload(bytes)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "pricingStrategy", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "pricingStrategy()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "loadedRefund", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "loadedRefund()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isMinimumGoalReached", outputs: [{name: "reached", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isMinimumGoalReached()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "multisigWallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "multisigWallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "tokenAmountOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenAmountOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "weiAmount", value: random.range( maxRandom )}, {type: "uint256", name: "tokenAmount", value: random.range( maxRandom )}, {type: "uint256", name: "weiRaisedTotal", value: random.range( maxRandom )}, {type: "uint256", name: "tokensSoldTotal", value: random.range( maxRandom )}], name: "isBreakingCap", outputs: [{name: "limitBroken", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isBreakingCap(uint256,uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value,methodCall.inputs[ 3 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isFinalizerSane", outputs: [{name: "sane", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isFinalizerSane()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startsAt", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startsAt()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finalized", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finalized()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "halted", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "halted()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "earlyParticipantWhitelist", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "earlyParticipantWhitelist(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isCrowdsaleFull", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isCrowdsaleFull()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "investorCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "investorCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTokensLeft", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokensLeft()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "presaleWeiRaised", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "presaleWeiRaised()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "KYCCrowdsale", function( accounts ) {

	it( "TEST: KYCCrowdsale( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4527663", timeStamp: "1510338853", hash: "0x29a6f03d091cf7741e1f89eed675ca9f73d739a20d615ceb6abb0e2c094f6fba", nonce: "11", blockHash: "0x49757722d77bd835eba77821f8452f414126670504b846853be1638633c5917b", transactionIndex: "54", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: 0, value: "0", gas: "2782614", gasPrice: "4800000000", isError: "0", txreceipt_status: "1", input: "0xcd0412d7000000000000000000000000ca0e7269600d353f70b14ad118a49575455c0f2f00000000000000000000000071e01346e052c13b386e4baaa3070b6517304ed4000000000000000000000000519c5dcaa311ca31009a3fcc7e03f7b24a55ff42000000000000000000000000000000000000000000000000000000005a09cf90000000000000000000000000000000000000000000000000000000005a4917900000000000000000000000000000000000000000000000000000000000000001000000000000000000000000083f24c0e1220179da4a752363871f3a88479624", contractAddress: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", cumulativeGasUsed: "5349199", gasUsed: "2682614", confirmations: "3209990"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}, {type: "address", name: "_pricingStrategy", value: addressList[5]}, {type: "address", name: "_multisigWallet", value: addressList[6]}, {type: "uint256", name: "_start", value: "1510592400"}, {type: "uint256", name: "_end", value: "1514739600"}, {type: "uint256", name: "_minimumFundingGoal", value: "1"}, {type: "address", name: "_beneficiary", value: addressList[3]}], name: "KYCCrowdsale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = KYCCrowdsale.new( addressList[4], addressList[5], addressList[6], "1510592400", "1514739600", "1", addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510338853 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = KYCCrowdsale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setFinalizeAgent( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4527677", timeStamp: "1510339056", hash: "0xdcd7bedf9e3d26d93803a11b491b98fd45b5e897494b587deceadd76c1e3f287", nonce: "17", blockHash: "0xbff9f1d6a2ca089c4ae8f20f790d092b813aaf1b7e95219cbe275e01fce1f4da", transactionIndex: "90", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "145537", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x19b667da00000000000000000000000065cc2557a3f041728085343dc8ec5ce2ec11c834", contractAddress: "", cumulativeGasUsed: "4300913", gasUsed: "45537", confirmations: "3209976"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[7]}], name: "setFinalizeAgent", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setFinalizeAgent(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510339056 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setSignerAddress( addressList[8] )", async function( ) {
		const txOriginal = {blockNumber: "4527678", timeStamp: "1510339058", hash: "0xd10de512b76ec0dddf2fc365404feaaa76d4e0dcce07be13407d4d4b898833e6", nonce: "18", blockHash: "0xa5324b02a222ae3a221fdca6c672aaad4f3cd55464576db3e8579135210c0c0f", transactionIndex: "10", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "144733", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x046dc166000000000000000000000000da60a8bbdf59e60d344781c6fd531adc429a6644", contractAddress: "", cumulativeGasUsed: "421391", gasUsed: "44733", confirmations: "3209975"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_signerAddress", value: addressList[8]}], name: "setSignerAddress", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setSignerAddress(address)" ]( addressList[8], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510339058 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "signer", type: "address"}], name: "SignerChanged", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "SignerChanged", events: [{name: "signer", type: "address", value: "0xda60a8bbdf59e60d344781c6fd531adc429a6644"}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setEarlyParicipantWhitelist( addressList[3], true )", async function( ) {
		const txOriginal = {blockNumber: "4527679", timeStamp: "1510339069", hash: "0xf7689b0ecadd25ea895d411ead6c82798b4ac0236f9f414542996219007bc794", nonce: "21", blockHash: "0x6cf28122098943e4eeb4a08bad998095a9ca292f6f89c72b1c2df5d4428c06c8", transactionIndex: "125", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "146193", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xeac24932000000000000000000000000083f24c0e1220179da4a752363871f3a884796240000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "4053394", gasUsed: "46193", confirmations: "3209974"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[3]}, {type: "bool", name: "status", value: true}], name: "setEarlyParicipantWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEarlyParicipantWhitelist(address,bool)" ]( addressList[3], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510339069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"} ;
		console.error( "eventCallOriginal[3,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Whitelisted", events: [{name: "addr", type: "address", value: "0x083f24c0e1220179da4a752363871f3a88479624"}, {name: "status", type: "bool", value: true}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[3,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x\", \"0\", \"0x000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4527769", timeStamp: "1510340193", hash: "0x54e2c19203d820e2c57bfafb91dbf77d154d0347e597ea56a095d9df783ead12", nonce: "22", blockHash: "0x14925bbcc9f3d2b03f6bbb61a6751230c73de55131201e0bcb2f2b63f774b4cb", transactionIndex: "29", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "10000000000000000", gas: "2111333", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1084978", gasUsed: "189343", confirmations: "3209884"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x"}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x", "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510340193 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x083f24c0e1220179da4a752363871f3a88479624"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "38381199999999940981"}, {name: "customerId", type: "uint128", value: {s: 1, e: 3, c: [4096]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x9cc9c3de8e710781983a65b90b7efeaad2d3... )", async function( ) {
		const txOriginal = {blockNumber: "4564164", timeStamp: "1510845592", hash: "0x1a0f53e978a76bb7cd2689dcfbe252760aa435e1ed4de4612598432017677011", nonce: "163", blockHash: "0x6b80f33f3cc0f2541ce7e1c522566589e798c4e873ee1adfcb807936caae950e", transactionIndex: "8", from: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "100000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001ce60ad5711a97ca54a227cf3f954da91448a76b927e457918a8aa4ea7472212da09020c909cae41ed24c797f97badd477a487b3715d69bad601b2c8499616cbb2000000000000000000000000000000000000000000000000000000000000002c9cc9c3de8e710781983a65b90b7efeaad2d3d7d84bf67df4230c4560a98049473d56b84c000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "603157", gasUsed: "214974", confirmations: "3173489"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d84bf67df4230c4560a98049473d56b84c000000a702fd7db8"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xe60ad5711a97ca54a227cf3f954da91448a76b927e457918a8aa4ea7472212da"}, {type: "bytes32", name: "s", value: "0x09020c909cae41ed24c797f97badd477a487b3715d69bad601b2c8499616cbb2"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d84bf67df4230c4560a98049473d56b84c000000a702fd7db8", "28", "0xe60ad5711a97ca54a227cf3f954da91448a76b927e457918a8aa4ea7472212da", "0x09020c909cae41ed24c797f97badd477a487b3715d69bad601b2c8499616cbb2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510845592 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8"}, {name: "weiAmount", type: "uint256", value: "100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "383811999999999409819"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10097195935, 47871780836764, 42645998516300]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "1404117226066867295" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setPricingStrategy( addressList[10] )", async function( ) {
		const txOriginal = {blockNumber: "4600904", timeStamp: "1511357323", hash: "0x3b62ff2d90fe53f9340bf5a9f209761955c63316105a7de5cd167f77586a2e44", nonce: "28", blockHash: "0x7b793eb2f447486df98b1189e988443592959a3aa1559735f1881eb0ea4e41f4", transactionIndex: "90", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "130687", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x50c677340000000000000000000000008b9efa58b9f1ffd33032cd7e68d5f2dc9fb03c0f", contractAddress: "", cumulativeGasUsed: "2573743", gasUsed: "30687", confirmations: "3136749"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pricingStrategy", value: addressList[10]}], name: "setPricingStrategy", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPricingStrategy(address)" ]( addressList[10], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1511357323 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x\", \"0\", \"0x000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4600909", timeStamp: "1511357386", hash: "0x248049c09733a29fcf10c7c6ddc7c111fd73a41a2a7211dd8fbbfb983072eb24", nonce: "29", blockHash: "0xe8cd22fa1611abc703c4b6591dfbd9008226403e679c158fc7d0900be7ee11cd", transactionIndex: "56", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "10000000000000000", gas: "2111333", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2356530", gasUsed: "122052", confirmations: "3136744"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x"}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x", "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1511357386 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x083f24c0e1220179da4a752363871f3a88479624"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "37972999999999965581"}, {name: "customerId", type: "uint128", value: {s: 1, e: 3, c: [4096]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setPricingStrategy( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4606390", timeStamp: "1511432649", hash: "0x7488822db8ae54e453ca5df6a322cd22883b02784d21d7609f011b60953b34d8", nonce: "30", blockHash: "0xdbe8e7a3bda63d7373cbb5e6846f294a80068d14e42fef49881ad07c9e8c226f", transactionIndex: "44", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "130687", gasPrice: "18150000000", isError: "0", txreceipt_status: "1", input: "0x50c6773400000000000000000000000071e01346e052c13b386e4baaa3070b6517304ed4", contractAddress: "", cumulativeGasUsed: "1564522", gasUsed: "30687", confirmations: "3131263"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pricingStrategy", value: addressList[5]}], name: "setPricingStrategy", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPricingStrategy(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1511432649 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x\", \"0\", \"0x000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4606400", timeStamp: "1511432764", hash: "0x07455d4029622fb98762b6d51c1ad6f91ca2fa897e0be3479f9dcc0f1bc11931", nonce: "31", blockHash: "0xd28597176266b8c9560aa5b74c5a310520b712a6434173f320c514f0c91945c1", transactionIndex: "78", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "10000000000000000", gas: "2111333", gasPrice: "18150000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3043535", gasUsed: "122052", confirmations: "3131253"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x"}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x", "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1511432764 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x083f24c0e1220179da4a752363871f3a88479624"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "38381199999999940981"}, {name: "customerId", type: "uint128", value: {s: 1, e: 3, c: [4096]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x16c69f351aadc768f73c2673c02431efbfb2... )", async function( ) {
		const txOriginal = {blockNumber: "4637452", timeStamp: "1511867936", hash: "0x7e049a47fb5359254edb21826ea2bf3671b8ad0b1c4fd612452c8359fc7e6ebb", nonce: "2", blockHash: "0x6c2c99e0d407b8d4aff3eb66c6a39ef97b80dded56f68b2ad5f3f9e7da092d0d", transactionIndex: "4", from: "0x16c69f351aadc768f73c2673c02431efbfb2e33f", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "36700000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b7264ebd607bd5a14b58ed40ea0f690be8556fc290565823f578234dffe8bd65c2baca8956172743a8a53b8e0ebaaa0175a5628da19b5369e2b16cac304fe2f07000000000000000000000000000000000000000000000000000000000000002c16c69f351aadc768f73c2673c02431efbfb2e33f0f55e087f16a4d97a3dc99a3ecede783000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "299025", gasUsed: "214974", confirmations: "3100201"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "36700000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f0f55e087f16a4d97a3dc99a3ecede783000000a702fd7db8"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7264ebd607bd5a14b58ed40ea0f690be8556fc290565823f578234dffe8bd65c"}, {type: "bytes32", name: "s", value: "0x2baca8956172743a8a53b8e0ebaaa0175a5628da19b5369e2b16cac304fe2f07"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x16c69f351aadc768f73c2673c02431efbfb2e33f0f55e087f16a4d97a3dc99a3ecede783000000a702fd7db8", "27", "0x7264ebd607bd5a14b58ed40ea0f690be8556fc290565823f578234dffe8bd65c", "0x2baca8956172743a8a53b8e0ebaaa0175a5628da19b5369e2b16cac304fe2f07", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1511867936 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f"}, {name: "weiAmount", type: "uint256", value: "36700000000000000"}, {name: "tokenAmount", type: "uint256", value: "140859003999999783403"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2038431920, 167557651510, 67005317408643]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1216813146197036723" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x16c69f351aadc768f73c2673c02431efbfb2... )", async function( ) {
		const txOriginal = {blockNumber: "4638951", timeStamp: "1511889530", hash: "0x45d211a3129a5747b37fcbe4ac6f882ab7ff894248928b32ab2d4c2990791d67", nonce: "4", blockHash: "0xb5039a3180f541f6ba54c60fa54cb6b3b266eb572cb7b18b7045e7e1a5641de8", transactionIndex: "10", from: "0x16c69f351aadc768f73c2673c02431efbfb2e33f", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "36700000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bd309a7c43596e2650de5b392200c50b5dc67648ba1f14c267ad433afd12cc9e1284179755a93c097407a1b54d131513596ed8109f6fd7f28b9f3cc6e0a37f527000000000000000000000000000000000000000000000000000000000000002c16c69f351aadc768f73c2673c02431efbfb2e33fa4092929084e4122ab1701d4489606ce000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "423293", gasUsed: "164759", confirmations: "3098702"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "36700000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33fa4092929084e4122ab1701d4489606ce000000a702fd7db8"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xd309a7c43596e2650de5b392200c50b5dc67648ba1f14c267ad433afd12cc9e1"}, {type: "bytes32", name: "s", value: "0x284179755a93c097407a1b54d131513596ed8109f6fd7f28b9f3cc6e0a37f527"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x16c69f351aadc768f73c2673c02431efbfb2e33fa4092929084e4122ab1701d4489606ce000000a702fd7db8", "27", "0xd309a7c43596e2650de5b392200c50b5dc67648ba1f14c267ad433afd12cc9e1", "0x284179755a93c097407a1b54d131513596ed8109f6fd7f28b9f3cc6e0a37f527", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1511889530 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f"}, {name: "weiAmount", type: "uint256", value: "36700000000000000"}, {name: "tokenAmount", type: "uint256", value: "140859003999999783403"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [21804095681, 1719132940460, 66700245665486]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1216813146197036723" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: setPricingStrategy( addressList[12] )", async function( ) {
		const txOriginal = {blockNumber: "4638963", timeStamp: "1511889746", hash: "0xce689d739563db4674114abc66d71994715574e6515f99990c79e5fd43ad40b8", nonce: "34", blockHash: "0x5b786ab8268f2b3833ba83ec1e09f023a616e028f710a5b5ab86b40f17f93229", transactionIndex: "92", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "130689", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x50c67734000000000000000000000000a39c41822da7ac313a6ca84157525a3baadcff7f", contractAddress: "", cumulativeGasUsed: "2330071", gasUsed: "30689", confirmations: "3098690"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pricingStrategy", value: addressList[12]}], name: "setPricingStrategy", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPricingStrategy(address)" ]( addressList[12], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1511889746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x\", \"0\", \"0x000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4638969", timeStamp: "1511889828", hash: "0x20da729c37cf1d191c9a4d81639f0e3c841503723f7019677d373d94a383a517", nonce: "35", blockHash: "0x2fc12f2e59fa4c507f9f6cd4b9cd1279541367d3dd766b83b6d6dafb3a8474c6", transactionIndex: "78", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "10000000000000000", gas: "2111333", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2507880", gasUsed: "122052", confirmations: "3098684"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x"}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x", "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1511889828 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x083f24c0e1220179da4a752363871f3a88479624"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "39804699999999939884"}, {name: "customerId", type: "uint128", value: {s: 1, e: 3, c: [4096]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x16c69f351aadc768f73c2673c02431efbfb2... )", async function( ) {
		const txOriginal = {blockNumber: "4643673", timeStamp: "1511955542", hash: "0x0362ed71f734012e3b58f67fcf87c3c32084d9196673dd9313f97da3ec6e9416", nonce: "5", blockHash: "0xbe2d8c07247a4d6900340a3695906059b6a486d3609f515866fabd6b38068798", transactionIndex: "6", from: "0x16c69f351aadc768f73c2673c02431efbfb2e33f", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "1000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001cbfbc569f64ca8895f6e000d73504ad2f977f8733741da3d860843b3b8915aff520ec31ca27beba92acb19b568d5f2a8fda100b36b9e3e52ab94f289566becec7000000000000000000000000000000000000000000000000000000000000002c16c69f351aadc768f73c2673c02431efbfb2e33fcaf9002d2a5a424c9fe2252ac9e2e618000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "372480", gasUsed: "164631", confirmations: "3093980"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33fcaf9002d2a5a424c9fe2252ac9e2e618000000a702fd7db8"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xbfbc569f64ca8895f6e000d73504ad2f977f8733741da3d860843b3b8915aff5"}, {type: "bytes32", name: "s", value: "0x20ec31ca27beba92acb19b568d5f2a8fda100b36b9e3e52ab94f289566becec7"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x16c69f351aadc768f73c2673c02431efbfb2e33fcaf9002d2a5a424c9fe2252ac9e2e618000000a702fd7db8", "28", "0xbfbc569f64ca8895f6e000d73504ad2f977f8733741da3d860843b3b8915aff5", "0x20ec31ca27beba92acb19b568d5f2a8fda100b36b9e3e52ab94f289566becec7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1511955542 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f"}, {name: "weiAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "3980469999999993988495"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [26979694064, 47029783738913, 51645230655000]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1216813146197036723" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x1b3b08371b071fa46f8ed489a53ba81422d4... )", async function( ) {
		const txOriginal = {blockNumber: "4643716", timeStamp: "1511956174", hash: "0xaf5e54adb09c27ab091d06df1a6790877ec04ba7e5b0b847142948ea74cc80a3", nonce: "0", blockHash: "0x786c7ecb5b66f82d804c472a0a89bf4d4a5e5f894c31df93b396f88554306564", transactionIndex: "30", from: "0x1b3b08371b071fa46f8ed489a53ba81422d44fe8", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "1999100000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001cfcc9b49a9205fbcf3760dd86be2ce9569d3a9100472998a97c8b6991e650c59a265e573b3ce34a42026f7224c8aa2a618f33f8ea213bfdfc1e8706031b3a7e57000000000000000000000000000000000000000000000000000000000000002c1b3b08371b071fa46f8ed489a53ba81422d44fe8314b1d61856a4f44aedd9a129c33fce3000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1643555", gasUsed: "214910", confirmations: "3093937"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "1999100000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x1b3b08371b071fa46f8ed489a53ba81422d44fe8314b1d61856a4f44aedd9a129c33fce3000000a702fd7db8"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xfcc9b49a9205fbcf3760dd86be2ce9569d3a9100472998a97c8b6991e650c59a"}, {type: "bytes32", name: "s", value: "0x265e573b3ce34a42026f7224c8aa2a618f33f8ea213bfdfc1e8706031b3a7e57"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x1b3b08371b071fa46f8ed489a53ba81422d44fe8314b1d61856a4f44aedd9a129c33fce3000000a702fd7db8", "28", "0xfcc9b49a9205fbcf3760dd86be2ce9569d3a9100472998a97c8b6991e650c59a", "0x265e573b3ce34a42026f7224c8aa2a618f33f8ea213bfdfc1e8706031b3a7e57", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1511956174 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x1b3b08371b071fa46f8ed489a53ba81422d44fe8"}, {name: "weiAmount", type: "uint256", value: "1999100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "7957357576999987982400719"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [6552218997, 41512864035585, 59506788252899]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "93087136000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xadaec55a84d03bcaf5030cfa6da242dd11c5... )", async function( ) {
		const txOriginal = {blockNumber: "4643742", timeStamp: "1511956499", hash: "0xf68c3b0ab1fc3a02f7684d21baa5004567470fe21656711fc5ffce1175749875", nonce: "0", blockHash: "0xc565955c77b6c8f2e917927d298a8823822f34fcc62905f46c52e25aac8b8086", transactionIndex: "113", from: "0xadaec55a84d03bcaf5030cfa6da242dd11c52a12", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "1038000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c44e888f81aff433a3c7c75ced422cb692a8dc7f24cf69ce7fc521a4e1c6872c10c9ecb2d024cf706f948fb038f1ca755086d25b95aaf6e79aff42e5f04b04efb000000000000000000000000000000000000000000000000000000000000002cadaec55a84d03bcaf5030cfa6da242dd11c52a123b71bee4de134acf88aaa0b70229558c000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4243426", gasUsed: "214974", confirmations: "3093911"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "1038000000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xadaec55a84d03bcaf5030cfa6da242dd11c52a123b71bee4de134acf88aaa0b70229558c000000a702fd7db8"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x44e888f81aff433a3c7c75ced422cb692a8dc7f24cf69ce7fc521a4e1c6872c1"}, {type: "bytes32", name: "s", value: "0x0c9ecb2d024cf706f948fb038f1ca755086d25b95aaf6e79aff42e5f04b04efb"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xadaec55a84d03bcaf5030cfa6da242dd11c52a123b71bee4de134acf88aaa0b70229558c000000a702fd7db8", "28", "0x44e888f81aff433a3c7c75ced422cb692a8dc7f24cf69ce7fc521a4e1c6872c1", "0x0c9ecb2d024cf706f948fb038f1ca755086d25b95aaf6e79aff42e5f04b04efb", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1511956499 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xadaec55a84d03bcaf5030cfa6da242dd11c52a12"}, {name: "weiAmount", type: "uint256", value: "1038000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "4131727859999993760057999"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [7901505308, 68992141473529, 83013425763724]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "93122779000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x4376f30bf747bb115549da88e879a33069b1... )", async function( ) {
		const txOriginal = {blockNumber: "4643761", timeStamp: "1511956765", hash: "0x5c93c905eed70cf584690e13a623c933c5bb4801a7056384b44b09e4282e1563", nonce: "0", blockHash: "0x053fdf78bdcc05fdf98d5c167665a121fe212ec32bfecdc85530ca1708629a0e", transactionIndex: "47", from: "0x4376f30bf747bb115549da88e879a33069b12b0e", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "1305000000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bd12dfdf9d5ded7cfa45639cb1471d36404234ce108e286a35ef8db92df1ad1c55b3973b5150a2d966736a39704b146ac37a06f3af5d7157259f8022c584ff08d000000000000000000000000000000000000000000000000000000000000002c4376f30bf747bb115549da88e879a33069b12b0ed29ffde53ae7492bbe843b3268187ad2000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2315082", gasUsed: "214974", confirmations: "3093892"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "1305000000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x4376f30bf747bb115549da88e879a33069b12b0ed29ffde53ae7492bbe843b3268187ad2000000a702fd7db8"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xd12dfdf9d5ded7cfa45639cb1471d36404234ce108e286a35ef8db92df1ad1c5"}, {type: "bytes32", name: "s", value: "0x5b3973b5150a2d966736a39704b146ac37a06f3af5d7157259f8022c584ff08d"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x4376f30bf747bb115549da88e879a33069b12b0ed29ffde53ae7492bbe843b3268187ad2000000a702fd7db8", "27", "0xd12dfdf9d5ded7cfa45639cb1471d36404234ce108e286a35ef8db92df1ad1c5", "0x5b3973b5150a2d966736a39704b146ac37a06f3af5d7157259f8022c584ff08d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1511956765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x4376f30bf747bb115549da88e879a33069b12b0e"}, {name: "weiAmount", type: "uint256", value: "1305000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "5194513349999992154986213"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [27996860392, 64480485155467, 99782177045202]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "93047653000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setEarlyParicipantWhitelist( addressList[16], true )", async function( ) {
		const txOriginal = {blockNumber: "4673406", timeStamp: "1512379216", hash: "0x07ca453e7b2875bf2db23615d199a989450feb230c05491bbb1b2b39eca1cedb", nonce: "36", blockHash: "0x3264ce325124be4eafd995406f1b755a0dc5cfcea9b035cd7767d4a33f7b48d6", transactionIndex: "11", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "146193", gasPrice: "24000000000", isError: "0", txreceipt_status: "1", input: "0xeac249320000000000000000000000006a2f9f2a88e945956dfd8e74be26bc59113741510000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "672103", gasUsed: "46193", confirmations: "3064247"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "addr", value: addressList[16]}, {type: "bool", name: "status", value: true}], name: "setEarlyParicipantWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEarlyParicipantWhitelist(address,bool)" ]( addressList[16], true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1512379216 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "addr", type: "address"}, {indexed: false, name: "status", type: "bool"}], name: "Whitelisted", type: "event"} ;
		console.error( "eventCallOriginal[18,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Whitelisted", events: [{name: "addr", type: "address", value: "0x6a2f9f2a88e945956dfd8e74be26bc5911374151"}, {name: "status", type: "bool", value: true}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[18,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setPricingStrategy( addressList[17] )", async function( ) {
		const txOriginal = {blockNumber: "4675620", timeStamp: "1512412877", hash: "0xd89d2b3a5214f9749357e062cdc1bf2ea53367e2d4798859dd69ed5d392b4b69", nonce: "39", blockHash: "0xf01cc36b7cc8a328ff35833aac91fb87bc43a0df15a4b04a5e52ec71b16484f0", transactionIndex: "115", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "130689", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x50c677340000000000000000000000006fd8f3cfdd99953eb489596dedc5eb3e0ec42499", contractAddress: "", cumulativeGasUsed: "3897830", gasUsed: "30689", confirmations: "3062033"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pricingStrategy", value: addressList[17]}], name: "setPricingStrategy", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPricingStrategy(address)" ]( addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1512412877 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x\", \"0\", \"0x000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4675634", timeStamp: "1512413067", hash: "0xe659e4198cdfa952a2c33f5e28e79d0fe44c87a9a219fa55f68a9021ce7b7e98", nonce: "40", blockHash: "0xa6b27461ed4816699a4b5dbf22862fcd7ca693324def8c092962837021070ba7", transactionIndex: "2", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "10000000000000000", gas: "2111333", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "165196", gasUsed: "122052", confirmations: "3062019"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x"}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x", "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1512413067 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x083f24c0e1220179da4a752363871f3a88479624"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "63061700000000165941"}, {name: "customerId", type: "uint128", value: {s: 1, e: 3, c: [4096]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x97f31237cfd2c0ae415feeec78fb527f081e... )", async function( ) {
		const txOriginal = {blockNumber: "4679056", timeStamp: "1512467190", hash: "0x3edb4d7826a27ed86d04d34c27e19cb1c72f92f7dab00a728662dc51a5b979f0", nonce: "0", blockHash: "0x2f521c0cbbded1773db8c90852e5dde17dd7ee751230de8462315e0cf65ec4d3", transactionIndex: "55", from: "0x97f31237cfd2c0ae415feeec78fb527f081ee065", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "1735000000000000000000", gas: "2600300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bfe3378dfd29c4ef7511bbcf6c50042cfb7409e15846b9e5ba91fb26099d9e66f2bf1aa05211abff8e3fee69a3f118cb3ea79720eda3c8d0a5fdf7495db198d7d000000000000000000000000000000000000000000000000000000000000002c97f31237cfd2c0ae415feeec78fb527f081ee065dea03c12bca742709bca869ca6e6687e000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2814487", gasUsed: "214910", confirmations: "3058597"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "1735000000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x97f31237cfd2c0ae415feeec78fb527f081ee065dea03c12bca742709bca869ca6e6687e000000a702fd7db8"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xfe3378dfd29c4ef7511bbcf6c50042cfb7409e15846b9e5ba91fb26099d9e66f"}, {type: "bytes32", name: "s", value: "0x2bf1aa05211abff8e3fee69a3f118cb3ea79720eda3c8d0a5fdf7495db198d7d"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x97f31237cfd2c0ae415feeec78fb527f081ee065dea03c12bca742709bca869ca6e6687e000000a702fd7db8", "27", "0xfe3378dfd29c4ef7511bbcf6c50042cfb7409e15846b9e5ba91fb26099d9e66f", "0x2bf1aa05211abff8e3fee69a3f118cb3ea79720eda3c8d0a5fdf7495db198d7d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1512467190 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x97f31237cfd2c0ae415feeec78fb527f081ee065"}, {name: "weiAmount", type: "uint256", value: "1735000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "10941204950000028790905529"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [29592060099, 6854267739312, 14986816153726]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "82927177999934464" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x9fa3afd7068583048c23ca49a637007fafce... )", async function( ) {
		const txOriginal = {blockNumber: "4685857", timeStamp: "1512573805", hash: "0x7b3c16308a923ce6c7c9937e8aea4d54e4781f65f40dd3051b40cbd73d742710", nonce: "0", blockHash: "0x36a8c881001285da27ec833ec61bd8f20d65d3dfed5594f808a3dbebb92c1891", transactionIndex: "100", from: "0x9fa3afd7068583048c23ca49a637007fafce8819", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "50000000000000000", gas: "260300", gasPrice: "40000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b00ea71055db558f28821244e7399804e96f6d11f84cf13501f6dda511c22f6664abd8632e3e3d0208bea663e0c8af60188dd757ba936525ee7cc17a4462e6798000000000000000000000000000000000000000000000000000000000000002c9fa3afd7068583048c23ca49a637007fafce8819f965ab727def464685641452a8673917000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3642794", gasUsed: "214846", confirmations: "3051796"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x9fa3afd7068583048c23ca49a637007fafce8819f965ab727def464685641452a8673917000000a702fd7db8"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x00ea71055db558f28821244e7399804e96f6d11f84cf13501f6dda511c22f666"}, {type: "bytes32", name: "s", value: "0x4abd8632e3e3d0208bea663e0c8af60188dd757ba936525ee7cc17a4462e6798"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x9fa3afd7068583048c23ca49a637007fafce8819f965ab727def464685641452a8673917000000a702fd7db8", "27", "0x00ea71055db558f28821244e7399804e96f6d11f84cf13501f6dda511c22f666", "0x4abd8632e3e3d0208bea663e0c8af60188dd757ba936525ee7cc17a4462e6798", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1512573805 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9fa3afd7068583048c23ca49a637007fafce8819"}, {name: "weiAmount", type: "uint256", value: "50000000000000000"}, {name: "tokenAmount", type: "uint256", value: "315308500000000829709"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [33150567029, 61837123704002, 64631183948055]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "5651455000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xd3ac35fd0fc81687e5ea21880a7dfd0ed506... )", async function( ) {
		const txOriginal = {blockNumber: "4686094", timeStamp: "1512577564", hash: "0xd7ee503666dc6373271681cd40f7b97f2283d78e61956a7fdc392e4a82d39368", nonce: "0", blockHash: "0x972a23eb5a21c39e3b7a53b854f88ba87b0b5b39721ec86af567f30e39dca989", transactionIndex: "9", from: "0xd3ac35fd0fc81687e5ea21880a7dfd0ed506949d", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "100000000000000000", gas: "260300", gasPrice: "76000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001be4465489aac96a12d4821be5652e6b64d53b69913021520eebaac786cd8c7cdf53c0bf161f6a98dda223dc0dcf8bdf0de0154e00d05baf86081ba2e08d66b02f000000000000000000000000000000000000000000000000000000000000002cd3ac35fd0fc81687e5ea21880a7dfd0ed506949dc7197923488040219447959ca0fe069c000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "444945", gasUsed: "214910", confirmations: "3051559"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xd3ac35fd0fc81687e5ea21880a7dfd0ed506949dc7197923488040219447959ca0fe069c000000a702fd7db8"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xe4465489aac96a12d4821be5652e6b64d53b69913021520eebaac786cd8c7cdf"}, {type: "bytes32", name: "s", value: "0x53c0bf161f6a98dda223dc0dcf8bdf0de0154e00d05baf86081ba2e08d66b02f"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xd3ac35fd0fc81687e5ea21880a7dfd0ed506949dc7197923488040219447959ca0fe069c000000a702fd7db8", "27", "0xe4465489aac96a12d4821be5652e6b64d53b69913021520eebaac786cd8c7cdf", "0x53c0bf161f6a98dda223dc0dcf8bdf0de0154e00d05baf86081ba2e08d66b02f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1512577564 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xd3ac35fd0fc81687e5ea21880a7dfd0ed506949d"}, {name: "weiAmount", type: "uint256", value: "100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "630617000000001659418"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [26464863554, 96473253128736, 29508626679452]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "103666840000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x57dc45c77fdbef96dd369d85ab1380cdfe28... )", async function( ) {
		const txOriginal = {blockNumber: "4686350", timeStamp: "1512581433", hash: "0x4a8f547cd95670fb5ba4dce36dd79e0b99312a8bbcc2af4a5c498d9ace9f2fc7", nonce: "0", blockHash: "0xd892ec68b7880046e80bbdff12cc42a242627a09ebfcab21dc9cd7cd97221c36", transactionIndex: "72", from: "0x57dc45c77fdbef96dd369d85ab1380cdfe2800f1", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "100000000000000000", gas: "260300", gasPrice: "38000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b7084f83a8a2fac825ac551349ef06d9a111f65beab210b0bcb5a92499a16d12e57087421ec4455d58973e095362e249df910644f1c9d6b7d216d1d1c1cf09d6e000000000000000000000000000000000000000000000000000000000000002c57dc45c77fdbef96dd369d85ab1380cdfe2800f16882e371b3b34c0bbe429e25c314c43e000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6506713", gasUsed: "214910", confirmations: "3051303"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "100000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x57dc45c77fdbef96dd369d85ab1380cdfe2800f16882e371b3b34c0bbe429e25c314c43e000000a702fd7db8"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7084f83a8a2fac825ac551349ef06d9a111f65beab210b0bcb5a92499a16d12e"}, {type: "bytes32", name: "s", value: "0x57087421ec4455d58973e095362e249df910644f1c9d6b7d216d1d1c1cf09d6e"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x57dc45c77fdbef96dd369d85ab1380cdfe2800f16882e371b3b34c0bbe429e25c314c43e000000a702fd7db8", "27", "0x7084f83a8a2fac825ac551349ef06d9a111f65beab210b0bcb5a92499a16d12e", "0x57087421ec4455d58973e095362e249df910644f1c9d6b7d216d1d1c1cf09d6e", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1512581433 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x57dc45c77fdbef96dd369d85ab1380cdfe2800f1"}, {name: "weiAmount", type: "uint256", value: "100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "630617000000001659418"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [13891932326, 86177450109696, 45817005392958]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "1833420000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x946775d90d0cf9d7a219160428c1cf9b1042... )", async function( ) {
		const txOriginal = {blockNumber: "4686433", timeStamp: "1512582608", hash: "0x829dced2c6f13c0490b2ceddfae9b5e8abfe6ca648524566c498b527867258b9", nonce: "0", blockHash: "0x9454f8f3cc97d094960f1f94123a58c471d9d7adc65e426452af322e1483aac1", transactionIndex: "6", from: "0x946775d90d0cf9d7a219160428c1cf9b1042a74c", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "9945000000000000000", gas: "260300", gasPrice: "77000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c6f6bd4b19726cdf1d5b9199da61b12ebaa7a0b0ac7f73292ded3fb61987cd28439cb4b65f4c479077dcee1c193a9ebc582750fe94299d82e4c98f20db8239864000000000000000000000000000000000000000000000000000000000000002c946775d90d0cf9d7a219160428c1cf9b1042a74cbefb5d062f804c518886336fc270e1e2000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "443691", gasUsed: "214974", confirmations: "3051220"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "9945000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x946775d90d0cf9d7a219160428c1cf9b1042a74cbefb5d062f804c518886336fc270e1e2000000a702fd7db8"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x6f6bd4b19726cdf1d5b9199da61b12ebaa7a0b0ac7f73292ded3fb61987cd284"}, {type: "bytes32", name: "s", value: "0x39cb4b65f4c479077dcee1c193a9ebc582750fe94299d82e4c98f20db8239864"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x946775d90d0cf9d7a219160428c1cf9b1042a74cbefb5d062f804c518886336fc270e1e2000000a702fd7db8", "28", "0x6f6bd4b19726cdf1d5b9199da61b12ebaa7a0b0ac7f73292ded3fb61987cd284", "0x39cb4b65f4c479077dcee1c193a9ebc582750fe94299d82e4c98f20db8239864", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1512582608 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x946775d90d0cf9d7a219160428c1cf9b1042a74c"}, {name: "weiAmount", type: "uint256", value: "9945000000000000000"}, {name: "tokenAmount", type: "uint256", value: "62714860650000165029138"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [25385847246, 47892706478104, 14506604028386]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "104704217426999829198" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x16c69f351aadc768f73c2673c02431efbfb2... )", async function( ) {
		const txOriginal = {blockNumber: "4692024", timeStamp: "1512667857", hash: "0x0459ed4f3f7e2c9f01d22d25a2da8339176dc9ca1945b95b16741c2107f8951e", nonce: "13", blockHash: "0xc35ee028691e02d3c69063bfcd3ad5c540576fe2a2071466db861c92f260b420", transactionIndex: "24", from: "0x16c69f351aadc768f73c2673c02431efbfb2e33f", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "10000000000000000", gas: "260300", gasPrice: "70000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001ccde6c7409b22b1cd5da8b92fa30db1dd8968ab1d88817f4e2d223c11186e450045854442fe473710476fe6dd4c6529e66c791e43f9e5cac4eb2771a22c3766cd000000000000000000000000000000000000000000000000000000000000002c16c69f351aadc768f73c2673c02431efbfb2e33fca31f32bc95a451ba1c20b75da25b278000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1967783", gasUsed: "164695", confirmations: "3045629"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33fca31f32bc95a451ba1c20b75da25b278000000a702fd7db8"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xcde6c7409b22b1cd5da8b92fa30db1dd8968ab1d88817f4e2d223c11186e4500"}, {type: "bytes32", name: "s", value: "0x45854442fe473710476fe6dd4c6529e66c791e43f9e5cac4eb2771a22c3766cd"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x16c69f351aadc768f73c2673c02431efbfb2e33fca31f32bc95a451ba1c20b75da25b278000000a702fd7db8", "28", "0xcde6c7409b22b1cd5da8b92fa30db1dd8968ab1d88817f4e2d223c11186e4500", "0x45854442fe473710476fe6dd4c6529e66c791e43f9e5cac4eb2771a22c3766cd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1512667857 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "63061700000000165941"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [26876340978, 92815050005075, 31022683189880]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1216813146197036723" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x16c69f351aadc768f73c2673c02431efbfb2... )", async function( ) {
		const txOriginal = {blockNumber: "4692026", timeStamp: "1512667885", hash: "0x39ea16ca0fb5716d6b3e5c42f73bb3e451b691c6c765b7ae0886390282b3a4d5", nonce: "14", blockHash: "0xe926de00c74b8d5a81e689825d6888d34b8bbfb335bfd40cd0b0e15ef1c3e200", transactionIndex: "9", from: "0x16c69f351aadc768f73c2673c02431efbfb2e33f", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "10000000000000000", gas: "260300", gasPrice: "70000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001ccde6c7409b22b1cd5da8b92fa30db1dd8968ab1d88817f4e2d223c11186e450045854442fe473710476fe6dd4c6529e66c791e43f9e5cac4eb2771a22c3766cd000000000000000000000000000000000000000000000000000000000000002c16c69f351aadc768f73c2673c02431efbfb2e33fca31f32bc95a451ba1c20b75da25b278000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "492272", gasUsed: "164695", confirmations: "3045627"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33fca31f32bc95a451ba1c20b75da25b278000000a702fd7db8"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xcde6c7409b22b1cd5da8b92fa30db1dd8968ab1d88817f4e2d223c11186e4500"}, {type: "bytes32", name: "s", value: "0x45854442fe473710476fe6dd4c6529e66c791e43f9e5cac4eb2771a22c3766cd"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x16c69f351aadc768f73c2673c02431efbfb2e33fca31f32bc95a451ba1c20b75da25b278000000a702fd7db8", "28", "0xcde6c7409b22b1cd5da8b92fa30db1dd8968ab1d88817f4e2d223c11186e4500", "0x45854442fe473710476fe6dd4c6529e66c791e43f9e5cac4eb2771a22c3766cd", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1512667885 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "63061700000000165941"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [26876340978, 92815050005075, 31022683189880]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1216813146197036723" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setEndsAt( \"1517324400\" )", async function( ) {
		const txOriginal = {blockNumber: "4696293", timeStamp: "1512729973", hash: "0x3c253442181b63aaa93a11195a544bd5526ec88605198df902fb29e8aad89480", nonce: "41", blockHash: "0xfa1569e697c66608d8f0c55aa8e05dc9233e62b6f5241c80165e68729c4c98ac", transactionIndex: "49", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "128936", gasPrice: "55000000000", isError: "0", txreceipt_status: "1", input: "0x6e50eb3f000000000000000000000000000000000000000000000000000000005a708870", contractAddress: "", cumulativeGasUsed: "2772050", gasUsed: "28936", confirmations: "3041360"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "time", value: "1517324400"}], name: "setEndsAt", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setEndsAt(uint256)" ]( "1517324400", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1512729973 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newEndsAt", type: "uint256"}], name: "EndsAtChanged", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "EndsAtChanged", events: [{name: "newEndsAt", type: "uint256", value: "1517324400"}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x82eac4f99b1a1a5ca7a074a9339e39dffdde... )", async function( ) {
		const txOriginal = {blockNumber: "4696985", timeStamp: "1512740534", hash: "0xc53a89087fe4e0d73b0ba948d0048b0c552e2133408143f2172b125479f5abc2", nonce: "0", blockHash: "0x0d7f838f388dba4f33a9ce9320ea91bf2e92d6b4c30f6f199285229a73392ad8", transactionIndex: "60", from: "0x82eac4f99b1a1a5ca7a074a9339e39dffdde2fd5", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "90000000000000000", gas: "260300", gasPrice: "60000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001cc760699dcab6abaee1476982ebeb59f19692dfa20fc79c32b117f175f43d27503366c1efbc1d0541565c7d809191eba94920e4d110d42dd5416a9a73721aa130000000000000000000000000000000000000000000000000000000000000002c82eac4f99b1a1a5ca7a074a9339e39dffdde2fd5a4c61963563e4e5794b4218f0601ede1000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3173835", gasUsed: "214974", confirmations: "3040668"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "90000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x82eac4f99b1a1a5ca7a074a9339e39dffdde2fd5a4c61963563e4e5794b4218f0601ede1000000a702fd7db8"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xc760699dcab6abaee1476982ebeb59f19692dfa20fc79c32b117f175f43d2750"}, {type: "bytes32", name: "s", value: "0x3366c1efbc1d0541565c7d809191eba94920e4d110d42dd5416a9a73721aa130"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x82eac4f99b1a1a5ca7a074a9339e39dffdde2fd5a4c61963563e4e5794b4218f0601ede1000000a702fd7db8", "28", "0xc760699dcab6abaee1476982ebeb59f19692dfa20fc79c32b117f175f43d2750", "0x3366c1efbc1d0541565c7d809191eba94920e4d110d42dd5416a9a73721aa130", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1512740534 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x82eac4f99b1a1a5ca7a074a9339e39dffdde2fd5"}, {name: "weiAmount", type: "uint256", value: "90000000000000000"}, {name: "tokenAmount", type: "uint256", value: "567555300000001493476"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [21902198101, 72353134362228, 24077102018017]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "7101560000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xe3f4f251cb553f9321d711ce32669af32c3e... )", async function( ) {
		const txOriginal = {blockNumber: "4697009", timeStamp: "1512740915", hash: "0x9fdcc75ca40552654e8f511671cc4a5fbccec638b63a03de1bcd1f04d100f667", nonce: "0", blockHash: "0x37a3a0b4427972d3aba3e86def10bc107ec5000be966eacae08b0e58b8b76eea", transactionIndex: "18", from: "0xe3f4f251cb553f9321d711ce32669af32c3e2a09", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "7100000000000000000", gas: "260300", gasPrice: "80000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001befed47258084e975f1b016af1bc87f9c6082ed766d6feee81e3a80d5f79aaa2f63f05233e8f8369da5f802d182c2eb8aab6ec44847fb4d962daa4dd5a07945a6000000000000000000000000000000000000000000000000000000000000002ce3f4f251cb553f9321d711ce32669af32c3e2a0912cce613cd9e4c49831a2d36acffac44000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1051167", gasUsed: "214974", confirmations: "3040644"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "7100000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xe3f4f251cb553f9321d711ce32669af32c3e2a0912cce613cd9e4c49831a2d36acffac44000000a702fd7db8"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xefed47258084e975f1b016af1bc87f9c6082ed766d6feee81e3a80d5f79aaa2f"}, {type: "bytes32", name: "s", value: "0x63f05233e8f8369da5f802d182c2eb8aab6ec44847fb4d962daa4dd5a07945a6"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xe3f4f251cb553f9321d711ce32669af32c3e2a0912cce613cd9e4c49831a2d36acffac44000000a702fd7db8", "27", "0xefed47258084e975f1b016af1bc87f9c6082ed766d6feee81e3a80d5f79aaa2f", "0x63f05233e8f8369da5f802d182c2eb8aab6ec44847fb4d962daa4dd5a07945a6", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1512740915 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xe3f4f251cb553f9321d711ce32669af32c3e2a09"}, {name: "weiAmount", type: "uint256", value: "7100000000000000000"}, {name: "tokenAmount", type: "uint256", value: "44773807000000117818691"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2498999900, 64493157524954, 49334572100676]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "1344812508876428" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x9fa3afd7068583048c23ca49a637007fafce... )", async function( ) {
		const txOriginal = {blockNumber: "4697013", timeStamp: "1512740998", hash: "0x21e5c5fb972ec7e422fe1cc96bea814316c4fb4f18d5094ceab35e5ca96a6d1c", nonce: "1", blockHash: "0x330e120955bf002bbb345078fd3423f39ffc5327b60a61d8b276bad006e4a306", transactionIndex: "108", from: "0x9fa3afd7068583048c23ca49a637007fafce8819", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "36700000000000000", gas: "260300", gasPrice: "55000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c1cf57e13633b4cf16a00e81a32b624125edb0fa58d2b7074e8ecc33e4ef5c7242c5c1547aa6019877fe9f7416469f37fd745f9bc6ce6abb3a1fd99809058cd12000000000000000000000000000000000000000000000000000000000000002c9fa3afd7068583048c23ca49a637007fafce88191593b0bf90ee4245b5d05fd534ef2891000000a702fd7db80000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5111611", gasUsed: "164631", confirmations: "3040640"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "36700000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x9fa3afd7068583048c23ca49a637007fafce88191593b0bf90ee4245b5d05fd534ef2891000000a702fd7db8"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x1cf57e13633b4cf16a00e81a32b624125edb0fa58d2b7074e8ecc33e4ef5c724"}, {type: "bytes32", name: "s", value: "0x2c5c1547aa6019877fe9f7416469f37fd745f9bc6ce6abb3a1fd99809058cd12"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x9fa3afd7068583048c23ca49a637007fafce88191593b0bf90ee4245b5d05fd534ef2891000000a702fd7db8", "28", "0x1cf57e13633b4cf16a00e81a32b624125edb0fa58d2b7074e8ecc33e4ef5c724", "0x2c5c1547aa6019877fe9f7416469f37fd745f9bc6ce6abb3a1fd99809058cd12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1512740998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9fa3afd7068583048c23ca49a637007fafce8819"}, {name: "weiAmount", type: "uint256", value: "36700000000000000"}, {name: "tokenAmount", type: "uint256", value: "231436439000000609006"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2868064043, 12110146323132, 85117236684945]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "5651455000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x5a22dfbcb53c7f75f99ab4ef24a8c97ceefb... )", async function( ) {
		const txOriginal = {blockNumber: "4703688", timeStamp: "1512840844", hash: "0xdc9a44d1c24b230a8fc3d4422b1f1a4242607c4c5119497d600a67d0f1bfce5a", nonce: "0", blockHash: "0x54b7bd4a91bee7e7625b4eaaf585b782483bcfe41c37fee35f96a052282d0c96", transactionIndex: "37", from: "0x5a22dfbcb53c7f75f99ab4ef24a8c97ceefb1037", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "4188000000000000000", gas: "260300", gasPrice: "70000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c90a36253e97ed2eb7fdce48be4573c9502b5334905bd8a37395df92c190f72a9265605a3baa4cf10c1290a8cc90ce40edf1dd98be488ebd1bffe3201608c9759000000000000000000000000000000000000000000000000000000000000002c5a22dfbcb53c7f75f99ab4ef24a8c97ceefb1037cc807c7cb18b467bb0c20b133f68b826000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1553453", gasUsed: "215038", confirmations: "3033965"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "4188000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x5a22dfbcb53c7f75f99ab4ef24a8c97ceefb1037cc807c7cb18b467bb0c20b133f68b826000007d001c9c380"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x90a36253e97ed2eb7fdce48be4573c9502b5334905bd8a37395df92c190f72a9"}, {type: "bytes32", name: "s", value: "0x265605a3baa4cf10c1290a8cc90ce40edf1dd98be488ebd1bffe3201608c9759"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x5a22dfbcb53c7f75f99ab4ef24a8c97ceefb1037cc807c7cb18b467bb0c20b133f68b826000007d001c9c380", "28", "0x90a36253e97ed2eb7fdce48be4573c9502b5334905bd8a37395df92c190f72a9", "0x265605a3baa4cf10c1290a8cc90ce40edf1dd98be488ebd1bffe3201608c9759", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1512840844 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x5a22dfbcb53c7f75f99ab4ef24a8c97ceefb1037"}, {name: "weiAmount", type: "uint256", value: "4188000000000000000"}, {name: "tokenAmount", type: "uint256", value: "26410239960000069496433"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [27182965003, 60455208593835, 62320403281958]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "5876435000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xbd6a8cca8d7e3aa526b929de4b97c89260ec... )", async function( ) {
		const txOriginal = {blockNumber: "4703689", timeStamp: "1512840866", hash: "0xace9a5d87b9262db34a0a57d546894c04a34752444badf60e0402f6334fe77b5", nonce: "0", blockHash: "0x53fa80486846c8e00d6ce0d94574347153fcc509637008fd106419b5dc1dd3f4", transactionIndex: "14", from: "0xbd6a8cca8d7e3aa526b929de4b97c89260ec9e86", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "584709000000000000", gas: "260300", gasPrice: "70100000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b6757db07498a1a044cb550a7d1dae1d5e95734ffe513ce383ebba0c8e8c397b155009cc6f8923688160df9368b2cfe4fca4dcad90837f834fcae280a7a1bff32000000000000000000000000000000000000000000000000000000000000002cbd6a8cca8d7e3aa526b929de4b97c89260ec9e8634014e68ef26495a9be1280e09c3776f000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "708906", gasUsed: "214974", confirmations: "3033964"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "584709000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xbd6a8cca8d7e3aa526b929de4b97c89260ec9e8634014e68ef26495a9be1280e09c3776f000007d001c9c380"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x6757db07498a1a044cb550a7d1dae1d5e95734ffe513ce383ebba0c8e8c397b1"}, {type: "bytes32", name: "s", value: "0x55009cc6f8923688160df9368b2cfe4fca4dcad90837f834fcae280a7a1bff32"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xbd6a8cca8d7e3aa526b929de4b97c89260ec9e8634014e68ef26495a9be1280e09c3776f000007d001c9c380", "27", "0x6757db07498a1a044cb550a7d1dae1d5e95734ffe513ce383ebba0c8e8c397b1", "0x55009cc6f8923688160df9368b2cfe4fca4dcad90837f834fcae280a7a1bff32", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1512840866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xbd6a8cca8d7e3aa526b929de4b97c89260ec9e86"}, {name: "weiAmount", type: "uint256", value: "584709000000000000"}, {name: "tokenAmount", type: "uint256", value: "3687274354530009702767"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [6912663841, 93653494650500, 21683297220463]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "2813708000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xc7b060925c4cf46f1f1a4cc1402b1c0c6e7a... )", async function( ) {
		const txOriginal = {blockNumber: "4703689", timeStamp: "1512840866", hash: "0x099b8df7134af54c8b2a8c045c61be6d2f3eb6d0f986066d6eaa55701b973d94", nonce: "0", blockHash: "0x53fa80486846c8e00d6ce0d94574347153fcc509637008fd106419b5dc1dd3f4", transactionIndex: "15", from: "0xc7b060925c4cf46f1f1a4cc1402b1c0c6e7a502a", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "708731000000000000", gas: "260300", gasPrice: "70100000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001cd0c1489ffd879e9db8dd6ce6264475c1afb91dc10ee748fd1f5ca7c67f4af4a54fbded5ac89ef0fccac38d3fe61db37bb829ca16f2f527750260daee0b39be12000000000000000000000000000000000000000000000000000000000000002cc7b060925c4cf46f1f1a4cc1402b1c0c6e7a502aa19ec9ed15804e86942e7683b498d252000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "923944", gasUsed: "215038", confirmations: "3033964"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "708731000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xc7b060925c4cf46f1f1a4cc1402b1c0c6e7a502aa19ec9ed15804e86942e7683b498d252000007d001c9c380"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xd0c1489ffd879e9db8dd6ce6264475c1afb91dc10ee748fd1f5ca7c67f4af4a5"}, {type: "bytes32", name: "s", value: "0x4fbded5ac89ef0fccac38d3fe61db37bb829ca16f2f527750260daee0b39be12"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xc7b060925c4cf46f1f1a4cc1402b1c0c6e7a502aa19ec9ed15804e86942e7683b498d252000007d001c9c380", "28", "0xd0c1489ffd879e9db8dd6ce6264475c1afb91dc10ee748fd1f5ca7c67f4af4a5", "0x4fbded5ac89ef0fccac38d3fe61db37bb829ca16f2f527750260daee0b39be12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1512840866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xc7b060925c4cf46f1f1a4cc1402b1c0c6e7a502a"}, {name: "weiAmount", type: "uint256", value: "708731000000000000"}, {name: "tokenAmount", type: "uint256", value: "4469378170270011760811"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [21483018577, 30791067075098, 68954151080530]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "4926456200000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x16c69f351aadc768f73c2673c02431efbfb2... )", async function( ) {
		const txOriginal = {blockNumber: "4703689", timeStamp: "1512840866", hash: "0x139b8ae4a7d98c153677499989ffcb72e6d9ac93fe9d15d7cbae94397cf76a98", nonce: "16", blockHash: "0x53fa80486846c8e00d6ce0d94574347153fcc509637008fd106419b5dc1dd3f4", transactionIndex: "17", from: "0x16c69f351aadc768f73c2673c02431efbfb2e33f", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "220000000000000000", gas: "260300", gasPrice: "70000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c7c077e479e34eedef376524a129743a8a375e2ddf6cab7aa46e4f9106510729468da198075fb320c52924095b1cb0800bbda141fea34ace9d517693b4269ea4f000000000000000000000000000000000000000000000000000000000000002c16c69f351aadc768f73c2673c02431efbfb2e33f02e74a8bb99a4af288e16808b2561af0000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1109703", gasUsed: "164759", confirmations: "3033964"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "220000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f02e74a8bb99a4af288e16808b2561af0000007d001c9c380"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x7c077e479e34eedef376524a129743a8a375e2ddf6cab7aa46e4f91065107294"}, {type: "bytes32", name: "s", value: "0x68da198075fb320c52924095b1cb0800bbda141fea34ace9d517693b4269ea4f"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x16c69f351aadc768f73c2673c02431efbfb2e33f02e74a8bb99a4af288e16808b2561af0000007d001c9c380", "28", "0x7c077e479e34eedef376524a129743a8a375e2ddf6cab7aa46e4f91065107294", "0x68da198075fb320c52924095b1cb0800bbda141fea34ace9d517693b4269ea4f", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1512840866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f"}, {name: "weiAmount", type: "uint256", value: "220000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1387357400000003650720"}, {name: "customerId", type: "uint128", value: {s: 1, e: 36, c: [385938853, 43578919566170, 24215740455664]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1216813146197036723" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x0fd91f04d342ce20293fbc6a93117aba72e2... )", async function( ) {
		const txOriginal = {blockNumber: "4703689", timeStamp: "1512840866", hash: "0x248fd2288d1440699184696c2398c7ec0dfad6837b2f9acfaa7ae7933ad3cc2d", nonce: "0", blockHash: "0x53fa80486846c8e00d6ce0d94574347153fcc509637008fd106419b5dc1dd3f4", transactionIndex: "18", from: "0x0fd91f04d342ce20293fbc6a93117aba72e20c01", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "16827000000000000000", gas: "260300", gasPrice: "70000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b9734f85e2a31354e90219cd5f9ba25ecc9d7d21268abf26f271c780b5f154bf05a12a9a463fde612f9f6ab8b9f9d3fd8a6a111b366b318407f781540dac505fe000000000000000000000000000000000000000000000000000000000000002c0fd91f04d342ce20293fbc6a93117aba72e20c015754ed76c0ec4edab660f964732ec135000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1324741", gasUsed: "215038", confirmations: "3033964"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "16827000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x0fd91f04d342ce20293fbc6a93117aba72e20c015754ed76c0ec4edab660f964732ec135000007d001c9c380"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x9734f85e2a31354e90219cd5f9ba25ecc9d7d21268abf26f271c780b5f154bf0"}, {type: "bytes32", name: "s", value: "0x5a12a9a463fde612f9f6ab8b9f9d3fd8a6a111b366b318407f781540dac505fe"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x0fd91f04d342ce20293fbc6a93117aba72e20c015754ed76c0ec4edab660f964732ec135000007d001c9c380", "27", "0x9734f85e2a31354e90219cd5f9ba25ecc9d7d21268abf26f271c780b5f154bf0", "0x5a12a9a463fde612f9f6ab8b9f9d3fd8a6a111b366b318407f781540dac505fe", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1512840866 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x0fd91f04d342ce20293fbc6a93117aba72e20c01"}, {name: "weiAmount", type: "uint256", value: "16827000000000000000"}, {name: "tokenAmount", type: "uint256", value: "106113922590000279230298"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [11608380490, 91106493507550, 42976674529589]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "5523176047123058" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xe337f2592aca17509c487b5b0a0638d1277f... )", async function( ) {
		const txOriginal = {blockNumber: "4704432", timeStamp: "1512851343", hash: "0x371ce12c677716f45fd07a0596ac27d8f80ea8ff9bc2e99abcca154f8fa6805e", nonce: "0", blockHash: "0x3bc31bc65b22f6e75fb09e6f247288205f644078e88557041cb680182aaae9d4", transactionIndex: "84", from: "0xe337f2592aca17509c487b5b0a0638d1277f4a3c", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "19000000000000000000", gas: "260300", gasPrice: "41000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b7de9eca79b7ff7c3c25330f7c8f5964137736da0e9b51783e1383191e98919f2014d7954ce57f0eccb3c852add34316a6f4cc72a963cf2ab12e7699039706c1d000000000000000000000000000000000000000000000000000000000000002ce337f2592aca17509c487b5b0a0638d1277f4a3cbd398fd3ff5546548e4ed4b8c5c244de000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6137527", gasUsed: "215038", confirmations: "3033221"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "19000000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xe337f2592aca17509c487b5b0a0638d1277f4a3cbd398fd3ff5546548e4ed4b8c5c244de000007d001c9c380"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x7de9eca79b7ff7c3c25330f7c8f5964137736da0e9b51783e1383191e98919f2"}, {type: "bytes32", name: "s", value: "0x014d7954ce57f0eccb3c852add34316a6f4cc72a963cf2ab12e7699039706c1d"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xe337f2592aca17509c487b5b0a0638d1277f4a3cbd398fd3ff5546548e4ed4b8c5c244de000007d001c9c380", "27", "0x7de9eca79b7ff7c3c25330f7c8f5964137736da0e9b51783e1383191e98919f2", "0x014d7954ce57f0eccb3c852add34316a6f4cc72a963cf2ab12e7699039706c1d", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1512851343 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xe337f2592aca17509c487b5b0a0638d1277f4a3c"}, {name: "weiAmount", type: "uint256", value: "19000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "119817230000000315289455"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [25152296930, 50229661768365, 35741520692446]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "28408986000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xf67fc8284747d0dcc11525b987cf1c7075b3... )", async function( ) {
		const txOriginal = {blockNumber: "4705890", timeStamp: "1512873100", hash: "0x075d00881031606caa9eb05aa7693fa7cb777c9ea07885acba28e2e84961045a", nonce: "8", blockHash: "0xc406a54f56c56e9790ad2da235ec3b57743bb891e2fbe3bd71a26667e32fca87", transactionIndex: "46", from: "0xf67fc8284747d0dcc11525b987cf1c7075b3d145", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "50000000000000000000", gas: "260300", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b75d67a29b3e5ad941ecee7b066a893928e30e69fe87e2f10a842be77a48237393b2119b5499fccd544fced7d27dad10e21f556dde435c2388b6455d70e36c4a2000000000000000000000000000000000000000000000000000000000000002cf67fc8284747d0dcc11525b987cf1c7075b3d1458c84e5fce9af4c6a926667796a87f864000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5083810", gasUsed: "215038", confirmations: "3031763"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "50000000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xf67fc8284747d0dcc11525b987cf1c7075b3d1458c84e5fce9af4c6a926667796a87f864000007d001c9c380"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x75d67a29b3e5ad941ecee7b066a893928e30e69fe87e2f10a842be77a4823739"}, {type: "bytes32", name: "s", value: "0x3b2119b5499fccd544fced7d27dad10e21f556dde435c2388b6455d70e36c4a2"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xf67fc8284747d0dcc11525b987cf1c7075b3d1458c84e5fce9af4c6a926667796a87f864000007d001c9c380", "27", "0x75d67a29b3e5ad941ecee7b066a893928e30e69fe87e2f10a842be77a4823739", "0x3b2119b5499fccd544fced7d27dad10e21f556dde435c2388b6455d70e36c4a2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1512873100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xf67fc8284747d0dcc11525b987cf1c7075b3d145"}, {name: "weiAmount", type: "uint256", value: "50000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "315308500000000829709093"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [18678196730, 48329394532019, 35421359519844]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "1386426000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x51213d7e84e29db099e7a81e54f9dfd34d9c... )", async function( ) {
		const txOriginal = {blockNumber: "4707636", timeStamp: "1512899795", hash: "0x540f334eb3c5e87c0fb871479ccd30ef9c80224512104bcf031a540d651e3ee8", nonce: "0", blockHash: "0xf83873ed6ce7cedc6b9d73093da0a8f5dac5eae4a3d27f11c99f9fa844f8de47", transactionIndex: "20", from: "0x51213d7e84e29db099e7a81e54f9dfd34d9cfa36", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "70000000000000000000", gas: "260300", gasPrice: "90000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001caea064cf47ecefbaccb1b0314895c586d8e5cbf15974ecb1337b4070498eb9ce007815c182378209cf9e6ceddfa53873edc94cd3910cf642c5f883d7550d3ba1000000000000000000000000000000000000000000000000000000000000002c51213d7e84e29db099e7a81e54f9dfd34d9cfa36315098bbb860417baf1940c92c8014a1000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "905010", gasUsed: "214974", confirmations: "3030017"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "70000000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x51213d7e84e29db099e7a81e54f9dfd34d9cfa36315098bbb860417baf1940c92c8014a1000007d001c9c380"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xaea064cf47ecefbaccb1b0314895c586d8e5cbf15974ecb1337b4070498eb9ce"}, {type: "bytes32", name: "s", value: "0x007815c182378209cf9e6ceddfa53873edc94cd3910cf642c5f883d7550d3ba1"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x51213d7e84e29db099e7a81e54f9dfd34d9cfa36315098bbb860417baf1940c92c8014a1000007d001c9c380", "28", "0xaea064cf47ecefbaccb1b0314895c586d8e5cbf15974ecb1337b4070498eb9ce", "0x007815c182378209cf9e6ceddfa53873edc94cd3910cf642c5f883d7550d3ba1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1512899795 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x51213d7e84e29db099e7a81e54f9dfd34d9cfa36"}, {name: "weiAmount", type: "uint256", value: "70000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "441431900000001161592730"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [6555065334, 11314171251031, 47338168276129]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "3158609747777777777" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x87af85a2df9638005ccd5d87c22ef5489fe1... )", async function( ) {
		const txOriginal = {blockNumber: "4708263", timeStamp: "1512909006", hash: "0x97a29c1d1192c490eb6e1dd8b3fc5af62f335f65c955b51219f43c118f3f0110", nonce: "5", blockHash: "0x7962d0e9ec911025381fb364d0d0ec55e5d6874a96542903b503b68829a5c80f", transactionIndex: "56", from: "0x87af85a2df9638005ccd5d87c22ef5489fe101cc", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "2280000000000000000", gas: "260300", gasPrice: "50000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bd7c8a603111d3aeab16ee69b11f312a4fea00906874fd0391436d9f0259d305b1412391b46275ce937193b0aeb919c5a60f97612c4b96cb94b3398e5f0f5a1f3000000000000000000000000000000000000000000000000000000000000002c87af85a2df9638005ccd5d87c22ef5489fe101ccd3ad23eb0006432189be48d5a87de085000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1752562", gasUsed: "214910", confirmations: "3029390"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "2280000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x87af85a2df9638005ccd5d87c22ef5489fe101ccd3ad23eb0006432189be48d5a87de085000007d001c9c380"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xd7c8a603111d3aeab16ee69b11f312a4fea00906874fd0391436d9f0259d305b"}, {type: "bytes32", name: "s", value: "0x1412391b46275ce937193b0aeb919c5a60f97612c4b96cb94b3398e5f0f5a1f3"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x87af85a2df9638005ccd5d87c22ef5489fe101ccd3ad23eb0006432189be48d5a87de085000007d001c9c380", "27", "0xd7c8a603111d3aeab16ee69b11f312a4fea00906874fd0391436d9f0259d305b", "0x1412391b46275ce937193b0aeb919c5a60f97612c4b96cb94b3398e5f0f5a1f3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1512909006 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x87af85a2df9638005ccd5d87c22ef5489fe101cc"}, {name: "weiAmount", type: "uint256", value: "2280000000000000000"}, {name: "tokenAmount", type: "uint256", value: "14378067600000037834734"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [28136610297, 1056635951632, 83405687087237]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "1481353490000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x87af85a2df9638005ccd5d87c22ef5489fe1... )", async function( ) {
		const txOriginal = {blockNumber: "4708339", timeStamp: "1512910069", hash: "0x755a2ab00204d19cf8ea486399f6d35936016992e0e17d32417627ab5e3a0c97", nonce: "6", blockHash: "0x1b68a659c7c570149ad759bd583e38b81bd6167168457a4263fc461c33e82f59", transactionIndex: "94", from: "0x87af85a2df9638005ccd5d87c22ef5489fe101cc", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "2280000000000000000", gas: "260300", gasPrice: "46000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001cabf646c8b9cad968f38f45cbb967ffc48b821275e7409f393e9b813c61e8d8973344cb085be9bf3817bbb277162cbf3dbf2dd64285ff0fac32f8d8d781b968de000000000000000000000000000000000000000000000000000000000000002c87af85a2df9638005ccd5d87c22ef5489fe101cc6554f78801c243648549a989249a66b2000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4893807", gasUsed: "164759", confirmations: "3029314"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "2280000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x87af85a2df9638005ccd5d87c22ef5489fe101cc6554f78801c243648549a989249a66b2000007d001c9c380"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0xabf646c8b9cad968f38f45cbb967ffc48b821275e7409f393e9b813c61e8d897"}, {type: "bytes32", name: "s", value: "0x3344cb085be9bf3817bbb277162cbf3dbf2dd64285ff0fac32f8d8d781b968de"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x87af85a2df9638005ccd5d87c22ef5489fe101cc6554f78801c243648549a989249a66b2000007d001c9c380", "28", "0xabf646c8b9cad968f38f45cbb967ffc48b821275e7409f393e9b813c61e8d897", "0x3344cb085be9bf3817bbb277162cbf3dbf2dd64285ff0fac32f8d8d781b968de", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1512910069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x87af85a2df9638005ccd5d87c22ef5489fe101cc"}, {name: "weiAmount", type: "uint256", value: "2280000000000000000"}, {name: "tokenAmount", type: "uint256", value: "14378067600000037834734"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [13469320104, 11399674582854, 39325650446002]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "1481353490000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4708747", timeStamp: "1512915992", hash: "0x4108a9c2128027134820dee5beca107509a2501ca6ee00cfee57ae77ab7cb95b", nonce: "26", blockHash: "0x69128bdb1ac2b8d5d788b2fc65c169f5a3089b2a6dea3dace4725df42a9e6250", transactionIndex: "148", from: "0xebe87ba8cd704b70055a40c229068934477da077", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "200000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "7439030", gasUsed: "21044", confirmations: "3028906"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "200000000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1512915992 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "34907287112804166" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0xebe87ba8cd704b70055a40c229068934477d... )", async function( ) {
		const txOriginal = {blockNumber: "4708871", timeStamp: "1512917992", hash: "0xfca81da743826b2daa8b4177502b31b15ffffcb71f602f7ebef3ce43e9901c04", nonce: "27", blockHash: "0x63876b98f55e957611615477aacea8fd766f90d9e370358d94fb7df491e2384a", transactionIndex: "96", from: "0xebe87ba8cd704b70055a40c229068934477da077", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "200000000000000000000", gas: "260300", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001b032e2461087cf45fdc4075f8e5d52ca132763a3eaefa2701c34d928ac8837e237175ae363920658141655e7ae0bb71fab49471d2436181a0952c21e556302ce2000000000000000000000000000000000000000000000000000000000000002cebe87ba8cd704b70055a40c229068934477da077507a68e4b4b94ed48541d746bd443979000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5185475", gasUsed: "215038", confirmations: "3028782"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "200000000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0xebe87ba8cd704b70055a40c229068934477da077507a68e4b4b94ed48541d746bd443979000007d001c9c380"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0x032e2461087cf45fdc4075f8e5d52ca132763a3eaefa2701c34d928ac8837e23"}, {type: "bytes32", name: "s", value: "0x7175ae363920658141655e7ae0bb71fab49471d2436181a0952c21e556302ce2"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0xebe87ba8cd704b70055a40c229068934477da077507a68e4b4b94ed48541d746bd443979000007d001c9c380", "27", "0x032e2461087cf45fdc4075f8e5d52ca132763a3eaefa2701c34d928ac8837e23", "0x7175ae363920658141655e7ae0bb71fab49471d2436181a0952c21e556302ce2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1512917992 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0xebe87ba8cd704b70055a40c229068934477da077"}, {name: "weiAmount", type: "uint256", value: "200000000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1261234000000003318836372"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [10697382737, 856771383467, 66022633339257]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "34907287112804166" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x9cc9c3de8e710781983a65b90b7efeaad2d3... )", async function( ) {
		const txOriginal = {blockNumber: "4714740", timeStamp: "1513005201", hash: "0xb183ae31a248ac3675b2708dfb3c7cb021ce7067cb3fa737d2a0a5ea34de762c", nonce: "187", blockHash: "0x32dc5ddd558c51a4239b5163032c2e84b8764091598349347f10eba993973585", transactionIndex: "89", from: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "220000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001bea85465f293f88687eff99eb65b9da334ef2dedcd5f222a1cbcbc3c74be8035412b2a146cb2b340e24392e2aad02e4eb6cbe2ed5260415a3cd6e386ef1ce4bcc000000000000000000000000000000000000000000000000000000000000002c9cc9c3de8e710781983a65b90b7efeaad2d3d7d8fbfe8d278be7496791b5c1b850d6b0f6000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5587189", gasUsed: "164823", confirmations: "3022913"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "220000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8fbfe8d278be7496791b5c1b850d6b0f6000007d001c9c380"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xea85465f293f88687eff99eb65b9da334ef2dedcd5f222a1cbcbc3c74be80354"}, {type: "bytes32", name: "s", value: "0x12b2a146cb2b340e24392e2aad02e4eb6cbe2ed5260415a3cd6e386ef1ce4bcc"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8fbfe8d278be7496791b5c1b850d6b0f6000007d001c9c380", "27", "0xea85465f293f88687eff99eb65b9da334ef2dedcd5f222a1cbcbc3c74be80354", "0x12b2a146cb2b340e24392e2aad02e4eb6cbe2ed5260415a3cd6e386ef1ce4bcc", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1513005201 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8"}, {name: "weiAmount", type: "uint256", value: "220000000000000000"}, {name: "tokenAmount", type: "uint256", value: "1387357400000003650720"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [33495793329, 70322081311066, 4980578463990]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "1404117226066867295" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: setPricingStrategy( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4719532", timeStamp: "1513076991", hash: "0x328f9623302dc9fdf95ec48567cecc3539f1b1daf110d44fe8eb1e5329627b75", nonce: "42", blockHash: "0x1fe535f994e8ca27a347f24886b8fdaac956bc56a8a9e9b86235645b7af89ef0", transactionIndex: "13", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "0", gas: "130687", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0x50c6773400000000000000000000000071e01346e052c13b386e4baaa3070b6517304ed4", contractAddress: "", cumulativeGasUsed: "396257", gasUsed: "30687", confirmations: "3018121"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_pricingStrategy", value: addressList[5]}], name: "setPricingStrategy", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setPricingStrategy(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1513076991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x\", \"0\", \"0x000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4719538", timeStamp: "1513077079", hash: "0x9335ef0b68119c893b03453f6f835f267791206f7e8854edd4a6ca678db8422b", nonce: "43", blockHash: "0xb5c5b99695b06448976decf60a6f47072a25572db879852d36219a076d33bedb", transactionIndex: "28", from: "0x083f24c0e1220179da4a752363871f3a88479624", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "10000000000000000", gas: "2111333", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2030841", gasUsed: "122052", confirmations: "3018115"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x"}, {type: "uint8", name: "v", value: "0"}, {type: "bytes32", name: "r", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}, {type: "bytes32", name: "s", value: "0x0000000000000000000000000000000000000000000000000000000000000000"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x", "0", "0x0000000000000000000000000000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000000000000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1513077079 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x083f24c0e1220179da4a752363871f3a88479624"}, {name: "weiAmount", type: "uint256", value: "10000000000000000"}, {name: "tokenAmount", type: "uint256", value: "38381199999999940981"}, {name: "customerId", type: "uint128", value: {s: 1, e: 3, c: [4096]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "995085101550000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x9cc9c3de8e710781983a65b90b7efeaad2d3... )", async function( ) {
		const txOriginal = {blockNumber: "4719576", timeStamp: "1513077616", hash: "0x4ab03cf78c2ee10c28ee391d7f1959890ab3c15b47756755ec1ab002f04cd5f3", nonce: "188", blockHash: "0xabbb344c204c56cac1dc771f5654d04a3a3756ec80b2f553b67b1eb31487d816", transactionIndex: "51", from: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "210000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001baf026563e82ced2298ffc618052e45a28aeae0c0e842f43f4aaa094428922c0708dfd31498d3b58b2b061c4a41cf3fe07c8f369a21a510baf4f3cdeef886ca7a000000000000000000000000000000000000000000000000000000000000002c9cc9c3de8e710781983a65b90b7efeaad2d3d7d8dfdfd47670c94d60867e41805744c7c6000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2452704", gasUsed: "164823", confirmations: "3018077"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "210000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8dfdfd47670c94d60867e41805744c7c6000007d001c9c380"}, {type: "uint8", name: "v", value: "27"}, {type: "bytes32", name: "r", value: "0xaf026563e82ced2298ffc618052e45a28aeae0c0e842f43f4aaa094428922c07"}, {type: "bytes32", name: "s", value: "0x08dfd31498d3b58b2b061c4a41cf3fe07c8f369a21a510baf4f3cdeef886ca7a"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8dfdfd47670c94d60867e41805744c7c6000007d001c9c380", "27", "0xaf026563e82ced2298ffc618052e45a28aeae0c0e842f43f4aaa094428922c07", "0x08dfd31498d3b58b2b061c4a41cf3fe07c8f369a21a510baf4f3cdeef886ca7a", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1513077616 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8"}, {name: "weiAmount", type: "uint256", value: "210000000000000000"}, {name: "tokenAmount", type: "uint256", value: "806005199999998760621"}, {name: "customerId", type: "uint128", value: {s: 1, e: 38, c: [29758003451, 41543376485640, 43647105157062]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "1404117226066867295" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x9cc9c3de8e710781983a65b90b7efeaad2d3... )", async function( ) {
		const txOriginal = {blockNumber: "4719617", timeStamp: "1513078255", hash: "0x4c365d6f6171052ecb781a5738de8cef94a4a955d730b3386b135867c48eecc9", nonce: "189", blockHash: "0x48a384792a6ba584600649c399f02964dbbc6313d71bfafbf8a0392fd8c52aa3", transactionIndex: "62", from: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "210000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c78abeb4f5317d7b41a1ccb6be598b9a78f3691627b143d4a0d198708a4afd88349fa71c5661938583ecc2085154d58e5883de9cc719eea70e4ac0a0ca10ecfa8000000000000000000000000000000000000000000000000000000000000002c9cc9c3de8e710781983a65b90b7efeaad2d3d7d810bbc6827d0c4784a8500f4cc3eb66de000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4727832", gasUsed: "164823", confirmations: "3018036"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "210000000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d810bbc6827d0c4784a8500f4cc3eb66de000007d001c9c380"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x78abeb4f5317d7b41a1ccb6be598b9a78f3691627b143d4a0d198708a4afd883"}, {type: "bytes32", name: "s", value: "0x49fa71c5661938583ecc2085154d58e5883de9cc719eea70e4ac0a0ca10ecfa8"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d810bbc6827d0c4784a8500f4cc3eb66de000007d001c9c380", "28", "0x78abeb4f5317d7b41a1ccb6be598b9a78f3691627b143d4a0d198708a4afd883", "0x49fa71c5661938583ecc2085154d58e5883de9cc719eea70e4ac0a0ca10ecfa8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1513078255 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x9cc9c3de8e710781983a65b90b7efeaad2d3d7d8"}, {name: "weiAmount", type: "uint256", value: "210000000000000000"}, {name: "tokenAmount", type: "uint256", value: "806005199999998760621"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [2224263370, 5677876907261, 65728570599134]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "1404117226066867295" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: buyWithKYCData( \"0x16c69f351aadc768f73c2673c02431efbfb2... )", async function( ) {
		const txOriginal = {blockNumber: "4720407", timeStamp: "1513090963", hash: "0x475aff0b5a6ac3ce4a79a318a0059ae4c2c24398f08254e6261e7f96d0f8302c", nonce: "17", blockHash: "0xd481b03cb43e687a868e3389cdb2c2c452f4c026583220c05eb66f78e3ae9f25", transactionIndex: "145", from: "0x16c69f351aadc768f73c2673c02431efbfb2e33f", to: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0", value: "230000000000000000", gas: "260300", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xd7c7159c0000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000001c81534fe09b2eeaaacc8284aa6854f2a653e679c5fd04f2eda559b8eecbd7477d2561c84073b36483a82a56b978d0d55f75ffca849ff9e3256b184c2ac686aa80000000000000000000000000000000000000000000000000000000000000002c16c69f351aadc768f73c2673c02431efbfb2e33f38a07d75b0234318a869a4a1ef5a5be6000007d001c9c3800000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7009914", gasUsed: "164823", confirmations: "3017246"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "230000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bytes", name: "dataframe", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f38a07d75b0234318a869a4a1ef5a5be6000007d001c9c380"}, {type: "uint8", name: "v", value: "28"}, {type: "bytes32", name: "r", value: "0x81534fe09b2eeaaacc8284aa6854f2a653e679c5fd04f2eda559b8eecbd7477d"}, {type: "bytes32", name: "s", value: "0x2561c84073b36483a82a56b978d0d55f75ffca849ff9e3256b184c2ac686aa80"}], name: "buyWithKYCData", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "buyWithKYCData(bytes,uint8,bytes32,bytes32)" ]( "0x16c69f351aadc768f73c2673c02431efbfb2e33f38a07d75b0234318a869a4a1ef5a5be6000007d001c9c380", "28", "0x81534fe09b2eeaaacc8284aa6854f2a653e679c5fd04f2eda559b8eecbd7477d", "0x2561c84073b36483a82a56b978d0d55f75ffca849ff9e3256b184c2ac686aa80", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1513090963 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "investor", type: "address"}, {indexed: false, name: "weiAmount", type: "uint256"}, {indexed: false, name: "tokenAmount", type: "uint256"}, {indexed: false, name: "customerId", type: "uint128"}], name: "Invested", type: "event"} ;
		console.error( "eventCallOriginal[49,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Invested", events: [{name: "investor", type: "address", value: "0x16c69f351aadc768f73c2673c02431efbfb2e33f"}, {name: "weiAmount", type: "uint256", value: "230000000000000000"}, {name: "tokenAmount", type: "uint256", value: "882767599999998642585"}, {name: "customerId", type: "uint128", value: {s: 1, e: 37, c: [7527007988, 67283229165634, 32477701069798]}}], address: "0x8ac03a3304519879e2ddb114c2eb2163043ab4b0"}] ;
		console.error( "eventResultOriginal[49,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "1216813146197036723" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
