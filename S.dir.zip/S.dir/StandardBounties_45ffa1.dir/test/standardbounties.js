const StandardBounties = artifacts.require( "./StandardBounties.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "StandardBounties" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x066128b9F7557b5398Db3D4ED141F2E64245fFA1", "0xbfDb50Dc66C8Df9fd9688D8fe5A0C34126427645", "0x0Bf4C238a25b66cd869331a692dFD0322708D7fB", "0x44Fa4780D8E07991d14a25868aE00A3E3398c425", "0x3Fa06237E441d261CD8d976E85daa4Fb5573CB70", "0x764d6F045b6ab1A60c4595144c185C5EE60Fa3df", "0x98aDE44Bd40fa5cfc35D7fd3Cab0CF679CaaB921", "0x484CA81ab83c7aa52feB5DC99F2b5B02A250Bad4", "0x480b7B1537ad5d65bB471b03565e5373a5d42495", "0x701d0ECB3BA780De7b2b36789aEC4493A426010a", "0x55e2780588aa5000F464f700D2676fD0a22Ee160", "0x839395e20bbB182fa440d08F850E6c7A8f6F0780", "0x8A16326a5E8168E8339A05Aee975c49B06E5c016", "0x0776DfB4eCfE128692d1092cbd013f36F2514cff", "0x2Dde54680D3b8EAa1c8986c71c369eA52C22a090", "0xE94327D07Fc17907b4DB788E5aDf2ed424adDff6", "0xf5B96Fc090A491C861C601f2b051FAE552194Aa3"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_bountyId", type: "uint256"}], name: "getBountyToken", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getNumBounties", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_bountyId", type: "uint256"}], name: "getBountyArbiter", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_bountyId", type: "uint256"}], name: "getBountyData", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_bountyId", type: "uint256"}, {name: "_fulfillmentId", type: "uint256"}], name: "getFulfillment", outputs: [{name: "", type: "bool"}, {name: "", type: "address"}, {name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "bounties", outputs: [{name: "issuer", type: "address"}, {name: "deadline", type: "uint256"}, {name: "data", type: "string"}, {name: "fulfillmentAmount", type: "uint256"}, {name: "arbiter", type: "address"}, {name: "paysTokens", type: "bool"}, {name: "bountyStage", type: "uint8"}, {name: "balance", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_bountyId", type: "uint256"}], name: "getBounty", outputs: [{name: "", type: "address"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bool"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_bountyId", type: "uint256"}], name: "getNumFulfillments", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_bountyId", type: "uint256"}, {indexed: false, name: "_fulfillmentId", type: "uint256"}], name: "FulfillmentUpdated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "FulfillmentAccepted", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "issuer", type: "address"}], name: "BountyKilled", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "newDeadline", type: "uint256"}], name: "DeadlineExtended", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_bountyId", type: "uint256"}, {indexed: true, name: "_newIssuer", type: "address"}], name: "IssuerTransferred", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "_bountyId", type: "uint256"}, {indexed: false, name: "_newFulfillmentAmount", type: "uint256"}], name: "PayoutIncreased", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["BountyIssued(uint256)", "BountyActivated(uint256,address)", "BountyFulfilled(uint256,address,uint256)", "FulfillmentUpdated(uint256,uint256)", "FulfillmentAccepted(uint256,address,uint256)", "BountyKilled(uint256,address)", "ContributionAdded(uint256,address,uint256)", "DeadlineExtended(uint256,uint256)", "BountyChanged(uint256)", "IssuerTransferred(uint256,address)", "PayoutIncreased(uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xe04ac09e4a49338f40cf62a51ba721823ed22f57bc4d53c6f8684bdb1be8fd10", "0xe42c1b76efa2e9aa5b354a151174590827beb1ef94bde26787491bf4e7d68a19", "0xeb70bc86dda3bbb4f37b25318d4737f2641d3e315df2f59a123c5a0619710357", "0x6e609af2c76c6673122c9a6ee1677adc2e9f20ec9979d056bf6c4f40799b9558", "0x7b9dbf959e54bb2ff6e9d505ef00d6b7fb3ce97880816181aecca973c1da31e6", "0x1b5171f0f6cd238c5b76b002b28e5c29dc3864174e7ed7f168b5e6373196d901", "0x75aecd8d57cb4b1b263271bddb4961b993924dd466e6003c254832572d8a57e1", "0x073d5fd87a7e0c2a384727f9aab2e84826370623aba582638b425a417e799a2c", "0xfb8e4f1ace1b37ebd0423cd75b120660780cc08a9414e04fe6b50f96a9482dde", "0x76a6676aed9f1a70fb8043b568311724b5e4cec1d68ff8fc9d5ab0a6fa619c17", "0x0061c78e3c7ddc2b1bfc8ba5996c63dd51b289e6ee3bd6f0e55089cf698aa692"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4458919 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4558672 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_owner", value: 3}], name: "StandardBounties", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "_bountyId", value: random.range( maxRandom )}], name: "getBountyToken", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBountyToken(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getNumBounties", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNumBounties()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_bountyId", value: random.range( maxRandom )}], name: "getBountyArbiter", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBountyArbiter(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_bountyId", value: random.range( maxRandom )}], name: "getBountyData", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBountyData(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_bountyId", value: random.range( maxRandom )}, {type: "uint256", name: "_fulfillmentId", value: random.range( maxRandom )}], name: "getFulfillment", outputs: [{name: "", type: "bool"}, {name: "", type: "address"}, {name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFulfillment(uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "bounties", outputs: [{name: "issuer", type: "address"}, {name: "deadline", type: "uint256"}, {name: "data", type: "string"}, {name: "fulfillmentAmount", type: "uint256"}, {name: "arbiter", type: "address"}, {name: "paysTokens", type: "bool"}, {name: "bountyStage", type: "uint8"}, {name: "balance", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bounties(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_bountyId", value: random.range( maxRandom )}], name: "getBounty", outputs: [{name: "", type: "address"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "bool"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBounty(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_bountyId", value: random.range( maxRandom )}], name: "getNumFulfillments", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNumFulfillments(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "StandardBounties", function( accounts ) {

	it( "TEST: StandardBounties( addressList[3] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4458919", timeStamp: "1509382218", hash: "0xbe8ec164cab188a3d76b4c55249c8359be96c737a5ac777be511dbbec62a938f", nonce: "0", blockHash: "0x463c94b2eef6604b31999c1d20baa0c673eb4e83812cec375beb2874d68a4bef", transactionIndex: "21", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: 0, value: "0", gas: "5600000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x07f9f7ba000000000000000000000000bfdb50dc66c8df9fd9688d8fe5a0c34126427645", contractAddress: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", cumulativeGasUsed: "5675766", gasUsed: "4795214", confirmations: "3273455"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_owner", value: addressList[3]}], name: "StandardBounties", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = StandardBounties.new( addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509382218 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = StandardBounties.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: issueBounty( addressList[3], \"1544573520\", `Qmbrqfj... )", async function( ) {
		const txOriginal = {blockNumber: "4458990", timeStamp: "1509383259", hash: "0xc04412888bdda8daba6851ecd368389376aacd35b912528ad0cba62bc6424701", nonce: "1", blockHash: "0x231cdf1f02ed1b574c7002abaf62286cb9f8720ec3bd4851d1c73916da0f9eb2", transactionIndex: "35", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "290067", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x788acd7e000000000000000000000000bfdb50dc66c8df9fd9688d8fe5a0c34126427645000000000000000000000000000000000000000000000000000000005c10525000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000008ac7230489e80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d627271666a75706674726273644b7775683163644c75364c6b656a6966347347776477774635713239376965000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1550199", gasUsed: "193378", confirmations: "3273384"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[3]}, {type: "uint256", name: "_deadline", value: "1544573520"}, {type: "string", name: "_data", value: `QmbrqfjupftrbsdKwuh1cdLu6Lkejif4sGwdwwF5q297ie`}, {type: "uint256", name: "_fulfillmentAmount", value: "10000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}], name: "issueBounty", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueBounty(address,uint256,string,uint256,address,bool,address)" ]( addressList[3], "1544573520", `QmbrqfjupftrbsdKwuh1cdLu6Lkejif4sGwdwwF5q297ie`, "10000000000000000000", addressList[0], false, addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509383259 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[1,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "0"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[1,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: activateBounty( \"0\", \"10000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4459018", timeStamp: "1509383701", hash: "0x70a41ca43dfb52a52a659a55e580f06d405222457cff62033bc0a3c1945d304e", nonce: "2", blockHash: "0x160d4bec76f302c5ac8e8ffe94cff1dec06154f87f62099a36e71ba5889975ff", transactionIndex: "126", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "10000000000000000000", gas: "104439", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x626a413a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008ac7230489e80000", contractAddress: "", cumulativeGasUsed: "5204886", gasUsed: "69626", confirmations: "3273356"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "0"}, {type: "uint256", name: "_value", value: "10000000000000000000"}], name: "activateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateBounty(uint256,uint256)" ]( "0", "10000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1509383701 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "0"}, {name: "issuer", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[2,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "0"}, {name: "contributor", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "value", type: "uint256", value: "10000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[2,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[3], \"1544573520\", `QmYgvGb... )", async function( ) {
		const txOriginal = {blockNumber: "4459152", timeStamp: "1509385488", hash: "0x9a6a7a3949bb2e68d8ca6f836a23b2aa949ed9832c319f181a2d2b5701a8cec7", nonce: "3", blockHash: "0x6bc47dbbefa0ef01efbc9b3a20a0ec0065168550a028a68abac6c6a72d8f2af9", transactionIndex: "122", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "5000000000000000000", gas: "318730", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d000000000000000000000000bfdb50dc66c8df9fd9688d8fe5a0c34126427645000000000000000000000000000000000000000000000000000000005c10525000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000004563918244f400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000000000000000000000000000000000000000002e516d59677647627245354d57424c676d657157585934647033614c486f746a4672655357364e5744483869333176000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5173411", gasUsed: "212487", confirmations: "3273222"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[3]}, {type: "uint256", name: "_deadline", value: "1544573520"}, {type: "string", name: "_data", value: `QmYgvGbrE5MWBLgmeqWXY4dp3aLHotjFreSW6NWDH8i31v`}, {type: "uint256", name: "_fulfillmentAmount", value: "5000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}, {type: "uint256", name: "_value", value: "5000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[3], "1544573520", `QmYgvGbrE5MWBLgmeqWXY4dp3aLHotjFreSW6NWDH8i31v`, "5000000000000000000", addressList[0], false, addressList[0], "5000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1509385488 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "1"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "1"}, {name: "issuer", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[3,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "1"}, {name: "contributor", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "value", type: "uint256", value: "5000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[3,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[3], \"1544573520\", `QmRaxNF... )", async function( ) {
		const txOriginal = {blockNumber: "4459164", timeStamp: "1509385647", hash: "0xa1a44bbc3b396ce751cf4f11d60fbd852629b2914e46ee77cb936c8493502e4e", nonce: "4", blockHash: "0xbf11953fc368f17827a6c8af195125482961ef52f3568d6f0f34ae3d91b8128e", transactionIndex: "72", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "2500000000000000000", gas: "318730", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d000000000000000000000000bfdb50dc66c8df9fd9688d8fe5a0c34126427645000000000000000000000000000000000000000000000000000000005c105250000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000022b1c8c1227a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022b1c8c1227a0000000000000000000000000000000000000000000000000000000000000000002e516d5261784e466474656b59464c633556544b70417573747447376369594348466a3636587a6d51744175684e4d000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3556351", gasUsed: "212487", confirmations: "3273210"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "2500000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[3]}, {type: "uint256", name: "_deadline", value: "1544573520"}, {type: "string", name: "_data", value: `QmRaxNFdtekYFLc5VTKpAusttG7ciYCHFj66XzmQtAuhNM`}, {type: "uint256", name: "_fulfillmentAmount", value: "2500000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}, {type: "uint256", name: "_value", value: "2500000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[3], "1544573520", `QmRaxNFdtekYFLc5VTKpAusttG7ciYCHFj66XzmQtAuhNM`, "2500000000000000000", addressList[0], false, addressList[0], "2500000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509385647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "2"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "2"}, {name: "issuer", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[4,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "2"}, {name: "contributor", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "value", type: "uint256", value: "2500000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[4,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[3], \"1544573520\", `QmXGFY7... )", async function( ) {
		const txOriginal = {blockNumber: "4459179", timeStamp: "1509385889", hash: "0x98a7518c9077a3766b96f9044264e8d4ef92353f9bebcadb2c66950637cb370a", nonce: "5", blockHash: "0xd531c18df57095c6554474b1773e734f7116fc67c49f9e48d3c64e5109569261", transactionIndex: "51", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "1000000000000000000", gas: "318730", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d000000000000000000000000bfdb50dc66c8df9fd9688d8fe5a0c34126427645000000000000000000000000000000000000000000000000000000005c10525000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000002e516d58474659374a656e515154446e5a676963587a73677368565459324148596b78336431595a75713447445946000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2105489", gasUsed: "212487", confirmations: "3273195"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[3]}, {type: "uint256", name: "_deadline", value: "1544573520"}, {type: "string", name: "_data", value: `QmXGFY7JenQQTDnZgicXzsgshVTY2AHYkx3d1YZuq4GDYF`}, {type: "uint256", name: "_fulfillmentAmount", value: "1000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[3], "1544573520", `QmXGFY7JenQQTDnZgicXzsgshVTY2AHYkx3d1YZuq4GDYF`, "1000000000000000000", addressList[0], false, addressList[0], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509385889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "3"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "3"}, {name: "issuer", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[5,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "3"}, {name: "contributor", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[5,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[3], \"1157920892373161954235... )", async function( ) {
		const txOriginal = {blockNumber: "4459233", timeStamp: "1509386591", hash: "0x0fe39d8d1a4ca394db221cfab847259a496c76a98d72e3f3fbfb9913473d9502", nonce: "6", blockHash: "0x5e8605cffea90c3ed0fd15279a8b7c0e8c6402c3583ee614d47aac64ce0aca30", transactionIndex: "66", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "3000000000000000000", gas: "321418", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d000000000000000000000000bfdb50dc66c8df9fd9688d8fe5a0c34126427645ffffffffffffffffffffffffffffffffffffffffffffffffffffffff9ee60c50000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000029a2241af62c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000029a2241af62c0000000000000000000000000000000000000000000000000000000000000000002e516d506b42356b79506848787164387338693638547a4773376a5a42576168434a50475a62525870507773505a6a000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2805458", gasUsed: "214279", confirmations: "3273141"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "3000000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[3]}, {type: "uint256", name: "_deadline", value: "115792089237316195423570985008687907853269984665640564039457584007911500549200"}, {type: "string", name: "_data", value: `QmPkB5kyPhHxqd8s8i68TzGs7jZBWahCJPGZbRXpPwsPZj`}, {type: "uint256", name: "_fulfillmentAmount", value: "3000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}, {type: "uint256", name: "_value", value: "3000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[3], "115792089237316195423570985008687907853269984665640564039457584007911500549200", `QmPkB5kyPhHxqd8s8i68TzGs7jZBWahCJPGZbRXpPwsPZj`, "3000000000000000000", addressList[0], false, addressList[0], "3000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1509386591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "4"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "4"}, {name: "issuer", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[6,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "4"}, {name: "contributor", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "value", type: "uint256", value: "3000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[6,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[4], \"1510362060\", `QmZysxB... )", async function( ) {
		const txOriginal = {blockNumber: "4460130", timeStamp: "1509398939", hash: "0x504c0727279c5168bc6b6b0b9aa07eee43a1f7655f826c5b555b8fdc7fd66d54", nonce: "1", blockHash: "0xbd1980cc41ded43667d281280a684d8773ee396888359129455daf5760008e0d", transactionIndex: "84", from: "0x0bf4c238a25b66cd869331a692dfd0322708d7fb", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "150000000000000000", gas: "318730", gasPrice: "4200000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d0000000000000000000000000bf4c238a25b66cd869331a692dfd0322708d7fb000000000000000000000000000000000000000000000000000000005a064bcc00000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000214e8348c4f00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000214e8348c4f0000000000000000000000000000000000000000000000000000000000000000002e516d5a79737842775a625374514b46525a7545464d794856414a5468474a72636d6f43694b356d4a3848364c7839000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3877221", gasUsed: "212487", confirmations: "3272244"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "150000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[4]}, {type: "uint256", name: "_deadline", value: "1510362060"}, {type: "string", name: "_data", value: `QmZysxBwZbStQKFRZuEFMyHVAJThGJrcmoCiK5mJ8H6Lx9`}, {type: "uint256", name: "_fulfillmentAmount", value: "150000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}, {type: "uint256", name: "_value", value: "150000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[4], "1510362060", `QmZysxBwZbStQKFRZuEFMyHVAJThGJrcmoCiK5mJ8H6Lx9`, "150000000000000000", addressList[0], false, addressList[0], "150000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1509398939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "5"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "5"}, {name: "issuer", type: "address", value: "0x0bf4c238a25b66cd869331a692dfd0322708d7fb"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[7,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "5"}, {name: "contributor", type: "address", value: "0x0bf4c238a25b66cd869331a692dfd0322708d7fb"}, {name: "value", type: "uint256", value: "150000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[7,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "488695975279658825" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"0\", `QmRypurKPnfaxfcbhyiXBk18jjC94jZw... )", async function( ) {
		const txOriginal = {blockNumber: "4460166", timeStamp: "1509399494", hash: "0x2ebfa291ed702af46839b13c83b0aecba72b7ac2be0cd1e1ac2401188d79461d", nonce: "2", blockHash: "0x5b93324f044aaf698effad9f6555ee17a24d3d942f97420ffea02480828f4087", transactionIndex: "109", from: "0x0bf4c238a25b66cd869331a692dfd0322708d7fb", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "207007", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x1e688c1400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d52797075724b506e66617866636268796958426b31386a6a4339346a5a774a3978357475444a344670437a33000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4016548", gasUsed: "138005", confirmations: "3272208"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "0"}, {type: "string", name: "_data", value: `QmRypurKPnfaxfcbhyiXBk18jjC94jZwJ9x5tuDJ4FpCz3`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "0", `QmRypurKPnfaxfcbhyiXBk18jjC94jZwJ9x5tuDJ4FpCz3`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1509399494 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "0"}, {name: "fulfiller", type: "address", value: "0x0bf4c238a25b66cd869331a692dfd0322708d7fb"}, {name: "_fulfillmentId", type: "uint256", value: "0"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "488695975279658825" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"3\", `QmTk83fmZndQgFvQAFwieidm66FAu94u... )", async function( ) {
		const txOriginal = {blockNumber: "4471519", timeStamp: "1509558038", hash: "0x59fa1f83a664246999be2c243022904abc3fd5220a84e9372d7b36af17e10db8", nonce: "0", blockHash: "0xb9eda12d156d97680ad538eae17dd48dba00eb74e0d953f6ab9d2ba6a80e87c4", transactionIndex: "45", from: "0x44fa4780d8e07991d14a25868ae00a3e3398c425", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "307103", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x1e688c1400000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d546b3833666d5a6e645167467651414677696569646d36364641753934756d564251554e506f783270554b56000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1649998", gasUsed: "138069", confirmations: "3260855"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "3"}, {type: "string", name: "_data", value: `QmTk83fmZndQgFvQAFwieidm66FAu94umVBQUNPox2pUKV`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "3", `QmTk83fmZndQgFvQAFwieidm66FAu94umVBQUNPox2pUKV`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1509558038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "3"}, {name: "fulfiller", type: "address", value: "0x44fa4780d8e07991d14a25868ae00a3e3398c425"}, {name: "_fulfillmentId", type: "uint256", value: "0"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "798958316500000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"4\", `QmUz6FRzoh5hvji4QF45mPY8MzDrV35Q... )", async function( ) {
		const txOriginal = {blockNumber: "4483937", timeStamp: "1509732088", hash: "0x877dcfbb8d555050467dde0376086ff7e05c879b0a1cf4d60618eb91b63f1cc9", nonce: "0", blockHash: "0xcd28683bcc3a4cb95fb016664ed21de927da82701e0f95b82505b8d39729cea1", transactionIndex: "60", from: "0x3fa06237e441d261cd8d976e85daa4fb5573cb70", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "207103", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x1e688c1400000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d557a3646527a6f683568766a6934514634356d5059384d7a4472563335516932553335335446684578574659000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3747139", gasUsed: "138069", confirmations: "3248437"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "4"}, {type: "string", name: "_data", value: `QmUz6FRzoh5hvji4QF45mPY8MzDrV35Qi2U353TFhExWFY`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "4", `QmUz6FRzoh5hvji4QF45mPY8MzDrV35Qi2U353TFhExWFY`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1509732088 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "4"}, {name: "fulfiller", type: "address", value: "0x3fa06237e441d261cd8d976e85daa4fb5573cb70"}, {name: "_fulfillmentId", type: "uint256", value: "0"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1312076760000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: acceptFulfillment( \"4\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4483952", timeStamp: "1509732342", hash: "0xac5943314b61cb895065ae01429490abec685e531ffb1f1017e77c9c8a4b44b5", nonce: "10", blockHash: "0xbee0a9347004bd3d8d6ca1ee3f16b4c9118cbb649562489e8615d372e5289000", transactionIndex: "158", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "103948", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd958349700000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6492104", gasUsed: "53887", confirmations: "3248422"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "4"}, {type: "uint256", name: "_fulfillmentId", value: "0"}], name: "acceptFulfillment", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptFulfillment(uint256,uint256)" ]( "4", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1509732342 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "FulfillmentAccepted", type: "event"} ;
		console.error( "eventCallOriginal[11,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FulfillmentAccepted", events: [{name: "bountyId", type: "uint256", value: "4"}, {name: "fulfiller", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "_fulfillmentId", type: "uint256", value: "0"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[11,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"4\", `QmRemmRchczcS6kh84MX8JMkHToVp3oJ... )", async function( ) {
		const txOriginal = {blockNumber: "4484000", timeStamp: "1509733064", hash: "0x1606e8757482f73779f242566be144cee1f34a91a88e0e3891fe3bfb602520c7", nonce: "36", blockHash: "0x9fa04d944d6b9da3386ff338b3b036dc152b03c1a803e984f6a12e96850f9921", transactionIndex: "43", from: "0x764d6f045b6ab1a60c4595144c185c5ee60fa3df", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "184603", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x1e688c1400000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d52656d6d526368637a6353366b6838344d58384a4d6b48546f5670336f4a715a78414348427a477751626839000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1828585", gasUsed: "123069", confirmations: "3248374"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "4"}, {type: "string", name: "_data", value: `QmRemmRchczcS6kh84MX8JMkHToVp3oJqZxACHBzGwQbh9`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "4", `QmRemmRchczcS6kh84MX8JMkHToVp3oJqZxACHBzGwQbh9`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1509733064 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "4"}, {name: "fulfiller", type: "address", value: "0x764d6f045b6ab1a60c4595144c185c5ee60fa3df"}, {name: "_fulfillmentId", type: "uint256", value: "1"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6920966775274927461" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[3], \"1157920892373161954235... )", async function( ) {
		const txOriginal = {blockNumber: "4485571", timeStamp: "1509754786", hash: "0x3d5235d3a278a3e033393c99fc74ba7f6c8fc5da6e28ddc190a68c03e2928011", nonce: "11", blockHash: "0xe00ec3d18452fcef49a03b811a4b0fa4925dc0196a022abfb6c470d07125c34c", transactionIndex: "35", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "250000000000000000", gas: "321322", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d000000000000000000000000bfdb50dc66c8df9fd9688d8fe5a0c34126427645ffffffffffffffffffffffffffffffffffffffffffffffffffffffffda4475880000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000003ff2e795f5000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003782dace9d90000000000000000000000000000000000000000000000000000000000000000002e516d50364a444c7467535a797a7a62584a5068666a6f5a6b446a6441616f5967314b586267656a44575673754231000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2511797", gasUsed: "214215", confirmations: "3246803"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "250000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[3]}, {type: "uint256", name: "_deadline", value: "115792089237316195423570985008687907853269984665640564039457584007912496592264"}, {type: "string", name: "_data", value: `QmP6JDLtgSZyzzbXJPhfjoZkDjdAaoYg1KXbgejDWVsuB1`}, {type: "uint256", name: "_fulfillmentAmount", value: "18000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}, {type: "uint256", name: "_value", value: "250000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[3], "115792089237316195423570985008687907853269984665640564039457584007912496592264", `QmP6JDLtgSZyzzbXJPhfjoZkDjdAaoYg1KXbgejDWVsuB1`, "18000000000000000", addressList[0], false, addressList[0], "250000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1509754786 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "6"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "issuer", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[13,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "contributor", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "value", type: "uint256", value: "250000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[13,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: killBounty( \"5\" )", async function( ) {
		const txOriginal = {blockNumber: "4496667", timeStamp: "1509907803", hash: "0x5d5a742a675ce083d7aecbe73af69e2b9904512cac94e792f40e0d878d970690", nonce: "4", blockHash: "0x15fa69ae237be85105c3ccd9836bb79333510de6d104e707a6209440cd89f0b9", transactionIndex: "41", from: "0x0bf4c238a25b66cd869331a692dfd0322708d7fb", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "67327", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x16b575090000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "1402405", gasUsed: "29082", confirmations: "3235707"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "5"}], name: "killBounty", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "killBounty(uint256)" ]( "5", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1509907803 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "issuer", type: "address"}], name: "BountyKilled", type: "event"} ;
		console.error( "eventCallOriginal[14,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyKilled", events: [{name: "bountyId", type: "uint256", value: "5"}, {name: "issuer", type: "address", value: "0x0bf4c238a25b66cd869331a692dfd0322708d7fb"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[14,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "488695975279658825" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[8], \"1512086340\", `QmTM7Pk... )", async function( ) {
		const txOriginal = {blockNumber: "4500318", timeStamp: "1509958653", hash: "0xb576f25b09ae4d694cc32a36456862496f2d533b47703f9e080e092bd0c14537", nonce: "0", blockHash: "0x49f26972221c442127a97f98e74211f1d791e6576839df111e59c9ff2ab27cae", transactionIndex: "141", from: "0x98ade44bd40fa5cfc35d7fd3cab0cf679caab921", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "1000000000000000000", gas: "318730", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d00000000000000000000000098ade44bd40fa5cfc35d7fd3cab0cf679caab921000000000000000000000000000000000000000000000000000000005a209b4400000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000002e516d544d37506b3669595570684259665242335976336e4b766f683831716a5357564658507238564b34784e5435000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5465463", gasUsed: "212487", confirmations: "3232056"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[8]}, {type: "uint256", name: "_deadline", value: "1512086340"}, {type: "string", name: "_data", value: `QmTM7Pk6iYUphBYfRB3Yv3nKvoh81qjSWVFXPr8VK4xNT5`}, {type: "uint256", name: "_fulfillmentAmount", value: "1000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[8], "1512086340", `QmTM7Pk6iYUphBYfRB3Yv3nKvoh81qjSWVFXPr8VK4xNT5`, "1000000000000000000", addressList[0], false, addressList[0], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1509958653 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "7"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "7"}, {name: "issuer", type: "address", value: "0x98ade44bd40fa5cfc35d7fd3cab0cf679caab921"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[15,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "7"}, {name: "contributor", type: "address", value: "0x98ade44bd40fa5cfc35d7fd3cab0cf679caab921"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[15,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "352677225000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"6\", `QmYC631yZp2ekmyLgtcHdCN1QkQrMTpm... )", async function( ) {
		const txOriginal = {blockNumber: "4504166", timeStamp: "1510012447", hash: "0xa8273f849742a6097b4f739ae988289f32e4ae00d87ee600cb7e6e51a00128bb", nonce: "83", blockHash: "0x7e5d52426da05260c5fb3187299d06081a216561f6ae9c6173fc8d98d8b8ee2f", transactionIndex: "10", from: "0x484ca81ab83c7aa52feb5dc99f2b5b02a250bad4", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "207103", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1e688c1400000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d5943363331795a7032656b6d794c6774634864434e31516b51724d54706d69613850777352795a6577624c56000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "408761", gasUsed: "138069", confirmations: "3228208"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "6"}, {type: "string", name: "_data", value: `QmYC631yZp2ekmyLgtcHdCN1QkQrMTpmia8PwsRyZewbLV`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "6", `QmYC631yZp2ekmyLgtcHdCN1QkQrMTpmia8PwsRyZewbLV`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510012447 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "fulfiller", type: "address", value: "0x484ca81ab83c7aa52feb5dc99f2b5b02a250bad4"}, {name: "_fulfillmentId", type: "uint256", value: "0"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "7278089293071182" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: acceptFulfillment( \"6\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4505126", timeStamp: "1510026214", hash: "0xa3b8316b9f5319a7166227bb8d911ca14ca2c8edf77a5a942feadbf7717d703e", nonce: "12", blockHash: "0xb58c29930cde89be44643a0aef91da632e392cfc54ff3210d5fc5a11000df9e3", transactionIndex: "16", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "103948", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xd958349700000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "692700", gasUsed: "68887", confirmations: "3227248"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "6"}, {type: "uint256", name: "_fulfillmentId", value: "0"}], name: "acceptFulfillment", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptFulfillment(uint256,uint256)" ]( "6", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510026214 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "FulfillmentAccepted", type: "event"} ;
		console.error( "eventCallOriginal[17,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FulfillmentAccepted", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "fulfiller", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "_fulfillmentId", type: "uint256", value: "0"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[17,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"6\", `QmSoku1KZSWmBsVRWi8xbwk3wMZuZ3yN... )", async function( ) {
		const txOriginal = {blockNumber: "4506221", timeStamp: "1510041242", hash: "0x19c25b945980c4ba74b8800cf634ecd2ec715a705a9e1bff2c509311567a50c0", nonce: "1", blockHash: "0x9aaaf8bfd5fbc94a90ef13293d2b80379a18272a660c91ccb46c851e191f505c", transactionIndex: "13", from: "0x98ade44bd40fa5cfc35d7fd3cab0cf679caab921", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "184603", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x1e688c1400000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d536f6b75314b5a53576d427356525769387862776b33774d5a755a33794e6272796a3142485571595a6b4243000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "400256", gasUsed: "123069", confirmations: "3226153"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "6"}, {type: "string", name: "_data", value: `QmSoku1KZSWmBsVRWi8xbwk3wMZuZ3yNbryj1BHUqYZkBC`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "6", `QmSoku1KZSWmBsVRWi8xbwk3wMZuZ3yNbryj1BHUqYZkBC`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510041242 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "fulfiller", type: "address", value: "0x98ade44bd40fa5cfc35d7fd3cab0cf679caab921"}, {name: "_fulfillmentId", type: "uint256", value: "1"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "352677225000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"6\", `QmZb4CPKTmG2RNBZCzQYnhhM16fKsHCa... )", async function( ) {
		const txOriginal = {blockNumber: "4507755", timeStamp: "1510062684", hash: "0xcf837c5af1e6f5edf3adc01bb69a01d2d1b2e6fe7657caf172532276bb2a8ca2", nonce: "0", blockHash: "0xe4d608ec657c02daae2a40460e5589bb44829f96608d999a49bc950e57cb602c", transactionIndex: "37", from: "0x480b7b1537ad5d65bb471b03565e5373a5d42495", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "184603", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x1e688c1400000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d5a623443504b546d4732524e425a437a51596e68684d3136664b73484361656a62504d576958534d4c4b6352000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1182686", gasUsed: "123069", confirmations: "3224619"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "6"}, {type: "string", name: "_data", value: `QmZb4CPKTmG2RNBZCzQYnhhM16fKsHCaejbPMWiXSMLKcR`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "6", `QmZb4CPKTmG2RNBZCzQYnhhM16fKsHCaejbPMWiXSMLKcR`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510062684 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "fulfiller", type: "address", value: "0x480b7b1537ad5d65bb471b03565e5373a5d42495"}, {name: "_fulfillmentId", type: "uint256", value: "2"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "29254337923933211" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: killBounty( \"7\" )", async function( ) {
		const txOriginal = {blockNumber: "4512779", timeStamp: "1510132045", hash: "0x6e5d13dd976bc56907d095ff57cefb998ea101dda435090769a4b497ba15c5a5", nonce: "2", blockHash: "0x814425625fdc4d6ce9a7e6652c7eea1f5672cbf99c9f90f9c457daa70969b06b", transactionIndex: "19", from: "0x98ade44bd40fa5cfc35d7fd3cab0cf679caab921", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "67327", gasPrice: "4787500000", isError: "0", txreceipt_status: "1", input: "0x16b575090000000000000000000000000000000000000000000000000000000000000007", contractAddress: "", cumulativeGasUsed: "595228", gasUsed: "29082", confirmations: "3219595"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "7"}], name: "killBounty", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "killBounty(uint256)" ]( "7", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510132045 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "issuer", type: "address"}], name: "BountyKilled", type: "event"} ;
		console.error( "eventCallOriginal[20,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyKilled", events: [{name: "bountyId", type: "uint256", value: "7"}, {name: "issuer", type: "address", value: "0x98ade44bd40fa5cfc35d7fd3cab0cf679caab921"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[20,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "352677225000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: acceptFulfillment( \"6\", \"1\" )", async function( ) {
		const txOriginal = {blockNumber: "4523955", timeStamp: "1510287382", hash: "0xc27a37c475c4375fda47b81134308a1d9ade03f393a9ade79d69778a5f84c23d", nonce: "14", blockHash: "0x7554535a8417ae6b6161ec98533e6570774869604dc56b085e3142905affadae", transactionIndex: "57", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "81544", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xd958349700000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1740732", gasUsed: "53951", confirmations: "3208419"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "6"}, {type: "uint256", name: "_fulfillmentId", value: "1"}], name: "acceptFulfillment", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptFulfillment(uint256,uint256)" ]( "6", "1", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510287382 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "FulfillmentAccepted", type: "event"} ;
		console.error( "eventCallOriginal[21,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FulfillmentAccepted", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "fulfiller", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "_fulfillmentId", type: "uint256", value: "1"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[21,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: acceptFulfillment( \"6\", \"2\" )", async function( ) {
		const txOriginal = {blockNumber: "4523955", timeStamp: "1510287382", hash: "0x51850fd65472d2e203d386f2012b89cde1ab5cf8246201aa7261b628e068342c", nonce: "15", blockHash: "0x7554535a8417ae6b6161ec98533e6570774869604dc56b085e3142905affadae", transactionIndex: "142", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "81544", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xd958349700000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "6547692", gasUsed: "53951", confirmations: "3208419"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "6"}, {type: "uint256", name: "_fulfillmentId", value: "2"}], name: "acceptFulfillment", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptFulfillment(uint256,uint256)" ]( "6", "2", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510287382 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "FulfillmentAccepted", type: "event"} ;
		console.error( "eventCallOriginal[22,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FulfillmentAccepted", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "fulfiller", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "_fulfillmentId", type: "uint256", value: "2"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[22,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"6\", `QmY1RNpFP3TDx1FWZ1cTY4qH6B6k7ANu... )", async function( ) {
		const txOriginal = {blockNumber: "4528012", timeStamp: "1510343808", hash: "0xd3529cf8536860407d27a71f942e8595eb100ea3861ef391b95349c2ca840ce8", nonce: "74", blockHash: "0xb6d3a91dfd0a515a69ca8499d4532b238ad72f103e713b5f13c86c64949ca84c", transactionIndex: "92", from: "0x701d0ecb3ba780de7b2b36789aec4493a426010a", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "184603", gasPrice: "1010000000", isError: "0", txreceipt_status: "1", input: "0x1e688c1400000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d5931524e704650335444783146575a316354593471483642366b37414e75455363485977365655644263554b000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5463711", gasUsed: "123069", confirmations: "3204362"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "6"}, {type: "string", name: "_data", value: `QmY1RNpFP3TDx1FWZ1cTY4qH6B6k7ANuEScHYw6VUdBcUK`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "6", `QmY1RNpFP3TDx1FWZ1cTY4qH6B6k7ANuEScHYw6VUdBcUK`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510343808 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "fulfiller", type: "address", value: "0x701d0ecb3ba780de7b2b36789aec4493a426010a"}, {name: "_fulfillmentId", type: "uint256", value: "3"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "666826349668850692" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: acceptFulfillment( \"6\", \"3\" )", async function( ) {
		const txOriginal = {blockNumber: "4535846", timeStamp: "1510451038", hash: "0x3f34a1598b12ff172c644dde2e93b7fd039911a609276321205d677e0f58dfad", nonce: "17", blockHash: "0x99225ea96f75946b8d0a980230561dac8240ae9031e252e7a281042070db873b", transactionIndex: "83", from: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "81544", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0xd958349700000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "3491910", gasUsed: "53951", confirmations: "3196528"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "6"}, {type: "uint256", name: "_fulfillmentId", value: "3"}], name: "acceptFulfillment", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptFulfillment(uint256,uint256)" ]( "6", "3", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510451038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "FulfillmentAccepted", type: "event"} ;
		console.error( "eventCallOriginal[24,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FulfillmentAccepted", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "fulfiller", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}, {name: "_fulfillmentId", type: "uint256", value: "3"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[24,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "22278963389820943224" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: issueBounty( addressList[7], \"1512000720\", `QmRJJF9... )", async function( ) {
		const txOriginal = {blockNumber: "4537324", timeStamp: "1510470745", hash: "0x32d13cbba439554d8efae8b1e2727c296efd61d7b23521ce796c3b83935665bc", nonce: "40", blockHash: "0x62e9afc5384ae21e9798f3d2f1ada68750b2badc1d7d8ce9f3dcec504bbff11a", transactionIndex: "32", from: "0x764d6f045b6ab1a60c4595144c185c5ee60fa3df", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "267567", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x788acd7e000000000000000000000000764d6f045b6ab1a60c4595144c185c5ee60fa3df000000000000000000000000000000000000000000000000000000005a1f4cd000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002e516d524a4a46395175617a326b6d3639535979447071347375364673555a4d474c5542643245346e46623252526f000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1437228", gasUsed: "178378", confirmations: "3195050"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[7]}, {type: "uint256", name: "_deadline", value: "1512000720"}, {type: "string", name: "_data", value: `QmRJJF9Quaz2km69SYyDpq4su6FsUZMGLUBd2E4nFb2RRo`}, {type: "uint256", name: "_fulfillmentAmount", value: "5000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}], name: "issueBounty", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueBounty(address,uint256,string,uint256,address,bool,address)" ]( addressList[7], "1512000720", `QmRJJF9Quaz2km69SYyDpq4su6FsUZMGLUBd2E4nFb2RRo`, "5000000000000000000", addressList[0], false, addressList[0], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510470745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "8"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6920966775274927461" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: transferIssuer( \"8\", addressList[3] )", async function( ) {
		const txOriginal = {blockNumber: "4537339", timeStamp: "1510470989", hash: "0xfd83b54f8425bd3006b623a269e63376f6e940cae1771f8321873340b513a2b8", nonce: "41", blockHash: "0x0b4929450185ecf024214487d9ebd75f870d885d0a41dfd57323ec5e895895fa", transactionIndex: "129", from: "0x764d6f045b6ab1a60c4595144c185c5ee60fa3df", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "46632", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x5d19606e0000000000000000000000000000000000000000000000000000000000000008000000000000000000000000bfdb50dc66c8df9fd9688d8fe5a0c34126427645", contractAddress: "", cumulativeGasUsed: "2793549", gasUsed: "31088", confirmations: "3195035"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "8"}, {type: "address", name: "_newIssuer", value: addressList[3]}], name: "transferIssuer", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "transferIssuer(uint256,address)" ]( "8", addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510470989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_bountyId", type: "uint256"}, {indexed: true, name: "_newIssuer", type: "address"}], name: "IssuerTransferred", type: "event"} ;
		console.error( "eventCallOriginal[26,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "IssuerTransferred", events: [{name: "_bountyId", type: "uint256", value: "8"}, {name: "_newIssuer", type: "address", value: "0xbfdb50dc66c8df9fd9688d8fe5a0c34126427645"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[26,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "6920966775274927461" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[12], \"1526216400\", `QmZcBE... )", async function( ) {
		const txOriginal = {blockNumber: "4546767", timeStamp: "1510602484", hash: "0xbed23568fcd158c37b4f988a287a3d3cf0f123bad6cd5936d78a83a40ac75846", nonce: "44", blockHash: "0x6b71e1cae323c17b769d07c9da9b2fd48ddaa81edf1de60f736b2bb791dc5125", transactionIndex: "21", from: "0x55e2780588aa5000f464f700d2676fd0a22ee160", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "1000000000000000000", gas: "318538", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d00000000000000000000000055e2780588aa5000f464f700d2676fd0a22ee160000000000000000000000000000000000000000000000000000000005af836d000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000de0b6b3a76400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000002e516d5a63424547753254713567726a67746d3968557546476235757a75435a374a63434e673451475238777a6767000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "851130", gasUsed: "212359", confirmations: "3185607"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[12]}, {type: "uint256", name: "_deadline", value: "1526216400"}, {type: "string", name: "_data", value: `QmZcBEGu2Tq5grjgtm9hUuFGb5uzuCZ7JcCNg4QGR8wzgg`}, {type: "uint256", name: "_fulfillmentAmount", value: "1000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: false}, {type: "address", name: "_tokenContract", value: addressList[0]}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[12], "1526216400", `QmZcBEGu2Tq5grjgtm9hUuFGb5uzuCZ7JcCNg4QGR8wzgg`, "1000000000000000000", addressList[0], false, addressList[0], "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510602484 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "9"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "9"}, {name: "issuer", type: "address", value: "0x55e2780588aa5000f464f700d2676fd0a22ee160"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[27,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "9"}, {name: "contributor", type: "address", value: "0x55e2780588aa5000f464f700d2676fd0a22ee160"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[27,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "7082413451811931861" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: contribute( \"9\", \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4547118", timeStamp: "1510607344", hash: "0x3f27eb355c3f6544ca1c1aca0cf2d2b64bf76d2bf6292a51a2b40e8549a3e7b3", nonce: "1264", blockHash: "0xcb278a973370d2b1ba0cd9e0f25d1329ccb11d7ddca21c9df5ba2362d59ff2d3", transactionIndex: "112", from: "0x839395e20bbb182fa440d08f850e6c7a8f6f0780", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "50000000000000000", gas: "47677", gasPrice: "100000000", isError: "0", txreceipt_status: "1", input: "0x8c590917000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "6682701", gasUsed: "31785", confirmations: "3185256"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "9"}, {type: "uint256", name: "_value", value: "50000000000000000"}], name: "contribute", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "contribute(uint256,uint256)" ]( "9", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510607344 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[28,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "9"}, {name: "contributor", type: "address", value: "0x839395e20bbb182fa440d08f850e6c7a8f6f0780"}, {name: "value", type: "uint256", value: "50000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[28,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "32474058800498165913" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"6\", `QmRHMZ7udyQ5EGhS9kjoCko3imDoqyBz... )", async function( ) {
		const txOriginal = {blockNumber: "4547241", timeStamp: "1510609032", hash: "0x959ee36294674dd9b971373c891b35825f2a7e26ffd71bc27090151d4e3774f9", nonce: "39", blockHash: "0xf281e4f1425185d5075d119b8562901fafd2f2cc74eab97565f86670b56b1b57", transactionIndex: "78", from: "0x8a16326a5e8168e8339a05aee975c49b06e5c016", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "184603", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x1e688c1400000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d52484d5a37756479513545476853396b6a6f436b6f33696d446f7179427a3252376f7038397661716f374454000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2420175", gasUsed: "123069", confirmations: "3185133"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "6"}, {type: "string", name: "_data", value: `QmRHMZ7udyQ5EGhS9kjoCko3imDoqyBz2R7op89vaqo7DT`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "6", `QmRHMZ7udyQ5EGhS9kjoCko3imDoqyBz2R7op89vaqo7DT`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510609032 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "6"}, {name: "fulfiller", type: "address", value: "0x8a16326a5e8168e8339a05aee975c49b06e5c016"}, {name: "_fulfillmentId", type: "uint256", value: "4"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "162178912204313" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: contribute( \"9\", \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4547558", timeStamp: "1510613414", hash: "0x039b7a3719b0202753baab6df19c79749ee8450624b1353781ced074cae98075", nonce: "21", blockHash: "0x44e06730a6d6a16ac122e052668019f5ae3175d33283a67ae00b657037793d41", transactionIndex: "44", from: "0x0776dfb4ecfe128692d1092cbd013f36f2514cff", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "50000000000000000", gas: "47677", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x8c590917000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "1646945", gasUsed: "31785", confirmations: "3184816"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "50000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "9"}, {type: "uint256", name: "_value", value: "50000000000000000"}], name: "contribute", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "contribute(uint256,uint256)" ]( "9", "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510613414 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[30,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "9"}, {name: "contributor", type: "address", value: "0x0776dfb4ecfe128692d1092cbd013f36f2514cff"}, {name: "value", type: "uint256", value: "50000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[30,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "980964777046404536" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[16], \"1510660800\", `QmSWtV... )", async function( ) {
		const txOriginal = {blockNumber: "4548508", timeStamp: "1510626320", hash: "0xdaa9ddd8860b7c8e6769869fefc0979baf02519a5007c84fad4d9ed704ed64aa", nonce: "1", blockHash: "0xb063925124b308a7075c150731cc78bd7037c3ca918e75ca2df9e724f1399269", transactionIndex: "118", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "406738", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d0000000000000000000000002dde54680d3b8eaa1c8986c71c369ea52c22a090000000000000000000000000000000000000000000000000000000005a0adac00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000002b5e3af16b188000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff6000000000000000000000000000000000000000000000002b5e3af16b1880000000000000000000000000000000000000000000000000000000000000000002e516d5357745651563333704851646e436e3158455848624833384753744155456f465a5a676d6a486b5651747731000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3753290", gasUsed: "241159", confirmations: "3183866"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[16]}, {type: "uint256", name: "_deadline", value: "1510660800"}, {type: "string", name: "_data", value: `QmSWtVQV33pHQdnCn1XEXHbH38GStAUEoFZZgmjHkVQtw1`}, {type: "uint256", name: "_fulfillmentAmount", value: "50000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: true}, {type: "address", name: "_tokenContract", value: addressList[17]}, {type: "uint256", name: "_value", value: "50000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[16], "1510660800", `QmSWtVQV33pHQdnCn1XEXHbH38GStAUEoFZZgmjHkVQtw1`, "50000000000000000000", addressList[0], true, addressList[17], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510626320 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "10"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "10"}, {name: "issuer", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[31,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "10"}, {name: "contributor", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[31,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[16], \"1510660800\", `QmSWtV... )", async function( ) {
		const txOriginal = {blockNumber: "4548508", timeStamp: "1510626320", hash: "0x6af73e3e715303231a1b6299513949b6a07cd95a6ece92c9bd7ac36be3a9dc4d", nonce: "2", blockHash: "0xb063925124b308a7075c150731cc78bd7037c3ca918e75ca2df9e724f1399269", transactionIndex: "119", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "406738", gasPrice: "10000000000", isError: "0", txreceipt_status: "0", input: "0x7e9e511d0000000000000000000000002dde54680d3b8eaa1c8986c71c369ea52c22a090000000000000000000000000000000000000000000000000000000005a0adac00000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000002b5e3af16b188000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff6000000000000000000000000000000000000000000000002b5e3af16b1880000000000000000000000000000000000000000000000000000000000000000002e516d5357745651563333704851646e436e3158455848624833384753744155456f465a5a676d6a486b5651747731000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4154535", gasUsed: "401245", confirmations: "3183866"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[16]}, {type: "uint256", name: "_deadline", value: "1510660800"}, {type: "string", name: "_data", value: `QmSWtVQV33pHQdnCn1XEXHbH38GStAUEoFZZgmjHkVQtw1`}, {type: "uint256", name: "_fulfillmentAmount", value: "50000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: true}, {type: "address", name: "_tokenContract", value: addressList[17]}, {type: "uint256", name: "_value", value: "50000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[16], "1510660800", `QmSWtVQV33pHQdnCn1XEXHbH38GStAUEoFZZgmjHkVQtw1`, "50000000000000000000", addressList[0], true, addressList[17], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510626320 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: extendDeadline( \"10\", \"1510747200\" )", async function( ) {
		const txOriginal = {blockNumber: "4548709", timeStamp: "1510629252", hash: "0x00e3d0f60ec3a2f3459a0e1624192371b06b702da028437f32906e1b6c1b6c01", nonce: "3", blockHash: "0xfeb71f7e7b0b6d3f2a30f2d385d08d5ca27cc132a1c67c72ba75f1214b0a8342", transactionIndex: "28", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "45198", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x2d1fdef6000000000000000000000000000000000000000000000000000000000000000a000000000000000000000000000000000000000000000000000000005a0c2c40", contractAddress: "", cumulativeGasUsed: "1243151", gasUsed: "30132", confirmations: "3183665"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "10"}, {type: "uint256", name: "_newDeadline", value: "1510747200"}], name: "extendDeadline", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "extendDeadline(uint256,uint256)" ]( "10", "1510747200", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510629252 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "newDeadline", type: "uint256"}], name: "DeadlineExtended", type: "event"} ;
		console.error( "eventCallOriginal[33,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DeadlineExtended", events: [{name: "bountyId", type: "uint256", value: "10"}, {name: "newDeadline", type: "uint256", value: "1510747200"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[33,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: killBounty( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "4548721", timeStamp: "1510629457", hash: "0x8b561568e2f93a2300446bc29342953884156d4e0a89b6c537d5406a5e5fb743", nonce: "4", blockHash: "0x05bdc4d3510e5260e6ccb03500e678febb4199f6e9fe50063c3283d00355f068", transactionIndex: "142", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "101328", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x16b57509000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "5356714", gasUsed: "37552", confirmations: "3183653"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "10"}], name: "killBounty", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "killBounty(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510629457 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "issuer", type: "address"}], name: "BountyKilled", type: "event"} ;
		console.error( "eventCallOriginal[34,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyKilled", events: [{name: "bountyId", type: "uint256", value: "10"}, {name: "issuer", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[34,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[16], \"1514764800\", `QmQrRb... )", async function( ) {
		const txOriginal = {blockNumber: "4548772", timeStamp: "1510630146", hash: "0x4e3323b3caf1f99337cb844c969131cc68d8f386e41f94c7fc722d0dc566b297", nonce: "6", blockHash: "0x1adc6b1f7abda111b5eba8a568448ed678b28799a7b3ccf162384a40671ec10d", transactionIndex: "29", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "406642", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d0000000000000000000000002dde54680d3b8eaa1c8986c71c369ea52c22a090000000000000000000000000000000000000000000000000000000005a497a000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000002b5e3af16b188000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff6000000000000000000000000000000000000000000000002b5e3af16b1880000000000000000000000000000000000000000000000000000000000000000002e516d517252626d436f514d324652324b66784574354b5477334e33334165334a574759594e7056666b3135514872000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1062958", gasUsed: "241095", confirmations: "3183602"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[16]}, {type: "uint256", name: "_deadline", value: "1514764800"}, {type: "string", name: "_data", value: `QmQrRbmCoQM2FR2KfxEt5KTw3N33Ae3JWGYYNpVfk15QHr`}, {type: "uint256", name: "_fulfillmentAmount", value: "50000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: true}, {type: "address", name: "_tokenContract", value: addressList[17]}, {type: "uint256", name: "_value", value: "50000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[16], "1514764800", `QmQrRbmCoQM2FR2KfxEt5KTw3N33Ae3JWGYYNpVfk15QHr`, "50000000000000000000", addressList[0], true, addressList[17], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510630146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "11"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "11"}, {name: "issuer", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[35,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "11"}, {name: "contributor", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[35,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[16], \"1514764800\", `QmQrRb... )", async function( ) {
		const txOriginal = {blockNumber: "4548772", timeStamp: "1510630146", hash: "0x984cf27bd7db94d79ce38cd4a915c8db95ff75a4302a8d9817e875d0fa12fc90", nonce: "7", blockHash: "0x1adc6b1f7abda111b5eba8a568448ed678b28799a7b3ccf162384a40671ec10d", transactionIndex: "76", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "406642", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x7e9e511d0000000000000000000000002dde54680d3b8eaa1c8986c71c369ea52c22a090000000000000000000000000000000000000000000000000000000005a497a000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000002b5e3af16b188000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff6000000000000000000000000000000000000000000000002b5e3af16b1880000000000000000000000000000000000000000000000000000000000000000002e516d517252626d436f514d324652324b66784574354b5477334e33334165334a574759594e7056666b3135514872000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3588394", gasUsed: "401150", confirmations: "3183602"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[16]}, {type: "uint256", name: "_deadline", value: "1514764800"}, {type: "string", name: "_data", value: `QmQrRbmCoQM2FR2KfxEt5KTw3N33Ae3JWGYYNpVfk15QHr`}, {type: "uint256", name: "_fulfillmentAmount", value: "50000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: true}, {type: "address", name: "_tokenContract", value: addressList[17]}, {type: "uint256", name: "_value", value: "50000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[16], "1514764800", `QmQrRbmCoQM2FR2KfxEt5KTw3N33Ae3JWGYYNpVfk15QHr`, "50000000000000000000", addressList[0], true, addressList[17], "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510630146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: killBounty( \"11\" )", async function( ) {
		const txOriginal = {blockNumber: "4548793", timeStamp: "1510630393", hash: "0xc2b04abdb954457a6700b328abd67d17f3002469bfbadd10e87cc922786c4a13", nonce: "8", blockHash: "0x2b0e88508bf446a6aa5fc4e0f0e344412d7541ef615dfc61cb9aa0516e95b04f", transactionIndex: "43", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "101328", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x16b57509000000000000000000000000000000000000000000000000000000000000000b", contractAddress: "", cumulativeGasUsed: "1656580", gasUsed: "37552", confirmations: "3183581"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "11"}], name: "killBounty", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "killBounty(uint256)" ]( "11", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510630393 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "issuer", type: "address"}], name: "BountyKilled", type: "event"} ;
		console.error( "eventCallOriginal[37,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyKilled", events: [{name: "bountyId", type: "uint256", value: "11"}, {name: "issuer", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[37,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: issueBounty( addressList[16], \"1512086400\", `QmQe7x... )", async function( ) {
		const txOriginal = {blockNumber: "4548805", timeStamp: "1510630527", hash: "0x6568181831bbfeedfea32c36619c7d71e5ba32fa4b6823b604cfd57805aff51e", nonce: "9", blockHash: "0xd581c0add93ed3e62003d9628f47a4c746346c2846a42c95e09945856924e560", transactionIndex: "16", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "323017", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x788acd7e0000000000000000000000002dde54680d3b8eaa1c8986c71c369ea52c22a090000000000000000000000000000000000000000000000000000000005a209b8000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000002b5e3af16b188000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff6000000000000000000000000000000000000000000000000000000000000002e516d516537787875696661704b456a4b69365935637a506f5a395550536f424a565355365a58313854384e756366000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "775294", gasUsed: "215345", confirmations: "3183569"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[16]}, {type: "uint256", name: "_deadline", value: "1512086400"}, {type: "string", name: "_data", value: `QmQe7xxuifapKEjKi6Y5czPoZ9UPSoBJVSU6ZX18T8Nucf`}, {type: "uint256", name: "_fulfillmentAmount", value: "50000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: true}, {type: "address", name: "_tokenContract", value: addressList[17]}], name: "issueBounty", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueBounty(address,uint256,string,uint256,address,bool,address)" ]( addressList[16], "1512086400", `QmQe7xxuifapKEjKi6Y5czPoZ9UPSoBJVSU6ZX18T8Nucf`, "50000000000000000000", addressList[0], true, addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510630527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[38,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "12"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[38,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: activateBounty( \"12\", \"50000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4548819", timeStamp: "1510630836", hash: "0x9dc7ae723da7e286024350b68a05bbb1274c9810e29df0c87123f72d365d155f", nonce: "11", blockHash: "0x94cd2ace8c5947b5e6fb17a451135e3ef34e3bb30183a13d4d6b5fb3610b08a9", transactionIndex: "83", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "145381", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x626a413a000000000000000000000000000000000000000000000000000000000000000c000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "3563176", gasUsed: "66921", confirmations: "3183555"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "12"}, {type: "uint256", name: "_value", value: "50000000000000000000"}], name: "activateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateBounty(uint256,uint256)" ]( "12", "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510630836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "12"}, {name: "issuer", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[39,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "12"}, {name: "contributor", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[39,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: killBounty( \"12\" )", async function( ) {
		const txOriginal = {blockNumber: "4548885", timeStamp: "1510631800", hash: "0x2289bbc32bf36bb0649a518e4007e8e48296ed47b3eae72d8602e4f6283b8744", nonce: "12", blockHash: "0x403bcbfea94e436d21d38ed8bb3ad4b3975f4722e0aca628ebb4e368d811581a", transactionIndex: "21", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "78828", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x16b57509000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "1010448", gasUsed: "26276", confirmations: "3183489"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "12"}], name: "killBounty", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "killBounty(uint256)" ]( "12", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510631800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "issuer", type: "address"}], name: "BountyKilled", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyKilled", events: [{name: "bountyId", type: "uint256", value: "12"}, {name: "issuer", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: contribute( \"9\", \"1000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4552646", timeStamp: "1510685305", hash: "0x9f11e5c70dc38d104e34faf17a88fbf6e091c2004731cacbb719bff35f266d36", nonce: "45", blockHash: "0xd08de23fdfc2da5251fea1a7b700371e41d9ec61413d2ad3f029739b61ee135b", transactionIndex: "52", from: "0x55e2780588aa5000f464f700d2676fd0a22ee160", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "1000000000000000000", gas: "47773", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x8c59091700000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "1197877", gasUsed: "31849", confirmations: "3179728"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "9"}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "contribute", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "contribute(uint256,uint256)" ]( "9", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510685305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[41,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "9"}, {name: "contributor", type: "address", value: "0x55e2780588aa5000f464f700d2676fd0a22ee160"}, {name: "value", type: "uint256", value: "1000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[41,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "7082413451811931861" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: issueBounty( addressList[16], \"1512086400\", `Qmbgs2... )", async function( ) {
		const txOriginal = {blockNumber: "4553758", timeStamp: "1510700598", hash: "0x38a0157bf5c4211559a6bd490c468c0a585390fad12c9d7b01861a4a0ef9776f", nonce: "14", blockHash: "0x7f70f4839bab23bc915f21b13338b90765cef960726f64bf438f1cbbd9c1ef08", transactionIndex: "89", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "323017", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x788acd7e0000000000000000000000002dde54680d3b8eaa1c8986c71c369ea52c22a090000000000000000000000000000000000000000000000000000000005a209b8000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000002b5e3af16b188000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff6000000000000000000000000000000000000000000000000000000000000002e516d6267733256656d5168617a796a666575454a38367a7074487379654d5155417871666d62387974454c665a4b000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3458891", gasUsed: "215345", confirmations: "3178616"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[16]}, {type: "uint256", name: "_deadline", value: "1512086400"}, {type: "string", name: "_data", value: `Qmbgs2VemQhazyjfeuEJ86zptHsyeMQUAxqfmb8ytELfZK`}, {type: "uint256", name: "_fulfillmentAmount", value: "50000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: true}, {type: "address", name: "_tokenContract", value: addressList[17]}], name: "issueBounty", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueBounty(address,uint256,string,uint256,address,bool,address)" ]( addressList[16], "1512086400", `Qmbgs2VemQhazyjfeuEJ86zptHsyeMQUAxqfmb8ytELfZK`, "50000000000000000000", addressList[0], true, addressList[17], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510700598 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "13"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: changeBountyData( \"13\", `QmTjttVyPczEKNUVZSNpqzmiqb6RXgF... )", async function( ) {
		const txOriginal = {blockNumber: "4553766", timeStamp: "1510700773", hash: "0xb35768048033f7e17dba8a7b5978acbbe3225aa3cd3e3ec679105778b47c1c1e", nonce: "15", blockHash: "0x8bcc61dac8256150802147e7c4c6e3b1d6f2b4e3b1a18ca30bad55ae12c073e3", transactionIndex: "24", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "66754", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xf3d3402a000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d546a7474567950637a454b4e55565a534e70717a6d69716236525867465a42484b584a536b57314c56334770000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1158965", gasUsed: "44503", confirmations: "3178608"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "13"}, {type: "string", name: "_newData", value: `QmTjttVyPczEKNUVZSNpqzmiqb6RXgFZBHKXJSkW1LV3Gp`}], name: "changeBountyData", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeBountyData(uint256,string)" ]( "13", `QmTjttVyPczEKNUVZSNpqzmiqb6RXgFZBHKXJSkW1LV3Gp`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510700773 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyChanged", type: "event"} ;
		console.error( "eventCallOriginal[43,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyChanged", events: [{name: "bountyId", type: "uint256", value: "13"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[43,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: activateBounty( \"13\", \"50000000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "4553774", timeStamp: "1510700926", hash: "0xe72797b57a44348f1aeb4fc62dc0dc1d3ab7c5358222e0755fc7b834ef9f6986", nonce: "17", blockHash: "0xe33019e5f2506bcece5c23b1369595bd9eab2cdf74d516ba836ca260c5475551", transactionIndex: "17", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "145381", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x626a413a000000000000000000000000000000000000000000000000000000000000000d000000000000000000000000000000000000000000000002b5e3af16b1880000", contractAddress: "", cumulativeGasUsed: "893014", gasUsed: "66921", confirmations: "3178600"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "13"}, {type: "uint256", name: "_value", value: "50000000000000000000"}], name: "activateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "activateBounty(uint256,uint256)" ]( "13", "50000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510700926 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "13"}, {name: "issuer", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[44,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "13"}, {name: "contributor", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}, {name: "value", type: "uint256", value: "50000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[44,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: fulfillBounty( \"13\", `Qmbqxh2A6ueNADRFkqv5AUasd3KGdZZ... )", async function( ) {
		const txOriginal = {blockNumber: "4553893", timeStamp: "1510702622", hash: "0xf3b9f7d145385a2ca3423ce8f985a8bcd083f7926d50f53a1f0aaef2bd88abbf", nonce: "5", blockHash: "0x9231a2e150f62bd7eb13568a2ad414523e2fc1fc7e59c0783ce1882385a1c45e", transactionIndex: "54", from: "0xf5b96fc090a491c861c601f2b051fae552194aa3", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "207103", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x1e688c14000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000002e516d6271786832413675654e414452466b7176354155617364334b47645a5a366a377838734a6268466472787676000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2048298", gasUsed: "138069", confirmations: "3178481"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "13"}, {type: "string", name: "_data", value: `Qmbqxh2A6ueNADRFkqv5AUasd3KGdZZ6j7x8sJbhFdrxvv`}], name: "fulfillBounty", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "fulfillBounty(uint256,string)" ]( "13", `Qmbqxh2A6ueNADRFkqv5AUasd3KGdZZ6j7x8sJbhFdrxvv`, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510702622 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "BountyFulfilled", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyFulfilled", events: [{name: "bountyId", type: "uint256", value: "13"}, {name: "fulfiller", type: "address", value: "0xf5b96fc090a491c861c601f2b051fae552194aa3"}, {name: "_fulfillmentId", type: "uint256", value: "0"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "370150844000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: acceptFulfillment( \"13\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "4553909", timeStamp: "1510702814", hash: "0x28de2c0745dc40ca2c6a1afe520eed44b6edd347aead4cd75fab99a0b2db86c1", nonce: "18", blockHash: "0x20132950f07d3f243061b0defd2c869bfccdaa23762224f7e6a9c9a8a131602f", transactionIndex: "31", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "138535", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xd9583497000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1011821", gasUsed: "62357", confirmations: "3178465"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "13"}, {type: "uint256", name: "_fulfillmentId", value: "0"}], name: "acceptFulfillment", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "acceptFulfillment(uint256,uint256)" ]( "13", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510702814 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "fulfiller", type: "address"}, {indexed: true, name: "_fulfillmentId", type: "uint256"}], name: "FulfillmentAccepted", type: "event"} ;
		console.error( "eventCallOriginal[46,4] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FulfillmentAccepted", events: [{name: "bountyId", type: "uint256", value: "13"}, {name: "fulfiller", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}, {name: "_fulfillmentId", type: "uint256", value: "0"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[46,4] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: killBounty( \"13\" )", async function( ) {
		const txOriginal = {blockNumber: "4553924", timeStamp: "1510702989", hash: "0xd57de10f26fc1b694a2416240ec124c08683c2b0f1e0b1518a85d4e08616cfee", nonce: "20", blockHash: "0x8d4fe45aa3bca2de714f7aea6190d24f6ba3dfb8e92aa89d8b14a104316cc9bb", transactionIndex: "68", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "53151", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x16b57509000000000000000000000000000000000000000000000000000000000000000d", contractAddress: "", cumulativeGasUsed: "2476666", gasUsed: "35434", confirmations: "3178450"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "13"}], name: "killBounty", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "killBounty(uint256)" ]( "13", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510702989 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "issuer", type: "address"}], name: "BountyKilled", type: "event"} ;
		console.error( "eventCallOriginal[47,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyKilled", events: [{name: "bountyId", type: "uint256", value: "13"}, {name: "issuer", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[47,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: issueAndActivateBounty( addressList[16], \"1514764800\", `QmPkgN... )", async function( ) {
		const txOriginal = {blockNumber: "4554020", timeStamp: "1510704386", hash: "0x455241f390c7594ea9e3c2ebeec2fe78e29f8b01b0e045cf86e139fcc513d396", nonce: "22", blockHash: "0xde7356c6b06d6f480bc5ad42a560e6ea9c67986c9b8165e11a86a58d1fb57132", transactionIndex: "43", from: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "0", gas: "406642", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x7e9e511d0000000000000000000000002dde54680d3b8eaa1c8986c71c369ea52c22a090000000000000000000000000000000000000000000000000000000005a497a00000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000006c6b935b8bbd40000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e94327d07fc17907b4db788e5adf2ed424addff600000000000000000000000000000000000000000000006c6b935b8bbd400000000000000000000000000000000000000000000000000000000000000000002e516d506b674e5474774b6e4b7232356864637246344d6539455637354c63467a62727144693138386633567a4e64000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "1711866", gasUsed: "241095", confirmations: "3178354"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_issuer", value: addressList[16]}, {type: "uint256", name: "_deadline", value: "1514764800"}, {type: "string", name: "_data", value: `QmPkgNTtwKnKr25hdcrF4Me9EV75LcFzbrqDi188f3VzNd`}, {type: "uint256", name: "_fulfillmentAmount", value: "2000000000000000000000"}, {type: "address", name: "_arbiter", value: addressList[0]}, {type: "bool", name: "_paysTokens", value: true}, {type: "address", name: "_tokenContract", value: addressList[17]}, {type: "uint256", name: "_value", value: "2000000000000000000000"}], name: "issueAndActivateBounty", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "issueAndActivateBounty(address,uint256,string,uint256,address,bool,address,uint256)" ]( addressList[16], "1514764800", `QmPkgNTtwKnKr25hdcrF4Me9EV75LcFzbrqDi188f3VzNd`, "2000000000000000000000", addressList[0], true, addressList[17], "2000000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510704386 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}], name: "BountyIssued", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "BountyIssued", events: [{name: "bountyId", type: "uint256", value: "14"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: false, name: "issuer", type: "address"}], name: "BountyActivated", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BountyActivated", events: [{name: "bountyId", type: "uint256", value: "14"}, {name: "issuer", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "bountyId", type: "uint256"}, {indexed: true, name: "contributor", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "ContributionAdded", type: "event"} ;
		console.error( "eventCallOriginal[48,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "ContributionAdded", events: [{name: "bountyId", type: "uint256", value: "14"}, {name: "contributor", type: "address", value: "0x2dde54680d3b8eaa1c8986c71c369ea52c22a090"}, {name: "value", type: "uint256", value: "2000000000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[48,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "610757071253229055" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: increasePayout( \"9\", \"3100000000000000000\", \"100000... )", async function( ) {
		const txOriginal = {blockNumber: "4558672", timeStamp: "1510769191", hash: "0xd3887bebb4a493a9f70dc42a4b39e825be33c864112468e9473da3dba5860e0b", nonce: "46", blockHash: "0xd9dc8a61dd8a6a0b6ff3bae9c7ecfcc575ae3f398ec39d0af92fbd45c7140956", transactionIndex: "126", from: "0x55e2780588aa5000f464f700d2676fd0a22ee160", to: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1", value: "1000000000000000000", gas: "56365", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x422d4cd600000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000002b05699353b600000000000000000000000000000000000000000000000000000de0b6b3a7640000", contractAddress: "", cumulativeGasUsed: "4990017", gasUsed: "37577", confirmations: "3173702"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_bountyId", value: "9"}, {type: "uint256", name: "_newFulfillmentAmount", value: "3100000000000000000"}, {type: "uint256", name: "_value", value: "1000000000000000000"}], name: "increasePayout", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "increasePayout(uint256,uint256,uint256)" ]( "9", "3100000000000000000", "1000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510769191 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "_bountyId", type: "uint256"}, {indexed: false, name: "_newFulfillmentAmount", type: "uint256"}], name: "PayoutIncreased", type: "event"} ;
		console.error( "eventCallOriginal[49,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PayoutIncreased", events: [{name: "_bountyId", type: "uint256", value: "9"}, {name: "_newFulfillmentAmount", type: "uint256", value: "3100000000000000000"}], address: "0x066128b9f7557b5398db3d4ed141f2e64245ffa1"}] ;
		console.error( "eventResultOriginal[49,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "7082413451811931861" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
