const SharpeCrowdsale = artifacts.require( "./SharpeCrowdsale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "SharpeCrowdsale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x8FbBB1102E2A3DDf920808609592b4A462E29330", "0x6b3b6e23aCaCC712bC6D8531F7a239ca10AC47A3", "0x28350c8cE237BC205B990A40266b46fE65197db4", "0x762F11B6509fBb0f7a90b5BA80d3Add087bebfF5", "0x6D15a5F9c98E272686a5b241bc31516514e18B30", "0xEF2463099360a085f1f10b076Ed72Ef625497a06", "0x85026104E34d7564b6E66aFfEd28a8b13C89dCA1", "0xfE841560AaBad01b6629fdADd982e4748Df31988", "0x1D75Cf336d85d57C40760484be36EebaA8c7875F", "0x4471988e602c6D61b8589419975E2bdDDE33A1ff", "0x9d5cc807184aCFD5bF0700785929306C06DF751D", "0x9908aE5bDE01dA77ae45e75c98FC3847e4a59191", "0x33DE12b5Cf336692c6b7cfD3aAF779425067f21c", "0x00Ba2867a196F505720cd799deEd0BC023B0269c", "0x8d93558d64bF79968a6e3EDb4e8497cad4Bb731c", "0x36b90858D2092de6C35C8b8B6b4793Ccc8bd24d3", "0x485395cD94475FfF25237e917E4aa626E391c691", "0x5CC21d4D94a3c8059912C374ed5Fe3ba0A47ed0A", "0x3833F8DBDbd6bdcb6A883FF209B869148965b364", "0x016CfA059E89B3Ee0E27571BB0e49fb2b36ECCe2", "0xCaE6a12744543db923A56007583b0CF400b7Cf07", "0x09AC7A0085c3DC597Ece0b30c29dE106Ebad3020", "0xd312c6c768f1490A8D9501335a68571314E71A01", "0xcf9Cea67C3Ee640f9251aAaC1E831f80c8A24B0a", "0xD10441da08659396aECb8467182b4F0F20B9a772", "0xBfdED1ebb58C69DD17BbF68792a5e2878c49D4Fc", "0x42f6075A7f682500E44c1383cA9AeacA9D013A03", "0x75750D0BbA74ECb961Fa588873A0EF69c54361c1", "0x4f994cb35F0c11a3649E820a23d87d858D078958", "0x02c73B421d1a8CB537573aC261831c6c377c7e4f", "0x56D0C8369D41D43276ccC0DE1322D8Ce25946dde", "0x27f364a96cc92793263ee07214b38E68aCaD220F", "0xA8e36b688eC3741e18D4F9f3AFBFA7f0F9f0662A", "0x92989EB906d40c6385c9982b08C5953cbF763ab2", "0x3d1bd8b08c45fF6d41424DE1577aFd8bF4962c6E", "0x28E77e566E72151392FaCb97ceDaE8eae17f155E", "0x6065a50fc70cc8801D2a88191077530Fe296182B", "0xc8bf969D412d16E21c2aEbE390513ACB801a4201", "0xd7AEb08596C1a29c4d04f7BAE8Cc28BE8091fDcD", "0xF7172c2070746e63AacE972AA655E37497893E80", "0xA0bB4Ba19F578A63Fa3f67adaF7bbcA15CcADC45"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "FOURTH_TIER_DISCOUNT", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "totalContributions", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "etherEscrowAddress", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "trusteeAddress", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "firstTierDiscountUpperLimitEther", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "THIRD_TIER_DISCOUNT", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "closed", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "RESERVE_EXCHANGE_SHARE", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "founderTokenCount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "shpExchangeRate", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "shp", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "FOUNDER_EXCHANGE_SHARE", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "CALLER_EXCHANGE_SHARE", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "BOUNTY_EXCHANGE_SHARE", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minDiscountEther", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "thirdTierDiscountUpperLimitEther", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "allowTransfer", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "reserveTokenCount", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "secondTierDiscountUpperLimitEther", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "maxPresaleContributionEther", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "minPresaleContributionEther", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "etherPaid", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "bountyAddress", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "MAX_GAS_PRICE", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "FIRST_TIER_DISCOUNT", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "SECOND_TIER_DISCOUNT", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "approvedAddresses", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "trustee", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "caller", type: "address"}, {indexed: false, name: "contributionState", type: "uint8"}], name: "ContributionStateChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "contribution", type: "uint256"}, {indexed: false, name: "allowedContributionState", type: "uint8"}], name: "AllowedContributionCheck", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "contribution", type: "uint256"}, {indexed: false, name: "isContributionValid", type: "bool"}], name: "ValidContributionCheck", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "ContributionRefund", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "plannedContribution", type: "uint256"}, {indexed: false, name: "contributed", type: "bool"}], name: "WhitelistedUpdated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "whitelistedPlannedContributions", type: "uint256"}, {indexed: false, name: "usedContributions", type: "uint256"}], name: "WhitelistedCounterUpdated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "when", type: "uint256"}], name: "SaleClosed", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["ContributionStateChanged(address,uint8)", "AllowedContributionCheck(uint256,uint8)", "ValidContributionCheck(uint256,bool)", "DiscountApplied(uint256,uint256,uint256)", "ContributionRefund(uint256,address)", "CountersUpdated(uint256,uint256)", "WhitelistedUpdated(uint256,bool)", "WhitelistedCounterUpdated(uint256,uint256)", "Contribution(uint256,address)", "NewSale(address,uint256,uint256)", "SaleClosed(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x4aefc3c4bf42d3d9026071cf14f617b5d5c231930149d7a66cdaf13c3d9f9a23", "0xbfdeddaafd0c16da7c9295e3a4e41d980868b4b89c5dcd7dbbe6e22efca4dcec", "0x03833bae32b022ed408f736e1ab9ed9130601aaaa73bc532bff0ab0cbeb554fe", "0x4b64a00f57d42114a649ee640c2f588fb42eda271b5f1f5f84cc45bbf11d0bfd", "0xc47e9fead18fefcbc6a362cacbd625408324ecc4a82938b4bb65f86f1decb511", "0xb3ee5307b1c59408f414ff714510c9ec5850412f0a795a7bd3bb7e316a81845d", "0xde6595b27918a0919254eb94dd6c8adfb9acf5972c79f1b1237d94fdf2ff1404", "0x64916fcf54f63e4952e56f7ed7291df1804e6c768769b7408024d345e6192f2f", "0x04e75fda068b8e114d7658bdff74280a0fd65586b7e026a034eae29dd5a9e68b", "0xa3ed4207b1480804a4590a74f4b9cc310dc0fc839af8d10e2141ca3b72fd9348", "0xcb67f20f64495b30f15524c55f90201dd6571d6b5c19dac183d2aeb25315b2dc"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4528045 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4561365 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_etherEscrowAddress", value: 4}, {type: "address", name: "_bountyAddress", value: 5}, {type: "address", name: "_trusteeAddress", value: 6}, {type: "uint256", name: "_minDiscountEther", value: "5000000000000000000"}, {type: "uint256", name: "_firstTierDiscountUpperLimitEther", value: "33333333333333336000"}, {type: "uint256", name: "_secondTierDiscountUpperLimitEther", value: "166666666666666660000"}, {type: "uint256", name: "_thirdTierDiscountUpperLimitEther", value: "833333333333333400000"}, {type: "uint256", name: "_minPresaleContributionEther", value: "333333333333333300"}, {type: "uint256", name: "_maxPresaleContributionEther", value: "1666666666666666700000"}, {type: "uint256", name: "_shpExchangeRate", value: "5000"}], name: "SharpeCrowdsale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "FOURTH_TIER_DISCOUNT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "FOURTH_TIER_DISCOUNT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalContributions", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalContributions()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "etherEscrowAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "etherEscrowAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "trusteeAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "trusteeAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "firstTierDiscountUpperLimitEther", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "firstTierDiscountUpperLimitEther()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "THIRD_TIER_DISCOUNT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "THIRD_TIER_DISCOUNT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "closed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "closed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "RESERVE_EXCHANGE_SHARE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "RESERVE_EXCHANGE_SHARE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "paused", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "paused()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "founderTokenCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "founderTokenCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "shpExchangeRate", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "shpExchangeRate()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "shp", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "shp()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "FOUNDER_EXCHANGE_SHARE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "FOUNDER_EXCHANGE_SHARE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CALLER_EXCHANGE_SHARE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CALLER_EXCHANGE_SHARE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "BOUNTY_EXCHANGE_SHARE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "BOUNTY_EXCHANGE_SHARE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minDiscountEther", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minDiscountEther()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "thirdTierDiscountUpperLimitEther", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "thirdTierDiscountUpperLimitEther()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "allowTransfer", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "allowTransfer()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "reserveTokenCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reserveTokenCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "secondTierDiscountUpperLimitEther", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "secondTierDiscountUpperLimitEther()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxPresaleContributionEther", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxPresaleContributionEther()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minPresaleContributionEther", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minPresaleContributionEther()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "etherPaid", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "etherPaid()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "bountyAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "bountyAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "newOwner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "newOwner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_GAS_PRICE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_GAS_PRICE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "FIRST_TIER_DISCOUNT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "FIRST_TIER_DISCOUNT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "SECOND_TIER_DISCOUNT", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "SECOND_TIER_DISCOUNT()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "approvedAddresses", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "approvedAddresses(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "trustee", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "trustee()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "SharpeCrowdsale", function( accounts ) {

	it( "TEST: SharpeCrowdsale( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4528045", timeStamp: "1510344265", hash: "0x8f409d823ab9a0452a0525a658e5f970dd94323a7fa569a65e8074b45680c3ad", nonce: "491", blockHash: "0x841951464f8d43c2ba2187a067632ab9b2ba6ce48492c4c56de4ea4c33b1711d", transactionIndex: "24", from: "0x6b3b6e23acacc712bc6d8531f7a239ca10ac47a3", to: 0, value: "0", gas: "4000000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xceb6894600000000000000000000000028350c8ce237bc205b990a40266b46fe65197db4000000000000000000000000762f11b6509fbb0f7a90b5ba80d3add087bebff50000000000000000000000006d15a5f9c98e272686a5b241bc31516514e18b300000000000000000000000000000000000000000000000004563918244f40000000000000000000000000000000000000000000000000001ce97ca0f21055fc000000000000000000000000000000000000000000000000908f6f24ba51a90a000000000000000000000000000000000000000000000002d2cd2bb7a398659c000000000000000000000000000000000000000000000000004a03ce68d21553400000000000000000000000000000000000000000000005a59a576f4730b2ce00000000000000000000000000000000000000000000000000000000000001388", contractAddress: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", cumulativeGasUsed: "2852601", gasUsed: "1790991", confirmations: "3211944"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_etherEscrowAddress", value: addressList[4]}, {type: "address", name: "_bountyAddress", value: addressList[5]}, {type: "address", name: "_trusteeAddress", value: addressList[6]}, {type: "uint256", name: "_minDiscountEther", value: "5000000000000000000"}, {type: "uint256", name: "_firstTierDiscountUpperLimitEther", value: "33333333333333336000"}, {type: "uint256", name: "_secondTierDiscountUpperLimitEther", value: "166666666666666660000"}, {type: "uint256", name: "_thirdTierDiscountUpperLimitEther", value: "833333333333333400000"}, {type: "uint256", name: "_minPresaleContributionEther", value: "333333333333333300"}, {type: "uint256", name: "_maxPresaleContributionEther", value: "1666666666666666700000"}, {type: "uint256", name: "_shpExchangeRate", value: "5000"}], name: "SharpeCrowdsale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = SharpeCrowdsale.new( addressList[4], addressList[5], addressList[6], "5000000000000000000", "33333333333333336000", "166666666666666660000", "833333333333333400000", "333333333333333300", "1666666666666666700000", "5000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1510344265 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = SharpeCrowdsale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setShp( addressList[7] )", async function( ) {
		const txOriginal = {blockNumber: "4534137", timeStamp: "1510427826", hash: "0x5a2f82a0cee910619baec2316335af7098c7243e10ee9e31b2ede70b72d038a0", nonce: "499", blockHash: "0x311b3a9f9059c3eb3cdd088fbf318780865713fa4a6311b9d4276c2457964283", transactionIndex: "17", from: "0x6b3b6e23acacc712bc6d8531f7a239ca10ac47a3", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "0", gas: "44486", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xfa9df423000000000000000000000000ef2463099360a085f1f10b076ed72ef625497a06", contractAddress: "", cumulativeGasUsed: "1347037", gasUsed: "44486", confirmations: "3205852"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_shp", value: addressList[7]}], name: "setShp", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setShp(address)" ]( addressList[7], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1510427826 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: resumeContribution(  )", async function( ) {
		const txOriginal = {blockNumber: "4534154", timeStamp: "1510428035", hash: "0x57adabfe95468871fd453d630f5f04a908f907cf13e2cfb836c2decda81ea4df", nonce: "500", blockHash: "0xb074003d6d984cf7fcc3101ffb181ed63870b465759e5c8ef050ef97736ad24d", transactionIndex: "9", from: "0x6b3b6e23acacc712bc6d8531f7a239ca10ac47a3", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "0", gas: "27650", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0xb681f9f6", contractAddress: "", cumulativeGasUsed: "222668", gasUsed: "13825", confirmations: "3205835"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "resumeContribution", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "resumeContribution()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1510428035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4534242", timeStamp: "1510429235", hash: "0xacc2e82d1b10d0638245b8a79d3711db38b03e2593900ac7ff71fc4da9a3afba", nonce: "2", blockHash: "0x0f789b517d7b4fdaf67d4c17c6f22123833a19b9590836e56ced3d6226335fa4", transactionIndex: "28", from: "0x85026104e34d7564b6e66affed28a8b13c89dca1", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "340000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1162579", gasUsed: "280307", confirmations: "3205747"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "340000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1510429235 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokens", type: "uint256", value: "680000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[3,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "340000000000000000"}, {name: "totalContributions", type: "uint256", value: "340000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[3,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[3,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "_caller", type: "address", value: "0x85026104e34d7564b6e66affed28a8b13c89dca1"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[3,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[3,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x85026104e34d7564b6e66affed28a8b13c89dca1"}, {name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "680000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "850000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "170000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[3,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "1348283878348747" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4534257", timeStamp: "1510429479", hash: "0xb53a8dac0b2ce8bf1cc17152c9d24feff0a6b23aa28222381aa7710e42b3b2ba", nonce: "4", blockHash: "0x6323042ab1415b3bf1ad25495b7cfab444751385d8ef44eac8bb70458c144541", transactionIndex: "14", from: "0xfe841560aabad01b6629fdadd982e4748df31988", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "340000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "619071", gasUsed: "232637", confirmations: "3205732"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "340000000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1510429479 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokens", type: "uint256", value: "680000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[4,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "680000000000000000"}, {name: "totalContributions", type: "uint256", value: "340000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[4,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[4,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "_caller", type: "address", value: "0xfe841560aabad01b6629fdadd982e4748df31988"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[4,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[4,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xfe841560aabad01b6629fdadd982e4748df31988"}, {name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "680000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "850000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "170000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[4,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "901166130854398" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4534845", timeStamp: "1510437212", hash: "0xd5a42aec815281031f35fdf07ca39f6fc0ad694c835e5685dc07247fe973f769", nonce: "13", blockHash: "0xbcd9072b2f8bcb6dc13748e632805a9f59dd8bb52d24ae4b3c3666de4e38af8c", transactionIndex: "31", from: "0x1d75cf336d85d57c40760484be36eebaa8c7875f", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "500000000000000000", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1406985", gasUsed: "232637", confirmations: "3205144"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1510437212 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[5,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "500000000000000000"}, {name: "tokens", type: "uint256", value: "1000000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[5,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[5,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "1180000000000000000"}, {name: "totalContributions", type: "uint256", value: "500000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[5,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[5,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "500000000000000000"}, {name: "_caller", type: "address", value: "0x1d75cf336d85d57c40760484be36eebaa8c7875f"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[5,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[5,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x1d75cf336d85d57c40760484be36eebaa8c7875f"}, {name: "etherAmount", type: "uint256", value: "500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1250000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "250000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[5,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1006521422100000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4534854", timeStamp: "1510437305", hash: "0x27f1287d3de699f12c25ff5bdff3c6378a046bf3daca977eceedf1b74e8b28f0", nonce: "14", blockHash: "0xf469f46387bded9af60e765a4038f1fc4f8f61bbbd83c6e06ae14be80bdce76b", transactionIndex: "70", from: "0x1d75cf336d85d57c40760484be36eebaa8c7875f", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "400000000000000000", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3110810", gasUsed: "220307", confirmations: "3205135"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1510437305 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[6,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokens", type: "uint256", value: "800000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[6,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[6,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "1580000000000000000"}, {name: "totalContributions", type: "uint256", value: "400000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[6,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[6,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "_caller", type: "address", value: "0x1d75cf336d85d57c40760484be36eebaa8c7875f"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[6,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[6,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x1d75cf336d85d57c40760484be36eebaa8c7875f"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "800000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "200000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[6,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1006521422100000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4538364", timeStamp: "1510485152", hash: "0x85b5ad14219aea7e2b949814be89506933be49eea46e93f54a76318666c9c959", nonce: "3", blockHash: "0xcc1cc400c068dc36919e53022ddf73a6707bca86eb65d6940279df5abcca89e2", transactionIndex: "23", from: "0x4471988e602c6d61b8589419975e2bddde33a1ff", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "5040000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1404027", gasUsed: "232407", confirmations: "3201625"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "5040000000000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1510485152 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[7,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "5040000000000000000"}, {name: "tokens", type: "uint256", value: "10080000000000000000000"}, {name: "discount", type: "uint256", value: "504000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[7,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[7,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "6620000000000000000"}, {name: "totalContributions", type: "uint256", value: "5040000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[7,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[7,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "5040000000000000000"}, {name: "_caller", type: "address", value: "0x4471988e602c6d61b8589419975e2bddde33a1ff"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[7,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[7,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x4471988e602c6d61b8589419975e2bddde33a1ff"}, {name: "etherAmount", type: "uint256", value: "5040000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "10584000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "5040000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "12600000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "5040000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2520000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[7,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "274292269219327" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4538558", timeStamp: "1510487715", hash: "0xd523d032f5d8c41d5fb6016e1b705970054c5979c899f03432ae6f94fe9dd965", nonce: "24", blockHash: "0xd779d9eec0c736fa21e28cf7309c73826ebf9237b7dc8353928c8e53df79afad", transactionIndex: "47", from: "0x9d5cc807184acfd5bf0700785929306c06df751d", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "650000000000000000", gas: "500000", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2515338", gasUsed: "232637", confirmations: "3201431"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "650000000000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1510487715 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[8,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "650000000000000000"}, {name: "tokens", type: "uint256", value: "1300000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[8,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[8,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "7270000000000000000"}, {name: "totalContributions", type: "uint256", value: "650000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[8,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[8,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "650000000000000000"}, {name: "_caller", type: "address", value: "0x9d5cc807184acfd5bf0700785929306c06df751d"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[8,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[8,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x9d5cc807184acfd5bf0700785929306c06df751d"}, {name: "etherAmount", type: "uint256", value: "650000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1300000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "650000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1625000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "650000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "325000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[8,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "117682706137055277" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4538805", timeStamp: "1510490998", hash: "0xdc629619deb2ad3bffea5189ebf70c859933e86977ff70de1ed5ad1ba5bbc18d", nonce: "9", blockHash: "0x2758654272de7d8f5ec7374c0721e84d278763885cb259e481cb81e5c2e4829a", transactionIndex: "10", from: "0x9908ae5bde01da77ae45e75c98fc3847e4a59191", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "1200000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "555877", gasUsed: "232637", confirmations: "3201184"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "1200000000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1510490998 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[9,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "1200000000000000000"}, {name: "tokens", type: "uint256", value: "2400000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[9,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[9,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "8470000000000000000"}, {name: "totalContributions", type: "uint256", value: "1200000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[9,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[9,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "1200000000000000000"}, {name: "_caller", type: "address", value: "0x9908ae5bde01da77ae45e75c98fc3847e4a59191"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[9,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[9,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x9908ae5bde01da77ae45e75c98fc3847e4a59191"}, {name: "etherAmount", type: "uint256", value: "1200000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2400000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "1200000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "3000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "1200000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "600000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[9,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4538806", timeStamp: "1510491010", hash: "0xdf6da58f0a4db360a1c5d55afaa7149d7c759ad899e4a07a2d8e9fa44f3398a7", nonce: "34620", blockHash: "0x6a695890591ce15daef389f1f359096814845247e7e62271e93c308ad15db7b2", transactionIndex: "16", from: "0x33de12b5cf336692c6b7cfd3aaf779425067f21c", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "340000000000000000", gas: "150000", gasPrice: "60000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "426251", gasUsed: "21959", confirmations: "3201183"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "340000000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1510491010 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "11156978223996344870228" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4539611", timeStamp: "1510502729", hash: "0x3128a881b9b980266eaa5317b3393d05d3a7dbdcd0bc6d31bfdb28154d5d8d30", nonce: "15", blockHash: "0x603fe4cb1740c75489af2f69f6bb894f523014160b8c46bac52e00555b8cd78f", transactionIndex: "58", from: "0x1d75cf336d85d57c40760484be36eebaa8c7875f", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "200000000000000000", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2129548", gasUsed: "220307", confirmations: "3200378"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "200000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1510502729 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[11,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "200000000000000000"}, {name: "tokens", type: "uint256", value: "400000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[11,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[11,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "8670000000000000000"}, {name: "totalContributions", type: "uint256", value: "200000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[11,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[11,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "200000000000000000"}, {name: "_caller", type: "address", value: "0x1d75cf336d85d57c40760484be36eebaa8c7875f"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[11,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[11,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x1d75cf336d85d57c40760484be36eebaa8c7875f"}, {name: "etherAmount", type: "uint256", value: "200000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "400000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "200000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "200000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "100000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[11,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "1006521422100000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4539848", timeStamp: "1510506213", hash: "0xdbfb4beea83294206c3a1efc6e71b606b41e0f30fc09e0436fe8fc2164f727ec", nonce: "94", blockHash: "0x0c975eb564b226e5c0957065d163d73ad417bcd7f76902f9ad085e15c7078e24", transactionIndex: "107", from: "0x00ba2867a196f505720cd799deed0bc023b0269c", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "64500000000000000000", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4521179", gasUsed: "220537", confirmations: "3200141"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "64500000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1510506213 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[12,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "64500000000000000000"}, {name: "tokens", type: "uint256", value: "129000000000000000000000"}, {name: "discount", type: "uint256", value: "12900000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[12,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[12,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "73170000000000000000"}, {name: "totalContributions", type: "uint256", value: "64500000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[12,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[12,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "64500000000000000000"}, {name: "_caller", type: "address", value: "0x00ba2867a196f505720cd799deed0bc023b0269c"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[12,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[12,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x00ba2867a196f505720cd799deed0bc023b0269c"}, {name: "etherAmount", type: "uint256", value: "64500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "141900000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "64500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "161250000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "64500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "32250000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[12,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: mintTokens( \"12900000000000000000000\", addressList... )", async function( ) {
		const txOriginal = {blockNumber: "4539893", timeStamp: "1510506889", hash: "0x2cb1a8692a5bd12cf205470cf965836fa17e7c65152f9cd64d56869ef07becb1", nonce: "505", blockHash: "0xe688f308e76999b284a215484e479e137e7da6d7086dd472c2f24916533b4ddd", transactionIndex: "19", from: "0x6b3b6e23acacc712bc6d8531f7a239ca10ac47a3", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "0", gas: "90338", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x10c5b3280000000000000000000000000000000000000000000002bb4f7674deeb10000000000000000000000000000000ba2867a196f505720cd799deed0bc023b0269c", contractAddress: "", cumulativeGasUsed: "732564", gasUsed: "90338", confirmations: "3200096"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokens", value: "12900000000000000000000"}, {type: "address", name: "_destination", value: addressList[15]}], name: "mintTokens", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTokens(uint256,address)" ]( "12900000000000000000000", addressList[15], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1510506889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[13,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x00ba2867a196f505720cd799deed0bc023b0269c"}, {name: "etherAmount", type: "uint256", value: "0"}, {name: "tokensGenerated", type: "uint256", value: "12900000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[13,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4540841", timeStamp: "1510520089", hash: "0xbbc1008c5d283c9b64165f5acdaff55b8d21a39d09cfce64ae11b65c579a5103", nonce: "0", blockHash: "0x2bea9b30a202750ba70e937f36df1eefc5f544e264ef8083a626ad27bc89aa2c", transactionIndex: "10", from: "0x8d93558d64bf79968a6e3edb4e8497cad4bb731c", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "497000000000000000", gas: "21000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "341207", gasUsed: "21000", confirmations: "3199148"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "497000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "480000000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4541227", timeStamp: "1510525795", hash: "0xe9d6244915d88a5330ce365950bbac5547d89973f77fae40101ec32a7981c21a", nonce: "2", blockHash: "0x705f56f5afa60b4a7bab9a28a9cd3109ab8b110fc249403591b485b457ea76ec", transactionIndex: "47", from: "0x36b90858d2092de6c35c8b8b6b4793ccc8bd24d3", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "345000000000000000", gas: "332637", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2807193", gasUsed: "232637", confirmations: "3198762"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "345000000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1510525795 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[15,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "345000000000000000"}, {name: "tokens", type: "uint256", value: "690000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[15,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[15,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "73515000000000000000"}, {name: "totalContributions", type: "uint256", value: "345000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[15,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[15,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "345000000000000000"}, {name: "_caller", type: "address", value: "0x36b90858d2092de6c35c8b8b6b4793ccc8bd24d3"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[15,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[15,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x36b90858d2092de6c35c8b8b6b4793ccc8bd24d3"}, {name: "etherAmount", type: "uint256", value: "345000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "690000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "345000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "862500000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "345000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "172500000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[15,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "4767363000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4541270", timeStamp: "1510526426", hash: "0x5d1a4bbd15d223e5c6b5233aeff7962546a9fb30eef5012891b50240ec9d2940", nonce: "1", blockHash: "0x51aed7814f487a23a3d62d0a6481abb6c5d8f221c05319f96afd96aa5ede0719", transactionIndex: "13", from: "0x8d93558d64bf79968a6e3edb4e8497cad4bb731c", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "480000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "662417", gasUsed: "232637", confirmations: "3198719"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "480000000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1510526426 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[16,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "480000000000000000"}, {name: "tokens", type: "uint256", value: "960000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[16,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[16,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "73995000000000000000"}, {name: "totalContributions", type: "uint256", value: "480000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[16,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[16,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "480000000000000000"}, {name: "_caller", type: "address", value: "0x8d93558d64bf79968a6e3edb4e8497cad4bb731c"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[16,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[16,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x8d93558d64bf79968a6e3edb4e8497cad4bb731c"}, {name: "etherAmount", type: "uint256", value: "480000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "960000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "480000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1200000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "480000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "240000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[16,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "480000000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4541325", timeStamp: "1510527202", hash: "0x2c78dced57c9db29c8244c7fbd0ba3e3dc391d2761f6e0b569a7d3fd38f1b455", nonce: "17", blockHash: "0xb396cdd84e9b3c0a38223ac1336195862d3db1cd1e9407dfc5e26fdaf6cee831", transactionIndex: "62", from: "0x485395cd94475fff25237e917e4aa626e391c691", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "1000000000000000000", gas: "348955", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2202262", gasUsed: "232637", confirmations: "3198664"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1510527202 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[17,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokens", type: "uint256", value: "2000000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[17,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[17,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "74995000000000000000"}, {name: "totalContributions", type: "uint256", value: "1000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[17,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[17,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "_caller", type: "address", value: "0x485395cd94475fff25237e917e4aa626e391c691"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[17,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[17,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x485395cd94475fff25237e917e4aa626e391c691"}, {name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[17,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "217271797779021990" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4541337", timeStamp: "1510527356", hash: "0x5498a7d00bdcda6ba4f5e9f21ef226e49a93c0a4748d6eeb61164fe109a950fc", nonce: "22", blockHash: "0x07e3444385ae678dcaad03c2a5201668826c86dd2910c4a239c1f68e07b1eb72", transactionIndex: "1", from: "0x5cc21d4d94a3c8059912c374ed5fe3ba0a47ed0a", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "340000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "297579", gasUsed: "232637", confirmations: "3198652"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "340000000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1510527356 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[18,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokens", type: "uint256", value: "680000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[18,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[18,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "75335000000000000000"}, {name: "totalContributions", type: "uint256", value: "340000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[18,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[18,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "_caller", type: "address", value: "0x5cc21d4d94a3c8059912c374ed5fe3ba0a47ed0a"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[18,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[18,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x5cc21d4d94a3c8059912c374ed5fe3ba0a47ed0a"}, {name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "680000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "850000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "340000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "170000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[18,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "13511101050000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4542347", timeStamp: "1510541178", hash: "0xbae92f4ea7f65ade999698b70516150783a9edc3028c1f7bf3d8f691abbe288e", nonce: "590", blockHash: "0xac093a2665f5e8ad3594f86cc26b03a78aead8d23452a19607c2f5a7fb1da8ee", transactionIndex: "80", from: "0x3833f8dbdbd6bdcb6a883ff209b869148965b364", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "5000000000000000000", gas: "232637", gasPrice: "11000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2760939", gasUsed: "232637", confirmations: "3197642"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1510541178 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[19,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokens", type: "uint256", value: "10000000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[19,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[19,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "80335000000000000000"}, {name: "totalContributions", type: "uint256", value: "5000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[19,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[19,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "_caller", type: "address", value: "0x3833f8dbdbd6bdcb6a883ff209b869148965b364"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[19,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[19,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x3833f8dbdbd6bdcb6a883ff209b869148965b364"}, {name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "10000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "12500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[19,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "25495255612076492199" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: mintTokens( \"500000000000000000000\", addressList[2... )", async function( ) {
		const txOriginal = {blockNumber: "4543673", timeStamp: "1510559205", hash: "0x05cdddf5b4b084315445d3eda5484b863712c6773febd73a21b86f2685a8df76", nonce: "506", blockHash: "0xba00fcf8303691a01db7f4f7f58cc8c10c83a4e955baaf82800a037295645843", transactionIndex: "2", from: "0x6b3b6e23acacc712bc6d8531f7a239ca10ac47a3", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "0", gas: "90338", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x10c5b32800000000000000000000000000000000000000000000001b1ae4d6e2ef5000000000000000000000000000003833f8dbdbd6bdcb6a883ff209b869148965b364", contractAddress: "", cumulativeGasUsed: "148224", gasUsed: "90338", confirmations: "3196316"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokens", value: "500000000000000000000"}, {type: "address", name: "_destination", value: addressList[20]}], name: "mintTokens", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTokens(uint256,address)" ]( "500000000000000000000", addressList[20], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1510559205 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[20,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x3833f8dbdbd6bdcb6a883ff209b869148965b364"}, {name: "etherAmount", type: "uint256", value: "0"}, {name: "tokensGenerated", type: "uint256", value: "500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[20,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: pegEtherValues( \"4950000000000000000\", \"3333333333333... )", async function( ) {
		const txOriginal = {blockNumber: "4543700", timeStamp: "1510559515", hash: "0xc0ec178fd7fbccfd357a959ac652dbb687a6a47100dc829218c2ae6f98c50d0b", nonce: "507", blockHash: "0x956ad7db710f34a509ba6f0f074c356ecc7f46680c4cff8602893a355bb60067", transactionIndex: "17", from: "0x6b3b6e23acacc712bc6d8531f7a239ca10ac47a3", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "0", gas: "56282", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x86bb1b2400000000000000000000000000000000000000000000000044b1eec6162f0000000000000000000000000000000000000000000000000001ce97ca0f2105485000000000000000000000000000000000000000000000000908f6f24ba51a90a000000000000000000000000000000000000000000000002d2cd2bb7a39803f4000000000000000000000000000000000000000000000000004a03ce68d21553400000000000000000000000000000000000000000000005a59a576f4730b2ce0", contractAddress: "", cumulativeGasUsed: "656910", gasUsed: "56282", confirmations: "3196289"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minDiscountEther", value: "4950000000000000000"}, {type: "uint256", name: "_firstTierDiscountUpperLimitEther", value: "33333333333333330000"}, {type: "uint256", name: "_secondTierDiscountUpperLimitEther", value: "166666666666666660000"}, {type: "uint256", name: "_thirdTierDiscountUpperLimitEther", value: "833333333333333000000"}, {type: "uint256", name: "_minPresaleContributionEther", value: "333333333333333300"}, {type: "uint256", name: "_maxPresaleContributionEther", value: "1666666666666666700000"}], name: "pegEtherValues", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pegEtherValues(uint256,uint256,uint256,uint256,uint256,uint256)" ]( "4950000000000000000", "33333333333333330000", "166666666666666660000", "833333333333333000000", "333333333333333300", "1666666666666666700000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1510559515 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4543894", timeStamp: "1510562271", hash: "0xcc52c600d78990b6079768df503443d6af3aa89bba915039c3218904ecaf271e", nonce: "9", blockHash: "0x1be2efd4c7013759b19bca47f757112a4ab9a5e0b07b51904e904b5e0472f0a7", transactionIndex: "23", from: "0x016cfa059e89b3ee0e27571bb0e49fb2b36ecce2", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "550000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "984579", gasUsed: "232637", confirmations: "3196095"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "550000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1510562271 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[22,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "tokens", type: "uint256", value: "1100000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[22,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[22,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "80885000000000000000"}, {name: "totalContributions", type: "uint256", value: "550000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[22,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[22,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "_caller", type: "address", value: "0x016cfa059e89b3ee0e27571bb0e49fb2b36ecce2"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[22,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[22,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x016cfa059e89b3ee0e27571bb0e49fb2b36ecce2"}, {name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1100000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1375000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "275000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[22,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "5473728968893647" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4544984", timeStamp: "1510577504", hash: "0x6d5241eacb78cb050c4d12d92daf9f6a701e9bf7dc3557c5231889c9e75674d8", nonce: "0", blockHash: "0xac2fc7fd716a57d15b3bbadf5d1968706f426edd9908877c105e720c6f774b2a", transactionIndex: "69", from: "0xcae6a12744543db923a56007583b0cf400b7cf07", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "350000000000000000", gas: "232637", gasPrice: "16800000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2705424", gasUsed: "232637", confirmations: "3195005"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "350000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1510577504 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[23,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "tokens", type: "uint256", value: "700000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[23,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[23,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "81235000000000000000"}, {name: "totalContributions", type: "uint256", value: "350000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[23,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[23,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "_caller", type: "address", value: "0xcae6a12744543db923a56007583b0cf400b7cf07"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[23,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[23,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xcae6a12744543db923a56007583b0cf400b7cf07"}, {name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "700000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "875000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "175000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[23,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "67598465600000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4545169", timeStamp: "1510580001", hash: "0xf8187324623cf094ce8ccaf18427631ecf00cf0376524517b2273e5eb19f692b", nonce: "106", blockHash: "0xb89b8fefec3a53d4ca61823e5fad324d2c9e18d845c7e02c6d0cbba6ee8c232a", transactionIndex: "20", from: "0x09ac7a0085c3dc597ece0b30c29de106ebad3020", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "8000000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "843400", gasUsed: "232407", confirmations: "3194820"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "8000000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1510580001 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[24,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "8000000000000000000"}, {name: "tokens", type: "uint256", value: "16000000000000000000000"}, {name: "discount", type: "uint256", value: "800000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[24,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[24,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "89235000000000000000"}, {name: "totalContributions", type: "uint256", value: "8000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[24,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[24,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "8000000000000000000"}, {name: "_caller", type: "address", value: "0x09ac7a0085c3dc597ece0b30c29de106ebad3020"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[24,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[24,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x09ac7a0085c3dc597ece0b30c29de106ebad3020"}, {name: "etherAmount", type: "uint256", value: "8000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "16800000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "8000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "20000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "8000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "4000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[24,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "272475386846119252" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4545236", timeStamp: "1510581101", hash: "0x94aa0c7da61bbf826c2d726691ccb5c2d03ab0d948f717fb2efad07d250dc8a7", nonce: "0", blockHash: "0xf9ffe1b87b3614f34fccc6e23aac10f4a1dae5874eb8d30d63647e92fa22346e", transactionIndex: "20", from: "0xd312c6c768f1490a8d9501335a68571314e71a01", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "340000000000000000", gas: "90000", gasPrice: "20000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "874567", gasUsed: "89273", confirmations: "3194753"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[24], to: addressList[2], value: "340000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1510581101 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[24], balance: "0" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[24], balance: ( await web3.eth.getBalance( addressList[24], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4545308", timeStamp: "1510582194", hash: "0xf7b57b51399012cf0c1ccd350f49a333982702765fe20ceb79bbde4d50e98689", nonce: "0", blockHash: "0x2e992921bf6d2ac10403ba545a3226f8fb78c4285490465585cbf138cd75ac36", transactionIndex: "14", from: "0xcf9cea67c3ee640f9251aaac1e831f80c8a24b0a", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "400000000000000000", gas: "348955", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "905599", gasUsed: "232637", confirmations: "3194681"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1510582194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[26,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokens", type: "uint256", value: "800000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[26,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[26,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "89635000000000000000"}, {name: "totalContributions", type: "uint256", value: "400000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[26,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[26,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "_caller", type: "address", value: "0xcf9cea67c3ee640f9251aaac1e831f80c8a24b0a"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[26,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[26,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xcf9cea67c3ee640f9251aaac1e831f80c8a24b0a"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "800000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "200000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[26,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "3697900551000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4545346", timeStamp: "1510582647", hash: "0xa35955b7bdf60046c84696a57465b9faa9cdbac994b6f553ab021335737d0708", nonce: "1", blockHash: "0xc09126a9eaa602f38886753123b4fa7b51200481cc81d010a8a5a52f734c1192", transactionIndex: "43", from: "0xcf9cea67c3ee640f9251aaac1e831f80c8a24b0a", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "1050000000000000000", gas: "330460", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1456107", gasUsed: "220307", confirmations: "3194643"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[25], to: addressList[2], value: "1050000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1510582647 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[27,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "1050000000000000000"}, {name: "tokens", type: "uint256", value: "2100000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[27,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[27,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "90685000000000000000"}, {name: "totalContributions", type: "uint256", value: "1050000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[27,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[27,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "1050000000000000000"}, {name: "_caller", type: "address", value: "0xcf9cea67c3ee640f9251aaac1e831f80c8a24b0a"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[27,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[27,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xcf9cea67c3ee640f9251aaac1e831f80c8a24b0a"}, {name: "etherAmount", type: "uint256", value: "1050000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2100000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "1050000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2625000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "1050000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "525000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[27,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[25], balance: "3697900551000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[25], balance: ( await web3.eth.getBalance( addressList[25], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4545755", timeStamp: "1510588865", hash: "0xd834a1193d6e09db1da24304a83224b98d3b5f802710654009c745fcf48fd34b", nonce: "24", blockHash: "0xb7c389961bfb6e141526fbed8a428c386ef67a196e614ec6a93f3c0fa5d74dda", transactionIndex: "36", from: "0xd10441da08659396aecb8467182b4f0f20b9a772", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "15000000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "2635941", gasUsed: "232407", confirmations: "3194234"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[26], to: addressList[2], value: "15000000000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1510588865 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[28,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "15000000000000000000"}, {name: "tokens", type: "uint256", value: "30000000000000000000000"}, {name: "discount", type: "uint256", value: "1500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[28,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[28,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "105685000000000000000"}, {name: "totalContributions", type: "uint256", value: "15000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[28,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[28,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "15000000000000000000"}, {name: "_caller", type: "address", value: "0xd10441da08659396aecb8467182b4f0f20b9a772"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[28,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[28,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xd10441da08659396aecb8467182b4f0f20b9a772"}, {name: "etherAmount", type: "uint256", value: "15000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "31500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "15000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "37500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "15000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "7500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[28,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[26], balance: "581277237500000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[26], balance: ( await web3.eth.getBalance( addressList[26], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: mintTokens( \"145000000000000000000\", addressList[2... )", async function( ) {
		const txOriginal = {blockNumber: "4545846", timeStamp: "1510590243", hash: "0x409bd325041200e46359380f5bf345c3a590dd283bcae0b9edb92d9b1d99e430", nonce: "508", blockHash: "0x4571c44219d28e9513e5a9c9800b6f9ff579edabc8756d0fd979c00af26f3da1", transactionIndex: "20", from: "0x6b3b6e23acacc712bc6d8531f7a239ca10ac47a3", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "0", gas: "90338", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x10c5b328000000000000000000000000000000000000000000000007dc477bc1cfa40000000000000000000000000000cf9cea67c3ee640f9251aaac1e831f80c8a24b0a", contractAddress: "", cumulativeGasUsed: "543418", gasUsed: "90338", confirmations: "3194143"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_tokens", value: "145000000000000000000"}, {type: "address", name: "_destination", value: addressList[25]}], name: "mintTokens", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintTokens(uint256,address)" ]( "145000000000000000000", addressList[25], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1510590243 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[29,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xcf9cea67c3ee640f9251aaac1e831f80c8a24b0a"}, {name: "etherAmount", type: "uint256", value: "0"}, {name: "tokensGenerated", type: "uint256", value: "145000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[29,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4545984", timeStamp: "1510591941", hash: "0x6baa40a466ff7334d24bc402991c10eeed73f3a50e1bac666845e32947d13091", nonce: "1", blockHash: "0x2462453f9baef08b942ce6aa09eac7c1ccc8c53e49ca5b0bd484545eaa5675fb", transactionIndex: "17", from: "0xbfded1ebb58c69dd17bbf68792a5e2878c49d4fc", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "355629675000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "812780", gasUsed: "232637", confirmations: "3194005"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[27], to: addressList[2], value: "355629675000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1510591941 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[30,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "355629675000000000"}, {name: "tokens", type: "uint256", value: "711259350000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[30,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[30,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "106040629675000000000"}, {name: "totalContributions", type: "uint256", value: "355629675000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[30,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[30,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "355629675000000000"}, {name: "_caller", type: "address", value: "0xbfded1ebb58c69dd17bbf68792a5e2878c49d4fc"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[30,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[30,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xbfded1ebb58c69dd17bbf68792a5e2878c49d4fc"}, {name: "etherAmount", type: "uint256", value: "355629675000000000"}, {name: "tokensGenerated", type: "uint256", value: "711259350000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "355629675000000000"}, {name: "tokensGenerated", type: "uint256", value: "889074187500000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "355629675000000000"}, {name: "tokensGenerated", type: "uint256", value: "177814837500000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[30,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[27], balance: "20871898000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[27], balance: ( await web3.eth.getBalance( addressList[27], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4547801", timeStamp: "1510616625", hash: "0xc59de66032b3b02ad94bfa180dcdac24c8cee16ba165683971530238c53b1b12", nonce: "16", blockHash: "0x234e2d4b9e424b5dab693ae0ec11af3a2584e8fe94b90d676ec1edb46bd9586c", transactionIndex: "1", from: "0x42f6075a7f682500e44c1383ca9aeaca9d013a03", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "550000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "340815", gasUsed: "232637", confirmations: "3192188"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[28], to: addressList[2], value: "550000000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1510616625 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[31,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "tokens", type: "uint256", value: "1100000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[31,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[31,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "106590629675000000000"}, {name: "totalContributions", type: "uint256", value: "550000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[31,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[31,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "_caller", type: "address", value: "0x42f6075a7f682500e44c1383ca9aeaca9d013a03"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[31,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[31,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x42f6075a7f682500e44c1383ca9aeaca9d013a03"}, {name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1100000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1375000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "550000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "275000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[31,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[28], balance: "0" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[28], balance: ( await web3.eth.getBalance( addressList[28], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4547939", timeStamp: "1510618385", hash: "0x0020842fe368c05dbc13b9bf6a21a77182ee82eebbb0fd5e1f7c4c8deeee16a3", nonce: "31", blockHash: "0x3fd42421937df2140d5d97a6da84ee636da19270450af66779d5b517d2ae3cc1", transactionIndex: "12", from: "0x75750d0bba74ecb961fa588873a0ef69c54361c1", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "2500000000000000000", gas: "500000", gasPrice: "21200000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "680730", gasUsed: "232637", confirmations: "3192050"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[29], to: addressList[2], value: "2500000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1510618385 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[32,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "tokens", type: "uint256", value: "5000000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[32,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[32,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "109090629675000000000"}, {name: "totalContributions", type: "uint256", value: "2500000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[32,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[32,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "_caller", type: "address", value: "0x75750d0bba74ecb961fa588873a0ef69c54361c1"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[32,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[32,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x75750d0bba74ecb961fa588873a0ef69c54361c1"}, {name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "5000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "6250000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1250000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[32,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[29], balance: "4362270472277777777" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[29], balance: ( await web3.eth.getBalance( addressList[29], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4548427", timeStamp: "1510625160", hash: "0x2a4e8de10cd0d2553df1ea94512ac1659c967e12492826a517afbbd03d0daf21", nonce: "11", blockHash: "0x54672d9577d0ee08c96995d20997a846cf3a2671bee212f9b6f85a16e9369895", transactionIndex: "26", from: "0x4f994cb35f0c11a3649e820a23d87d858d078958", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "400000000000000000", gas: "348955", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "950862", gasUsed: "232637", confirmations: "3191562"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1510625160 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[33,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokens", type: "uint256", value: "800000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[33,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[33,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "109490629675000000000"}, {name: "totalContributions", type: "uint256", value: "400000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[33,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[33,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "_caller", type: "address", value: "0x4f994cb35f0c11a3649e820a23d87d858d078958"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[33,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[33,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x4f994cb35f0c11a3649e820a23d87d858d078958"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "800000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "200000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[33,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "5995758245824007" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4549736", timeStamp: "1510644072", hash: "0xdd7e935565248b6f24a442d495e9c9a3f6ff17b6f589dba645da6ad16fee686f", nonce: "33", blockHash: "0xdf6309dfe67f3257722e03335c23889e393526771204084ac599106dfd10fa76", transactionIndex: "3", from: "0x02c73b421d1a8cb537573ac261831c6c377c7e4f", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "2500000000000000000", gas: "232637", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "338962", gasUsed: "232637", confirmations: "3190253"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[31], to: addressList[2], value: "2500000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1510644072 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[34,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "tokens", type: "uint256", value: "5000000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[34,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[34,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "111990629675000000000"}, {name: "totalContributions", type: "uint256", value: "2500000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[34,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[34,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "_caller", type: "address", value: "0x02c73b421d1a8cb537573ac261831c6c377c7e4f"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[34,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[34,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x02c73b421d1a8cb537573ac261831c6c377c7e4f"}, {name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "5000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "6250000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "2500000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1250000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[34,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[31], balance: "136413138155708284" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[31], balance: ( await web3.eth.getBalance( addressList[31], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4549944", timeStamp: "1510646908", hash: "0x07e86715beb22db50518cd01b9678e8c8c06c4f045470eb7a4ce1f37c658606f", nonce: "0", blockHash: "0xaff78c1d59f19e0e5a67a93704f40a56349a0e0c3079ab11e91ce0bb6a8e3e3e", transactionIndex: "94", from: "0x56d0c8369d41d43276ccc0de1322d8ce25946dde", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "400000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3613833", gasUsed: "232637", confirmations: "3190045"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[32], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1510646908 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[35,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokens", type: "uint256", value: "800000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[35,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[35,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "112390629675000000000"}, {name: "totalContributions", type: "uint256", value: "400000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[35,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[35,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "_caller", type: "address", value: "0x56d0c8369d41d43276ccc0de1322d8ce25946dde"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[35,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[35,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x56d0c8369d41d43276ccc0de1322d8ce25946dde"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "800000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "200000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[35,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[32], balance: "764694623000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[32], balance: ( await web3.eth.getBalance( addressList[32], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4550630", timeStamp: "1510656224", hash: "0x40f072bcecf2715b32772007367a5fc9431d33c5c78aa0c687d176cd3e184a90", nonce: "3", blockHash: "0x86631578495cb8abc5bcb4c4935bfaa141ab88b3f6cd90f6a2bac3106933bad5", transactionIndex: "27", from: "0x27f364a96cc92793263ee07214b38e68acad220f", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "350000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1149607", gasUsed: "232637", confirmations: "3189359"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "350000000000000000" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1510656224 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[36,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "tokens", type: "uint256", value: "700000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[36,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[36,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "112740629675000000000"}, {name: "totalContributions", type: "uint256", value: "350000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[36,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[36,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "_caller", type: "address", value: "0x27f364a96cc92793263ee07214b38e68acad220f"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[36,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[36,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x27f364a96cc92793263ee07214b38e68acad220f"}, {name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "700000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "875000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "350000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "175000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[36,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "18883498661756327" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4550967", timeStamp: "1510661160", hash: "0xdb6aadaf6705f5b8b0f2d07aa87b837fa308eca4ea62832e7627ad0efd4b585b", nonce: "1", blockHash: "0x3c342e21c7397c8f4e6320542b3bb502c2426d88f997b98b6e9b721b202181f1", transactionIndex: "26", from: "0xa8e36b688ec3741e18d4f9f3afbfa7f0f9f0662a", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "4995000000000000000", gas: "50000", gasPrice: "1000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "630068", gasUsed: "49894", confirmations: "3189022"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "4995000000000000000" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1510661160 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "132802701138101609" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4551029", timeStamp: "1510662082", hash: "0xf3785d18da735b63d66ebb6068a21ea9f2f1a6c528ca3da95d611872d0c50817", nonce: "2", blockHash: "0xe09880052a50ff19be7f68bc55164ff639dae649d4ee0ed45875463040fa33f8", transactionIndex: "29", from: "0xa8e36b688ec3741e18d4f9f3afbfa7f0f9f0662a", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "6300000000000000000", gas: "500000", gasPrice: "1000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "5722152", gasUsed: "232407", confirmations: "3188960"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[34], to: addressList[2], value: "6300000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1510662082 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[38,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "6300000000000000000"}, {name: "tokens", type: "uint256", value: "12600000000000000000000"}, {name: "discount", type: "uint256", value: "630000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[38,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[38,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "119040629675000000000"}, {name: "totalContributions", type: "uint256", value: "6300000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[38,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[38,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "6300000000000000000"}, {name: "_caller", type: "address", value: "0xa8e36b688ec3741e18d4f9f3afbfa7f0f9f0662a"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[38,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[38,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xa8e36b688ec3741e18d4f9f3afbfa7f0f9f0662a"}, {name: "etherAmount", type: "uint256", value: "6300000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "13230000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "6300000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "15750000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "6300000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "3150000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[38,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[34], balance: "132802701138101609" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[34], balance: ( await web3.eth.getBalance( addressList[34], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4553746", timeStamp: "1510700427", hash: "0xacaa4a93b6ff1ab9aba27ec2a2317682df47313b52d1ac332e444d8ae206ac0c", nonce: "174", blockHash: "0xa068eb3ac6294c2939153325602a2836a37fc978a793dfea502d06b36996ac1e", transactionIndex: "6", from: "0x92989eb906d40c6385c9982b08c5953cbf763ab2", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "1100000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "474693", gasUsed: "232637", confirmations: "3186243"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[35], to: addressList[2], value: "1100000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1510700427 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[39,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "1100000000000000000"}, {name: "tokens", type: "uint256", value: "2200000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[39,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[39,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "120140629675000000000"}, {name: "totalContributions", type: "uint256", value: "1100000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[39,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[39,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "1100000000000000000"}, {name: "_caller", type: "address", value: "0x92989eb906d40c6385c9982b08c5953cbf763ab2"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[39,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[39,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x92989eb906d40c6385c9982b08c5953cbf763ab2"}, {name: "etherAmount", type: "uint256", value: "1100000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2200000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "1100000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2750000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "1100000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "550000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[39,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[35], balance: "382481719801334575" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[35], balance: ( await web3.eth.getBalance( addressList[35], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4556760", timeStamp: "1510742072", hash: "0x7a025e50f680d27f905ff53d5f52997fa35c5b8ef909b00ec20bd0c70c92c347", nonce: "4", blockHash: "0x0ab7d3fdd5d065e5e49187a46ef603b5196cecac55a34670956ccca6baebd09f", transactionIndex: "42", from: "0x27f364a96cc92793263ee07214b38e68acad220f", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "400000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "1342251", gasUsed: "220307", confirmations: "3183229"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[33], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1510742072 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokens", type: "uint256", value: "800000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[40,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "120540629675000000000"}, {name: "totalContributions", type: "uint256", value: "400000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[40,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[40,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "_caller", type: "address", value: "0x27f364a96cc92793263ee07214b38e68acad220f"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[40,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[40,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x27f364a96cc92793263ee07214b38e68acad220f"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "800000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "400000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "200000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[40,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[33], balance: "18883498661756327" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[33], balance: ( await web3.eth.getBalance( addressList[33], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4557520", timeStamp: "1510752892", hash: "0xd52d78ea54a2f23e6c434f167a7dacffd160e3c3cffe09bdd8d13eaa6ba6f961", nonce: "23", blockHash: "0x72f60d88c5353c2b5c26d7fea35fc42a7c247426e7cd6ebdf639b361061db2b7", transactionIndex: "12", from: "0x3d1bd8b08c45ff6d41424de1577afd8bf4962c6e", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "2100000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "552208", gasUsed: "232637", confirmations: "3182469"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[36], to: addressList[2], value: "2100000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1510752892 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "2100000000000000000"}, {name: "tokens", type: "uint256", value: "4200000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[41,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "122640629675000000000"}, {name: "totalContributions", type: "uint256", value: "2100000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[41,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[41,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "2100000000000000000"}, {name: "_caller", type: "address", value: "0x3d1bd8b08c45ff6d41424de1577afd8bf4962c6e"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[41,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[41,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x3d1bd8b08c45ff6d41424de1577afd8bf4962c6e"}, {name: "etherAmount", type: "uint256", value: "2100000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "4200000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "2100000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "5250000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "2100000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1050000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[41,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[36], balance: "36451111419499148" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[36], balance: ( await web3.eth.getBalance( addressList[36], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4558309", timeStamp: "1510764300", hash: "0x32a0c08704fb6cc649994599019c761795d2cbb317e7de26009d4e86bb1b26a5", nonce: "0", blockHash: "0x1a709493233679785c54ca955e81df38e2281d1635dc89d514c5632cd3d2e857", transactionIndex: "8", from: "0x28e77e566e72151392facb97cedae8eae17f155e", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "1000000000000000000", gas: "348958", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "684387", gasUsed: "232637", confirmations: "3181680"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[37], to: addressList[2], value: "1000000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1510764300 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[42,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokens", type: "uint256", value: "2000000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[42,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[42,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "123640629675000000000"}, {name: "totalContributions", type: "uint256", value: "1000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[42,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[42,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "_caller", type: "address", value: "0x28e77e566e72151392facb97cedae8eae17f155e"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[42,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[42,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x28e77e566e72151392facb97cedae8eae17f155e"}, {name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2000000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "1000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[42,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[37], balance: "15495010850640648" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[37], balance: ( await web3.eth.getBalance( addressList[37], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4559203", timeStamp: "1510776670", hash: "0xbf7f5d395bdd0330712cf991059b1a60112cf6baf732d13cb82ae5e8e2c702ea", nonce: "0", blockHash: "0x65c1bb685cd066f38cc24d8010be4c82dc55e4e4f06857f47568188fd013e82e", transactionIndex: "6", from: "0x6065a50fc70cc8801d2a88191077530fe296182b", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "1211790000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "548949", gasUsed: "232637", confirmations: "3180786"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[38], to: addressList[2], value: "1211790000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1510776670 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[43,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "1211790000000000000"}, {name: "tokens", type: "uint256", value: "2423580000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[43,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[43,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "124852419675000000000"}, {name: "totalContributions", type: "uint256", value: "1211790000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[43,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[43,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "1211790000000000000"}, {name: "_caller", type: "address", value: "0x6065a50fc70cc8801d2a88191077530fe296182b"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[43,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[43,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x6065a50fc70cc8801d2a88191077530fe296182b"}, {name: "etherAmount", type: "uint256", value: "1211790000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2423580000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "1211790000000000000"}, {name: "tokensGenerated", type: "uint256", value: "3029475000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "1211790000000000000"}, {name: "tokensGenerated", type: "uint256", value: "605895000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[43,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[38], balance: "38598659097812061" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[38], balance: ( await web3.eth.getBalance( addressList[38], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4559206", timeStamp: "1510776708", hash: "0x30ca6cac51803b154ffb12abfd4c3e8c17a616d714ce5f62eac35bd138cb465d", nonce: "2", blockHash: "0x2ab42a12b3ae763e4adf8a0222d906664d4fb1044df7afc967e6a9e3a7407a8f", transactionIndex: "7", from: "0xc8bf969d412d16e21c2aebe390513acb801a4201", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "280000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "408121", gasUsed: "232637", confirmations: "3180783"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[39], to: addressList[2], value: "280000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1510776708 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "280000000000000000"}, {name: "tokens", type: "uint256", value: "560000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[44,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "125132419675000000000"}, {name: "totalContributions", type: "uint256", value: "280000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[44,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[44,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "280000000000000000"}, {name: "_caller", type: "address", value: "0xc8bf969d412d16e21c2aebe390513acb801a4201"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[44,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[44,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xc8bf969d412d16e21c2aebe390513acb801a4201"}, {name: "etherAmount", type: "uint256", value: "280000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "560000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "280000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "700000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "280000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "140000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[44,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[39], balance: "1081884700000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[39], balance: ( await web3.eth.getBalance( addressList[39], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: pegEtherValues( \"4570000000000000000\", \"3048000000000... )", async function( ) {
		const txOriginal = {blockNumber: "4559466", timeStamp: "1510780137", hash: "0x1f518c22f0b190099188cc02a526df7f7bfaae3d54d5207f509224e9550038f5", nonce: "509", blockHash: "0x4dbf2b38f54f76ac06e8902bca49685e382df001218b9f8abda0df89301df087", transactionIndex: "101", from: "0x6b3b6e23acacc712bc6d8531f7a239ca10ac47a3", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "0", gas: "55642", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x86bb1b240000000000000000000000000000000000000000000000003f6be6c97f890000000000000000000000000000000000000000000000000001a6feb68291e8000000000000000000000000000000000000000000000000000842f9908cd988000000000000000000000000000000000000000000000000002951a65db0fabc00000000000000000000000000000000000000000000000000000429d069189e0000000000000000000000000000000000000000000000000052aba05c3426b40000", contractAddress: "", cumulativeGasUsed: "2504053", gasUsed: "55642", confirmations: "3180523"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minDiscountEther", value: "4570000000000000000"}, {type: "uint256", name: "_firstTierDiscountUpperLimitEther", value: "30480000000000000000"}, {type: "uint256", name: "_secondTierDiscountUpperLimitEther", value: "152400000000000000000"}, {type: "uint256", name: "_thirdTierDiscountUpperLimitEther", value: "762200000000000000000"}, {type: "uint256", name: "_minPresaleContributionEther", value: "300000000000000000"}, {type: "uint256", name: "_maxPresaleContributionEther", value: "1525000000000000000000"}], name: "pegEtherValues", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "pegEtherValues(uint256,uint256,uint256,uint256,uint256,uint256)" ]( "4570000000000000000", "30480000000000000000", "152400000000000000000", "762200000000000000000", "300000000000000000", "1525000000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1510780137 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4559811", timeStamp: "1510784964", hash: "0x878245e38516fe95cbb26f77c8f16b90f946d91993d49310ffa7e0b5e7e6b039", nonce: "0", blockHash: "0x9ce3749b976958f572b7b7ff1138de7b4607e5b414095ff719a7ae20ecf66c1b", transactionIndex: "7", from: "0xd7aeb08596c1a29c4d04f7bae8cc28be8091fdcd", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "5000000000000000000", gas: "500000", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "399400", gasUsed: "232407", confirmations: "3180178"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[40], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1510784964 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[46,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokens", type: "uint256", value: "10000000000000000000000"}, {name: "discount", type: "uint256", value: "500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[46,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[46,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "130132419675000000000"}, {name: "totalContributions", type: "uint256", value: "5000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[46,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[46,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "_caller", type: "address", value: "0xd7aeb08596c1a29c4d04f7bae8cc28be8091fdcd"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[46,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[46,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xd7aeb08596c1a29c4d04f7bae8cc28be8091fdcd"}, {name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "10500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "12500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "5000000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[46,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[40], balance: "85885654878720169" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[40], balance: ( await web3.eth.getBalance( addressList[40], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4560058", timeStamp: "1510788049", hash: "0x1c3f8d00d179bce1845ffe23bfc07d899004c1621a15149fbb214b433a7faebd", nonce: "0", blockHash: "0x6c75d722e6c1fa6cf1e527e1f1b9032f5800f42b675775f2bc8e6595fc0e6c11", transactionIndex: "16", from: "0xf7172c2070746e63aace972aa655e37497893e80", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "1005619000000000000", gas: "232637", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "879376", gasUsed: "232637", confirmations: "3179931"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[41], to: addressList[2], value: "1005619000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1510788049 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "1005619000000000000"}, {name: "tokens", type: "uint256", value: "2011238000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[47,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "131138038675000000000"}, {name: "totalContributions", type: "uint256", value: "1005619000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[47,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[47,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "1005619000000000000"}, {name: "_caller", type: "address", value: "0xf7172c2070746e63aace972aa655e37497893e80"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[47,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[47,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0xf7172c2070746e63aace972aa655e37497893e80"}, {name: "etherAmount", type: "uint256", value: "1005619000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2011238000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "1005619000000000000"}, {name: "tokensGenerated", type: "uint256", value: "2514047500000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "1005619000000000000"}, {name: "tokensGenerated", type: "uint256", value: "502809500000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[47,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[41], balance: "2273620000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[41], balance: ( await web3.eth.getBalance( addressList[41], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4561009", timeStamp: "1510801272", hash: "0x085111cab6abdb72e031679230917dbb965a0ea8450671c251756c06d2fa77b7", nonce: "49297", blockHash: "0xb649daa609e4b13f931e2a3cf7a47c079713d0395632f2c4817522d9cfd94ada", transactionIndex: "4", from: "0xa0bb4ba19f578a63fa3f67adaf7bbca15ccadc45", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "597361710000000000", gas: "90000", gasPrice: "70000000000", isError: "0", txreceipt_status: "0", input: "0x", contractAddress: "", cumulativeGasUsed: "106010", gasUsed: "21959", confirmations: "3178980"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[42], to: addressList[2], value: "597361710000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1510801272 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[42], balance: "9765544000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[42], balance: ( await web3.eth.getBalance( addressList[42], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "4561365", timeStamp: "1510806870", hash: "0x00cf03b3bc8eebe06e14b742f552aed5601711e65bb12f33596d4929147bfbc3", nonce: "12", blockHash: "0x1a32a1c78ca09398a15757a2bd9c12341eeb14931b52364b722be38c4c73909f", transactionIndex: "108", from: "0x4f994cb35f0c11a3649e820a23d87d858d078958", to: "0x8fbbb1102e2a3ddf920808609592b4a462e29330", value: "600000000000000000", gas: "330460", gasPrice: "21000000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "4587922", gasUsed: "220307", confirmations: "3178624"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[30], to: addressList[2], value: "600000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1510806870 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokens", type: "uint256"}, {indexed: false, name: "discount", type: "uint256"}], name: "DiscountApplied", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DiscountApplied", events: [{name: "etherAmount", type: "uint256", value: "600000000000000000"}, {name: "tokens", type: "uint256", value: "1200000000000000000000"}, {name: "discount", type: "uint256", value: "0"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "preSaleEtherPaid", type: "uint256"}, {indexed: false, name: "totalContributions", type: "uint256"}], name: "CountersUpdated", type: "event"} ;
		console.error( "eventCallOriginal[49,5] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "CountersUpdated", events: [{name: "preSaleEtherPaid", type: "uint256", value: "131738038675000000000"}, {name: "totalContributions", type: "uint256", value: "600000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[49,5] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "_caller", type: "address"}], name: "Contribution", type: "event"} ;
		console.error( "eventCallOriginal[49,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Contribution", events: [{name: "etherAmount", type: "uint256", value: "600000000000000000"}, {name: "_caller", type: "address", value: "0x4f994cb35f0c11a3649e820a23d87d858d078958"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[49,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "caller", type: "address"}, {indexed: false, name: "etherAmount", type: "uint256"}, {indexed: false, name: "tokensGenerated", type: "uint256"}], name: "NewSale", type: "event"} ;
		console.error( "eventCallOriginal[49,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NewSale", events: [{name: "caller", type: "address", value: "0x4f994cb35f0c11a3649e820a23d87d858d078958"}, {name: "etherAmount", type: "uint256", value: "600000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1200000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x6d15a5f9c98e272686a5b241bc31516514e18b30"}, {name: "etherAmount", type: "uint256", value: "600000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "1500000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}, {name: "NewSale", events: [{name: "caller", type: "address", value: "0x762f11b6509fbb0f7a90b5ba80d3add087bebff5"}, {name: "etherAmount", type: "uint256", value: "600000000000000000"}, {name: "tokensGenerated", type: "uint256", value: "300000000000000000000"}], address: "0x8fbbb1102e2a3ddf920808609592b4a462e29330"}] ;
		console.error( "eventResultOriginal[49,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[30], balance: "5995758245824007" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[30], balance: ( await web3.eth.getBalance( addressList[30], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
