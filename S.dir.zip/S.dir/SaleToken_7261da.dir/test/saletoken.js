const SaleToken = artifacts.require( "./SaleToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "SaleToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xb28BF5232F743c61f8C8F0db7b89bA88447261DA", "0x315fB673a6Fa8720Cf0341795faAD602061D1267", "0x7AEAf9C8A62caf79C60B0EEB1e57EAefC140a5Ca", "0x5425A1cA8b650CcfE0620fd10Fe6E3dC46f0211D", "0xD75C77816C83537A6bb97819398fc2694e2E1478", "0xa98e0024dB4A1720a301F464c4dabf685E34D078", "0x402552C254831142f8FCFCc525277101fa3167e5", "0x9e315E9701908501f6dC68A2af6e28a20C75d970", "0x6fF2d379B9A09aF951A8044BaF39dA438515Fe07", "0x7487D77070743da4B67CBcfb86DE75CE3a6e8CB8", "0x853DF570C6E76f9A373A9e3B2861Cb646Fa0E0F7", "0x5Bd87FadB913901aE56769b171D461EF3d3Eb3aE", "0xCa57279327F0fFFBa89029418DFBf44571Fe05E8", "0xA0D8e7564Af7CD56a4e50580Ec7BE253fE4867F1", "0xbaA7a4da76847e61bBDca56E1DD8C7437dB56F15", "0x15C40d6ae972C54111621bCe26B4d0f6696a03a5", "0x4D6697c4926B22ab5B79a7f9024063cb0481e2e7"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "cfoAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "ceoAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_address", type: "address"}, {name: "_amount", type: "uint256"}, {name: "_nonce", type: "uint256"}], name: "withdrawDeklaHashing", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "_newCFO", type: "address"}, {name: "_nonce", type: "uint256"}], name: "getCFOHashing", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "hash", type: "bytes32"}, {name: "sig", type: "bytes"}], name: "recover", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "_address", type: "address"}, {name: "_amount", type: "uint256"}, {name: "_nonce", type: "uint256"}], name: "withdrawEthHashing", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_newCEO", type: "address"}, {name: "_nonce", type: "uint256"}], name: "getCEOHashing", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "_sender", type: "address"}], name: "getNonces", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "CLevelTxCount_", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_value", type: "uint256"}], name: "calculateDekla", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_newCOO", type: "address"}, {name: "_nonce", type: "uint256"}], name: "getCOOHashing", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "_token", type: "address"}, {name: "_nonce", type: "uint256"}], name: "getTokenAddressHashing", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "minimumPurchaseAmount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "cooAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getNonce", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "systemAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "deklaTokenPrice", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "dekla", type: "uint256"}, {indexed: false, name: "buyer", type: "address"}], name: "BuyDeklaSuccessful", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawEthSuccessful", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "percent", type: "uint256"}], name: "UpdateMinimumPurchaseAmountSuccessful", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "signer", type: "address"}], name: "addressLogger", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["BuyDeklaSuccessful(uint256,address)", "UpdateDeklaPriceSuccessful(uint256,address)", "WithdrawEthSuccessful(address,uint256)", "WithdrawDeklaSuccessful(address,uint256)", "UpdateMinimumPurchaseAmountSuccessful(address,uint256)", "addressLogger(address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x0be24121535c2246b9c3ff6c89238d91f84a4f051df138795fc04e1c9b4f4c05", "0xf6b710a4e46a4bcd568034815205762bf26ced9049698cee58f92c46be13b909", "0x6d8931475fdf518d8e4fde1a24434812a7367d9f928fabeb4204004873e194bb", "0x286994841661c43dedbaa8ad15288ce26d763ada7125111c98685da5108ffeed", "0xf293446bb6820b9fd8a3f5ff21e058fef59ef1fadbb3b7a71a25c0cc2aecaf30", "0xaf3c4179a2293e18516e0580c808b1d6c7f43c15f13670decd3da1177d31f021"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6678164 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6708803 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_ceoAddress", value: 4}, {type: "address", name: "_cfoAddress", value: 5}, {type: "address", name: "_cooAddress", value: 6}, {type: "address", name: "_systemAddress", value: 3}], name: "SaleToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "cfoAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cfoAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "ceoAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ceoAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_amount", value: random.range( maxRandom )}, {type: "uint256", name: "_nonce", value: random.range( maxRandom )}], name: "withdrawDeklaHashing", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "withdrawDeklaHashing(address,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_newCFO", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_nonce", value: random.range( maxRandom )}], name: "getCFOHashing", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCFOHashing(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "hash", value: "0x" + random.range( maxRandom ).toString( 16 )}, {type: "bytes", name: "sig", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "recover", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "recover(bytes32,bytes)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_address", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_amount", value: random.range( maxRandom )}, {type: "uint256", name: "_nonce", value: random.range( maxRandom )}], name: "withdrawEthHashing", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "withdrawEthHashing(address,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "decimals", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "decimals()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_newCEO", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_nonce", value: random.range( maxRandom )}], name: "getCEOHashing", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCEOHashing(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_sender", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getNonces", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNonces(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "CLevelTxCount_", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "CLevelTxCount_()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_value", value: random.range( maxRandom )}], name: "calculateDekla", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculateDekla(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_newCOO", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_nonce", value: random.range( maxRandom )}], name: "getCOOHashing", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCOOHashing(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_token", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "_nonce", value: random.range( maxRandom )}], name: "getTokenAddressHashing", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTokenAddressHashing(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minimumPurchaseAmount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minimumPurchaseAmount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "cooAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cooAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getNonce", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getNonce()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "systemAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "systemAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "deklaTokenPrice", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "deklaTokenPrice()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "SaleToken", function( accounts ) {

	it( "TEST: SaleToken( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6678164", timeStamp: "1541848898", hash: "0x315a88569da24676d523ae45837a3e76dfb72b63326cca88cf101533acce1577", nonce: "351", blockHash: "0x5125696f9e1a9de68248c97a4324ecb3392ecb8d62285bffed8bab5284cfd047", transactionIndex: "58", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: 0, value: "0", gas: "3494839", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x5d2888ba0000000000000000000000007aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca0000000000000000000000005425a1ca8b650ccfe0620fd10fe6e3dc46f0211d000000000000000000000000d75c77816c83537a6bb97819398fc2694e2e1478000000000000000000000000315fb673a6fa8720cf0341795faad602061d1267", contractAddress: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", cumulativeGasUsed: "7237793", gasUsed: "3494839", confirmations: "1037529"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_ceoAddress", value: addressList[4]}, {type: "address", name: "_cfoAddress", value: addressList[5]}, {type: "address", name: "_cooAddress", value: addressList[6]}, {type: "address", name: "_systemAddress", value: addressList[3]}], name: "SaleToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = SaleToken.new( addressList[4], addressList[5], addressList[6], addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1541848898 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = SaleToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setTokenAddress( addressList[7], \"0x37a837fd3eda4556028e... )", async function( ) {
		const txOriginal = {blockNumber: "6678324", timeStamp: "1541851537", hash: "0xe960c5dbea36592f0049eed6b9b05c5ad288e75e973eeeaa7e377d8ad0b2d03d", nonce: "1", blockHash: "0xf44d5c0c842eac752db23f483f6f09adedee332b2be36f5bde51f38791a036ba", transactionIndex: "103", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "56046", gasPrice: "3795000000", isError: "0", txreceipt_status: "1", input: "0x4b16304f000000000000000000000000a98e0024db4a1720a301f464c4dabf685e34d0780000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000004137a837fd3eda4556028e82159e6f9be3f353a94483b8575c643948f1e6b022284e3bb26cc509100f122c37d15940a5c265c86d49580e75e2e7536066126c1db21c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6407569", gasUsed: "56046", confirmations: "1037369"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[7]}, {type: "bytes", name: "_sig", value: "0x37a837fd3eda4556028e82159e6f9be3f353a94483b8575c643948f1e6b022284e3bb26cc509100f122c37d15940a5c265c86d49580e75e2e7536066126c1db21c"}], name: "setTokenAddress", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTokenAddress(address,bytes)" ]( addressList[7], "0x37a837fd3eda4556028e82159e6f9be3f353a94483b8575c643948f1e6b022284e3bb26cc509100f122c37d15940a5c265c86d49580e75e2e7536066126c1db21c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1541851537 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[8], \"9000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6678387", timeStamp: "1541852342", hash: "0x97ec9f54acd1478f8c88fcb8a9f78d2a3cd066eab40d72979db0a72c5f915ef8", nonce: "4", blockHash: "0x5d35aa1da19c3968b8bac6e09c4ff5846066d2e0f94d436fb800b22ca1e90631", transactionIndex: "71", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "93367", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e000000000000000000000000402552c254831142f8fcfcc525277101fa3167e500000000000000000000000000000000000000000000130ee8e7179044400000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000415380d9bced1d33c245b437b7a8010f2735b3c0465c75389f5bbbe5613650eeb64db5ba92ac3b88d8fcf02290f255b99fdbcf3ee25ed4f1a1c6b126985c205e0b1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3254397", gasUsed: "93367", confirmations: "1037306"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[8]}, {type: "uint256", name: "_amount", value: "90000000000000000000000"}, {type: "bytes", name: "_sig", value: "0x5380d9bced1d33c245b437b7a8010f2735b3c0465c75389f5bbbe5613650eeb64db5ba92ac3b88d8fcf02290f255b99fdbcf3ee25ed4f1a1c6b126985c205e0b1c"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[8], "90000000000000000000000", "0x5380d9bced1d33c245b437b7a8010f2735b3c0465c75389f5bbbe5613650eeb64db5ba92ac3b88d8fcf02290f255b99fdbcf3ee25ed4f1a1c6b126985c205e0b1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1541852342 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0x402552c254831142f8fcfcc525277101fa3167e5"}, {name: "amount", type: "uint256", value: "90000000000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[9], \"1400147200000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6678441", timeStamp: "1541853177", hash: "0xd55bc60342aa0b828bbeed8c9864b61eff4b6056c7497dca990d32f79775d6d1", nonce: "5", blockHash: "0x39f613d0b3e8205626247345883526399902d785378efaffd84aa2e8bb015f5b", transactionIndex: "123", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "78347", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e0000000000000000000000009e315e9701908501f6dc68a2af6e28a20c75d9700000000000000000000000000000000000000000000002f705751905a220000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041bcb821b04b6abc53c7eaeed48ca892f39e80875532a37a876b2131fcfd3111f0501b5f7b17b2d8a3059c6157d5b81de9ef0cf966d1227a469e0d4d601fa4d33f1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5181978", gasUsed: "78347", confirmations: "1037252"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[9]}, {type: "uint256", name: "_amount", value: "14001472000000000000000"}, {type: "bytes", name: "_sig", value: "0xbcb821b04b6abc53c7eaeed48ca892f39e80875532a37a876b2131fcfd3111f0501b5f7b17b2d8a3059c6157d5b81de9ef0cf966d1227a469e0d4d601fa4d33f1b"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[9], "14001472000000000000000", "0xbcb821b04b6abc53c7eaeed48ca892f39e80875532a37a876b2131fcfd3111f0501b5f7b17b2d8a3059c6157d5b81de9ef0cf966d1227a469e0d4d601fa4d33f1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1541853177 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[3,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0x9e315e9701908501f6dc68a2af6e28a20c75d970"}, {name: "amount", type: "uint256", value: "14001472000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[3,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[10], \"983758720000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6678451", timeStamp: "1541853348", hash: "0xfee896efb837bc4554eef04413eead48bb8fc23cf3c1d7d74b4469bf8098f6bd", nonce: "6", blockHash: "0x14305ce2ef91e7360ffb441ef8bcd60ebce9dfd8bfd91900866eef77ffc2538b", transactionIndex: "56", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "78347", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e0000000000000000000000006ff2d379b9a09af951a8044baf39da438515fe070000000000000000000000000000000000000000000014d4f77a1e4ab0e0000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041d213d3d3d2e36706c185f1b6d3f503fe76872ffb56beced6643ec426efbf15fa7504b9fb5bf5a69d99aee9b7ad26d9e18fa1e4284cb5a90d6cc77d900a04b03f1b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3515204", gasUsed: "78347", confirmations: "1037242"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[10]}, {type: "uint256", name: "_amount", value: "98375872000000000000000"}, {type: "bytes", name: "_sig", value: "0xd213d3d3d2e36706c185f1b6d3f503fe76872ffb56beced6643ec426efbf15fa7504b9fb5bf5a69d99aee9b7ad26d9e18fa1e4284cb5a90d6cc77d900a04b03f1b"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[10], "98375872000000000000000", "0xd213d3d3d2e36706c185f1b6d3f503fe76872ffb56beced6643ec426efbf15fa7504b9fb5bf5a69d99aee9b7ad26d9e18fa1e4284cb5a90d6cc77d900a04b03f1b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1541853348 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[4,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0x6ff2d379b9a09af951a8044baf39da438515fe07"}, {name: "amount", type: "uint256", value: "98375872000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[4,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23533889374605\" )", async function( ) {
		const txOriginal = {blockNumber: "6679892", timeStamp: "1541873115", hash: "0xf789eb410535d4bb11ab8f706260e604afd0109c013d4362ca0bcf6bc06038cc", nonce: "355", blockHash: "0xecb9d5d2b4022a04694a57addbc67131634005423f4a95587b1a451370ac6e74", transactionIndex: "103", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x9570549300000000000000000000000000000000000000000000000000001567691dc98d", contractAddress: "", cumulativeGasUsed: "5324914", gasUsed: "28974", confirmations: "1035801"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23533889374605"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23533889374605", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1541873115 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23533889374605"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23511901204696\" )", async function( ) {
		const txOriginal = {blockNumber: "6680663", timeStamp: "1541884025", hash: "0x9bd61c57485be76e7da5c6131136f9f0c81016aa02896648c21822f7556dc9da", nonce: "356", blockHash: "0x429fce5b78d67775eea033290a6c0c2cc3b9e8e5e83d1da13cbb8a5f4b062999", transactionIndex: "58", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015624a84f0d8", contractAddress: "", cumulativeGasUsed: "2914169", gasUsed: "28974", confirmations: "1035030"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23511901204696"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23511901204696", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541884025 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23511901204696"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23661891793067\" )", async function( ) {
		const txOriginal = {blockNumber: "6681418", timeStamp: "1541894727", hash: "0x207ffb1ba2c4cecba0bed0928d05f7b58d48a22f1efa7b24ed9a4824bbf688ff", nonce: "357", blockHash: "0x23886430d9892f9951733233a64118e59f209ed1e14ef8177c268f783f4e21f1", transactionIndex: "49", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "1800000001", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000158536a7b0ab", contractAddress: "", cumulativeGasUsed: "3213984", gasUsed: "28974", confirmations: "1034275"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23661891793067"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23661891793067", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1541894727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23661891793067"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23675934037500\" )", async function( ) {
		const txOriginal = {blockNumber: "6682183", timeStamp: "1541905529", hash: "0xacf54ba44b13cc88fe5b4d677c5879c7b60a2f841a078bafff9c769ee28a73f1", nonce: "358", blockHash: "0x4c77977d7a88c931c7e34004a075b28bfb2f0cdbf14f64153981a4e0fbc639a0", transactionIndex: "90", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "2100000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015887ba355fc", contractAddress: "", cumulativeGasUsed: "4858357", gasUsed: "28974", confirmations: "1033510"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23675934037500"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23675934037500", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541905529 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23675934037500"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23769553368146\" )", async function( ) {
		const txOriginal = {blockNumber: "6683977", timeStamp: "1541930869", hash: "0x0f52066809a99f5fea409874fd3a08855b20d3eefa3aac6e7cb86f2ed0286f02", nonce: "359", blockHash: "0x7bada82cbba97deb20cb02ee08c871d7f161fadbcaeb8bb163a9c2555f836443", transactionIndex: "18", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "1401000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000159e47c8f452", contractAddress: "", cumulativeGasUsed: "406974", gasUsed: "28974", confirmations: "1031716"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23769553368146"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23769553368146", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541930869 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23769553368146"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23686609258620\" )", async function( ) {
		const txOriginal = {blockNumber: "6684406", timeStamp: "1541936999", hash: "0xfcb2c4e0a2e2bab91bf4e5116b915bbedf70b08c4bff15931f7d016e56744080", nonce: "360", blockHash: "0x73e936a8208fba4b703bfe713863d1c18c82d21530d9ca67d7233501f3a43797", transactionIndex: "162", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000158af7ee487c", contractAddress: "", cumulativeGasUsed: "7716346", gasUsed: "28974", confirmations: "1031287"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23686609258620"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23686609258620", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541936999 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[10,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23686609258620"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[10,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23770288678450\" )", async function( ) {
		const txOriginal = {blockNumber: "6685196", timeStamp: "1541947754", hash: "0xea5671ee5d51edd684dd2b789e28411795619c91f0ae19ba2f08bd23699021cc", nonce: "361", blockHash: "0x95affedf7590ab19911bfb58af1e69e71b2b90e3ff23c4727c75b6adf82cb80d", transactionIndex: "86", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000159e739ce632", contractAddress: "", cumulativeGasUsed: "7558607", gasUsed: "28974", confirmations: "1030497"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23770288678450"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23770288678450", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541947754 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23770288678450"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23856065239157\" )", async function( ) {
		const txOriginal = {blockNumber: "6686368", timeStamp: "1541964584", hash: "0x4e02e76d5e08302942d2c161e19b9b1030cb7e817852da0b08f2db7c7ecc7634", nonce: "362", blockHash: "0x14ae5a30cfd124199f62c7ae1c826e1a20c10a06bb085424f026c0b3816b0d1b", transactionIndex: "137", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015b26c4b5875", contractAddress: "", cumulativeGasUsed: "6215633", gasUsed: "28974", confirmations: "1029325"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23856065239157"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23856065239157", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541964584 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23856065239157"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23938692102631\" )", async function( ) {
		const txOriginal = {blockNumber: "6687106", timeStamp: "1541974944", hash: "0xd819a1d1bc0a19eed8e6e41ffe6d285c644ce30ee04a3bc42b16ab21dea43b0e", nonce: "363", blockHash: "0x284abb6082f37b88b7a5c851f504bfa58c572e9bd8f61da46b70072b95813a4b", transactionIndex: "49", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015c5a93d39e7", contractAddress: "", cumulativeGasUsed: "3453842", gasUsed: "28974", confirmations: "1028587"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23938692102631"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23938692102631", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1541974944 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23938692102631"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23643947630336\" )", async function( ) {
		const txOriginal = {blockNumber: "6687889", timeStamp: "1541985785", hash: "0xacd60d0e2866764c9f5f678a7a6f61d2b50dab041bb159ee0430bce75b147fbc", nonce: "364", blockHash: "0xccbcdd678b180928fb1ffa9ca35a934d35e3c7fa1cc4fd9b8e6606130b9cf675", transactionIndex: "84", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28910", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000158109197f00", contractAddress: "", cumulativeGasUsed: "4611484", gasUsed: "28910", confirmations: "1027804"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23643947630336"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23643947630336", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541985785 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23643947630336"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23723213323335\" )", async function( ) {
		const txOriginal = {blockNumber: "6688625", timeStamp: "1541996547", hash: "0xcd6464475b78a870203a949e4ebfc1e285261803e81f02bbc4219f6c16381504", nonce: "365", blockHash: "0xa7eb6d5dc6fd139b0f9df5b7405bbaf21ef3583c0bf13af3ef25dc3152bf536f", transactionIndex: "70", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015937db3fc47", contractAddress: "", cumulativeGasUsed: "6357118", gasUsed: "28974", confirmations: "1027068"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23723213323335"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23723213323335", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541996547 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23723213323335"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23796573947754\" )", async function( ) {
		const txOriginal = {blockNumber: "6689398", timeStamp: "1542007390", hash: "0xf102fd2d6b003ee43d0b43924af3bcb2a3516dc24964ee6c2376f1894f96501d", nonce: "366", blockHash: "0x79f3f568f3a0a5cc787480e62563d33dd119b0d4353b455d929d5825caca7ca5", transactionIndex: "127", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5500000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015a49256476a", contractAddress: "", cumulativeGasUsed: "6194909", gasUsed: "28974", confirmations: "1026295"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23796573947754"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23796573947754", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542007390 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23796573947754"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23682959459965\" )", async function( ) {
		const txOriginal = {blockNumber: "6690831", timeStamp: "1542027942", hash: "0x7e30194a2f77dfaf945b237a09d44f403eb9bf0230cae7888e62295a11abfb63", nonce: "368", blockHash: "0x91bdb0d38c85595e943b8af2008fce69ed25e1ea81ffb2bb4b89073b85a91d48", transactionIndex: "73", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "4812500000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000158a1e62c67d", contractAddress: "", cumulativeGasUsed: "4614492", gasUsed: "28974", confirmations: "1024862"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23682959459965"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23682959459965", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542027942 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23682959459965"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23771105442441\" )", async function( ) {
		const txOriginal = {blockNumber: "6691802", timeStamp: "1542041146", hash: "0xf4030cf2b74942cbd1316fc063defcb42356030c47c1f9e05048a515b7cbcb20", nonce: "369", blockHash: "0xf3bcfdb614dc6421680e517c578da8353045007d705fd87e85eb6e51831d0cc1", transactionIndex: "84", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "3500000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000159ea44bba89", contractAddress: "", cumulativeGasUsed: "7807727", gasUsed: "28974", confirmations: "1023891"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23771105442441"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23771105442441", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542041146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23771105442441"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23906978885942\" )", async function( ) {
		const txOriginal = {blockNumber: "6692538", timeStamp: "1542051574", hash: "0xe238276fd61c4a5aab05cefbf065a7bf56fd2fad2b4e40fc922c7b2b9935b29d", nonce: "370", blockHash: "0x7147a2f10e52349afb4a01a0f8c1ba506144efe35daa5ef1085fc4bc731c4fd4", transactionIndex: "76", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015be46fbf136", contractAddress: "", cumulativeGasUsed: "6978329", gasUsed: "28974", confirmations: "1023155"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23906978885942"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23906978885942", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542051574 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23906978885942"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23967657563875\" )", async function( ) {
		const txOriginal = {blockNumber: "6693349", timeStamp: "1542062588", hash: "0xdc9274ff4e594e0e98761a6711af5f6c4ffa9c6fc543f13912620f621af44e4e", nonce: "371", blockHash: "0xa37e3d0bf286398922d4e0d88f84c507c740cdfe66f9f5b6620d670174701096", transactionIndex: "88", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015cc67b716e3", contractAddress: "", cumulativeGasUsed: "4376143", gasUsed: "28974", confirmations: "1022344"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23967657563875"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23967657563875", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542062588 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23967657563875"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23974637015805\" )", async function( ) {
		const txOriginal = {blockNumber: "6694102", timeStamp: "1542073230", hash: "0x2ee7eecd2adca892e5d1516ffe616315e59d020472e1fe6042c71b19b78f4021", nonce: "372", blockHash: "0x562e4bb3cec228a942cf9f2ff57330a7174b2c0d92c8c3570c3b3c85083e2711", transactionIndex: "52", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015ce07b912fd", contractAddress: "", cumulativeGasUsed: "3251896", gasUsed: "28974", confirmations: "1021591"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23974637015805"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23974637015805", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542073230 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23974637015805"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"23982965093292\" )", async function( ) {
		const txOriginal = {blockNumber: "6694909", timeStamp: "1542084529", hash: "0xe02afa7d2210ad3ef4bd222975af2e051c553e54525f9c39398a7536cf81f9a1", nonce: "373", blockHash: "0xa3120bd310fff5fa396eef41fa41b1d473f90f46c27da1decdf76a2519350395", transactionIndex: "47", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015cff81d73ac", contractAddress: "", cumulativeGasUsed: "2574271", gasUsed: "28974", confirmations: "1020784"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "23982965093292"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "23982965093292", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542084529 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "23982965093292"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24113385792393\" )", async function( ) {
		const txOriginal = {blockNumber: "6695648", timeStamp: "1542094752", hash: "0x1def3af1da0430e1eb03c7fa671f78108ec933c6496ed0eb4c70b598a5ad00a2", nonce: "374", blockHash: "0xe558b246fd620abfce6903362f6d13ac29557e49aaeaee47985f320038c04336", transactionIndex: "91", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015ee55cb6389", contractAddress: "", cumulativeGasUsed: "4589827", gasUsed: "28974", confirmations: "1020045"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24113385792393"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24113385792393", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542094752 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24113385792393"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24065208416006\" )", async function( ) {
		const txOriginal = {blockNumber: "6696633", timeStamp: "1542109009", hash: "0xccc4350f8051db62148f6de450041aec6139b5d93d545a1c27ca7eef77db1a0b", nonce: "375", blockHash: "0x8fccae1e94c40e5a6695690044f6cd6c2dbf082d15e86ed2e7cbd14cbc5739de", transactionIndex: "112", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015e31e32f706", contractAddress: "", cumulativeGasUsed: "5067376", gasUsed: "28974", confirmations: "1019060"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24065208416006"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24065208416006", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542109009 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24065208416006"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24127622895306\" )", async function( ) {
		const txOriginal = {blockNumber: "6697475", timeStamp: "1542121646", hash: "0xe07d081cb244391d5f2beea1d77d46e74fcff2dbbbff2911f1db7b21a0dd4135", nonce: "376", blockHash: "0xb1d0ab422832aeeabaead5159f39e71cd845d6a978c4916e82412c5f2eb9beed", transactionIndex: "88", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015f1a66456ca", contractAddress: "", cumulativeGasUsed: "4594027", gasUsed: "28974", confirmations: "1018218"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24127622895306"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24127622895306", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542121646 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24127622895306"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24053518485373\" )", async function( ) {
		const txOriginal = {blockNumber: "6698244", timeStamp: "1542132357", hash: "0xb83d452a73594feeedb85867c36bdee63a8b64c6fa82cce534ed95e69a5ca516", nonce: "377", blockHash: "0xfbd24dcea9314daac2d28d8cf4ae25963a29ea2c68e91d2bd2ca51a60d81b1b6", transactionIndex: "97", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000015e0656cc77d", contractAddress: "", cumulativeGasUsed: "5366997", gasUsed: "28974", confirmations: "1017449"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24053518485373"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24053518485373", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542132357 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24053518485373"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24297280195369\" )", async function( ) {
		const txOriginal = {blockNumber: "6699001", timeStamp: "1542143394", hash: "0x289a96eb767910f76c9a7a7874402b66629cd92d6fd3af646ac93eb1ea3886ea", nonce: "378", blockHash: "0x43e511c9cf7c14189213dba679c0c9c79e83115c20884ba20899b32d598a0cfb", transactionIndex: "152", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000161926c14b29", contractAddress: "", cumulativeGasUsed: "7079851", gasUsed: "28974", confirmations: "1016692"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24297280195369"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24297280195369", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542143394 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24297280195369"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24380973325384\" )", async function( ) {
		const txOriginal = {blockNumber: "6699801", timeStamp: "1542153836", hash: "0x978f49adee75422298e8a232f2a5eb0bebd56699615eded7ba31c07f28581ce8", nonce: "379", blockHash: "0x52c4c5d84a30795eb72e15fb6705f2dbdbcc56e4b66c0e2b4b37962082ef31f3", transactionIndex: "71", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000162ca3411c48", contractAddress: "", cumulativeGasUsed: "3997455", gasUsed: "28974", confirmations: "1015892"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24380973325384"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24380973325384", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542153836 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24380973325384"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24378588785737\" )", async function( ) {
		const txOriginal = {blockNumber: "6700556", timeStamp: "1542164595", hash: "0xb5e87261822302e7489b66970b168d50464a67e763c1852c0b6946fc43d87b5f", nonce: "380", blockHash: "0xf386917b5ac4973bd29025249268696aae9c1815b55d14def4bd4086ec74fae5", transactionIndex: "110", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000162c151fec49", contractAddress: "", cumulativeGasUsed: "5938673", gasUsed: "28974", confirmations: "1015137"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24378588785737"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24378588785737", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542164595 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24378588785737"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24325952055590\" )", async function( ) {
		const txOriginal = {blockNumber: "6701319", timeStamp: "1542175730", hash: "0x73aaa57bd833dc7df955b89e459255e6bef14b9a5758232dc0eae05c6ffcad87", nonce: "381", blockHash: "0xaba27785545f7493bd2def4497a612cf3d64b710bde0156486a705df1570208d", transactionIndex: "96", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000161fd3bb2926", contractAddress: "", cumulativeGasUsed: "7997381", gasUsed: "28974", confirmations: "1014374"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24325952055590"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24325952055590", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542175730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24325952055590"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24382652830318\" )", async function( ) {
		const txOriginal = {blockNumber: "6702094", timeStamp: "1542187008", hash: "0xff8dd07ac76a06fc476e3b59e2ae9bfc4eb65cf5d372a32f30d68e2aa4939bf1", nonce: "382", blockHash: "0x891a69bb8da0c01f7cedbe4d7e8a7dc1ea6e69982d03f3a0197643fe6e6cbad6", transactionIndex: "119", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000162d075c526e", contractAddress: "", cumulativeGasUsed: "5506402", gasUsed: "28974", confirmations: "1013599"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24382652830318"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24382652830318", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542187008 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24382652830318"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"24955114942307\" )", async function( ) {
		const txOriginal = {blockNumber: "6702777", timeStamp: "1542197058", hash: "0xa9abf61fa4224be7ca30395a23e0e83043cf8e2f341708c86ed0c3a8cfc96ffb", nonce: "383", blockHash: "0x4db1553761a74c93fd4579deca8b54547c4e9f5559adca9834c17c82fad69278", transactionIndex: "134", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000016b250c2ef63", contractAddress: "", cumulativeGasUsed: "6624963", gasUsed: "28974", confirmations: "1012916"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "24955114942307"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "24955114942307", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542197058 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "24955114942307"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"25893317803085\" )", async function( ) {
		const txOriginal = {blockNumber: "6703664", timeStamp: "1542209271", hash: "0x382fa8968fe3d102264ea44ab9546188203bec2643f0903a7a839b83ecd3c6d6", nonce: "384", blockHash: "0xffdcba701f1b98bcd3b3756c8b9f0f497d91cbacd4fc88dfbe62df2fca9e8cf0", transactionIndex: "15", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000178cc2027c4d", contractAddress: "", cumulativeGasUsed: "1145576", gasUsed: "28974", confirmations: "1012029"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "25893317803085"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "25893317803085", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542209271 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "25893317803085"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"27212991822833\" )", async function( ) {
		const txOriginal = {blockNumber: "6704399", timeStamp: "1542220065", hash: "0x381ddec8ec7ee705086f811617aa81833063cfb5a464000a9bb17228d955c5ce", nonce: "385", blockHash: "0x187de081c40c25cd392787ea84c6d1889b75c74cf2a072c6223c6e2514c6492c", transactionIndex: "45", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000018c004b5fbf1", contractAddress: "", cumulativeGasUsed: "2975551", gasUsed: "28974", confirmations: "1011294"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "27212991822833"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "27212991822833", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542220065 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "27212991822833"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"28281089259818\" )", async function( ) {
		const txOriginal = {blockNumber: "6705204", timeStamp: "1542230876", hash: "0xd69b5fbe841531f3dbfc6548ee55f0eda85ac185eb5841a5efad1f75491e9e25", nonce: "386", blockHash: "0x1d5b18bfeda11bc30d6888fee159970d80ec308366cdfb509115ec3b8e271c89", transactionIndex: "115", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "3250000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000019b8b447792a", contractAddress: "", cumulativeGasUsed: "7882158", gasUsed: "28974", confirmations: "1010489"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "28281089259818"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "28281089259818", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542230876 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "28281089259818"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"27827757014299\" )", async function( ) {
		const txOriginal = {blockNumber: "6706022", timeStamp: "1542242291", hash: "0xe0768fb4ed3dd3019242e9c50bf6b37a04b03d52dde6ff2c35bad90e3ea7c5bc", nonce: "387", blockHash: "0x0d91ee56725676b11e1188370c90735ed3349b8c1b4e71d16e7ade424c805860", transactionIndex: "118", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x957054930000000000000000000000000000000000000000000000000000194f27925d1b", contractAddress: "", cumulativeGasUsed: "7667122", gasUsed: "28974", confirmations: "1009671"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "27827757014299"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "27827757014299", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542242291 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "27827757014299"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"28236154948639\" )", async function( ) {
		const txOriginal = {blockNumber: "6706712", timeStamp: "1542252552", hash: "0x02d71d1e70358e5313a72908cbbff1f1b29cd87627b57890c03b6f9a5474c254", nonce: "388", blockHash: "0x84a8c9ce7e42f43cdf07c202fdd6ff0a9e6fb48c15f3372d6dc4e26a5e191fb5", transactionIndex: "20", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "16000000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000019ae3dfc4c1f", contractAddress: "", cumulativeGasUsed: "1032089", gasUsed: "28974", confirmations: "1008981"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "28236154948639"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "28236154948639", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542252552 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "28236154948639"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"28331221329186\" )", async function( ) {
		const txOriginal = {blockNumber: "6707445", timeStamp: "1542263285", hash: "0x51163e675782ee16300364d45b511364361093192f564e35fc9b8716abbde019", nonce: "389", blockHash: "0xdcadda00159340d5f40fc42748d460e9135894e03caa3d434247c8d607e11558", transactionIndex: "73", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "9800000000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000019c460622522", contractAddress: "", cumulativeGasUsed: "4337684", gasUsed: "28974", confirmations: "1008248"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "28331221329186"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "28331221329186", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542263285 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[38,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "28331221329186"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[38,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setDeklaPrice( \"28193508850716\" )", async function( ) {
		const txOriginal = {blockNumber: "6708259", timeStamp: "1542274077", hash: "0xbe516afa4844167aa0b29cbbccd18acb09795d1660f7ad646d9b55b0d3ed8182", nonce: "390", blockHash: "0x19a986defb59727555dbad2f136d01936879beacaa2f9001a31991bad4c6d685", transactionIndex: "75", from: "0x315fb673a6fa8720cf0341795faad602061d1267", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "28974", gasPrice: "7562500000", isError: "0", txreceipt_status: "1", input: "0x95705493000000000000000000000000000000000000000000000000000019a450147c1c", contractAddress: "", cumulativeGasUsed: "4099026", gasUsed: "28974", confirmations: "1007434"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_price", value: "28193508850716"}], name: "setDeklaPrice", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setDeklaPrice(uint256)" ]( "28193508850716", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542274077 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "price", type: "uint256"}, {indexed: false, name: "sender", type: "address"}], name: "UpdateDeklaPriceSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "UpdateDeklaPriceSuccessful", events: [{name: "price", type: "uint256", value: "28193508850716"}, {name: "sender", type: "address", value: "0x315fb673a6fa8720cf0341795faad602061d1267"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "71160449909809" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[11], \"510500000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708537", timeStamp: "1542278277", hash: "0x32fee523eec92bc3e8bd2d029347f9d98040349cb52231a80e497d78228211c4", nonce: "9", blockHash: "0xf5ca0ac2f9ccedc69012c84c11697cb1a6a0cbd9166ed8628a6bc3e7f9c3a2c5", transactionIndex: "126", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "118231", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e0000000000000000000000007487d77070743da4b67cbcfb86de75ce3a6e8cb8000000000000000000000000000000000000000000006c1a42ad07147210000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041f2c947beba3efd07a8c24cc4778f226d9d4e71bc11a733a2ea2d49d25b76e276799500ce45f78248c525a5d8da725d768f2b7cc0661c0d5279d9126201d7e27f1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7403474", gasUsed: "78821", confirmations: "1007156"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[11]}, {type: "uint256", name: "_amount", value: "510500000000000000000000"}, {type: "bytes", name: "_sig", value: "0xf2c947beba3efd07a8c24cc4778f226d9d4e71bc11a733a2ea2d49d25b76e276799500ce45f78248c525a5d8da725d768f2b7cc0661c0d5279d9126201d7e27f1c"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[11], "510500000000000000000000", "0xf2c947beba3efd07a8c24cc4778f226d9d4e71bc11a733a2ea2d49d25b76e276799500ce45f78248c525a5d8da725d768f2b7cc0661c0d5279d9126201d7e27f1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542278277 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[40,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0x7487d77070743da4b67cbcfb86de75ce3a6e8cb8"}, {name: "amount", type: "uint256", value: "510500000000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[40,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[12], \"570000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708574", timeStamp: "1542278752", hash: "0x28f337733c339ff2390c44a047303f6ca03514baea1cbbb2b380d412f92478c3", nonce: "10", blockHash: "0x8971fcfe8953729b28dd5648315157f5e428fef616a26a6de2c7a00380a547b9", transactionIndex: "40", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "80297", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e000000000000000000000000853df570c6e76f9a373a9e3b2861cb646fa0e0f70000000000000000000000000000000000000000000078b3c30cea91b040000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041da973f4257f8ca9f85b8946bb7dc3f03f8d03193adec2d56951ceb74972d4fd844cf0fcc6ae0a2bdcac4cc63098d690b4873bfc92ce6f0d68dac8506ed3ad7f51b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2939446", gasUsed: "78865", confirmations: "1007119"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[12]}, {type: "uint256", name: "_amount", value: "570000000000000000000000"}, {type: "bytes", name: "_sig", value: "0xda973f4257f8ca9f85b8946bb7dc3f03f8d03193adec2d56951ceb74972d4fd844cf0fcc6ae0a2bdcac4cc63098d690b4873bfc92ce6f0d68dac8506ed3ad7f51b"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[12], "570000000000000000000000", "0xda973f4257f8ca9f85b8946bb7dc3f03f8d03193adec2d56951ceb74972d4fd844cf0fcc6ae0a2bdcac4cc63098d690b4873bfc92ce6f0d68dac8506ed3ad7f51b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542278752 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[41,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0x853df570c6e76f9a373a9e3b2861cb646fa0e0f7"}, {name: "amount", type: "uint256", value: "570000000000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[41,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[13], \"132000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708579", timeStamp: "1542278819", hash: "0x90cf9d54f90206ad691b86a475059d0591f012339298ca36421aad00a7b1ee48", nonce: "11", blockHash: "0x1d36725d696dd38c8aee83fe6457f6b4c624627d6eed0c8787e616d69e8c82b0", transactionIndex: "78", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "78327", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xea01df7e0000000000000000000000005bd87fadb913901ae56769b171d461ef3d3eb3ae000000000000000000000000000000000000000000001bf3bbfd9a06ca80000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041b3584271ad9415b1ef8fb162d956244e6c88f8ecd1bc9bc948ef76e2c1b82a6b484797b7ab4e063eab37af6c71c1c07bc18f7e14afaf770bec0198ef6d40675f1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "6782523", gasUsed: "78327", confirmations: "1007114"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[13]}, {type: "uint256", name: "_amount", value: "132000000000000000000000"}, {type: "bytes", name: "_sig", value: "0xb3584271ad9415b1ef8fb162d956244e6c88f8ecd1bc9bc948ef76e2c1b82a6b484797b7ab4e063eab37af6c71c1c07bc18f7e14afaf770bec0198ef6d40675f1c"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[14], \"790000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708586", timeStamp: "1542278880", hash: "0xc031546af63af919c69dd377d13dfa5cf8b92644d0feb81896910aeba233b6d4", nonce: "12", blockHash: "0x57bd4d69a1b74d5863620acaef422890612035d42ffe17d6a8c635b8edc399ec", transactionIndex: "71", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "78327", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xea01df7e000000000000000000000000ca57279327f0fffba89029418dfbf44571fe05e80000000000000000000000000000000000000000000010ba993ca00fb3600000000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000413bc9382cf7e63f51a086dda1ba07c210ceb361b8ecdea80ce2b7aacf88934f89470abb78e8ef03f7c8cefca1deb7c1eb850835fa21a3481cfa7fafcd2d705c901c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "3617195", gasUsed: "78327", confirmations: "1007107"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[14]}, {type: "uint256", name: "_amount", value: "79000000000000000000000"}, {type: "bytes", name: "_sig", value: "0x3bc9382cf7e63f51a086dda1ba07c210ceb361b8ecdea80ce2b7aacf88934f89470abb78e8ef03f7c8cefca1deb7c1eb850835fa21a3481cfa7fafcd2d705c901c"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[13], \"132000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708682", timeStamp: "1542280222", hash: "0x7bb23c0955ff5a59fc9f43447da5f256e83fd90eacb75635e60ead40918148f9", nonce: "13", blockHash: "0xd8fc8e72ef4cbfabece71c102a62ee0c830626c56e3bbb6d2ba73a0d7a434d97", transactionIndex: "84", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "80327", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e0000000000000000000000005bd87fadb913901ae56769b171d461ef3d3eb3ae000000000000000000000000000000000000000000001bf3bbfd9a06ca80000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041b3584271ad9415b1ef8fb162d956244e6c88f8ecd1bc9bc948ef76e2c1b82a6b484797b7ab4e063eab37af6c71c1c07bc18f7e14afaf770bec0198ef6d40675f1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "4861283", gasUsed: "78885", confirmations: "1007011"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[13]}, {type: "uint256", name: "_amount", value: "132000000000000000000000"}, {type: "bytes", name: "_sig", value: "0xb3584271ad9415b1ef8fb162d956244e6c88f8ecd1bc9bc948ef76e2c1b82a6b484797b7ab4e063eab37af6c71c1c07bc18f7e14afaf770bec0198ef6d40675f1c"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[13], "132000000000000000000000", "0xb3584271ad9415b1ef8fb162d956244e6c88f8ecd1bc9bc948ef76e2c1b82a6b484797b7ab4e063eab37af6c71c1c07bc18f7e14afaf770bec0198ef6d40675f1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542280222 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[44,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0x5bd87fadb913901ae56769b171d461ef3d3eb3ae"}, {name: "amount", type: "uint256", value: "132000000000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[44,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[14], \"790000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708725", timeStamp: "1542281035", hash: "0xff64e5ae43ed3addaf63976221d66548f61488e358158c0651e562943fee2bfe", nonce: "14", blockHash: "0xd5bc2deea58311bc5bdc245e610c1d81f39e355171eb17f59b8ef4bbd0577e9e", transactionIndex: "148", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "80327", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e000000000000000000000000ca57279327f0fffba89029418dfbf44571fe05e80000000000000000000000000000000000000000000010ba993ca00fb360000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041b6f48003f012d86769ad76bd66c051cabb4c98b50133b392272ee75ede251bde1abc9e5b9580fd1f7c09e8ff9436f989deccb614a3d68c245a466da96cef1ca71c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7854395", gasUsed: "78885", confirmations: "1006968"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[14]}, {type: "uint256", name: "_amount", value: "79000000000000000000000"}, {type: "bytes", name: "_sig", value: "0xb6f48003f012d86769ad76bd66c051cabb4c98b50133b392272ee75ede251bde1abc9e5b9580fd1f7c09e8ff9436f989deccb614a3d68c245a466da96cef1ca71c"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[14], "79000000000000000000000", "0xb6f48003f012d86769ad76bd66c051cabb4c98b50133b392272ee75ede251bde1abc9e5b9580fd1f7c09e8ff9436f989deccb614a3d68c245a466da96cef1ca71c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542281035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[45,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0xca57279327f0fffba89029418dfbf44571fe05e8"}, {name: "amount", type: "uint256", value: "79000000000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[45,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[15], \"650000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708725", timeStamp: "1542281035", hash: "0x50182a134353a5063357d011912fea87c00aa1850a785cd882bdb69e79a90989", nonce: "15", blockHash: "0xd5bc2deea58311bc5bdc245e610c1d81f39e355171eb17f59b8ef4bbd0577e9e", transactionIndex: "149", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "80827", gasPrice: "5000000000", isError: "1", txreceipt_status: "0", input: "0xea01df7e000000000000000000000000a0d8e7564af7cd56a4e50580ec7be253fe4867f1000000000000000000000000000000000000000000000dc3a8351f3d86a0000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041b5247bbe2e139df8a27d3829a4c320ff08a29f0fbf5d088bec04d384e8607c25650240a25563425451a07e6a9a58b0e79a0fa3e9d442dd12c2f5f23f51a22e041c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7892130", gasUsed: "37735", confirmations: "1006968"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[15]}, {type: "uint256", name: "_amount", value: "65000000000000000000000"}, {type: "bytes", name: "_sig", value: "0xb5247bbe2e139df8a27d3829a4c320ff08a29f0fbf5d088bec04d384e8607c25650240a25563425451a07e6a9a58b0e79a0fa3e9d442dd12c2f5f23f51a22e041c"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[15], "65000000000000000000000", "0xb5247bbe2e139df8a27d3829a4c320ff08a29f0fbf5d088bec04d384e8607c25650240a25563425451a07e6a9a58b0e79a0fa3e9d442dd12c2f5f23f51a22e041c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542281035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[16], \"175000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708783", timeStamp: "1542281889", hash: "0x2fcdbf7150953ead6422dd78dbd402c157bf931841cf287f37d244f7df2f37f6", nonce: "16", blockHash: "0x985fec3acd88522c62db970494d07965d60406d7178d98d486b118dfeb802908", transactionIndex: "90", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "81327", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e000000000000000000000000baa7a4da76847e61bbdca56e1dd8c7437db56f1500000000000000000000000000000000000000000000250ec4ddca432f6000000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004145757524d08e2087239e32933eda3be6b897d3a5c0770dc4ae84347c7ca26a5a5d34f1f6b6399c8f97a217bafb2e92f2c178768c7a909011782b2b37cfb7ce8f1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7107502", gasUsed: "78885", confirmations: "1006910"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[16]}, {type: "uint256", name: "_amount", value: "175000000000000000000000"}, {type: "bytes", name: "_sig", value: "0x45757524d08e2087239e32933eda3be6b897d3a5c0770dc4ae84347c7ca26a5a5d34f1f6b6399c8f97a217bafb2e92f2c178768c7a909011782b2b37cfb7ce8f1c"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[16], "175000000000000000000000", "0x45757524d08e2087239e32933eda3be6b897d3a5c0770dc4ae84347c7ca26a5a5d34f1f6b6399c8f97a217bafb2e92f2c178768c7a909011782b2b37cfb7ce8f1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542281889 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[47,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0xbaa7a4da76847e61bbdca56e1dd8c7437db56f15"}, {name: "amount", type: "uint256", value: "175000000000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[47,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[17], \"110000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708796", timeStamp: "1542282019", hash: "0xd4195b2c9f339d00e003cbf2890e2c6d3be1957f88e2087c107399df17857487", nonce: "17", blockHash: "0xed2720590b8e918aa8a5b4f44e9311870c4ab975916c24ca12d89e7724483bcc", transactionIndex: "136", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "81297", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e00000000000000000000000015c40d6ae972c54111621bce26b4d0f6696a03a500000000000000000000000000000000000000000000174b1ca8ab05a8c000000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000004154fdec788f5bd0ab100deaf8b93fe64a597c82870a6c9cad591f1067567f97d44df9486b16dfef2c76b9b3273e1e98ef0ae817d1eadd487d6297e9e745331e061b00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "5410346", gasUsed: "78865", confirmations: "1006897"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[17]}, {type: "uint256", name: "_amount", value: "110000000000000000000000"}, {type: "bytes", name: "_sig", value: "0x54fdec788f5bd0ab100deaf8b93fe64a597c82870a6c9cad591f1067567f97d44df9486b16dfef2c76b9b3273e1e98ef0ae817d1eadd487d6297e9e745331e061b"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[17], "110000000000000000000000", "0x54fdec788f5bd0ab100deaf8b93fe64a597c82870a6c9cad591f1067567f97d44df9486b16dfef2c76b9b3273e1e98ef0ae817d1eadd487d6297e9e745331e061b", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542282019 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[48,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0x15c40d6ae972c54111621bce26b4d0f6696a03a5"}, {name: "amount", type: "uint256", value: "110000000000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[48,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawDekla( addressList[18], \"550000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6708803", timeStamp: "1542282074", hash: "0x9a9e70f0b39913f0c743a587b76e3d05cd7684c2f03440ba0da93335fad6fb61", nonce: "18", blockHash: "0x49ecdc374a9f39d0f6a6f0ceefe93e6e28d9c914f70e2a9c7493f11711b2bf1e", transactionIndex: "103", from: "0x7aeaf9c8a62caf79c60b0eeb1e57eaefc140a5ca", to: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da", value: "0", gas: "81231", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xea01df7e0000000000000000000000004d6697c4926b22ab5b79a7f9024063cb0481e2e7000000000000000000000000000000000000000000000ba58e545582d460000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000041d3bb0dd5590041dc53f362d2aca2b7f81c27e9f14b1ed60b030e8e5eeb38fe117d3d013eb4f46847c60727154c550dac4e62ef87a8b1a52b3a9db4cc6308211d1c00000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "7106971", gasUsed: "78821", confirmations: "1006890"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[4], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_withdrawWallet", value: addressList[18]}, {type: "uint256", name: "_amount", value: "55000000000000000000000"}, {type: "bytes", name: "_sig", value: "0xd3bb0dd5590041dc53f362d2aca2b7f81c27e9f14b1ed60b030e8e5eeb38fe117d3d013eb4f46847c60727154c550dac4e62ef87a8b1a52b3a9db4cc6308211d1c"}], name: "withdrawDekla", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawDekla(address,uint256,bytes)" ]( addressList[18], "55000000000000000000000", "0xd3bb0dd5590041dc53f362d2aca2b7f81c27e9f14b1ed60b030e8e5eeb38fe117d3d013eb4f46847c60727154c550dac4e62ef87a8b1a52b3a9db4cc6308211d1c", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542282074 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "WithdrawDeklaSuccessful", type: "event"} ;
		console.error( "eventCallOriginal[49,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "WithdrawDeklaSuccessful", events: [{name: "sender", type: "address", value: "0x4d6697c4926b22ab5b79a7f9024063cb0481e2e7"}, {name: "amount", type: "uint256", value: "55000000000000000000000"}], address: "0xb28bf5232f743c61f8c8f0db7b89ba88447261da"}] ;
		console.error( "eventResultOriginal[49,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[4], balance: "355455400892680223" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[4], balance: ( await web3.eth.getBalance( addressList[4], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
