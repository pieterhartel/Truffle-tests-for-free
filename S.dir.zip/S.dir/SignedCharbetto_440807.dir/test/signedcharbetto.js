const SignedCharbetto = artifacts.require( "./SignedCharbetto.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "SignedCharbetto" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xEa2FDf90Bc0cA29eEc91e1c952f83Ba2b0440807", "0xf94A427C54082Dd674dF41D7629C37E7928A98A2", "0x92a1Ab397360A103cF7F54832ac9A3de73d1F45D", "0x1DFBDEDAB24A9738D129bA9c76DF521Be4Ceb2Cf", "0x46Ba9e653d7230Dd828fE45a2A69CA68E7ff69D2", "0xD15199f2B5909bC36CA3bb3Ee07Ef68eCD605E9f", "0x2CbDA5fB93f08cC196A196bfA8Bf043713DC7576", "0x1Af8A835141b721F3D29ccaFf2C46DDb1415965E"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "getFinalShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalVariants", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "finishedWithdrawalBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "addonEndsIn", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getPayoutValueSender", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getBytes", outputs: [{name: "", type: "bytes"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getGameAdmin", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isRandomStored", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "prizeName", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getVersion", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_lastBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMinPrize", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gameFinishing", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "canAddCharity", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "blockExpired", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getIdHash", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "blocks2Finish", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "dev", type: "address"}], name: "getDeveloperUrl", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getRandomValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "dev", type: "address"}], name: "getDeveloperName", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "endsIn", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "minPrize", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "defaultGameAvailable", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "defaultGameId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxBlocks", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "signed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "number", type: "uint256"}, {name: "minPrize", type: "uint256"}, {name: "maxPrize", type: "uint256"}], name: "calculatePrize", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "randomValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "calcGameAddon", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "gameProfited", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_afterFinishLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "info_admin", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "addon", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "transferInteractionsAllowed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "prizeFunctionName", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getTotalPayoutValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "totalBets", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "contract_id", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getFinalProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "getWinner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "charity", type: "address"}], name: "getCharityUrl", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "info_address", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startOnlyMinPrizes", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isItReallyCharbetto", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "autoCreationAfterOwnAllowed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getStartGameStatus", outputs: [{name: "", type: "bool"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getLastBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "repeatBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxPrizeShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_charityShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getId", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "charity", type: "address"}], name: "getCharityName", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getLastProfitSync", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "payedOut", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "dedicatedCharityAddress", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "r", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "contract_signature", outputs: [{name: "", type: "bytes"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gameFinishedBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getAddonBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "gameExists", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "canStartGame", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gameAdmin", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "randomBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMaxPrize", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "canStoreRandom", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMaxGameAddon", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "v", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCharityShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "sm_profits", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "dedicatedCharitySet", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "s", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "prize", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "autoCreationAllowed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getSignature", outputs: [{name: "", type: "uint8"}, {name: "", type: "bytes32"}, {name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getProfitedCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startGameAddon", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "lastCharityAdded", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "creationAllowed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "addr", type: "address"}], name: "getPayoutValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_lastProfitSync", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMaxPrizeShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getRepeatBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "sm_charity", outputs: [{name: "receiver", type: "address"}, {name: "description", type: "string"}, {name: "url", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "reservedBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "finishedGame", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "number", type: "uint256"}], name: "calcGameLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getDataHash", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startProfitedGamesAllowed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "availableBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMinGameAddon", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "totalBalance", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "x", type: "uint256"}, {name: "fMax", type: "uint256"}, {name: "maxPrize", type: "uint256"}], name: "calcPrizeX", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "randomBlockPassed", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "developersAdded", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCharityProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "contract_version", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_finalShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startGameId", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMaxGameLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "canUpdatePayout", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_developerShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_lastCharityAdded", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_dedicatedCharity", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_profitSyncLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getMinGameLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "maxLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "profitValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "sm_reciever", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "sm_maxDevelopers", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "finishedWithdrawalTime", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}, {name: "better", type: "address"}], name: "getBet", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "gameId", type: "uint256"}], name: "lastBetBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isSigned", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getDeveloperShare", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "gameFinished", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getCreateFastGamesCount", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "participant", type: "address"}], name: "getTransferProfitedGame", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startGameLength", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startPrizeValue", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "isRandomAvailable", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "sm_developers", outputs: [{name: "receiver", type: "address"}, {name: "description", type: "string"}, {name: "url", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getDeveloperProfit", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "addonBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "getWholePrize", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "MoneyDeposited", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "reciever", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "MoneyWithdrawn", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "gameFinish", type: "bool"}, {indexed: false, name: "developerProfit", type: "uint256"}, {indexed: false, name: "charityProfit", type: "uint256"}, {indexed: false, name: "finalProfit", type: "uint256"}, {indexed: false, name: "developerCount", type: "uint256"}, {indexed: false, name: "charityCount", type: "uint256"}, {indexed: false, name: "dedicated", type: "bool"}, {indexed: false, name: "dedicatedCharity", type: "address"}], name: "ProfitRecalculated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "charity", type: "address"}, {indexed: false, name: "name", type: "string"}, {indexed: false, name: "url", type: "string"}], name: "CharityAdded", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "charity", type: "address"}], name: "DedicatedCharitySelected", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "developer", type: "address"}, {indexed: false, name: "name", type: "string"}, {indexed: false, name: "url", type: "string"}], name: "DeveloperAdded", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "MinGameLengthAltered", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "MaxGameLengthAltered", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "AddonAltered", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "prize", type: "uint256"}], name: "MinPrizeAltered", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "prize", type: "uint256"}], name: "MaxPrizeAltered", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "finishingBlock", type: "uint256"}], name: "GameStopInitiated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "TransferInteractionsChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "StartOnlyMinPrizesChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "StartProfitedGamesAllowedChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "AutoCreationChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "AutoCreationAfterOwnChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newTotalVariants", type: "uint256"}], name: "TotalVariantsChanged", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "share", type: "uint256"}], name: "MaxPrizeShareAltered", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "RepeatBlockAltered", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "RepeatAddonBlockAltered", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "better", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "TransferBet", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "GameProfitedEvent", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "faseGamesCreate", type: "uint256"}], name: "FastGamesChanged", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["MoneyDeposited(address,uint256)", "MoneyWithdrawn(address,uint256)", "ProfitRecalculated(bool,uint256,uint256,uint256,uint256,uint256,bool,address)", "CharityAdded(address,string,string)", "DedicatedCharitySelected(address)", "DeveloperAdded(address,string,string)", "RandomValueCalculated(uint256,uint256)", "GameStarted(uint256,address,uint256,uint256,uint256)", "GameBet(uint256,address,address,uint256,uint256,uint256)", "GamePrizeTaken(uint256,address)", "BalanceReserved(uint256,uint256)", "BalanceFreed(uint256,uint256)", "MinGameLengthAltered(uint256)", "MaxGameLengthAltered(uint256)", "AddonAltered(uint256)", "MinPrizeAltered(uint256)", "MaxPrizeAltered(uint256)", "GameStopInitiated(uint256)", "TransferInteractionsChanged(bool)", "StartOnlyMinPrizesChanged(bool)", "StartProfitedGamesAllowedChanged(bool)", "AutoCreationChanged(bool)", "AutoCreationAfterOwnChanged(bool)", "TotalVariantsChanged(uint256)", "MaxPrizeShareAltered(uint256)", "RepeatBlockAltered(uint256)", "RepeatAddonBlockAltered(uint256)", "NextGameIdCalculated(uint256)", "DefaultGameUpdated(uint256)", "TransferBet(address,uint256)", "GameProfitedEvent(uint256)", "FastGamesChanged(uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x8183e4d4ee059a1213db94a2d1d9486616f49a493fca6f883a302414b5bd9e55", "0xe020566b3b7b0c11a72c9a01a70122b5bb1e70d24128480342bad5367fbf54e2", "0x0558e9aec8a13642fb94517c7959feb55f1d42a0cf5b554c348e38168c8eb075", "0xe98eae7756c47bbacd394b79782d9696a7e8dd84adc9a3128ddca61111937eb1", "0x057167a37e9e9f70cb6752589b340e1a944f368c915bad0dfc10c8b370c4f6cd", "0x0600e83b227523075596bb2d9c59ed7b1b7fb975a1a7c32ebb7de5b6cc1de5c0", "0x4db6279fb0d934b75994aa4fb440b70d3c00f9166e7699e275a8fa9bf6dbb188", "0xd638ae86679fdf64b28c14eae71d8facbf04f828463fdc2c9f0bf05089ef98e5", "0xd40a6db8f4ca18d940182bf30335bc2fab8caf7f95fcaae428320e0df1b312d0", "0xd66d3a5b87a89afbe40fcd32f9e92855d8cb16f537d48be7e2d14144c4c1ca8a", "0x47c1b775b98f7e402e82ef442bf727a19a0b9296877a0b73539a2f4d3012a1c3", "0xa66a368abdffd9c82bd89bf9f0aab7c0897cac2ee311193e133373f1c768d3d6", "0xf04223328f1ed8cd9e356506c271e6f18507f6dd9190d3c5dac8224c68ba7b2b", "0xef601042d81cab5588225f54b72087d8bf7bab4d668ceb6063565e80ca3c2842", "0x4c9459f528ab9257f3870eaebd0cc0f06d069e8fa2c738631056cf07a0b40af8", "0xccaf69211f59f71e62de53a2eb1197ef9d666e960683c8e7adcb6b2a3212db81", "0x14499454f789bc2d39f31460b672671dc4711b2b66a3dee1e6bfd3a0ccd43830", "0x048221434c6bee70b4c04eead8f38a156e9ed428aa4975bb12feb2401af8d850", "0x7c82bcd425ba8097111b54618ff3073a5044fa4bb3dafca39a446fd1e72e8116", "0x099eb4254886a2f6bb96e2eb7aa037967102d27d51f6515fce8de84c048e2388", "0x4fbb4af81d2b013bb7e76be215ca95a2f4d41d9dcffc290e81a083797fceaaa7", "0x1564fdc1970cdbca210350b6eb577cac9d60b0bb0e3ab9a97215e6a6d23cbf27", "0x282316048e785317a9bf7cf34206730c2c5d56da31f4bff884a58740cbeef1c6", "0x961e7526ce8a93f272030e137b0392e1f94a507515ce21e679a8a1b348607e74", "0x10e45d55778a9c72b2549cf14310d8147094155631bddadbea70e67d9954e32a", "0xd0af1849eac9019eb74c638eaf8fc3a05a5bd7a7bbb54eac3c50b1ad9eb79cd5", "0xd2cd581de221514361fb2d5b8d65c574ae2ea0aac2a97ff482da2e04332c23a8", "0xbd9a70ce46ce30bf039c0af1fa204e8747284408731efdb373e39baae1017cd7", "0xafea07db85fe98f06d7161fda2e81d59e541c5526874eacba52afec1b5bd0569", "0x2a830e5915f63665d6100f8a504a99187d2d646bbcea7d854e8a912c6f286c39", "0x058b1fcf0495d75d41be2830df92b3927bf6b4393abe2100bff36adcb96a208e", "0x698f702a2d9f145cf89875db8cbf12bcbe23179239dfc1db8880043b330114c1"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6607415 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6698082 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "admin_", value: 3}, {type: "uint256", name: "version_", value: "3"}, {type: "address", name: "infoContract_", value: 4}, {type: "address", name: "infoAdminAddress_", value: 3}], name: "SignedCharbetto", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "getFinalShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFinalShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalVariants", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalVariants()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finishedWithdrawalBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finishedWithdrawalBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "addonEndsIn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addonEndsIn(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getPayoutValueSender", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPayoutValueSender()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getBytes", outputs: [{name: "", type: "bytes"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBytes()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getGameAdmin", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGameAdmin()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isRandomStored", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isRandomStored()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "prizeName", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prizeName()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getVersion", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getVersion()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_lastBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_lastBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMinPrize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMinPrize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gameFinishing", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameFinishing()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "canAddCharity", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "canAddCharity()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "blockExpired", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "blockExpired()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getIdHash", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getIdHash()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "blocks2Finish", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "blocks2Finish()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "dev", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getDeveloperUrl", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDeveloperUrl(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getRandomValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRandomValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "dev", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getDeveloperName", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDeveloperName(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "endsIn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endsIn(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "minPrize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "minPrize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "defaultGameAvailable", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "defaultGameAvailable()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "defaultGameId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "defaultGameId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxBlocks", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",25] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxBlocks()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",25] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "signed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",26] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "signed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",26] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "number", value: random.range( maxRandom )}, {type: "uint256", name: "minPrize", value: random.range( maxRandom )}, {type: "uint256", name: "maxPrize", value: random.range( maxRandom )}], name: "calculatePrize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",27] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calculatePrize(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",27] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "randomValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",28] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "randomValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",28] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "calcGameAddon", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",29] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcGameAddon(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",29] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "gameProfited", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",30] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameProfited(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",30] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_afterFinishLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",31] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_afterFinishLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",31] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "info_admin", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",32] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "info_admin()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",32] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "addon", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",33] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addon()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",33] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "transferInteractionsAllowed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",34] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "transferInteractionsAllowed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",34] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "prizeFunctionName", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",35] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prizeFunctionName()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",35] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getTotalPayoutValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",36] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTotalPayoutValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",36] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "totalBets", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",37] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalBets(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",37] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contract_id", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",38] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contract_id()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",38] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getFinalProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",39] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getFinalProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",39] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "getWinner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",40] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getWinner(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",40] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "charity", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getCharityUrl", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",41] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCharityUrl(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",41] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "info_address", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",42] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "info_address()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",42] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startOnlyMinPrizes", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",43] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startOnlyMinPrizes()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",43] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isItReallyCharbetto", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",44] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isItReallyCharbetto()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",44] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "autoCreationAfterOwnAllowed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",45] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "autoCreationAfterOwnAllowed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",45] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getStartGameStatus", outputs: [{name: "", type: "bool"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}, {name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",46] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getStartGameStatus()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",46] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getLastBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",47] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLastBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",47] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "repeatBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",48] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "repeatBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",48] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxPrizeShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",49] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxPrizeShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",49] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_charityShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",50] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_charityShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",50] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getId", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",51] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",51] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "charity", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getCharityName", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",52] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCharityName(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",52] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getLastProfitSync", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",53] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getLastProfitSync()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",53] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "payedOut", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",54] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "payedOut(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",54] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "dedicatedCharityAddress", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",55] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dedicatedCharityAddress()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",55] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "r", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",56] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "r()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",56] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contract_signature", outputs: [{name: "", type: "bytes"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",57] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contract_signature()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",57] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gameFinishedBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",58] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameFinishedBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",58] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getAddonBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",59] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getAddonBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",59] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "gameExists", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",60] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameExists(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",60] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "canStartGame", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",61] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "canStartGame()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",61] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gameAdmin", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",62] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameAdmin()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",62] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "randomBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",63] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "randomBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",63] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMaxPrize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",64] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMaxPrize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",64] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "canStoreRandom", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",65] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "canStoreRandom()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",65] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMaxGameAddon", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",66] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMaxGameAddon()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",66] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "v", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",67] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "v()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",67] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCharityShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",68] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCharityShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",68] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "sm_profits", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",69] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_profits(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",69] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "dedicatedCharitySet", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",70] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "dedicatedCharitySet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",70] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "s", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",71] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "s()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",71] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "prize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",72] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "prize(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",72] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "autoCreationAllowed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",73] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "autoCreationAllowed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",73] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getSignature", outputs: [{name: "", type: "uint8"}, {name: "", type: "bytes32"}, {name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",74] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getSignature()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",74] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getProfitedCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",75] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getProfitedCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",75] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startGameAddon", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",76] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startGameAddon()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",76] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "lastCharityAdded", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",77] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lastCharityAdded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",77] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "creationAllowed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",78] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "creationAllowed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",78] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "addr", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getPayoutValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",79] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getPayoutValue(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",79] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_lastProfitSync", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",80] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_lastProfitSync()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",80] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMaxPrizeShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",81] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMaxPrizeShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",81] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getRepeatBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",82] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRepeatBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",82] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "sm_charity", outputs: [{name: "receiver", type: "address"}, {name: "description", type: "string"}, {name: "url", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",83] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_charity(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",83] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "reservedBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",84] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "reservedBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",84] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "finishedGame", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",85] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finishedGame(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",85] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "number", value: random.range( maxRandom )}], name: "calcGameLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",86] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcGameLength(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",86] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getDataHash", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",87] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDataHash()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",87] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startProfitedGamesAllowed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",88] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startProfitedGamesAllowed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",88] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "availableBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",89] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "availableBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",89] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMinGameAddon", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",90] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMinGameAddon()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",90] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "totalBalance", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",91] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalBalance()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",91] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "x", value: random.range( maxRandom )}, {type: "uint256", name: "fMax", value: random.range( maxRandom )}, {type: "uint256", name: "maxPrize", value: random.range( maxRandom )}], name: "calcPrizeX", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",92] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "calcPrizeX(uint256,uint256,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value,methodCall.inputs[ 2 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",92] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "randomBlockPassed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",93] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "randomBlockPassed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",93] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "developersAdded", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",94] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "developersAdded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",94] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCharityProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",95] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCharityProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",95] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "contract_version", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",96] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contract_version()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",96] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_finalShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",97] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_finalShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",97] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startGameId", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",98] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startGameId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",98] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMaxGameLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",99] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMaxGameLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",99] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "canUpdatePayout", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",100] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "canUpdatePayout()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",100] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_developerShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",101] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_developerShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",101] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_lastCharityAdded", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",102] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_lastCharityAdded()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",102] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_dedicatedCharity", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",103] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_dedicatedCharity()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",103] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_profitSyncLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",104] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_profitSyncLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",104] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getMinGameLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",105] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getMinGameLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",105] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "maxLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",106] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "maxLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",106] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "profitValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",107] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "profitValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",107] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "sm_reciever", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",108] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_reciever(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",108] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "sm_maxDevelopers", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",109] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_maxDevelopers()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",109] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "finishedWithdrawalTime", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",110] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "finishedWithdrawalTime()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",110] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}, {type: "address", name: "better", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getBet", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",111] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getBet(uint256,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",111] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "gameId", value: random.range( maxRandom )}], name: "lastBetBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",112] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "lastBetBlock(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",112] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isSigned", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",113] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isSigned()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",113] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getDeveloperShare", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",114] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDeveloperShare()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",114] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "gameFinished", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",115] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "gameFinished()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",115] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getCreateFastGamesCount", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",116] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCreateFastGamesCount()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",116] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "participant", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getTransferProfitedGame", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",117] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getTransferProfitedGame(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",117] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startGameLength", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",118] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startGameLength()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",118] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startPrizeValue", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",119] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startPrizeValue()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",119] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "isRandomAvailable", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",120] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isRandomAvailable()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",120] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "sm_developers", outputs: [{name: "receiver", type: "address"}, {name: "description", type: "string"}, {name: "url", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",121] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "sm_developers(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",121] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getDeveloperProfit", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",122] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDeveloperProfit()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",122] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "addonBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",123] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "addonBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",123] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "getWholePrize", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",124] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getWholePrize()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",124] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "SignedCharbetto", function( accounts ) {

	it( "TEST: SignedCharbetto( addressList[3], \"3\", addressList[4], a... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6607415", timeStamp: "1540845671", hash: "0xd461149bcd054d2968f0578bc835a280194283cae8b2b1f8cbe076f3df724a5c", nonce: "18", blockHash: "0x7f185ea80da5e66890ab7615795f4790daef833621079d7a54ef21200ed48edf", transactionIndex: "8", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: 0, value: "0", gas: "7000000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0x02aed6d6000000000000000000000000f94a427c54082dd674df41d7629c37e7928a98a2000000000000000000000000000000000000000000000000000000000000000300000000000000000000000092a1ab397360a103cf7f54832ac9a3de73d1f45d000000000000000000000000f94a427c54082dd674df41d7629c37e7928a98a2", contractAddress: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", cumulativeGasUsed: "6742702", gasUsed: "6171140", confirmations: "1125448"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "admin_", value: addressList[3]}, {type: "uint256", name: "version_", value: "3"}, {type: "address", name: "infoContract_", value: addressList[4]}, {type: "address", name: "infoAdminAddress_", value: addressList[3]}], name: "SignedCharbetto", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = SignedCharbetto.new( addressList[3], "3", addressList[4], addressList[3], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1540845671 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = SignedCharbetto.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[0,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6607420"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[0,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[0,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6607420"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[0,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: sign( \"28\", \"0x6491dcb6ce5c6b873df961edeb04... )", async function( ) {
		const txOriginal = {blockNumber: "6607420", timeStamp: "1540845718", hash: "0x8a6a38da95a5ee32ed9bcef78ca809d82825b6ef055d6eafc1914fafaa40ac05", nonce: "19", blockHash: "0x952dd7c628122585147cb02081ef08fbaa223fd859c984e294f1ed400b548f65", transactionIndex: "36", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xd8632ae3000000000000000000000000000000000000000000000000000000000000001c6491dcb6ce5c6b873df961edeb043281c807fa13651bd27583575af419bc2f1e598fb589ebb2d546369f33f66cb9884b3a43c521797d449375880929c37a42f8", contractAddress: "", cumulativeGasUsed: "2444788", gasUsed: "101513", confirmations: "1125443"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint8", name: "v_", value: "28"}, {type: "bytes32", name: "r_", value: "0x6491dcb6ce5c6b873df961edeb043281c807fa13651bd27583575af419bc2f1e"}, {type: "bytes32", name: "s_", value: "0x598fb589ebb2d546369f33f66cb9884b3a43c521797d449375880929c37a42f8"}], name: "sign", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "sign(uint8,bytes32,bytes32)" ]( "28", "0x6491dcb6ce5c6b873df961edeb043281c807fa13651bd27583575af419bc2f1e", "0x598fb589ebb2d546369f33f66cb9884b3a43c521797d449375880929c37a42f8", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1540845718 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: setAutoCreation( false )", async function( ) {
		const txOriginal = {blockNumber: "6607472", timeStamp: "1540846365", hash: "0x1d87da24e9498468103b7df478b646737791597fe73359d1bd65cf07763e4d98", nonce: "21", blockHash: "0xda6209e06b1c185e4412920c1256c31086c2634dc5c4808b3453c200a9b508db", transactionIndex: "40", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "3001000000", isError: "0", txreceipt_status: "1", input: "0x695ca9240000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2080559", gasUsed: "29706", confirmations: "1125391"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "allowed", value: false}], name: "setAutoCreation", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAutoCreation(bool)" ]( false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1540846365 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "AutoCreationChanged", type: "event"} ;
		console.error( "eventCallOriginal[2,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AutoCreationChanged", events: [{name: "newValue", type: "bool", value: false}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[2,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setAutoCreation( false )", async function( ) {
		const txOriginal = {blockNumber: "6607483", timeStamp: "1540846527", hash: "0x064b336c1827f895e82fc79dfa4ad501c05ba9d9334417a55ff4e60bb3ee5a06", nonce: "22", blockHash: "0x71296df3b1effbb52cab49d2ec735030e7ad265a4125d501a258a2a2c47f14c6", transactionIndex: "53", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "4001000000", isError: "0", txreceipt_status: "1", input: "0x695ca9240000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2841018", gasUsed: "29706", confirmations: "1125380"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "allowed", value: false}], name: "setAutoCreation", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAutoCreation(bool)" ]( false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1540846527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "AutoCreationChanged", type: "event"} ;
		console.error( "eventCallOriginal[3,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AutoCreationChanged", events: [{name: "newValue", type: "bool", value: false}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[3,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setTransferInteractions( false )", async function( ) {
		const txOriginal = {blockNumber: "6607483", timeStamp: "1540846527", hash: "0x59054f2c29690ca962eb16bc22cc8d4a9c5b9d237029d9e960e95b5593c5099f", nonce: "23", blockHash: "0x71296df3b1effbb52cab49d2ec735030e7ad265a4125d501a258a2a2c47f14c6", transactionIndex: "54", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "4001000000", isError: "0", txreceipt_status: "1", input: "0x37b4098b0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2870233", gasUsed: "29215", confirmations: "1125380"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "allowed", value: false}], name: "setTransferInteractions", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setTransferInteractions(bool)" ]( false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1540846527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "TransferInteractionsChanged", type: "event"} ;
		console.error( "eventCallOriginal[4,18] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TransferInteractionsChanged", events: [{name: "newValue", type: "bool", value: false}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[4,18] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setAutoCreationAfterOwn( false )", async function( ) {
		const txOriginal = {blockNumber: "6607483", timeStamp: "1540846527", hash: "0xe5e42c4ab826acfe2ec0f3cc754b7b88982d7d06cb947e26a71352fe213f2e48", nonce: "24", blockHash: "0x71296df3b1effbb52cab49d2ec735030e7ad265a4125d501a258a2a2c47f14c6", transactionIndex: "55", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "4001000000", isError: "0", txreceipt_status: "1", input: "0x3a53791f0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2884848", gasUsed: "14615", confirmations: "1125380"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "allowed", value: false}], name: "setAutoCreationAfterOwn", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAutoCreationAfterOwn(bool)" ]( false, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1540846527 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "AutoCreationAfterOwnChanged", type: "event"} ;
		console.error( "eventCallOriginal[5,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AutoCreationAfterOwnChanged", events: [{name: "newValue", type: "bool", value: false}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[5,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: alterMaxGameLength( \"300\" )", async function( ) {
		const txOriginal = {blockNumber: "6625305", timeStamp: "1541099295", hash: "0x382eb963caae672d7a0ce58b66d79dea150c5e646d4a7ea3d1bc2cc2e0d35a24", nonce: "25", blockHash: "0x308971548c2acbe30b1879d6bce67d2dd2eda8ef0b12a01c0055ecb85c08e27d", transactionIndex: "61", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xee4eee11000000000000000000000000000000000000000000000000000000000000012c", contractAddress: "", cumulativeGasUsed: "3666467", gasUsed: "31529", confirmations: "1107558"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_maxGameLength", value: "300"}], name: "alterMaxGameLength", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "alterMaxGameLength(uint256)" ]( "300", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1541099295 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "MaxGameLengthAltered", type: "event"} ;
		console.error( "eventCallOriginal[6,13] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MaxGameLengthAltered", events: [{name: "newValue", type: "uint256", value: "300"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[6,13] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: alterRepeatBlock( \"300\" )", async function( ) {
		const txOriginal = {blockNumber: "6625322", timeStamp: "1541099567", hash: "0x932827edcfa938aa6f9e70b97143ffe682384305e196e611a7b6569b6c0f1f74", nonce: "26", blockHash: "0xeb3b991323c6b3f7e1420f22f8886b8e56a1b85505d40eb2df12ed2b45b01c56", transactionIndex: "14", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0x7a34e2f0000000000000000000000000000000000000000000000000000000000000012c", contractAddress: "", cumulativeGasUsed: "5320319", gasUsed: "4300000", confirmations: "1107541"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_repeatBlock", value: "300"}], name: "alterRepeatBlock", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: alterAddonBlock( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6625331", timeStamp: "1541099739", hash: "0x74910a71995a44d1b88931bdc3d23a4a75b0fe579921cda7c791cdf5cf2ad99e", nonce: "27", blockHash: "0x5a46efb993d7a9bc23ff4b616e697dbc65177e7836206c0087bcccea59cd6961", transactionIndex: "29", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x095c343c000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "1585080", gasUsed: "28224", confirmations: "1107532"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_addonBlock", value: "10"}], name: "alterAddonBlock", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "alterAddonBlock(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1541099739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "RepeatAddonBlockAltered", type: "event"} ;
		console.error( "eventCallOriginal[8,26] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RepeatAddonBlockAltered", events: [{name: "newValue", type: "uint256", value: "10"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[8,26] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: alterMinGameLength( \"150\" )", async function( ) {
		const txOriginal = {blockNumber: "6625340", timeStamp: "1541099919", hash: "0xf5a14db7fdec17d71cbedb29aac063fbdf7f2048502ab528e0c5b4b4f8f632ba", nonce: "28", blockHash: "0xe2d2df1a5bd23f04535f4b92aef6ea31a389b0e9d67392b3ece3da8d81d2e187", transactionIndex: "14", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb414d55b0000000000000000000000000000000000000000000000000000000000000096", contractAddress: "", cumulativeGasUsed: "1205713", gasUsed: "30915", confirmations: "1107523"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_minGameLength", value: "150"}], name: "alterMinGameLength", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "alterMinGameLength(uint256)" ]( "150", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1541099919 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "MinGameLengthAltered", type: "event"} ;
		console.error( "eventCallOriginal[9,12] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MinGameLengthAltered", events: [{name: "newValue", type: "uint256", value: "150"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[9,12] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: alterPrizeShare( \"50000000000000000\" )", async function( ) {
		const txOriginal = {blockNumber: "6625350", timeStamp: "1541100035", hash: "0x53cd73525a84e3814fedb78bcfa350ee23a715744cbe057c8884d786852318dc", nonce: "29", blockHash: "0x8c48c8447c627da36a5b3033dd68e71a6c74d30607517f2f0c59bba00ec740a6", transactionIndex: "2", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x831e9b8500000000000000000000000000000000000000000000000000b1a2bc2ec50000", contractAddress: "", cumulativeGasUsed: "187640", gasUsed: "30259", confirmations: "1107513"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_maxPrizeShare", value: "50000000000000000"}], name: "alterPrizeShare", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "alterPrizeShare(uint256)" ]( "50000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1541100035 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "share", type: "uint256"}], name: "MaxPrizeShareAltered", type: "event"} ;
		console.error( "eventCallOriginal[10,24] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "MaxPrizeShareAltered", events: [{name: "share", type: "uint256", value: "50000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[10,24] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: recalcNextGameId(  )", async function( ) {
		const txOriginal = {blockNumber: "6625358", timeStamp: "1541100121", hash: "0x2cb193f90906b12bbf46b571c69755a735b15c12862f5728690df4bb645290a6", nonce: "30", blockHash: "0x4231e5a2b87af5013ea8fce82323b52eac94f04885897bf08cea271a4b706fd7", transactionIndex: "14", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x8db3fe90", contractAddress: "", cumulativeGasUsed: "678436", gasUsed: "55104", confirmations: "1107505"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "recalcNextGameId", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "recalcNextGameId()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1541100121 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[11,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6625360"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[11,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[11,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6625360"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[11,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: alterAddon( \"30\" )", async function( ) {
		const txOriginal = {blockNumber: "6625385", timeStamp: "1541100483", hash: "0x09d6fec5d0986dd5df03f6167afcf314c8b33516e870eed369ad06ed70e7680d", nonce: "31", blockHash: "0x432958d5ebc1b45ae3c5640fe63fb1c4fe9b9b3a874f1f0b8a2a882e55abc584", transactionIndex: "30", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x6c169b0a000000000000000000000000000000000000000000000000000000000000001e", contractAddress: "", cumulativeGasUsed: "1503889", gasUsed: "29544", confirmations: "1107478"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_addon", value: "30"}], name: "alterAddon", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "alterAddon(uint256)" ]( "30", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1541100483 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "AddonAltered", type: "event"} ;
		console.error( "eventCallOriginal[12,14] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AddonAltered", events: [{name: "newValue", type: "uint256", value: "30"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[12,14] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: alterRepeatBlock( \"250\" )", async function( ) {
		const txOriginal = {blockNumber: "6625386", timeStamp: "1541100510", hash: "0x0680e15bc897473def51739ea1d2694abea693ad22b73db4d4f6d3386489374c", nonce: "32", blockHash: "0xe79fb749f9fdffebd1d72c4c92517f3c0bfb41b2a9ee2f99a33da59ba4d8eced", transactionIndex: "39", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0x7a34e2f000000000000000000000000000000000000000000000000000000000000000fa", contractAddress: "", cumulativeGasUsed: "5868042", gasUsed: "4300000", confirmations: "1107477"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_repeatBlock", value: "250"}], name: "alterRepeatBlock", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: alterRepeatBlock( \"249\" )", async function( ) {
		const txOriginal = {blockNumber: "6625391", timeStamp: "1541100612", hash: "0x7e28055e0a40ba5276e061a0240c8ddb717252a8ddbfd3eb0edd560365312aa5", nonce: "33", blockHash: "0x4dcaa9c1a623634b72b3de372d2d25065784e93f21ba0d1f0c36c2f1202e26db", transactionIndex: "60", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x7a34e2f000000000000000000000000000000000000000000000000000000000000000f9", contractAddress: "", cumulativeGasUsed: "2871601", gasUsed: "29809", confirmations: "1107472"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "_repeatBlock", value: "249"}], name: "alterRepeatBlock", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "alterRepeatBlock(uint256)" ]( "249", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1541100612 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "uint256"}], name: "RepeatBlockAltered", type: "event"} ;
		console.error( "eventCallOriginal[14,25] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RepeatBlockAltered", events: [{name: "newValue", type: "uint256", value: "249"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[14,25] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: updateRandom(  )", async function( ) {
		const txOriginal = {blockNumber: "6625422", timeStamp: "1541101005", hash: "0x285b3f0c06b96b7144717089fca187c4a09908aba7961174afce2c25328f5672", nonce: "34", blockHash: "0x2290f6b1f9b4d676aab630f6df71c29c17774ba7742300862a67e2537002353e", transactionIndex: "11", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x645dbfd4", contractAddress: "", cumulativeGasUsed: "657068", gasUsed: "45336", confirmations: "1107441"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "updateRandom", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "updateRandom()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1541101005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"} ;
		console.error( "eventCallOriginal[15,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RandomValueCalculated", events: [{name: "value", type: "uint256", value: "73722476230802806447473863069459422219980039559423120613662785544183502378716"}, {name: "randomBlock", type: "uint256", value: "6625360"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[15,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: setAutoCreation( true )", async function( ) {
		const txOriginal = {blockNumber: "6625422", timeStamp: "1541101005", hash: "0x4d86b501fd700ef280358bf05b70984af6ea53b1a6382bb37c36b198370e6cde", nonce: "35", blockHash: "0x2290f6b1f9b4d676aab630f6df71c29c17774ba7742300862a67e2537002353e", transactionIndex: "32", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x695ca9240000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1609038", gasUsed: "44770", confirmations: "1107441"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "allowed", value: true}], name: "setAutoCreation", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAutoCreation(bool)" ]( true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1541101005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "AutoCreationChanged", type: "event"} ;
		console.error( "eventCallOriginal[16,21] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AutoCreationChanged", events: [{name: "newValue", type: "bool", value: true}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[16,21] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: setStartProfitedGamesAllowed( true )", async function( ) {
		const txOriginal = {blockNumber: "6625427", timeStamp: "1541101097", hash: "0x160c5c34ebba428edb4177d170a05e854b595f1aef11ea91e88575cba1f2bad1", nonce: "36", blockHash: "0x8346b6e5a74d159f4daea8a83ca8725df065795ce5c56c2ffe57060cc788f013", transactionIndex: "26", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb9322a500000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "1586953", gasUsed: "31061", confirmations: "1107436"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "games", value: true}], name: "setStartProfitedGamesAllowed", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setStartProfitedGamesAllowed(bool)" ]( true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1541101097 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "StartProfitedGamesAllowedChanged", type: "event"} ;
		console.error( "eventCallOriginal[17,20] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "StartProfitedGamesAllowedChanged", events: [{name: "newValue", type: "bool", value: true}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[17,20] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setAutoCreationAfterOwn( true )", async function( ) {
		const txOriginal = {blockNumber: "6625430", timeStamp: "1541101142", hash: "0x503e7d321a1e906f24fb2e2f6aac92295ed02f65ca8a0798282b850c3ab5b5f3", nonce: "37", blockHash: "0xa3c5c8b3ee4da74600b45f71e38ccfd13e65c67489c817191ff20e4784147073", transactionIndex: "4", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x3a53791f0000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "190333", gasUsed: "29294", confirmations: "1107433"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "bool", name: "allowed", value: true}], name: "setAutoCreationAfterOwn", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setAutoCreationAfterOwn(bool)" ]( true, txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1541101142 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "newValue", type: "bool"}], name: "AutoCreationAfterOwnChanged", type: "event"} ;
		console.error( "eventCallOriginal[18,22] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "AutoCreationAfterOwnChanged", events: [{name: "newValue", type: "bool", value: true}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[18,22] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: depositToBank(  )", async function( ) {
		const txOriginal = {blockNumber: "6625433", timeStamp: "1541101255", hash: "0x30b2fa52d59b60543c01928ab99a6e16c2b1b58429d37242951a1466566c01c9", nonce: "38", blockHash: "0x8cff38841913198b30e775fd6623eb0ecfcfe3274a35dd33e51ca3fdc4b83ce6", transactionIndex: "32", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "500000000000000000", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xa1a5ba78", contractAddress: "", cumulativeGasUsed: "2688704", gasUsed: "45637", confirmations: "1107430"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "depositToBank", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "depositToBank()" ]( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1541101255 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "sender", type: "address"}, {indexed: false, name: "value", type: "uint256"}], name: "MoneyDeposited", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "MoneyDeposited", events: [{name: "sender", type: "address", value: "0xf94a427c54082dd674df41d7629c37e7928a98a2"}, {name: "value", type: "uint256", value: "500000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: startOwnFixed( \"6625463\", \"100\", \"15\", \"0\" )", async function( ) {
		const txOriginal = {blockNumber: "6625468", timeStamp: "1541101642", hash: "0x07feefc84f50be7405b3265309566930bd2f08347448f22f943741a13619e9ad", nonce: "39", blockHash: "0x398278be9910f8edfc971210f418f80f98a02e864211be19ea593b9b7e02728a", transactionIndex: "61", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "4300000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0xf483436200000000000000000000000000000000000000000000000000000000006518b70000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000000000000000000", contractAddress: "", cumulativeGasUsed: "2586864", gasUsed: "25885", confirmations: "1107395"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6625463"}, {type: "uint256", name: "length", value: "100"}, {type: "uint256", name: "addon", value: "15"}, {type: "uint256", name: "prize", value: "0"}], name: "startOwnFixed", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startOwnFixed(uint256,uint256,uint256,uint256)" ]( "6625463", "100", "15", "0", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1541101642 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: startOwnFixed( \"6625463\", \"100\", \"15\", \"10000000... )", async function( ) {
		const txOriginal = {blockNumber: "6625472", timeStamp: "1541101698", hash: "0xb556057d5d1d78cf90e96f9c956fded8b1c5b9351aa91a1f896831dad85bcdf4", nonce: "40", blockHash: "0xe84d2fd0c99c174d661739d2385c97b867f768a516101dd62aa345cad02dcdb3", transactionIndex: "11", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000", gas: "4300000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0xf483436200000000000000000000000000000000000000000000000000000000006518b70000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000f000000000000000000000000000000000000000000000000002386f26fc10000", contractAddress: "", cumulativeGasUsed: "449555", gasUsed: "26815", confirmations: "1107391"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6625463"}, {type: "uint256", name: "length", value: "100"}, {type: "uint256", name: "addon", value: "15"}, {type: "uint256", name: "prize", value: "10000000000000000"}], name: "startOwnFixed", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startOwnFixed(uint256,uint256,uint256,uint256)" ]( "6625463", "100", "15", "10000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1541101698 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: startOwnFixed( \"6625463\", \"100\", \"15\", \"11000000... )", async function( ) {
		const txOriginal = {blockNumber: "6625483", timeStamp: "1541101800", hash: "0xdb1d10d7c94cdcc4576f8727e8d93bbfc424564c15e7bd80b13ed07bd953b6cb", nonce: "41", blockHash: "0x12473aa29eb23c8cb077bfc3a5a39b55d330e98f211670c0de22a1884da28ab4", transactionIndex: "2", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000", gas: "4300000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0xf483436200000000000000000000000000000000000000000000000000000000006518b70000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000027147114878000", contractAddress: "", cumulativeGasUsed: "126129", gasUsed: "26879", confirmations: "1107380"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6625463"}, {type: "uint256", name: "length", value: "100"}, {type: "uint256", name: "addon", value: "15"}, {type: "uint256", name: "prize", value: "11000000000000000"}], name: "startOwnFixed", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startOwnFixed(uint256,uint256,uint256,uint256)" ]( "6625463", "100", "15", "11000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1541101800 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: startOwnFixed( \"6625463\", \"150\", \"15\", \"11000000... )", async function( ) {
		const txOriginal = {blockNumber: "6625499", timeStamp: "1541101938", hash: "0x8ea082de4f2d3b2ca860ebb42b55fdc849a52e9c8a98b3e47523ccb7dc9fa639", nonce: "42", blockHash: "0x0f35c2667edcf72b06eb7c25f0bc083ef135c5e9e2f0b982cb5e4cf637c0c718", transactionIndex: "15", from: "0xf94a427c54082dd674df41d7629c37e7928a98a2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf483436200000000000000000000000000000000000000000000000000000000006518b70000000000000000000000000000000000000000000000000000000000000096000000000000000000000000000000000000000000000000000000000000000f0000000000000000000000000000000000000000000000000027147114878000", contractAddress: "", cumulativeGasUsed: "915490", gasUsed: "224058", confirmations: "1107364"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6625463"}, {type: "uint256", name: "length", value: "150"}, {type: "uint256", name: "addon", value: "15"}, {type: "uint256", name: "prize", value: "11000000000000000"}], name: "startOwnFixed", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "startOwnFixed(uint256,uint256,uint256,uint256)" ]( "6625463", "150", "15", "11000000000000000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1541101938 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[23,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6625463"}, {name: "starter", type: "address", value: "0xf94a427c54082dd674df41d7629c37e7928a98a2"}, {name: "blockNumber", type: "uint256", value: "6625499"}, {name: "finishBlock", type: "uint256", value: "6625648"}, {name: "prize", type: "uint256", value: "11000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[23,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[23,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6625463"}, {name: "bidder", type: "address", value: "0xf94a427c54082dd674df41d7629c37e7928a98a2"}, {name: "winner", type: "address", value: "0xf94a427c54082dd674df41d7629c37e7928a98a2"}, {name: "highestBet", type: "uint256", value: "1000000000000"}, {name: "finishBlock", type: "uint256", value: "6625648"}, {name: "value", type: "uint256", value: "1000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[23,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[23,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "11000000000000000"}, {name: "total", type: "uint256", value: "11000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[23,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "583899376058000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6625463\" )", async function( ) {
		const txOriginal = {blockNumber: "6625531", timeStamp: "1541102457", hash: "0x8ab952b3c32759af2f44aa228ca6538f50744522ba2eef5bfc43c7036b6cc8e9", nonce: "0", blockHash: "0x7e1b6482cb2924354e3e59af010c49dca326461d914ee998e18ddcb2eb5a68ea", transactionIndex: "38", from: "0x1dfbdedab24a9738d129ba9c76df521be4ceb2cf", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "4000000000000000", gas: "4300000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xf951c31900000000000000000000000000000000000000000000000000000000006518b7", contractAddress: "", cumulativeGasUsed: "2710736", gasUsed: "70067", confirmations: "1107332"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "4000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6625463"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6625463", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1541102457 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[24,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6625463"}, {name: "bidder", type: "address", value: "0x1dfbdedab24a9738d129ba9c76df521be4ceb2cf"}, {name: "winner", type: "address", value: "0x1dfbdedab24a9738d129ba9c76df521be4ceb2cf"}, {name: "highestBet", type: "uint256", value: "4000000000000000"}, {name: "finishBlock", type: "uint256", value: "6625648"}, {name: "value", type: "uint256", value: "4000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[24,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1936158961000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6625463\" )", async function( ) {
		const txOriginal = {blockNumber: "6625532", timeStamp: "1541102469", hash: "0xec997c3c8b4baa3227e0afd9b7ca483079aa4195c55f7f6e0349cdfedd4151c0", nonce: "1", blockHash: "0x216b9079fc779231eb0b6edba7d10a442a666929fd0d4128ba2ab50068de39ef", transactionIndex: "52", from: "0x1dfbdedab24a9738d129ba9c76df521be4ceb2cf", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "16000000000000000", gas: "4300000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xf951c31900000000000000000000000000000000000000000000000000000000006518b7", contractAddress: "", cumulativeGasUsed: "2689268", gasUsed: "98723", confirmations: "1107331"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "16000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6625463"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6625463", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1541102469 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[25,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6625463"}, {name: "bidder", type: "address", value: "0x1dfbdedab24a9738d129ba9c76df521be4ceb2cf"}, {name: "winner", type: "address", value: "0x1dfbdedab24a9738d129ba9c76df521be4ceb2cf"}, {name: "highestBet", type: "uint256", value: "20000000000000000"}, {name: "finishBlock", type: "uint256", value: "6625648"}, {name: "value", type: "uint256", value: "20000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[25,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "GameProfitedEvent", type: "event"} ;
		console.error( "eventCallOriginal[25,30] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameProfitedEvent", events: [{name: "gameId", type: "uint256", value: "6625463"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[25,30] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "faseGamesCreate", type: "uint256"}], name: "FastGamesChanged", type: "event"} ;
		console.error( "eventCallOriginal[25,31] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "FastGamesChanged", events: [{name: "faseGamesCreate", type: "uint256", value: "1"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[25,31] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "1936158961000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6625360\" )", async function( ) {
		const txOriginal = {blockNumber: "6691403", timeStamp: "1542036003", hash: "0xe53944d848794b29d7f90d4b3648cfc55c93e8b5fe1c95c830593874108a2ea1", nonce: "0", blockHash: "0x798645d8aa2781219450885dd42a870b25aca1efd3bbc88826ffa9803238be90", transactionIndex: "127", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "390375", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000651850", contractAddress: "", cumulativeGasUsed: "5459013", gasUsed: "215256", confirmations: "1041460"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6625360"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6625360", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542036003 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[26,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6625360"}, {name: "starter", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "blockNumber", type: "uint256", value: "6691403"}, {name: "finishBlock", type: "uint256", value: "6691659"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[26,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[26,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6625360"}, {name: "bidder", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6691659"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[26,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[26,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "12000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "22000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[26,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[26,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "21000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[26,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[26,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6691414"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[26,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPrize( \"6625360\" )", async function( ) {
		const txOriginal = {blockNumber: "6691736", timeStamp: "1542040377", hash: "0xe7d52873e24779ce1ca7ee27d055be3289123d2d228c4fc77511cfcf789fff65", nonce: "1", blockHash: "0xcbc95b90722b5d9ff35e5f2481448bed6fba0b1a03d75e7988fce6c464baf04b", transactionIndex: "108", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "96337", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc20eec7b0000000000000000000000000000000000000000000000000000000000651850", contractAddress: "", cumulativeGasUsed: "7753365", gasUsed: "63514", confirmations: "1041127"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6625360"}], name: "withdrawPrize", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPrize(uint256)" ]( "6625360", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542040377 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"} ;
		console.error( "eventCallOriginal[27,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GamePrizeTaken", events: [{name: "gameId", type: "uint256", value: "6625360"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[27,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[27,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "11000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[27,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6691414\" )", async function( ) {
		const txOriginal = {blockNumber: "6692018", timeStamp: "1542044207", hash: "0xb9f05e3a41ce0aeea06c2a3add60e10844f40615c607c9c79c33f4c68f797201", nonce: "2", blockHash: "0xca1b8175412fb3d268be6000c9f992a49b894856db2fcd96ff94150562599304", transactionIndex: "71", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "100000000000000", gas: "414445", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000661a56", contractAddress: "", cumulativeGasUsed: "7444599", gasUsed: "276297", confirmations: "1040845"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6691414"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6691414", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542044207 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[28,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6691414"}, {name: "starter", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "blockNumber", type: "uint256", value: "6692018"}, {name: "finishBlock", type: "uint256", value: "6692167"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[28,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[28,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6691414"}, {name: "bidder", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "highestBet", type: "uint256", value: "100000000000000"}, {name: "finishBlock", type: "uint256", value: "6692167"}, {name: "value", type: "uint256", value: "100000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[28,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[28,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "100000000000000"}, {name: "total", type: "uint256", value: "11100000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "21100000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[28,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[28,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "100000000000000"}, {name: "total", type: "uint256", value: "21000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[28,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[28,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6692124"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[28,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[28,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6691414"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[28,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6691414\" )", async function( ) {
		const txOriginal = {blockNumber: "6692084", timeStamp: "1542044982", hash: "0xfc3fb76f4aef73ee63e793c8e835ba4f8f1490a905dda83013c9c64df7f81dca", nonce: "1", blockHash: "0x65351c7c74da0eb59f1be06a2c165db9dc92d85b285a8df24ece97804dbd14fc", transactionIndex: "49", from: "0xd15199f2b5909bc36ca3bb3ee07ef68ecd605e9f", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "110000000000000", gas: "106204", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000661a56", contractAddress: "", cumulativeGasUsed: "6783483", gasUsed: "70803", confirmations: "1040779"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "110000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6691414"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6691414", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542044982 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[29,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6691414"}, {name: "bidder", type: "address", value: "0xd15199f2b5909bc36ca3bb3ee07ef68ecd605e9f"}, {name: "winner", type: "address", value: "0xd15199f2b5909bc36ca3bb3ee07ef68ecd605e9f"}, {name: "highestBet", type: "uint256", value: "110000000000000"}, {name: "finishBlock", type: "uint256", value: "6692167"}, {name: "value", type: "uint256", value: "110000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[29,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1935904044267781917" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6692124\" )", async function( ) {
		const txOriginal = {blockNumber: "6692207", timeStamp: "1542046689", hash: "0x32d645cd778c0f8bb13291d479efae1111652db09ca3d6b8ae81284a17df1b86", nonce: "2", blockHash: "0xb2b3993b76a0a7b89350870fba80c779c0f4317bb606d332ac776a0f07cc3d45", transactionIndex: "84", from: "0xd15199f2b5909bc36ca3bb3ee07ef68ecd605e9f", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "424680", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000661d1c", contractAddress: "", cumulativeGasUsed: "5351754", gasUsed: "268120", confirmations: "1040656"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6692124"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6692124", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542046689 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"} ;
		console.error( "eventCallOriginal[30,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RandomValueCalculated", events: [{name: "value", type: "uint256", value: "75635928833137806157252099103703074451920757980732038013884725387457029019938"}, {name: "randomBlock", type: "uint256", value: "6692124"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[30,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[30,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6692124"}, {name: "starter", type: "address", value: "0xd15199f2b5909bc36ca3bb3ee07ef68ecd605e9f"}, {name: "blockNumber", type: "uint256", value: "6692207"}, {name: "finishBlock", type: "uint256", value: "6692496"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[30,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[30,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6692124"}, {name: "bidder", type: "address", value: "0xd15199f2b5909bc36ca3bb3ee07ef68ecd605e9f"}, {name: "winner", type: "address", value: "0xd15199f2b5909bc36ca3bb3ee07ef68ecd605e9f"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6692496"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[30,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[30,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "22000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "32000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[30,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[30,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "31000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[30,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[30,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6692374"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[30,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[30,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6692124"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[30,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1935904044267781917" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPrize( \"6691414\" )", async function( ) {
		const txOriginal = {blockNumber: "6692214", timeStamp: "1542046827", hash: "0x77d49669ad8073f1823a13e6af417d123361a104b4e5a03814265f3b13822810", nonce: "3", blockHash: "0x0eecc2b888881f86f80aa83458fe01fbbae262616632ba328405841e642b7a91", transactionIndex: "75", from: "0xd15199f2b5909bc36ca3bb3ee07ef68ecd605e9f", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "96337", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xc20eec7b0000000000000000000000000000000000000000000000000000000000661a56", contractAddress: "", cumulativeGasUsed: "4043090", gasUsed: "63514", confirmations: "1040649"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6691414"}], name: "withdrawPrize", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPrize(uint256)" ]( "6691414", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542046827 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"} ;
		console.error( "eventCallOriginal[31,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GamePrizeTaken", events: [{name: "gameId", type: "uint256", value: "6691414"}, {name: "winner", type: "address", value: "0xd15199f2b5909bc36ca3bb3ee07ef68ecd605e9f"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[31,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[31,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "21000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[31,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "1935904044267781917" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6692374\" )", async function( ) {
		const txOriginal = {blockNumber: "6693158", timeStamp: "1542059739", hash: "0xa306e7325c223967906d74a11f2794a22bf50fc3c2f28f83299e014aef94f829", nonce: "3", blockHash: "0xdfb4ca4cd84e2c3074ee36963889b3e5b7f73e83942cbfb785fe38636bc84eb3", transactionIndex: "84", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "391945", gasPrice: "2210000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000661e16", contractAddress: "", cumulativeGasUsed: "4585871", gasUsed: "261303", confirmations: "1039705"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6692374"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6692374", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542059739 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[32,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6692374"}, {name: "starter", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "blockNumber", type: "uint256", value: "6693158"}, {name: "finishBlock", type: "uint256", value: "6693307"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[32,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[32,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6692374"}, {name: "bidder", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6693307"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[32,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[32,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "22000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "32000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[32,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[32,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "31000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[32,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[32,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6693370"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[32,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[32,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6692374"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[32,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPrize( \"6692374\" )", async function( ) {
		const txOriginal = {blockNumber: "6693317", timeStamp: "1542062119", hash: "0x1d8a9c8cc47206ca0bcc783086de201b1706a1cdbb2ff0a4eaf27954917f0a1a", nonce: "4", blockHash: "0x6c79754cf6f046b8b15e99b46b03d322ff8eb25ff218454b3321d3a4a22e71a4", transactionIndex: "90", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "96337", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc20eec7b0000000000000000000000000000000000000000000000000000000000661e16", contractAddress: "", cumulativeGasUsed: "4121571", gasUsed: "63514", confirmations: "1039546"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6692374"}], name: "withdrawPrize", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPrize(uint256)" ]( "6692374", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542062119 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"} ;
		console.error( "eventCallOriginal[33,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GamePrizeTaken", events: [{name: "gameId", type: "uint256", value: "6692374"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[33,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[33,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "21000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[33,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6693370\" )", async function( ) {
		const txOriginal = {blockNumber: "6693509", timeStamp: "1542064916", hash: "0xcb950fc03a3c244dd1b42df48f511a0525d0b73a79dbb488bdc63be7bf65ec31", nonce: "5", blockHash: "0xa88098874b0b195c42491594862abd49b1192c2b053b2ac5772ecef1f70d5a80", transactionIndex: "49", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "424671", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf951c31900000000000000000000000000000000000000000000000000000000006621fa", contractAddress: "", cumulativeGasUsed: "6776490", gasUsed: "268114", confirmations: "1039354"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6693370"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6693370", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542064916 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"} ;
		console.error( "eventCallOriginal[34,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RandomValueCalculated", events: [{name: "value", type: "uint256", value: "87656777626557404141239617733214935360117681420419423107369947340375778683619"}, {name: "randomBlock", type: "uint256", value: "6693370"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[34,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[34,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6693370"}, {name: "starter", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "blockNumber", type: "uint256", value: "6693509"}, {name: "finishBlock", type: "uint256", value: "6693751"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[34,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[34,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6693370"}, {name: "bidder", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6693751"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[34,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[34,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "22000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "32000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[34,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[34,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "31000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[34,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[34,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6693618"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[34,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[34,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6693370"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[34,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6693618\" )", async function( ) {
		const txOriginal = {blockNumber: "6693717", timeStamp: "1542067661", hash: "0x4197297600b766bde3c56823269725a10dc4b55133bdc048416e3546887bd82f", nonce: "6", blockHash: "0xd7ae70d7d1ab59184fb36ee07443563b93ea89c4a8b9d8005527ec28bb9965b5", transactionIndex: "89", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "416361", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xf951c31900000000000000000000000000000000000000000000000000000000006622f2", contractAddress: "", cumulativeGasUsed: "6866307", gasUsed: "262574", confirmations: "1039146"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6693618"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6693618", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542067661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"} ;
		console.error( "eventCallOriginal[35,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RandomValueCalculated", events: [{name: "value", type: "uint256", value: "24981247795019355150603647571873663445590097359609323486769804242005525844877"}, {name: "randomBlock", type: "uint256", value: "6693618"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[35,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[35,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6693618"}, {name: "starter", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "blockNumber", type: "uint256", value: "6693717"}, {name: "finishBlock", type: "uint256", value: "6693997"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[35,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[35,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6693618"}, {name: "bidder", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6693997"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[35,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[35,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "32000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "42000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[35,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[35,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "41000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[35,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[35,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6693868"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[35,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPrize( \"6693370\" )", async function( ) {
		const txOriginal = {blockNumber: "6693794", timeStamp: "1542068755", hash: "0x667b7af3d12c1b6bc21ab450dfe9fee898e65c43b0c8340e131cb09d68c50fca", nonce: "7", blockHash: "0xf317c3df7b726aa9b258864a369cd0a5d5ff53e6d26ef474a9bc43f4f65c5e2b", transactionIndex: "148", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "96337", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xc20eec7b00000000000000000000000000000000000000000000000000000000006621fa", contractAddress: "", cumulativeGasUsed: "7944950", gasUsed: "63514", confirmations: "1039069"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6693370"}], name: "withdrawPrize", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPrize(uint256)" ]( "6693370", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542068755 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"} ;
		console.error( "eventCallOriginal[36,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GamePrizeTaken", events: [{name: "gameId", type: "uint256", value: "6693370"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[36,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[36,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "31000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[36,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPrize( \"6693618\" )", async function( ) {
		const txOriginal = {blockNumber: "6696017", timeStamp: "1542100179", hash: "0xacdabe323a2f978da96fadf87a9e6698b4ec9b337cb3dc5d3c64c0d89db59b8d", nonce: "8", blockHash: "0x104d95599abe549cb7f27a1213fffd6e324553fea1d8bff298430a38598cd994", transactionIndex: "108", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "96337", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xc20eec7b00000000000000000000000000000000000000000000000000000000006622f2", contractAddress: "", cumulativeGasUsed: "5981827", gasUsed: "63514", confirmations: "1036846"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6693618"}], name: "withdrawPrize", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPrize(uint256)" ]( "6693618", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542100179 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"} ;
		console.error( "eventCallOriginal[37,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GamePrizeTaken", events: [{name: "gameId", type: "uint256", value: "6693618"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[37,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[37,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "21000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[37,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6693868\" )", async function( ) {
		const txOriginal = {blockNumber: "6696052", timeStamp: "1542100746", hash: "0xe1140b27a7084db875262ea6077d1ce7824382a0c94095314c268ef10992db85", nonce: "9", blockHash: "0xe3c7df72fede91f6674a83a0d108cc6b9364deeaeab87515dbd587d80fc22ee2", transactionIndex: "68", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "391945", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c31900000000000000000000000000000000000000000000000000000000006623ec", contractAddress: "", cumulativeGasUsed: "5614628", gasUsed: "261297", confirmations: "1036811"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6693868"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6693868", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542100746 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[38,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6693868"}, {name: "starter", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "blockNumber", type: "uint256", value: "6696052"}, {name: "finishBlock", type: "uint256", value: "6696201"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[38,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[38,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6693868"}, {name: "bidder", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6696201"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[38,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[38,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "22000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "32000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[38,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[38,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "31000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[38,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[38,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6696108"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[38,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[38,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6693868"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[38,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPrize( \"6693868\" )", async function( ) {
		const txOriginal = {blockNumber: "6696334", timeStamp: "1542104939", hash: "0x4ca60193f341c2296e222dc3654c3ea1f9d0ffbeddf15f0cc1a3d4cfcca1d456", nonce: "10", blockHash: "0xecc76447c2d2efcef9f69bfd4b06c306f389c54b108532cce70efa2ecdef5df4", transactionIndex: "140", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "96337", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc20eec7b00000000000000000000000000000000000000000000000000000000006623ec", contractAddress: "", cumulativeGasUsed: "7226034", gasUsed: "63514", confirmations: "1036529"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6693868"}], name: "withdrawPrize", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPrize(uint256)" ]( "6693868", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542104939 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"} ;
		console.error( "eventCallOriginal[39,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GamePrizeTaken", events: [{name: "gameId", type: "uint256", value: "6693868"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[39,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[39,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "21000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[39,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6696108\" )", async function( ) {
		const txOriginal = {blockNumber: "6696738", timeStamp: "1542110506", hash: "0x09f9d73755736f97c226ea1ce1b7c845e0013e593a07f0c596d54147cd8a11ea", nonce: "11", blockHash: "0x13539f48018854ff37304af99be5753265268b6f2438259af66c0b7dcd9c537c", transactionIndex: "12", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "391954", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000662cac", contractAddress: "", cumulativeGasUsed: "6868212", gasUsed: "261303", confirmations: "1036125"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6696108"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6696108", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542110506 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[40,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6696108"}, {name: "starter", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "blockNumber", type: "uint256", value: "6696738"}, {name: "finishBlock", type: "uint256", value: "6696887"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[40,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[40,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6696108"}, {name: "bidder", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6696887"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[40,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[40,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "22000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "32000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[40,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[40,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "31000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[40,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[40,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6696856"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[40,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[40,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6696108"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[40,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6696856\" )", async function( ) {
		const txOriginal = {blockNumber: "6696926", timeStamp: "1542113459", hash: "0x403674904d316406021dca2cee3474168fe5078b5021e7c59387ad5f7f305766", nonce: "0", blockHash: "0x46e802d345903373b1a2785606943b7e23b382421a2307e52d0c9bf7ce40b6ae", transactionIndex: "121", from: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "424671", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000662f98", contractAddress: "", cumulativeGasUsed: "7424233", gasUsed: "268114", confirmations: "1035937"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6696856"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6696856", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542113459 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"} ;
		console.error( "eventCallOriginal[41,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RandomValueCalculated", events: [{name: "value", type: "uint256", value: "39270790974637025561661067382363956588793109592045815984534856583923985167593"}, {name: "randomBlock", type: "uint256", value: "6696856"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[41,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[41,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6696856"}, {name: "starter", type: "address", value: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576"}, {name: "blockNumber", type: "uint256", value: "6696926"}, {name: "finishBlock", type: "uint256", value: "6697164"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[41,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[41,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6696856"}, {name: "bidder", type: "address", value: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576"}, {name: "winner", type: "address", value: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6697164"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[41,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[41,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "32000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "42000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[41,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[41,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "41000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[41,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[41,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6697104"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[41,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[41,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6696856"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[41,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "176145607891705757" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPrize( \"6696108\" )", async function( ) {
		const txOriginal = {blockNumber: "6696975", timeStamp: "1542114194", hash: "0xee34522516fbc19a507ed53e18481773a1554aa1f056e091fb262eac32483117", nonce: "12", blockHash: "0xc035f8f44cf774913b5338a6572f6c7a8e7a262f8aa85d9dad5ff00f9bbf0295", transactionIndex: "127", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "96337", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc20eec7b0000000000000000000000000000000000000000000000000000000000662cac", contractAddress: "", cumulativeGasUsed: "6807404", gasUsed: "63514", confirmations: "1035888"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6696108"}], name: "withdrawPrize", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPrize(uint256)" ]( "6696108", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542114194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"} ;
		console.error( "eventCallOriginal[42,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GamePrizeTaken", events: [{name: "gameId", type: "uint256", value: "6696108"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[42,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[42,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "31000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[42,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6697104\" )", async function( ) {
		const txOriginal = {blockNumber: "6697289", timeStamp: "1542118728", hash: "0x9cf6315af3aca66abdfc1520cd0183b9332f68728bbcad2086b632a7033c714b", nonce: "0", blockHash: "0x49ca38ae8b55daab97d0ca260149210c658d9415782f552161b9737656a86c41", transactionIndex: "89", from: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "424665", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000663090", contractAddress: "", cumulativeGasUsed: "7757342", gasUsed: "268110", confirmations: "1035574"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6697104"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6697104", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542118728 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"} ;
		console.error( "eventCallOriginal[43,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RandomValueCalculated", events: [{name: "value", type: "uint256", value: "10602751955298213766136558026471685572762322764276392269723382582027909714980"}, {name: "randomBlock", type: "uint256", value: "6697104"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[43,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[43,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6697104"}, {name: "starter", type: "address", value: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e"}, {name: "blockNumber", type: "uint256", value: "6697289"}, {name: "finishBlock", type: "uint256", value: "6697585"}, {name: "prize", type: "uint256", value: "15715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[43,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[43,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6697104"}, {name: "bidder", type: "address", value: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e"}, {name: "winner", type: "address", value: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6697585"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[43,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[43,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "32000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "15715078290851715"}, {name: "total", type: "uint256", value: "47715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[43,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[43,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "46715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[43,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[43,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6697354"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[43,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[43,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6697104"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[43,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "471183965702500000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPrize( \"6696856\" )", async function( ) {
		const txOriginal = {blockNumber: "6697314", timeStamp: "1542119100", hash: "0xe4c0122d06cfca07e6ce9a987cb811147b5ba029c639f341fc6151d70043b51a", nonce: "1", blockHash: "0xff8b2cb9ffc2666b1c777faca700481f15ab85683036d472469db748683bc1c5", transactionIndex: "120", from: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "96337", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc20eec7b0000000000000000000000000000000000000000000000000000000000662f98", contractAddress: "", cumulativeGasUsed: "5930418", gasUsed: "63514", confirmations: "1035549"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6696856"}], name: "withdrawPrize", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPrize(uint256)" ]( "6696856", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542119100 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"} ;
		console.error( "eventCallOriginal[44,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GamePrizeTaken", events: [{name: "gameId", type: "uint256", value: "6696856"}, {name: "winner", type: "address", value: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[44,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[44,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "36715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[44,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "176145607891705757" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6697354\" )", async function( ) {
		const txOriginal = {blockNumber: "6697381", timeStamp: "1542120081", hash: "0xcf93463570aec6aa1df89b22862e5f2eaa09337a1871b4793d283c5a69b79cfd", nonce: "2", blockHash: "0x6f759ba0713c6c5abc058cc61e0ebd532d4f869be59d0055280547e9f1dccd58", transactionIndex: "157", from: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "416352", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c319000000000000000000000000000000000000000000000000000000000066318a", contractAddress: "", cumulativeGasUsed: "6726122", gasUsed: "262568", confirmations: "1035482"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6697354"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6697354", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542120081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"} ;
		console.error( "eventCallOriginal[45,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RandomValueCalculated", events: [{name: "value", type: "uint256", value: "72464472639965337349169546949430076971435833032154776835244889230083657801795"}, {name: "randomBlock", type: "uint256", value: "6697354"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[45,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[45,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6697354"}, {name: "starter", type: "address", value: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576"}, {name: "blockNumber", type: "uint256", value: "6697381"}, {name: "finishBlock", type: "uint256", value: "6697649"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[45,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[45,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6697354"}, {name: "bidder", type: "address", value: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576"}, {name: "winner", type: "address", value: "0x2cbda5fb93f08cc196a196bfa8bf043713dc7576"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6697649"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[45,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[45,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "37715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "47715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[45,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[45,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "46715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[45,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[45,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6697602"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[45,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "176145607891705757" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6697104\" )", async function( ) {
		const txOriginal = {blockNumber: "6697423", timeStamp: "1542120842", hash: "0x81ab6ef8d3b6a83b725e170001c540ac363fa99098eb90e14cf295c69f01b821", nonce: "13", blockHash: "0x7e055eb480344083e198411e3068c23e8045c98bee9a0237b5b1d0382dd04365", transactionIndex: "47", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "2000000000000000", gas: "106204", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000663090", contractAddress: "", cumulativeGasUsed: "4418611", gasUsed: "70803", confirmations: "1035440"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "2000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6697104"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6697104", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542120842 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[46,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6697104"}, {name: "bidder", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}, {name: "highestBet", type: "uint256", value: "2000000000000000"}, {name: "finishBlock", type: "uint256", value: "6697585"}, {name: "value", type: "uint256", value: "2000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[46,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6697602\" )", async function( ) {
		const txOriginal = {blockNumber: "6697779", timeStamp: "1542126209", hash: "0xb4c45b060e5d998757acc227549042f7703e48b16d273c32b7a31d451be6c368", nonce: "1", blockHash: "0x36ca65fa92a20eeb495bb47d6094067ae2d4b4372315fe4f158da32ac0e643df", transactionIndex: "137", from: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "424680", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c3190000000000000000000000000000000000000000000000000000000000663282", contractAddress: "", cumulativeGasUsed: "7431575", gasUsed: "268120", confirmations: "1035084"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6697602"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6697602", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542126209 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"} ;
		console.error( "eventCallOriginal[47,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RandomValueCalculated", events: [{name: "value", type: "uint256", value: "24914599750943028278473819573584078067382974267193679338390788694876388411955"}, {name: "randomBlock", type: "uint256", value: "6697602"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[47,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[47,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6697602"}, {name: "starter", type: "address", value: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e"}, {name: "blockNumber", type: "uint256", value: "6697779"}, {name: "finishBlock", type: "uint256", value: "6698071"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[47,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[47,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6697602"}, {name: "bidder", type: "address", value: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e"}, {name: "winner", type: "address", value: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6698071"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[47,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[47,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "47715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "57715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[47,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[47,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "56715078290851715"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[47,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[47,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6697852"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[47,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[47,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6697602"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[47,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "471183965702500000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: withdrawPrize( \"6697104\" )", async function( ) {
		const txOriginal = {blockNumber: "6697797", timeStamp: "1542126477", hash: "0x464208eaf012bc15e04a3f92bb94dbc0ee59cb6e4ba6360f23f2e45818e50172", nonce: "14", blockHash: "0xa941ae890e5e335f09e8aa1032ab963bdfb2bae3eb72e8617b20e0e96df45ee6", transactionIndex: "73", from: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "0", gas: "96337", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xc20eec7b0000000000000000000000000000000000000000000000000000000000663090", contractAddress: "", cumulativeGasUsed: "4663381", gasUsed: "63514", confirmations: "1035066"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6697104"}], name: "withdrawPrize", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "withdrawPrize(uint256)" ]( "6697104", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542126477 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "winner", type: "address"}], name: "GamePrizeTaken", type: "event"} ;
		console.error( "eventCallOriginal[48,9] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GamePrizeTaken", events: [{name: "gameId", type: "uint256", value: "6697104"}, {name: "winner", type: "address", value: "0x46ba9e653d7230dd828fe45a2a69ca68e7ff69d2"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[48,9] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[48,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "15715078290851715"}, {name: "total", type: "uint256", value: "41000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[48,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "1788406959688748365" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: betInGame( \"6697852\" )", async function( ) {
		const txOriginal = {blockNumber: "6698082", timeStamp: "1542130237", hash: "0xf96f393c8463e06e5868f8a309a0fd20d2b036673aa14168b78258be22770458", nonce: "2", blockHash: "0xe5fd2dfb7f05091cee4089fb3c10f37ad1d024ddedec3ede71a0d82cbb7fa881", transactionIndex: "117", from: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e", to: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807", value: "1000000000000000", gas: "416352", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xf951c319000000000000000000000000000000000000000000000000000000000066337c", contractAddress: "", cumulativeGasUsed: "6810809", gasUsed: "268114", confirmations: "1034781"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "gameId", value: "6697852"}], name: "betInGame", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "betInGame(uint256)" ]( "6697852", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542130237 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "randomBlock", type: "uint256"}], name: "RandomValueCalculated", type: "event"} ;
		console.error( "eventCallOriginal[49,6] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "RandomValueCalculated", events: [{name: "value", type: "uint256", value: "43976722683720252286601665128754275866486100650642943445279050417875865708887"}, {name: "randomBlock", type: "uint256", value: "6697852"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[49,6] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "starter", type: "address"}, {indexed: false, name: "blockNumber", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "prize", type: "uint256"}], name: "GameStarted", type: "event"} ;
		console.error( "eventCallOriginal[49,7] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameStarted", events: [{name: "gameId", type: "uint256", value: "6697852"}, {name: "starter", type: "address", value: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e"}, {name: "blockNumber", type: "uint256", value: "6698082"}, {name: "finishBlock", type: "uint256", value: "6698364"}, {name: "prize", type: "uint256", value: "10000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[49,7] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "gameId", type: "uint256"}, {indexed: true, name: "bidder", type: "address"}, {indexed: true, name: "winner", type: "address"}, {indexed: false, name: "highestBet", type: "uint256"}, {indexed: false, name: "finishBlock", type: "uint256"}, {indexed: false, name: "value", type: "uint256"}], name: "GameBet", type: "event"} ;
		console.error( "eventCallOriginal[49,8] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "GameBet", events: [{name: "gameId", type: "uint256", value: "6697852"}, {name: "bidder", type: "address", value: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e"}, {name: "winner", type: "address", value: "0x1af8a835141b721f3d29ccaff2c46ddb1415965e"}, {name: "highestBet", type: "uint256", value: "1000000000000000"}, {name: "finishBlock", type: "uint256", value: "6698364"}, {name: "value", type: "uint256", value: "1000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[49,8] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceReserved", type: "event"} ;
		console.error( "eventCallOriginal[49,10] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "42000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}, {name: "BalanceReserved", events: [{name: "value", type: "uint256", value: "10000000000000000"}, {name: "total", type: "uint256", value: "52000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[49,10] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "value", type: "uint256"}, {indexed: false, name: "total", type: "uint256"}], name: "BalanceFreed", type: "event"} ;
		console.error( "eventCallOriginal[49,11] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "BalanceFreed", events: [{name: "value", type: "uint256", value: "1000000000000000"}, {name: "total", type: "uint256", value: "51000000000000000"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[49,11] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "NextGameIdCalculated", type: "event"} ;
		console.error( "eventCallOriginal[49,27] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "NextGameIdCalculated", events: [{name: "gameId", type: "uint256", value: "6698100"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[49,27] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "gameId", type: "uint256"}], name: "DefaultGameUpdated", type: "event"} ;
		console.error( "eventCallOriginal[49,28] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "DefaultGameUpdated", events: [{name: "gameId", type: "uint256", value: "6697852"}], address: "0xea2fdf90bc0ca29eec91e1c952f83ba2b0440807"}] ;
		console.error( "eventResultOriginal[49,28] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "471183965702500000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "3322390900243644751" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
