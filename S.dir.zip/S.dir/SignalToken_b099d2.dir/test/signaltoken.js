const SignalToken = artifacts.require( "./SignalToken.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "SignalToken" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x36f16a0d35B866CdD0f3C3FA39e2Ba8F48b099d2", "0xD3B16f647aD234f8B5bB2bdBE8E919daa5268681", "0x4946Fcea7C692606e8908002e55A582af44AC121", "0xC7d47D741007F1f4488b4ce23eC0b0ffA592f680", "0xAB2a19c49Ea7422b2889566B96767B67436f582E", "0xABd06CC36f3Ce3deBE08b1788F16A0D6D21A5ca7", "0x0F1F11234e485864009225112d9663F82C841526", "0x0C819EcAF6A9e0263ef9bd7cA7A79f3eD41a73D9", "0xD36B26697220c5FAcED7a82332d044865e90C5e4", "0xCf0489AE7bbf3B7321841F3cE9DB682A6b0Cf612", "0xbB9AD3062c536c70217A3933Af33987730C52602", "0x49739691fB5f3992b3f2536f309D955558e75933", "0xF794c2FD357962a5908A51A09CeAd6D5A8B75381", "0x8175c0FFA6891A2BD149a9c86e1E034cB39C5Cc1", "0x276718F63a8D0A25d49616097eb458eAe6566890", "0x0a48296F7631708C95d2b74975BC4ab88ac1392A", "0x569F8174e65f3263de89633ab8e62665E285C989", "0x7d000f237d74313038Fe7D0669a9B8C4f225727b", "0x3f264498ad6E8407a3704C17077852b208737b2a", "0x896dB7C827E6Dc3635F659DAE77cD04b8D6cd5E3", "0x542c10b76fA485e8bE1e3b5f80F04392B3199EDA", "0xA00e47c8fBE274aB3C24b08081D661C8536Bc80C"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "_interfaceId", type: "bytes4"}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "name", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "getApproved", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "InterfaceId_ERC165", outputs: [{name: "", type: "bytes4"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "cst", type: "bytes32"}], name: "getRadius", outputs: [{name: "radius", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "tokenBurntOn", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "cst", type: "bytes32"}], name: "getDeletedOn", outputs: [{name: "timestamp", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "exists", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_tokenId", type: "uint256"}], name: "ownerOf", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "prover", type: "address"}], name: "numApplications", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "nftContract", type: "address"}, {name: "tokenID", type: "uint256"}], name: "computeCST", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "tokenGeohash", outputs: [{name: "", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "tokenRadius", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "prover", type: "address"}], name: "totalStaked", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "cst", type: "bytes32"}], name: "getGeohash", outputs: [{name: "geohash", type: "bytes32"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "tokenStake", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "tokenMintedOn", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "cst", type: "bytes32"}], name: "getCreatedOn", outputs: [{name: "timestamp", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "bytes32"}], name: "cstToID", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "cst", type: "bytes32"}], name: "isTracked", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "_owner", type: "address"}, {name: "_operator", type: "address"}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "controller", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_approved", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Approval", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "_owner", type: "address"}, {indexed: true, name: "_operator", type: "address"}, {indexed: false, name: "_approved", type: "bool"}], name: "ApprovalForAll", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}], name: "OwnershipRenounced", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "previousOwner", type: "address"}, {indexed: true, name: "newOwner", type: "address"}], name: "OwnershipTransferred", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TrackedToken(bytes32,address,uint256,bytes32,uint256)", "Transfer(address,address,uint256)", "Approval(address,address,uint256)", "ApprovalForAll(address,address,bool)", "OwnershipRenounced(address)", "OwnershipTransferred(address,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xae066be719a025aa84ce2e5cb92f496010fb4a339d6d9a2aac332be5770d471a", "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef", "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925", "0x17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31", "0xf8df31144d9c2f0f6b59d69b8b98abd5459d07f2742c4df920b25aae33c64820", "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6822073 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6826746 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_token", value: 4}], name: "SignalToken", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "bytes4", name: "_interfaceId", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "supportsInterface", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "supportsInterface(bytes4)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "name", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "name()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "getApproved", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getApproved(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "InterfaceId_ERC165", outputs: [{name: "", type: "bytes4"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "InterfaceId_ERC165()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "cst", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getRadius", outputs: [{name: "radius", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getRadius(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tokenBurntOn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenBurntOn(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "cst", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getDeletedOn", outputs: [{name: "timestamp", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getDeletedOn(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "exists", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "exists(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "_tokenId", value: random.range( maxRandom )}], name: "ownerOf", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "ownerOf(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "prover", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "numApplications", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "numApplications(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "balanceOf", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "balanceOf(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "nftContract", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "uint256", name: "tokenID", value: random.range( maxRandom )}], name: "computeCST", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "computeCST(address,uint256)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tokenGeohash", outputs: [{name: "", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenGeohash(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "symbol", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "symbol()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tokenRadius", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenRadius(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "prover", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "totalStaked", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "totalStaked(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "cst", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getGeohash", outputs: [{name: "geohash", type: "bytes32"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getGeohash(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tokenStake", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenStake(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "tokenMintedOn", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "tokenMintedOn(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "cst", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "getCreatedOn", outputs: [{name: "timestamp", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",20] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getCreatedOn(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",20] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "cstToID", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",21] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "cstToID(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",21] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "bytes32", name: "cst", value: "0x" + random.range( maxRandom ).toString( 16 )}], name: "isTracked", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",22] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isTracked(bytes32)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",22] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "_owner", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "_operator", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "isApprovedForAll", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",23] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "isApprovedForAll(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",23] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "controller", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",24] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "controller()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",24] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "SignalToken", function( accounts ) {

	it( "TEST: SignalToken( addressList[4] )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6822073", timeStamp: "1543891397", hash: "0xddb2942ad9e4706a725f67b0d8e193a3f47d2ccc7f9a43997b2af87c3e2cdc13", nonce: "30", blockHash: "0x9467fd88ccffcc78ffecc2384305d9d9e63dd9f07ff7ccb9f1adc8e8a28201cb", transactionIndex: "20", from: "0xd3b16f647ad234f8b5bb2bdbe8e919daa5268681", to: 0, value: "0", gas: "5000000", gasPrice: "25000000000", isError: "0", txreceipt_status: "1", input: "0x0237f37a0000000000000000000000004946fcea7c692606e8908002e55a582af44ac121", contractAddress: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", cumulativeGasUsed: "3017481", gasUsed: "1867258", confirmations: "861196"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_token", value: addressList[4]}], name: "SignalToken", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = SignalToken.new( addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1543891397 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = SignalToken.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "4780879078416146028" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[5], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6825697", timeStamp: "1543943078", hash: "0xcac6027557e799364a60f06d1ae97d9fb07cc6fbf916206e9fc6e5208c2fc54d", nonce: "1517", blockHash: "0x34b2d91b080e78f64548410bd8b8605ba87358ce0493016b4a81e555eb9d7d6d", transactionIndex: "13", from: "0xc7d47d741007f1f4488b4ce23ec0b0ffa592f680", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "1", txreceipt_status: "0", input: "0xb7f65439000000000000000000000000c7d47d741007f1f4488b4ce23ec0b0ffa592f68000000000000000000000000000000000000000000000003635c9adc5dea00000065cb7c26fe632d10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002710", contractAddress: "", cumulativeGasUsed: "589595", gasUsed: "156263", confirmations: "857572"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[5]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x065cb7c26fe632d1000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "10000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[5], "1000000000000000000000", "0x065cb7c26fe632d1000000000000000000000000000000000000000000000000", "10000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1543943078 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "39556673622944968" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[6], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6825781", timeStamp: "1543944297", hash: "0xa952c7fdd5ba1a7507f837350e9bf88b5b099e354605fc710fa168c5d53c6aba", nonce: "38", blockHash: "0x313a7129cfc23b8d40352b20c7549cfa61fd2c328eee7abb9b48ab1928afd516", transactionIndex: "73", from: "0xab2a19c49ea7422b2889566b96767b67436f582e", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000ab2a19c49ea7422b2889566b96767b67436f582e00000000000000000000000000000000000000000000021e19e0c9bab2400000065cb7c23775da6500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "3042089", gasUsed: "253783", confirmations: "857488"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[6], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[6]}, {type: "uint256", name: "stake", value: "10000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x065cb7c23775da65000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[6], "10000000000000000000000", "0x065cb7c23775da65000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1543944297 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[2,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x0661a22088f60194c64aeb4ff6dccf0c870b277db95111e17135140a7bbaebdb"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "1"}, {name: "geohash", type: "bytes32", value: "0x065cb7c23775da65000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[2,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xab2a19c49ea7422b2889566b96767b67436f582e"}, {name: "_tokenId", type: "uint256", value: "1"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[6], balance: "4635261666787798044" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[6], balance: ( await web3.eth.getBalance( addressList[6], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[5], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6825788", timeStamp: "1543944403", hash: "0x6db2fdf160fb0d1d6519cdcd4f6a4311444774d7bbcdcea6e9fd92b153ac1c6d", nonce: "1518", blockHash: "0xf4d6b7158ed5a1089fd8e9aee786759638e080bc88e3622b3478ed2c7d42be1c", transactionIndex: "16", from: "0xc7d47d741007f1f4488b4ce23ec0b0ffa592f680", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "30000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000c7d47d741007f1f4488b4ce23ec0b0ffa592f68000000000000000000000000000000000000000000000003635c9adc5dea00000065cb7c33b4db2ca0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "1167476", gasUsed: "223719", confirmations: "857481"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[5]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x065cb7c33b4db2ca000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[5], "1000000000000000000000", "0x065cb7c33b4db2ca000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1543944403 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xede51a540f67d0814eb574e03e8362013fe7f21697f1e6556c80f003165f4ab4"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "2"}, {name: "geohash", type: "bytes32", value: "0x065cb7c33b4db2ca000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[3,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xc7d47d741007f1f4488b4ce23ec0b0ffa592f680"}, {name: "_tokenId", type: "uint256", value: "2"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[3,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "39556673622944968" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[5], \"2000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6825837", timeStamp: "1543945037", hash: "0x971fe2842cef0adc1352e82a4677a8170197b8024c0ae169bf7fcf2acc5c5f83", nonce: "1519", blockHash: "0xbcc39c2e27abeee846105838ee732c3aee1c44cff28d1fe7973612b1a161be99", transactionIndex: "59", from: "0xc7d47d741007f1f4488b4ce23ec0b0ffa592f680", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000c7d47d741007f1f4488b4ce23ec0b0ffa592f68000000000000000000000000000000000000000000000006c6b935b8bbd4000000ed0e6d51b9e15be0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001b58", contractAddress: "", cumulativeGasUsed: "5437085", gasUsed: "193719", confirmations: "857432"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[5]}, {type: "uint256", name: "stake", value: "2000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0ed0e6d51b9e15be000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "7000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[5], "2000000000000000000000", "0x0ed0e6d51b9e15be000000000000000000000000000000000000000000000000", "7000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1543945037 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xad55cb5bc2d95f677843ab7fa24e21c54b44ec9f09e58d2d7044bc9d505d3ad2"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "3"}, {name: "geohash", type: "bytes32", value: "0x0ed0e6d51b9e15be000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "7000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[4,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xc7d47d741007f1f4488b4ce23ec0b0ffa592f680"}, {name: "_tokenId", type: "uint256", value: "3"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[4,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "39556673622944968" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[5], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6825904", timeStamp: "1543945908", hash: "0x33914ac2f6ad8dc2e78c724492c607114542d00e2958acde476ec4a2bab3c61b", nonce: "1520", blockHash: "0x3fe3aa77692ec8aba63e907a9b28811bc718c844a3c2ced9f67e374e5e9c5a77", transactionIndex: "2", from: "0xc7d47d741007f1f4488b4ce23ec0b0ffa592f680", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "15000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000c7d47d741007f1f4488b4ce23ec0b0ffa592f68000000000000000000000000000000000000000000000003635c9adc5dea00000065ce282bcdfd6460000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "252960", gasUsed: "193719", confirmations: "857365"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[5]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x065ce282bcdfd646000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[5], "1000000000000000000000", "0x065ce282bcdfd646000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1543945908 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x5483e839b80a8625f52ff8611c876eb5568b1c135372657559914c8e6188978b"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "4"}, {name: "geohash", type: "bytes32", value: "0x065ce282bcdfd646000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[5,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xc7d47d741007f1f4488b4ce23ec0b0ffa592f680"}, {name: "_tokenId", type: "uint256", value: "4"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[5,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "39556673622944968" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[7], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6825978", timeStamp: "1543947016", hash: "0x90b3f981c251c112f2d7d510817c0ba44af54ae055ecf5e746f8cfef6e7642bf", nonce: "35", blockHash: "0xcdb4aaf54a96d2911cc8a5183a06c05d572ef3a4ced8f42c707f8fbc2c91e43e", transactionIndex: "128", from: "0xabd06cc36f3ce3debe08b1788f16a0d6d21a5ca7", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000abd06cc36f3ce3debe08b1788f16a0d6d21a5ca700000000000000000000000000000000000000000000003635c9adc5dea000000d0c6c58306f534b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000061a8", contractAddress: "", cumulativeGasUsed: "5922902", gasUsed: "208719", confirmations: "857291"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[7]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d0c6c58306f534b000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "25000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[7], "1000000000000000000000", "0x0d0c6c58306f534b000000000000000000000000000000000000000000000000", "25000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1543947016 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x869ce77a0d93b7eb401be02b1e113402c16ebc07fb286512b0297ae4a8015c76"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "5"}, {name: "geohash", type: "bytes32", value: "0x0d0c6c58306f534b000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "25000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[6,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xabd06cc36f3ce3debe08b1788f16a0d6d21a5ca7"}, {name: "_tokenId", type: "uint256", value: "5"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[6,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "351609918438687737" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[8], \"500000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6825978", timeStamp: "1543947016", hash: "0x099e051b2ad89d65127d0527bc3c3f38c166bfdcb4074cb82834e3aa946580e4", nonce: "59", blockHash: "0xcdb4aaf54a96d2911cc8a5183a06c05d572ef3a4ced8f42c707f8fbc2c91e43e", transactionIndex: "142", from: "0x0f1f11234e485864009225112d9663f82c841526", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000000f1f11234e485864009225112d9663f82c84152600000000000000000000000000000000000000000000001b1ae4d6e2ef50000004d930e3c2ef46000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "7151355", gasUsed: "208591", confirmations: "857291"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[8]}, {type: "uint256", name: "stake", value: "500000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x04d930e3c2ef4600000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[8], "500000000000000000000", "0x04d930e3c2ef4600000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1543947016 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x4e5a2ec9825f7b50ce209da61086d65e5ca1c05e7c1a3dc179f95fe110146f22"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "6"}, {name: "geohash", type: "bytes32", value: "0x04d930e3c2ef4600000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[7,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0f1f11234e485864009225112d9663f82c841526"}, {name: "_tokenId", type: "uint256", value: "6"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[7,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "443903229000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[9], \"500000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6825978", timeStamp: "1543947016", hash: "0x807e82729585d9de87767bf3778f65a31339de113e7ad0572500235a18548aa2", nonce: "50", blockHash: "0xcdb4aaf54a96d2911cc8a5183a06c05d572ef3a4ced8f42c707f8fbc2c91e43e", transactionIndex: "145", from: "0x0c819ecaf6a9e0263ef9bd7ca7a79f3ed41a73d9", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000000c819ecaf6a9e0263ef9bd7ca7a79f3ed41a73d900000000000000000000000000000000000000000000001b1ae4d6e2ef5000000e12fc03509c1acd00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "7434221", gasUsed: "208719", confirmations: "857291"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[9]}, {type: "uint256", name: "stake", value: "500000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0e12fc03509c1acd000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[9], "500000000000000000000", "0x0e12fc03509c1acd000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1543947016 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x0a5711b578e3fd12a63e580589daaa651d135772af35e5fb3bdc03d645b3576b"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "7"}, {name: "geohash", type: "bytes32", value: "0x0e12fc03509c1acd000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[8,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0c819ecaf6a9e0263ef9bd7ca7a79f3ed41a73d9"}, {name: "_tokenId", type: "uint256", value: "7"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[8,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "1518803072500000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[10], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826020", timeStamp: "1543947673", hash: "0x45ae469ea27ea243b561ca9e2058d698f00bc9945ab6edc4e4629dbb5a2a5b19", nonce: "31", blockHash: "0xf60860fe4dc24921773eb99cc98fee83513bc6a7022aa25acd48acdb941db9c8", transactionIndex: "69", from: "0xd36b26697220c5faced7a82332d044865e90c5e4", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000d36b26697220c5faced7a82332d044865e90c5e400000000000000000000000000000000000000000000001b1ae4d6e2ef5000000d04e3fd897e4dd90000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001388", contractAddress: "", cumulativeGasUsed: "3960673", gasUsed: "208719", confirmations: "857249"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[10], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[10]}, {type: "uint256", name: "stake", value: "500000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d04e3fd897e4dd9000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "5000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[10], "500000000000000000000", "0x0d04e3fd897e4dd9000000000000000000000000000000000000000000000000", "5000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1543947673 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x44bb1d3e2e7201e564dd086f756a72737e217f7335a8dc789e487005175defaa"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "8"}, {name: "geohash", type: "bytes32", value: "0x0d04e3fd897e4dd9000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "5000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[9,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xd36b26697220c5faced7a82332d044865e90c5e4"}, {name: "_tokenId", type: "uint256", value: "8"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[9,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[10], balance: "175696931656780000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[10], balance: ( await web3.eth.getBalance( addressList[10], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[11], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826026", timeStamp: "1543947740", hash: "0x685ffa65325606418f586ace0b78fa92b64cf0b13e4bd09a3eeb887cadb3e865", nonce: "400", blockHash: "0xc46839e3558940fe1493cabb15dcfa59708d7608cea3e0e5b42e31fc3aeb7095", transactionIndex: "58", from: "0xcf0489ae7bbf3b7321841f3ce9db682a6b0cf612", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "200000", gasPrice: "9000000000", isError: "1", txreceipt_status: "0", input: "0xb7f65439000000000000000000000000cf0489ae7bbf3b7321841f3ce9db682a6b0cf61200000000000000000000000000000000000000000000001b1ae4d6e2ef5000000657e81a150684220000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "3175579", gasUsed: "200000", confirmations: "857243"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[11]}, {type: "uint256", name: "stake", value: "500000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0657e81a15068422000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "5390194500000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[11], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826055", timeStamp: "1543948242", hash: "0x04b9d343e156d18e945745a902ffaa581d38fac571a9cb14a17035d4c48f3979", nonce: "401", blockHash: "0xd70392605694f3dcb6b4272f4d14eb0c1a8f2553ab56672c6e173ac0b2a592ca", transactionIndex: "83", from: "0xcf0489ae7bbf3b7321841f3ce9db682a6b0cf612", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000cf0489ae7bbf3b7321841f3ce9db682a6b0cf61200000000000000000000000000000000000000000000003635c9adc5dea000000657e81a150684360000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "4709424", gasUsed: "223719", confirmations: "857214"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[11]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0657e81a15068436000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[11], "1000000000000000000000", "0x0657e81a15068436000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1543948242 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[11,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xd8bc38ad1f9f04fae6962ab66383a31e029d85cb34788c01f689e0ee02ff30a2"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "9"}, {name: "geohash", type: "bytes32", value: "0x0657e81a15068436000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[11,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[11,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xcf0489ae7bbf3b7321841f3ce9db682a6b0cf612"}, {name: "_tokenId", type: "uint256", value: "9"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[11,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "5390194500000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[12], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826070", timeStamp: "1543948509", hash: "0x7f13aff010c6cc1d5202cbeb0ee05fe37b9313fb10b90fd4c482f769433aa4f7", nonce: "328", blockHash: "0xcc5fc7a1abab19e68f5ca82e5824a94e26b4d3f4e50e770a2a148d43dbf3869d", transactionIndex: "85", from: "0xbb9ad3062c536c70217a3933af33987730c52602", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000bb9ad3062c536c70217a3933af33987730c5260200000000000000000000000000000000000000000000000ad78ebc5ac62000000d2ddb04510b9b3300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007d0", contractAddress: "", cumulativeGasUsed: "5551715", gasUsed: "223719", confirmations: "857199"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[12]}, {type: "uint256", name: "stake", value: "200000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d2ddb04510b9b33000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "2000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[12], "200000000000000000000", "0x0d2ddb04510b9b33000000000000000000000000000000000000000000000000", "2000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1543948509 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[12,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x15015902f8c577e7873b64bfe2ef089b1204b89cec281f015cf3715677eb9618"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "10"}, {name: "geohash", type: "bytes32", value: "0x0d2ddb04510b9b33000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "2000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[12,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbb9ad3062c536c70217a3933af33987730c52602"}, {name: "_tokenId", type: "uint256", value: "10"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46757333988749487" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[12], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826072", timeStamp: "1543948611", hash: "0xa4647b8277468cdba36806d130395e3a66b65a013e5e5f597a5a2d60a2fe0b53", nonce: "329", blockHash: "0x7f85ba09b6760f71b8e98716b9af15721387a742ca0be4ba993c094b3c55043e", transactionIndex: "183", from: "0xbb9ad3062c536c70217a3933af33987730c52602", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000bb9ad3062c536c70217a3933af33987730c526020000000000000000000000000000000000000000000000056bc75e2d631000000d2dd9a4393d849100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007d0", contractAddress: "", cumulativeGasUsed: "7439697", gasUsed: "193719", confirmations: "857197"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[12]}, {type: "uint256", name: "stake", value: "100000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d2dd9a4393d8491000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "2000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[12], "100000000000000000000", "0x0d2dd9a4393d8491000000000000000000000000000000000000000000000000", "2000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1543948611 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[13,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x1a7313e522cfc39954e7a6b695e33ecc7d39482e7cd4616b4a0fd8023ec54585"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "11"}, {name: "geohash", type: "bytes32", value: "0x0d2dd9a4393d8491000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "2000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[13,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbb9ad3062c536c70217a3933af33987730c52602"}, {name: "_tokenId", type: "uint256", value: "11"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46757333988749487" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[12], \"50000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6826096", timeStamp: "1543948943", hash: "0xdd869131cb1038724bab8c07c96053af049ff9306913b55ed78a335a22910530", nonce: "330", blockHash: "0xb7e36138f7687d4ddfd666aaf61ef42b10d93034622b6d94b1a60d8af9fb164d", transactionIndex: "109", from: "0xbb9ad3062c536c70217a3933af33987730c52602", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000bb9ad3062c536c70217a3933af33987730c52602000000000000000000000000000000000000000000000002b5e3af16b18800000d2dd9a7a91cccbf00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007d0", contractAddress: "", cumulativeGasUsed: "5541008", gasUsed: "193719", confirmations: "857173"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[12]}, {type: "uint256", name: "stake", value: "50000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d2dd9a7a91cccbf000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "2000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[12], "50000000000000000000", "0x0d2dd9a7a91cccbf000000000000000000000000000000000000000000000000", "2000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1543948943 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[14,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xce7dc5580466428d6651aa8234195699dfe765bd7dcfd3193dbf235a9e88b560"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "12"}, {name: "geohash", type: "bytes32", value: "0x0d2dd9a7a91cccbf000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "2000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[14,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbb9ad3062c536c70217a3933af33987730c52602"}, {name: "_tokenId", type: "uint256", value: "12"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46757333988749487" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[11], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826099", timeStamp: "1543948988", hash: "0x99dde05049980ad4d189da340b62364afef24ebcc1d070f2eded9bb1e74f3a63", nonce: "402", blockHash: "0xd8fc5275dcfddba4ab24ff72a079451fa6a43862d7f011f5e0e3ff67061d7c1b", transactionIndex: "31", from: "0xcf0489ae7bbf3b7321841f3ce9db682a6b0cf612", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000cf0489ae7bbf3b7321841f3ce9db682a6b0cf61200000000000000000000000000000000000000000000003635c9adc5dea000000657e8674b23a73a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "2185989", gasUsed: "178719", confirmations: "857170"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[11]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0657e8674b23a73a000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[11], "1000000000000000000000", "0x0657e8674b23a73a000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1543948988 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[15,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xd38c407674ba7ec0672e696ba7e563163c26af5841cee7d941bbd2c311cf567f"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "13"}, {name: "geohash", type: "bytes32", value: "0x0657e8674b23a73a000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[15,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xcf0489ae7bbf3b7321841f3ce9db682a6b0cf612"}, {name: "_tokenId", type: "uint256", value: "13"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "5390194500000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[5], \"1000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826100", timeStamp: "1543949005", hash: "0xc1905f2e17c1505a06c5ab58e4b034f0bdae2bbebfca0401bc3623f6820b9de2", nonce: "1521", blockHash: "0xe865af9a45bd6dd1b0c743d7e4807ff2c00f7d770b41f36e36b7cbd235392a8f", transactionIndex: "79", from: "0xc7d47d741007f1f4488b4ce23ec0b0ffa592f680", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000c7d47d741007f1f4488b4ce23ec0b0ffa592f68000000000000000000000000000000000000000000000003635c9adc5dea0000004d91ecf4a6e1a670000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002710", contractAddress: "", cumulativeGasUsed: "7004727", gasUsed: "193719", confirmations: "857169"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[5], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[5]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x04d91ecf4a6e1a67000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "10000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[5], "1000000000000000000000", "0x04d91ecf4a6e1a67000000000000000000000000000000000000000000000000", "10000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1543949005 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[16,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x70c60f2c094b0819a9d1b8d846e95a966caa91020590e8900f73244737906f8c"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "14"}, {name: "geohash", type: "bytes32", value: "0x04d91ecf4a6e1a67000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "10000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[16,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xc7d47d741007f1f4488b4ce23ec0b0ffa592f680"}, {name: "_tokenId", type: "uint256", value: "14"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[5], balance: "39556673622944968" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[5], balance: ( await web3.eth.getBalance( addressList[5], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: burn( \"10\" )", async function( ) {
		const txOriginal = {blockNumber: "6826121", timeStamp: "1543949256", hash: "0x78ce060d82e528044f1188ee564b549d23afcd7097dd9b46b22e800db5e26256", nonce: "332", blockHash: "0x57d09caaa6b16b367dd11e21d646bc6c6c2988f5a10ff2e7b889e4a45c220b8a", transactionIndex: "111", from: "0xbb9ad3062c536c70217a3933af33987730c52602", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0x42966c68000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "3788152", gasUsed: "67136", confirmations: "857148"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "tokenID", value: "10"}], name: "burn", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "burn(uint256)" ]( "10", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1543949256 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xbb9ad3062c536c70217a3933af33987730c52602"}, {name: "_to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_tokenId", type: "uint256", value: "10"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46757333988749487" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[13], \"350000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826147", timeStamp: "1543949666", hash: "0x5c60eb9426171478b7a49071a0de6b06d4f40505466d4f0447c91381629db3f4", nonce: "176", blockHash: "0xeac59def099499c3827bcfe41e27ce1e1498723f51b1df743048c766069e6c68", transactionIndex: "19", from: "0x49739691fb5f3992b3f2536f309d955558e75933", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f6543900000000000000000000000049739691fb5f3992b3f2536f309d955558e75933000000000000000000000000000000000000000000000012f939c99edab8000006548c2d9af817710000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002710", contractAddress: "", cumulativeGasUsed: "6352487", gasUsed: "208719", confirmations: "857122"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[13], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[13]}, {type: "uint256", name: "stake", value: "350000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x06548c2d9af81771000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "10000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[13], "350000000000000000000", "0x06548c2d9af81771000000000000000000000000000000000000000000000000", "10000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1543949666 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[18,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x9cb5a30fd7b148dd2e141834780a470f5e823b0d5ea7205b0cd532254d70409b"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "15"}, {name: "geohash", type: "bytes32", value: "0x06548c2d9af81771000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "10000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[18,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x49739691fb5f3992b3f2536f309d955558e75933"}, {name: "_tokenId", type: "uint256", value: "15"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[13], balance: "654379347992238263" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[13], balance: ( await web3.eth.getBalance( addressList[13], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[12], \"750000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826152", timeStamp: "1543949745", hash: "0x1bbba921846bb53f2def6a57066e81f818d8c0923dd8e811eff72f8d665c5ec2", nonce: "335", blockHash: "0x654b6b78b25758e2831221509455087ab6dcc9981357c315ac03e6b8902d7787", transactionIndex: "25", from: "0xbb9ad3062c536c70217a3933af33987730c52602", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000bb9ad3062c536c70217a3933af33987730c52602000000000000000000000000000000000000000000000028a857425466f800000d2ddb0447722c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007d0", contractAddress: "", cumulativeGasUsed: "1803305", gasUsed: "178655", confirmations: "857117"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[12]}, {type: "uint256", name: "stake", value: "750000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d2ddb0447722c00000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "2000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[12], "750000000000000000000", "0x0d2ddb0447722c00000000000000000000000000000000000000000000000000", "2000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1543949745 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[19,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x003ae4f85cd91c6e3f2fd846f6030b97a4a09c2c9eaabe63a5fbadee2c4ef244"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "16"}, {name: "geohash", type: "bytes32", value: "0x0d2ddb0447722c00000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "2000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[19,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbb9ad3062c536c70217a3933af33987730c52602"}, {name: "_tokenId", type: "uint256", value: "16"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46757333988749487" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[14], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826168", timeStamp: "1543949943", hash: "0xf61c68aa8ee6f6bc0396bedb62475f9db4faf5074627a991e2d22d6925c13d83", nonce: "109", blockHash: "0x95719ab7a474f1558312a4f5c1b9c630a41bb975606242c097b171df418cf56f", transactionIndex: "17", from: "0xf794c2fd357962a5908a51a09cead6d5a8b75381", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000f794c2fd357962a5908a51a09cead6d5a8b753810000000000000000000000000000000000000000000000056bc75e2d6310000004d91ef10a4ff36a0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001388", contractAddress: "", cumulativeGasUsed: "5005204", gasUsed: "223719", confirmations: "857101"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[14]}, {type: "uint256", name: "stake", value: "100000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x04d91ef10a4ff36a000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "5000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[14], "100000000000000000000", "0x04d91ef10a4ff36a000000000000000000000000000000000000000000000000", "5000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1543949943 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[20,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x98316e737d3f4828f01ba353b6562de57333200e563bc17a5b5fa26471767dfe"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "17"}, {name: "geohash", type: "bytes32", value: "0x04d91ef10a4ff36a000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "5000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[20,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf794c2fd357962a5908a51a09cead6d5a8b75381"}, {name: "_tokenId", type: "uint256", value: "17"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "39979959900000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: burn( \"17\" )", async function( ) {
		const txOriginal = {blockNumber: "6826188", timeStamp: "1543950228", hash: "0x45813d76518571a77d074dc9c6e92beef7e00f3b64cb1280e59d6ace1ccf2b88", nonce: "110", blockHash: "0x8dc44cf0f90d6a696d2f0e09ba2ccbd4ad447007fafdfbefa3299544e2246d32", transactionIndex: "30", from: "0xf794c2fd357962a5908a51a09cead6d5a8b75381", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0x42966c680000000000000000000000000000000000000000000000000000000000000011", contractAddress: "", cumulativeGasUsed: "5323305", gasUsed: "41068", confirmations: "857081"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "tokenID", value: "17"}], name: "burn", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "burn(uint256)" ]( "17", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1543950228 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0xf794c2fd357962a5908a51a09cead6d5a8b75381"}, {name: "_to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_tokenId", type: "uint256", value: "17"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "39979959900000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[12], \"250000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826189", timeStamp: "1543950237", hash: "0xe00a14c1698ca64879da15639a9c4378026a60c72ce093d6550c21f973d2e1a5", nonce: "337", blockHash: "0x22dd7168c5fda9b6073959d33d92678b79e1899afedc3c19cd3fc133df1daa4e", transactionIndex: "73", from: "0xbb9ad3062c536c70217a3933af33987730c52602", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000bb9ad3062c536c70217a3933af33987730c5260200000000000000000000000000000000000000000000000d8d726b7177a800000d2ddb124e8b468100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "4650884", gasUsed: "178719", confirmations: "857080"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[12]}, {type: "uint256", name: "stake", value: "250000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d2ddb124e8b4681000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[12], "250000000000000000000", "0x0d2ddb124e8b4681000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1543950237 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[22,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xba96a6b14009fd8688434161bad6db0e826cc3aa51f4f6a2c5fb19937ae085cd"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "18"}, {name: "geohash", type: "bytes32", value: "0x0d2ddb124e8b4681000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[22,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbb9ad3062c536c70217a3933af33987730c52602"}, {name: "_tokenId", type: "uint256", value: "18"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46757333988749487" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[12], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826229", timeStamp: "1543950737", hash: "0xc1c3f4e9ae86ba39d7674ee4efea4a7e95ff3204c0a07f665bef662d5aa75171", nonce: "339", blockHash: "0xb017404e158fae4ee50c6b7b486c1ebf2b2a745d1ebe4f055ef7a2accf7df718", transactionIndex: "85", from: "0xbb9ad3062c536c70217a3933af33987730c52602", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000bb9ad3062c536c70217a3933af33987730c5260200000000000000000000000000000000000000000000000ad78ebc5ac62000000d2dd8c6edb1f0f700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "7662983", gasUsed: "193719", confirmations: "857040"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[12]}, {type: "uint256", name: "stake", value: "200000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d2dd8c6edb1f0f7000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[12], "200000000000000000000", "0x0d2dd8c6edb1f0f7000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1543950737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[23,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xa0b9ec06f57d5c4b53acdbe77596f08c0043c49b2de8375db2d6690cd7e46c22"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "19"}, {name: "geohash", type: "bytes32", value: "0x0d2dd8c6edb1f0f7000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[23,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbb9ad3062c536c70217a3933af33987730c52602"}, {name: "_tokenId", type: "uint256", value: "19"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46757333988749487" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[14], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826253", timeStamp: "1543951022", hash: "0x340933f8a33475d2f4572e15a601598169210ea79c6772b83dec55a22079b3b6", nonce: "112", blockHash: "0xa2097856eb4a3b1528eadfcfcc25ce49b3e4e435a7716bd77a722f4fb6efbcc9", transactionIndex: "78", from: "0xf794c2fd357962a5908a51a09cead6d5a8b75381", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000f794c2fd357962a5908a51a09cead6d5a8b7538100000000000000000000000000000000000000000000003635c9adc5dea0000004d91ede9254536f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001388", contractAddress: "", cumulativeGasUsed: "6210094", gasUsed: "208719", confirmations: "857016"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[14]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x04d91ede9254536f000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "5000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[14], "1000000000000000000000", "0x04d91ede9254536f000000000000000000000000000000000000000000000000", "5000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1543951022 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[24,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x10cc1fb31d2802ad8546b54d25b3e1d07a5f576ca570397e079a4a5aead30da6"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "20"}, {name: "geohash", type: "bytes32", value: "0x04d91ede9254536f000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "5000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[24,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf794c2fd357962a5908a51a09cead6d5a8b75381"}, {name: "_tokenId", type: "uint256", value: "20"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "39979959900000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[11], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826267", timeStamp: "1543951194", hash: "0xfca61e9f59cf4d7645d10f2615ffdc528f33723aeffcbfe2c69fdf9801a024c3", nonce: "404", blockHash: "0x16ee94111b471bd760c9376233c8fb844c0099ad8f1820f368fcb856d312b4f0", transactionIndex: "39", from: "0xcf0489ae7bbf3b7321841f3ce9db682a6b0cf612", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000cf0489ae7bbf3b7321841f3ce9db682a6b0cf61200000000000000000000000000000000000000000000003635c9adc5dea000000657e81e553c2c060000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "2639875", gasUsed: "193719", confirmations: "857002"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[11], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[11]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0657e81e553c2c06000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[11], "1000000000000000000000", "0x0657e81e553c2c06000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1543951194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[25,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x77f3710732f76ad3728a8e7681edebac49f68877f257fcaaa32c60abc3d18316"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "21"}, {name: "geohash", type: "bytes32", value: "0x0657e81e553c2c06000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[25,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xcf0489ae7bbf3b7321841f3ce9db682a6b0cf612"}, {name: "_tokenId", type: "uint256", value: "21"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[11], balance: "5390194500000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[11], balance: ( await web3.eth.getBalance( addressList[11], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[8], \"5000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826267", timeStamp: "1543951194", hash: "0xf8339298b4c742a69f93ae2d76b83361bba6f7a74d26513d1021e9c0276fec4c", nonce: "61", blockHash: "0x16ee94111b471bd760c9376233c8fb844c0099ad8f1820f368fcb856d312b4f0", transactionIndex: "41", from: "0x0f1f11234e485864009225112d9663f82c841526", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000000f1f11234e485864009225112d9663f82c841526000000000000000000000000000000000000000000000a968163f0a57b40000004d930da4ac6a07c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "2986533", gasUsed: "193719", confirmations: "857002"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[8]}, {type: "uint256", name: "stake", value: "50000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x04d930da4ac6a07c000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[8], "50000000000000000000000", "0x04d930da4ac6a07c000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1543951194 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[26,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x961402eba928a9060c1dfa550321e59d96d1cd470ef324d269b59bd104ba60b3"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "22"}, {name: "geohash", type: "bytes32", value: "0x04d930da4ac6a07c000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[26,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0f1f11234e485864009225112d9663f82c841526"}, {name: "_tokenId", type: "uint256", value: "22"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "443903229000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[12], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826273", timeStamp: "1543951245", hash: "0x87acd0de41f903d4a4110eb695297a80f4b695d5a77fd689b486dc2d531dd77a", nonce: "340", blockHash: "0xea673dda8efb6f05e0a938200509533e21228e834c6a3629e0f9a7bda43c21b0", transactionIndex: "52", from: "0xbb9ad3062c536c70217a3933af33987730c52602", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000bb9ad3062c536c70217a3933af33987730c526020000000000000000000000000000000000000000000000056bc75e2d631000000d2bb99a21714c9e00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "4433573", gasUsed: "178719", confirmations: "856996"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[12], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[12]}, {type: "uint256", name: "stake", value: "100000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d2bb99a21714c9e000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[12], "100000000000000000000", "0x0d2bb99a21714c9e000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1543951245 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[27,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x139536f65ffd20db52c90719c815d2f9d4620797fd22c803c8e5124e534e51ee"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "23"}, {name: "geohash", type: "bytes32", value: "0x0d2bb99a21714c9e000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[27,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xbb9ad3062c536c70217a3933af33987730c52602"}, {name: "_tokenId", type: "uint256", value: "23"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[12], balance: "46757333988749487" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[12], balance: ( await web3.eth.getBalance( addressList[12], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[8], \"5000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826313", timeStamp: "1543951722", hash: "0x85a3193d6dbf4f30f5b68cee6a231b15e33c46c7e93c930d276897f1e3c6dc9c", nonce: "62", blockHash: "0xe450584d8879095631305bb810dd51c2190e776cf76c37dc94f238382bd9d64a", transactionIndex: "156", from: "0x0f1f11234e485864009225112d9663f82c841526", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "20000000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000000f1f11234e485864009225112d9663f82c841526000000000000000000000000000000000000000000000a968163f0a57b40000004d931800cf2696b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "5805891", gasUsed: "193719", confirmations: "856956"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[8]}, {type: "uint256", name: "stake", value: "50000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x04d931800cf2696b000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[8], "50000000000000000000000", "0x04d931800cf2696b000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1543951722 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[28,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x9d7cb8cf55a7088490ab77ade46777ffb806fe30c88a41133c463f6e7fd26918"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "24"}, {name: "geohash", type: "bytes32", value: "0x04d931800cf2696b000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[28,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[28,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0f1f11234e485864009225112d9663f82c841526"}, {name: "_tokenId", type: "uint256", value: "24"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[28,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "443903229000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[14], \"700000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826324", timeStamp: "1543951947", hash: "0xf05b1eb1e2fdc4e50a6baf16a1f5da72de5fdc68e5ca79a89ffbc465b4857eb4", nonce: "114", blockHash: "0xc6f04e29ad0e22d853aa73c15f1a15c8f5081b759caaaf4ffa2aed9f4c156e9d", transactionIndex: "17", from: "0xf794c2fd357962a5908a51a09cead6d5a8b75381", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000f794c2fd357962a5908a51a09cead6d5a8b7538100000000000000000000000000000000000000000000017b7883c0691660000004d91ef4f330c15700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007d0", contractAddress: "", cumulativeGasUsed: "1166626", gasUsed: "163783", confirmations: "856945"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[14], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[14]}, {type: "uint256", name: "stake", value: "7000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x04d91ef4f330c157000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "2000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[14], "7000000000000000000000", "0x04d91ef4f330c157000000000000000000000000000000000000000000000000", "2000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1543951947 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[29,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xf4d16c0392dc5f3fbf3e94799d6d9daa9d8ab64411d85640850800ddf2018cad"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "25"}, {name: "geohash", type: "bytes32", value: "0x04d91ef4f330c157000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "2000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[29,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[29,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xf794c2fd357962a5908a51a09cead6d5a8b75381"}, {name: "_tokenId", type: "uint256", value: "25"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[29,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[14], balance: "39979959900000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[14], balance: ( await web3.eth.getBalance( addressList[14], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[15], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826338", timeStamp: "1543952119", hash: "0x92667f85680b2e447998f44cecc238cfb1922caba14c634509d9a86b053fb37b", nonce: "77", blockHash: "0x23f2b2d3a0de8a8c88b24cf7db3432947d82c784f9c9914e3e8817299446f11f", transactionIndex: "120", from: "0x8175c0ffa6891a2bd149a9c86e1e034cb39c5cc1", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9100000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000008175c0ffa6891a2bd149a9c86e1e034cb39c5cc100000000000000000000000000000000000000000000021e19e0c9bab240000007aeba7fe268640500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "7590364", gasUsed: "223783", confirmations: "856931"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[15], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[15]}, {type: "uint256", name: "stake", value: "10000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x07aeba7fe2686405000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[15], "10000000000000000000000", "0x07aeba7fe2686405000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1543952119 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[30,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xe75bceab5619721be00c568c93233a272ed7c293c5ff126b1bc4b274139e99ad"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "26"}, {name: "geohash", type: "bytes32", value: "0x07aeba7fe2686405000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[30,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[30,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x8175c0ffa6891a2bd149a9c86e1e034cb39c5cc1"}, {name: "_tokenId", type: "uint256", value: "26"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[30,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[15], balance: "4056484330947420073" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[15], balance: ( await web3.eth.getBalance( addressList[15], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[8], \"5000000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826414", timeStamp: "1543953062", hash: "0xa18c891f2ea6455a1f6da2f488ce075787f65d027ba879e4e47714bc14dac225", nonce: "63", blockHash: "0x4b2a4b6b3433a4200cbc3b1fb9fb233c6501f2ad5eeaf939147255f3d4abf13a", transactionIndex: "58", from: "0x0f1f11234e485864009225112d9663f82c841526", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "10000000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000000f1f11234e485864009225112d9663f82c841526000000000000000000000000000000000000000000000a968163f0a57b40000004d9312785e05e410000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "2431442", gasUsed: "193719", confirmations: "856855"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[8], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[8]}, {type: "uint256", name: "stake", value: "50000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x04d9312785e05e41000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[8], "50000000000000000000000", "0x04d9312785e05e41000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1543953062 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[31,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x0a4fadde77fe6637c330f74f86740409e537fba0c374d669c15d0f0f001c698e"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "27"}, {name: "geohash", type: "bytes32", value: "0x04d9312785e05e41000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[31,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[31,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0f1f11234e485864009225112d9663f82c841526"}, {name: "_tokenId", type: "uint256", value: "27"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[31,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[8], balance: "443903229000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[8], balance: ( await web3.eth.getBalance( addressList[8], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[16], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826454", timeStamp: "1543953537", hash: "0xbbcfb0eac99efef8aa0ccfebb0346c88fb03fd1e966ef074a9686232740beec6", nonce: "310", blockHash: "0x73d0cea5d1ec1f31afd65c289d81e51a0c23c8a5255f5051ef2888c44f08c8d4", transactionIndex: "51", from: "0x276718f63a8d0a25d49616097eb458eae6566890", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000276718f63a8d0a25d49616097eb458eae656689000000000000000000000000000000000000000000000010f0cf064dd592000000d04e986297f365300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000061a8", contractAddress: "", cumulativeGasUsed: "5793987", gasUsed: "223783", confirmations: "856815"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[16]}, {type: "uint256", name: "stake", value: "5000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d04e986297f3653000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "25000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[16], "5000000000000000000000", "0x0d04e986297f3653000000000000000000000000000000000000000000000000", "25000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1543953537 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[32,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xd4cc7a7ff2edd28098a0b0d603be263a4f02d5d247a0c91ea0278891b68b0333"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "28"}, {name: "geohash", type: "bytes32", value: "0x0d04e986297f3653000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "25000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[32,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[32,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x276718f63a8d0a25d49616097eb458eae6566890"}, {name: "_tokenId", type: "uint256", value: "28"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[32,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "39749226369484400" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[16], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826490", timeStamp: "1543953913", hash: "0xb0160dc85fb234d217c6cd34b906ac35efc5f65a1cb9a98f95f1f544f3e50f00", nonce: "311", blockHash: "0xa3dd0e6ead53192652a0ca48e510c8284ee1e3cece63d97fd60fbe7bd8981160", transactionIndex: "14", from: "0x276718f63a8d0a25d49616097eb458eae6566890", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "8000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000276718f63a8d0a25d49616097eb458eae65668900000000000000000000000000000000000000000000000a2a15d09519be000000d04e7a0b3e391260000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004e20", contractAddress: "", cumulativeGasUsed: "6072303", gasUsed: "193719", confirmations: "856779"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[16]}, {type: "uint256", name: "stake", value: "3000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d04e7a0b3e39126000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "20000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[16], "3000000000000000000000", "0x0d04e7a0b3e39126000000000000000000000000000000000000000000000000", "20000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1543953913 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[33,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xe3a938821021be5daba352bd62f9a229d65890881daf5cb759e9d50995e6ffbb"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "29"}, {name: "geohash", type: "bytes32", value: "0x0d04e7a0b3e39126000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "20000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[33,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[33,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x276718f63a8d0a25d49616097eb458eae6566890"}, {name: "_tokenId", type: "uint256", value: "29"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[33,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "39749226369484400" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[16], \"400000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826502", timeStamp: "1543954069", hash: "0x8671cba4cf7b78fd54696038c427a739cb8cf5392393c58fbd43e6b5e112b888", nonce: "312", blockHash: "0xd4e96860db7c42e54527c7fb75ebaef8a2be2afa64c2add5f53cce03b8a0ba8f", transactionIndex: "53", from: "0x276718f63a8d0a25d49616097eb458eae6566890", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000276718f63a8d0a25d49616097eb458eae65668900000000000000000000000000000000000000000000000d8d726b7177a8000000d04b59b7adce18700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000061a8", contractAddress: "", cumulativeGasUsed: "5380046", gasUsed: "193719", confirmations: "856767"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[16]}, {type: "uint256", name: "stake", value: "4000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d04b59b7adce187000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "25000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[16], "4000000000000000000000", "0x0d04b59b7adce187000000000000000000000000000000000000000000000000", "25000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1543954069 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[34,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x3cfa64072f4b4037916980646ddf05c9adf1a127a1165cdb6aed9a4ea609645c"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "30"}, {name: "geohash", type: "bytes32", value: "0x0d04b59b7adce187000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "25000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[34,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[34,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x276718f63a8d0a25d49616097eb458eae6566890"}, {name: "_tokenId", type: "uint256", value: "30"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[34,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "39749226369484400" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[17], \"900000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826504", timeStamp: "1543954081", hash: "0x8b2d8e7474cc459f7c64fe9dd6bf6f3b734e51aeb79b1867a7f29c460963a939", nonce: "252", blockHash: "0xc611f6063d89235781f1c2c4bdf364bdea567752c63bfb2fa5c3e19f16cf937d", transactionIndex: "73", from: "0x0a48296f7631708c95d2b74975bc4ab88ac1392a", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000000a48296f7631708c95d2b74975bc4ab88ac1392a00000000000000000000000000000000000000000000130ee8e71790444000000708acdb5f1fa3790000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb8", contractAddress: "", cumulativeGasUsed: "7247655", gasUsed: "208783", confirmations: "856765"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[17]}, {type: "uint256", name: "stake", value: "90000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0708acdb5f1fa379000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "3000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[17], "90000000000000000000000", "0x0708acdb5f1fa379000000000000000000000000000000000000000000000000", "3000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1543954081 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[35,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xd78a274685083cf27f1c4982db069f79d1162e951b469cbd9962bd0e1cb194c4"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "31"}, {name: "geohash", type: "bytes32", value: "0x0708acdb5f1fa379000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "3000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[35,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[35,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x0a48296f7631708c95d2b74975bc4ab88ac1392a"}, {name: "_tokenId", type: "uint256", value: "31"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[35,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "21377384037249768" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[16], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826525", timeStamp: "1543954404", hash: "0x8edb5e5750f5279ccec9cdcfaa940dc2a4df7664ddb8dfbe37d17a92a062d769", nonce: "313", blockHash: "0x2a97bf06eeb896125991048a62861fc5bf6d3c1f3bc4761fdda633f9d4cec762", transactionIndex: "136", from: "0x276718f63a8d0a25d49616097eb458eae6566890", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000276718f63a8d0a25d49616097eb458eae65668900000000000000000000000000000000000000000000000a2a15d09519be000000d04e3d2001b48b20000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004e20", contractAddress: "", cumulativeGasUsed: "7335739", gasUsed: "193655", confirmations: "856744"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[16]}, {type: "uint256", name: "stake", value: "3000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d04e3d2001b48b2000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "20000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[16], "3000000000000000000000", "0x0d04e3d2001b48b2000000000000000000000000000000000000000000000000", "20000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1543954404 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[36,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x3c65f1a2b84ae725446d713a4f567b3d2897b3bf969e2f77648711d7ad657c7e"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "32"}, {name: "geohash", type: "bytes32", value: "0x0d04e3d2001b48b2000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "20000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[36,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[36,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x276718f63a8d0a25d49616097eb458eae6566890"}, {name: "_tokenId", type: "uint256", value: "32"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[36,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "39749226369484400" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[18], \"500000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826607", timeStamp: "1543955526", hash: "0xf69d08b731200ff8b3688cc364bab1c40faf912e180954031a6ce8b1023c5c38", nonce: "94", blockHash: "0x72d6bb92698e43b3d0e9d6ce9cf9872d5843976979cdcef67e265fca48efaaed", transactionIndex: "102", from: "0x569f8174e65f3263de89633ab8e62665e285c989", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000569f8174e65f3263de89633ab8e62665e285c98900000000000000000000000000000000000000000000001b1ae4d6e2ef500000065cb7d31e6a053700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "7213786", gasUsed: "208719", confirmations: "856662"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[18]}, {type: "uint256", name: "stake", value: "500000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x065cb7d31e6a0537000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[18], "500000000000000000000", "0x065cb7d31e6a0537000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1543955526 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[37,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xd31e70958b079336f9d5a321b6ba1d94a6b8200d1dd9dc35a1f06ea6991f484d"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "33"}, {name: "geohash", type: "bytes32", value: "0x065cb7d31e6a0537000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[37,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[37,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x569f8174e65f3263de89633ab8e62665e285c989"}, {name: "_tokenId", type: "uint256", value: "33"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[37,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "216922300802292655" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[18], \"50000000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "6826607", timeStamp: "1543955526", hash: "0x861b465f13f3dc3a8304405f66fa6d7f9b77c13343973fe0c7a663a39ae10076", nonce: "95", blockHash: "0x72d6bb92698e43b3d0e9d6ce9cf9872d5843976979cdcef67e265fca48efaaed", transactionIndex: "103", from: "0x569f8174e65f3263de89633ab8e62665e285c989", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "10000000000", isError: "1", txreceipt_status: "0", input: "0xb7f65439000000000000000000000000569f8174e65f3263de89633ab8e62665e285c989000000000000000000000000000000000000000000000002b5e3af16b1880000065cb7d09fcfb31400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "7325552", gasUsed: "111766", confirmations: "856662"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[18], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[18]}, {type: "uint256", name: "stake", value: "50000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x065cb7d09fcfb314000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[18], "50000000000000000000", "0x065cb7d09fcfb314000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1543955526 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[18], balance: "216922300802292655" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[18], balance: ( await web3.eth.getBalance( addressList[18], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[19], \"300000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826614", timeStamp: "1543955591", hash: "0x219a938ab667964f7bb385478a060100e63ea3d3d03ea0ea601ecc5984a107ae", nonce: "59", blockHash: "0x1d57a40d2d5f86f409c6651a9fe954aeda3d1fa1e78598078b95596e04ec01f5", transactionIndex: "133", from: "0x7d000f237d74313038fe7d0669a9b8c4f225727b", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "12000000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000007d000f237d74313038fe7d0669a9b8c4f225727b0000000000000000000000000000000000000000000000a2a15d09519be000000d0a813f069ffa1f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000fa0", contractAddress: "", cumulativeGasUsed: "5380816", gasUsed: "208655", confirmations: "856655"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[19], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[19]}, {type: "uint256", name: "stake", value: "3000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d0a813f069ffa1f000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "4000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[19], "3000000000000000000000", "0x0d0a813f069ffa1f000000000000000000000000000000000000000000000000", "4000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1543955591 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[39,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xfa61b34225f5e0ac7db0aa0bdd456a78746e4224c27e335082dd982841c241bd"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "34"}, {name: "geohash", type: "bytes32", value: "0x0d0a813f069ffa1f000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "4000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[39,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[39,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x7d000f237d74313038fe7d0669a9b8c4f225727b"}, {name: "_tokenId", type: "uint256", value: "34"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[39,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[19], balance: "91560323910787727531" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[19], balance: ( await web3.eth.getBalance( addressList[19], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: burn( \"31\" )", async function( ) {
		const txOriginal = {blockNumber: "6826634", timeStamp: "1543955763", hash: "0x5465dec7e79ae411bb36f0f3061153374762f0e9e92132e15f26e23b2318ca4d", nonce: "253", blockHash: "0xf8a55ba97610684198fcc139abe762fe1dcd585f9493532e5b80a5778c51fafb", transactionIndex: "24", from: "0x0a48296f7631708c95d2b74975bc4ab88ac1392a", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0x42966c68000000000000000000000000000000000000000000000000000000000000001f", contractAddress: "", cumulativeGasUsed: "7533296", gasUsed: "41068", confirmations: "856635"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[17], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "tokenID", value: "31"}], name: "burn", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "burn(uint256)" ]( "31", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1543955763 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[40,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0a48296f7631708c95d2b74975bc4ab88ac1392a"}, {name: "_to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_tokenId", type: "uint256", value: "31"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[40,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[17], balance: "21377384037249768" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[17], balance: ( await web3.eth.getBalance( addressList[17], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[20], \"5000000000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "6826637", timeStamp: "1543955791", hash: "0x26d17f7fa76ece165ffb892a02c786f6b1bc440962e3b74b2c19224509f82845", nonce: "33", blockHash: "0x106d7f21220782efffc104bc845b2908ae39bc017c3b24bb70ec21ddf8d5efa3", transactionIndex: "34", from: "0x3f264498ad6e8407a3704c17077852b208737b2a", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000003f264498ad6e8407a3704c17077852b208737b2a0000000000000000000000000000000000000000000000004563918244f400000c71e6152e408c4600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "2346121", gasUsed: "223655", confirmations: "856632"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[20]}, {type: "uint256", name: "stake", value: "5000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0c71e6152e408c46000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[20], "5000000000000000000", "0x0c71e6152e408c46000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1543955791 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[41,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xb24ec937d7a39d496a8287ef0c05fc6ab4fb6120dfeb8cc30a883ff3351251e4"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "35"}, {name: "geohash", type: "bytes32", value: "0x0c71e6152e408c46000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[41,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[41,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x3f264498ad6e8407a3704c17077852b208737b2a"}, {name: "_tokenId", type: "uint256", value: "35"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[41,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "7744854769548500" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[16], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826644", timeStamp: "1543955890", hash: "0xba233a61d5e1fe17f8d07db3d2ce5da8b0b1e3f1d184758f8ff3c05cd3675fc2", nonce: "314", blockHash: "0xa48dc1fb293a6527beea14496606be39eaf0662bc2e5c36d8ca492f7c4f5b9b9", transactionIndex: "85", from: "0x276718f63a8d0a25d49616097eb458eae6566890", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "5000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000276718f63a8d0a25d49616097eb458eae656689000000000000000000000000000000000000000000000003635c9adc5dea000000d04e0e70cb4b2dc0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002710", contractAddress: "", cumulativeGasUsed: "7676338", gasUsed: "193719", confirmations: "856625"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[16]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d04e0e70cb4b2dc000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "10000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[16], "1000000000000000000000", "0x0d04e0e70cb4b2dc000000000000000000000000000000000000000000000000", "10000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1543955890 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[42,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x63053bece5b9b0c26b3c3def3697a9cd46a77b6b3d3fc6f1670ecd19c4aec9b5"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "36"}, {name: "geohash", type: "bytes32", value: "0x0d04e0e70cb4b2dc000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "10000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[42,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[42,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x276718f63a8d0a25d49616097eb458eae6566890"}, {name: "_tokenId", type: "uint256", value: "36"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[42,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "39749226369484400" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[21], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826655", timeStamp: "1543955996", hash: "0x0b1c75e3467e97d075023b706cb2b98817afc6fe419d591469a4fd6df6904e5e", nonce: "156", blockHash: "0xa7edef4dde25a682fc29b4e2a9bd45dcd3fac95c31ffd25792992c29a31640b0", transactionIndex: "187", from: "0x896db7c827e6dc3635f659dae77cd04b8d6cd5e3", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000896db7c827e6dc3635f659dae77cd04b8d6cd5e30000000000000000000000000000000000000000000000056bc75e2d631000000d2ddb07367ae5c900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "7613717", gasUsed: "208719", confirmations: "856614"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[21], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[21]}, {type: "uint256", name: "stake", value: "100000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d2ddb07367ae5c9000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[21], "100000000000000000000", "0x0d2ddb07367ae5c9000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1543955996 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[43,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x9d306eb437726f3465635962181a0db02bf44673fa5d9800686e33db7fa3d97d"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "37"}, {name: "geohash", type: "bytes32", value: "0x0d2ddb07367ae5c9000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[43,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[43,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x896db7c827e6dc3635f659dae77cd04b8d6cd5e3"}, {name: "_tokenId", type: "uint256", value: "37"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[43,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[21], balance: "200929621118260543" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[21], balance: ( await web3.eth.getBalance( addressList[21], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[22], \"100000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826698", timeStamp: "1543956573", hash: "0x13fc38ba9e61a90098578c8935cc34d3577a2abdd9c8219cfde2588627615c1c", nonce: "84", blockHash: "0xdde12e3d3b071ba4f5fc1246e392c631655645f0ecae17750f74bc9b83054b9b", transactionIndex: "86", from: "0x542c10b76fa485e8be1e3b5f80f04392b3199eda", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "9000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000542c10b76fa485e8be1e3b5f80f04392b3199eda00000000000000000000000000000000000000000000003635c9adc5dea00000065ce9b77f8107ac00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000007d0", contractAddress: "", cumulativeGasUsed: "7193737", gasUsed: "223719", confirmations: "856571"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[22], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[22]}, {type: "uint256", name: "stake", value: "1000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x065ce9b77f8107ac000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "2000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[22], "1000000000000000000000", "0x065ce9b77f8107ac000000000000000000000000000000000000000000000000", "2000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1543956573 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[44,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x7c5fe72c3e4924e8d2b0988fce45e58bd7d882c218332f3f19a736aed752d630"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "38"}, {name: "geohash", type: "bytes32", value: "0x065ce9b77f8107ac000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "2000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[44,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[44,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x542c10b76fa485e8be1e3b5f80f04392b3199eda"}, {name: "_tokenId", type: "uint256", value: "38"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[44,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[22], balance: "6187447168786751236" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[22], balance: ( await web3.eth.getBalance( addressList[22], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[20], \"1000000000000000000\"... )", async function( ) {
		const txOriginal = {blockNumber: "6826739", timeStamp: "1543957115", hash: "0xbb12bb40cb60a48ffc0effb0f706f19c5abba7b7b3a5dda14d78372761cb5e9a", nonce: "34", blockHash: "0x28b10d98557055cc9ca5d556572cf939b8b8ff3b46949b92805658419484e5bf", transactionIndex: "75", from: "0x3f264498ad6e8407a3704c17077852b208737b2a", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7f654390000000000000000000000003f264498ad6e8407a3704c17077852b208737b2a0000000000000000000000000000000000000000000000000de0b6b3a76400000c71e648dd7f72c500000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003e8", contractAddress: "", cumulativeGasUsed: "6804616", gasUsed: "193655", confirmations: "856530"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[20]}, {type: "uint256", name: "stake", value: "1000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0c71e648dd7f72c5000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "1000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[20], "1000000000000000000", "0x0c71e648dd7f72c5000000000000000000000000000000000000000000000000", "1000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1543957115 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[45,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x202539f40a16780e1a1e1cadf87de013aadfbdfeaa6cd96b59b1c635e5f4bcc6"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "39"}, {name: "geohash", type: "bytes32", value: "0x0c71e648dd7f72c5000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "1000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[45,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[45,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x3f264498ad6e8407a3704c17077852b208737b2a"}, {name: "_tokenId", type: "uint256", value: "39"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[45,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "7744854769548500" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: burn( \"35\" )", async function( ) {
		const txOriginal = {blockNumber: "6826744", timeStamp: "1543957191", hash: "0x1f15d92ca02914d3f07d4ffb665b435554ac7cd7ffa36967b193d38f115fb3ec", nonce: "35", blockHash: "0xaa53a87cf5b4b8e9fcbd95ddec2951e9ac3f113b91e868f091839f9430e87a28", transactionIndex: "43", from: "0x3f264498ad6e8407a3704c17077852b208737b2a", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0x42966c680000000000000000000000000000000000000000000000000000000000000023", contractAddress: "", cumulativeGasUsed: "6403650", gasUsed: "67136", confirmations: "856525"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "tokenID", value: "35"}], name: "burn", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "burn(uint256)" ]( "35", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1543957191 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[46,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x3f264498ad6e8407a3704c17077852b208737b2a"}, {name: "_to", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_tokenId", type: "uint256", value: "35"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[46,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "7744854769548500" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[23], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826744", timeStamp: "1543957191", hash: "0xb1d1418b59ee8da4917cb871456ce626ca47d661e31ff11d893288f9aef2a2f6", nonce: "151", blockHash: "0xaa53a87cf5b4b8e9fcbd95ddec2951e9ac3f113b91e868f091839f9430e87a28", transactionIndex: "48", from: "0xa00e47c8fbe274ab3c24b08081d661c8536bc80c", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000a00e47c8fbe274ab3c24b08081d661c8536bc80c00000000000000000000000000000000000000000000006c6b935b8bbd400000065f22fd77c55d040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001b58", contractAddress: "", cumulativeGasUsed: "6933265", gasUsed: "223719", confirmations: "856525"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[23], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[23]}, {type: "uint256", name: "stake", value: "2000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x065f22fd77c55d04000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "7000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[23], "2000000000000000000000", "0x065f22fd77c55d04000000000000000000000000000000000000000000000000", "7000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1543957191 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[47,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0xf6ca28db8e2e561f86d079274601b9e45f5705016554250fdce4d949d2a9e003"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "40"}, {name: "geohash", type: "bytes32", value: "0x065f22fd77c55d04000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "7000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[47,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[47,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0xa00e47c8fbe274ab3c24b08081d661c8536bc80c"}, {name: "_tokenId", type: "uint256", value: "40"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[47,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[23], balance: "5219641297624746305" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[23], balance: ( await web3.eth.getBalance( addressList[23], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: mintSignal( addressList[16], \"200000000000000000000... )", async function( ) {
		const txOriginal = {blockNumber: "6826744", timeStamp: "1543957191", hash: "0x1384be9d35ff06d24956df6e6aed421b048aa5dfea898e2de7cc2fa5d48f399b", nonce: "315", blockHash: "0xaa53a87cf5b4b8e9fcbd95ddec2951e9ac3f113b91e868f091839f9430e87a28", transactionIndex: "52", from: "0x276718f63a8d0a25d49616097eb458eae6566890", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "6000000000", isError: "0", txreceipt_status: "1", input: "0xb7f65439000000000000000000000000276718f63a8d0a25d49616097eb458eae656689000000000000000000000000000000000000000000000006c6b935b8bbd4000000d04bcc114c637fe00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000061a8", contractAddress: "", cumulativeGasUsed: "7351766", gasUsed: "178719", confirmations: "856525"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[16], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "owner", value: addressList[16]}, {type: "uint256", name: "stake", value: "2000000000000000000000"}, {type: "bytes32", name: "geohash", value: "0x0d04bcc114c637fe000000000000000000000000000000000000000000000000"}, {type: "uint256", name: "radius", value: "25000"}], name: "mintSignal", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "mintSignal(address,uint256,bytes32,uint256)" ]( addressList[16], "2000000000000000000000", "0x0d04bcc114c637fe000000000000000000000000000000000000000000000000", "25000", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1543957191 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "cst", type: "bytes32"}, {indexed: true, name: "nftAddress", type: "address"}, {indexed: false, name: "tokenID", type: "uint256"}, {indexed: false, name: "geohash", type: "bytes32"}, {indexed: false, name: "radius", type: "uint256"}], name: "TrackedToken", type: "event"} ;
		console.error( "eventCallOriginal[48,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TrackedToken", events: [{name: "cst", type: "bytes32", value: "0x46661f394ebf00996a2a869901f6f9551a83abf6ced95978ddf04ea1df791f8f"}, {name: "nftAddress", type: "address", value: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}, {name: "tokenID", type: "uint256", value: "41"}, {name: "geohash", type: "bytes32", value: "0x0d04bcc114c637fe000000000000000000000000000000000000000000000000"}, {name: "radius", type: "uint256", value: "25000"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[48,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "_from", type: "address"}, {indexed: true, name: "_to", type: "address"}, {indexed: true, name: "_tokenId", type: "uint256"}], name: "Transfer", type: "event"} ;
		console.error( "eventCallOriginal[48,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "Transfer", events: [{name: "_from", type: "address", value: "0x0000000000000000000000000000000000000000"}, {name: "_to", type: "address", value: "0x276718f63a8d0a25d49616097eb458eae6566890"}, {name: "_tokenId", type: "uint256", value: "41"}], address: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2"}] ;
		console.error( "eventResultOriginal[48,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[16], balance: "39749226369484400" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[16], balance: ( await web3.eth.getBalance( addressList[16], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: burn( \"35\" )", async function( ) {
		const txOriginal = {blockNumber: "6826746", timeStamp: "1543957203", hash: "0x80cbb412366f09463f27b1f0fe82fc1042313bbbde732bc12a514cfc194ccd4e", nonce: "36", blockHash: "0x8e8f080fbe223687572e659e15d8f2af341646f533a486417b8c7545f04fb61c", transactionIndex: "59", from: "0x3f264498ad6e8407a3704c17077852b208737b2a", to: "0x36f16a0d35b866cdd0f3c3fa39e2ba8f48b099d2", value: "0", gas: "500000", gasPrice: "7000000000", isError: "1", txreceipt_status: "0", input: "0x42966c680000000000000000000000000000000000000000000000000000000000000023", contractAddress: "", cumulativeGasUsed: "2356192", gasUsed: "22317", confirmations: "856523"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[20], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "uint256", name: "tokenID", value: "35"}], name: "burn", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "burn(uint256)" ]( "35", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1543957203 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[20], balance: "7744854769548500" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[20], balance: ( await web3.eth.getBalance( addressList[20], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
