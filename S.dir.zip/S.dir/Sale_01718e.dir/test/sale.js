const Sale = artifacts.require( "./Sale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Sale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0xf2Fbb2939981594e25d93e6226231FcC1b01718e", "0x434dC9EF22B28CB1E9669D0A7ABdDABe8682e3c0", "0xF327f9883C6771E40c8F9B24817564D2c7feD8B8", "0x42338FF7E4C3B999Eb69B521323657017cE08727", "0x09AE9886C971279E771030aD5Da37f227fb1e7f9", "0x9e13b3E84eE0E0aea5d6F93DC05Ee7B5113d522F", "0xaC01F01f51F0bdd012C1838Bd5ceF330E6c7FFCa", "0x07b128EB671D2F3D98ba809cCda6F801b5b238A5", "0xB8e668958b6151Db3ef13b97866cc4359DEdFee6", "0xd98cb2B207eb024381C1c40315044c67782E555f", "0x875f6DC5c6e671a99b6B75FfC8be749fE024A8A9", "0x5A56F4cdBE88D529d68340F6B822C3fba4a17f7C", "0x61618B6C994E8Aa340DDcC15af7c8E743f194eB9", "0x37AF3A72Ccf6aB71505e4B583650A5e8C5f5e710", "0xb37FdB09a5793ecDdc1EFc48014d6D4F55096E4B", "0x23b892E361Db5B7a49C2aCD1A382Ef48b5ED0969", "0xcE2B966A246D643179FABeDDDDa03209bBFef807", "0x47a6E95495D959f556589d6c10665d8e8C6b37B9", "0x646beA631C753307B398513Ff57A4cf269465fA6", "0x943fba8542d38556331B5f53239123Dc845f29F6", "0x5a22CE293899E3FeE176Bf8816B5bE7Ac5327945", "0x49D4533Ab400f3E8E60C01A94114289e0827503C", "0xE9eBEE76A902b6536C0bddf79Ac4c4343e5bDBfb", "0xd161e863F9C3e099020abb1B7092795dF6c72950", "0xDc5796A839736017EC3d083aB053B03f51a7455F", "0x84256D81C1a191e6952C781f6A204626c6912B83", "0x3E5548dDe6D74cAA89313057b7d286F46cc309f4", "0x5f21639f20F586662A3EB24fE971B5C2a35BD012", "0x50dF85aE6cC9557D87f06C6BdD69FF8b7B19fc16", "0x8628D73d3F950ABDE99739EF34B6CfA10394f579", "0x5Acca1d9874bCC2B50f63A7a4c48e9506485e1Aa", "0x00a96e78D4900Cb5F8C412C1437B15aaf81f6733", "0x58CBe3eDF182e28Ba6C7453b33503BC886ADf35c", "0x6507d08CDa616F2F253E6AAfD6509408Cb89818D", "0xf9fA4C86800Ab01C15884b4c964ffefDdB6b0C89", "0x9c19A027141d4B43542252bfe44d9c600635331b", "0x00d6b5603F711f5B2d33DeB365613608AF40E4C6", "0xD07780f54E6b52A24d2ef9f17125ADf1917B9a2b", "0x627Bd5cD4c8125541b27C9f38f4d0224ACdA3ACB", "0xe4BAC8191754B79f955D06eca8d95FaEc6b57E24", "0x03097A46FfB4D9F5291E1975a76f7bB9926B2a1f", "0xF1bf0F88a43B64ed1776e71295e78baeE7DaE994", "0x2dA86FD3C3f2CC1cc8c1339eDD9bd9bDe1f3822D", "0x1E7462b92672CE48D76a067972BCf32F12626BF5", "0xc3dc221bAEE69184f68ed2AC68815c12cB15Df25", "0x4f58A944580788C502b2d9BE382AB96358A1C063", "0x5fd474f8AbDB347eC54B15cbcA40b56dD2F2aEFC", "0x624aA1b650F239Cd7E2D99EB642036c706587F9A", "0x188A67deC970DdDc53d45504576F359960d1534A", "0xCB3833A6a1dab47376c94Ee9Ca15BDeD513cA883", "0xD822346C13e251c80aC5cC5aEb1626f02BA6B64C", "0x02B322ECFD80Aa1dE6536Be93a496820a84711eD", "0x9E1b202B129384A331B6C694b584c5Be02cb9fC0", "0x8d1CB90FAe9e824038856c9b098d452f37E396f6", "0xA3ac9714B7bD582cF80753cD171335f9b0517574", "0xa62444D723e1C6F7f666a013606453DC62D9c7b8", "0xf18055387961a61eEff5A3fCf9d510B56a94C6Da", "0xfF8A412B3Ab681308f722f9Cb7Ab23CE32e99846", "0xf2383106F3bEd64a4C3FF24FDea44563a613dA84", "0xD2E4d935F5b1495A4afBAf51caC00d769AD21aCe", "0x7dAfD53AEE8982aB1D767830c2fe50f62E3a98E6", "0x3092D6939DA0BfD3b3044Ba67eFC580f82970dD4", "0x0723040085de7B32BB91DbA32Abe01653Bc63eCf", "0xD79Ee3be5E0154Cd7540A55cc4f7E44D78a38B6A", "0xDD5BaB9dffB66733330A015B41C5627fc72103Eb", "0x66b098C04C9d11f4150E79c89e611377F6F6483C", "0xD2b09D0266689b5baa23C01a377eC71C9646f540", "0x930c4667464Fc346B4065B3FFdE8d4a8533c0Ed3", "0xF3D10939063783F11E69760336B64d8da380a605", "0x701E66003EDBe78c0A16c3B24de0A8b68048fB38", "0x94969672704Fbe6f19eBba746E3f119E9D259545", "0x53bEDb22d57D40F748A6Cb575B221b5F952956A3", "0xf4fC45F121dDea36725eE28F7d865F07f44f7dF9", "0xAa6993FbDAb3E4549a0B8B974D860d0FF18468F9", "0x4f276e1405941F5839619215465EfCb02F39997D", "0x26E8B8bc4053638fcED7c3bD60fD893Dca1bD7DA", "0x1e59a036e19f5c430fd9A46477FA5538e2Cb63BD", "0x88c2EDEE1e1135244F537bb67051081873526Dc6", "0x4D280Adb927F333D14F7Ef4f8F901dF870419610", "0xbd848dE0c9b56517165d7e96DC77083361Bf3cb8", "0x427dD85f9667B0C72801E12b949557AD718d7CaC", "0x76cDD2e593d0c95EC088C3cb594b949Ee6AA1ef8", "0xD2Bf9B72cA82605F782696e5981c9eA5de128426", "0xc0D3a8d939d8653F0Fd8fE7a0646DD3884293466", "0xc3AE6F90D375a82b2A3F9FE3679331141DFEB6a8", "0x046D05c025Aa76452bafc566Ff69eF65C06973Df", "0x2D860Ff6e483ad750F853F4795cCB3CdF3D25D06", "0x940B801df38718254869c33Bc9Db9462ee76DA9D", "0x58396b6D39fb1231991FEc52c2e30B991Ad36992", "0xb11E3c2B81bf2D5856Dd110c48a19dcba58f68AB", "0xa0dB493C83b211F7BF8C83586F8F3a4cFa978A18", "0x14771461655dD3A887144ed81add8D4298cB1361", "0xea2A3ee765f1A826Dc5fC854aEA1766F72D40905", "0xF1066b9B515F21c02c70FEA24F84e48BFd8976D9", "0x1dE00cc156F53Ac088F39CcBE58979Aca7620ad0", "0xEd1316a78223565Ff499Aca062E0d16F4f96f2aC", "0x014cC0D352a8a74d843BbE1a53c21B734Aa2Da7e", "0xf4D29947f022437f800eDA0f9FaeB512eD5e72B5", "0x4945e6D54134C5E5f1e70e2FB0E5e6c840754C71", "0x6AF2c786d6588eb4770897c4E5C465eF37781AfC", "0x169f656cca16FAe961F024dD184f89290707517e", "0x60d77EF89E7267c667D7CF27Bd6cd56D7212ebA0", "0xC923f91B082b7A0deC07210ccF94D700E88B8E16", "0xc6110aD7a29E537178D790595CfB1e7A45AFDD44", "0x6C0a7BF079186A8A59e59C99a622c9fEeF5b6888", "0x3Fd51473217cF4a556620523d9Cc5E23E85E7C5F", "0x2Abc27D69C175bfd9FD2ac0391c2aDeB4479C989", "0x4e61Ea5FA18271a2Cd15C4Fff53300196FA6A195", "0x00069d5e9C2F9635346c5A0B90967ca98E47C19c", "0x5599c0eEBB6C56D17e46F016A98263CF8a6Ae570", "0x351a7DFfbE4b4EBA06a0b583C970c4f83e89835C", "0x4bF9457A22C07b5892551f456B807590Ff2a5dad", "0xc68D9e6d2fD556BF697afB3572cF7f34eC525fAc", "0xc0741cB56A86DDd99e2a5Fd0053c380fc1dAF435", "0xC91143076b9F74730Ca3167eeF565524dA268474", "0xD3438e11D5de4518dCef9A3C455fCB75DcC600Cf", "0xa344987A9BD5207dF824296016cC50a8BE11eAcd", "0x73691ab45f827E88f4dDdf055698D857AAE9ED41"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "endBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "whitelistRegistrants", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "MAX_PRIVATE", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "DECIMALS", outputs: [{name: "", type: "uint8"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "publicSale", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "freezeBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "startBlock", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "whitelistAdmin", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "uint256"}], name: "disbursements", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "setupCompleteFlag", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "privateAllocated", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "TOTAL_SUPPLY", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "", type: "address"}], name: "whitelistRegistrantsFlag", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "NAME", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "emergencyFlag", outputs: [{name: "", type: "bool"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "price_in_wei", outputs: [{name: "", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "SYMBOL", outputs: [{name: "", type: "string"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "disbursement", type: "address"}, {indexed: false, name: "beneficiaryTokens", type: "uint256"}], name: "TransferredTimelockedTokens", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "numTokensLocked", type: "uint256"}, {indexed: false, name: "disburser", type: "address"}], name: "LockedUnsoldTokens", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["TransferredTimelockedTokens(address,address,uint256)", "PurchasedTokens(address,uint256)", "LockedUnsoldTokens(uint256,address)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x659bd17426525d271e76e8b662badf9e68de74efbdb62927843499ecec17c924", "0xf9c447a9cff6748e98623cddf46579164dc4c2af6253de5278893e8659277364", "0x178394bd3d3f3a67e10feb6c72c680672592e37c14e1f799ae54fe869cec1a80"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 4494253 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 4494348 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_owner", value: 3}, {type: "uint256", name: "_freezeBlock", value: "4494550"}, {type: "uint256", name: "_startBlock", value: "4494650"}, {type: "uint256", name: "_endBlock", value: "4688045"}, {type: "address", name: "_whitelistAdmin", value: 4}], name: "Sale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "endBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "endBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whitelistRegistrants", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelistRegistrants(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "MAX_PRIVATE", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "MAX_PRIVATE()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "DECIMALS", outputs: [{name: "", type: "uint8"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "DECIMALS()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "publicSale", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "publicSale()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "freezeBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "freezeBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "whitelistAdmin", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelistAdmin()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "disbursements", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "disbursements(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "wallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "setupCompleteFlag", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",10] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "setupCompleteFlag()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",10] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",11] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",11] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "privateAllocated", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",12] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "privateAllocated()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",12] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "TOTAL_SUPPLY", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",13] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "TOTAL_SUPPLY()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",13] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "whitelistRegistrantsFlag", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",14] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "whitelistRegistrantsFlag(address)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",14] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "NAME", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",15] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "NAME()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",15] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "emergencyFlag", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",16] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "emergencyFlag()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",16] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "price_in_wei", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",17] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "price_in_wei()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",17] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "SYMBOL", outputs: [{name: "", type: "string"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",18] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "SYMBOL()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",18] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",19] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",19] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Sale", function( accounts ) {

	it( "TEST: Sale( addressList[3], \"4494550\", \"4494650\"... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "4494253", timeStamp: "1509874026", hash: "0x8bd30b1cc4081e09e737c344487528dd9ef2d02f804eac509b3c3cc2a86b0b7b", nonce: "61", blockHash: "0x88ab8ba2049e7e305d5102fa7f8a7eee6d8473b19dee4e18f7ebe7cb312105bf", transactionIndex: "2", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: 0, value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0xd5e21567000000000000000000000000434dc9ef22b28cb1e9669d0a7abddabe8682e3c000000000000000000000000000000000000000000000000000000000004494d6000000000000000000000000000000000000000000000000000000000044953a00000000000000000000000000000000000000000000000000000000004788ad000000000000000000000000f327f9883c6771e40c8f9b24817564d2c7fed8b8", contractAddress: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", cumulativeGasUsed: "5957547", gasUsed: "5915547", confirmations: "3244335"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_owner", value: addressList[3]}, {type: "uint256", name: "_freezeBlock", value: "4494550"}, {type: "uint256", name: "_startBlock", value: "4494650"}, {type: "uint256", name: "_endBlock", value: "4688045"}, {type: "address", name: "_whitelistAdmin", value: addressList[4]}], name: "Sale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Sale.new( addressList[3], "4494550", "4494650", "4688045", addressList[4], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1509874026 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Sale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: configureWallet( addressList[5] )", async function( ) {
		const txOriginal = {blockNumber: "4494272", timeStamp: "1509874307", hash: "0xb60ccd66836d8ef586b941e6fff2934e80ee69327fd71f5faf8979b01de2d37a", nonce: "64", blockHash: "0xfbf92e4942d77206c8f24494f1dc80d092d817e04959e9c27dba440065129a8f", transactionIndex: "2", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0xcb1be21a00000000000000000000000042338ff7e4c3b999eb69b521323657017ce08727", contractAddress: "", cumulativeGasUsed: "158292", gasUsed: "44050", confirmations: "3244316"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_wallet", value: addressList[5]}], name: "configureWallet", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "configureWallet(address)" ]( addressList[5], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1509874307 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[6]], [\"150000000000000000\... )", async function( ) {
		const txOriginal = {blockNumber: "4494275", timeStamp: "1509874333", hash: "0x7c90d70796bd72bafbfc58f922feb360a692a203bc5d0c98ad7f02134149f757", nonce: "65", blockHash: "0x217d217130bd1759155e874d38ceedfc11506d0dedf7316ab866fc6266fd9c36", transactionIndex: "1", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000009ae9886c971279e771030ad5da37f227fb1e7f900000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000214e8348c4f0000", contractAddress: "", cumulativeGasUsed: "102713", gasUsed: "81713", confirmations: "3244313"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[6]]}, {type: "uint256[]", name: "_amounts", value: ["150000000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[6]], ["150000000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1509874333 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[2,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x09ae9886c971279e771030ad5da37f227fb1e7f9"}, {name: "amount", type: "uint256", value: "150000000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[2,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: distributeTimelockedTokens( [addressList[7],addressList[8],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "4494277", timeStamp: "1509874394", hash: "0xa0dbc53cfe4ef30a2cd12a6544f925b61d741403a46f7c9a2d632e401e365b31", nonce: "66", blockHash: "0x5003d37a2e5278e852f47ce130689d05fe3e5c08e54a1c345c7a6da975f3a439", transactionIndex: "7", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x555c47580000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000026000000000000000000000000000000000000000000000000000000000000000040000000000000000000000009e13b3e84ee0e0aea5d6f93dc05ee7b5113d522f000000000000000000000000ac01f01f51f0bdd012c1838bd5cef330e6c7ffca00000000000000000000000007b128eb671d2f3d98ba809ccda6f801b5b238a5000000000000000000000000b8e668958b6151db3ef13b97866cc4359dedfee60000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000016345785d8a00000000000000000000000000000000000000000000000000000429d069189e00000000000000000000000000000000000000000000000000000024d775c652200000000000000000000000000000000000000000000000000000187152d40e00000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2981609", gasUsed: "2755428", confirmations: "3244311"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_beneficiaries", value: [addressList[7],addressList[8],addressList[9],addressList[10]]}, {type: "uint256[]", name: "_beneficiariesTokens", value: ["100000000000000000","300000000000000000","10370000000000000","6880000000000000"]}, {type: "uint256[]", name: "_timelockStarts", value: ["1512507600","1512507600","1512507600","1512507600"]}, {type: "uint256[]", name: "_periods", value: ["1","1","1","1"]}], name: "distributeTimelockedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributeTimelockedTokens(address[],uint256[],uint256[],uint256[])" ]( [addressList[7],addressList[8],addressList[9],addressList[10]], ["100000000000000000","300000000000000000","10370000000000000","6880000000000000"], ["1512507600","1512507600","1512507600","1512507600"], ["1","1","1","1"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1509874394 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "disbursement", type: "address"}, {indexed: false, name: "beneficiaryTokens", type: "uint256"}], name: "TransferredTimelockedTokens", type: "event"} ;
		console.error( "eventCallOriginal[3,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x9e13b3e84ee0e0aea5d6f93dc05ee7b5113d522f"}, {name: "disbursement", type: "address", value: "0xb722200fb2e90dd5780b240266f971eded40c000"}, {name: "beneficiaryTokens", type: "uint256", value: "100000000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0xac01f01f51f0bdd012c1838bd5cef330e6c7ffca"}, {name: "disbursement", type: "address", value: "0x273f5db72b72059c043cad022c446232f3d33085"}, {name: "beneficiaryTokens", type: "uint256", value: "300000000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x07b128eb671d2f3d98ba809ccda6f801b5b238a5"}, {name: "disbursement", type: "address", value: "0x0ada0f630f37373398b699d705fd93ad04398916"}, {name: "beneficiaryTokens", type: "uint256", value: "10370000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0xb8e668958b6151db3ef13b97866cc4359dedfee6"}, {name: "disbursement", type: "address", value: "0x1b796d6acd4b73794d5e080fb4b717b367e124d2"}, {name: "beneficiaryTokens", type: "uint256", value: "6880000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[3,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: distributeTimelockedTokens( [addressList[11],addressList[12],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494279", timeStamp: "1509874418", hash: "0x1fc0fba20c12342b762b65938e8b7b1dea758c08b2d8eeba09192437e5d08ba2", nonce: "67", blockHash: "0xdb7495a7766a5d4da36443dd3fd271dd310c58fbe2edf58561c51c90083005af", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x555c47580000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000d98cb2b207eb024381c1c40315044c67782e555f000000000000000000000000875f6dc5c6e671a99b6b75ffc8be749fe024a8a90000000000000000000000005a56f4cdbe88d529d68340f6b822c3fba4a17f7c00000000000000000000000061618b6c994e8aa340ddcc15af7c8e743f194eb900000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000cca2e513100000000000000000000000000000000000000000000000000000071afd498d000000000000000000000000000000000000000000000000000000005af3107a400000000000000000000000000000000000000000000000000000005af3107a40000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "2740236", gasUsed: "2740236", confirmations: "3244309"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_beneficiaries", value: [addressList[11],addressList[12],addressList[13],addressList[14]]}, {type: "uint256[]", name: "_beneficiariesTokens", value: ["225000000000000","2000000000000000","100000000000000","100000000000000"]}, {type: "uint256[]", name: "_timelockStarts", value: ["1512507600","1512507600","1512507600","1512507600"]}, {type: "uint256[]", name: "_periods", value: ["1","1","1","1"]}], name: "distributeTimelockedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributeTimelockedTokens(address[],uint256[],uint256[],uint256[])" ]( [addressList[11],addressList[12],addressList[13],addressList[14]], ["225000000000000","2000000000000000","100000000000000","100000000000000"], ["1512507600","1512507600","1512507600","1512507600"], ["1","1","1","1"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1509874418 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "disbursement", type: "address"}, {indexed: false, name: "beneficiaryTokens", type: "uint256"}], name: "TransferredTimelockedTokens", type: "event"} ;
		console.error( "eventCallOriginal[4,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0xd98cb2b207eb024381c1c40315044c67782e555f"}, {name: "disbursement", type: "address", value: "0xe0de5657fc9288051408f96180770475bdc4dc92"}, {name: "beneficiaryTokens", type: "uint256", value: "225000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x875f6dc5c6e671a99b6b75ffc8be749fe024a8a9"}, {name: "disbursement", type: "address", value: "0x9d071786e2dda3b15fedf4719c3a0d3b8144a331"}, {name: "beneficiaryTokens", type: "uint256", value: "2000000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x5a56f4cdbe88d529d68340f6b822c3fba4a17f7c"}, {name: "disbursement", type: "address", value: "0x64a1b1af43e18ca3ca5afb391728221f989664e9"}, {name: "beneficiaryTokens", type: "uint256", value: "100000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x61618b6c994e8aa340ddcc15af7c8e743f194eb9"}, {name: "disbursement", type: "address", value: "0x8dc5a51347847d1d1961d3c75b00f2faa3d3282d"}, {name: "beneficiaryTokens", type: "uint256", value: "100000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[4,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: distributeTimelockedTokens( [addressList[15],addressList[9],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4494280", timeStamp: "1509874438", hash: "0xf35f78f11c4b4e9696a9b14da2ddcce42fa8f3b62235535c00a41c6ce3cb199e", nonce: "68", blockHash: "0x307515888a700d76670a4cf77f58de1cc82925c85a6b674bdc4b6051072aeeeb", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x555c47580000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000000400000000000000000000000037af3a72ccf6ab71505e4b583650a5e8c5f5e71000000000000000000000000007b128eb671d2f3d98ba809ccda6f801b5b238a5000000000000000000000000b8e668958b6151db3ef13b97866cc4359dedfee6000000000000000000000000d98cb2b207eb024381c1c40315044c67782e555f000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000012795f58d5000000000000000000000000000000000000000000000000000006e866152f66000000000000000000000000000000000000000000000000000004953f87c2a0000000000000000000000000000000000000000000000000000000265e8af3930000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e00", contractAddress: "", cumulativeGasUsed: "2740620", gasUsed: "2740620", confirmations: "3244308"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_beneficiaries", value: [addressList[15],addressList[9],addressList[10],addressList[11]]}, {type: "uint256[]", name: "_beneficiariesTokens", value: ["325000000000000","31110000000000000","20640000000000000","675000000000000"]}, {type: "uint256[]", name: "_timelockStarts", value: ["1512507600","1512507600","1512507600","1512507600"]}, {type: "uint256[]", name: "_periods", value: ["1","15552000","15552000","15552000"]}], name: "distributeTimelockedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributeTimelockedTokens(address[],uint256[],uint256[],uint256[])" ]( [addressList[15],addressList[9],addressList[10],addressList[11]], ["325000000000000","31110000000000000","20640000000000000","675000000000000"], ["1512507600","1512507600","1512507600","1512507600"], ["1","15552000","15552000","15552000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1509874438 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "disbursement", type: "address"}, {indexed: false, name: "beneficiaryTokens", type: "uint256"}], name: "TransferredTimelockedTokens", type: "event"} ;
		console.error( "eventCallOriginal[5,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x37af3a72ccf6ab71505e4b583650a5e8c5f5e710"}, {name: "disbursement", type: "address", value: "0xae454991eaa240310446937d73bc00d75bd45700"}, {name: "beneficiaryTokens", type: "uint256", value: "325000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x07b128eb671d2f3d98ba809ccda6f801b5b238a5"}, {name: "disbursement", type: "address", value: "0xc1edf78990a2a1d11a88db4b3e56d6ec20d88d09"}, {name: "beneficiaryTokens", type: "uint256", value: "31110000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0xb8e668958b6151db3ef13b97866cc4359dedfee6"}, {name: "disbursement", type: "address", value: "0xf6897d030818605ab7fcdb8fb06b82c3604759b5"}, {name: "beneficiaryTokens", type: "uint256", value: "20640000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0xd98cb2b207eb024381c1c40315044c67782e555f"}, {name: "disbursement", type: "address", value: "0x28994f25cfcb745bf5dc79cc105d2f2b2d173e9b"}, {name: "beneficiaryTokens", type: "uint256", value: "675000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[5,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: distributeTimelockedTokens( [addressList[12],addressList[13],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494282", timeStamp: "1509874459", hash: "0xa85ac3b8aab9200228c0ee622c57ac957ba7d25d7151548a44b6ae58e1d76e2d", nonce: "69", blockHash: "0xd41836fd1e1ad42a4db3bd21fda393194c41aebb8ca7e5d33d88e6bdcb513c23", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x555c47580000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000875f6dc5c6e671a99b6b75ffc8be749fe024a8a90000000000000000000000005a56f4cdbe88d529d68340f6b822c3fba4a17f7c00000000000000000000000061618b6c994e8aa340ddcc15af7c8e743f194eb900000000000000000000000037af3a72ccf6ab71505e4b583650a5e8c5f5e7100000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000001550f7dca70000000000000000000000000000000000000000000000000000000110d9316ec000000000000000000000000000000000000000000000000000000110d9316ec000000000000000000000000000000000000000000000000000000376c1e0a7f0000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005a2708d000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e00", contractAddress: "", cumulativeGasUsed: "2740684", gasUsed: "2740684", confirmations: "3244306"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_beneficiaries", value: [addressList[12],addressList[13],addressList[14],addressList[15]]}, {type: "uint256[]", name: "_beneficiariesTokens", value: ["6000000000000000","300000000000000","300000000000000","975000000000000"]}, {type: "uint256[]", name: "_timelockStarts", value: ["1512507600","1512507600","1512507600","1512507600"]}, {type: "uint256[]", name: "_periods", value: ["15552000","15552000","15552000","15552000"]}], name: "distributeTimelockedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributeTimelockedTokens(address[],uint256[],uint256[],uint256[])" ]( [addressList[12],addressList[13],addressList[14],addressList[15]], ["6000000000000000","300000000000000","300000000000000","975000000000000"], ["1512507600","1512507600","1512507600","1512507600"], ["15552000","15552000","15552000","15552000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1509874459 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "disbursement", type: "address"}, {indexed: false, name: "beneficiaryTokens", type: "uint256"}], name: "TransferredTimelockedTokens", type: "event"} ;
		console.error( "eventCallOriginal[6,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x875f6dc5c6e671a99b6b75ffc8be749fe024a8a9"}, {name: "disbursement", type: "address", value: "0xa04782fbbb2350a3aa3f06d3a563f7cf50b63307"}, {name: "beneficiaryTokens", type: "uint256", value: "6000000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x5a56f4cdbe88d529d68340f6b822c3fba4a17f7c"}, {name: "disbursement", type: "address", value: "0xedf05c0d10ce796fe82ad3a7772b60d9ee0ff75b"}, {name: "beneficiaryTokens", type: "uint256", value: "300000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x61618b6c994e8aa340ddcc15af7c8e743f194eb9"}, {name: "disbursement", type: "address", value: "0x5d3354e6fee7a9be49e667df691aaae450d904a4"}, {name: "beneficiaryTokens", type: "uint256", value: "300000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x37af3a72ccf6ab71505e4b583650a5e8c5f5e710"}, {name: "disbursement", type: "address", value: "0xbeadf4f0d23de72e3c87a9a36b3170584cfbe2cd"}, {name: "beneficiaryTokens", type: "uint256", value: "975000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[6,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: distributeTimelockedTokens( [addressList[9],addressList[10],addressL... )", async function( ) {
		const txOriginal = {blockNumber: "4494284", timeStamp: "1509874497", hash: "0xc73723ac0db0c69359595bb54bc776686783ff19554c00b0be9d5bde987e6141", nonce: "70", blockHash: "0x9d44105e22528a68bb7fcc2302802c79654d88d74fa32c2f402a96fd62c3ff9f", transactionIndex: "2", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x555c47580000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001c00000000000000000000000000000000000000000000000000000000000000260000000000000000000000000000000000000000000000000000000000000000400000000000000000000000007b128eb671d2f3d98ba809ccda6f801b5b238a5000000000000000000000000b8e668958b6151db3ef13b97866cc4359dedfee6000000000000000000000000d98cb2b207eb024381c1c40315044c67782e555f000000000000000000000000875f6dc5c6e671a99b6b75ffc8be749fe024a8a90000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000006e866152f66000000000000000000000000000000000000000000000000000004953f87c2a0000000000000000000000000000000000000000000000000000000265e8af393000000000000000000000000000000000000000000000000000001550f7dca700000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000005a2708d0000000000000000000000000000000000000000000000000000000005b1456d0000000000000000000000000000000000000000000000000000000005b1456d0000000000000000000000000000000000000000000000000000000005b1456d000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e00", contractAddress: "", cumulativeGasUsed: "2813029", gasUsed: "2740620", confirmations: "3244304"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_beneficiaries", value: [addressList[9],addressList[10],addressList[11],addressList[12]]}, {type: "uint256[]", name: "_beneficiariesTokens", value: ["31110000000000000","20640000000000000","675000000000000","6000000000000000"]}, {type: "uint256[]", name: "_timelockStarts", value: ["1512507600","1528059600","1528059600","1528059600"]}, {type: "uint256[]", name: "_periods", value: ["15552000","15552000","15552000","15552000"]}], name: "distributeTimelockedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributeTimelockedTokens(address[],uint256[],uint256[],uint256[])" ]( [addressList[9],addressList[10],addressList[11],addressList[12]], ["31110000000000000","20640000000000000","675000000000000","6000000000000000"], ["1512507600","1528059600","1528059600","1528059600"], ["15552000","15552000","15552000","15552000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1509874497 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "disbursement", type: "address"}, {indexed: false, name: "beneficiaryTokens", type: "uint256"}], name: "TransferredTimelockedTokens", type: "event"} ;
		console.error( "eventCallOriginal[7,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x07b128eb671d2f3d98ba809ccda6f801b5b238a5"}, {name: "disbursement", type: "address", value: "0xa8c23bf2b1980c55334293a26627b5dd3a4a607a"}, {name: "beneficiaryTokens", type: "uint256", value: "31110000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0xb8e668958b6151db3ef13b97866cc4359dedfee6"}, {name: "disbursement", type: "address", value: "0xa84f4b7b74fb030d1f9566d4daf332fbeac58f42"}, {name: "beneficiaryTokens", type: "uint256", value: "20640000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0xd98cb2b207eb024381c1c40315044c67782e555f"}, {name: "disbursement", type: "address", value: "0x028758359f424f4762a615d6dcc445b884c444f0"}, {name: "beneficiaryTokens", type: "uint256", value: "675000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x875f6dc5c6e671a99b6b75ffc8be749fe024a8a9"}, {name: "disbursement", type: "address", value: "0x21c96d226952cff669584eb07a7cb197cb876a4f"}, {name: "beneficiaryTokens", type: "uint256", value: "6000000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[7,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: distributeTimelockedTokens( [addressList[13],addressList[14],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494285", timeStamp: "1509874522", hash: "0xfd09fd5cca9d50c4bd7144d2813e9da1db0fd06795ab3411613815801cc15b21", nonce: "71", blockHash: "0xbdcb653f0ed18a2fef54ba9538e7e5ccae427c12dc0ea60ee101d1967e3ed174", transactionIndex: "5", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x555c47580000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001c0000000000000000000000000000000000000000000000000000000000000026000000000000000000000000000000000000000000000000000000000000000040000000000000000000000005a56f4cdbe88d529d68340f6b822c3fba4a17f7c00000000000000000000000061618b6c994e8aa340ddcc15af7c8e743f194eb900000000000000000000000037af3a72ccf6ab71505e4b583650a5e8c5f5e71000000000000000000000000007b128eb671d2f3d98ba809ccda6f801b5b238a50000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000110d9316ec000000000000000000000000000000000000000000000000000000110d9316ec000000000000000000000000000000000000000000000000000000376c1e0a7f000000000000000000000000000000000000000000000000000006e866152f660000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000005b1456d0000000000000000000000000000000000000000000000000000000005b1456d0000000000000000000000000000000000000000000000000000000005b1456d0000000000000000000000000000000000000000000000000000000005c01a4d000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e00", contractAddress: "", cumulativeGasUsed: "2920355", gasUsed: "2740748", confirmations: "3244303"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_beneficiaries", value: [addressList[13],addressList[14],addressList[15],addressList[9]]}, {type: "uint256[]", name: "_beneficiariesTokens", value: ["300000000000000","300000000000000","975000000000000","31110000000000000"]}, {type: "uint256[]", name: "_timelockStarts", value: ["1528059600","1528059600","1528059600","1543611600"]}, {type: "uint256[]", name: "_periods", value: ["15552000","15552000","15552000","15552000"]}], name: "distributeTimelockedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributeTimelockedTokens(address[],uint256[],uint256[],uint256[])" ]( [addressList[13],addressList[14],addressList[15],addressList[9]], ["300000000000000","300000000000000","975000000000000","31110000000000000"], ["1528059600","1528059600","1528059600","1543611600"], ["15552000","15552000","15552000","15552000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1509874522 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "disbursement", type: "address"}, {indexed: false, name: "beneficiaryTokens", type: "uint256"}], name: "TransferredTimelockedTokens", type: "event"} ;
		console.error( "eventCallOriginal[8,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x5a56f4cdbe88d529d68340f6b822c3fba4a17f7c"}, {name: "disbursement", type: "address", value: "0xa78edcdea071bd6b1da701622e340880533f6f55"}, {name: "beneficiaryTokens", type: "uint256", value: "300000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x61618b6c994e8aa340ddcc15af7c8e743f194eb9"}, {name: "disbursement", type: "address", value: "0x20879343cc1a89d759afbd47683a33f9b77dc92f"}, {name: "beneficiaryTokens", type: "uint256", value: "300000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x37af3a72ccf6ab71505e4b583650a5e8c5f5e710"}, {name: "disbursement", type: "address", value: "0x19381c12133af4c9db2bf6e8d365882dc9bfcdf1"}, {name: "beneficiaryTokens", type: "uint256", value: "975000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x07b128eb671d2f3d98ba809ccda6f801b5b238a5"}, {name: "disbursement", type: "address", value: "0xbb4ccd2ab135ee3cc7d3d0cd10bd184721722c0c"}, {name: "beneficiaryTokens", type: "uint256", value: "31110000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[8,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: distributeTimelockedTokens( [addressList[10],addressList[11],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494286", timeStamp: "1509874549", hash: "0x51b2d864310360a9724bb59322619d03e04c7388d176256324a76b81d50d1379", nonce: "72", blockHash: "0xc53665af3d1ecfe891d765534e69452084e726c70b97031ebcfc25d9c2a29704", transactionIndex: "1", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x555c47580000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000002600000000000000000000000000000000000000000000000000000000000000004000000000000000000000000b8e668958b6151db3ef13b97866cc4359dedfee6000000000000000000000000d98cb2b207eb024381c1c40315044c67782e555f000000000000000000000000875f6dc5c6e671a99b6b75ffc8be749fe024a8a90000000000000000000000005a56f4cdbe88d529d68340f6b822c3fba4a17f7c0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000004953f87c2a0000000000000000000000000000000000000000000000000000000265e8af393000000000000000000000000000000000000000000000000000001550f7dca70000000000000000000000000000000000000000000000000000000110d9316ec0000000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000005c01a4d0000000000000000000000000000000000000000000000000000000005c01a4d0000000000000000000000000000000000000000000000000000000005c01a4d0000000000000000000000000000000000000000000000000000000005c01a4d000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e00", contractAddress: "", cumulativeGasUsed: "2777157", gasUsed: "2740620", confirmations: "3244302"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_beneficiaries", value: [addressList[10],addressList[11],addressList[12],addressList[13]]}, {type: "uint256[]", name: "_beneficiariesTokens", value: ["20640000000000000","675000000000000","6000000000000000","300000000000000"]}, {type: "uint256[]", name: "_timelockStarts", value: ["1543611600","1543611600","1543611600","1543611600"]}, {type: "uint256[]", name: "_periods", value: ["15552000","15552000","15552000","15552000"]}], name: "distributeTimelockedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributeTimelockedTokens(address[],uint256[],uint256[],uint256[])" ]( [addressList[10],addressList[11],addressList[12],addressList[13]], ["20640000000000000","675000000000000","6000000000000000","300000000000000"], ["1543611600","1543611600","1543611600","1543611600"], ["15552000","15552000","15552000","15552000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1509874549 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "disbursement", type: "address"}, {indexed: false, name: "beneficiaryTokens", type: "uint256"}], name: "TransferredTimelockedTokens", type: "event"} ;
		console.error( "eventCallOriginal[9,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0xb8e668958b6151db3ef13b97866cc4359dedfee6"}, {name: "disbursement", type: "address", value: "0x21bb3278071e56357bc30f189e5657e8c41897d6"}, {name: "beneficiaryTokens", type: "uint256", value: "20640000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0xd98cb2b207eb024381c1c40315044c67782e555f"}, {name: "disbursement", type: "address", value: "0x845132ee199ae46d60835d2358fb60b687eb8213"}, {name: "beneficiaryTokens", type: "uint256", value: "675000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x875f6dc5c6e671a99b6b75ffc8be749fe024a8a9"}, {name: "disbursement", type: "address", value: "0x0675670108832aca53cc335732899b872cef2f4f"}, {name: "beneficiaryTokens", type: "uint256", value: "6000000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x5a56f4cdbe88d529d68340f6b822c3fba4a17f7c"}, {name: "disbursement", type: "address", value: "0xa2b784310177723c2f27823a3235bb8ac4317038"}, {name: "beneficiaryTokens", type: "uint256", value: "300000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[9,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: distributeTimelockedTokens( [addressList[14],addressList[15]], [\"30... )", async function( ) {
		const txOriginal = {blockNumber: "4494287", timeStamp: "1509874560", hash: "0x01e6506fd1bfde4f6705d278133fe1964700dc7f39b88c40f3513dfd46023a82", nonce: "73", blockHash: "0x57e426e21d55cdff6bd2b2e55974eaac291a907eb7a9f484b9d16802373d5b8d", transactionIndex: "1", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x555c4758000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000014000000000000000000000000000000000000000000000000000000000000001a0000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061618b6c994e8aa340ddcc15af7c8e743f194eb900000000000000000000000037af3a72ccf6ab71505e4b583650a5e8c5f5e7100000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000110d9316ec000000000000000000000000000000000000000000000000000000376c1e0a7f0000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000005c01a4d0000000000000000000000000000000000000000000000000000000005c01a4d000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000ed4e000000000000000000000000000000000000000000000000000000000000ed4e00", contractAddress: "", cumulativeGasUsed: "1436525", gasUsed: "1384355", confirmations: "3244301"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_beneficiaries", value: [addressList[14],addressList[15]]}, {type: "uint256[]", name: "_beneficiariesTokens", value: ["300000000000000","975000000000000"]}, {type: "uint256[]", name: "_timelockStarts", value: ["1543611600","1543611600"]}, {type: "uint256[]", name: "_periods", value: ["15552000","15552000"]}], name: "distributeTimelockedTokens", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributeTimelockedTokens(address[],uint256[],uint256[],uint256[])" ]( [addressList[14],addressList[15]], ["300000000000000","975000000000000"], ["1543611600","1543611600"], ["15552000","15552000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1509874560 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		var eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "beneficiary", type: "address"}, {indexed: false, name: "disbursement", type: "address"}, {indexed: false, name: "beneficiaryTokens", type: "uint256"}], name: "TransferredTimelockedTokens", type: "event"} ;
		console.error( "eventCallOriginal[10,0] = %s", JSON.stringify( eventCallOriginal ) ) ;
		var eventResultOriginal = [{name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x61618b6c994e8aa340ddcc15af7c8e743f194eb9"}, {name: "disbursement", type: "address", value: "0xfca3becf5ca65c477a03f2323b17a4a66caa2e12"}, {name: "beneficiaryTokens", type: "uint256", value: "300000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}, {name: "TransferredTimelockedTokens", events: [{name: "beneficiary", type: "address", value: "0x37af3a72ccf6ab71505e4b583650a5e8c5f5e710"}, {name: "disbursement", type: "address", value: "0x317908bb441fe46f56cb7e5223eb6dd88449169e"}, {name: "beneficiaryTokens", type: "uint256", value: "975000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[10,0] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[16]], [\"249824581514581500... )", async function( ) {
		const txOriginal = {blockNumber: "4494293", timeStamp: "1509874680", hash: "0xfdf3ec641c28a4ae782b8422e238c9540a0cdad0c6746860c8cb3beb2a049cf9", nonce: "74", blockHash: "0xe6e0e37ab7e0e9956f72bbf16b10ddc96dce0d6676a632712a9b0dcf615ed8c2", transactionIndex: "2", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "0", input: "0x8c1d92af000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000b37fdb09a5793ecddc1efc48014d6d4f55096e4b000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000003778e221d5655fc", contractAddress: "", cumulativeGasUsed: "106350", gasUsed: "26252", confirmations: "3244295"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[16]]}, {type: "uint256[]", name: "_amounts", value: ["249824581514581500"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[16]], ["249824581514581500"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1509874680 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[17]], [\"8970008970008\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494294", timeStamp: "1509874702", hash: "0xe6e521b3b4e7e7e8d1a49ce36089872827462e27173c51eca49ce1c70700492f", nonce: "75", blockHash: "0x839dd887683ec230fabf885156a10be68370f8e2ecf41b7a29a06063147d92a4", transactionIndex: "2", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000023b892e361db5b7a49c2acd1a382ef48b5ed09690000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000008287e32c318", contractAddress: "", cumulativeGasUsed: "274806", gasUsed: "66713", confirmations: "3244294"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[17]]}, {type: "uint256[]", name: "_amounts", value: ["8970008970008"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[17]], ["8970008970008"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1509874702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[12,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x23b892e361db5b7a49c2acd1a382ef48b5ed0969"}, {name: "amount", type: "uint256", value: "8970008970008"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[12,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[18]], [\"120000120000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494294", timeStamp: "1509874702", hash: "0x171858fd34890ab66a99d0068d0b92998b364c441e6e38e0758cc0cfb0bfce0f", nonce: "76", blockHash: "0x839dd887683ec230fabf885156a10be68370f8e2ecf41b7a29a06063147d92a4", transactionIndex: "3", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000ce2b966a246d643179fabedddda03209bbfef80700000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000001bf09084c0", contractAddress: "", cumulativeGasUsed: "341455", gasUsed: "66649", confirmations: "3244294"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[18]]}, {type: "uint256[]", name: "_amounts", value: ["120000120000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[18]], ["120000120000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1509874702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[13,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0xce2b966a246d643179fabedddda03209bbfef807"}, {name: "amount", type: "uint256", value: "120000120000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[13,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[19]], [\"6128406128406\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494294", timeStamp: "1509874702", hash: "0xbfb2b395d84a44c64e5d5af0e65bbe636856ffc98057e1292dc97c20de16b760", nonce: "77", blockHash: "0x839dd887683ec230fabf885156a10be68370f8e2ecf41b7a29a06063147d92a4", transactionIndex: "4", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000047a6e95495d959f556589d6c10665d8e8c6b37b9000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000592e1786716", contractAddress: "", cumulativeGasUsed: "408168", gasUsed: "66713", confirmations: "3244294"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[19]]}, {type: "uint256[]", name: "_amounts", value: ["6128406128406"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[19]], ["6128406128406"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1509874702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[14,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x47a6e95495d959f556589d6c10665d8e8c6b37b9"}, {name: "amount", type: "uint256", value: "6128406128406"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[14,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[20]], [\"15000000000000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494294", timeStamp: "1509874702", hash: "0xddd7456772f28e49ca774bc4c2120e9c90af55ab713b615980686a6bd79aaf63", nonce: "78", blockHash: "0x839dd887683ec230fabf885156a10be68370f8e2ecf41b7a29a06063147d92a4", transactionIndex: "5", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000646bea631c753307b398513ff57a4cf269465fa6000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000da475abf000", contractAddress: "", cumulativeGasUsed: "474817", gasUsed: "66649", confirmations: "3244294"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[20]]}, {type: "uint256[]", name: "_amounts", value: ["15000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[20]], ["15000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1509874702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[15,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x646bea631c753307b398513ff57a4cf269465fa6"}, {name: "amount", type: "uint256", value: "15000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[15,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[21]], [\"6000006000006\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494294", timeStamp: "1509874702", hash: "0x1057d45c06fd379375ed71fefe47da44700bbdf8ffecc544c67122de88fcc1a4", nonce: "79", blockHash: "0x839dd887683ec230fabf885156a10be68370f8e2ecf41b7a29a06063147d92a4", transactionIndex: "6", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000943fba8542d38556331b5f53239123dc845f29f6000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000574fc39ed86", contractAddress: "", cumulativeGasUsed: "541530", gasUsed: "66713", confirmations: "3244294"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[21]]}, {type: "uint256[]", name: "_amounts", value: ["6000006000006"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[21]], ["6000006000006"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1509874702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[16,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x943fba8542d38556331b5f53239123dc845f29f6"}, {name: "amount", type: "uint256", value: "6000006000006"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[16,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[22]], [\"15000000000000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494294", timeStamp: "1509874702", hash: "0xa8a7b9436e44b6dd8cca9fd84b46b246f8d27e7a2ccd7765e893f959f437553e", nonce: "80", blockHash: "0x839dd887683ec230fabf885156a10be68370f8e2ecf41b7a29a06063147d92a4", transactionIndex: "7", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000005a22ce293899e3fee176bf8816b5be7ac5327945000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000da475abf000", contractAddress: "", cumulativeGasUsed: "608179", gasUsed: "66649", confirmations: "3244294"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[22]]}, {type: "uint256[]", name: "_amounts", value: ["15000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[22]], ["15000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1509874702 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[17,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x5a22ce293899e3fee176bf8816b5be7ac5327945"}, {name: "amount", type: "uint256", value: "15000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[17,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[23]], [\"3000000000000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494296", timeStamp: "1509874726", hash: "0x459a5af36478937b867d1fc289ccc17a82e44f839bb4b0cc7f759d043eb4f53e", nonce: "81", blockHash: "0x0543496cde9d392b4cefdb112fab570f8f4bf53667fd23946a73aaa1d9144b81", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000049d4533ab400f3e8e60c01a94114289e0827503c0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000002ba7def3000", contractAddress: "", cumulativeGasUsed: "66585", gasUsed: "66585", confirmations: "3244292"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[23]]}, {type: "uint256[]", name: "_amounts", value: ["3000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[23]], ["3000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1509874726 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[18,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x49d4533ab400f3e8e60c01a94114289e0827503c"}, {name: "amount", type: "uint256", value: "3000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[18,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[24]], [\"30000000000000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494297", timeStamp: "1509874727", hash: "0xb8de184cdfefebfbfaad5c76d5c6215cb90b741da0940ce9c0077ac794cedf7a", nonce: "82", blockHash: "0xa04cc935a9f1f77b62af1296530cbfd97707bc671e8e6138420ee62e8364915c", transactionIndex: "14", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000e9ebee76a902b6536c0bddf79ac4c4343e5bdbfb000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000001b48eb57e000", contractAddress: "", cumulativeGasUsed: "674048", gasUsed: "66649", confirmations: "3244291"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[24]]}, {type: "uint256[]", name: "_amounts", value: ["30000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[24]], ["30000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1509874727 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[19,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0xe9ebee76a902b6536c0bddf79ac4c4343e5bdbfb"}, {name: "amount", type: "uint256", value: "30000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[19,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[25]], [\"3000000000000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494298", timeStamp: "1509874730", hash: "0xdfa4b187a7fbe33c6ab5d5d16d88de17f6ee98324da8079049cb97a8df72c6d4", nonce: "83", blockHash: "0x40a9f43e41378f7e91fd4823a71aa115cf89af7dd9e007628505b9b2d63c22f3", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000d161e863f9c3e099020abb1b7092795df6c729500000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000002ba7def3000", contractAddress: "", cumulativeGasUsed: "66649", gasUsed: "66649", confirmations: "3244290"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[25]]}, {type: "uint256[]", name: "_amounts", value: ["3000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[25]], ["3000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1509874730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[20,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0xd161e863f9c3e099020abb1b7092795df6c72950"}, {name: "amount", type: "uint256", value: "3000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[20,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[26]], [\"3000000000000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494298", timeStamp: "1509874730", hash: "0x92c522ca60b28d0ea138168943be5f281f2c779e2ec4c972df52f7484b5c8593", nonce: "84", blockHash: "0x40a9f43e41378f7e91fd4823a71aa115cf89af7dd9e007628505b9b2d63c22f3", transactionIndex: "7", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000001000000000000000000000000dc5796a839736017ec3d083ab053b03f51a7455f0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000002ba7def3000", contractAddress: "", cumulativeGasUsed: "398758", gasUsed: "66649", confirmations: "3244290"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[26]]}, {type: "uint256[]", name: "_amounts", value: ["3000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[26]], ["3000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1509874730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[21,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0xdc5796a839736017ec3d083ab053b03f51a7455f"}, {name: "amount", type: "uint256", value: "3000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[21,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[27]], [\"15000000000000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494298", timeStamp: "1509874730", hash: "0xbea5e45bd362b4f8087a56e0a1b076776f1ac29cbf2027dabfb49d766c6a4d5e", nonce: "85", blockHash: "0x40a9f43e41378f7e91fd4823a71aa115cf89af7dd9e007628505b9b2d63c22f3", transactionIndex: "8", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000084256d81c1a191e6952c781f6a204626c6912b83000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000da475abf000", contractAddress: "", cumulativeGasUsed: "465407", gasUsed: "66649", confirmations: "3244290"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[27]]}, {type: "uint256[]", name: "_amounts", value: ["15000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[27]], ["15000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1509874730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[22,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x84256d81c1a191e6952c781f6a204626c6912b83"}, {name: "amount", type: "uint256", value: "15000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[22,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[28]], [\"4500004500004\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494298", timeStamp: "1509874730", hash: "0xc5b28cb025abc8d3fec9f308af77f42a2de3aa1c8dc24392ccb2c001888328ed", nonce: "86", blockHash: "0x40a9f43e41378f7e91fd4823a71aa115cf89af7dd9e007628505b9b2d63c22f3", transactionIndex: "9", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000003e5548dde6d74caa89313057b7d286f46cc309f4000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000000417bd2b7224", contractAddress: "", cumulativeGasUsed: "532120", gasUsed: "66713", confirmations: "3244290"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[28]]}, {type: "uint256[]", name: "_amounts", value: ["4500004500004"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[28]], ["4500004500004"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1509874730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[23,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x3e5548dde6d74caa89313057b7d286f46cc309f4"}, {name: "amount", type: "uint256", value: "4500004500004"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[23,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[29]], [\"3000000000000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494298", timeStamp: "1509874730", hash: "0x17a44998cf4364c8a3c914735bc3f7575932a72dbb5fe8654505fb27718dee3d", nonce: "87", blockHash: "0x40a9f43e41378f7e91fd4823a71aa115cf89af7dd9e007628505b9b2d63c22f3", transactionIndex: "10", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000005f21639f20f586662a3eb24fe971b5c2a35bd0120000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000002ba7def3000", contractAddress: "", cumulativeGasUsed: "598769", gasUsed: "66649", confirmations: "3244290"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[29]]}, {type: "uint256[]", name: "_amounts", value: ["3000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[29]], ["3000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1509874730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[24,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x5f21639f20f586662a3eb24fe971b5c2a35bd012"}, {name: "amount", type: "uint256", value: "3000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[24,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[30]], [\"3000000000000\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494298", timeStamp: "1509874730", hash: "0x6d7dfbd1e98561701aff5e425c769f261efcdffe1e24e3b0ea3ddb857318ac00", nonce: "88", blockHash: "0x40a9f43e41378f7e91fd4823a71aa115cf89af7dd9e007628505b9b2d63c22f3", transactionIndex: "11", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000000100000000000000000000000050df85ae6cc9557d87f06c6bdd69ff8b7b19fc160000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000002ba7def3000", contractAddress: "", cumulativeGasUsed: "665418", gasUsed: "66649", confirmations: "3244290"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[30]]}, {type: "uint256[]", name: "_amounts", value: ["3000000000000"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[30]], ["3000000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1509874730 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[25,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x50df85ae6cc9557d87f06c6bdd69ff8b7b19fc16"}, {name: "amount", type: "uint256", value: "3000000000000"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[25,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[31]], [\"29700029700029\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494299", timeStamp: "1509874732", hash: "0x6abb4b79403e360dcd129c29dd5cb559cb93ceabb40a3fc2e021d02993065c39", nonce: "89", blockHash: "0x9764c8db5971c56ad185fea9f545b7635c38e06307a439448792840d64ab3777", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000008628d73d3f950abde99739ef34b6cfa10394f579000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000001b0313b857bd", contractAddress: "", cumulativeGasUsed: "66713", gasUsed: "66713", confirmations: "3244289"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[31]]}, {type: "uint256[]", name: "_amounts", value: ["29700029700029"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[31]], ["29700029700029"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1509874732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[26,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x8628d73d3f950abde99739ef34b6cfa10394f579"}, {name: "amount", type: "uint256", value: "29700029700029"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[26,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: distributePresaleTokens( [addressList[32]], [\"30000030000030\"] )", async function( ) {
		const txOriginal = {blockNumber: "4494299", timeStamp: "1509874732", hash: "0xda059d01cf02a1061f12405f903b273cd9b21bc471b5de02bbaed09929e9d659", nonce: "90", blockHash: "0x9764c8db5971c56ad185fea9f545b7635c38e06307a439448792840d64ab3777", transactionIndex: "1", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x8c1d92af0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000010000000000000000000000005acca1d9874bcc2b50f63a7a4c48e9506485e1aa000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000000000000000000001b48ed21a39e", contractAddress: "", cumulativeGasUsed: "133426", gasUsed: "66713", confirmations: "3244289"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_buyers", value: [addressList[32]]}, {type: "uint256[]", name: "_amounts", value: ["30000030000030"]}], name: "distributePresaleTokens", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePresaleTokens(address[],uint256[])" ]( [addressList[32]], ["30000030000030"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1509874732 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"} ;
		console.error( "eventCallOriginal[27,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "PurchasedTokens", events: [{name: "purchaser", type: "address", value: "0x5acca1d9874bcc2b50f63a7a4c48e9506485e1aa"}, {name: "amount", type: "uint256", value: "30000030000030"}], address: "0xf2fbb2939981594e25d93e6226231fcc1b01718e"}] ;
		console.error( "eventResultOriginal[27,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[33],addressList[34],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494337", timeStamp: "1509875312", hash: "0x08001b3593a8763a09bd97791a12058d044a277d7f6859a94247ccd17704c701", nonce: "91", blockHash: "0x8f3587806b40b621dd4ec5af2cbec2aaaad58d671358e9ce6a151d3afa182076", transactionIndex: "19", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000a96e78d4900cb5f8c412c1437b15aaf81f673300000000000000000000000058cbe3edf182e28ba6c7453b33503bc886adf35c0000000000000000000000006507d08cda616f2f253e6aafd6509408cb89818d000000000000000000000000f9fa4c86800ab01c15884b4c964ffefddb6b0c890000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000004b00000000000000000000000000000000000000000000000000000000000000430000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000003c", contractAddress: "", cumulativeGasUsed: "757026", gasUsed: "192366", confirmations: "3244251"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[33],addressList[34],addressList[35],addressList[36]]}, {type: "uint256[]", name: "_amount", value: ["75","67","3","60"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[33],addressList[34],addressList[35],addressList[36]], ["75","67","3","60"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1509875312 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[37],addressList[38],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494338", timeStamp: "1509875323", hash: "0xc10c53c301d820b6867a996c067af84d0ebb2ff537c953cdf96fb453bf9a7ae2", nonce: "92", blockHash: "0x0d57d70d17f51664441f877c0c69bde38ab27caea29751fa6001052c7f35845f", transactionIndex: "1", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000040000000000000000000000009c19a027141d4b43542252bfe44d9c600635331b00000000000000000000000000d6b5603f711f5b2d33deb365613608af40e4c6000000000000000000000000d07780f54e6b52a24d2ef9f17125adf1917b9a2b000000000000000000000000627bd5cd4c8125541b27c9f38f4d0224acda3acb0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000004b000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000005", contractAddress: "", cumulativeGasUsed: "244710", gasUsed: "192366", confirmations: "3244250"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[37],addressList[38],addressList[39],addressList[40]]}, {type: "uint256[]", name: "_amount", value: ["28","75","12","5"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[37],addressList[38],addressList[39],addressList[40]], ["28","75","12","5"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1509875323 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[41],addressList[42],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494338", timeStamp: "1509875323", hash: "0xa64a04e947d9c4925c7beb84455bd29f68213fa4bd70a123712bcddd7e158cf4", nonce: "93", blockHash: "0x0d57d70d17f51664441f877c0c69bde38ab27caea29751fa6001052c7f35845f", transactionIndex: "2", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000e4bac8191754b79f955d06eca8d95faec6b57e2400000000000000000000000003097a46ffb4d9f5291e1975a76f7bb9926b2a1f000000000000000000000000f1bf0f88a43b64ed1776e71295e78baee7dae9940000000000000000000000002da86fd3c3f2cc1cc8c1339edd9bd9bde1f3822d00000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000011000000000000000000000000000000000000000000000000000000000000000d0000000000000000000000000000000000000000000000000000000000000037000000000000000000000000000000000000000000000000000000000000000a", contractAddress: "", cumulativeGasUsed: "437140", gasUsed: "192430", confirmations: "3244250"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[41],addressList[42],addressList[43],addressList[44]]}, {type: "uint256[]", name: "_amount", value: ["17","13","55","10"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[41],addressList[42],addressList[43],addressList[44]], ["17","13","55","10"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1509875323 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[45],addressList[46],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494338", timeStamp: "1509875323", hash: "0x9466821a5316db443c1d12042a52cddce4737207015644305e19a8ac9f09c298", nonce: "94", blockHash: "0x0d57d70d17f51664441f877c0c69bde38ab27caea29751fa6001052c7f35845f", transactionIndex: "3", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000040000000000000000000000001e7462b92672ce48d76a067972bcf32f12626bf5000000000000000000000000c3dc221baee69184f68ed2ac68815c12cb15df250000000000000000000000004f58a944580788c502b2d9be382ab96358a1c0630000000000000000000000005fd474f8abdb347ec54b15cbca40b56dd2f2aefc000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000063000000000000000000000000000000000000000000000000000000000000000b0000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "629570", gasUsed: "192430", confirmations: "3244250"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[45],addressList[46],addressList[47],addressList[48]]}, {type: "uint256[]", name: "_amount", value: ["1","99","11","3"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[45],addressList[46],addressList[47],addressList[48]], ["1","99","11","3"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1509875323 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[49],addressList[50],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494339", timeStamp: "1509875348", hash: "0x4e597c65d1aef55c75aa9c08b257880c5c22251dc40f11974fd0f7aa2f09a042", nonce: "95", blockHash: "0x2c172a0f7d62f16414c7bf38a782d5034b1d1c8e23137d3a919f86a93fec04e7", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000624aa1b650f239cd7e2d99eb642036c706587f9a000000000000000000000000188a67dec970dddc53d45504576f359960d1534a000000000000000000000000cb3833a6a1dab47376c94ee9ca15bded513ca883000000000000000000000000d822346c13e251c80ac5cc5aeb1626f02ba6b64c00000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000004500000000000000000000000000000000000000000000000000000000000000500000000000000000000000000000000000000000000000000000000000000003", contractAddress: "", cumulativeGasUsed: "192430", gasUsed: "192430", confirmations: "3244249"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[49],addressList[50],addressList[51],addressList[52]]}, {type: "uint256[]", name: "_amount", value: ["5","69","80","3"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[49],addressList[50],addressList[51],addressList[52]], ["5","69","80","3"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1509875348 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[53],addressList[54],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494341", timeStamp: "1509875369", hash: "0xab76bfa3cd5cdb974f9c16d936ebe616350095a7008d7f245ca62e10ac0a7079", nonce: "96", blockHash: "0x71480f4d3ad993e70d906c5d99e508c1b9facd35c348df15007627e2db0e66d7", transactionIndex: "17", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000000400000000000000000000000002b322ecfd80aa1de6536be93a496820a84711ed0000000000000000000000009e1b202b129384a331b6c694b584c5be02cb9fc00000000000000000000000008d1cb90fae9e824038856c9b098d452f37e396f6000000000000000000000000a3ac9714b7bd582cf80753cd171335f9b05175740000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000900000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "777689", gasUsed: "192430", confirmations: "3244247"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[53],addressList[54],addressList[55],addressList[56]]}, {type: "uint256[]", name: "_amount", value: ["9","2","6","12"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[53],addressList[54],addressList[55],addressList[56]], ["9","2","6","12"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1509875369 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[57],addressList[21],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494343", timeStamp: "1509875441", hash: "0x9578904f6d892a9d2a0cb410828528d66ffecff930fda62672816ed0e51f57e7", nonce: "97", blockHash: "0xc4b6cca215a5904a24f373d1a50d03fde9c10d84ec9ba84cd74d1a3ba9b9ff3a", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000a62444d723e1c6f7f666a013606453dc62d9c7b8000000000000000000000000943fba8542d38556331b5f53239123dc845f29f6000000000000000000000000f18055387961a61eeff5a3fcf9d510b56a94c6da000000000000000000000000ff8a412b3ab681308f722f9cb7ab23ce32e998460000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000003c", contractAddress: "", cumulativeGasUsed: "192430", gasUsed: "192430", confirmations: "3244245"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[57],addressList[21],addressList[58],addressList[59]]}, {type: "uint256[]", name: "_amount", value: ["3","2","5","60"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[57],addressList[21],addressList[58],addressList[59]], ["3","2","5","60"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1509875441 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[60],addressList[61],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494344", timeStamp: "1509875444", hash: "0x8d709a67a5ad0109fb082e575e97d1c1baddeb49ab37c038a41cfd4868f100c5", nonce: "98", blockHash: "0xe5a47b928ff0f1fbeff56d4e6b28a18e62364b5d023c1f8781b98831a3e6e73b", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000f2383106f3bed64a4c3ff24fdea44563a613da84000000000000000000000000d2e4d935f5b1495a4afbaf51cac00d769ad21ace0000000000000000000000007dafd53aee8982ab1d767830c2fe50f62e3a98e60000000000000000000000003092d6939da0bfd3b3044ba67efc580f82970dd400000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000002300000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "192430", gasUsed: "192430", confirmations: "3244244"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[60],addressList[61],addressList[62],addressList[63]]}, {type: "uint256[]", name: "_amount", value: ["23","35","3","1"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[60],addressList[61],addressList[62],addressList[63]], ["23","35","3","1"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1509875444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[64],addressList[65],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494344", timeStamp: "1509875444", hash: "0x4e47766dee53c4813e28c8a09bf59a83c5bdf8f0a718f48fc8b0f200c93f0c71", nonce: "99", blockHash: "0xe5a47b928ff0f1fbeff56d4e6b28a18e62364b5d023c1f8781b98831a3e6e73b", transactionIndex: "1", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000723040085de7b32bb91dba32abe01653bc63ecf000000000000000000000000d79ee3be5e0154cd7540a55cc4f7e44d78a38b6a000000000000000000000000dd5bab9dffb66733330a015b41c5627fc72103eb00000000000000000000000066b098c04c9d11f4150e79c89e611377f6f6483c0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000001c000000000000000000000000000000000000000000000000000000000000001f00000000000000000000000000000000000000000000000000000000000000030000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "384796", gasUsed: "192366", confirmations: "3244244"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[64],addressList[65],addressList[66],addressList[67]]}, {type: "uint256[]", name: "_amount", value: ["28","31","3","1"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[64],addressList[65],addressList[66],addressList[67]], ["28","31","3","1"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1509875444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[68],addressList[69],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494344", timeStamp: "1509875444", hash: "0xbbdc63fa1cb724d00b071667c2f51db0c9843cc380104557c520238c42b847a1", nonce: "100", blockHash: "0xe5a47b928ff0f1fbeff56d4e6b28a18e62364b5d023c1f8781b98831a3e6e73b", transactionIndex: "2", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000d2b09d0266689b5baa23c01a377ec71c9646f540000000000000000000000000930c4667464fc346b4065b3ffde8d4a8533c0ed3000000000000000000000000f3d10939063783f11e69760336b64d8da380a605000000000000000000000000701e66003edbe78c0a16c3b24de0a8b68048fb380000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000300000000000000000000000000000000000000000000000000000000000000080000000000000000000000000000000000000000000000000000000000000190000000000000000000000000000000000000000000000000000000000000004b", contractAddress: "", cumulativeGasUsed: "577226", gasUsed: "192430", confirmations: "3244244"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[68],addressList[69],addressList[70],addressList[71]]}, {type: "uint256[]", name: "_amount", value: ["3","8","400","75"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[68],addressList[69],addressList[70],addressList[71]], ["3","8","400","75"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1509875444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[72],addressList[73],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494344", timeStamp: "1509875444", hash: "0xb55dff58cb2366c61f90ea9a090b95f5d1dfb796008accea71ff12d7c74bf63c", nonce: "101", blockHash: "0xe5a47b928ff0f1fbeff56d4e6b28a18e62364b5d023c1f8781b98831a3e6e73b", transactionIndex: "3", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000000400000000000000000000000094969672704fbe6f19ebba746e3f119e9d25954500000000000000000000000053bedb22d57d40f748a6cb575b221b5f952956a3000000000000000000000000f4fc45f121ddea36725ee28f7d865f07f44f7df9000000000000000000000000aa6993fbdab3e4549a0b8b974d860d0ff18468f9000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000046000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0", contractAddress: "", cumulativeGasUsed: "769656", gasUsed: "192430", confirmations: "3244244"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[72],addressList[73],addressList[74],addressList[75]]}, {type: "uint256[]", name: "_amount", value: ["1","70","96","160"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[72],addressList[73],addressList[74],addressList[75]], ["1","70","96","160"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1509875444 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[76],addressList[77],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494345", timeStamp: "1509875448", hash: "0x7b15351ee1e96b1d76636052d68938c3276d86a17b8e1442fb21462491c82bbb", nonce: "102", blockHash: "0x3f7d0ec59b33d820895f3eacab00097ddbef329fdcfe7fde59832d8a1297302f", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000040000000000000000000000004f276e1405941f5839619215465efcb02f39997d00000000000000000000000026e8b8bc4053638fced7c3bd60fd893dca1bd7da0000000000000000000000001e59a036e19f5c430fd9a46477fa5538e2cb63bd00000000000000000000000088c2edee1e1135244f537bb67051081873526dc600000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000082000000000000000000000000000000000000000000000000000000000000004b0000000000000000000000000000000000000000000000000000000000000078000000000000000000000000000000000000000000000000000000000000004c", contractAddress: "", cumulativeGasUsed: "192430", gasUsed: "192430", confirmations: "3244243"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[76],addressList[77],addressList[78],addressList[79]]}, {type: "uint256[]", name: "_amount", value: ["130","75","120","76"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[76],addressList[77],addressList[78],addressList[79]], ["130","75","120","76"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1509875448 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[80],addressList[81],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494346", timeStamp: "1509875449", hash: "0x95755d75d38fde56aa5284f5edfb1e8db50d9157d2e3313019873b41e737e8d3", nonce: "103", blockHash: "0xe8a21743b5e7e93773a812b3b6b524bdd84f9aa2c8795647c22585396acd3b66", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000040000000000000000000000004d280adb927f333d14f7ef4f8f901df870419610000000000000000000000000bd848de0c9b56517165d7e96dc77083361bf3cb8000000000000000000000000427dd85f9667b0c72801e12b949557ad718d7cac00000000000000000000000076cdd2e593d0c95ec088c3cb594b949ee6aa1ef80000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000aa000000000000000000000000000000000000000000000000000000000000003700000000000000000000000000000000000000000000000000000000000000be", contractAddress: "", cumulativeGasUsed: "192430", gasUsed: "192430", confirmations: "3244242"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[80],addressList[81],addressList[82],addressList[83]]}, {type: "uint256[]", name: "_amount", value: ["2","170","55","190"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[80],addressList[81],addressList[82],addressList[83]], ["2","170","55","190"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1509875449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[84],addressList[85],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494346", timeStamp: "1509875449", hash: "0x05856c98b5afa4bb881cbc819883a270c22b1fd94f8ade3e799cfe87fa23b9ad", nonce: "104", blockHash: "0xe8a21743b5e7e93773a812b3b6b524bdd84f9aa2c8795647c22585396acd3b66", transactionIndex: "1", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000d2bf9b72ca82605f782696e5981c9ea5de128426000000000000000000000000c0d3a8d939d8653f0fd8fe7a0646dd3884293466000000000000000000000000c3ae6f90d375a82b2a3f9fe3679331141dfeb6a8000000000000000000000000046d05c025aa76452bafc566ff69ef65c06973df000000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000230000000000000000000000000000000000000000000000000000000000000037000000000000000000000000000000000000000000000000000000000000003c0000000000000000000000000000000000000000000000000000000000000033", contractAddress: "", cumulativeGasUsed: "384860", gasUsed: "192430", confirmations: "3244242"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[84],addressList[85],addressList[86],addressList[87]]}, {type: "uint256[]", name: "_amount", value: ["35","55","60","51"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[84],addressList[85],addressList[86],addressList[87]], ["35","55","60","51"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1509875449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[88],addressList[89],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494346", timeStamp: "1509875449", hash: "0x50f2ff4244edd71560b4d079219161890d478f8847b0bd30e5193410909891cc", nonce: "105", blockHash: "0xe8a21743b5e7e93773a812b3b6b524bdd84f9aa2c8795647c22585396acd3b66", transactionIndex: "2", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000040000000000000000000000002d860ff6e483ad750f853f4795ccb3cdf3d25d06000000000000000000000000940b801df38718254869c33bc9db9462ee76da9d00000000000000000000000058396b6d39fb1231991fec52c2e30b991ad36992000000000000000000000000b11e3c2b81bf2d5856dd110c48a19dcba58f68ab0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000012c0000000000000000000000000000000000000000000000000000000000000063000000000000000000000000000000000000000000000000000000000000012c0000000000000000000000000000000000000000000000000000000000000018", contractAddress: "", cumulativeGasUsed: "577418", gasUsed: "192558", confirmations: "3244242"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[88],addressList[89],addressList[90],addressList[91]]}, {type: "uint256[]", name: "_amount", value: ["300","99","300","24"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[88],addressList[89],addressList[90],addressList[91]], ["300","99","300","24"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1509875449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[92],addressList[93],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494346", timeStamp: "1509875449", hash: "0xefa6225ad10b3a4b77043db946c2a99997f5fd480765d3355b09f2b0b2eca922", nonce: "106", blockHash: "0xe8a21743b5e7e93773a812b3b6b524bdd84f9aa2c8795647c22585396acd3b66", transactionIndex: "3", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000a0db493c83b211f7bf8c83586f8f3a4cfa978a1800000000000000000000000014771461655dd3a887144ed81add8d4298cb1361000000000000000000000000ea2a3ee765f1a826dc5fc854aea1766f72d40905000000000000000000000000f1066b9b515f21c02c70fea24f84e48bfd8976d900000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000019000000000000000000000000000000000000000000000000000000000000000fa000000000000000000000000000000000000000000000000000000000000015e", contractAddress: "", cumulativeGasUsed: "769976", gasUsed: "192558", confirmations: "3244242"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[92],addressList[93],addressList[94],addressList[95]]}, {type: "uint256[]", name: "_amount", value: ["80","400","250","350"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[92],addressList[93],addressList[94],addressList[95]], ["80","400","250","350"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1509875449 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[96],addressList[97],address... )", async function( ) {
		const txOriginal = {blockNumber: "4494347", timeStamp: "1509875456", hash: "0xfc53d561cbc2215f6ee99928104599779f034e37cc930cc1d10ad1d4ee92913e", nonce: "107", blockHash: "0x6eb1be96a6f00d7083152d3abf3ab347fbf80710de74bb073aca61074b593cf2", transactionIndex: "1", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000040000000000000000000000001de00cc156f53ac088f39ccbe58979aca7620ad0000000000000000000000000ed1316a78223565ff499aca062e0d16f4f96f2ac000000000000000000000000014cc0d352a8a74d843bbe1a53c21b734aa2da7e000000000000000000000000f4d29947f022437f800eda0f9faeb512ed5e72b50000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000009c0000000000000000000000000000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000001800000000000000000000000000000000000000000000000000000000000000fa", contractAddress: "", cumulativeGasUsed: "223430", gasUsed: "192430", confirmations: "3244241"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[96],addressList[97],addressList[98],addressList[99]]}, {type: "uint256[]", name: "_amount", value: ["156","80","24","250"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[96],addressList[97],addressList[98],addressList[99]], ["156","80","24","250"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1509875456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[100],addressList[101],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4494347", timeStamp: "1509875456", hash: "0x01a0f6b955e6fae553e2d64e1247709e546c934395e836d65332a8a7c4b12f23", nonce: "108", blockHash: "0x6eb1be96a6f00d7083152d3abf3ab347fbf80710de74bb073aca61074b593cf2", transactionIndex: "2", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000040000000000000000000000004945e6d54134c5e5f1e70e2fb0e5e6c840754c710000000000000000000000006af2c786d6588eb4770897c4e5c465ef37781afc000000000000000000000000169f656cca16fae961f024dd184f89290707517e00000000000000000000000060d77ef89e7267c667d7cf27bd6cd56d7212eba000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000017000000000000000000000000000000000000000000000000000000000000015e000000000000000000000000000000000000000000000000000000000000004b00000000000000000000000000000000000000000000000000000000000000b4", contractAddress: "", cumulativeGasUsed: "415924", gasUsed: "192494", confirmations: "3244241"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[100],addressList[101],addressList[102],addressList[103]]}, {type: "uint256[]", name: "_amount", value: ["23","350","75","180"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[100],addressList[101],addressList[102],addressList[103]], ["23","350","75","180"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1509875456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[104],addressList[105],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4494347", timeStamp: "1509875456", hash: "0x6c0853b6ed69f1d1c820de594b42c9f6bf82c336d863be62328b05adab1c941f", nonce: "109", blockHash: "0x6eb1be96a6f00d7083152d3abf3ab347fbf80710de74bb073aca61074b593cf2", transactionIndex: "3", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000c923f91b082b7a0dec07210ccf94d700e88b8e16000000000000000000000000c6110ad7a29e537178d790595cfb1e7a45afdd440000000000000000000000006c0a7bf079186a8a59e59c99a622c9feef5b68880000000000000000000000003fd51473217cf4a556620523d9cc5e23e85e7c5f0000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000fa000000000000000000000000000000000000000000000000000000000000003c000000000000000000000000000000000000000000000000000000000000000c", contractAddress: "", cumulativeGasUsed: "608290", gasUsed: "192366", confirmations: "3244241"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[104],addressList[105],addressList[106],addressList[107]]}, {type: "uint256[]", name: "_amount", value: ["60","250","60","12"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[104],addressList[105],addressList[106],addressList[107]], ["60","250","60","12"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1509875456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[108],addressList[109],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4494347", timeStamp: "1509875456", hash: "0xeb06a6b8db340959874424b59de03298dc506a64b826d8a89e08fb30f85623f2", nonce: "110", blockHash: "0x6eb1be96a6f00d7083152d3abf3ab347fbf80710de74bb073aca61074b593cf2", transactionIndex: "4", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e000000000000000000000000000000000000000000000000000000000000000040000000000000000000000002abc27d69c175bfd9fd2ac0391c2adeb4479c9890000000000000000000000004e61ea5fa18271a2cd15c4fff53300196fa6a19500000000000000000000000000069d5e9c2f9635346c5a0b90967ca98e47c19c0000000000000000000000005599c0eebb6c56d17e46f016a98263cf8a6ae57000000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000021000000000000000000000000000000000000000000000000000000000000000b000000000000000000000000000000000000000000000000000000000000012c00000000000000000000000000000000000000000000000000000000000000fa", contractAddress: "", cumulativeGasUsed: "800656", gasUsed: "192366", confirmations: "3244241"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[108],addressList[109],addressList[110],addressList[111]]}, {type: "uint256[]", name: "_amount", value: ["33","11","300","250"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[108],addressList[109],addressList[110],addressList[111]], ["33","11","300","250"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1509875456 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[112],addressList[113],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4494348", timeStamp: "1509875460", hash: "0x4a4a51500ca2ab5d04be8dadf5a9b220b515eb20702d8d44760f44ab1acdf672", nonce: "111", blockHash: "0x02e296d6138de63938aefa8ac582ec9e544819113562933449289df96b8276a5", transactionIndex: "0", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000351a7dffbe4b4eba06a0b583c970c4f83e89835c0000000000000000000000004bf9457a22c07b5892551f456b807590ff2a5dad000000000000000000000000c68d9e6d2fd556bf697afb3572cf7f34ec525fac000000000000000000000000c0741cb56a86ddd99e2a5fd0053c380fc1daf43500000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000000000000000000170000000000000000000000000000000000000000000000000000000000000002", contractAddress: "", cumulativeGasUsed: "192430", gasUsed: "192430", confirmations: "3244240"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[112],addressList[113],addressList[114],addressList[115]]}, {type: "uint256[]", name: "_amount", value: ["3","2","23","2"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[112],addressList[113],addressList[114],addressList[115]], ["3","2","23","2"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1509875460 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: addWhitelist( [addressList[116],addressList[117],addre... )", async function( ) {
		const txOriginal = {blockNumber: "4494348", timeStamp: "1509875460", hash: "0xba5c8d3997fe2417ce91d4695da4e26d3432b1d4ce9334126ce135a09d79774b", nonce: "112", blockHash: "0x02e296d6138de63938aefa8ac582ec9e544819113562933449289df96b8276a5", transactionIndex: "1", from: "0x434dc9ef22b28cb1e9669d0a7abddabe8682e3c0", to: "0xf2fbb2939981594e25d93e6226231fcc1b01718e", value: "0", gas: "6110980", gasPrice: "33000000000", isError: "0", txreceipt_status: "1", input: "0x050414bb000000000000000000000000000000000000000000000000000000000000004000000000000000000000000000000000000000000000000000000000000000e00000000000000000000000000000000000000000000000000000000000000004000000000000000000000000c91143076b9f74730ca3167eef565524da268474000000000000000000000000d3438e11d5de4518dcef9a3c455fcb75dcc600cf000000000000000000000000a344987a9bd5207df824296016cc50a8be11eacd00000000000000000000000073691ab45f827e88f4dddf055698d857aae9ed4100000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000003000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000020000000000000000000000000000000000000000000000000000000000000001", contractAddress: "", cumulativeGasUsed: "384796", gasUsed: "192366", confirmations: "3244240"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_purchaser", value: [addressList[116],addressList[117],addressList[118],addressList[119]]}, {type: "uint256[]", name: "_amount", value: ["3","60","2","1"]}], name: "addWhitelist", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "addWhitelist(address[],uint256[])" ]( [addressList[116],addressList[117],addressList[118],addressList[119]], ["3","60","2","1"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1509875460 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "18534724000000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
