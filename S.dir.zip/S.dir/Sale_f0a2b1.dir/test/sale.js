const Sale = artifacts.require( "./Sale.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "Sale" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x5678bcea6d6f33F645dCa8C8C9B7d8d5cAF0A2B1", "0xc1ac6dd9a73f39801B4A73F7b98d3Ba74Ab836b3", "0x3Ebe70Ed8122cF0EE7c1Ae1dAc5A7362DC240Ec0", "0x260E5500fbEeb26d3632Cca07CA819CaA1E29B7A", "0x70EEe2D2f75ED29a62866b80b57C8f2990e1ca36", "0x002611951BA386Db26261142b8F685a26Ec91205", "0x9cc5B4DD8D672DA071EBb69A789956b54b820525", "0x508ad1f1511b9Bd4CeB89c12514241e3546FacD2", "0x13525cE40B1a16A4350A21Bae04920A3079412Bb", "0xedB0DFf82f71647A2757baCe9D76969ac4963781", "0xf3374c5D7394DB9f84421fB4C7dD3f7A48928B80", "0xBCeF1ec3c78eeBcf8Bf269118aF0AD4cB22C43c4", "0x92Af7D428fa7044c38F0Ac5C7a4258D3395988Ea", "0x898c85ebd232dDb5e27628a7069Ab7dcB8a548A4", "0x6eE5408aE077D90a616EB617467939680e1e84ef", "0xFb79bEe9184b3427AC60F984Fff8FF7bB5fe9771", "0x408EF32D69dc5E71152f776e94059b4d87BdF4cf", "0x74f06A98A33F390b46C521747CCd34D328ccd2f2", "0x69c63CbF504cd8841DEcc8875d4018Df136Cd344", "0x00aF7A08F0a421F2BE1BD659116F03D6c0473Ab7", "0x9463f75B8af2eb6DE64aec52F8dfBc7c4Ad20469", "0x5fa079673749104641B0e59388a87c84c2843Fe6", "0x5bF50c00da77b1f3864Cae3C927d029750c040a8", "0x0047C20d2eF4998dC2be6bC28967374C7c6a6B5d", "0x06905127EcB3f59c46a468489e5b262d7AfCc2e8", "0xbC411247092da7133eD5A4bFEa4cc71e54Fe16E0", "0xDdBd16316e2D9328199579EfBDfE9f84aa3Cd678", "0xB14e4b24B46CD8cEb73bC6A9607004D69B6F564d", "0xE9Aa55013556590186AcDFab4F82919F81C24559", "0xf23DadE2097018306A4b91bA82b6017012477E1d", "0xb827433D881Ee05b025bCE6b5144171B76eDd4fd", "0x2207f2a9D82130c1FB2F818c3D851bF5EA9255C9", "0xe35546E159973e3dC637f3fF9438c60D92fb0E07", "0x851D020687Ab66Bb080b60b02114c35F46961E31", "0x55F99BeBFA5e09E48E402b2Fa21aD736AA6a1910", "0xF66cCA103FD85F5a7da5107b07870Cf1E398D981", "0x0049b126FF923cF4c868F2B09aA58b798353fA52", "0x71547706099dA06fc8fF089aE3E8027632F98953", "0x00EA29cB2e2Ca58eC093BDC2C1400E91594609Cc", "0xFE00b2407bAb3De30EeEea14b719F7455F6e5a06", "0x4c7256CF27A29992a752BD710a859F6542D63546", "0x7C47C2bdBe8307E06E034eE0F3941b483a91E535", "0xEf76677AC59C5d47775024803c8CC2da6539D6DD", "0xc789C36Bf5cB223f0446e1dE95519AE757762f13", "0x005c1bc72DF1B10581a4125520C36E650E13Df20", "0x8f464cF6e81724a999Af630B284b9A21bb657EEa", "0xd13db656a5166B8476fD6dE32f76222417bBA2C1", "0x2dA86FD3C3f2CC1cc8c1339eDD9bd9bDe1f3822D", "0x00f866241cb94Ece61b1e16a46457e801E4Fd38B", "0x00890DfA0bd28F631Df9d99FA617625E43120163", "0xcA02Fa3188FCd3E081b66C4C961BB036Bb0049E6", "0x0042787221ddc2D9B4F9F3Bcf29fbD461dAbcdcE", "0xFAd5c3F26DeeEb78CBE91A5Ff45Ee6316a5ab34a", "0x823f327E1b4551ee278a8ca135E27A69793F1D58", "0x34a52AD4E1885837E41c606caef3a3bB6D7DC8dD", "0x765fdCbaa945c2f73daE083770Dd0aedFa386d5a", "0xE881587E0446db2De272B5a82874A9cfa37e97b1", "0xEa3A9Ed81f0DEdD5d12A797bc5854E652578aA84", "0x1982581A3cD5C0124127C6ca94d1E00c6Beb3249"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [{name: "", type: "uint256"}], name: "filters", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "freezeBlock", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "startBlock", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "owner", outputs: [{name: "", type: "address"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "price", outputs: [{name: "", type: "uint256"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "foundersTokensDisbursed", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "emergencyFlag", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "preSaleTokensDisbursed", outputs: [{name: "", type: "bool"}], payable: false, type: "function"}, {constant: true, inputs: [], name: "token", outputs: [{name: "", type: "address"}], payable: false, type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: true, name: "purchaser", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "PurchasedTokens", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "preBuyer", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "TransferredPreBuyersReward", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "vault", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "TransferredFoundersTokens", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["PurchasedTokens(address,uint256)", "TransferredPreBuyersReward(address,uint256)", "TransferredFoundersTokens(address,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0xf9c447a9cff6748e98623cddf46579164dc4c2af6253de5278893e8659277364", "0xc8cd09ae0c3d03fa0d2a7fac69f32a4f2957ef01cf0c00cc96a7cb7b2d662205", "0xdf54c65993b967a898d91ddb01509dce3e832dbe8beef6ef5f42743b65cbad40"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 3899751 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 3926685 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "_owner", value: 3}, {type: "address", name: "_wallet", value: 4}, {type: "uint256", name: "_tokenSupply", value: "1000000000000000000"}, {type: "string", name: "_tokenName", value: "AdToken"}, {type: "uint8", name: "_tokenDecimals", value: "9"}, {type: "string", name: "_tokenSymbol", value: "ADT"}, {type: "uint256", name: "_price", value: "57140"}, {type: "uint256", name: "_startBlock", value: "3939181"}, {type: "uint256", name: "_freezeBlock", value: "3937741"}], name: "Sale", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [{type: "uint256", name: "", value: random.range( maxRandom )}], name: "filters", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "filters(uint256)" ]( methodCall.inputs[ 0 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "freezeBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "freezeBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "startBlock", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "startBlock()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "wallet", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "wallet()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "owner", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",4] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "owner()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",4] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "price", outputs: [{name: "", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",5] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "price()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",5] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "foundersTokensDisbursed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",6] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "foundersTokensDisbursed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",6] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "emergencyFlag", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",7] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "emergencyFlag()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",7] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "preSaleTokensDisbursed", outputs: [{name: "", type: "bool"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",8] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "preSaleTokensDisbursed()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",8] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "token", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",9] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "token()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",9] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "Sale", function( accounts ) {

	it( "TEST: Sale( addressList[3], addressList[4], \"100000... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "3899751", timeStamp: "1497902038", hash: "0x93b2eb77faa8887d2e4d1579b0c63b962c38d246e66583d1d189193abe629c61", nonce: "3", blockHash: "0xfd86e405ad614cc646c4aa007cf2355edf178f835b0445d86b52c8c1bd78e7bf", transactionIndex: "3", from: "0xc1ac6dd9a73f39801b4a73f7b98d3ba74ab836b3", to: 0, value: "0", gas: "4500000", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0xaf6b08a1000000000000000000000000c1ac6dd9a73f39801b4a73f7b98d3ba74ab836b30000000000000000000000003ebe70ed8122cf0ee7c1ae1dac5a7362dc240ec00000000000000000000000000000000000000000000000000de0b6b3a7640000000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000000000000160000000000000000000000000000000000000000000000000000000000000df3400000000000000000000000000000000000000000000000000000000003c1b6d00000000000000000000000000000000000000000000000000000000003c15cd00000000000000000000000000000000000000000000000000000000000000074164546f6b656e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000034144540000000000000000000000000000000000000000000000000000000000", contractAddress: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", cumulativeGasUsed: "4300231", gasUsed: "4237231", confirmations: "3776937"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_owner", value: addressList[3]}, {type: "address", name: "_wallet", value: addressList[4]}, {type: "uint256", name: "_tokenSupply", value: "1000000000000000000"}, {type: "string", name: "_tokenName", value: `AdToken`}, {type: "uint8", name: "_tokenDecimals", value: "9"}, {type: "string", name: "_tokenSymbol", value: `ADT`}, {type: "uint256", name: "_price", value: "57140"}, {type: "uint256", name: "_startBlock", value: "3939181"}, {type: "uint256", name: "_freezeBlock", value: "3937741"}], name: "Sale", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = Sale.new( addressList[3], addressList[4], "1000000000000000000", `AdToken`, "9", `ADT`, "57140", "3939181", "3937741", txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1497902038 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = Sale.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: distributePreBuyersRewards( [addressList[5],addressList[6],addressLi... )", async function( ) {
		const txOriginal = {blockNumber: "3899753", timeStamp: "1497902112", hash: "0x7532eff1e0b5c89978d9e831b966ca08e562f13d6fa67c09940633537a5dfdae", nonce: "4", blockHash: "0x00d39849cd287e36576aa2b3fb81e4e9d5873d38400c5fb0f9a2ccc73666737b", transactionIndex: "6", from: "0xc1ac6dd9a73f39801b4a73f7b98d3ba74ab836b3", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "0", gas: "4500000", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0x94b5255b00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000420000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000260e5500fbeeb26d3632cca07ca819caa1e29b7a00000000000000000000000070eee2d2f75ed29a62866b80b57c8f2990e1ca36000000000000000000000000002611951ba386db26261142b8f685a26ec912050000000000000000000000009cc5b4dd8d672da071ebb69a789956b54b820525000000000000000000000000508ad1f1511b9bd4ceb89c12514241e3546facd200000000000000000000000013525ce40b1a16a4350a21bae04920a3079412bb000000000000000000000000edb0dff82f71647a2757bace9d76969ac4963781000000000000000000000000f3374c5d7394db9f84421fb4c7dd3f7a48928b80000000000000000000000000bcef1ec3c78eebcf8bf269118af0ad4cb22c43c400000000000000000000000092af7d428fa7044c38f0ac5c7a4258d3395988ea000000000000000000000000898c85ebd232ddb5e27628a7069ab7dcb8a548a40000000000000000000000006ee5408ae077d90a616eb617467939680e1e84ef000000000000000000000000fb79bee9184b3427ac60f984fff8ff7bb5fe9771000000000000000000000000408ef32d69dc5e71152f776e94059b4d87bdf4cf00000000000000000000000074f06a98a33f390b46c521747ccd34d328ccd2f200000000000000000000000069c63cbf504cd8841decc8875d4018df136cd34400000000000000000000000000af7a08f0a421f2be1bd659116f03d6c0473ab70000000000000000000000009463f75b8af2eb6de64aec52f8dfbc7c4ad204690000000000000000000000005fa079673749104641b0e59388a87c84c2843fe60000000000000000000000005bf50c00da77b1f3864cae3c927d029750c040a80000000000000000000000000047c20d2ef4998dc2be6bc28967374c7c6a6b5d00000000000000000000000006905127ecb3f59c46a468489e5b262d7afcc2e8000000000000000000000000bc411247092da7133ed5a4bfea4cc71e54fe16e0000000000000000000000000ddbd16316e2d9328199579efbdfe9f84aa3cd678000000000000000000000000b14e4b24b46cd8ceb73bc6a9607004d69b6f564d000000000000000000000000e9aa55013556590186acdfab4f82919f81c24559000000000000000000000000f23dade2097018306a4b91ba82b6017012477e1d000000000000000000000000b827433d881ee05b025bce6b5144171b76edd4fd0000000000000000000000002207f2a9d82130c1fb2f818c3d851bf5ea9255c9000000000000000000000000e35546e159973e3dc637f3ff9438c60d92fb0e07000000000000000000000000000000000000000000000000000000000000001e000000000000000000000000000000000000000000000000000aa87bb2b8b6000000000000000000000000000000000000000000000000000078a4ecc33bec00000000000000000000000000000000000000000000000000005dffb6ef6b2c00000000000000000000000000000000000000000000000000001aa535d3d0c000000000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000017af4d8864e0000000000000000000000000000000000000000000000000000017af4d8864e000000000000000000000000000000000000000000000000000005ebd3267e6e000000000000000000000000000000000000000000000000000002f5e97571d200000000000000000000000000000000000000000000000000000470de4df820000000000000000000000000000000000000000000000000000002f5e97571d2000000000000000000000000000000000000000000000000000000bd7a4e75c20000000000000000000000000000000000000000000000000000017af4d8864e0000000000000000000000000000000000000000000000000000017af4d8864e0000000000000000000000000000000000000000000000000000017af4d8864e000000000000000000000000000000000000000000000000000000bd7a4e75c200000000000000000000000000000000000000000000000000000335d5077bec0000000000000000000000000000000000000000000000000000002d79883d200000000000000000000000000000000000000000000000000000002d79883d200000000000000000000000000000000000000000000000000000002d79883d2000000000000000000000000000000000000000000000000000000016bcc41e900000000000000000000000000000000000000000000000000000002d79883d2000000000000000000000000000000000000000000000000000000016bcc41e9000000000000000000000000000000000000000000000000000000016bcc41e9000000000000000000000000000000000000000000000000000000009184e72a00000000000000000000000000000000000000000000000000000038d7ea4c680000000000000000000000000000000000000000000000000000000e35fa931a0000000000000000000000000000000000000000000000000000000e35fa931a0000000000000000000000000000000000000000000000000000000048c2739500000000000000000000000000000000000000000000000000000182e5f00212a00", contractAddress: "", cumulativeGasUsed: "1196460", gasUsed: "1057889", confirmations: "3776935"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_preBuyers", value: [addressList[5],addressList[6],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34]]}, {type: "uint256[]", name: "_preBuyersTokens", value: ["2999999000000000","33958334000000000","26458334000000000","7500000000000000","12500000000000000","416667000000000","416667000000000","1666667000000000","833333000000000","1250000000000000","833333000000000","208333000000000","416667000000000","416667000000000","416667000000000","208333000000000","903614000000000","50000000000000","50000000000000","50000000000000","25000000000000","50000000000000","25000000000000","25000000000000","10000000000000","1000000000000000","250000000000000","250000000000000","5000000000000","6806385000000000"]}], name: "distributePreBuyersRewards", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributePreBuyersRewards(address[],uint256[])" ]( [addressList[5],addressList[6],addressList[7],addressList[8],addressList[9],addressList[10],addressList[11],addressList[12],addressList[13],addressList[14],addressList[15],addressList[16],addressList[17],addressList[18],addressList[19],addressList[20],addressList[21],addressList[22],addressList[23],addressList[24],addressList[25],addressList[26],addressList[27],addressList[28],addressList[29],addressList[30],addressList[31],addressList[32],addressList[33],addressList[34]], ["2999999000000000","33958334000000000","26458334000000000","7500000000000000","12500000000000000","416667000000000","416667000000000","1666667000000000","833333000000000","1250000000000000","833333000000000","208333000000000","416667000000000","416667000000000","416667000000000","208333000000000","903614000000000","50000000000000","50000000000000","50000000000000","25000000000000","50000000000000","25000000000000","25000000000000","10000000000000","1000000000000000","250000000000000","250000000000000","5000000000000","6806385000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1497902112 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "preBuyer", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "TransferredPreBuyersReward", type: "event"} ;
		console.error( "eventCallOriginal[1,1] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x260e5500fbeeb26d3632cca07ca819caa1e29b7a"}, {name: "amount", type: "uint256", value: "2999999000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x70eee2d2f75ed29a62866b80b57c8f2990e1ca36"}, {name: "amount", type: "uint256", value: "33958334000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x002611951ba386db26261142b8f685a26ec91205"}, {name: "amount", type: "uint256", value: "26458334000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x9cc5b4dd8d672da071ebb69a789956b54b820525"}, {name: "amount", type: "uint256", value: "7500000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x508ad1f1511b9bd4ceb89c12514241e3546facd2"}, {name: "amount", type: "uint256", value: "12500000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x13525ce40b1a16a4350a21bae04920a3079412bb"}, {name: "amount", type: "uint256", value: "416667000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xedb0dff82f71647a2757bace9d76969ac4963781"}, {name: "amount", type: "uint256", value: "416667000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xf3374c5d7394db9f84421fb4c7dd3f7a48928b80"}, {name: "amount", type: "uint256", value: "1666667000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xbcef1ec3c78eebcf8bf269118af0ad4cb22c43c4"}, {name: "amount", type: "uint256", value: "833333000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x92af7d428fa7044c38f0ac5c7a4258d3395988ea"}, {name: "amount", type: "uint256", value: "1250000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x898c85ebd232ddb5e27628a7069ab7dcb8a548a4"}, {name: "amount", type: "uint256", value: "833333000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x6ee5408ae077d90a616eb617467939680e1e84ef"}, {name: "amount", type: "uint256", value: "208333000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xfb79bee9184b3427ac60f984fff8ff7bb5fe9771"}, {name: "amount", type: "uint256", value: "416667000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x408ef32d69dc5e71152f776e94059b4d87bdf4cf"}, {name: "amount", type: "uint256", value: "416667000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x74f06a98a33f390b46c521747ccd34d328ccd2f2"}, {name: "amount", type: "uint256", value: "416667000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x69c63cbf504cd8841decc8875d4018df136cd344"}, {name: "amount", type: "uint256", value: "208333000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x00af7a08f0a421f2be1bd659116f03d6c0473ab7"}, {name: "amount", type: "uint256", value: "903614000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x9463f75b8af2eb6de64aec52f8dfbc7c4ad20469"}, {name: "amount", type: "uint256", value: "50000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x5fa079673749104641b0e59388a87c84c2843fe6"}, {name: "amount", type: "uint256", value: "50000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x5bf50c00da77b1f3864cae3c927d029750c040a8"}, {name: "amount", type: "uint256", value: "50000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x0047c20d2ef4998dc2be6bc28967374c7c6a6b5d"}, {name: "amount", type: "uint256", value: "25000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x06905127ecb3f59c46a468489e5b262d7afcc2e8"}, {name: "amount", type: "uint256", value: "50000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xbc411247092da7133ed5a4bfea4cc71e54fe16e0"}, {name: "amount", type: "uint256", value: "25000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xddbd16316e2d9328199579efbdfe9f84aa3cd678"}, {name: "amount", type: "uint256", value: "25000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xb14e4b24b46cd8ceb73bc6a9607004d69b6f564d"}, {name: "amount", type: "uint256", value: "10000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xe9aa55013556590186acdfab4f82919f81c24559"}, {name: "amount", type: "uint256", value: "1000000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xf23dade2097018306a4b91ba82b6017012477e1d"}, {name: "amount", type: "uint256", value: "250000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xb827433d881ee05b025bce6b5144171b76edd4fd"}, {name: "amount", type: "uint256", value: "250000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0x2207f2a9d82130c1fb2f818c3d851bf5ea9255c9"}, {name: "amount", type: "uint256", value: "5000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredPreBuyersReward", events: [{name: "preBuyer", type: "address", value: "0xe35546e159973e3dc637f3ff9438c60d92fb0e07"}, {name: "amount", type: "uint256", value: "6806385000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}] ;
		console.error( "eventResultOriginal[1,1] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: distributeFoundersRewards( [addressList[35],addressList[36],address... )", async function( ) {
		const txOriginal = {blockNumber: "3899755", timeStamp: "1497902137", hash: "0x1172869eabd1eb42398daf16f047cf53a0454f80a09e9bb66fa318094db3460a", nonce: "5", blockHash: "0xa51b546d635d067fb44a38fd522b23fda2e6ffa13f19b6c63094174b73af6d9f", transactionIndex: "3", from: "0xc1ac6dd9a73f39801b4a73f7b98d3ba74ab836b3", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "0", gas: "4500000", gasPrice: "25000000000", isError: "0", txreceipt_status: "", input: "0xb0ebefbc000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000001a000000000000000000000000000000000000000000000000000000000000002e00000000000000000000000000000000000000000000000000000000000000009000000000000000000000000851d020687ab66bb080b60b02114c35f46961e3100000000000000000000000055f99bebfa5e09e48e402b2fa21ad736aa6a1910000000000000000000000000f66cca103fd85f5a7da5107b07870cf1e398d9810000000000000000000000000049b126ff923cf4c868f2b09aa58b798353fa5200000000000000000000000071547706099da06fc8ff089ae3e8027632f9895300000000000000000000000000ea29cb2e2ca58ec093bdc2c1400e91594609cc000000000000000000000000fe00b2407bab3de30eeeea14b719f7455f6e5a060000000000000000000000004c7256cf27a29992a752bd710a859f6542d635460000000000000000000000007c47c2bdbe8307e06e034ee0f3941b483a91e53500000000000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000186cc6acd4b0000000000000000000000000000000000000000000000000000009fdf42f6e48000000000000000000000000000000000000000000000000000005fec5b60ef8000000000000000000000000000000000000000000000000000003ff2e795f5000000000000000000000000000000000000000000000000000000c8ba735dcf400000000000000000000000000000000000000000000000000000ea7aa67b2d0000000000000000000000000000000000000000000000000000002c68af0bb1400000000000000000000000000000000000000000000000000000c3663566a58000000000000000000000000000000000000000000000000000002386f26fc100000000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000005b3238d0000000000000000000000000000000000000000000000000000000005c2229d0", contractAddress: "", cumulativeGasUsed: "2487828", gasUsed: "2377349", confirmations: "3776933"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "_founders", value: [addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43]]}, {type: "uint256[]", name: "_foundersTokens", value: ["110000000000000000","45000000000000000","27000000000000000","18000000000000000","56500000000000000","66000000000000000","12500000000000000","55000000000000000","10000000000000000"]}, {type: "uint256[]", name: "_founderTimelocks", value: ["1530018000","1545742800"]}], name: "distributeFoundersRewards", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "distributeFoundersRewards(address[],uint256[],uint256[])" ]( [addressList[35],addressList[36],addressList[37],addressList[38],addressList[39],addressList[40],addressList[41],addressList[42],addressList[43]], ["110000000000000000","45000000000000000","27000000000000000","18000000000000000","56500000000000000","66000000000000000","12500000000000000","55000000000000000","10000000000000000"], ["1530018000","1545742800"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1497902137 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "vault", type: "address"}, {indexed: false, name: "amount", type: "uint256"}], name: "TransferredFoundersTokens", type: "event"} ;
		console.error( "eventCallOriginal[2,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "TransferredFoundersTokens", events: [{name: "vault", type: "address", value: "0xb96870b4aa01f5f9e8e1aeb3f42916758eb1a5db"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}, {name: "TransferredFoundersTokens", events: [{name: "vault", type: "address", value: "0x3aa13d921857d50cfd4fc921bd4b2f41a6ffc20e"}, {name: "amount", type: "uint256", value: "200000000000000000"}], address: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1"}] ;
		console.error( "eventResultOriginal[2,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3912489", timeStamp: "1498124584", hash: "0x0ccb338f1037284aaf979d7e1aea704779753888b21c8a58f7a9137a44dfc6c3", nonce: "0", blockHash: "0x398e5f1df8707c77c0ee71e4a227d082c792dc42ee94c12afbd7be36a6eb1ed8", transactionIndex: "12", from: "0xef76677ac59c5d47775024803c8cc2da6539d6dd", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "88000000000000000000", gas: "100000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "374806", gasUsed: "100000", confirmations: "3764199"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[44], to: addressList[2], value: "88000000000000000000" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[44], balance: "819692000000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[44], balance: ( await web3.eth.getBalance( addressList[44], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3913136", timeStamp: "1498136175", hash: "0x615c455feb8ee1d838610780b620a2a2b6501fa0c4e9c0ccec48afa22d66017f", nonce: "10", blockHash: "0x38d3a5b4add6cd1c8a0496a60ece409d948283fede23d9c4f46b3f568fe6a9e2", transactionIndex: "3", from: "0xc789c36bf5cb223f0446e1de95519ae757762f13", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1000000000000", gas: "100000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "340073", gasUsed: "100000", confirmations: "3763552"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[45], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[45], balance: "49543724000000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[45], balance: ( await web3.eth.getBalance( addressList[45], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3913322", timeStamp: "1498139574", hash: "0x2a153f6adfabdcec1bcb1bf22b5887ee9225fb1a318acbf222bfd4a7701f5eb1", nonce: "1", blockHash: "0x6b521af4d84d727b23fe48c7fe1e3f0095f922d7466f5acf30a775144216c5f7", transactionIndex: "21", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "100000000000000", gas: "100000", gasPrice: "46908618288", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "1737576", gasUsed: "100000", confirmations: "3763366"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3913561", timeStamp: "1498144206", hash: "0x34f8df02d7b0220aee8cc1718be290f29ff507485e39fa60cb9db2993ee6e0e1", nonce: "2", blockHash: "0xee4167fbc933f695deec39492d94dbc5285c70e666e493f90cad0308bdf5743f", transactionIndex: "2", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "100000000000", gas: "100000", gasPrice: "100000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "142000", gasUsed: "100000", confirmations: "3763127"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "100000000000" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3913712", timeStamp: "1498146984", hash: "0xd3fa13bd8574a966deabc5d4083dbc249ac98e6e40e1fcba7d7c61952c691614", nonce: "3", blockHash: "0x7abfb0563795f08398d6108574374e8bf205435ba10b39a0315c2e11a76a2700", transactionIndex: "0", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "100000000000", gas: "100000", gasPrice: "100097078777", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "100000", gasUsed: "100000", confirmations: "3762976"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "100000000000" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3913732", timeStamp: "1498147364", hash: "0x68b7ccf8ffa600e88aa426f33e8a4fd99402dd9042af5ddef7ebee3375f4c48b", nonce: "4", blockHash: "0x148150383bae1d6660492fdff71b90045b36dace7c67950055fefe2b8b8711c3", transactionIndex: "0", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "100000000000", gas: "100000", gasPrice: "200000000100", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "100000", gasUsed: "100000", confirmations: "3762956"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "100000000000" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3913772", timeStamp: "1498148021", hash: "0x0427684faae5da3950ad7b39807edd8eb3836ee45c0ff4f2ec3f1c6bbfbc530d", nonce: "5", blockHash: "0xce7a55bebd902ef634e25af18cc7d90eb213a5d054b3b928c6869c83559b0960", transactionIndex: "0", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1000000000000", gas: "100000", gasPrice: "80000000010", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "100000", gasUsed: "100000", confirmations: "3762916"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3913782", timeStamp: "1498148142", hash: "0xd626bf75b88ce7c86da4069bee94aa26fb56bd5b6d3e139aab53abed8cfc48ee", nonce: "6", blockHash: "0x2f5576d571c8007b97be5e6da3a71ec9b965e0fb68de7126bf7ea49e721a5d79", transactionIndex: "5", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "10000000000000", gas: "100000", gasPrice: "80000000010", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "720108", gasUsed: "100000", confirmations: "3762906"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3916804", timeStamp: "1498201249", hash: "0x0ba76e1e545f8eb1712b92d55c3ab3074e36be58d63fcc489e8b917793a292a7", nonce: "0", blockHash: "0x3daa5226dc23b067bdd540ae1c64a4c0ecfb4fe8517f3459348da8ae71f5ed48", transactionIndex: "83", from: "0x8f464cf6e81724a999af630b284b9a21bb657eea", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1150000000000000000", gas: "21272", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "2337906", gasUsed: "21272", confirmations: "3759884"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "1150000000000000000" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "0" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3916815", timeStamp: "1498201477", hash: "0x2538ea14110aa71cabcdd0e8e222f6afd316998616b0b8bf13325ca9abfd788c", nonce: "1", blockHash: "0x3fda9facd925683dc2985eb461ede62a133ec659718f66a3bc07e1b2ef701169", transactionIndex: "29", from: "0x8f464cf6e81724a999af630b284b9a21bb657eea", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1150000000000000000", gas: "21272", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "630272", gasUsed: "21272", confirmations: "3759873"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "1150000000000000000" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "0" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3916863", timeStamp: "1498202328", hash: "0x6eee98c09c77a26be9ecdb00309c5d7aa5b3e9e3eeeff12fe28d2d47411632da", nonce: "2", blockHash: "0x8ec44f338cc2ba581e73196a2d9ee1a967150b3ec60c4a340a977266d2e7a79e", transactionIndex: "115", from: "0x8f464cf6e81724a999af630b284b9a21bb657eea", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1180000000000000000", gas: "21272", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "3751527", gasUsed: "21272", confirmations: "3759825"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "1180000000000000000" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "0" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3917094", timeStamp: "1498206292", hash: "0x72d390d45772d35c357d3117eef6ec3e2ef499d746a5a560bb24026e338d4f79", nonce: "3", blockHash: "0x66649485c6c3e37b4aa978b9e872221e6d43880fb8f9b18dc06ef67626d9afa0", transactionIndex: "37", from: "0x8f464cf6e81724a999af630b284b9a21bb657eea", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1190000000000000000", gas: "21272", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "1557528", gasUsed: "21272", confirmations: "3759594"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[47], to: addressList[2], value: "1190000000000000000" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[47], balance: "0" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[47], balance: ( await web3.eth.getBalance( addressList[47], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918212", timeStamp: "1498225759", hash: "0x924021067f1c1ed667a6c870b014e60e7043e8fb65110b2fe7e71f70177669e2", nonce: "7", blockHash: "0x5cd28ff6ff926ed5b2eb11be9f88fc1e8a8d9bab5da067e39395fd115e60f5be", transactionIndex: "15", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1000000000000", gas: "100000", gasPrice: "51000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "599508", gasUsed: "100000", confirmations: "3758476"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918222", timeStamp: "1498225918", hash: "0xb909c46c30bfd062550387db8eb1b426bbf3856de1eca5c81524267796319d03", nonce: "8", blockHash: "0xe9e6afa842c9067a521df6f58a3df6cd08f375ae10a30cae7150edd271314c5b", transactionIndex: "17", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1000000000000", gas: "100000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "484247", gasUsed: "100000", confirmations: "3758466"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918232", timeStamp: "1498226105", hash: "0xf8d4382b3d33b2500d2ce80869dde1e40eaee5fe32f7277958a76b67596585ba", nonce: "9", blockHash: "0x724f88aeae59def139c46a8c2cdecaca1fe4854105791905f8ef2d368c1f67c8", transactionIndex: "3", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "100000000000", gas: "100000", gasPrice: "52000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "194344", gasUsed: "100000", confirmations: "3758456"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "100000000000" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918382", timeStamp: "1498228874", hash: "0xb5a04a490fb7a92db005ef76eba6952d27e8444d17ce25b4952c11a9cf66e9dd", nonce: "10", blockHash: "0x833efc66b2a5ceaa281f1894da9f18b625c33e9114f70f2ae2f430e808d4d23a", transactionIndex: "61", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1000000000000", gas: "100000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "2014960", gasUsed: "100000", confirmations: "3758306"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918392", timeStamp: "1498229013", hash: "0xd12e5d7f32a6940c068708223e46cb9a8f234f664c34e31d39f865dc52c545fe", nonce: "11", blockHash: "0x743d608725c3e011af47516f2261bc3a1c639cb5d3137daff86ffa101f19bab4", transactionIndex: "35", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1000000000000", gas: "100000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "1335134", gasUsed: "100000", confirmations: "3758296"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "1000000000000" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918402", timeStamp: "1498229274", hash: "0xee927f0d370364ce920ea5e9c3b27854df48bbd432b0565885036fdbc0e2c681", nonce: "12", blockHash: "0xc6b4d1f05d53948786f9d8abb25d5872e94d762caafca4c8e8102891523a7451", transactionIndex: "52", from: "0x005c1bc72df1b10581a4125520c36e650e13df20", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "100000000000", gas: "100000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "2269312", gasUsed: "100000", confirmations: "3758286"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[46], to: addressList[2], value: "100000000000" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[46], balance: "0" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[46], balance: ( await web3.eth.getBalance( addressList[46], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918740", timeStamp: "1498234728", hash: "0x9c54153bfd99087a6973d60746686da57b05ad14deea765d0883a00ed98ea3e1", nonce: "0", blockHash: "0x4e079a301472a8ff748226e3137d4870570432cfab52aeb66cba3a984c5431ca", transactionIndex: "52", from: "0xd13db656a5166b8476fd6de32f76222417bba2c1", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "400000000000000000", gas: "100000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "2088684", gasUsed: "100000", confirmations: "3757948"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "400000000000000000" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "27052147000000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918875", timeStamp: "1498236901", hash: "0x3e0352e8ee6235b68e1a4aac2c48a5b12325148e70f6f736ee3c4090261eabc5", nonce: "6", blockHash: "0x1d6f204320b236c1f63bd5c1777c969185c2f31c6ef34fdc2dc918260a62ef97", transactionIndex: "35", from: "0x2da86fd3c3f2cc1cc8c1339edd9bd9bde1f3822d", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "10000000000000000000", gas: "100000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "2809348", gasUsed: "100000", confirmations: "3757813"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "151537220811449860" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918903", timeStamp: "1498237359", hash: "0x76a8068e45c90b91c86687ca44ad487e33dcd88861cc7242c8fcbb908abb5ccb", nonce: "7", blockHash: "0x27e28583855619da036a7eb0d7e5c40a17d3230952eb3c85b2d91bec26d5e626", transactionIndex: "76", from: "0x2da86fd3c3f2cc1cc8c1339edd9bd9bde1f3822d", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "10000000000000000000", gas: "100000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "2351586", gasUsed: "100000", confirmations: "3757785"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "151537220811449860" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918915", timeStamp: "1498237599", hash: "0x068c1891a4f0bc4eb7ff56091bdf7bedebd6504306cdcb58a5b16504369492a1", nonce: "8", blockHash: "0x0a88128d6d29b0946fb8c5e6c6850f0203ebae9daefa6fe4e4a86d6ef0148579", transactionIndex: "31", from: "0x2da86fd3c3f2cc1cc8c1339edd9bd9bde1f3822d", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "10000000000000000000", gas: "100000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "1892076", gasUsed: "100000", confirmations: "3757773"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "151537220811449860" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918951", timeStamp: "1498238128", hash: "0xb696b1225a742accf43d2b2e768172eeb6b1900f9e72e61f5e3d02eafa92fb09", nonce: "9", blockHash: "0x75ed73ecf65fe51b1e27a9df0cc27cfc052ec3a0e0770ad990db385f4e3d89f5", transactionIndex: "31", from: "0x2da86fd3c3f2cc1cc8c1339edd9bd9bde1f3822d", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "10000000000000000000", gas: "100000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "1360054", gasUsed: "100000", confirmations: "3757737"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "151537220811449860" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3918993", timeStamp: "1498238750", hash: "0xa751c6c895f3306571412c13e24a1d35ab399fedb3d363f8b0f0ba728b4b787e", nonce: "10", blockHash: "0x406de3a7efeb7aeafb1e07ad7184b68f7db2b41fd5255d792d78ec61424928a0", transactionIndex: "23", from: "0x2da86fd3c3f2cc1cc8c1339edd9bd9bde1f3822d", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "10000000000000000000", gas: "100000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "3089555", gasUsed: "100000", confirmations: "3757695"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[49], to: addressList[2], value: "10000000000000000000" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[49], balance: "151537220811449860" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[49], balance: ( await web3.eth.getBalance( addressList[49], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3919051", timeStamp: "1498240004", hash: "0x29c8281c1f15c4cc7a7bf7f7cc3bfccf73382caf2bb99a02cc46d28ea948b7ea", nonce: "1", blockHash: "0xd055266bc29d04db7323ebe41876b1b26d06a05cd7b675f0a48628d1d1d9e5dd", transactionIndex: "46", from: "0xd13db656a5166b8476fd6de32f76222417bba2c1", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "300000000000000000", gas: "100000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "3899505", gasUsed: "100000", confirmations: "3757637"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "300000000000000000" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "27052147000000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3919062", timeStamp: "1498240170", hash: "0xa0dd2050409eeea8467fee01d6cb42163756956e9216a23cf645281f419f9420", nonce: "2", blockHash: "0x866544ca991c20cb5e24d25e5b460d98223312c497309ad2a61699f5b84cf5ed", transactionIndex: "2", from: "0x00f866241cb94ece61b1e16a46457e801e4fd38b", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "100000000000000", gas: "100000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "165074", gasUsed: "100000", confirmations: "3757626"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[50], to: addressList[2], value: "100000000000000" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[50], balance: "2373302026455590977" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[50], balance: ( await web3.eth.getBalance( addressList[50], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3919108", timeStamp: "1498240941", hash: "0x6745ec8041436167c5587bdefa382752a85c482cde690e68848d2c02982db00f", nonce: "2", blockHash: "0xaff5a6f83c091401e930cab01439253baf1bbf6ee8091f59d0321ed062145c2a", transactionIndex: "88", from: "0xd13db656a5166b8476fd6de32f76222417bba2c1", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "350000000000000000", gas: "100000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "4441052", gasUsed: "100000", confirmations: "3757580"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[48], to: addressList[2], value: "350000000000000000" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[48], balance: "27052147000000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[48], balance: ( await web3.eth.getBalance( addressList[48], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3919132", timeStamp: "1498241430", hash: "0xcdfe0f84d836870efa17306043e17f0e3fa68e49a8d6d19c862118075fdcfc6e", nonce: "3", blockHash: "0x6df8654d52787db6ccc32a5a467789ed3a6571a7bb1427a64347be4d6e6477e1", transactionIndex: "45", from: "0x00890dfa0bd28f631df9d99fa617625e43120163", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1000000000000000", gas: "100000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "1395415", gasUsed: "100000", confirmations: "3757556"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[51], to: addressList[2], value: "1000000000000000" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[51], balance: "16667537568759000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[51], balance: ( await web3.eth.getBalance( addressList[51], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3919177", timeStamp: "1498242261", hash: "0x08e069f9036f5a974e706ed7880b7c3632267a2e9f7403a2fc7df23132aa0167", nonce: "0", blockHash: "0xab3985535409c3221b1d707d6faac826df3eeaea34ee0bae54a209d863a449aa", transactionIndex: "1", from: "0xca02fa3188fcd3e081b66c4c961bb036bb0049e6", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "900000000000000", gas: "100000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "121000", gasUsed: "100000", confirmations: "3757511"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[52], to: addressList[2], value: "900000000000000" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[52], balance: "5000000000000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[52], balance: ( await web3.eth.getBalance( addressList[52], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3919810", timeStamp: "1498253737", hash: "0x1056a648d3f3aaf87ea40cd6480dd377fd79c2674686ec40cb04a1eaee09b2e6", nonce: "2", blockHash: "0xb8e2dbd06f01ae25bb62e2de0d4275e93dcc6d2e4894fa0b7e9d3fb218cb359b", transactionIndex: "11", from: "0x0042787221ddc2d9b4f9f3bcf29fbd461dabcdce", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "10000000000000000", gas: "50000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "334880", gasUsed: "50000", confirmations: "3756878"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[53], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[53], balance: "7277245189651884000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[53], balance: ( await web3.eth.getBalance( addressList[53], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3920002", timeStamp: "1498256887", hash: "0x251ff3624868b9aaf4cb4da8e34c1193949bb96855c13eeaeace3b44b442c9b6", nonce: "0", blockHash: "0x712d23df819e994744fbfa1147d220b6c568d370e25c83b2b71f6b51d3269c12", transactionIndex: "1", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "0", gas: "90000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "111000", gasUsed: "90000", confirmations: "3756686"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3920002", timeStamp: "1498256887", hash: "0x82e5358b22aedffffa54ef7c04460eb5bd343fdc9b0b3d0c164e2ac4d66eea77", nonce: "1", blockHash: "0x712d23df819e994744fbfa1147d220b6c568d370e25c83b2b71f6b51d3269c12", transactionIndex: "15", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "0", gas: "90000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "583365", gasUsed: "90000", confirmations: "3756686"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3920002", timeStamp: "1498256887", hash: "0xb53f4af1d410285b1cf578452dcd389e08690b2bcf961564691deb2f86f5d32b", nonce: "2", blockHash: "0x712d23df819e994744fbfa1147d220b6c568d370e25c83b2b71f6b51d3269c12", transactionIndex: "17", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "0", gas: "90000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "694365", gasUsed: "90000", confirmations: "3756686"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3920022", timeStamp: "1498257219", hash: "0xae3f6fae3528af82882652eab891b51f12fba3650590b444a0d7d04e89842257", nonce: "3", blockHash: "0xcc9e022662621769c4e9ca6531b7fac069c4c36f13b750070da1c03435a179d1", transactionIndex: "18", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "0", gas: "90000", gasPrice: "50000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "622240", gasUsed: "90000", confirmations: "3756666"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: changeWallet( addressList[55] )", async function( ) {
		const txOriginal = {blockNumber: "3923620", timeStamp: "1498320767", hash: "0xe91d05a2904cc1122974fcca2df551b5c33aa5ee8a4270febb2600aaf941a865", nonce: "7", blockHash: "0xc8352f98c4dc0104fd528d790258a1f98cfd48c62373c3c1532cb79d9b226ee3", transactionIndex: "29", from: "0xc1ac6dd9a73f39801b4a73f7b98d3ba74ab836b3", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "0", gas: "100000", gasPrice: "21000000000", isError: "0", txreceipt_status: "", input: "0x98b9a2dc000000000000000000000000823f327e1b4551ee278a8ca135e27a69793f1d58", contractAddress: "", cumulativeGasUsed: "3384783", gasUsed: "28857", confirmations: "3753068"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "_wallet", value: addressList[55]}], name: "changeWallet", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "changeWallet(address)" ]( addressList[55], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1498320767 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "0" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3923778", timeStamp: "1498323528", hash: "0x848d367f3624502438288e02a1358162018eec74b5af7643d2c58effabdf6ee3", nonce: "0", blockHash: "0xaa545d94210752ee5d05eb076bcb876a3dd9e031dcaed3245d80b331f6eb0c5a", transactionIndex: "25", from: "0x34a52ad4e1885837e41c606caef3a3bb6d7dc8dd", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "7000000000000000", gas: "100000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "1977078", gasUsed: "100000", confirmations: "3752910"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[56], to: addressList[2], value: "7000000000000000" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[56], balance: "7900000000000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[56], balance: ( await web3.eth.getBalance( addressList[56], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3924497", timeStamp: "1498335724", hash: "0x67714d4756ffebc69ed01e31ab84e7c9691d27c166809c0cf0c2160096293df7", nonce: "4", blockHash: "0xd9678120ad899035547866addf6492547db6d0086ad81850a792d6e58050da77", transactionIndex: "33", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "500000000000000000", gas: "90000", gasPrice: "31000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "2080630", gasUsed: "90000", confirmations: "3752191"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "3924593", timeStamp: "1498337488", hash: "0xb5794009ee44a7b88fd0d754a1756848c1fc20e29d96d7cdf462600f12ce82d9", nonce: "38", blockHash: "0x7de53ad9e91c7ba593807de1891b01777e99809ba5fe8dd0707039fbada7a58f", transactionIndex: "3", from: "0x765fdcbaa945c2f73dae083770dd0aedfa386d5a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "10000000000000000", gas: "25200", gasPrice: "99999997952", isError: "1", txreceipt_status: "", input: "0x", contractAddress: "", cumulativeGasUsed: "117542", gasUsed: "25200", confirmations: "3752095"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[57], to: addressList[2], value: "10000000000000000" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[57], balance: "1649881011591322507" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[57], balance: ( await web3.eth.getBalance( addressList[57], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3924603", timeStamp: "1498337766", hash: "0xa01c97b56e815c388dd0f4c53c31f8cf5ebaa72874909102cd60c0f68c7fde90", nonce: "5", blockHash: "0x4b7785aee4454df62f87f280aac3c36965ef3f35248fed60cba919a0460a09f5", transactionIndex: "23", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "500000000000000000", gas: "90000", gasPrice: "31000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "1712016", gasUsed: "90000", confirmations: "3752085"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3925256", timeStamp: "1498348929", hash: "0x13b60e89fb182aa77d2f5b4fd3e383aec296f76fa40e129fed9db21da789c508", nonce: "6", blockHash: "0xfa41867337430e7b18d149f08f2419c1b106e5288107747b39dc2a544b3aa1d6", transactionIndex: "8", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "500000000000000000", gas: "90000", gasPrice: "21000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "472172", gasUsed: "90000", confirmations: "3751432"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3925307", timeStamp: "1498349921", hash: "0xf73a01f46b2a223b5e2340caa9b50158f19eaecd85bff71f104ec73b70177a74", nonce: "7", blockHash: "0x24bc019d9f4b3a19e97b756d84f32680ced167a7042d94ea14f72f993ff3051e", transactionIndex: "67", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "500000000000000000", gas: "90000", gasPrice: "23000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "3482371", gasUsed: "90000", confirmations: "3751381"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3925320", timeStamp: "1498350123", hash: "0x7cd0a124ac1bb888c5b8924ac380bd1fbea76dd11214f47aa879f411f8192406", nonce: "8", blockHash: "0xe5d3b57bd6a10368e40b785a877c66064a30dd59825f10458bff97ba95d8d1e2", transactionIndex: "34", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "500000000000000000", gas: "90000", gasPrice: "23000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "3407326", gasUsed: "90000", confirmations: "3751368"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3925340", timeStamp: "1498350393", hash: "0xedaecf3b4f628951c3014f9fc3ecc6f63e502869ddfdcd1bf5d2cfbd957fe136", nonce: "9", blockHash: "0x9bbc921a1773e78e38c658d52d2f60888c20bf3cd29b5cfeee66cc1ed7209b5f", transactionIndex: "9", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "500000000000000000", gas: "100000", gasPrice: "23000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "910546", gasUsed: "100000", confirmations: "3751348"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3925351", timeStamp: "1498350510", hash: "0x6c96aeb222682a1545b17060e80d169f5196989624d00189dd4d8ce8f322684d", nonce: "10", blockHash: "0xdc74fb69d49ba84233fb3b4693f46a8b26f69fcede8eb7c7f754d62ff2fc40b2", transactionIndex: "40", from: "0xfad5c3f26deeeb78cbe91a5ff45ee6316a5ab34a", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "500000000000000000", gas: "100000", gasPrice: "12000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "1711887", gasUsed: "100000", confirmations: "3751337"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[54], to: addressList[2], value: "500000000000000000" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[54], balance: "2042820244808800000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[54], balance: ( await web3.eth.getBalance( addressList[54], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3926205", timeStamp: "1498365575", hash: "0x8476696c1a0e6f534c4ec4505eb9e44be6595d0403e7d34d42a3f1f3ca2b8a42", nonce: "1", blockHash: "0x275b01b4a571aa300f65e246b479776c66bb4a5e82237ea847237771f982535b", transactionIndex: "74", from: "0xe881587e0446db2de272b5a82874a9cfa37e97b1", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "12000000000000000000", gas: "100000", gasPrice: "28000000000", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "2216097", gasUsed: "100000", confirmations: "3750483"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[58], to: addressList[2], value: "12000000000000000000" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[58], balance: "39336614782091872782" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[58], balance: ( await web3.eth.getBalance( addressList[58], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3926518", timeStamp: "1498370607", hash: "0xec2ba77389b67a163cfb3f1a2ae3c6b0b96af78461f0148c74dbcdb75e98f513", nonce: "28", blockHash: "0x489adeae5e670b8e462ba74de57ae31b4e8355ad5cbe4ca5ed4ee12dabd05435", transactionIndex: "10", from: "0xea3a9ed81f0dedd5d12a797bc5854e652578aa84", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "10000000000000", gas: "25600", gasPrice: "33744005564", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "294522", gasUsed: "25600", confirmations: "3750170"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[59], to: addressList[2], value: "10000000000000" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[59], balance: "1052777750122178047974" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[59], balance: ( await web3.eth.getBalance( addressList[59], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: purchaseTokens(  )", async function( ) {
		const txOriginal = {blockNumber: "3926685", timeStamp: "1498373246", hash: "0x196fbeaefc503c8165d03e28b58c19f1f2354480f2baa854cacfc22970a4d44b", nonce: "0", blockHash: "0x964a90229b92c2fe8f00ae60797fadf1b2bced25841b9a63a4550aeba555ce1c", transactionIndex: "31", from: "0x1982581a3cd5c0124127c6ca94d1e00c6beb3249", to: "0x5678bcea6d6f33f645dca8c8c9b7d8d5caf0a2b1", value: "1900003926676999936", gas: "100000", gasPrice: "20309717837", isError: "1", txreceipt_status: "", input: "0x3290ce29", contractAddress: "", cumulativeGasUsed: "2365634", gasUsed: "100000", confirmations: "3750003"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[60], to: addressList[2], value: "1900003926676999936" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "purchaseTokens", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		txRequest = { receipt: { isError: 1, message: "Original out of gas, replay skipped" }, blockNumber: "latest", logs: [] } ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[60], balance: "0" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "0" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[60], balance: ( await web3.eth.getBalance( addressList[60], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
