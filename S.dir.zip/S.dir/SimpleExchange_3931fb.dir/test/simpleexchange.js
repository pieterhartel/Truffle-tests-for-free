const SimpleExchange = artifacts.require( "./SimpleExchange.sol" ) ;
const web3Utils = require( "web3-utils" ) ;
const support = require( "./support.js" ) ;

const maxRandom = 10 ;
const randomSeed = 0 ;
const random = require( "random-seed" ).create( randomSeed ) ;


console.error( "var addressList ;" ) ;
console.error( "var addressListOriginal ;" ) ;
console.error( "var block = [] ;" ) ;
console.error( "var constructorPrototypeOriginal ;" ) ;
console.error( "var contractAddress ;" ) ;
console.error( "var contractName ;" ) ;
console.error( "var createTransactionHash ;" ) ;
console.error( "var eventCall = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventCallOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventPrototypeList ;" ) ;
console.error( "var eventPrototypeListOriginal ;" ) ;
console.error( "var eventResult = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventResultOriginal = new Array( 50 ).fill( [] ) ;" ) ;
console.error( "var eventSignatureListOriginal ;" ) ;
console.error( "var fromBalance = [] ;" ) ;
console.error( "var fromBalanceOriginal = [] ;" ) ;
console.error( "var fromBlockOriginal ;" ) ;
console.error( "var methodCall = [] ;" ) ;
console.error( "var methodPrototypeList ;" ) ;
console.error( "var methodPrototypeListOriginal ;" ) ;
console.error( "var methodResult = [] ;" ) ;
console.error( "var nBlocksOriginal ;" ) ;
console.error( "var toBalance = [] ;" ) ;
console.error( "var toBalanceOriginal = [] ;" ) ;
console.error( "var toBlockOriginal ;" ) ;
console.error( "var topicListOriginal ;" ) ;
console.error( "var txCall = [] ;" ) ;
console.error( "var txDeployer ;" ) ;
console.error( "var txOptions = [] ;" ) ;
console.error( "var txOriginal = [] ;" ) ;
console.error( "var txResult = [] ;" ) ;
console.error( "var txTime = [] ;" ) ;

const contractName = "SimpleExchange" ;
console.error( "contractName = %s", JSON.stringify( contractName ) ) ;

const addressListOriginal = ["0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "0x4426d15AD435c156eDc1183938ff47B37D3931Fb", "0x08712307A86632b15d13ECfEBe732c07Cc026915", "0xaE38c27E646959735ec70d77ED4eCc03A3EFf490", "0x61646f3BEdE9E1A24D387Feb661888B4cc1587d8", "0x0B7dc5A43Ce121b4EaaA41b0F4f43BBA47Bb8951", "0x7C725f972D1ebDEF5Bbfd8996d3Cbe307b23cd42", "0xA823E6722006afe99E91c30FF5295052fe6b8E32", "0x8601034a23E834a807AeDC2628e589c35f4c0FFd"] ;
console.error( "addressListOriginal = %s", JSON.stringify( addressListOriginal ) ) ;
console.error( "addressListOriginal.length = %d", addressListOriginal.length ) ;

const methodPrototypeListOriginal = [{constant: true, inputs: [], name: "contractId", outputs: [{name: "id", type: "bytes32"}, {name: "version", type: "uint256"}], payable: false, stateMutability: "pure", type: "function"}, {constant: true, inputs: [{name: "numeratorTokens", type: "address[]"}, {name: "denominatorTokens", type: "address[]"}], name: "getExchangeRates", outputs: [{name: "rateFractions", type: "uint256[]"}, {name: "timestamps", type: "uint256[]"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [{name: "numeratorToken", type: "address"}, {name: "denominatorToken", type: "address"}], name: "getExchangeRate", outputs: [{name: "rateFraction", type: "uint256"}, {name: "timestamp", type: "uint256"}], payable: false, stateMutability: "view", type: "function"}, {constant: true, inputs: [], name: "accessPolicy", outputs: [{name: "", type: "address"}], payable: false, stateMutability: "view", type: "function"}] ;
console.error( "methodPrototypeListOriginal = %s", JSON.stringify( methodPrototypeListOriginal ) ) ;

const eventPrototypeListOriginal = [{anonymous: false, inputs: [{indexed: false, name: "controller", type: "address"}, {indexed: false, name: "oldPolicy", type: "address"}, {indexed: false, name: "newPolicy", type: "address"}], name: "LogAccessPolicyChanged", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "gasRecipient", type: "address"}, {indexed: false, name: "amountEurUlps", type: "uint256"}, {indexed: false, name: "exchangeFeeFrac", type: "uint256"}, {indexed: false, name: "amountWei", type: "uint256"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogGasExchange", type: "event"}, {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"}, {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "LogReceivedEther", type: "event"}] ;
console.error( "eventPrototypeListOriginal = %s", JSON.stringify( eventPrototypeListOriginal ) ) ;

const eventSignatureListOriginal = ["LogAccessPolicyChanged(address,address,address)", "LogGasExchange(address,uint256,uint256,uint256,uint256)", "LogSetExchangeRate(address,address,uint256)", "LogReceivedEther(address,uint256,uint256)"] ;
console.error( "eventSignatureListOriginal = %s", JSON.stringify( eventSignatureListOriginal ) ) ;

const topicListOriginal = ["0x7d475c32583df95fccc34a6e12df24c1fc9943092cc129b6512013aecba0f136", "0x68e7498f69f8111a2f38ea9fcdd9ec33aa072c3ee3e4c665981b416f82b3f0e3", "0x1d89fb077bf2ce0a703a51c0422f114127b7ef7b0cc4315d5b2eb6bdf45f027a", "0x633d9fea77720aaf2e5fa116283184d790773f86cb47f83e32a613a0f7afc3b4"] ;
console.error( "topicListOriginal = %s", JSON.stringify( topicListOriginal ) ) ;

const nBlocksOriginal = 50 ;
console.error( "nBlocksOriginal = %s", nBlocksOriginal ) ;

const fromBlockOriginal = 6690921 ;
console.error( "fromBlockOriginal = %s", fromBlockOriginal ) ;

const toBlockOriginal = 6694024 ;
console.error( "toBlockOriginal = %s", toBlockOriginal ) ;

const constructorPrototypeOriginal = {inputs: [{type: "address", name: "accessPolicy", value: 4}, {type: "address", name: "euroToken", value: 5}, {type: "address", name: "etherToken", value: 6}], name: "SimpleExchange", outputs: [], type: "function"} ;
console.error( "constructorPrototypeOriginal = %s", JSON.stringify( constructorPrototypeOriginal ) ) ;

var addressList = null ;
var deployedContract = "address(this)" ;
var eventPrototypeList = null ;

function convertAddress( theAddress ) {
	if( theAddress === 0 || theAddress.match( /^0x0*$/ ) ) {
		return "0x0000000000000000000000000000000000000000" ;
	} else if( theAddress === 1 || theAddress.match( /^0x0*1$/ ) ) {
		return "0x0000000000000000000000000000000000000001" ;
	} else if( theAddress === "address(this)" ) {
		return "address(this)" ;
	} else {
		try {
			return web3.utils.toChecksumAddress( theAddress ) ;
		} catch( error ) {
			return theAddress ;
		}
	}
}

function mergeEvent( call, result ) {
	var merge = { inputs: [], name: call.name, outputs: [], type: call.type } ;
	for( var i = 0; i < call.inputs.length; i++ ) {
		const item = result[ call.inputs[ i ].name ] ;
		if( typeof item !== "undefined" ) {
			merge.outputs[ i ] = { name: call.inputs[ i ].name, type: call.inputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

function mergeCall( call, args ) {
	var merge = { inputs: call.inputs, name: call.name, outputs: [], type: call.type } ;
	if( typeof args.isError !== 'undefined' ) {
		merge.isError = args.isError ;
		merge.message = args.message ;
	} else if( call.outputs.length === 1 ) {
		merge.outputs[ 0 ] = { name: call.outputs[ 0 ].name, type: call.outputs[ 0 ].type, value: ( args === null ? "null" :
				( typeof args.toString === "undefined" ? args : args.toString( 10, 85 ) ) ) } ;
	} else {
		for( var i = 0; i < call.outputs.length; i++ ) {
			const item = args[ i ] ;
			merge.outputs[ i ] = { name: call.outputs[ i ].name, type: call.outputs[ i ].type, value: ( item === null ? "null" :
				( typeof item.toString === "undefined" ? item : item.toString( 10, 85 ) ) ) } ;
		}
	}
	return merge ;
}

async function constantFunction( txIndex, deployedContract ) {
	var methodCall, methodArgs, methodResult ;
	methodCall = {inputs: [], name: "contractId", outputs: [{name: "id", type: "bytes32"}, {name: "version", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",0] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "contractId()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",0] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[ random.range( addressList.length - 3 ) + 3 ]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[ random.range( addressList.length - 3 ) + 3 ]]}], name: "getExchangeRates", outputs: [{name: "rateFractions", type: "uint256[]"}, {name: "timestamps", type: "uint256[]"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",1] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getExchangeRates(address[],address[])" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",1] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [{type: "address", name: "numeratorToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}, {type: "address", name: "denominatorToken", value: addressList[ random.range( addressList.length - 3 ) + 3 ]}], name: "getExchangeRate", outputs: [{name: "rateFraction", type: "uint256"}, {name: "timestamp", type: "uint256"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",2] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "getExchangeRate(address,address)" ]( methodCall.inputs[ 0 ].value,methodCall.inputs[ 1 ].value ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",2] = %s", JSON.stringify( methodResult ) ) ;
	methodCall = {inputs: [], name: "accessPolicy", outputs: [{name: "", type: "address"}], type: "function"} ;
	console.error( "methodCall[" + txIndex + ",3] = %s", JSON.stringify( methodCall ) ) ;
	try {
		methodArgs = await deployedContract.methods[ "accessPolicy()" ](  ) ;
	} catch( methodError ) {
		methodArgs = { isError: 1, message: methodError.message } ;
	}
	methodResult = mergeCall( methodCall, methodArgs ) ;
	console.error( "methodResult[" + txIndex + ",3] = %s", JSON.stringify( methodResult ) ) ;
}

contract( "SimpleExchange", function( accounts ) {

	it( "TEST: SimpleExchange( addressList[4], addressList[5], addressL... )", async function( ) {
		await support.minerStop( ) ;
		addressList = [ "0x0000000000000000000000000000000000000000", "0x0000000000000000000000000000000000000001", "address(this)" ].concat( accounts ).map( item => convertAddress( item ) ) ;
		const txOriginal = {blockNumber: "6690921", timeStamp: "1542029278", hash: "0xd8ed365c0077a8824aa6ad79bb623632ef05a1cc15c3b9bc1daf6fd596d8e116", nonce: "8", blockHash: "0x2d0512f8bd63c11f58af9049fe942373e58f49a23d51dbcf511c559205f53db2", transactionIndex: "24", from: "0x08712307a86632b15d13ecfebe732c07cc026915", to: 0, value: "0", gas: "6500000", gasPrice: "7000000000", isError: "0", txreceipt_status: "1", input: "0x510a7123000000000000000000000000ae38c27e646959735ec70d77ed4ecc03a3eff49000000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d80000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951", contractAddress: "0x4426d15ad435c156edc1183938ff47b37d3931fb", cumulativeGasUsed: "2850611", gasUsed: "1638605", confirmations: "1025833"} ;
		console.error( "txOriginal[0] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[3], to: 0, value: "0" }
		console.error( "txOptions[0] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address", name: "accessPolicy", value: addressList[4]}, {type: "address", name: "euroToken", value: addressList[5]}, {type: "address", name: "etherToken", value: addressList[6]}], name: "SimpleExchange", outputs: [], type: "function"} ;
		console.error( "txCall[0] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = SimpleExchange.new( addressList[4], addressList[5], addressList[6], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 0, 1542029278 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		if( typeof txResult.receipt !== 'undefined' ) {
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
			process.exit( 1 ) ;
		} else {
			deployedContract = txResult;
			const txReceipt = await web3.eth.getTransactionReceipt( deployedContract.transactionHash ) ;
			const decodedLogs = SimpleExchange.decodeLogs( txReceipt.logs ) ;
			txResult = { receipt: txReceipt, blockNumber: txReceipt.blockNumber, logs: decodedLogs, rawLogs: txReceipt.logs } ;
			deployedContract.address = txReceipt.contractAddress ;
			console.error( "contractAddress = %s", JSON.stringify( deployedContract.address ) ) ;
			addressList[2] = deployedContract.address ;
			console.error( "addressList = %s", JSON.stringify( addressList ) ) ;
			const bytecode = await web3.eth.getCode( deployedContract.address ) ;
			console.error( "code = %s", JSON.stringify( bytecode ) ) ;
			eventPrototypeList = deployedContract.abi.filter( item => item.type === "event" ) ;
			console.error( "eventPrototypeList = %s", JSON.stringify( eventPrototypeList ) ) ;
			methodPrototypeList = deployedContract.abi.filter( item => item.constant ) ;
			console.error( "methodPrototypeList = %s", JSON.stringify( methodPrototypeList ) ) ;
			console.error( "txResult[0] = %s", JSON.stringify( txResult.receipt ) ) ;
		}
		const fromBalanceOriginal = { address: addressListOriginal[3], balance: "1020338141000000000" } ;
		console.error( "fromBalanceOriginal[0] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[3], balance: ( await web3.eth.getBalance( addressList[3], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[0] = %s", JSON.stringify( fromBalance ) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[0,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[0,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 0", async function( ) {
		await constantFunction( 0, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692227", timeStamp: "1542047019", hash: "0x0c322df019b79a8453329387ef2817d1a97beb2a4cd97b8085012cb433a04aaf", nonce: "0", blockHash: "0x43b28a285ca291fd5de416c8daa2aad674f6b5b77a16069a8916b45fa58efb36", transactionIndex: "93", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "116492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a27e4b484301377000000000000000000000000000000000000000000000000000456b63d322e8d00", contractAddress: "", cumulativeGasUsed: "7292574", gasUsed: "97077", confirmations: "1024527"} ;
		console.error( "txOriginal[1] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[1] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187342061679100000000","312637598100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[1] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187342061679100000000","312637598100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 1, 1542047019 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[1] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[1,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187342061679100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5337829588493104"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "312637598100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3198591615587261640"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[1,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[1] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[1] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[1] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[1] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[1,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[1,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 1", async function( ) {
		await constantFunction( 1, deployedContract ) ;
	} ) ;

	it( "TEST: sendTransaction(  )", async function( ) {
		const txOriginal = {blockNumber: "6692284", timeStamp: "1542047880", hash: "0xb1ae9d718ba78b477f0c71be6cb5dcf6c377fa40acb9dbd9c566a84c66712757", nonce: "40", blockHash: "0x55b47a5dc2f7c99a5fa354ffa141e4cfecbdad902dbc49a525dae1f4d307f993", transactionIndex: "65", from: "0x8601034a23e834a807aedc2628e589c35f4c0ffd", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "5000000000000000000", gas: "100000", gasPrice: "6500000000", isError: "0", txreceipt_status: "1", input: "0x", contractAddress: "", cumulativeGasUsed: "3208080", gasUsed: "23045", confirmations: "1024470"} ;
		console.error( "txOriginal[2] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[9], to: addressList[2], value: "5000000000000000000" }
		console.error( "txOptions[2] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [], name: "sendTransaction", outputs: [], type: "function"} ;
		console.error( "txCall[2] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.sendTransaction( txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 2, 1542047880 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[2] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: false, name: "sender", type: "address"}, {indexed: false, name: "amount", type: "uint256"}, {indexed: false, name: "balance", type: "uint256"}], name: "LogReceivedEther", type: "event"} ;
		console.error( "eventCallOriginal[2,3] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogReceivedEther", events: [{name: "sender", type: "address", value: "0x8601034a23e834a807aedc2628e589c35f4c0ffd"}, {name: "amount", type: "uint256", value: "5000000000000000000"}, {name: "balance", type: "uint256", value: "5000000000000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[2,3] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[9], balance: "185698700457500000000" } ;
		console.error( "fromBalanceOriginal[2] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[2] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[9], balance: ( await web3.eth.getBalance( addressList[9], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[2] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[2] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[2,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[2,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 2", async function( ) {
		await constantFunction( 2, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692288", timeStamp: "1542047949", hash: "0x7854f97f6176a08e762456a6dee96d283024ebb84a9a1bad5bd85ddc40fb8493", nonce: "1", blockHash: "0xae8fed133df34fbe83502855f656cea1deaab659bf11154d3e96ec04c36d2a80", transactionIndex: "24", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a22522d30560221000000000000000000000000000000000000000000000000000456a8db17d57f00", contractAddress: "", cumulativeGasUsed: "1527899", gasUsed: "67077", confirmations: "1024466"} ;
		console.error( "txOriginal[3] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[3] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186940529568100000000","312622883100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[3] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186940529568100000000","312622883100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 3, 1542047949 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[3] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[3,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186940529568100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5349294785407747"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "312622883100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3198742171666703563"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[3,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[3] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[3] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[3] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[3] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[3,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[3,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 3", async function( ) {
		await constantFunction( 3, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692294", timeStamp: "1542048013", hash: "0x165d60245716625474dcebd9e061e6fd356aad32e44f71c867899808dc941f23", nonce: "2", blockHash: "0x7a749ebb94c17652c02e0e9af1cb21d917ae824d5242da68a400a46d17f48d5d", transactionIndex: "67", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a210c57d4b809d0000000000000000000000000000000000000000000000000000455feaaa8ae2d00", contractAddress: "", cumulativeGasUsed: "2997811", gasUsed: "67077", confirmations: "1024460"} ;
		console.error( "txOriginal[4] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[4] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186848815611200000000","312435758100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[4] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186848815611200000000","312435758100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 4, 1542048013 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[4] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[4,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186848815611200000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5351920464301078"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "312435758100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3200657972318053949"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[4,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[4] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[4] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[4] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[4] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[4,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[4,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 4", async function( ) {
		await constantFunction( 4, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692347", timeStamp: "1542048718", hash: "0x7419efa7b55818f1825746810c5c21a0bbc9629dc57e3b1f91526756dc0bb8f0", nonce: "3", blockHash: "0xbfea399b5071bb98da576447d8dd08352ff8296f7cb4b9fe0b1160bb76dba33a", transactionIndex: "145", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a28065b15879495000000000000000000000000000000000000000000000000000455d5d4ef7f5500", contractAddress: "", cumulativeGasUsed: "7728901", gasUsed: "67077", confirmations: "1024407"} ;
		console.error( "txOriginal[5] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[5] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187351533496500000000","312390859700000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[5] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187351533496500000000","312390859700000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 5, 1542048718 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[5] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[5,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187351533496500000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5337559727092821"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "312390859700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3201117987127841692"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[5,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[5] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[5] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[5] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[5] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[5,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[5,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 5", async function( ) {
		await constantFunction( 5, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692357", timeStamp: "1542048824", hash: "0x051890f35e2cebf8518a1f85e21c949be92863dce4a561fea063b4b7e86f6163", nonce: "4", blockHash: "0xdc34135763458525e3dd6ed334ec6a4a3c2e086b84b39590ddd6d87209bb4c10", transactionIndex: "148", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a28065b15879495000000000000000000000000000000000000000000000000000455d5d4ef7f5500", contractAddress: "", cumulativeGasUsed: "7050875", gasUsed: "67077", confirmations: "1024397"} ;
		console.error( "txOriginal[6] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[6] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187351533496500000000","312390859700000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[6] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187351533496500000000","312390859700000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 6, 1542048824 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[6] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[6,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187351533496500000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5337559727092821"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "312390859700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3201117987127841692"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[6,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[6] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[6] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[6] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[6] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[6,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[6,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 6", async function( ) {
		await constantFunction( 6, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692399", timeStamp: "1542049570", hash: "0x7af748c45d4fd780fe10f5bdd9ef1e33be84a56eb26275570d7da2e8865f7ab8", nonce: "5", blockHash: "0x245a080f5b4494d37e896a74ce1eeaa40d85dcf1c3555a09461a87c549abd4d4", transactionIndex: "5", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2663ad0516cb5a000000000000000000000000000000000000000000000000000472e8b14d45c500", contractAddress: "", cumulativeGasUsed: "269924", gasUsed: "67077", confirmations: "1024355"} ;
		console.error( "txOriginal[7] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[7] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187233685570600000000","320574371700000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[7] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187233685570600000000","320574371700000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 7, 1542049570 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[7] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[7,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187233685570600000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5340919273967563"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "320574371700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3119400951164681016"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[7,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[7] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[7] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[7] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[7] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[7,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[7,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 7", async function( ) {
		await constantFunction( 7, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692405", timeStamp: "1542049640", hash: "0x392b96979b69f75352cc8dfd2835f0185f6223d2b516b0ee38341dd7ef95c2f7", nonce: "6", blockHash: "0x13a1cdd8931d4803ca5d80a0a556de3a8603adc081e530f4a304ad9408958b6b", transactionIndex: "73", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2663ad0516cb5a000000000000000000000000000000000000000000000000000472e8b14d45c500", contractAddress: "", cumulativeGasUsed: "6079623", gasUsed: "67077", confirmations: "1024349"} ;
		console.error( "txOriginal[8] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[8] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187233685570600000000","320574371700000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[8] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187233685570600000000","320574371700000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 8, 1542049640 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[8] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[8,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187233685570600000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5340919273967563"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "320574371700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3119400951164681016"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[8,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[8] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[8] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[8] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[8] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[8,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[8,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 8", async function( ) {
		await constantFunction( 8, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692453", timeStamp: "1542050333", hash: "0x0e45fc0be53548f98ebb117744bbb296c0351e7a5fe1fefead3909c8554cdbaf", nonce: "7", blockHash: "0xd69b746cd5d0a123b8149c7cc4df47158307c13aece12d5623d1a586efc3308a", transactionIndex: "107", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a22a133d4a92f150000000000000000000000000000000000000000000000000004752ee8dce2cd00", contractAddress: "", cumulativeGasUsed: "7238729", gasUsed: "67077", confirmations: "1024301"} ;
		console.error( "txOriginal[9] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[9] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186962773394100000000","321214526100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[9] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186962773394100000000","321214526100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 9, 1542050333 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[9] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[9,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186962773394100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5348658355062447"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "321214526100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3113184239023740714"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[9,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[9] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[9] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[9] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[9] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[9,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[9,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 9", async function( ) {
		await constantFunction( 9, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692494", timeStamp: "1542050991", hash: "0x9fc9bd35ab3fec4d5eb41cd656f0550e0a9ea28fa8f8166ac66b483aa71d6a78", nonce: "8", blockHash: "0x20db65be9044c117e18b2fbfca9b776bfda9b459e7f9e6e376ba2babb4e0cd82", transactionIndex: "49", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a215bda16eb5290000000000000000000000000000000000000000000000000000475178b6b99e800", contractAddress: "", cumulativeGasUsed: "2135356", gasUsed: "67077", confirmations: "1024260"} ;
		console.error( "txOriginal[10] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[10] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186871195355200000000","321188836000000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[10] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186871195355200000000","321188836000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 10, 1542050991 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[10] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[10,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186871195355200000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5351279516884480"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "321188836000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3113433245232720355"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[10,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[10] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[10] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[10] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[10] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[10,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[10,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 10", async function( ) {
		await constantFunction( 10, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692553", timeStamp: "1542051737", hash: "0x7557e231ad561e71da6b52dd25e0fc7aa5a274755419ca4e61307776a6fc75ea", nonce: "9", blockHash: "0x99d59c4c3a6fb126d60b35ffabefcdfcaeb0690b66f2859a446f96963613556d", transactionIndex: "56", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a1d5b2d9993433f000000000000000000000000000000000000000000000000000476e3f3405d8d00", contractAddress: "", cumulativeGasUsed: "6983646", gasUsed: "67077", confirmations: "1024201"} ;
		console.error( "txOriginal[11] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[11] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186582775324700000000","321695057300000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[11] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186582775324700000000","321695057300000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 11, 1542051737 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[11] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[11,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186582775324700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5359551535557093"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "321695057300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3108533927729700310"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[11,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[11] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[11] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[11] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[11] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[11,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[11,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 11", async function( ) {
		await constantFunction( 11, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692593", timeStamp: "1542052414", hash: "0x364ff37fe10c8b4e67ba3f7fcd1bd35ca2305fac6be997732ca4debbd7edcfc0", nonce: "10", blockHash: "0x6fcb76750c7f5caa7008d70af03aa4677f862cbf41a70abbdd01b8380938e0ad", transactionIndex: "65", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a212ed4031c436f000000000000000000000000000000000000000000000000000475ade0c4080d00", contractAddress: "", cumulativeGasUsed: "6793642", gasUsed: "67077", confirmations: "1024161"} ;
		console.error( "txOriginal[12] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[12] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186858522299100000000","321354129300000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[12] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186858522299100000000","321354129300000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 12, 1542052414 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[12] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[12,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186858522299100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5351642449571145"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "321354129300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3111831804303502379"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[12,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[12] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[12] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[12] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[12] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[12,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[12,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 12", async function( ) {
		await constantFunction( 12, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692647", timeStamp: "1542053151", hash: "0xb64d638b7f9598edbb700677be2778733d1aa351d49372ed854a609e89048b19", nonce: "11", blockHash: "0xe806125be47a879077f31fc5af286f69b644c362df681b90a367e3ffe1f3a03c", transactionIndex: "67", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a27af91ea9a873f000000000000000000000000000000000000000000000000000478983e52b55400", contractAddress: "", cumulativeGasUsed: "4952512", gasUsed: "67077", confirmations: "1024107"} ;
		console.error( "txOriginal[13] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[13] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187327105462300000000","322174766800000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[13] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187327105462300000000","322174766800000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 13, 1542053151 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[13] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[13,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187327105462300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5338255761397286"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "322174766800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3103905404921984722"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[13,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[13] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[13] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[13] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[13] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[13,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[13,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 13", async function( ) {
		await constantFunction( 13, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692693", timeStamp: "1542053845", hash: "0xa4ea2b09cd3956f44fe5d514f42b49b66d9ee619962a651ee44c643f4fe62c5a", nonce: "12", blockHash: "0xca4595b1e4319fa2551178884bf9212f46fb954d8055545dac213f6dc8a610d4", transactionIndex: "53", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a28f676a002f65d00000000000000000000000000000000000000000000000000047fd1663af57800", contractAddress: "", cumulativeGasUsed: "2870010", gasUsed: "67077", confirmations: "1024061"} ;
		console.error( "txOriginal[14] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[14] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187419117772500000000","324207935200000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[14] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187419117772500000000","324207935200000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 14, 1542053845 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[14] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[14,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187419117772500000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5335634976224021"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "324207935200000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3084440235502292542"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[14,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[14] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[14] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[14] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[14] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[14,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[14,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 14", async function( ) {
		await constantFunction( 14, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692703", timeStamp: "1542053946", hash: "0x63fea086a7e1d6cc2126dd84e30692490da55cd856241bccc0a52b2e4fe61b03", nonce: "13", blockHash: "0x2817ebb188b30cf3504f2bdb373098e4a3f8c9e846b6d0e1ce8a812c30e62d8d", transactionIndex: "62", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a28f676a002f65d00000000000000000000000000000000000000000000000000047fd1663af57800", contractAddress: "", cumulativeGasUsed: "3427031", gasUsed: "67077", confirmations: "1024051"} ;
		console.error( "txOriginal[15] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[15] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187419117772500000000","324207935200000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[15] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187419117772500000000","324207935200000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 15, 1542053946 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[15] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[15,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187419117772500000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5335634976224021"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "324207935200000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3084440235502292542"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[15,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "421361259300000000" } ;
		console.error( "fromBalanceOriginal[15] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[15] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[15] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[15] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[15,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[15,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 15", async function( ) {
		await constantFunction( 15, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692759", timeStamp: "1542054635", hash: "0x12ff1672cc611628f39d7915e28ea0162770ad53930d54bd249ec4b35c4bb998", nonce: "14", blockHash: "0x4498f0ccc6069173df47bafb3d75c12de8c502b5ba12ec361b28f35ca22c5cc6", transactionIndex: "126", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80415", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2a00ffdd1560a500000000000000000000000000000000000000000000000000047f7772e2433f00", contractAddress: "", cumulativeGasUsed: "6677275", gasUsed: "67013", confirmations: "1023995"} ;
		console.error( "txOriginal[16] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[16] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187494141011700000000","324109033500000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[16] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187494141011700000000","324109033500000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 16, 1542054635 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[16] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[16,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187494141011700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5333499994208342"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "324109033500000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3085381450807356161"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[16,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[16] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[16] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[16] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[16] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[16,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[16,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 16", async function( ) {
		await constantFunction( 16, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692818", timeStamp: "1542055300", hash: "0x6b54eeb482ba364fc737bf111ee6262ed1645da31ff3296499f35a9c1059cd72", nonce: "15", blockHash: "0xf4ad01a44f8c3da3b9f02bd002055a00d1d45974ea3a9d5d993b19c64dae3484", transactionIndex: "92", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2683f6f5f98c1000000000000000000000000000000000000000000000000000047f90febf53d400", contractAddress: "", cumulativeGasUsed: "7542619", gasUsed: "67077", confirmations: "1023936"} ;
		console.error( "txOriginal[17] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[17] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187242774068800000000","324137122000000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[17] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187242774068800000000","324137122000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 17, 1542055300 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[17] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[17,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187242774068800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5340660033334918"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "324137122000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3085114083292193851"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[17,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[17] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[17] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[17] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[17] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[17,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[17,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 17", async function( ) {
		await constantFunction( 17, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692865", timeStamp: "1542055981", hash: "0xf5a52fde36f2b9f1bc2f0e8c925abc28e29f0e812df3823a3f16df58fe3b63e1", nonce: "16", blockHash: "0xa98861d98711dd28833c1803ca26958c96a69784470fbc441656f5f040f38132", transactionIndex: "36", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a21c953ec0f4be800000000000000000000000000000000000000000000000000047c9c8a9bf86400", contractAddress: "", cumulativeGasUsed: "1719725", gasUsed: "67077", confirmations: "1023889"} ;
		console.error( "txOriginal[18] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[18] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186902010084000000000","323305392400000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[18] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186902010084000000000","323305392400000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 18, 1542055981 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[18] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[18,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186902010084000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5350397245864647"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323305392400000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3093050791936002364"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[18,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[18] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[18] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[18] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[18] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[18,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[18,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 18", async function( ) {
		await constantFunction( 18, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692919", timeStamp: "1542056664", hash: "0xcb8f61d52d497137bddd087e39334b2e9cecda77870fd2b9755e19b911d018e4", nonce: "17", blockHash: "0x102920bd5cc8a7fcbfb95941356dd54658340518152aaaa2daeefb2e67f5b6ac", transactionIndex: "86", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a280ec8b282285d00000000000000000000000000000000000000000000000000047ccda42e5cd700", contractAddress: "", cumulativeGasUsed: "4180928", gasUsed: "67077", confirmations: "1023835"} ;
		console.error( "txOriginal[19] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[19] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187353905817300000000","323359378300000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[19] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187353905817300000000","323359378300000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 19, 1542056664 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[19] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[19,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187353905817300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5337492141611181"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323359378300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3092534397045505453"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[19,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[19] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[19] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[19] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[19] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[19,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[19,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 19", async function( ) {
		await constantFunction( 19, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692924", timeStamp: "1542056743", hash: "0xf2a0810949f51315347887b920805cf443687df7eebdebf72dd2974f54aeda95", nonce: "18", blockHash: "0x28306bb3061469673532274c59a98e65d012a290bcac9b7ff1ca21b00997d860", transactionIndex: "116", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a280ec8b282285d00000000000000000000000000000000000000000000000000047ccda42e5cd700", contractAddress: "", cumulativeGasUsed: "6696819", gasUsed: "67077", confirmations: "1023830"} ;
		console.error( "txOriginal[20] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[20] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187353905817300000000","323359378300000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[20] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187353905817300000000","323359378300000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 20, 1542056743 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[20] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[20,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187353905817300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5337492141611181"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323359378300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3092534397045505453"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[20,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[20] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[20] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[20] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[20] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[20,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[20,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 20", async function( ) {
		await constantFunction( 20, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692986", timeStamp: "1542057436", hash: "0x9f1f3e697079f714da6340e11cb7fda5033858b81303edd709f29295059bf2fb", nonce: "19", blockHash: "0x3382cc127445e8fffe2a325550ec74b4b36c2b867085c662471c8f4ff7784dd8", transactionIndex: "55", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80415", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2d98b66baa776400000000000000000000000000000000000000000000000000047d00e571f5f900", contractAddress: "", cumulativeGasUsed: "3356077", gasUsed: "67013", confirmations: "1023768"} ;
		console.error( "txOriginal[21] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[21] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187753017238800000000","323415733700000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[21] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187753017238800000000","323415733700000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 21, 1542057436 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[21] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[21,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187753017238800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5326146097178914"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323415733700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3091995520934051577"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[21,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[21] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[21] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[21] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[21] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[21,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[21,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 21", async function( ) {
		await constantFunction( 21, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6692991", timeStamp: "1542057528", hash: "0x969cb8eff82601a09270e3278aacbd119487606e22e32c936dbc4638450d894a", nonce: "20", blockHash: "0x1c15209320e6d3959ffcf8b99a2e2adebfcb43a126da71f9377d49591c181504", transactionIndex: "59", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80415", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2d98b66baa776400000000000000000000000000000000000000000000000000047d00e571f5f900", contractAddress: "", cumulativeGasUsed: "3184755", gasUsed: "67013", confirmations: "1023763"} ;
		console.error( "txOriginal[22] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[22] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187753017238800000000","323415733700000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[22] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187753017238800000000","323415733700000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 22, 1542057528 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[22] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[22,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187753017238800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5326146097178914"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323415733700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3091995520934051577"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[22,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[22] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[22] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[22] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[22] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[22,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[22,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 22", async function( ) {
		await constantFunction( 22, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693047", timeStamp: "1542058211", hash: "0xd0d2f680316a1ad984fb1afafdb96725ef73826aa76837b2a7d1f266f89f1d4c", nonce: "21", blockHash: "0x66a237613e642c993dca6f5a028f2ef8a6daeb210967f9b337d4b194a947498a", transactionIndex: "14", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2874bd726933e600000000000000000000000000000000000000000000000000047e845c482caf00", contractAddress: "", cumulativeGasUsed: "2298425", gasUsed: "67077", confirmations: "1023707"} ;
		console.error( "txOriginal[23] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[23] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187382603895000000000","323841755100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[23] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187382603895000000000","323841755100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 23, 1542058211 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[23] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[23,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187382603895000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5336674692386871"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323841755100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3087927928537835423"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[23,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[23] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[23] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[23] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[23] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[23,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[23,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 23", async function( ) {
		await constantFunction( 23, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693052", timeStamp: "1542058267", hash: "0xb8e48ae378f0a3e5adb0edc0998e9b7df6e4079b5ceef39abb28d0a016dcf24c", nonce: "22", blockHash: "0x08e78d16a8cc09d65e670cb82d098b69c51efb9e02571eccb5cd904a58327052", transactionIndex: "67", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2874bd726933e600000000000000000000000000000000000000000000000000047e845c482caf00", contractAddress: "", cumulativeGasUsed: "4194143", gasUsed: "67077", confirmations: "1023702"} ;
		console.error( "txOriginal[24] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[24] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187382603895000000000","323841755100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[24] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187382603895000000000","323841755100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 24, 1542058267 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[24] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[24,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187382603895000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5336674692386871"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323841755100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3087927928537835423"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[24,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[24] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[24] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[24] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[24] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[24,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[24,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 24", async function( ) {
		await constantFunction( 24, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693103", timeStamp: "1542058937", hash: "0x3e1138862782e84592fdb47a6bfce13b5086f63cbad083bd1bc6fde3d5e2f9c0", nonce: "23", blockHash: "0xf2132fa9c6bc3f4f368d89ef906a44bf575d74e798329ed8215c1865f5967941", transactionIndex: "49", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2ad744178bb34a00000000000000000000000000000000000000000000000000047e43f3f5f76700", contractAddress: "", cumulativeGasUsed: "6432704", gasUsed: "67077", confirmations: "1023651"} ;
		console.error( "txOriginal[25] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[25] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187554451674600000000","323770938300000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[25] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187554451674600000000","323770938300000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 25, 1542058937 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[25] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[25,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187554451674600000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5331784935368865"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323770938300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3088603335588504856"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[25,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[25] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[25] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[25] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[25] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[25,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[25,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 25", async function( ) {
		await constantFunction( 25, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693144", timeStamp: "1542059616", hash: "0x6e7f5f55b18c0cc4fd004ab23f2ace1b51dce9d7c73472432bae21fae70dfbf6", nonce: "24", blockHash: "0x738405da4ef23119ca1e5f1f9ceeb628f907c6c5f8779617f9fff8520e63b1ec", transactionIndex: "25", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a27546e621796a600000000000000000000000000000000000000000000000000047e0a87621a2e00", contractAddress: "", cumulativeGasUsed: "1019234", gasUsed: "67077", confirmations: "1023610"} ;
		console.error( "txOriginal[26] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[26] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187301452170200000000","323707799800000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[26] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187301452170200000000","323707799800000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 26, 1542059616 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[26] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[26,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187301452170200000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5338986902735300"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323707799800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3089205760929582643"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[26,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[26] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[26] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[26] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[26] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[26,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[26,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 26", async function( ) {
		await constantFunction( 26, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693204", timeStamp: "1542060331", hash: "0x2c454b97bc093b1611f3ca6e19753901cf226c2b58fab8e133a0a2552b6fb0c8", nonce: "25", blockHash: "0xb623665629ee4704d23c5085db5d9036752cadf474438e5c5a010a42c236e5e4", transactionIndex: "117", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a272a725bf08e4800000000000000000000000000000000000000000000000000047e629f383b8000", contractAddress: "", cumulativeGasUsed: "7509443", gasUsed: "67077", confirmations: "1023550"} ;
		console.error( "txOriginal[27] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[27] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187289634592800000000","323804659200000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[27] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187289634592800000000","323804659200000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 27, 1542060331 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[27] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[27,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187289634592800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5339323781447770"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "323804659200000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3088281689555132874"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[27,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[27] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[27] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[27] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[27] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[27,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[27,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 27", async function( ) {
		await constantFunction( 27, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693243", timeStamp: "1542061012", hash: "0x32e317367c85178cb23427723cfb6d56548d4c1b6981ac9e78e8b56b3272f5c8", nonce: "26", blockHash: "0xaec8aa82b47c85d5f340bbf73179b932aba173b9554ee3b1dbe9f9932a79bba1", transactionIndex: "67", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a1c43776d9316d5000000000000000000000000000000000000000000000000000499dea0b4ece600", contractAddress: "", cumulativeGasUsed: "7954651", gasUsed: "67077", confirmations: "1023511"} ;
		console.error( "txOriginal[28] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[28] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186504043506100000000","331540829400000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[28] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186504043506100000000","331540829400000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 28, 1542061012 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[28] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[28,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186504043506100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5361814045427347"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "331540829400000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "3016219757336470004"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[28,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[28] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[28] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[28] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[28] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[28,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[28,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 28", async function( ) {
		await constantFunction( 28, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693288", timeStamp: "1542061662", hash: "0xc3f67838909aadbf4b58462a2c3f508bf99d420fdc446d92268488f4e2a4665b", nonce: "27", blockHash: "0x4b733494ec55119b7a3417dcc4eabb49f20ac3ceccc98cf39b93dcfe2b08465e", transactionIndex: "56", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a198aa46994843a0000000000000000000000000000000000000000000000000004b0a009850a9400", contractAddress: "", cumulativeGasUsed: "3760297", gasUsed: "67077", confirmations: "1023466"} ;
		console.error( "txOriginal[29] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[29] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186307904908200000000","337945934800000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[29] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186307904908200000000","337945934800000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 29, 1542061662 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[29] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[29,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186307904908200000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5367458780091659"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "337945934800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2959053200600890909"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[29,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[29] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[29] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[29] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[29] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[29,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[29,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 29", async function( ) {
		await constantFunction( 29, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693333", timeStamp: "1542062338", hash: "0xe27a368a3339b80fd60b4001c03422d596baa2605fce23bd963caf55ffdf3c79", nonce: "28", blockHash: "0x756628d040d825fdba22db5f0b2d1921f7a861f5322efb03b089751ce8fbe0f7", transactionIndex: "29", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a1f154dc3b30ad90000000000000000000000000000000000000000000000000004b1111e54dda200", contractAddress: "", cumulativeGasUsed: "2060755", gasUsed: "67077", confirmations: "1023421"} ;
		console.error( "txOriginal[30] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[30] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186707222629700000000","338070269000000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[30] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186707222629700000000","338070269000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 30, 1542062338 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[30] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[30,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186707222629700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5355979195209385"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "338070269000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2957964931249248658"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[30,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[30] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[30] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[30] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[30] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[30,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[30,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 30", async function( ) {
		await constantFunction( 30, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693382", timeStamp: "1542063018", hash: "0xd80cf735213ea95f0db2af2de70e9bf4a15d319c268b5cf4a8923593f7b3ac03", nonce: "29", blockHash: "0xe02e435e67a1c0550e6c9de47ac95c1bf16a522d432514e49f0464ce9392e056", transactionIndex: "28", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a21c1d09de99b330000000000000000000000000000000000000000000000000004b50f3c947cc600", contractAddress: "", cumulativeGasUsed: "6822496", gasUsed: "67077", confirmations: "1023372"} ;
		console.error( "txOriginal[31] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[31] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186899895387500000000","339194099800000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[31] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186899895387500000000","339194099800000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 31, 1542063018 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[31] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[31,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186899895387500000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5350457783439084"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "339194099800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2948164489269220478"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[31,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[31] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[31] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[31] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[31] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[31,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[31,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 31", async function( ) {
		await constantFunction( 31, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693431", timeStamp: "1542063707", hash: "0x21daa066324722173ff03f710cde2211dd35634369e739ba2d8fb7bf8409ae9f", nonce: "30", blockHash: "0xa8c0e6e9ca15fa4aee77cfabcf6a7c40446ec5e84361dcc8b906a087b2602cc0", transactionIndex: "89", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a24de0329db64180000000000000000000000000000000000000000000000000004b1cd6ae3b4c400", contractAddress: "", cumulativeGasUsed: "5113556", gasUsed: "67077", confirmations: "1023323"} ;
		console.error( "txOriginal[32] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[32] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187124005045600000000","338277306000000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[32] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187124005045600000000","338277306000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 32, 1542063707 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[32] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[32,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187124005045600000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5344049790705962"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "338277306000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2956154558000411650"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[32,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[32] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[32] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[32] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[32] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[32,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[32,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 32", async function( ) {
		await constantFunction( 32, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693437", timeStamp: "1542063906", hash: "0x303e32294abb8e86fb9456a885e6357d2bea1eb1ea11da2f00a823c6f3f48012", nonce: "31", blockHash: "0x8334415884711805e115330ce80aa7811d48dd7220eab02683b1e521d82e7171", transactionIndex: "90", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a235bd39328b0eb0000000000000000000000000000000000000000000000000004b1e64e40e3b400", contractAddress: "", cumulativeGasUsed: "4379833", gasUsed: "67077", confirmations: "1023317"} ;
		console.error( "txOriginal[33] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[33] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187015303380300000000","338304670800000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[33] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187015303380300000000","338304670800000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 33, 1542063906 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[33] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[33,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187015303380300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5347155991648858"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "338304670800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2955915440467516005"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[33,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[33] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[33] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[33] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[33] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[33,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[33,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 33", async function( ) {
		await constantFunction( 33, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693445", timeStamp: "1542063996", hash: "0x758e2089c1c59ca732134bdc09af4e7763e5d669e2603fc2504af22755381093", nonce: "32", blockHash: "0xa63fb5e7e7c73ecebd66e00bed5f22576b083676773377f5af334f7367d1cb31", transactionIndex: "68", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a235bd39328b0eb0000000000000000000000000000000000000000000000000004b1e64e40e3b400", contractAddress: "", cumulativeGasUsed: "4117205", gasUsed: "67077", confirmations: "1023309"} ;
		console.error( "txOriginal[34] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[34] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187015303380300000000","338304670800000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[34] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187015303380300000000","338304670800000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 34, 1542063996 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[34] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[34,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187015303380300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5347155991648858"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "338304670800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2955915440467516005"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[34,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[34] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[34] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[34] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[34] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[34,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[34,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 34", async function( ) {
		await constantFunction( 34, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693452", timeStamp: "1542064126", hash: "0x60b7393f88f5aceb9499930b40f7781a6892f6b1a4a858d2088063824978617c", nonce: "33", blockHash: "0x8b98dcb4ea655684f62732ed46316987412abe3b347cbb784dc8dca043d98947", transactionIndex: "68", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2528165a01c7920000000000000000000000000000000000000000000000000004b5359d2bf5b100", contractAddress: "", cumulativeGasUsed: "3496226", gasUsed: "67077", confirmations: "1023302"} ;
		console.error( "txOriginal[35] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[35] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187144855291400000000","339236296100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[35] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187144855291400000000","339236296100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 35, 1542064126 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[35] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[35,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187144855291400000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5343454397626466"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "339236296100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2947797778411129162"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[35,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[35] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[35] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[35] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[35] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[35,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[35,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 35", async function( ) {
		await constantFunction( 35, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693462", timeStamp: "1542064226", hash: "0x03911d9bbad410baec65de3266170ff36161206e656d08bb6664e615f0c56398", nonce: "34", blockHash: "0x9e627947a0950f4cef4bd3c35400723f1fd8ee725a6d19b595f6e64b471510b5", transactionIndex: "43", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2528165a01c7920000000000000000000000000000000000000000000000000004b5359d2bf5b100", contractAddress: "", cumulativeGasUsed: "1916463", gasUsed: "67077", confirmations: "1023292"} ;
		console.error( "txOriginal[36] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[36] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187144855291400000000","339236296100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[36] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187144855291400000000","339236296100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 36, 1542064226 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[36] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[36,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187144855291400000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5343454397626466"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "339236296100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2947797778411129162"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[36,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[36] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[36] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[36] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[36] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[36,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[36,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 36", async function( ) {
		await constantFunction( 36, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693466", timeStamp: "1542064269", hash: "0x0b7166c35812ec1ed1bcfd862f9af540d170b7d5681cbe9bffd2d3ae54badb11", nonce: "35", blockHash: "0xbc93321c12315ddbac056e447b1d6fce2bec5a0115cd042c092cb15b2d1ac2c0", transactionIndex: "154", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a25eeb39cf7398d0000000000000000000000000000000000000000000000000004b591ab91545a00", contractAddress: "", cumulativeGasUsed: "4690717", gasUsed: "67077", confirmations: "1023288"} ;
		console.error( "txOriginal[37] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[37] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187200760247700000000","339337513000000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[37] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187200760247700000000","339337513000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 37, 1542064269 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[37] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[37,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187200760247700000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5341858647779110"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "339337513000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2946918515313100677"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[37,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[37] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[37] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[37] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[37] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[37,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[37,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 37", async function( ) {
		await constantFunction( 37, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693513", timeStamp: "1542064952", hash: "0x2e36351e38b581044f21102e9eb32d63d1f3cc5c80e0e6e466bc38bb05cb7f39", nonce: "36", blockHash: "0x42a6a3cae959df985b7bfc74bcd013d14b4a72d96116377278812c43baa40e53", transactionIndex: "25", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a242894e8ade2e60000000000000000000000000000000000000000000000000004a8bfbc76621c00", contractAddress: "", cumulativeGasUsed: "1571757", gasUsed: "67077", confirmations: "1023241"} ;
		console.error( "txOriginal[38] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[38] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187072936848600000000","335728988400000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[38] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187072936848600000000","335728988400000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 38, 1542064952 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[38] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[38,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187072936848600000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5345508638747196"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "335728988400000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2978592956079690139"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[38,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[38] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[38] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[38] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[38] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[38,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[38,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 38", async function( ) {
		await constantFunction( 38, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693570", timeStamp: "1542065617", hash: "0x8dc8da3f994d9c15be3e0e111a23894eeadbd84772e42ae047f4b6330125c53e", nonce: "37", blockHash: "0x8559f10a253fccb0e9c18eccd8eeb0065b3a504a47bc2d1f045c31b4d8e102d1", transactionIndex: "77", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a24f8b0640444cb0000000000000000000000000000000000000000000000000004a58bc6639d2b00", contractAddress: "", cumulativeGasUsed: "3234484", gasUsed: "67077", confirmations: "1023184"} ;
		console.error( "txOriginal[39] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[39] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187131513860300000000","334827431500000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[39] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187131513860300000000","334827431500000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 39, 1542065617 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[39] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[39,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187131513860300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5343835356061587"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "334827431500000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2986613120436639015"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[39,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[39] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[39] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[39] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[39] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[39,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[39,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 39", async function( ) {
		await constantFunction( 39, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693617", timeStamp: "1542066280", hash: "0x94c44e50e2f45c898de3cd5c10c0325ea6c9f3101f6c4fbe66e71f60d806bdd6", nonce: "38", blockHash: "0x3d855dd968e51a7c2dc03ccdb50abc658501f75641d466c3522c0518c3004e6e", transactionIndex: "56", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a264bfc7e83f4950000000000000000000000000000000000000000000000000004a942dccc155100", contractAddress: "", cumulativeGasUsed: "4881692", gasUsed: "67077", confirmations: "1023137"} ;
		console.error( "txOriginal[40] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[40] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187227017554100000000","335873163300000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[40] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187227017554100000000","335873163300000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 40, 1542066280 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[40] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[40,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187227017554100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5341109488704246"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "335873163300000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2977314383128626698"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[40,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[40] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[40] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[40] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[40] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[40,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[40,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 40", async function( ) {
		await constantFunction( 40, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693671", timeStamp: "1542067011", hash: "0x001b9e4211ea856491f4039634ae0bb6ead4a27af614d77aa690c2708b8234f3", nonce: "39", blockHash: "0x226dbba37151603b78f9351c758176ed99f3afa60d84dc65bf56071fd45fb86b", transactionIndex: "53", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "2000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a26f4eeea9264910000000000000000000000000000000000000000000000000004a61e9ee0270400", contractAddress: "", cumulativeGasUsed: "5586069", gasUsed: "67077", confirmations: "1023083"} ;
		console.error( "txOriginal[41] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[41] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187274571896100000000","334988890000000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[41] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187274571896100000000","334988890000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 41, 1542067011 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[41] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[41,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187274571896100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5339753229043825"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "334988890000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2985173627698518599"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[41,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[41] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[41] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[41] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[41] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[41,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[41,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 41", async function( ) {
		await constantFunction( 41, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693717", timeStamp: "1542067661", hash: "0x2edb6ec7e2fdce0b2ca972960b38ea69754d020dd52d9e23123c19a7436739f7", nonce: "40", blockHash: "0xd7ae70d7d1ab59184fb36ee07443563b93ea89c4a8b9d8005527ec28bb9965b5", transactionIndex: "73", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a26913c13c6f7da0000000000000000000000000000000000000000000000000004a69bb44e8d9200", contractAddress: "", cumulativeGasUsed: "3942351", gasUsed: "67077", confirmations: "1023037"} ;
		console.error( "txOriginal[42] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[42] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187246509237800000000","335126421000000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[42] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187246509237800000000","335126421000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 42, 1542067661 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[42] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[42,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187246509237800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5340553498543550"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "335126421000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2983948555939133191"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[42,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[42] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[42] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[42] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[42] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[42,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[42,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 42", async function( ) {
		await constantFunction( 42, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693722", timeStamp: "1542067765", hash: "0x7cf4b1ded5a629bf58b306dadb1433b018a46d17400f1ceef1b86e9b5f8da94d", nonce: "41", blockHash: "0xa788df66ecb57f52fb5f02a3cdb7def1ea5609c181a19a19f3fd5c6c16bea6c2", transactionIndex: "89", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a26913c13c6f7da0000000000000000000000000000000000000000000000000004a69bb44e8d9200", contractAddress: "", cumulativeGasUsed: "6521339", gasUsed: "67077", confirmations: "1023032"} ;
		console.error( "txOriginal[43] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[43] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187246509237800000000","335126421000000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[43] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187246509237800000000","335126421000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 43, 1542067765 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[43] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[43,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187246509237800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5340553498543550"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "335126421000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2983948555939133191"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[43,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[43] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[43] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[43] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[43] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[43,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[43,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 43", async function( ) {
		await constantFunction( 43, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693776", timeStamp: "1542068472", hash: "0xa7ba910a0ee14bf6313627c7e3f70ab724874b3feb4221d90ad19b44695c8277", nonce: "42", blockHash: "0x6eec838c928510b307d0d92e1aa2bb99f9dc0dfc887448d4690ea31314396c4d", transactionIndex: "113", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a26ec6ce0ba9fc70000000000000000000000000000000000000000000000000004a8943f3f014400", contractAddress: "", cumulativeGasUsed: "5862914", gasUsed: "67077", confirmations: "1022978"} ;
		console.error( "txOriginal[44] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[44] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187272177117500000000","335681171600000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[44] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187272177117500000000","335681171600000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 44, 1542068472 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[44] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[44,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187272177117500000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5339821512154317"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "335681171600000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2979017247924786497"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[44,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[44] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[44] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[44] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[44] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[44,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[44,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 44", async function( ) {
		await constantFunction( 44, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693815", timeStamp: "1542069146", hash: "0xce0f390bd3808c22d42142142d6de287ad59f657fa770eb69ba1dd7385477717", nonce: "43", blockHash: "0x5776a0fed5158c6a5c7a89aabef89f016c5accee76003bad1f34e3e30e3e4301", transactionIndex: "121", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a289087c1e509550000000000000000000000000000000000000000000000000004a89f4793301c00", contractAddress: "", cumulativeGasUsed: "6949803", gasUsed: "67077", confirmations: "1022939"} ;
		console.error( "txOriginal[45] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[45] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187390426162100000000","335693302000000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[45] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187390426162100000000","335693302000000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 45, 1542069146 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[45] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[45,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187390426162100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5336451922762378"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "335693302000000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2978909600049154392"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[45,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[45] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[45] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[45] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[45] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[45,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[45,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 45", async function( ) {
		await constantFunction( 45, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693862", timeStamp: "1542069891", hash: "0x2a7be0fb05af557a6d8235ab78b0da0ea7453e83f6e392af16d3f2a4df768d36", nonce: "44", blockHash: "0x86684d9b404e89e55e8ed2ace75ee00994b05ac4425c1911a81b932a3b278d6b", transactionIndex: "42", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a24ca95f9da66310000000000000000000000000000000000000000000000000004a688d0aba56900", contractAddress: "", cumulativeGasUsed: "2293693", gasUsed: "67077", confirmations: "1022892"} ;
		console.error( "txOriginal[46] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[46] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187118536968100000000","335105652100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[46] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187118536968100000000","335105652100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 46, 1542069891 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[46] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[46,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187118536968100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5344205957373855"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "335105652100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2984133492626339381"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[46,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[46] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[46] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[46] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[46] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[46,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[46,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 46", async function( ) {
		await constantFunction( 46, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693914", timeStamp: "1542070552", hash: "0xb21226bf889edcef53f751da01f4c0b01394f39abb4a9eaf1464a3c8da64c1d1", nonce: "45", blockHash: "0x36a4f2fb9a6f306851f609a2b71aa23c22c82db6fd6d47cbfc376e7ebc703f9d", transactionIndex: "60", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a1fba90e52c06870000000000000000000000000000000000000000000000000004a6686560298500", contractAddress: "", cumulativeGasUsed: "5412601", gasUsed: "67077", confirmations: "1022840"} ;
		console.error( "txOriginal[47] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[47] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186753739811900000000","335070006900000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[47] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186753739811900000000","335070006900000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 47, 1542070552 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[47] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[47,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186753739811900000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5354645111831274"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "335070006900000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2984450948778728186"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[47,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[47] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[47] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[47] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[47] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[47,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[47,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 47", async function( ) {
		await constantFunction( 47, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6693974", timeStamp: "1542071383", hash: "0xe49ca94cc092f29475bbea4b0bbbef710ff556cbb50faac6759ef01598532d87", nonce: "46", blockHash: "0xe7566b36cb93faa31feb7e2d8aeed615c8dd9a27e3dabeb9563b121af83bb4c6", transactionIndex: "7", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "3000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a2512c49c6cdce60000000000000000000000000000000000000000000000000004a8c12ac0691000", contractAddress: "", cumulativeGasUsed: "723160", gasUsed: "67077", confirmations: "1022780"} ;
		console.error( "txOriginal[48] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[48] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["187138854442200000000","335730561600000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[48] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["187138854442200000000","335730561600000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 48, 1542071383 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[48] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[48,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "187138854442200000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5343625742396866"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "335730561600000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2978578998689525321"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[48,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[48] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[48] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[48] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[48] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[48,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[48,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 48", async function( ) {
		await constantFunction( 48, deployedContract ) ;
	} ) ;

	it( "TEST: setExchangeRates( [addressList[6],addressList[8]], [addres... )", async function( ) {
		const txOriginal = {blockNumber: "6694024", timeStamp: "1542072077", hash: "0xa8050e896942c47e21774c54508c0c70b3d2321bfefc23bbf6d2f9ef97dcc254", nonce: "47", blockHash: "0x626658bc27d9609dab77798b769ce39f4c0e8a8cee3ad71afbbc3f0f62168757", transactionIndex: "150", from: "0x7c725f972d1ebdef5bbfd8996d3cbe307b23cd42", to: "0x4426d15ad435c156edc1183938ff47b37d3931fb", value: "0", gas: "80492", gasPrice: "4000000000", isError: "0", txreceipt_status: "1", input: "0xe8b6ab90000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000c0000000000000000000000000000000000000000000000000000000000000012000000000000000000000000000000000000000000000000000000000000000020000000000000000000000000b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951000000000000000000000000a823e6722006afe99e91c30ff5295052fe6b8e32000000000000000000000000000000000000000000000000000000000000000200000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d800000000000000000000000061646f3bede9e1a24d387feb661888b4cc1587d8000000000000000000000000000000000000000000000000000000000000000200000000000000000000000000000000000000000000000a1c554ced6d24ea0000000000000000000000000000000000000000000000000004a4771e3db11900", contractAddress: "", cumulativeGasUsed: "6303696", gasUsed: "67077", confirmations: "1022730"} ;
		console.error( "txOriginal[49] = %s", JSON.stringify( txOriginal ) ) ;
		const txOptions = { from: addressList[7], to: addressList[2], value: "0" }
		console.error( "txOptions[49] = %s", JSON.stringify( txOptions ) ) ;
		const txCall = {inputs: [{type: "address[]", name: "numeratorTokens", value: [addressList[6],addressList[8]]}, {type: "address[]", name: "denominatorTokens", value: [addressList[5],addressList[5]]}, {type: "uint256[]", name: "rateFractions", value: ["186509063325800000000","334523244100000000"]}], name: "setExchangeRates", outputs: [], type: "function"} ;
		console.error( "txCall[49] = %s", JSON.stringify( txCall ) ) ;
		var txRequest, txResult ;
		try {
			txRequest = deployedContract.methods[ "setExchangeRates(address[],address[],uint256[])" ]( [addressList[6],addressList[8]], [addressList[5],addressList[5]], ["186509063325800000000","334523244100000000"], txOptions ) ;
			await new Promise( (resolve) => { txRequest.on( "transactionHash", resolve ) } ) ;
		} catch( requestError ) {
			txRequest = { receipt: { isError: 1, message: requestError.message }, blockNumber: "latest", logs: [] } ;
		}
		await support.mineBlockWithTimestamp( 49, 1542072077 ) ;
		try {
			txResult = await txRequest ;
		} catch( resultError ) {
			txResult = { receipt: { isError: 1, message: resultError.message }, blockNumber: "latest", logs: [] } ;
		}
		console.error( "txResult[49] = %s", JSON.stringify( txResult.receipt ) ) ;
		eventCallOriginal = {anonymous: false, inputs: [{indexed: true, name: "numeratorToken", type: "address"}, {indexed: true, name: "denominatorToken", type: "address"}, {indexed: false, name: "rate", type: "uint256"}], name: "LogSetExchangeRate", type: "event"} ;
		console.error( "eventCallOriginal[49,2] = %s", JSON.stringify( eventCallOriginal ) ) ;
		eventResultOriginal = [{name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "186509063325800000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0x0b7dc5a43ce121b4eaaa41b0f4f43bba47bb8951"}, {name: "rate", type: "uint256", value: "5361669734264699"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "denominatorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "rate", type: "uint256", value: "334523244100000000"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}, {name: "LogSetExchangeRate", events: [{name: "numeratorToken", type: "address", value: "0x61646f3bede9e1a24d387feb661888b4cc1587d8"}, {name: "denominatorToken", type: "address", value: "0xa823e6722006afe99e91c30ff5295052fe6b8e32"}, {name: "rate", type: "uint256", value: "2989328896084324444"}], address: "0x4426d15ad435c156edc1183938ff47b37d3931fb"}] ;
		console.error( "eventResultOriginal[49,2] = %s", JSON.stringify( eventResultOriginal ) ) ;
		const fromBalanceOriginal = { address: addressListOriginal[7], balance: "420924426800000000" } ;
		console.error( "fromBalanceOriginal[49] = %s", JSON.stringify( fromBalanceOriginal ) ) ;
		const toBalanceOriginal = { address: addressListOriginal[2], balance: "4534381084084180753" } ;
		console.error( "toBalanceOriginal[49] = %s", JSON.stringify( toBalanceOriginal ) ) ;
		const fromBalance = { address: addressList[7], balance: ( await web3.eth.getBalance( addressList[7], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "fromBalance[49] = %s", JSON.stringify( fromBalance ) ) ;
		const toBalance = { address: addressList[2], balance: ( await web3.eth.getBalance( addressList[2], txResult.blockNumber ) ).toString( 10, 85) } ;
		console.error( "toBalance[49] = %s", JSON.stringify( toBalance) ) ;
		for( var eventIndex = 0; eventIndex < eventPrototypeList.length; eventIndex++ ) {
			const eventCall = eventPrototypeList[ eventIndex ] ;
			const eventLogs = txResult.logs.filter( item => item.event === eventCall.name && item.args.__length__ === eventCall.inputs.length ) ;
			if( eventLogs.length > 0 ) {
				console.error( "eventCall[49,%d] = %s", eventIndex, JSON.stringify( eventCall ) ) ;
				console.error( "eventResult[49,%d] = %s", eventIndex, JSON.stringify( eventLogs.map( item => mergeEvent( eventCall, item.args ) ) ) ) ;
			}
		}
	} ) ;

	it( "TEST: constantFunction 49", async function( ) {
		await constantFunction( 49, deployedContract ) ;
	} ) ;

	it( "TEST: check all blocks", async function( ) {
		const blocknumber = await support.getBlockNumber( ) ;
		for( var i = 0; i <= blocknumber; i++ ) {
			const block = await web3.eth.getBlock( i, true ) ;
			console.error( "block[%d] = %s", i, JSON.stringify( block ) ) ;
		}
	} )

	it( "analysis", async function( ) {
		console.error( "console.log( contractName, addressListOriginal[ 2 ] ) ;" ) ;
		console.error( "txResult.map( ( item, index ) => {" ) ;
		console.error( "	if( item.isError ) {" ) ;
		console.error( "		console.log( \"%s tx %d failure: %s\", contractName, index, item.message ) ;" ) ;
		console.error( "	} else {" ) ;
		console.error( "		console.log( \"%s tx %d success: %d gas used\", contractName, index, item.gasUsed ) ;" ) ;
		console.error( "	}" ) ;
		console.error( "} )" ) ;
	} )
} )
