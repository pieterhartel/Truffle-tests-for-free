var addressList ;
var addressListOriginal ;
var block = [] ;
var constructorPrototypeOriginal ;
var contractAddress ;
var contractName ;
var createTransactionHash ;
var eventCall = new Array( 50 ).fill( [] ) ;
var eventCallOriginal = new Array( 50 ).fill( [] ) ;
var eventPrototypeList ;
var eventPrototypeListOriginal ;
var eventResult = new Array( 50 ).fill( [] ) ;
var eventResultOriginal = new Array( 50 ).fill( [] ) ;
var eventSignatureListOriginal ;
var fromBalance = [] ;
var fromBalanceOriginal = [] ;
var fromBlockOriginal ;
var methodCall = [] ;
var methodPrototypeList ;
var methodPrototypeListOriginal ;
var methodResult = [] ;
var nBlocksOriginal ;
var toBalance = [] ;
var toBalanceOriginal = [] ;
var toBlockOriginal ;
var topicListOriginal ;
var txCall = [] ;
var txDeployer ;
var txOptions = [] ;
var txOriginal = [] ;
var txResult = [] ;
var txTime = [] ;
contractName = "ShibbolethToken"
addressListOriginal = ["0x0000000000000000000000000000000000000000","0x0000000000000000000000000000000000000001","0xe19d396c4e7f96eBA568E9d62ad80aB902d207C8","0x2D915c3e78767b123Bf56AB2Daa49F74bB97904c","0x314159265dD8dbb310642f98f50C066173C1259b","0x0904Dac3347eA47d208F3Fd67402D039a3b99859","0xFa6F2D7cC987d592556ac07392b9d6395bfcc379","0xE6171f5f5f04a7c044b0dCDd3cC4e84ef46dF01c","0x5ED8ee5A5C7CC34106EF15FE92C71ED5959722C5","0x9236A9016394b9dFC75b43b00aC37E3bF1E44508","0xD357C63ad90855178E5169Cb1666BD47542d8852","0xBc7221B0c8226C3bAEFD31421bA125eA6178EF6F","0xcd47D84c99B1bac5d261dd747e5E8f49BF35d02B","0xFa333dfeeEb1730ab9DbD21Ac902F9987b8060f2","0x6539857DBb97eE920567E042d3568Ab300b9f14B","0xda83663DA0e859c2c6457b266DAA9Cc73543f4C1","0x0f883e35aaa52751373496E72342d7d417721777","0xEc02c765e00Fd4f0059C6A338ab825a1DCf12Fce","0x85c242efF7186a105E78e0f056b8F91C8Cd1ff7A","0x9E96ae20E05FDc513bD68Baa4296cD451D5013fc","0x3c661347183950C84B9aEa0C0e82Fd0Ca3a23f04","0x888A38124bC79aCE4C7132bE332B192c66563E0f","0xFF2E3345a125F46094360014BD6A78FF62fd901F","0x8c6B463Ab06bC37e9796ce2d7676D235C2a9a7F7","0x1ecb3296ED031758318f04d686625C6898591d36","0xDb297F4477B643815844C726861503DcC0EE72B5","0x4A9e7c935574da7df4B63AcCeFa6e9674dF8eEd0","0x2a73272426d8E350f7bb85652A88F1Ab38B5FC43","0xAd0cB72454C434725fB8007abf9F1b3980996e24","0x50Bc04cB110Ae14107d5F166Faaed8C64ee2EfBA","0x2D123946bA5621e11C6ed17A9e4051918F78503E","0xcf6A3Ebf534Ab0681D08b76CE12bA259B43D23E3","0x9f0ff2E19bB8256d6A9903844997A5Ed44600A80","0xC67714435964E87D498096A6990EA2Be7a99D390","0xA85c6f0011e2c30eCbCfdC17d899168740E8faA3","0x7Ef729e864AB4E2EC1B794a19a8604dAedE4EBcE","0xe198051c0026654D35c8D8CeC79460A754CfCCCE","0xa2AE693a161e72AB77d0527D4aaBa2448985bb6E","0x76Ed896d3f16Bb86E49AFD5BA4577Ad41794626c","0x9807D7d9113DB216c0A9a8F5c98Fa8b1BEDdfc18","0x21fA01b2BF46b95cacE468434D9afE233B424431","0x3F5718FeCBda5637F9D0e3a45D59c42E0194BD1C","0x0D0786AE8470D2b004165079146aEf6c9C522370","0x0561C84cd9cD6bD609a8609954C297eE89801f50","0x8B247cdee11c02955557446D69741BBE75a263c6","0x412cA4adbCE75ceA857Ccc409C2e9420878CCD22","0x402e84f4F0C8AC8fa030746eda4Fe0C1514Ec3fe","0xE52c324e736F25Fd0643Ea518E5c0ed101Cb7dFE","0xc737412D31bad4c44C1B62d213A605A0833e48A5","0x8115A73282a80Be18B9B6DA1Ee6b9D42EA5aAEF6","0x0Efb05BC14Be5a2D85A8d197E81eA6817526BC21","0x7D3817901c8C5D43661440e956ebBBCBFf37Dff7","0x23CD924A6ecC3aB8977607520A6BeC1D8544ebbC"]
addressListOriginal.length = 53
methodPrototypeListOriginal = [{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"issuer","outputs":[{"name":"","type":"address"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"version","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"node","type":"bytes32"}],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"remaining","type":"uint256"}],"payable":false,"type":"function"}]
eventPrototypeListOriginal = [{"anonymous":false,"inputs":[{"indexed":true,"name":"_from","type":"address"},{"indexed":true,"name":"_to","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_owner","type":"address"},{"indexed":true,"name":"_spender","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Approval","type":"event"}]
eventSignatureListOriginal = ["Transfer(address,address,uint256)","Approval(address,address,uint256)"]
topicListOriginal = ["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef","0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"]
nBlocksOriginal = 51
fromBlockOriginal = 4062003
toBlockOriginal = 4062220
constructorPrototypeOriginal = {"inputs":[{"type":"address","name":"_ens","value":4},{"type":"string","name":"_name","value":"token.breaktheblock.eth"},{"type":"string","name":"_symbol","value":"btb"},{"type":"address","name":"_issuer","value":5}],"name":"ShibbolethToken","outputs":[],"type":"function"}
txOriginal[0] = {"blockNumber":4062003,"timeStamp":"0x597481cb","hash":"0xcc6898a7cf634eeeb798761c09a3f422284f6fe62caf6535a87be1116f00ee0b","from":"0x2d915c3e78767b123bf56ab2daa49f74bb97904c","to":0,"value":"0x0","isError":"0","txreceipt_status":"1","gas":"0xaf961","input":"0x3caf613a000000000000000000000000314159265dd8dbb310642f98f50c066173c1259b000000000000000000000000000000000000000000000000000000000000008000000000000000000000000000000000000000000000000000000000000000c00000000000000000000000000904dac3347ea47d208f3fd67402d039a3b998590000000000000000000000000000000000000000000000000000000000000017746f6b656e2e627265616b746865626c6f636b2e65746800000000000000000000000000000000000000000000000000000000000000000000000000000000036274620000000000000000000000000000000000000000000000000000000000","contractAddress":"0xe19d396c4e7f96eba568e9d62ad80ab902d207c8","gasUsed":"0xaf961"}
txOptions[0] = {"from":"0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1","to":0,"value":"0x0"}
txCall[0] = {"inputs":[{"type":"address","name":"_ens","value":"0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0"},{"type":"string","name":"_name","value":"token.breaktheblock.eth"},{"type":"string","name":"_symbol","value":"btb"},{"type":"address","name":"_issuer","value":"0x22d491Bde2303f2f43325b2108D26f1eAbA1e32b"}],"name":"ShibbolethToken","outputs":[],"type":"function"}
txResult[0] = {"isError":1,"message":"The contract code couldn't be stored, please check your gas limit."}
